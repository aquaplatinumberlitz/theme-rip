# Sulat Models local build

Requires Node.js 22 or newer. No dependency installation or API key is needed.

Run `npm start`, then open http://localhost:4174/ or http://localhost:4174/models/xai-grok-45-97244c89.

Set PORT to change the port. Keep server/, src/, data/, public/ and reference/ together. The two saved pages use JSON on disk. Unarchived links open the original website when selected; external video playback requires internet.
