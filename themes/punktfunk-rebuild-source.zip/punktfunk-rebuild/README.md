# Punktfunk — bản dựng lại trang chủ

Bản local của **https://punktfunk.unom.io/en/**, gồm bố cục responsive, nội dung, font, hình hero và năm cảnh chuyển động. Trang chạy bằng HTML, CSS và JavaScript ES modules, không cần cài thư viện để chạy hoặc build.

## Chạy

Cần Node.js 22 trở lên; đã kiểm tra với Node.js 24.

```sh
cd /home/admin/punktfunk-rebuild
npm run dev
```

Mở **http://localhost:4173/en/**. Có thể đổi cổng bằng `npm run dev -- --port 8080`.

Không mở `index.html` bằng `file://`: trình duyệt cần HTTP để tải ES modules.

## Build để đưa lên hosting tĩnh

```sh
npm run check
npm run build
npm run preview
```

Upload **nội dung thư mục `dist/`** vào thư mục gốc của hosting. Cả `/` và `/en/` đều có trang. Các đường dẫn tài nguyên bắt đầu từ `/`, nên nếu host trong một subfolder cần đổi base path.

## Source để sửa

- `index.html`: toàn bộ nội dung, cấu trúc và SVG của trang chủ.
- `src/app.js`: khởi tạo, theo dõi cài đặt giảm chuyển động, dọn tài nguyên.
- `src/scenes.js`: khởi tạo lười năm cảnh `ring`, `macro`, `play`, `work`, `alone`.
- `src/engine/tile-engine.js`: renderer gốc đã định dạng; Canvas 2D, GLSL/WebGL2, chuyển động vật thể, kính, foreground, tương tác chuột và chuyển về 2D khi mất WebGL context.
- `src/motion.js`: hiệu ứng xuất hiện theo vị trí/cuộn; logo orbit, spring và chữ hiện lần lượt.
- `src/menus.js`: menu mobile và ngôn ngữ; hỗ trợ chuột, phím mũi tên, Home/End, Escape và focus.
- `src/styles/theme.css`: bảng màu, layout, breakpoint, trạng thái hover và CSS animation của bản tham chiếu, đã định dạng.
- `src/styles/fonts.css`, `assets/`, `design/`: font và hình được lưu local.
- `src/enhancements.css`: nối các trạng thái của runtime JavaScript với CSS.

Mỗi hình chuyển động có ba canvas: ảnh 2D, ảnh WebGL và các vật thể phía trước. **Không thay chúng bằng `<img>` hoặc ảnh chụp** nếu muốn giữ animation.

## Các chế độ animation

- `/en/`: tự chọn 2D/WebGL theo khả năng thiết bị và phép đo hiệu năng, giống trang tham chiếu.
- `/en/?stage=2d`: dùng Canvas 2D; vẫn có animation.
- `/en/?stage=3d`: yêu cầu WebGL2; nếu WebGL không khả dụng vẫn có 2D.

Cảnh chỉ vẽ khi nằm trong vùng nhìn thấy, tạm dừng khi tab ẩn, cập nhật kích thước khi resize. Chuyển động liên tục tôn trọng **prefers-reduced-motion** của hệ điều hành. Hình hero còn có hiệu ứng zoom/drift bằng CSS.

## Phạm vi và nguồn

Đây là bản dựng lại **trang chủ tiếng Anh tại URL đã gửi**. Các liên kết Install, Compare, Blog, Docs, trang pháp lý và tiếng Đức mở trang đích thực trên website gốc. Nội dung bài viết ở trang chủ là snapshot tại lúc thu thập, không nối CMS. Tài nguyên hiển thị và animation đều ở local; không cần website gốc để vẽ trang và không tải script analytics.

Để hình ảnh và chuyển động khớp, bản này sử dụng tài nguyên hình/font/CSS và renderer được website công khai phân phối, rồi viết lại phần UI runtime thành các module ở trên. **Đây không phải source React/TypeScript nguyên bản từ repository của tác giả.** Tên biến bên trong renderer vẫn theo bundle công khai; phần định dạng không đổi AST JavaScript. Xem `reference/PROVENANCE.md` để biết nguồn và bằng chứng.

## Kiểm tra

`npm run check` kiểm tra cú pháp module, import, tài nguyên HTML/CSS và đủ năm scene. Báo cáo trình duyệt thực nằm ở `verification/report.json` sau khi chạy QA.

Kiểm tra trình duyệt tùy chọn cần Playwright đã cài và Chromium. Có thể chỉ đường dẫn module bằng `PLAYWRIGHT_MODULE` và trình duyệt bằng `CHROMIUM_PATH`, rồi chạy `node scripts/qa.mjs`. Script chạy server tạm, so sánh với trang gốc ở nhiều kích thước, kiểm tra canvas thay đổi theo thời gian, menu bàn phím, reduced motion, WebGL và mất context; tự đóng server sau khi xong.
