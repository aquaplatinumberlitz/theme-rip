# Reference and reconstruction record

Reference URL: https://punktfunk.unom.io/en/

Captured for this task on 2026-10-26. The page structure, display copy, SVGs, CSS, hero artwork, font and procedural renderer originate from the publicly delivered website. Original branding and assets retain their original ownership; no new license is asserted for them.

The authored reconstruction comprises the static HTML organization, vanilla UI runtime in `src/app.js`, `src/scenes.js`, `src/motion.js`, `src/menus.js`, integration CSS and build/preview/verification scripts.

## Retained evidence

- `ev_fcdf0389dfce09b5b07078f194a358b4ba34396d2646fdfdb638522a4e20d8cc`: controlled Chromium page load with normal motion and captured first-party resource responses.
- `ev_7fdefb1ff41228d54a550b386f136acc0c3bc8ce30a12cdede193a787a3f2d3b`: controlled page load, rendered DOM and canvas structure; reduced motion enabled.
- `ev_0dcb9cce6c2293320704e55f26069428cf4910591d588b22bd27e20ba9edcfa1`: main runtime bundle used to establish scene startup parameters, logo trajectory and UI behavior. This bundle is not required by the reconstruction.
- `ev_6988a8db61f739403519dcd6c5222a7f6f6f0fe5ed983d5511ff0d0878edae68`: desktop reference at 1440 × 1000, normal motion, forced 2D renderer.

`resources.json` retains the selected original response bytes, media types and SHA-256 digests. `rendered.html` is the observed DOM and `server.html` is the original HTML response. `desktop.png` is the observed desktop reference screenshot.

The additional WebP/JXL hero variants were fetched from their declared first-party URLs. Their byte lengths and SHA-256 digests are retained in `fallback-assets.json`; controlled process Evidence: `ev_1d959ffceb69a8e20144aca58d7b7c68853bdf76bc0215ce87c282a5c9a31e64`.

Renderer URL: https://punktfunk.unom.io/assets/tile-engine-BJBoz00s.js

Original renderer SHA-256: `0fe32ebd0a35c4cf42ee63c235c661db1e51e4ba211dd7ba9037436760e3d79a`.

The runtime renderer at `src/engine/tile-engine.js` is a whitespace-formatted copy with a provenance comment. The syntax trees before and after formatting were compared with @babel/parser and found identical after removing source locations and raw-literal metadata. This establishes syntax preservation, not recovery of the author's original unbundled names or files.

## Known differences and boundaries

- The original React, Motion and Radix runtime is replaced by browser APIs. Animation parameters and trajectories were recovered from shipped code; exact frame scheduling can vary by browser and frame rate.
- The source renders the English homepage. Other original-site routes are real external links, not locally implemented pages.
- The original CMS, admin UI, analytics and live blog updates are not part of this reconstruction.
- Only the Latin font subset needed by this page is included.
- Pixel output of moving scenes depends on elapsed time, pointer position, canvas scale, WebGL driver and GPU performance. Still screenshots are compared with reduced motion and the same 2D renderer.
- The page's functional menu behavior is reconstructed; the internal React/Radix component tree is not reproduced.
