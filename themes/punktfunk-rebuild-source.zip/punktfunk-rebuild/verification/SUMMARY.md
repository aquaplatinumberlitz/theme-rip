# Browser verification

Validated in Chromium 153.0.8010.52 on 2026-10-26.

- Viewports: 1440 × 1000, 1024 × 768, 390 × 844, 320 × 740.
- Twelve representative layout boxes match reference coordinates and dimensions within 0.5 CSS pixels at all four widths; reveal translations are excluded from layout coordinates.
- No horizontal overflow.
- All five scenes initialize with nonempty canvases at every viewport.
- In normal-motion mode, all five scenes produce different canvas byte hashes at samples 280ms apart.
- Mobile menu: seven live destination links, arrow-key selection, Escape and focus restoration pass.
- Language menu exposes the English selected state and real German destination.
- Changing prefers-reduced-motion at runtime settles the canvas.
- Forced WebGL2 starts successfully. Losing its context switches to the 2D renderer.
- No page errors or failed local resource responses.
- Display-resource requests outside the local server were blocked during layout verification; the page still loads correctly.

Results: `report.json`. Reference/local screenshots and WebGL/menu screenshots are retained in this directory in the workspace.

Successful controlled process Evidence: `ev_e7d46885c1b99518f74c5ad48387a62714f46407b6498e61ddb66cacc05ee33b`.

The final `dist/` build was also served and smoke-tested: homepage/routes/modules return 200, the normal picture source selects the 2000 × 2000 AVIF, and a simulated fallback selects the 2000 × 2000 WebP. No page errors. Results: `build-smoke.json`; Evidence: `ev_561df5ac6cfe2aab4dfd3b409d3664ee73bf9c96c412adbf852d69c68af9fe06`.

Screenshots freeze the hero CSS animation at the same timestamp and use reduced motion plus `stage=2d` for both original and local pages. Moving scenes at normal speed vary with time and renderer. This is a homepage fidelity check, not a claim of identical output on every browser/GPU or a reconstruction of the original site's backend.
