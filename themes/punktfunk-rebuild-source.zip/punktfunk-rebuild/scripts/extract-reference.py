"""Materialize the retained first-party resources and prepare editable homepage HTML."""
import base64
import json
import re
from pathlib import Path
from urllib.parse import urlparse
from bs4 import BeautifulSoup, Comment

ROOT = Path(__file__).resolve().parents[1]
reference = json.loads((ROOT / 'reference/resources.json').read_text())
for resource in reference['resources']:
    path = urlparse(resource['url']).path
    destination = ROOT / ('reference/server.html' if path == '/en/' else path.lstrip('/'))
    destination.parent.mkdir(parents=True, exist_ok=True)
    destination.write_bytes(base64.b64decode(resource['content']))

soup = BeautifulSoup((ROOT / 'reference/rendered.html').read_text(), 'html.parser')
for node in soup.find_all(string=lambda value: isinstance(value, Comment)):
    node.extract()
for node in soup.find_all('script'):
    node.decompose()
for node in soup.select('link[rel=modulepreload], link[rel=canonical], link[rel=alternate]'):
    node.decompose()
for node in soup.select('[data-reveal]'):
    node.attrs.pop('style', None)
for node in soup.select('[data-status]'):
    node.attrs.pop('data-status', None)
for node in soup.select('[id^=radix-]'):
    del node['id']
for node in soup.select('canvas'):
    node.attrs.pop('width', None)
    node.attrs.pop('height', None)
for node in soup.select('a[href]'):
    href = node['href']
    if href in ('/en/', '/en'):
        node['href'] = '/en/'
    elif href.startswith('/'):
        node['href'] = reference['origin'] + href
scenes = [('devices-art','ring'), ('latency-art','macro'), ('gaming-card','play'), ('desktop-card','work'), ('linux-art','alone')]
for parent, name in scenes:
    soup.select_one(f'.{parent} .tile-scene')['data-scene'] = name
for node in soup.select('link[rel=stylesheet]'):
    node.attrs.pop('data-precedence', None)
extra = soup.new_tag('link', rel='stylesheet', href='/src/enhancements.css')
soup.head.append(extra)
boot = soup.new_tag('script')
boot.string = "document.documentElement.classList.add('js');"
soup.head.append(boot)
script = soup.new_tag('script', type='module', src='/src/app.js')
soup.head.append(script)
soup.body.append(soup.new_tag('noscript'))
soup.body.noscript.string = 'Enable JavaScript to play the interactive illustrations.'
# HTML parsers lowercase SVG names; restore the SVG namespace spelling on serialization.
output = soup.prettify(formatter='minimal')
for old, new in {'viewbox':'viewBox', 'lineargradient':'linearGradient', 'gradientunits':'gradientUnits', 'clippath':'clipPath', 'clippathunits':'clipPathUnits', 'preserveaspectratio':'preserveAspectRatio'}.items():
    output = re.sub(r'(?<![\w-])' + old + r'(?![\w-])', new, output)
(ROOT / 'index.html').write_text(output)
print(f'Prepared {len(reference["resources"])} resources and the homepage with {len(scenes)} animated scenes.')
