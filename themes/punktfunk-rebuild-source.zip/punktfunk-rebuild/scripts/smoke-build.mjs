import assert from 'node:assert/strict';
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import { server } from './serve.mjs';

const { chromium } = await import(pathToFileURL(process.env.PLAYWRIGHT_MODULE).href);
const browser = await chromium.launch({ executablePath: '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
const base = `http://127.0.0.1:${server.address().port}`;
const results = { routes: {}, errors: [], images: [] };
try {
  for (const path of ['/', '/en/', '/src/app.js', '/src/engine/tile-engine.js', '/design/lens.avif', '/design/lens.webp', '/design/lens.jxl']) {
    const response = await fetch(base + path);
    results.routes[path] = response.status;
    assert.equal(response.status, 200);
  }
  for (const fallback of [false, true]) {
    const page = await browser.newPage({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'no-preference' });
    page.on('pageerror', (error) => results.errors.push(error.message));
    if (fallback) {
      // Simulate a browser without AVIF/JXL picture-source support.
      await page.route('**/en/*', async (route) => {
        const response = await route.fetch();
        const html = (await response.text()).replace(/<source[^>]+>/g, '');
        await route.fulfill({ response, body: html });
      });
    }
    await page.goto(`${base}/en/?stage=2d`, { waitUntil: 'networkidle' });
    await page.waitForFunction(() => document.documentElement.dataset.ready === 'true' && document.querySelector('[data-scene="ring"]')?.dataset.initialized === 'true');
    const image = await page.locator('.hero-art img').evaluate((el) => ({ source: el.currentSrc, width: el.naturalWidth, height: el.naturalHeight }));
    assert(image.width > 0 && image.height > 0);
    assert(image.source.endsWith(fallback ? 'lens.webp' : 'lens.avif'));
    results.images.push({ fallback, ...image });
    await page.close();
  }
  assert.equal(results.errors.length, 0);
  results.status = 'passed';
} finally {
  await browser.close();
  await new Promise((done) => server.close(done));
  await mkdir(resolve(import.meta.dirname, '../verification'), { recursive: true });
  await writeFile(resolve(import.meta.dirname, '../verification/build-smoke.json'), JSON.stringify(results, null, 2));
  console.log(JSON.stringify(results));
}
