import { cp, mkdir, rm } from 'node:fs/promises';
import { resolve } from 'node:path';

const root = resolve(import.meta.dirname, '..');
const dist = resolve(root, 'dist');
await rm(dist, { recursive: true, force: true });
await mkdir(dist, { recursive: true });
for (const path of ['index.html', 'src', 'assets', 'design', 'favicon.svg']) {
  await cp(resolve(root, path), resolve(dist, path), { recursive: true });
}
await mkdir(resolve(dist, 'en'), { recursive: true });
await cp(resolve(root, 'index.html'), resolve(dist, 'en/index.html'));
console.log('Built standalone static files in dist/.');
