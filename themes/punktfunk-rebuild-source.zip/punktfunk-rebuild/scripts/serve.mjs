import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';

const root = resolve(import.meta.dirname, '..', process.argv.includes('--dist') ? 'dist' : '.');
const portFlag = process.argv.indexOf('--port');
const port = Number(portFlag >= 0 ? process.argv[portFlag + 1] : process.env.PORT || 4173);
const types = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml', '.avif': 'image/avif', '.jxl': 'image/jxl', '.png': 'image/png',
  '.webp': 'image/webp', '.woff2': 'font/woff2',
};

export const server = createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    const pathname = decodeURIComponent(url.pathname);
    // Only the supplied English homepage is rebuilt; other navigation uses
    // explicit original-site URLs in index.html rather than fake local routes.
    const home = ['/', '/en', '/en/', '/index.html'].includes(pathname);
    const filename = resolve(root, home ? 'index.html' : `.${pathname}`);
    if (!filename.startsWith(root + sep)) {
      response.writeHead(403).end('Forbidden');
      return;
    }
    const file = await stat(filename);
    if (!file.isFile()) throw Object.assign(new Error('Not a file'), { code: 'ENOENT' });
    const bytes = await readFile(filename);
    response.writeHead(200, {
      'Content-Type': types[extname(filename)] || 'application/octet-stream',
      'Content-Length': bytes.length,
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
    });
    response.end(request.method === 'HEAD' ? undefined : bytes);
  } catch (error) {
    const code = error.code === 'ENOENT' || error.code === 'ENOTDIR' ? 404 : 500;
    response.writeHead(code, { 'Content-Type': 'text/plain; charset=utf-8' });
    response.end(code === 404 ? 'Not found' : 'Unable to read file');
  }
});

server.listen(port, '0.0.0.0', () => console.log(`Punktfunk local preview: http://localhost:${port}/en/`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
