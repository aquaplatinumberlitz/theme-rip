// One-time whitespace-only formatting of the retained reference renderer/CSS.
// @babel/parser is supplied via BABEL_PARSER for this development operation.
const fs = require('node:fs');
const path = require('node:path');
const parser = require(process.env.BABEL_PARSER);
const root = path.resolve(__dirname, '..');
const input = fs.readFileSync(path.join(root, 'assets/tile-engine-BJBoz00s.js'), 'utf8');
const ast = parser.parse(input, { sourceType: 'module' });
const breaks = new Map();
const mark = (position, indent) => breaks.set(position, Math.max(breaks.get(position) ?? 0, indent));
function visit(node, depth = 0) {
  if (!node || typeof node !== 'object' || typeof node.type !== 'string') return;
  if (node.type === 'BlockStatement' || node.type === 'ClassBody') {
    mark(node.start + 1, depth + 1);
    mark(node.end - 1, depth);
    depth++;
  }
  if (/Statement$|Declaration$/.test(node.type) && !['BlockStatement','EmptyStatement'].includes(node.type)) {
    mark(node.start, depth);
    mark(node.end, depth);
  }
  for (const [key, child] of Object.entries(node)) {
    if (['loc','start','end','extra','comments','tokens'].includes(key)) continue;
    if (Array.isArray(child)) child.forEach((entry) => visit(entry, depth));
    else visit(child, depth);
  }
}
visit(ast.program);
let formatted = '';
for (let index = 0; index < input.length; index++) {
  if (breaks.has(index)) formatted += '\n' + '  '.repeat(breaks.get(index));
  formatted += input[index];
}
// Parsing both versions must yield the same syntax tree; formatting changes no code.
function syntax(node) {
  return JSON.stringify(node, (key, value) => ['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments'].includes(key) ? undefined : value);
}
if (syntax(ast.program) !== syntax(parser.parse(formatted, { sourceType: 'module' }).program)) throw new Error('Renderer syntax changed');
fs.mkdirSync(path.join(root, 'src/engine'), { recursive: true });
fs.writeFileSync(path.join(root, 'src/engine/tile-engine.js'), '// Retained Punktfunk procedural renderer; whitespace formatted only.\n// Original: /assets/tile-engine-BJBoz00s.js. See reference/PROVENANCE.md.\n' + formatted.trim() + '\n');

function formatCSS(text) {
  let out = '', depth = 0, parentheses = 0, quote = '', comment = false;
  const newline = () => { out = out.trimEnd() + '\n' + '  '.repeat(depth); };
  for (let i = 0; i < text.length; i++) {
    const c = text[i], next = text[i + 1];
    if (comment) { out += c; if (c === '*' && next === '/') { out += next; i++; comment = false; } continue; }
    if (quote) { out += c; if (c === '\\') out += text[++i]; else if (c === quote) quote = ''; continue; }
    if (c === '/' && next === '*') { out += c + next; i++; comment = true; continue; }
    if (c === '"' || c === "'") { quote = c; out += c; continue; }
    if (c === '(') parentheses++;
    if (c === ')') parentheses--;
    if (!parentheses && c === '{') { out += ' {'; depth++; newline(); }
    else if (!parentheses && c === '}') { depth--; newline(); out += '}'; newline(); }
    else if (!parentheses && c === ';') { out += ';'; newline(); }
    else out += c;
  }
  return out.trim() + '\n';
}
fs.mkdirSync(path.join(root, 'src/styles'), { recursive: true });
fs.writeFileSync(path.join(root, 'src/styles/theme.css'), formatCSS(fs.readFileSync(path.join(root, 'assets/globals-B-6EEMbP.css'), 'utf8')));
fs.writeFileSync(path.join(root, 'src/styles/fonts.css'), formatCSS(fs.readFileSync(path.join(root, 'assets/index-CWlGCPL-.css'), 'utf8')));
let html = fs.readFileSync(path.join(root, 'index.html'), 'utf8');
html = html.replace('/assets/globals-B-6EEMbP.css', '/src/styles/theme.css').replace('/assets/index-CWlGCPL-.css', '/src/styles/fonts.css');
fs.writeFileSync(path.join(root, 'index.html'), html);
console.log('Formatted renderer with identical AST and prepared readable stylesheets.');
