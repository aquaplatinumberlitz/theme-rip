import { readFile, readdir, stat } from 'node:fs/promises';
import { spawnSync } from 'node:child_process';
import { resolve, dirname } from 'node:path';
import assert from 'node:assert/strict';

const root = resolve(import.meta.dirname, '..');
const html = await readFile(resolve(root, 'index.html'), 'utf8');
const assets = [...html.matchAll(/(?:src|srcset|href)="(\/[^"#?]+)"/g)].map((match) => match[1]);
for (const asset of assets) {
  if (['/en/', '/en'].includes(asset)) continue;
  assert((await stat(resolve(root, `.${asset}`))).isFile(), `Missing asset ${asset}`);
}
async function checkDirectory(directory) {
  for (const entry of await readdir(directory, { withFileTypes: true })) {
    const path = resolve(directory, entry.name);
    if (entry.isDirectory()) await checkDirectory(path);
    else if (/\.(?:js|mjs|cjs)$/.test(entry.name)) {
      const result = spawnSync(process.execPath, ['--check', path], { encoding: 'utf8' });
      assert.equal(result.status, 0, result.stderr);
      const source = await readFile(path, 'utf8');
      for (const match of source.matchAll(/(?:from\s*|import\s*\()\s*['"](\.[^'"]+)['"]/g)) {
        assert((await stat(resolve(dirname(path), match[1]))).isFile(), `Missing import ${match[1]}`);
      }
    }
  }
}
await checkDirectory(resolve(root, 'src'));
await checkDirectory(resolve(root, 'scripts'));
for (const file of ['theme.css', 'fonts.css']) {
  const css = await readFile(resolve(root, 'src/styles', file), 'utf8');
  for (const match of css.matchAll(/url\(["']?(\/[^)"']+)["']?\)/g)) {
    assert((await stat(resolve(root, `.${match[1]}`))).isFile(), `Missing CSS asset ${match[1]}`);
  }
}
assert.equal((html.match(/data-scene="/g) || []).length, 5);
assert(!html.includes('analytics.unom.io'), 'The local page should not load analytics');
console.log('Passed: module syntax, local imports, HTML/CSS assets, five scenes, no analytics.');
