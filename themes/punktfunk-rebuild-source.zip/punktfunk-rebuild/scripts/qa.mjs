/** Optional real-browser verification. Supply an installed Playwright module. */
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { pathToFileURL } from 'node:url';
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { server } from './serve.mjs';

const root = resolve(import.meta.dirname, '..');
const artifacts = resolve(root, 'verification');
await mkdir(artifacts, { recursive: true });
const modulePath = process.env.PLAYWRIGHT_MODULE;
const { chromium } = await import(modulePath ? pathToFileURL(modulePath).href : 'playwright');
const browser = await chromium.launch({
  executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium',
  headless: true,
  args: ['--no-sandbox', '--enable-unsafe-swiftshader'],
});
const base = `http://127.0.0.1:${server.address().port}`;
const report = { comparisons: [], animations: [], browser: browser.version(), consoleErrors: [], failedResources: [] };
const metrics = () => {
  const selectors = ['.site-header', '.brand-capsule', '.hero-art', '.hero-copy', '.devices-art', '.latency-art', '.gaming-card', '.desktop-card', '.linux-art', '.privacy-panel', '.install-card', '.site-footer'];
  return Object.fromEntries(selectors.map((selector) => {
    const element = document.querySelector(selector);
    const rect = element.getBoundingClientRect();
    const style = getComputedStyle(element);
    // Compare layout coordinates independently of an in-progress reveal's 28px
    // translation. Screenshots retain the real animation state for visual review.
    const transform = style.transform === 'none' ? new DOMMatrixReadOnly() : new DOMMatrixReadOnly(style.transform);
    return [selector, { x: rect.x - transform.m41, y: rect.y + scrollY - transform.m42, width: rect.width, height: rect.height, background: style.backgroundColor }];
  }));
};

async function settle(page) {
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(1800);
}
async function freezeHero(page) {
  await page.locator('.hero-art img').evaluate((image) => {
    for (const animation of image.getAnimations()) {
      animation.pause();
      animation.currentTime = 2000;
    }
  });
}
async function revealAll(page) {
  await page.evaluate(async () => {
    const wait = (ms) => new Promise((done) => setTimeout(done, ms));
    for (const panel of document.querySelectorAll('[data-reveal]')) {
      panel.scrollIntoView({ block: 'center', behavior: 'instant' });
      await wait(140);
    }
    await wait(1000);
    scrollTo({ top: 0, behavior: 'instant' });
  });
  await page.waitForTimeout(400);
}

try {
  for (const viewport of [{ width: 1440, height: 1000 }, { width: 1024, height: 768 }, { width: 390, height: 844 }, { width: 320, height: 740 }]) {
    const context = await browser.newContext({ viewport, reducedMotion: 'reduce' });
    const original = await context.newPage();
    const local = await context.newPage();
    local.on('pageerror', (error) => report.consoleErrors.push(error.message));
    local.on('response', (response) => { if (response.status() >= 400) report.failedResources.push({ url: response.url(), status: response.status() }); });
    // Every displayed resource must work without contacting the original server.
    await local.route('**/*', (route) => route.request().url().startsWith(base) ? route.continue() : route.abort());
    await original.goto('https://punktfunk.unom.io/en/?stage=2d', { waitUntil: 'networkidle' });
    await local.goto(`${base}/en/?stage=2d`, { waitUntil: 'networkidle' });
    await Promise.all([settle(original), settle(local)]);
    await Promise.all([revealAll(original), revealAll(local)]);
    await Promise.all([freezeHero(original), freezeHero(local)]);
    const originalMetrics = await original.evaluate(metrics);
    const localMetrics = await local.evaluate(metrics);
    const differences = [];
    for (const selector of Object.keys(originalMetrics)) {
      for (const property of ['x', 'y', 'width', 'height']) {
        const delta = Math.abs(originalMetrics[selector][property] - localMetrics[selector][property]);
        if (delta > 0.5) differences.push({ selector, property, delta, original: originalMetrics[selector][property], local: localMetrics[selector][property] });
      }
    }
    const overflow = await local.evaluate(() => document.documentElement.scrollWidth > innerWidth);
    const name = `${viewport.width}`;
    await original.screenshot({ path: resolve(artifacts, `original-${name}.png`) });
    await local.screenshot({ path: resolve(artifacts, `local-${name}.png`) });
    if (viewport.width === 1440 || viewport.width === 390) {
      await original.screenshot({ path: resolve(artifacts, `original-${name}-full.png`), fullPage: true });
      await local.screenshot({ path: resolve(artifacts, `local-${name}-full.png`), fullPage: true });
    }
    const scenes = await local.locator('[data-scene]').evaluateAll((elements) => elements.map((el) => ({ scene: el.dataset.scene, ready: el.dataset.initialized, width: el.querySelector('canvas').width, height: el.querySelector('canvas').height })));
    report.comparisons.push({ viewport, differences, overflow, scenes, originalMetrics, localMetrics });
    assert.equal(differences.length, 0, `Layout differs from the reference at ${viewport.width}px`);
    assert(!overflow, `Horizontal overflow at ${viewport.width}px`);
    assert(scenes.every((scene) => scene.ready === 'true' && scene.width > 0 && scene.height > 0), 'Uninitialized canvas');

    if (viewport.width === 390) {
      await local.locator('.mobile-menu-trigger').click();
      await local.locator('#mobile-navigation').waitFor({ state: 'visible' });
      assert.equal(await local.locator('#mobile-navigation a').count(), 7);
      await local.screenshot({ path: resolve(artifacts, 'mobile-menu.png') });
      await local.keyboard.press('ArrowDown');
      assert.equal(await local.evaluate(() => document.activeElement.textContent), 'Compare');
      await local.keyboard.press('Escape');
      assert.equal(await local.locator('.mobile-menu-trigger').getAttribute('aria-expanded'), 'false');
      assert(await local.locator('.mobile-menu-trigger').evaluate((el) => el === document.activeElement));
      await local.locator('.locale-trigger').click();
      assert.equal(await local.locator('#language-navigation [aria-checked="true"]').textContent(), 'English');
      await local.screenshot({ path: resolve(artifacts, 'language-menu.png') });
      await local.keyboard.press('Escape');
      report.menuKeyboard = 'passed';
    }
    await context.close();
  }

  const context = await browser.newContext({ viewport: { width: 1440, height: 1000 }, reducedMotion: 'no-preference' });
  const page = await context.newPage();
  page.on('pageerror', (error) => report.consoleErrors.push(error.message));
  await page.goto(`${base}/en/?stage=2d`, { waitUntil: 'networkidle' });
  await settle(page);
  await page.screenshot({ path: resolve(artifacts, 'animated-desktop.png') });
  for (const scene of ['ring', 'macro', 'play', 'work', 'alone']) {
    const locator = page.locator(`[data-scene="${scene}"]`);
    await locator.scrollIntoViewIfNeeded();
    await page.waitForTimeout(1000);
    const sample = async () => locator.evaluate((el) => [...el.querySelectorAll('canvas')].filter((canvas) => !canvas.classList.contains('tile-scene-gpu')).map((canvas) => canvas.toDataURL()).join('|'));
    const a = createHash('sha256').update(await sample()).digest('hex');
    await page.waitForTimeout(280);
    const b = createHash('sha256').update(await sample()).digest('hex');
    const changed = a !== b;
    report.animations.push({ scene, changed, before: a, after: b });
    assert(changed, `${scene} stayed static`);
  }
  // The pointer should affect the scene even while time advances normally.
  await page.locator('[data-scene="ring"]').scrollIntoViewIfNeeded();
  await page.mouse.move(800, 500);
  await page.waitForTimeout(350);
  await page.screenshot({ path: resolve(artifacts, 'pointer-scene.png') });
  await page.emulateMedia({ reducedMotion: 'reduce' });
  await page.waitForTimeout(400);
  const stillSample = () => page.locator('[data-scene="ring"] canvas').first().evaluate((canvas) => canvas.toDataURL());
  const stillA = await stillSample();
  await page.waitForTimeout(300);
  report.reducedMotion = stillA === await stillSample();
  assert(report.reducedMotion, 'Reduced motion did not settle');

  await page.emulateMedia({ reducedMotion: 'no-preference' });
  await page.goto(`${base}/en/?stage=3d`, { waitUntil: 'networkidle' });
  const gpu = page.locator('[data-scene="ring"] .tile-scene-gpu');
  await page.locator('[data-scene="ring"]').scrollIntoViewIfNeeded();
  await gpu.waitFor({ state: 'attached' });
  await page.waitForFunction(() => document.querySelector('[data-scene="ring"]')?.dataset.renderer === '3d', { timeout: 15000 });
  await page.screenshot({ path: resolve(artifacts, 'webgl-renderer.png') });
  report.webgl = await gpu.evaluate((canvas) => ({ active: canvas.classList.contains('is-on'), width: canvas.width, height: canvas.height }));
  await gpu.evaluate((canvas) => canvas.getContext('webgl2').getExtension('WEBGL_lose_context').loseContext());
  await page.waitForFunction(() => document.querySelector('[data-scene="ring"]')?.dataset.renderer === '2d');
  report.webglContextLoss = 'fell back to 2d';
  await context.close();
  assert.equal(report.consoleErrors.length, 0, 'JavaScript errors');
  assert.equal(report.failedResources.length, 0, 'Failed local resources');
  report.status = 'passed';
} catch (error) {
  report.status = 'failed';
  report.error = error.stack;
  process.exitCode = 1;
} finally {
  await writeFile(resolve(artifacts, 'report.json'), JSON.stringify(report, null, 2));
  console.log(JSON.stringify({ status: report.status, comparisons: report.comparisons.map(({ viewport, differences, overflow }) => ({ viewport, differences, overflow })), animations: report.animations, menuKeyboard: report.menuKeyboard, reducedMotion: report.reducedMotion, webgl: report.webgl, webglContextLoss: report.webglContextLoss, errors: report.consoleErrors, resources: report.failedResources, error: report.error }, null, 2));
  await browser.close();
  await new Promise((done) => server.close(done));
}
