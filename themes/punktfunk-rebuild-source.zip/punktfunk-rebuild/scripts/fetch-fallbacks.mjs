// One-time asset acquisition; not needed to run the local page.
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';

const root = resolve(import.meta.dirname, '..');
const records = [];
for (const filename of ['lens.webp', 'lens.jxl']) {
  const url = `https://punktfunk.unom.io/design/${filename}`;
  const response = await fetch(url);
  if (!response.ok) throw new Error(`${url}: ${response.status}`);
  const bytes = Buffer.from(await response.arrayBuffer());
  await mkdir(resolve(root, 'design'), { recursive: true });
  await writeFile(resolve(root, 'design', filename), bytes);
  records.push({ url, bytes: bytes.length, sha256: createHash('sha256').update(bytes).digest('hex') });
}
await writeFile(resolve(root, 'reference/fallback-assets.json'), JSON.stringify(records, null, 2));
console.log(JSON.stringify(records));
