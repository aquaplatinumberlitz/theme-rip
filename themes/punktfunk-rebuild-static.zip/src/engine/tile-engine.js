// Retained Punktfunk procedural renderer; whitespace formatted only.
// Original: /assets/tile-engine-BJBoz00s.js. See reference/PROVENANCE.md.
var e={page:`#21186e`,host:`#a79ff8`,rim:`#ede8ff`,glow:`#5a48f0`,mesh:`#664bfe`};
function t(e){
  let t=/^#([0-9a-f]{6})$/i.exec(e.trim());
  if(!t)
  return[0,0,0];
  let n=Number.parseInt(t[1],16);
  return[(n>>16&255)/255,(n>>8&255)/255,(n&255)/255]
  }
var n={ior:1.07,refl:.06,rough:.24,disp:.01,tint:0,glow:1.25,fres:1.3,light:1.25},r=.36,i=.24,a=.09,o=.66,s=78*Math.PI/180,c=.63,l=-.3,u=[{h:[-.1,-.12,-3],c:[.33,.26,.42],under:0,ring:0,fleet:0,prop:0},{h:[0,-.05,-3],c:[0,.2,-.8],under:0,ring:1,fleet:0,prop:0},{h:[-.15,-.15,-2.7],c:[.22,.16,.66],under:0,ring:0,fleet:0,prop:0},{h:[-.05,0,-3.2],c:[.52,.34,-.5],under:0,ring:0,fleet:1,prop:0},{h:[.05,.1,-3],c:[-.4,-.36,.4],under:0,ring:0,fleet:0,prop:0},{h:[0,-.05,-3],c:[.05,.12,-.75],under:1,ring:0,fleet:0,prop:0},{h:[-.1,-.12,-3],c:[.33,.26,.42],under:0,ring:0,fleet:0,prop:0}],d=[{h:[-.2,.1,-3],c:[.52,-.32,.25],under:0,ring:0,fleet:0,prop:1},{h:[-.35,.3,-3.4],c:[.6,-.5,1.4],under:0,ring:0,fleet:0,prop:1},{h:[.2,.08,-3],c:[-.62,-.22,-.05],under:0,ring:0,fleet:0,prop:1},{h:[0,-.02,-2.75],c:[-.55,-.42,-.4],under:0,ring:0,fleet:0,prop:1},{...u[0]}],f=[{h:[-.15,.14,-3],c:[.55,-.3,.2],under:0,ring:0,fleet:1,prop:1},{h:[-.3,.35,-3.3],c:[.55,-.35,1.2],under:0,ring:0,fleet:1,prop:1},{...u[2]},{h:[.05,-.02,-2.6],c:[-.62,-.42,-.45],under:.7,ring:0,fleet:0,prop:0},{...u[1]},{...u[0]}];
function p(e){
  let t=Math.min(1,Math.max(0,e));
  return t*t*t*(t*(t*6-15)+10)
  }
function m(e,t=o){
  return[Math.cos(e)*t,-Math.sin(e)*t*Math.cos(s),Math.sin(e)*t*Math.sin(s)]
  }
var h=[[.9,.8,.75,.1],[2,1.15,1.3,-.14],[2.9,.95,.9,.18],[4.1,1.1,1.15,-.06],[5.3,.7,.6,.12]];
function g(e,t){
  let n=t[0]*.14,r=-t[1]*.1,i=e[0]*Math.cos(n)+e[2]*Math.sin(n),a=-e[0]*Math.sin(n)+e[2]*Math.cos(n);
  return[i,e[1]*Math.cos(r)-a*Math.sin(r),e[1]*Math.sin(r)+a*Math.cos(r)]
  }
function _(e,t,n){
  let r=m(t+l),i=p(e.ring),s=[e.c[0]+(r[0]-e.c[0])*i,e.c[1]+(r[1]-e.c[1])*i,e.c[2]+(r[2]-e.c[2])*i];
  s=g(s,n);
  let u=Math.hypot(s[0],s[1],s[2]);
  u<1e-4?s=[0,0,-.63]:u<c&&(s=[s[0]*c/u,s[1]*c/u,s[2]*c/u]);
  let d=[e.h[0]+n[0]*.03,e.h[1]+n[1]*.03,e.h[2]],f=a*p(e.ring/.6),_=1+2.5*(1-e.ring),v=[];
  for(
  let[e,r,i,a]
  of h){
    let s=m(t+l+e,r*o*_),c=g([s[0],s[1]+a,s[2]],n);
    v.push([d[0]+c[0],d[1]+c[1],d[2]+c[2],f*i])
    }
  return{h:d,g:[d[0]+s[0],d[1]+s[1],d[2]+s[2]],sats:v,under:e.under}
  }
function v(e,t,n,r){
  let i=Math.min(1,t/n/.9)*(r[2]??1)*n/2,a=3/Math.max(.05,-e[2]);
  return[t/2+(e[0]*a+r[0])*i,n/2-(e[1]*a+r[1])*i,a*i]
  }
var y=class{
  x;v=0;constructor(e){
    this.x=e
    }step(e,t,n){
    if(n){
      this.x=e,this.v=0;
      return
      }
    let r=8.8;
    this.v+=(r*r*(e-this.x)-1.48*r*this.v)*t,this.x+=this.v*t
    }busy(e){
    return Math.abs(e-this.x)>8e-4||Math.abs(this.v)>.002
    }
},b=`#version 300 es
in vec2 a; void main(){ gl_Position=vec4(a,0.0,1.0); }`,x=`#version 300 es
precision highp float;
out vec4 O;
uniform vec2 uRes; uniform float uAspect; uniform float uPx; uniform float uZoom; uniform vec2 uShift; uniform float uTime;
uniform vec3 uBg, uHostCol, uRimCol, uGlowCol, uMeshCol;
uniform vec4 uHost; uniform vec4 uGlass; uniform vec4 uSat[5];
uniform float uUnder, uIor, uRefl, uRough, uDisp, uTint, uGlow, uFres, uLight;
const float D=3.0;
const vec3 DEEP=vec3(0.424,0.357,0.953);
const vec3 KEY=normalize(vec3(-0.55,0.75,0.6));
float hash(vec2 p){ return fract(sin(dot(p,vec2(127.1,311.7)))*43758.5453); }
vec3 hash3(vec2 p){ return vec3(hash(p),hash(p+19.19),hash(p+37.37))*2.0-1.0; }
float isect(vec3 ro, vec3 rd, vec3 c, float r){
  vec3 oc=ro-c; float b=dot(oc,rd); float h=b*b-dot(oc,oc)+r*r;
  if(h<0.0) return -1.0; h=sqrt(h); float t=-b-h; if(t<1e-4) t=-b+h; return t>1e-4?t:-1.0;
}
// Fades anything additive to nothing before the canvas edge, so the canvas never shows.
float edge(vec2 ps){
  vec2 ext=vec2(uAspect,1.0)/uZoom; float e=min(ext.x-abs(ps.x),ext.y-abs(ps.y));
  return smoothstep(0.0,0.3,e);
}
// The backdrop: a glow around the scene and three soft blobs drifting slowly, a mesh
// gradient the page colour shows through, all gone before the canvas edge.
vec3 bg(vec2 p, vec2 ps){
  float g=max(0.0,1.0-dot(p,p)/0.5); vec3 c=uGlowCol*0.32*g*g;
  float t=uTime*0.06;
  vec2 b1=vec2(-1.0+0.3*sin(t*0.7), 0.7+0.25*cos(t*0.5));
  vec2 b2=vec2(1.2+0.35*cos(t*0.6+1.0), -0.4+0.3*sin(t*0.8+2.0));
  vec2 b3=vec2(0.3+0.4*sin(t*0.4+3.0), -1.2+0.2*cos(t*0.9+1.5));
  c+=uMeshCol*0.24*exp(-dot(p-b1,p-b1)*1.1);
  c+=uMeshCol*0.28*exp(-dot(p-b2,p-b2)*0.9);
  c+=uMeshCol*0.16*exp(-dot(p-b3,p-b3)*1.4);
  return uBg+c*edge(ps);
}
// A soft-edged rectangular light seen from direction d: 1 inside, feathered by soft.
float box(vec3 d, vec3 L, vec3 up, vec2 size, float soft){
  float c=dot(d,L); if(c<=0.02) return 0.0;
  vec3 R=normalize(cross(up,L)); vec3 V=cross(L,R);
  vec2 a=vec2(dot(d,R),dot(d,V))/c;
  vec2 q=abs(a)-size; float sd=length(max(q,0.0))+min(max(q.x,q.y),0.0);
  return 1.0-smoothstep(-soft,soft,sd);
}
// The room the spheres reflect: a backdrop sweep, a big soft key upper left, a tall thin rim
// strip on the right, a faint floor bounce.
vec3 env(vec3 d){
  vec3 c=mix(uBg*0.75,uBg*1.4+vec3(0.05,0.03,0.10),clamp(d.y*0.5+0.5,0.0,1.0));
  c+=vec3(1.0,0.97,1.0)*2.2*box(d,normalize(vec3(-0.6,0.7,0.5)),vec3(0.0,1.0,0.0),vec2(0.55,0.35),0.25);
  c+=vec3(0.75,0.70,1.0)*1.4*box(d,normalize(vec3(0.85,0.25,-0.2)),vec3(0.0,1.0,0.0),vec2(0.06,0.9),0.12);
  c+=vec3(0.45,0.40,0.95)*0.5*box(d,normalize(vec3(0.0,-1.0,0.3)),vec3(0.0,0.0,1.0),vec2(1.2,0.8),0.5);
  return c*uLight;
}
// The host: a glowing body, brighter toward the rim, with a hint of form from the key light.
vec3 shadeHost(vec3 N, vec3 rd){
  float f=pow(1.0-clamp(dot(N,-rd),0.0,1.0),uFres);
  vec3 col=mix(uHostCol*0.88,uRimCol,f);
  col*=mix(0.86,1.06,clamp(dot(N,KEY)*0.5+0.5,0.0,1.0));
  col*=uGlow*(1.0+0.22*uUnder);
  col+=env(reflect(rd,N))*0.06;   // a faint sheen of the room, so both bodies share one light
  return col-max(col-0.85,0.0)*0.45;   // soft knee so the rim rolls off instead of clipping
}
bool hitGlass(vec3 ro, vec3 rd, out float t, out vec3 C){
  t=1e9; bool h=false;
  float tg=isect(ro,rd,uGlass.xyz,uGlass.w); if(tg>0.0){t=tg;C=uGlass.xyz;h=true;}
  for(int i=0;i<5;i++){ if(uSat[i].w<=0.001) continue; float ts=isect(ro,rd,uSat[i].xyz,uSat[i].w); if(ts>0.0&&ts<t){t=ts;C=uSat[i].xyz;h=true;} }
  return h;
}
vec3 trace(vec3 ro, vec3 rd){
  float t=isect(ro,rd,uHost.xyz,uHost.w);
  if(t>0.0) return shadeHost(normalize(ro+rd*t-uHost.xyz),rd);
  return env(rd);
}
// Small beads get fewer frosting samples and one refraction instead of three: at their
// size the difference is below a pixel.
vec3 shadeGlass(vec3 rd, vec3 P, vec3 N, vec3 C, float r, vec2 seed){
  float rp=r*D/max(0.2,-C.z); int K=rp>0.15?8:4; int CH=rp>0.15?3:1;
  float cosi=clamp(dot(-rd,N),0.0,1.0);
  float F=uRefl+(1.0-uRefl)*pow(1.0-cosi,5.0);   // reflectance is its own knob, not tied to the IOR
  vec3 absorb=(vec3(1.0)-DEEP)*uTint*1.6;
  vec3 refl=vec3(0.0); vec3 trans=vec3(0.0);
  for(int k=0;k<8;k++){
    if(k>=K) break;
    vec3 j=hash3(seed+float(k)*17.13)*uRough*0.55;
    vec3 Nj=normalize(N+j);
    refl+=trace(P+N*1e-3,reflect(rd,Nj));
    for(int ch=0;ch<3;ch++){
      if(ch>=CH) break;
      float ior=uIor+(CH==3?uDisp*(float(ch)-1.0):0.0);
      vec3 r1=refract(rd,Nj,1.0/ior); if(dot(r1,r1)<0.5) r1=reflect(rd,Nj);
      float tc=max(0.0,-2.0*dot(r1,P-C)); vec3 P2=P+r1*tc;
      vec3 N2=normalize(normalize(C-P2)+j);
      vec3 r2=refract(r1,N2,ior); if(dot(r2,r2)<0.5) r2=r1;
      vec3 c2=trace(P2+r2*1e-3,r2);
      if(CH==3) trans[ch]+=c2[ch]*exp(-tc*absorb[ch]); else trans+=c2*exp(-tc*absorb);
    }
  }
  trans/=float(K); refl/=float(K);
  return mix(trans,refl,F);
}
vec3 halo(vec2 p, vec2 ps){
  float k=D/max(0.05,-uHost.z); vec2 c=uHost.xy*k; float r=uHost.w*k;
  float d=max(0.0,length(p-c)-r);
  return uHostCol*0.6*exp(-d*4.5/r)*uGlow*(1.0+0.6*uUnder)*edge(ps);
}
vec3 render(vec2 p, vec2 ps, vec2 seed){
  vec3 ro=vec3(0.0); vec3 rd=normalize(vec3(p,-D));
  float th=isect(ro,rd,uHost.xyz,uHost.w);
  float tg; vec3 C; bool hg=hitGlass(ro,rd,tg,C);
  if(hg&&(th<0.0||tg<th)){ vec3 P=ro+rd*tg; float r=(C==uGlass.xyz)?uGlass.w:uSat[0].w; for(int i=0;i<5;i++) if(C==uSat[i].xyz) r=uSat[i].w; return shadeGlass(rd,P,normalize(P-C),C,r,seed); }
  if(th>0.0) return shadeHost(normalize(ro+rd*th-uHost.xyz),rd);
  return bg(p,ps)+halo(p,ps);
}
float sil(vec2 p, vec4 s){ if(s.w<=0.001) return 1e9; float k=D/max(0.05,-s.z); return abs(length(p-s.xy*k)-s.w*k); }
void main(){
  vec2 fc=gl_FragCoord.xy; vec2 uv=(fc/uRes)*2.0-1.0; vec2 ps=vec2(uv.x*uAspect,uv.y)/uZoom; vec2 p=ps-uShift;
  float e=min(sil(p,uHost),sil(p,uGlass));
  for(int i=0;i<5;i++) e=min(e,sil(p,uSat[i]));
  vec3 col;
  if(e<uPx*2.5){
    col = render(p+vec2(-0.375,-0.125)*uPx,ps,fc*0.37)
        + render(p+vec2( 0.125,-0.375)*uPx,ps,fc*0.37+1.0)
        + render(p+vec2( 0.375, 0.125)*uPx,ps,fc*0.37+2.0)
        + render(p+vec2(-0.125, 0.375)*uPx,ps,fc*0.37+3.0);
    col*=0.25;
  } else col=render(p,ps,fc*0.37);
  O=vec4(clamp(col,0.0,1.0),1.0);
}`,S=/swiftshader|llvmpipe|softpipe|basic render|software/i,C=()=>new Promise(e=>requestAnimationFrame(e));
async function w(e,n,a){
  let o=e.getContext(`webgl2`,{antialias:!1,alpha:!1,powerPreference:`low-power`});
  if(!o||o.isContextLost())
  return null;
  let s=o.getExtension(`WEBGL_debug_renderer_info`);
  if(!n&&s&&S.test(String(o.getParameter(s.UNMASKED_RENDERER_WEBGL))))
  return null;
  let c=o.getExtension(`KHR_parallel_shader_compile`),l=o.createShader(o.VERTEX_SHADER),u=o.createShader(o.FRAGMENT_SHADER),d=o.createProgram();
  if(!l||!u||!d)
  return null;
  o.shaderSource(l,b),o.shaderSource(u,x),o.compileShader(l),o.compileShader(u),o.attachShader(d,l),o.attachShader(d,u),o.linkProgram(d);
  do 
  if(await C(),a()||o.isContextLost())
  return null;
  while(c&&!o.getProgramParameter(d,c.COMPLETION_STATUS_KHR));
  if(!o.getProgramParameter(d,o.LINK_STATUS))
  return console.warn(`orbit shader`,o.getShaderInfoLog(u)||o.getProgramInfoLog(d)),null;
  o.useProgram(d),o.bindBuffer(o.ARRAY_BUFFER,o.createBuffer()),o.bufferData(o.ARRAY_BUFFER,new Float32Array([-1,-1,3,-1,-1,3]),o.STATIC_DRAW);
  let f=o.getAttribLocation(d,`a`);
  o.enableVertexAttribArray(f),o.vertexAttribPointer(f,2,o.FLOAT,!1,0,0),o.drawArrays(o.TRIANGLES,0,3);
  let p=o.fenceSync(o.SYNC_GPU_COMMANDS_COMPLETE,0);
  for(o.flush();p&&o.getSyncParameter(p,o.SYNC_STATUS)!==o.SIGNALED;)
  if(await C(),a()||o.isContextLost())
  return null;
  p&&o.deleteSync(p);
  let m=e=>o.getUniformLocation(d,e),h={res:m(`uRes`),aspect:m(`uAspect`),px:m(`uPx`),zoom:m(`uZoom`),shift:m(`uShift`),time:m(`uTime`),bg:m(`uBg`),hostCol:m(`uHostCol`),rimCol:m(`uRimCol`),glowCol:m(`uGlowCol`),meshCol:m(`uMeshCol`),host:m(`uHost`),glass:m(`uGlass`),sats:[0,1,2,3,4].map(e=>m(`uSat[${e}]`)),under:m(`uUnder`),ior:m(`uIor`),refl:m(`uRefl`),rough:m(`uRough`),disp:m(`uDisp`),tint:m(`uTint`),glow:m(`uGlow`),fres:m(`uFres`),light:m(`uLight`)};
  return{draw(n,a,s,c,l,u,d){
    (e.width!==a||e.height!==s)&&(e.width=a,e.height=s);
    let f=Math.min(1,a/s/.9)*(l[2]??1);
    o.viewport(0,0,a,s),o.uniform2f(h.res,a,s),o.uniform1f(h.aspect,a/s),o.uniform1f(h.px,2/s/f),o.uniform1f(h.zoom,f),o.uniform2f(h.shift,l[0],l[1]),o.uniform1f(h.time,u),o.uniform3fv(h.bg,t(d.page)),o.uniform3fv(h.hostCol,t(d.host)),o.uniform3fv(h.rimCol,t(d.rim)),o.uniform3fv(h.glowCol,t(d.glow)),o.uniform3fv(h.meshCol,t(d.mesh)),o.uniform4f(h.host,n.h[0],n.h[1],n.h[2],r),o.uniform4f(h.glass,n.g[0],n.g[1],n.g[2],i);
    for(
    let e=0
    ;e<5;e++){
      let t=n.sats[e];
      o.uniform4f(h.sats[e],t[0],t[1],t[2],t[3])
      }
    o.uniform1f(h.under,n.under),o.uniform1f(h.ior,c.ior),o.uniform1f(h.refl,c.refl),o.uniform1f(h.rough,c.rough),o.uniform1f(h.disp,c.disp),o.uniform1f(h.tint,c.tint),o.uniform1f(h.glow,c.glow),o.uniform1f(h.fres,c.fres),o.uniform1f(h.light,c.light),o.drawArrays(o.TRIANGLES,0,3)
    },sync(){
    o.readPixels(0,0,1,1,o.RGBA,o.UNSIGNED_BYTE,new Uint8Array(4))
    },dispose(){
    setTimeout(()=>{
      e.isConnected||o.getExtension(`WEBGL_lose_context`)?.loseContext()
      },0)
    }}
  }
var T=14,E=(e,t)=>e+Math.random()*(t-e);
function D(e,t,n,r){
  let i=e*Math.cos(r),a=e*Math.sin(r),o=-a*Math.sin(t),s=a*Math.cos(t);
  return[i*Math.cos(n)+s*Math.sin(n),o,-i*Math.sin(n)+s*Math.cos(n)]
  }
function O(){
  let e=[];
  for(
  let t=0
  ;t<4;t++){
    let n=r*E(1.35,2.1),i=E(.35,1.2)*(Math.random()>.5?1:-1),a=E(0,Math.PI*2),o=Math.random()>.5?1:-1,s=E(0,Math.PI*2);
    for(
    let r
     of[0,E(.3,.5)])
    e.push({side:(t+ +!!r)%2,a:n,inc:i,node:a,dir:o,ph:s,lag:r,cool:E(.3,1.2),dead:0,aim:.2,fired:-1,scored:-1,p:[0,0,0],v:[0,0,0],trail:[]})
    }
  let t={t:0,ships:e,bolts:[],bursts:[],tick:0};
  return k(t,0),t
  }
function k(e,t){
  e.t+=t,e.tick+=t;
  let n=e.tick>=1/60;
  n&&(e.tick=0);
  for(
  let[r,i]
  of e.ships.entries()){
    let a=.55/i.a*i.dir,o=i.lag?i.lag+.12*Math.sin(e.t*.7+r):0,s=i.ph+e.t*a-o*i.dir,c=D(i.a,i.inc,i.node,s),l=D(i.a,i.inc,i.node,s+.01*i.dir);
    if(i.v=[(l[0]-c[0])*55,(l[1]-c[1])*55,(l[2]-c[2])*55],i.p=c,i.dead>0){
      i.dead-=t,i.trail.length=0;
      continue
      }
    if(n&&(i.trail.unshift(c),i.trail.length>T&&i.trail.pop()),!i.lag||t===0||(i.cool-=t,i.cool>0))
    continue;
    i.cool=E(.9,2);
    let u=Math.hypot(...i.v),d=[i.v[0]/u*2.4,i.v[1]/u*2.4,i.v[2]/u*2.4];
    e.bolts.push({side:i.side,p:[...c],v:d,life:.7}),i.fired=e.t;
    let f=e.ships[r-1];
    f.dead<=0&&Math.random()<i.aim&&(e.bursts.push({p:[...f.p],side:i.side,life:.9}),f.dead=E(2,3.5),i.scored=e.t)
    }
  for(
  let n
   of e.bolts)
  n.life-=t,n.p=[n.p[0]+n.v[0]*t,n.p[1]+n.v[1]*t,n.p[2]+n.v[2]*t];
  e.bolts=e.bolts.filter(e=>e.life>0);
  for(
  let n
   of e.bursts)
  n.life-=t;
  e.bursts=e.bursts.filter(e=>e.life>0)
  }
function A(e,t,n,r,i,a,o){
  let s=1+2.5*(1-n)**2,c=g([e[0]*s,e[1]*s,e[2]*s],r),l=[t[0]+c[0],t[1]+c[1],t[2]+c[2]],[u,d,f]=v(l,i,a,o);
  return[u,d,f,l[2]]
  }
function j(e,n,i,a,o,s,c,l,u){
  let d=e=>t(e).map(e=>Math.round(e*255)),f=[d(u.rim),d(u.glow)],p=d(u.rim),m=e=>A(e,i,a,o,s,c,l),[h,g,_]=v(i,s,c,l),y=r*_,b=(e,t,n)=>n<i[2]&&Math.hypot(e-h,t-g)<y,x=(e,t)=>`rgba(${e[0]},${e[1]},${e[2]},${t})`;
  e.save(),e.lineCap=`round`,e.globalCompositeOperation=`lighter`;
  for(
  let t
   of n.ships){
    let n=f[t.side];
    for(
    let r=1
    ;r<t.trail.length;r++){
      let[i,o,s,c]=m(t.trail[r-1]),[l,u,,d]=m(t.trail[r]);
      if(b(i,o,c)||b(l,u,d))
      continue;
      let f=a*(1-r/t.trail.length);
      e.beginPath(),e.moveTo(i,o),e.lineTo(l,u),e.strokeStyle=x(n,.07*f),e.lineWidth=Math.max(3,.04*s),e.stroke(),e.strokeStyle=x(n,.5*f),e.lineWidth=Math.max(1,.008*s),e.stroke()
      }
    }
  for(
  let t
   of n.bolts){
    let[n,r,i,o]=m(t.p),[s,c]=m([t.p[0]-t.v[0]*.05,t.p[1]-t.v[1]*.05,t.p[2]-t.v[2]*.05]);
    if(b(n,r,o))
    continue;
    let l=a*Math.min(1,t.life*3),u=f[t.side];
    e.beginPath(),e.moveTo(n,r),e.lineTo(s,c),e.shadowColor=x(u,l),e.shadowBlur=Math.max(6,.06*i),e.strokeStyle=x(u,.5*l),e.lineWidth=Math.max(2,.018*i),e.stroke(),e.shadowBlur=0,e.strokeStyle=x([255,255,255],.9*l),e.lineWidth=Math.max(1,.006*i),e.stroke()
    }
  for(
  let t
   of n.bursts){
    let[n,r,i,o]=m(t.p);
    if(b(n,r,o))
    continue;
    let s=1-t.life/.9,c=a*(1-s),l=e.createRadialGradient(n,r,0,n,r,(.03+.1*s)*i);
    l.addColorStop(0,x([255,255,255],c)),l.addColorStop(.4,x(f[t.side],.6*c)),l.addColorStop(1,x(f[t.side],0)),e.fillStyle=l,e.beginPath(),e.arc(n,r,(.03+.1*s)*i,0,Math.PI*2),e.fill()
    }
  e.globalCompositeOperation=`source-over`;
  for(
  let t
   of n.ships){
    if(t.dead>0)
    continue;
    let[n,r,o,s]=m(t.p);
    if(b(n,r,s))
    continue;
    let[c,l]=m([t.p[0]+t.v[0]*.02,t.p[1]+t.v[1]*.02,t.p[2]+t.v[2]*.02]),u=Math.atan2(l-r,c-n),d=.03*o,h=a*(s<i[2]?.7:1);
    e.save(),e.translate(n,r),e.rotate(u),e.globalCompositeOperation=`lighter`;
    let g=e.createRadialGradient(0,0,0,0,0,1.8*d);
    g.addColorStop(0,x(f[t.side],.35*h)),g.addColorStop(.4,x(f[t.side],.12*h)),g.addColorStop(1,x(f[t.side],0)),e.fillStyle=g,e.fillRect(-1.8*d,-1.8*d,3.6*d,3.6*d);
    let _=e.createRadialGradient(-.5*d,0,0,-.5*d,0,.6*d);
    _.addColorStop(0,x(f[t.side],.9*h)),_.addColorStop(1,x(f[t.side],0)),e.fillStyle=_,e.fillRect(-1.1*d,-.6*d,1.2*d,1.2*d),e.globalCompositeOperation=`source-over`,e.fillStyle=x(p,h),e.beginPath(),e.moveTo(.6*d,0),e.lineTo(-.45*d,.38*d),e.lineTo(-.22*d,0),e.lineTo(-.45*d,-.38*d),e.closePath(),e.fill(),e.restore()
    }
  e.restore()
  }
var M=1,N=[0,-.21],P=[[[.28,-.21]],[[.4,-.21],[.47,-.18],[.5,-.09]],[[.54,.05],[.57,.26],[.52,.37]],[[.48,.45],[.37,.47],[.32,.39]],[[.27,.31],[.22,.17],[.13,.15]],[[0,.15]]];
function F(e){
  let t=e=>[-e[0],e[1]];
  e.beginPath(),e.moveTo(N[0],N[1]);
  for(
  let t
   of P)
  t.length===1?e.lineTo(t[0][0],t[0][1]):e.bezierCurveTo(t[0][0],t[0][1],t[1][0],t[1][1],t[2][0],t[2][1]);
  for(
  let n=P.length-1
  ;n>=0;n--){
    let r=P[n],i=t(n===0?N:P[n-1][P[n-1].length-1]);
    if(r.length===1)
    e.lineTo(i[0],i[1]);
    else{
      let[n,a]=[t(r[1]),t(r[0])];
      e.bezierCurveTo(n[0],n[1],a[0],a[1],i[0],i[1])
      }
    }
  e.closePath()
  }
function I(e){
  let n=[0,0];
  return e.ships[M].aim=.45,{step(t){
    let r=e.ships[M].v,i=Math.hypot(r[0],r[1],r[2])||1,a=Math.min(1,t*8);
    n[0]+=(r[0]/i-n[0])*a,n[1]+=(-r[1]/i-n[1])*a
    },draw(r,a,o,s,c,l,u,d){
    let f=e.ships[M],p=e.t,m=f.fired<0?0:Math.max(0,1-(p-f.fired)/.22),h=f.scored<0?0:Math.max(0,1-(p-f.scored)/.5),g=(e,n)=>`rgba(${t(e).map(e=>Math.round(e*255)).join(`,`)},${Math.max(0,Math.min(1,n))})`;
    if(f.dead<=0){
      let[e,t,n,i]=A(f.p,a.h,o,s,c,l,u),[p,m,h]=v(a.h,c,l,u);
      i<a.h[2]&&Math.hypot(e-p,t-m)<.36*h||(r.strokeStyle=g(d.rim,.75*o),r.lineWidth=Math.max(1.5,.006*n),r.beginPath(),r.arc(e,t,.06*n,0,Math.PI*2),r.stroke(),r.fillStyle=g(d.rim,.9*o),r.font=`600 ${Math.max(10,Math.round(.045*n))}px "Geist Variable", system-ui, sans-serif`,r.fillText(`P1`,e+.055*n,t-.055*n))
      }
    let[_,y,b]=v(a.g,c,l,u),x=i*b,S=2*x,C=(1-o)**2*4*x;
    r.save(),r.translate(_+.1*x+h*.012*S*Math.sin(p*95),y+1.6*x+C+h*.009*S*Math.sin(p*83+1)),r.rotate(-.06+s[0]*.06),r.scale(S,S*.82),r.globalAlpha=Math.min(1,o*1.5),r.shadowColor=`rgba(8,4,40,0.45)`,r.shadowBlur=.12*S,r.shadowOffsetY=.06*S;
    let w=r.createLinearGradient(0,-.21,0,.47);
    w.addColorStop(0,`#fbfaff`),w.addColorStop(.55,`#e9e6f7`),w.addColorStop(1,`#c9c2e6`),r.fillStyle=w,F(r),r.fill(),r.shadowColor=`transparent`;
    let T=r.createLinearGradient(0,-.2,0,-.01);
    T.addColorStop(0,`#2d237e`),T.addColorStop(1,`#18114f`),r.fillStyle=T,r.beginPath(),r.roundRect(-.15,-.2,.3,.19,.035),r.fill(),r.fillStyle=g(d.glow,.9);
    for(
    let e
     of[-.172,.16])
    r.beginPath(),r.roundRect(e,-.18,.012,.14,.006),r.fill();
    let E=[[-.14,.07,n],[.14,.07,[.25*Math.sin(p*1.3),.2*Math.cos(p*1.7)]]];
    for(
    let[e,t,n]
    of E){
      r.fillStyle=`#1d1660`,r.beginPath(),r.arc(e,t,.068,0,Math.PI*2),r.fill();
      let i=e+n[0]*.022,a=t+n[1]*.022,o=r.createRadialGradient(i-.012,a-.015,0,i,a,.05);
      o.addColorStop(0,`#4a3fa8`),o.addColorStop(1,`#150f47`),r.fillStyle=o,r.beginPath(),r.arc(i,a,.05,0,Math.PI*2),r.fill()
      }
    r.fillStyle=`#b6afd9`;
    for(
    let[e,t]
    of[[0,-1],[1,0],[0,1],[-1,0]])
    r.beginPath(),r.roundRect(-.31+e*.045-.022,-.07+t*.045-.022,.044,.044,.01),r.fill(),r.beginPath(),r.arc(.31+e*.052,-.07+t*.052,.027,0,Math.PI*2),r.fill();
    if(m>0){
      let e=r.createRadialGradient(.31,-.018,0,.31,-.018,.07);
      e.addColorStop(0,g(d.rim,m)),e.addColorStop(.4,g(d.glow,.8*m)),e.addColorStop(1,g(d.glow,0)),r.globalCompositeOperation=`lighter`,r.fillStyle=e,r.fillRect(.24,-.088,.14,.14),r.globalCompositeOperation=`source-over`
      }
    if(h>0){
      r.strokeStyle=g(d.rim,.95*h),r.lineWidth=.016;
      for(
      let e
       of[-1,1])
      for(
      let t
       of[0,1]){
        let n=.08+.05*t+.1*(1-h);
        r.beginPath(),r.arc(e*.44,.32,n,e>0?-.9:Math.PI-.5,e>0?.5:Math.PI+.9),r.stroke()
        }
      }
    r.restore()
    }}
  }
function L(e){
  let t=[];
  for(
  let n=0
  ;n<e.length-1;n++){
    let r=e[Math.max(0,n-1)],i=e[n],a=e[n+1],o=e[Math.min(e.length-1,n+2)],s=Math.max(2,Math.ceil(Math.hypot(a[0]-i[0],a[1]-i[1])/.02));
    for(
    let e=0
    ;e<s;e++){
      let n=e/s,c=e=>.5*(2*i[e]+(a[e]-r[e])*n+(2*r[e]-5*i[e]+4*a[e]-o[e])*n*n+(3*i[e]-r[e]-3*a[e]+o[e])*n*n*n);
      t.push([c(0),c(1)])
      }
    }
  return t.push(e[e.length-1]),t
  }
function R(e,t,n,r,i,a,o=0){
  let s=Math.ceil(Math.abs(a-i)*Math.max(n,r)/.02),c=[];
  for(
  let l=0
  ;l<=s;l++){
    let u=i+(a-i)*l/s,d=n*Math.cos(u),f=r*Math.sin(u);
    c.push([e+d*Math.cos(o)-f*Math.sin(o),t+d*Math.sin(o)+f*Math.cos(o)])
    }
  return c
  }
function z(e,t,n,r){
  let i=[[]];
  for(
  let a
   of e)
  Math.hypot(a[0]-t,a[1]-n)>r?i[i.length-1].push(a):i[i.length-1].length&&i.push([]);
  return i.filter(e=>e.length>2)
  }
var B=Math.PI*2,V=[-.05,.05,.72,.15,-.3],H=[[L([[-.85,-.2],[-.55,.18],[-.35,-.02],[.02,.42],[.35,.02],[.55,.16],[.85,-.18]]),R(-.42,.58,.13,.13,.4,.4+B*1.06),L([[-.7,-.44],[-.25,-.39],[.2,-.46],[.68,-.41]]),L([[-.3,-.6],[0,-.57],[.3,-.61]]),L([[.26,.6],[.34,.67],[.41,.6],[.48,.67],[.56,.61]]),L([[.54,.4],[.59,.45],[.63,.41],[.67,.45],[.72,.41]])],[Array.from({length:160},(e,t)=>{
  let n=t/159*Math.PI,r=.32*Math.cos(5*n);
  return[r*Math.cos(n),.38+r*Math.sin(n)]
  }),R(0,.38,.06,.06,0,B*1.1),L([[.02,.05],[-.02,-.2],[.06,-.52],[.02,-.86]]),L([[.05,-.5],[.26,-.32],[.52,-.36],[.3,-.52],[.05,-.5]]),L([[0,-.28],[-.22,-.16],[-.44,-.22],[-.25,-.36],[0,-.28]])],[R(V[0],V[1],.36,.36,2.2,2.2+B),R(V[0],V[1],V[2],V[3],Math.PI,B,V[4]),...z(R(V[0],V[1],V[2],V[3],0,Math.PI,V[4]),V[0],V[1],.37),L([[.56,.52],[.56,.74]]),L([[.45,.63],[.67,.63]]),L([[-.62,-.46],[-.62,-.62]]),L([[-.7,-.54],[-.54,-.54]])]],U=1.5,W=2.4,G=.7,K=[.8,-.72],q=e=>(1-Math.cos(Math.PI*Math.min(1,Math.max(0,e))))/2,J=H.map(e=>{
  let t=0,n=K,r=[],i=[];
  for(
  let a
   of e){
    let e=[0];
    for(
    let t=1
    ;t<a.length;t++)
    e.push(e[t-1]+Math.hypot(a[t][0]-a[t-1][0],a[t][1]-a[t-1][1]));
    let o=e[e.length-1];
    t+=.2+Math.hypot(a[0][0]-n[0],a[0][1]-n[1])*.35,i.push([t,t+.1+o/U]),t=i[i.length-1][1],r.push({pts:a,at:e,len:o}),n=a[a.length-1]
    }
  return{strokes:r,legs:i,end:t+W+G}
  });
function ee(e){
  let t=J[0],n={n:0,t:e?t.legs[t.legs.length-1][1]+.6:0};
  return{step:e=>te(n,e),draw:(e,...t)=>re(e,n,...t)}
  }
function te(e,t){
  e.t+=t,e.t>=J[e.n].end&&(e.t=0,e.n=(e.n+1)%J.length)
  }
function Y(e,t){
  let n=e=>Math.min(1,Math.max(0,e));
  return Math.max(.12,n(t/.1)**.6*n((e.len-t)/.22)**.8*(.78+.22*Math.sin(t*11+e.len)))
  }
function ne(e,t){
  let n=1;
  for(;n<e.at.length-1&&e.at[n]<t;)
  n++;
  let r=(t-e.at[n-1])/Math.max(1e-6,e.at[n]-e.at[n-1]),i=e.pts[n-1],a=e.pts[n];
  return[i[0]+(a[0]-i[0])*r,i[1]+(a[1]-i[1])*r]
  }
function re(e,n,a,o,s,c,l,u,d){
  let f=J[n.n],[p,m,h]=v(a.h,c,l,u),[g,_,y]=v(a.g,c,l,u),b=r*h,x=i*y,S=s[0]*.14,C=s[1]*.1,w=(e,t,n,r)=>{
    let i=r[0]+S,a=r[1]+C;
    return[e+n*Math.cos(a)*Math.sin(i),t-n*Math.sin(a),Math.sqrt(Math.max(0,Math.cos(a)*Math.cos(i)))]
    },T=n.t,E=K,D=1,O=0,k=[],A=K,j=0;
  for(
  let[e,t]
  of f.strokes.entries()){
    let[n,r]=f.legs[e];
    if(T>=r)
    k.push({k:t,s:t.len});
    else 
    if(T>=n){
      let e=t.len*q((T-n)/(r-n));
      k.push({k:t,s:e}),E=ne(t,e),D=0,O=Y(t,e)
      }else{
      let r=(T-j)/(n-j),i=q(r),a=t.pts[0];
      E=[A[0]+(a[0]-A[0])*i,A[1]+(a[1]-A[1])*i],D=e===0?1-i:.45*Math.sin(Math.PI*r)
      }
    if(T<r)
    break;
    if(A=t.pts[t.pts.length-1],j=r,e===f.strokes.length-1){
      let e=q((T-r)/.8);
      E=[A[0]+(K[0]-A[0])*e,A[1]+(K[1]-A[1])*e],D=e
      }
    }
  let M=o*Math.min(1,(f.end-T)/G),N=(t,n,r,i,a)=>{
    e.fillStyle=i;
    for(
    let{k:i,s:o}
    of k){
      let s=[];
      for(
      let e=0
      ;e<i.pts.length&&i.at[e]<=o;e++){
        let[o,c,l]=w(t,n,r,i.pts[e]);
        s.push([o,c,r*a*(.3+.7*Y(i,i.at[e]))*l/2])
        }
      if(s.length<2)
      continue;
      let c=[],l=[];
      for(
      let e=0
      ;e<s.length;e++){
        let t=s[Math.max(0,e-1)],n=s[Math.min(s.length-1,e+1)],r=Math.hypot(n[0]-t[0],n[1]-t[1])||1,i=-(n[1]-t[1])/r*s[e][2],a=(n[0]-t[0])/r*s[e][2];
        c.push([s[e][0]+i,s[e][1]+a]),l.push([s[e][0]-i,s[e][1]-a])
        }
      e.beginPath(),e.moveTo(c[0][0],c[0][1]);
      for(
      let t
       of c)
      e.lineTo(t[0],t[1]);
      for(
      let t=l.length-1
      ;t>=0;t--)
      e.lineTo(l[t][0],l[t][1]);
      e.closePath(),e.fill()
      }
    },P=(t,n,r,i,a,o,s)=>{
    e.beginPath(),e.arc(t,n,r,0,Math.PI*2),s&&(e.moveTo(i+o,a),e.arc(i,a,o,0,Math.PI*2)),e.clip(`evenodd`)
    },F=(e,n)=>`rgba(${t(e).map(e=>Math.round(e*255)).join(`,`)},${Math.max(0,Math.min(1,n))})`;
  M>.01&&(e.save(),P(p,m,b,g,_,x,a.g[2]>a.h[2]),N(p,m,b,F(d.page,.88*M),.05),e.restore(),e.save(),P(g,_,x,p,m,b,a.h[2]>a.g[2]),N(g,_,x,F(d.rim,.8*M),.06),e.restore());
  let[I,L]=w(g,_,x,E),R=2.3*x,z=.065*R,B=T+n.n*7,V=.72+.07*Math.sin(B*.7)-.06*O,H=(1-o)**2*R*2;
  if(e.save(),e.translate(I+Math.cos(V)*H-.04*x*D,L+Math.sin(V)*H-.14*x*D),O>0&&o>.5){
    let t=x*.1*(.6+O),n=e.createRadialGradient(0,0,0,0,0,t);
    n.addColorStop(0,F(d.rim,.7*O)),n.addColorStop(1,F(d.rim,0)),e.globalCompositeOperation=`lighter`,e.fillStyle=n,e.fillRect(-t,-t,2*t,2*t),e.globalCompositeOperation=`source-over`
    }
  e.rotate(V),e.shadowColor=`rgba(8,4,40,${.45*(1-.5*D)})`,e.shadowBlur=x*(.1+.2*D),e.shadowOffsetX=x*(.04+.12*D),e.shadowOffsetY=x*(.08+.2*D);
  let U=e.createLinearGradient(0,-z/2,0,z/2);
  U.addColorStop(0,`#bdb6e2`),U.addColorStop(.28,`#ffffff`),U.addColorStop(.6,`#eeebf9`),U.addColorStop(1,`#9d96c9`),e.fillStyle=U,e.beginPath(),e.roundRect(.12*R,-z/2,.88*R,z,[0,z*.4,z*.4,0]),e.fill(),e.shadowColor=`transparent`;
  let W=e.createLinearGradient(0,-z/2,0,z/2);
  W.addColorStop(0,`#8f89b8`),W.addColorStop(.35,`#dcd8f0`),W.addColorStop(1,`#7a74a6`),e.fillStyle=W,e.beginPath(),e.moveTo(0,-z*.06),e.lineTo(.12*R,-z/2),e.lineTo(.12*R,z/2),e.lineTo(0,z*.06),e.closePath(),e.fill(),e.restore()
  }
var X=(e,t)=>[e[0]*t,e[1]*t,e[2]*t],ie=(e,t,n)=>[e[0]+(t[0]-e[0])*n,e[1]+(t[1]-e[1])*n,e[2]+(t[2]-e[2])*n],ae=e=>e.map(e=>e-Math.max(e-.85,0)*.45),Z=(e,t=1)=>`rgba(${e.map(e=>Math.round(Math.min(1,Math.max(0,e))*255)).join(`,`)},${Math.min(1,Math.max(0,t))})`;
function oe(e){
  let n=e.getContext(`2d`,{alpha:!1}),a=document.createElement(`canvas`),o=a.getContext(`2d`);
  if(!n||!o)
  return null;
  let s=document.createElement(`canvas`);
  s.width=s.height=128;
  let c=s.getContext(`2d`);
  if(c){
    let e=c.createImageData(128,128);
    for(
    let t=0
    ;t<e.data.length;t+=4){
      let n=Math.random()*255;
      e.data[t]=e.data[t+1]=e.data[t+2]=n,e.data[t+3]=255
      }
    c.putImageData(e,0,0)
    }
  let l=n.createPattern(s,`repeat`),u=(e,t,n,r,i,a,o)=>{
    let s=e.createRadialGradient(t,n,r,t,n,i);
    for(
    let e=0
    ;e<=24;e++)
    s.addColorStop(e/24,Z(a,o(e/24)));
    e.fillStyle=s,e.beginPath(),e.arc(t,n,i,0,Math.PI*2),e.fill()
    };
  return{draw(s,c,d,f,p,m,h){
    (e.width!==c||e.height!==d)&&(e.width=c,e.height=d);
    let g=Math.ceil(c/2),_=Math.ceil(d/2);
    (a.width!==g||a.height!==_)&&(a.width=g,a.height=_);
    let y=Math.min(1,c/d/.9)*(p[2]??1)*d/2,b=e=>c/2+(e+p[0])*y,x=e=>d/2-(e+p[1])*y,S=(e,t)=>{
      let[n,r,i]=v(e,c,d,p);
      return[n,r,t*i]
      },C=t(h.page),w=t(h.host),T=t(h.rim),E=t(h.glow),D=t(h.mesh),O=1+.22*s.under;
    o.setTransform(1,0,0,1,0,0),o.globalCompositeOperation=`source-over`,o.clearRect(0,0,g,_),o.setTransform(g/c,0,0,_/d,0,0),o.globalCompositeOperation=`lighter`,u(o,b(0),x(0),0,Math.SQRT1_2*y,E,e=>{
      let t=1-e*e;
      return .32*t*t
      });
    let k=m*.06,A=[[-1+.3*Math.sin(k*.7),.7+.25*Math.cos(k*.5),.24,1.1],[1.2+.35*Math.cos(k*.6+1),-.4+.3*Math.sin(k*.8+2),.28,.9],[.3+.4*Math.sin(k*.4+3),-1.2+.2*Math.cos(k*.9+1.5),.16,1.4]];
    for(
    let[e,t,n,r]
    of A){
      let i=Math.sqrt(4.6/r);
      u(o,b(e),x(t),0,i*y,D,e=>n*Math.exp(-((e*i)**2)*r))
      }
    let[j,M,N]=S(s.h,r);
    u(o,j,M,N*.98,N*2.1,w,e=>.6*f.glow*(1+.6*s.under)*Math.exp(-e*1.12*4.5));
    let P=.3*y;
    o.setTransform(1,0,0,1,0,0),o.globalCompositeOperation=`destination-in`;
    for(
    let[e,t,n]
    of[[c,1,0],[d,0,1]]){
      let r=Math.min(.5,P/e),i=o.createLinearGradient(0,0,t*g,n*_);
      i.addColorStop(0,`rgba(0,0,0,0)`),i.addColorStop(r/2,`rgba(0,0,0,0.5)`),i.addColorStop(r,`rgba(0,0,0,1)`),i.addColorStop(1-r,`rgba(0,0,0,1)`),i.addColorStop(1-r/2,`rgba(0,0,0,0.5)`),i.addColorStop(1,`rgba(0,0,0,0)`),o.fillStyle=i,o.fillRect(0,0,g,_)
      }
    n.globalCompositeOperation=`source-over`,n.fillStyle=Z(C),n.fillRect(0,0,c,d),n.globalCompositeOperation=`lighter`,n.drawImage(a,0,0,c,d),n.globalCompositeOperation=`source-over`;
    let F=(e,t,r)=>{
      let i=n.createRadialGradient(e,t,0,e,t,r);
      for(
      let e=0
      ;e<=24;e++){
        let t=e/24,n=(1-Math.sqrt(1-t*t))**f.fres;
        i.addColorStop(t,Z(ae(X(ie(X(w,.88),T,n),f.glow*O))))
        }
      n.fillStyle=i,n.beginPath(),n.arc(e,t,r,0,Math.PI*2),n.fill();
      let a=n.createLinearGradient(e-r,t-r,e+r,t+r);
      a.addColorStop(0,`rgba(255,255,255,0.08)`),a.addColorStop(1,`rgba(20,10,80,0.1)`),n.fillStyle=a,n.fill(),n.save(),n.translate(e-.3*r,t-.38*r),n.rotate(-.35);
      let o=.36*r,s=n.createLinearGradient(0,-o/2,0,o/2);
      s.addColorStop(0,`rgba(255,255,255,0.4)`),s.addColorStop(1,`rgba(255,255,255,0.1)`),n.fillStyle=s,n.beginPath(),n.roundRect(-o/2,-o/2.6,o,o/1.3,o*.3),n.fill(),n.restore(),n.strokeStyle=`rgba(255,255,255,0.35)`,n.lineWidth=Math.max(1,.025*r),n.beginPath(),n.arc(e,t,r*.84,-.95,.55),n.stroke()
      },I=(e,t)=>{
      let[r,i,a]=S(e,t);
      if(a<.5)
      return;
      n.save(),n.beginPath(),n.arc(r,i,a,0,Math.PI*2),n.clip();
      let o=n.createLinearGradient(r,i-a,r,i+a);
      if(o.addColorStop(0,Z(X(C,.95*f.light))),o.addColorStop(.55,Z(X(C,1.12*f.light))),o.addColorStop(1,Z(X(C,1.4*f.light))),n.fillStyle=o,n.fillRect(r-a,i-a,2*a,2*a),s.h[2]<e[2]){
        let e=1+(f.ior-1)*2,[t,o,s]=[r+(j-r)*e,i+(M-i)*e,N*e];
        n.globalAlpha=.3,F(t,o,s),n.globalAlpha=1,n.save(),n.beginPath(),n.arc(t,o,s,0,Math.PI*2),n.clip(),u(n,r,i,0,a,T,e=>e<.6?0:.85*Math.sin((e-.6)/.4*Math.PI*.85)),n.restore()
        }
      if(n.globalCompositeOperation=`lighter`,n.save(),n.translate(r+.1*a,i+.55*a),n.scale(1,.42),u(n,0,0,0,.62*a,w,e=>.12*(1-e*e)**2),n.restore(),n.globalCompositeOperation=`source-over`,u(n,r,i,0,a,ie(T,C,.35),e=>.32*e**6),a>6){
        n.save(),n.translate(r-.36*a,i-.42*a),n.rotate(-.55);
        let e=.34*a,t=n.createLinearGradient(0,-e/3,0,e/3);
        t.addColorStop(0,`rgba(255,255,255,0.45)`),t.addColorStop(1,`rgba(255,255,255,0.08)`),n.fillStyle=t,n.beginPath(),n.roundRect(-e/2,-e/3,e,e*2/3,e*.28),n.fill(),n.restore(),n.strokeStyle=`rgba(255,255,255,0.14)`,n.lineWidth=Math.max(1,.025*a),n.beginPath(),n.arc(r,i,a*.86,-.25,.75),n.stroke()
        }
      l&&a>8&&(n.globalAlpha=.08+f.rough*.25,n.globalCompositeOperation=`soft-light`,n.fillStyle=l,n.fillRect(r-a,i-a,2*a,2*a),n.globalCompositeOperation=`source-over`,n.globalAlpha=1),n.restore()
      },L=[[s.h[2],()=>F(j,M,N)],[s.g[2],()=>I(s.g,i)]];
    for(
    let e
     of s.sats)
    e[3]>.001&&L.push([e[2],()=>I([e[0],e[1],e[2]],e[3])]);
    L.sort((e,t)=>e[0]-t[0]);
    for(
    let[,e]
    of L)
    e();
    l&&(n.globalAlpha=.035,n.globalCompositeOperation=`soft-light`,n.fillStyle=l,n.fillRect(0,0,c,d),n.globalCompositeOperation=`source-over`,n.globalAlpha=1)
    },sync(){
    },dispose(){
    }}
  }
var se={ring:{pose:u[1],zoom:1.4},macro:{pose:u[2],zoom:1.3},play:{pose:u[3],zoom:1.45},work:{pose:u[4],zoom:1.45},alone:{pose:u[5],zoom:1.3},pen:{pose:d[1],prop:`pen`,zoom:1.25},pads:{pose:f[1],prop:`pad`,zoom:1.1,shift:[0,.18]}};
function Q(e,t){
  let n=document.createElement(`span`);
  n.style.color=`var(${e})`,document.body.appendChild(n);
  let r=getComputedStyle(n).color;
  n.remove();
  let i=document.createElement(`canvas`).getContext(`2d`);
  if(!i||!r)
  return t;
  i.fillStyle=`#000000`,i.fillStyle=r;
  let a=i.fillStyle;
  return/^#[0-9a-f]{6}$/i.test(a)?a:t
  }
function ce(){
  return{page:Q(`--neutral`,e.page),host:Q(`--stage-host`,e.host),rim:Q(`--stage-rim`,e.rim),glow:Q(`--stage-glow`,e.glow),mesh:Q(`--stage-mesh`,e.mesh)}
  }
function le(t){
  let n=document.createElement(`canvas`).getContext(`2d`);
  for(
  let e=t
  ;e&&n;e=e.parentElement){
    let t=getComputedStyle(e).backgroundColor;
    if(t&&t!==`transparent`&&t!==`rgba(0, 0, 0, 0)`&&(n.fillStyle=t,/^#[0-9a-f]{6}$/i.test(n.fillStyle)))
    return n.fillStyle
    }
  return e.page
  }
var ue=11,de=.045,fe=1.5,$=null;
async function pe(e,t,r,i,a,o){
  let s=Math.min(window.devicePixelRatio||1,fe),c=window.innerWidth*window.innerHeight*s*s,l=ue*r*i/c,u=[];
  for(
  let s=0
  ;s<4;s++){
    let c=performance.now();
    if(e.draw(t,r,i,n,a,0,o),e.sync(),s===0)
    continue;
    let d=performance.now()-c;
    if(d>l*3)
    return!1;
    u.push(d)
    }
  return u.sort((e,t)=>e-t),u[1]<=l
  }
function me({root:e,flat:t,gpu:r,over:i},a,o,s){
  let c=i.getContext(`2d`),l=oe(t);
  if(!c||!l)
  return()=>{
    };
  let u=l,d=null,{pose:f,prop:p,zoom:m,shift:h=[0,0]}=se[a],g=[h[0],h[1],m],v={...ce(),page:le(e)},b={h:f.h.map(e=>new y(e)),c:f.c.map(e=>new y(e)),under:new y(f.under),ring:new y(f.ring),fleet:new y(f.fleet),prop:new y(f.prop)};
  o||(b.h[0].x-=.1,b.c[0].x+=1.5,b.c[1].x+=.5,b.c[2].x+=.9);
  let x=O(),S=p===`pen`?ee(o):p===`pad`?I(x):null,C=0,T=!1,E=0,D=0,A=performance.now(),M=1/0,N=!0,P=!1,F=!1,L=.9,R=[0,0],z=[0,0],B=null,V=performance.now(),H=()=>{
    u===d&&(u=l,s(`2d`),N=!0)
    },U=()=>{
    let e=Math.min(window.devicePixelRatio||1,fe);
    return[Math.round(t.clientWidth*e),Math.round(t.clientHeight*e)]
    },W=(e,t,n)=>{
    let r=e.fleet>.01||S!==null&&e.prop>.01;
    if(!r&&!F||!B)
    return;
    let i=c.canvas;
    (i.width!==t||i.height!==n)&&(i.width=t,i.height=n),c.clearRect(0,0,t,n);
    let a=e=>e*e*(3-2*e),{s:o,look:s}=B;
    e.fleet>.01&&j(c,x,o.h,a(e.fleet),s,t,n,g,v),S&&e.prop>.01&&S.draw(c,o,a(e.prop),s,t,n,g,v),F=r
    },G=e=>{
    C=requestAnimationFrame(G);
    let t=(e-A)/1e3,r=Math.min(.05,t);
    if(A=e,!P||document.hidden)
    return;
    u===d&&(E+=(Math.min(.1,t)-E)*.05,++D>60&&E>de&&H());
    let i=!1;
    for(
    let e=0
    ;e<3;e++)
    b.h[e].step(f.h[e],r,o),b.c[e].step(f.c[e],r,o),i||=b.h[e].busy(f.h[e])||b.c[e].busy(f.c[e]);
    b.under.step(f.under,r,o),b.ring.step(f.ring,r,o),b.fleet.step(f.fleet,r,o),b.prop.step(f.prop,r,o);
    let a={h:[b.h[0].x,b.h[1].x,b.h[2].x],c:[b.c[0].x,b.c[1].x,b.c[2].x],under:b.under.x,ring:b.ring.x,fleet:b.fleet.x,prop:b.prop.x},s=!1;
    if(!o){
      a.fleet>.01&&(k(x,r),s=!0),S&&a.prop>.01&&(S.step(r),s=!0);
      let t=e/1e3,n=.022*Math.sin(t*.9),i=.018*Math.sin(t*.7+1.3);
      a.c[0]+=n,a.c[1]+=i,a.c[2]+=.02*Math.sin(t*.5+2.1),a.h[0]-=n/3,a.h[1]-=i/3,a.ring>.01&&(L+=r*.22*a.ring);
      let o=Math.min(1,r*4);
      R[0]+=(z[0]-R[0])*o,R[1]+=(z[1]-R[1])*o
      }
    M+=t;
    let c=N||!o&&(i||M>=.029333333333333333)||o&&i,[l,p]=U();
    if(c){
      let e=_(a,L,R);
      u.draw(e,l,p,n,g,o?0:(performance.now()-V)/1e3,v),B={s:e,look:[R[0],R[1]]},M=0,N=!1
      }
    (c||s||F)&&W(a,l,p)
    };
  C=requestAnimationFrame(G);
  let K=new URLSearchParams(window.location.search).get(`stage`),q=navigator.connection?.saveData;
  (K===`3d`||K!==`2d`&&!q)&&(async()=>{
    if(K!==`3d`&&$&&!await $||T)
    return;
    let e=await w(r,K===`3d`,()=>T);
    if(!T){
      if(!e){
        $??=Promise.resolve(!1);
        return
        }
      if(K!==`3d`){
        let[t,n]=U();
        if($??=pe(e,_(f,L,R),t,n,g,v),!await $||T)
        return
        }
      d=e,u=e,E=0,D=0,s(`3d`),N=!0
      }
    })();
  let J=t=>{
    if(!P)
    return;
    let n=e.getBoundingClientRect();
    z[0]=Math.max(-1,Math.min(1,(t.clientX-n.left)/n.width*2-1)),z[1]=Math.max(-1,Math.min(1,1-(t.clientY-n.top)/n.height*2))
    },te=()=>{
    z[0]=0,z[1]=0
    },Y=e=>{
    e.preventDefault(),H(),d=null
    },ne=new IntersectionObserver(e=>{
    P=e[0]?.isIntersecting??!0,P&&(N=!0,A=performance.now())
    });
  ne.observe(e);
  let re=new ResizeObserver(()=>{
    N=!0
    });
  return re.observe(e),window.addEventListener(`pointermove`,J,{passive:!0}),document.addEventListener(`pointerleave`,te),r.addEventListener(`webglcontextlost`,Y),()=>{
    T=!0,cancelAnimationFrame(C),ne.disconnect(),re.disconnect(),window.removeEventListener(`pointermove`,J),document.removeEventListener(`pointerleave`,te),r.removeEventListener(`webglcontextlost`,Y),d?.dispose()
    }
  }
export{me as startTile};
