const origin = 'https://punktfunk.unom.io';

const navigation = [
  ['Docs', 'https://docs.punktfunk.unom.io'],
  ['Compare', `${origin}/en/compare`],
  ['Donate', 'https://ko-fi.com/punktfunk'],
  ['Blog', `${origin}/en/blog`],
  ['FAQ', `${origin}/en/faq`],
  ['Support', `${origin}/en/support`],
  ['Source code', 'https://git.unom.io/unom/punktfunk'],
];

/** Portalled dropdowns preserve the page layout and stay inside the viewport. */
export function mountMenus() {
  let active;
  const listeners = [];
  const on = (target, type, callback, options) => {
    target.addEventListener(type, callback, options);
    listeners.push(() => target.removeEventListener(type, callback, options));
  };

  function close(restoreFocus = false) {
    if (!active) return;
    const { trigger, menu } = active;
    trigger.setAttribute('aria-expanded', 'false');
    trigger.dataset.state = 'closed';
    menu.remove();
    active = undefined;
    if (restoreFocus) trigger.focus();
  }

  function position() {
    if (!active) return;
    const { trigger, menu, placement } = active;
    const rect = trigger.getBoundingClientRect();
    const gap = placement === 'top' ? 8 : 12;
    const top = placement === 'top' ? rect.top - menu.offsetHeight - gap : rect.bottom + gap;
    menu.style.top = `${Math.max(8, Math.min(top, window.innerHeight - menu.offsetHeight - 8))}px`;
    menu.style.left = `${Math.max(8, Math.min(rect.right - menu.offsetWidth, window.innerWidth - menu.offsetWidth - 8))}px`;
  }

  function install(trigger, items, placement, id) {
    trigger.id = `${id}-trigger`;
    trigger.setAttribute('aria-controls', id);
    on(trigger, 'click', () => {
      if (active?.trigger === trigger) return close();
      close();
      const menu = document.createElement('div');
      menu.id = id;
      menu.className = 'float-menu local-menu';
      menu.role = 'menu';
      menu.tabIndex = -1;
      menu.dataset.state = 'open';
      menu.setAttribute('aria-labelledby', trigger.id);
      for (const [label, href, checked] of items) {
        const item = document.createElement('a');
        item.href = href;
        item.textContent = label;
        item.tabIndex = -1;
        item.role = checked === undefined ? 'menuitem' : 'menuitemradio';
        if (checked !== undefined) {
          item.setAttribute('aria-checked', String(checked));
          item.dataset.state = checked ? 'checked' : 'unchecked';
          if (checked) {
            const check = document.createElementNS('http://www.w3.org/2000/svg', 'svg');
            check.setAttribute('viewBox', '0 0 24 24');
            check.setAttribute('width', '16');
            check.setAttribute('height', '16');
            check.setAttribute('aria-hidden', 'true');
            check.innerHTML = '<path d="m20 6-11 11-5-5" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>';
            item.append(check);
          }
        }
        item.addEventListener('click', (event) => {
          if (checked) event.preventDefault();
          close(true);
        });
        menu.append(item);
      }
      document.body.append(menu);
      active = { trigger, menu, placement };
      trigger.setAttribute('aria-expanded', 'true');
      trigger.dataset.state = 'open';
      position();
      menu.querySelector('a')?.focus({ preventScroll: true });
    });
    on(trigger, 'keydown', (event) => {
      if (event.key === 'ArrowDown' || event.key === 'ArrowUp') {
        event.preventDefault();
        if (active?.trigger !== trigger) trigger.click();
        const links = active?.menu.querySelectorAll('a');
        (event.key === 'ArrowUp' ? links?.[links.length - 1] : links?.[0])?.focus();
      }
    });
  }

  install(document.querySelector('.mobile-menu-trigger'), navigation, 'bottom', 'mobile-navigation');
  install(document.querySelector('.locale-trigger'), [
    ['Deutsch', `${origin}/de/`, false],
    ['English', '/en/', true],
  ], 'top', 'language-navigation');

  on(document, 'pointerdown', (event) => {
    if (active && !active.menu.contains(event.target) && !active.trigger.contains(event.target)) close();
  });
  on(document, 'keydown', (event) => {
    if (!active) return;
    const links = [...active.menu.querySelectorAll('a')];
    const index = links.indexOf(document.activeElement);
    if (event.key === 'Escape') {
      event.preventDefault();
      close(true);
    } else if (event.key === 'Tab') {
      // Restore the trigger before the browser advances to the next normal tab stop.
      close(true);
    } else if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      const next = event.key === 'Home' ? 0 : event.key === 'End' ? links.length - 1
        : (index + (event.key === 'ArrowUp' ? -1 : 1) + links.length) % links.length;
      links[next]?.focus();
    }
  });
  on(window, 'resize', position);
  on(window, 'scroll', position, { passive: true });
  return () => { close(); listeners.forEach((remove) => remove()); };
}
