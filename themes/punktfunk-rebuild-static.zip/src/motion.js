/** The same stagger, viewport margin, offsets and curves as the reference. */
export function revealPanels(reducedMotion) {
  const panels = [...document.querySelectorAll('[data-reveal]')];
  const pending = new Map();
  const animations = [];
  const observer = new IntersectionObserver((entries) => {
    for (const { target, isIntersecting } of entries) {
      if (!isIntersecting) continue;
      observer.unobserve(target);
      const { delay, nested, still } = pending.get(target);
      target.dataset.revealed = 'true';
      if (reducedMotion || still) continue;
      const options = { delay: delay * 1000, fill: 'both' };
      animations.push(target.animate(
        [{ opacity: 0 }, { opacity: 1 }],
        { ...options, duration: 600, easing: 'ease-out' },
      ));
      animations.push(target.animate(
        [{ transform: `translateY(${nested ? 0 : 28}px)` }, { transform: 'none' }],
        { ...options, duration: 750, easing: 'cubic-bezier(.23, 1, .32, 1)' },
      ));
    }
  }, { rootMargin: '0px 0px -8% 0px' });

  for (const panel of panels) {
    const rect = panel.getBoundingClientRect();
    const inView = rect.top < window.innerHeight * 0.92;
    const nested = !!panel.parentElement.closest('[data-reveal]');
    const horizontalDelay = 0.12 * Math.max(0, rect.left) / window.innerWidth;
    const delay = nested ? 0 : inView
      ? 0.12 + 0.5 * Math.max(0, rect.top) / window.innerHeight + horizontalDelay
      : horizontalDelay;
    pending.set(panel, { delay, nested, still: nested && inView });
    observer.observe(panel);
  }
  return () => {
    observer.disconnect();
    animations.forEach((animation) => animation.cancel());
  };
}

/** Recreate the two-circle orbit, light-disc spring and clipped wordmark reveal. */
export function animateBrand(reducedMotion) {
  if (reducedMotion) return () => {};
  const svg = document.querySelector('.brand-mark');
  const [light, deep, overlap] = svg.querySelectorAll(':scope > path');
  const animations = [];
  let frame = 0;
  const start = performance.now();
  const ease = (p) => p < 0.5 ? 2 * p * p : 1 - (2 - 2 * p) ** 2 / 2;

  for (const path of [light, deep]) {
    path.style.transformBox = 'fill-box';
    path.style.transformOrigin = 'center';
  }

  // Underdamped spring: stiffness 200, damping 15, mass 1.
  const springFrames = Array.from({ length: 81 }, (_, index) => {
    const t = index / 80;
    const w = Math.sqrt(200 - 7.5 ** 2);
    const scale = 1 - Math.exp(-7.5 * t) * (Math.cos(w * t) + 7.5 / w * Math.sin(w * t));
    return { transform: `scale(${index === 80 ? 1 : scale})`, offset: t };
  });
  animations.push(light.animate(springFrames, { duration: 1000, delay: 50, fill: 'both' }));
  animations.push(deep.animate([{ opacity: 0 }, { opacity: 1 }], {
    duration: 100, delay: 420, fill: 'both', easing: 'ease-out',
  }));
  animations.push(overlap.animate([{ opacity: 0 }, { opacity: 1 }], {
    duration: 400, delay: 1370, fill: 'both', easing: 'ease-out',
  }));

  let previousFront;
  function tick(now) {
    const p = Math.min(1, Math.max(0, (now - start - 420) / 1150));
    const angle = -Math.PI / 2 - 1.5 * Math.PI * ease(p);
    const distance = 36.17 + 6 * Math.sin(angle / 2) ** 2;
    const x = 25.5749 + distance * Math.SQRT1_2 * (Math.cos(angle) + 0.12 * Math.sin(angle)) - 51.1499;
    const y = 61.7431 + distance * Math.SQRT1_2 * (-Math.cos(angle) + 0.12 * Math.sin(angle)) - 36.1682;
    const scale = 1 + 0.2 * (Math.cos(angle) - 1);
    const front = angle < -Math.PI;
    if (front !== previousFront) {
      svg.insertBefore(front ? light : deep, front ? deep : light);
      previousFront = front;
    }
    deep.style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
    if (p < 1) frame = requestAnimationFrame(tick);
    else deep.style.transform = '';
  }
  frame = requestAnimationFrame(tick);

  const wordmark = document.querySelector('.brand-wordmark');
  const ns = 'http://www.w3.org/2000/svg';
  const defs = document.createElementNS(ns, 'defs');
  wordmark.prepend(defs);
  const bounds = [[16.782, 108.537], [131.785, 133.325], [271.575, 142.869], [420.91, 141.79]];
  wordmark.querySelectorAll(':scope > path').forEach((path, index) => {
    const [x, width] = bounds[index];
    const clip = document.createElementNS(ns, 'clipPath');
    clip.id = `wordmark-reveal-${index}`;
    clip.setAttribute('clipPathUnits', 'userSpaceOnUse');
    const rect = document.createElementNS(ns, 'rect');
    for (const [name, value] of Object.entries({ x, y: 0, width, height: 136 })) {
      rect.setAttribute(name, value);
    }
    clip.append(rect);
    defs.append(clip);
    const group = document.createElementNS(ns, 'g');
    group.setAttribute('clip-path', `url(#${clip.id})`);
    path.replaceWith(group);
    group.append(path);
    animations.push(path.animate([
      { transform: `translateX(${width}px)` }, { transform: 'translateX(0)' },
    ], { duration: 550, delay: 150 + index * 90, fill: 'both', easing: 'cubic-bezier(.16, 1, .3, 1)' }));
  });

  return () => {
    cancelAnimationFrame(frame);
    animations.forEach((animation) => animation.cancel());
  };
}
