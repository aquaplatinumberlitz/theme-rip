import { mountScenes } from './scenes.js';
import { revealPanels, animateBrand } from './motion.js';
import { mountMenus } from './menus.js';

// These UI modules replace the original React/router runtime. The illustrations
// use the retained first-party renderer so their optics and physics stay intact.
const motion = window.matchMedia('(prefers-reduced-motion: reduce)');
const disposeMenus = mountMenus();
const disposePanels = revealPanels(motion.matches);
const disposeBrand = animateBrand(motion.matches);
let disposeScenes = mountScenes(motion.matches);

function updateMotion() {
  disposeScenes();
  disposeScenes = mountScenes(motion.matches);
}
motion.addEventListener('change', updateMotion);

window.addEventListener('pagehide', (event) => {
  if (event.persisted) return;
  disposeMenus();
  disposePanels();
  disposeBrand();
  disposeScenes();
  motion.removeEventListener('change', updateMotion);
});

document.documentElement.dataset.ready = 'true';
