/**
 * A scene has three layers: the 2D renderer, optional WebGL2 renderer,
 * and the 2D foreground props. The engine owns its frame loop, resize observer,
 * visibility observer, pointer tracking, performance probe, and GPU fallback.
 */
export function mountScenes(reducedMotion) {
  const cleanups = new Map();
  let disposed = false;
  let engine;

  const observer = new IntersectionObserver(async (entries) => {
    for (const entry of entries) {
      if (!entry.isIntersecting) continue;
      const root = entry.target;
      observer.unobserve(root);
      try {
        engine ??= import('./engine/tile-engine.js');
        const { startTile } = await engine;
        if (disposed) return;
        const [flat, gpu, over] = root.querySelectorAll('canvas');
        const stop = startTile(
          { root, flat, gpu, over },
          root.dataset.scene,
          reducedMotion,
          (mode) => {
            gpu.classList.toggle('is-on', mode === '3d');
            root.dataset.renderer = mode;
          },
        );
        root.dataset.renderer ??= '2d';
        root.dataset.initialized = 'true';
        cleanups.set(root, stop);
      } catch (error) {
        console.error(`Unable to start scene ${root.dataset.scene}:`, error);
        root.dataset.error = 'true';
      }
    }
  }, { rootMargin: '50% 0px' });

  document.querySelectorAll('[data-scene]').forEach((root) => observer.observe(root));

  return () => {
    disposed = true;
    observer.disconnect();
    for (const [root, stop] of cleanups) {
      stop();
      root.querySelector('.tile-scene-gpu').classList.remove('is-on');
      delete root.dataset.initialized;
      delete root.dataset.renderer;
    }
    cleanups.clear();
  };
}
