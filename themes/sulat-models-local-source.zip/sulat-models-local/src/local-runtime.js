/* Local-only integrations; the recovered UI owns menus, motion and page state. */
(() => {
  const saved = new Set(['/', '/models/xai-grok-45-97244c89']);
  const original = 'https://models.sulat.com';
  let speechButton;
  let originalLabel;
  function stopSpeech() {
    window.speechSynthesis?.cancel();
    if (speechButton && originalLabel) {
      const text = [...speechButton.childNodes].find((node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
      if (text) text.textContent = originalLabel;
      speechButton.removeAttribute('data-local-speaking');
    }
    speechButton = undefined;
  }
  document.addEventListener('click', async (event) => {
    const audio = event.target.closest?.('button[aria-label="Listen to model overview audio"], button[data-local-speaking]');
    if (audio && 'speechSynthesis' in window) {
      event.preventDefault();
      event.stopImmediatePropagation();
      if (audio === speechButton) return stopSpeech();
      stopSpeech();
      const data = await fetch('/_catalog/models/xai-grok-45-97244c89/overview').then((response) => response.json());
      const paragraphs = data.paragraphs || [];
      const utterance = new SpeechSynthesisUtterance(paragraphs.join('\n\n'));
      utterance.lang = 'en-US';
      speechButton = audio;
      audio.dataset.localSpeaking = 'true';
      const text = [...audio.childNodes].find((node) => node.nodeType === Node.TEXT_NODE && node.textContent.trim());
      originalLabel = text?.textContent || 'Listen';
      if (text) text.textContent = 'Stop';
      utterance.onend = stopSpeech;
      utterance.onerror = stopSpeech;
      window.speechSynthesis.speak(utterance);
      return;
    }
    const anchor = event.target.closest?.('a[href]');
    if (!anchor || anchor.hasAttribute('download')) return;
    let url;
    try { url = new URL(anchor.href, location.href); } catch { return; }
    if (url.origin !== location.origin || saved.has(url.pathname.replace(/\/$/, '') || '/')) return;
    if (!/^\/(?:models|providers|news|feed)(?:\/|$)/.test(url.pathname)) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    const destination = original + url.pathname + url.search + url.hash;
    if (event.metaKey || event.ctrlKey || anchor.target === '_blank') window.open(destination, '_blank', 'noopener');
    else location.assign(destination);
  }, true);
  window.addEventListener('pagehide', stopSpeech);
})();
