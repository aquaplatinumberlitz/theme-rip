import{c as e,p as t}from"./react-inertia-runtime.js";
import{T as n}from"./app.js";
var r=t(e(),1),i=[`16`,`24`],a={16:{width:16,path:r.createElement(`path`,{d:`M8.22 2.97a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042l2.97-2.97H3.75a.75.75 0 0 1 0-1.5h7.44L8.22 4.03a.75.75 0 0 1 0-1.06Z`})},24:{width:24,path:r.createElement(`path`,{d:`M13.22 19.03a.75.75 0 0 1 0-1.06L18.19 13H3.75a.75.75 0 0 1 0-1.5h14.44l-4.97-4.97a.749.749 0 0 1 .326-1.275.749.749 0 0 1 .734.215l6.25 6.25a.75.75 0 0 1 0 1.06l-6.25 6.25a.75.75 0 0 1-1.06 0Z`})}},o=r.forwardRef(function(e,t){
  return n(e,t,`octicon octicon-arrow-right`,a,i)
  });
o.displayName=`ArrowRightIcon`;
export{o as t};
