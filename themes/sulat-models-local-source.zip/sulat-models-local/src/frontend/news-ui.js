import{c as e,n as t,p as n}from"./react-inertia-runtime.js";
import{Dt as r,bt as i,h as a,n as o,xt as s}from"./app.js";
var c=n(e(),1),l=t();
function u(...e){
  return e.filter(Boolean).join(` `)
  }
function d(){
  return(0,l.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,l.jsx)(`path`,{d:`M6 4.5h5.5V10M11.5 4.5 4.5 11.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.35`})})
  }
function f({eyebrow:e,children:t,icon:n}){
  return(0,l.jsxs)(l.Fragment,{children:[(0,l.jsx)(`span`,{"aria-hidden":`true`,className:`pointer-events-none absolute inset-y-0 -left-1/2 w-1/2 rotate-[18deg] bg-linear-to-r from-white/0 via-white/35 to-white/0 transition-transform duration-700 group-hover:translate-x-[260%]`}),(0,l.jsxs)(`span`,{className:`relative flex flex-col items-start gap-1`,children:[e?(0,l.jsx)(`span`,{className:`text-[0.62rem] tracking-[0.18em] text-white/80 uppercase`,children:e}):null,(0,l.jsx)(`span`,{className:`text-white`,children:t})]}),(0,l.jsx)(`span`,{className:`relative inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full border border-white/25 bg-white/15 text-white shadow-inner transition group-hover:bg-white/20`,children:n??(0,l.jsx)(d,{})})]})
  }
function p(e){
  let{eyebrow:t,children:n,className:r,fullWidth:i=!1,icon:a,...o}=e,s=u(`group relative inline-flex items-center justify-between gap-4 overflow-hidden rounded-[1.05rem] border border-white/20 bg-linear-to-br from-amber-500 via-accent to-accent-deep px-4 py-4 text-left text-[0.92rem] font-semibold text-white shadow-xl transition hover:-translate-y-[1px] hover:shadow-2xl`,i&&`w-full`,r);
  if(`href`in e&&typeof e.href==`string`)
  return(0,l.jsx)(`a`,{...o,className:u(s,`no-underline`),children:(0,l.jsx)(f,{eyebrow:t,icon:a,children:n})});
  let c=o;
  return(0,l.jsx)(`button`,{...c,className:s,type:c.type??`button`,children:(0,l.jsx)(f,{eyebrow:t,icon:a,children:n})})
  }
var m=[`news-skeleton-1`,`news-skeleton-2`,`news-skeleton-3`];
function h(){
  return(0,l.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,l.jsx)(`path`,{d:`M12.5 5.5A4.75 4.75 0 0 0 4.4 4.15M4.5 2.75v2.1h2.1`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.35`}),(0,l.jsx)(`path`,{d:`M3.5 10.5a4.75 4.75 0 0 0 8.1 1.35m-.1 1.4v-2.1H9.4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.35`})]})
  }
function g({article:e,onOpen:t}){
  let n=e.articleKind?r(e.articleKind):null,i=e.articleKind?.toLowerCase()===(e.isOfficial?`official`:`coverage`),s=n!==null&&!i;
  return(0,l.jsxs)(`article`,{className:`grid grid-cols-[auto_minmax(0,1fr)] items-start gap-x-4 gap-y-4 px-5 py-5 sm:gap-x-5 sm:px-6 sm:py-6`,children:[(0,l.jsx)(a,{className:`size-12 shrink-0 sm:size-14`,compact:!0,decorative:!0,provider:{name:e.providerName,logo:e.providerLogo}}),(0,l.jsxs)(`div`,{className:`grid min-w-0 gap-2.5`,children:[(0,l.jsx)(`p`,{className:`text-sm font-medium text-[color:var(--color-ink)]`,children:e.providerName}),(0,l.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,l.jsx)(o,{tone:e.isOfficial?`accent`:`muted`,children:e.isOfficial?`Official source`:`Coverage`}),s?(0,l.jsx)(o,{tone:`muted`,children:n}):null]})]}),(0,l.jsxs)(`div`,{className:`col-span-2 space-y-3 sm:col-span-1 sm:col-start-2`,children:[(0,l.jsx)(`button`,{className:`inline-flex items-start text-left font-serif text-[1.6rem] tracking-[-0.04em] text-[color:var(--color-ink)] transition hover:text-[color:var(--color-accent-deep)]`,type:`button`,onClick:()=>t(e),children:e.title}),e.summary?(0,l.jsx)(`p`,{className:`max-w-3xl text-sm leading-7 text-[color:var(--color-muted)]`,children:e.summary}):null]})]})
  }
function _({article:e,onClose:t}){
  let n=(0,c.useId)(),r=e.summaryParagraphs?.filter(e=>e.trim()!==``)??[];
  return(0,l.jsx)(s,{ariaLabelledBy:n,className:`items-center justify-center`,onClose:t,panelClassName:`surface-panel mx-auto max-w-3xl rounded-[1.4rem] p-5 sm:p-6`,children:(0,l.jsxs)(`div`,{className:`grid gap-5`,children:[(0,l.jsx)(i,{eyebrow:e.sourceName??e.sourceHost??`Coverage`,onClose:t,title:e.title,titleId:n}),(0,l.jsx)(`div`,{className:`space-y-4 text-base/7 text-[color:var(--color-muted)] sm:text-sm/7`,children:r.length>0?r.map(e=>(0,l.jsx)(`p`,{children:e},e)):e.summary?(0,l.jsx)(`p`,{children:e.summary}):(0,l.jsx)(`p`,{children:`A generated summary is not available for this saved article yet.`})}),(0,l.jsx)(`div`,{children:(0,l.jsx)(`a`,{className:`news-modal-read-link inline-flex rounded-full bg-[color:var(--color-ink)] px-5 py-3 text-sm font-semibold transition hover:bg-[color:var(--color-accent-deep)]`,href:e.url,rel:`noreferrer`,target:`_blank`,children:`Read the full piece`})})]})})
  }
function v(){
  return(0,l.jsx)(`div`,{"aria-live":`polite`,className:`grid gap-4`,children:(0,l.jsx)(`div`,{className:`grid gap-3`,children:m.map(e=>(0,l.jsxs)(`div`,{className:`rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/75 px-5 py-5`,children:[(0,l.jsxs)(`div`,{className:`mb-4 flex gap-2`,children:[(0,l.jsx)(`div`,{className:`bg-accent/15 h-7 w-28 animate-pulse rounded-full`}),(0,l.jsx)(`div`,{className:`h-7 w-24 animate-pulse rounded-full bg-neutral-500/15`})]}),(0,l.jsxs)(`div`,{className:`space-y-3`,children:[(0,l.jsx)(`div`,{className:`h-8 w-4/5 animate-pulse rounded-full bg-neutral-950/10`}),(0,l.jsx)(`div`,{className:`h-4 w-full animate-pulse rounded-full bg-neutral-500/15`}),(0,l.jsx)(`div`,{className:`h-4 w-3/4 animate-pulse rounded-full bg-neutral-500/15`})]})]},e))})})
  }
function y({message:e,detail:t,onRequest:n}){
  return(0,l.jsxs)(`div`,{className:`grid justify-items-center gap-5 rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70 p-6 text-center`,children:[(0,l.jsx)(`p`,{className:`max-w-2xl text-sm leading-7 text-[color:var(--color-muted)]`,children:e}),(0,l.jsx)(p,{icon:(0,l.jsx)(h,{}),onClick:n,children:`Fetch latest news`}),t?(0,l.jsx)(`p`,{className:`max-w-2xl text-sm leading-7 text-[color:var(--color-accent-deep)]`,children:t}):null]})
  }
function b({title:e,body:t,detail:n}){
  return(0,l.jsxs)(`div`,{className:`rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70 p-6`,children:[(0,l.jsx)(`h3`,{className:`font-serif text-[1.8rem] tracking-[-0.05em] text-[color:var(--color-ink)]`,children:e}),(0,l.jsx)(`p`,{className:`mt-3 max-w-3xl text-sm leading-7 text-[color:var(--color-muted)]`,children:t}),n?(0,l.jsx)(`p`,{className:`mt-3 text-sm leading-7 text-[color:var(--color-accent-deep)]`,children:n}):null]})
  }
export{b as a,y as i,_ as n,v as r,g as t};
