import{c as e,n as t,o as n,p as r,t as i}from"./react-inertia-runtime.js";
import{a,c as o,l as s,n as c,o as l,r as u,s as d,t as f}from"./model-sections.js";
import{A as p,B as m,F as h,I as g,M as _,N as v,P as y,Rt as b,Tt as x,U as ee,V as te,b as ne,bt as S,c as re,ct as C,d as ie,dt as w,ft as T,g as E,h as ae,j as D,k as oe,kt as O,lt as k,m as se,n as A,nt as j,o as ce,pt as M,r as le,rt as N,s as ue,t as de,u as fe,ut as P,v as F,wt as pe,x as I,xt as me,y as L,z as he}from"./app.js";
import{t as ge}from"./seo.js";
var R=r(e(),1),z=t();
function _e(){
  return(0,z.jsxs)(`a`,{href:d,target:`_blank`,rel:`noreferrer sponsored`,"aria-label":`TTS sponsored by Synthetic.`,className:`section-promo-badge inline-flex max-w-full items-center justify-center gap-2 rounded-full border border-amber-700/20 bg-linear-to-b from-white to-amber-50 px-2.5 py-1.5 text-center shadow-sm transition hover:-translate-y-0.5 hover:border-amber-700/35 hover:shadow-md dark:border-amber-300/30 dark:shadow-none dark:hover:shadow-none`,children:[(0,z.jsx)(`span`,{className:`text-[0.56rem] leading-none font-semibold tracking-[0.18em] text-[color:var(--color-muted)] uppercase`,children:`TTS sponsored by`}),(0,z.jsxs)(`span`,{className:`inline-flex items-center gap-2`,children:[(0,z.jsx)(h,{src:`/synthetic.svg`,alt:``,width:24,height:24,"aria-hidden":`true`,className:`h-6 w-6 dark:hidden`}),(0,z.jsx)(h,{src:`/synthetic-dark.svg`,alt:``,width:24,height:24,"aria-hidden":`true`,className:`hidden h-6 w-6 dark:block`}),(0,z.jsx)(`span`,{className:`text-[0.82rem] leading-none font-black text-neutral-950 dark:text-amber-200`,children:`Synthetic`})]})]})
  }
var B=class extends Error{
  status;details;constructor(e,t,n){
    super(e),this.name=`BrowserModelOverviewError`,this.status=t,this.details=n
    }
};
async function ve(e,t){
  let n=await T(e);
  if(e.ok){
    let e=t(n);
    if(e!==null)
    return e;
    throw new B(`Model overview service returned invalid data.`,502)
    }
  let r=M(n);
  throw new B(r.message??`Model overview request failed.`,r.status??e.status,r.details)
  }
async function V(e,t){
  return ve(await fetch(e,{headers:{accept:`application/json`}}).catch(e=>{
    throw new B(e instanceof Error?e.message:`Unable to reach the overview service.`,503)
    }),t)
  }
function ye(e){
  return!P(e)||typeof e.status!=`string`||typeof e.modelSlug!=`string`||!w(e.paragraphs)||!w(e.sourceUrls)||!Array.isArray(e.sources)||!e.sources.every(be)||e.refresh!==null&&!H(e.refresh)?null:e
  }
function be(e){
  return P(e)&&k(e.title)&&k(e.url)&&k(e.sourceHost)&&k(e.sourceType)&&k(e.publishedAt)&&k(e.excerpt)
  }
function H(e){
  return P(e)&&typeof e.id==`string`&&typeof e.status==`string`&&typeof e.source==`string`&&k(e.requestedAt)&&k(e.startedAt)&&k(e.finishedAt)&&C(e.sourcesFound)&&C(e.sourcesUsed)&&k(e.errorMessage)
  }
function xe(e){
  return H(e)?e:null
  }
function U(e){
  return V(`/_catalog/models/${encodeURIComponent(e)}/overview`,ye)
  }
function Se(e){
  return V(`/_catalog/overview-refreshes/${encodeURIComponent(e)}`,xe)
  }
async function Ce(e){
  if((e.headers.get(`content-type`)??``).includes(`json`)){
    let t=M(await T(e));
    return new B(t.message??`Model overview audio request failed.`,t.status??e.status,t.details)
    }
  return new B(await e.text()||`Model overview audio request failed.`,e.status)
  }
async function we(e){
  let t=await fetch(`/_catalog/models/${encodeURIComponent(e)}/overview-audio`,{headers:{accept:`audio/mpeg, audio/*;q=0.9`}}).catch(e=>{
    throw new B(e instanceof Error?e.message:`Unable to reach the overview audio service.`,503)
    });
  if(!t.ok)
  throw await Ce(t);
  let n=await t.blob();
  if(n.size===0)
  throw new B(`Model overview audio was empty.`,502);
  return n
  }
function Te(e){
  return e===`loading`?`Loading`:e===`playing`?`Pause`:e===`paused`?`Resume`:`Listen`
  }
function Ee({hasOverview:e,state:t}){
  return!e||t===`loading`
  }
function De({active:e}){
  return(0,z.jsx)(`span`,{"aria-hidden":`true`,className:`grid h-7 w-7 shrink-0 place-items-center rounded-full transition ${e?`bg-minimax-mint text-neutral-950`:`text-minimax-mint bg-white/12`}`,children:(0,z.jsxs)(`svg`,{className:`h-4.5 w-4.5`,viewBox:`0 0 24 24`,fill:`none`,children:[(0,z.jsx)(`path`,{d:`M4 13.25v-2.5M8 16V8m4 11V5m4 10.5v-7m4 4.75v-2.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.7`}),(0,z.jsx)(`path`,{d:`M4 18.25c3.3-3.1 6.7-3.1 10 0 2 1.85 4 1.85 6 0`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.5`})]})})
  }
function Oe({modelSlug:e,initialOverview:t}){
  let[n,r]=(0,R.useState)(`idle`),[i,a]=(0,R.useState)(null),[o,s]=(0,R.useState)(!1),c=(0,R.useRef)(null),l=(0,R.useRef)(null),u=p(O({queryKey:N.modelOverview(e),queryFn:()=>U(e),initialData:t??void 0,refetchOnMount:!1,staleTime:3e5}).data),d=Ee({hasOverview:u,state:n}),f=Te(n);
  (0,R.useEffect)(()=>()=>{
    c.current?.pause(),l.current&&URL.revokeObjectURL(l.current)
    },[]);
  async function m(e){
    e.ended&&(e.currentTime=0),await e.play(),r(`playing`)
    }
  function h(){
    c.current?.pause(),c.current=null,l.current&&=(URL.revokeObjectURL(l.current),null)
    }
  async function g(){
    s(!0);
    let t=c.current;
    if(t&&!t.paused){
      t.pause(),r(`paused`);
      return
      }
    if(t){
      await m(t);
      return
      }
    r(`loading`),a(null);
    try{
      let t=await we(e),n=URL.createObjectURL(t),i=new Audio(n);
      l.current=n,c.current=i,i.addEventListener(`ended`,()=>r(`idle`)),i.addEventListener(`pause`,()=>{
        i.ended||r(`paused`)
        }),i.addEventListener(`play`,()=>r(`playing`)),i.addEventListener(`error`,()=>{
        h(),a(`Overview audio is unavailable right now.`),r(`error`)
        }),await m(i)
      }catch{
      h(),a(`Overview audio is unavailable right now.`),r(`error`)
      }
    }
  let _=u?`${f} to model overview audio`:`Overview audio becomes available after the overview is generated`;
  return(0,z.jsxs)(`div`,{className:`inline-flex max-w-full flex-col items-start gap-1.5 ${o?`basis-full`:``}`,children:[i?null:(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`button`,{type:`button`,"aria-label":_,title:_,disabled:d,onClick:()=>{
    g()
    },className:`focus-visible:ring-minimax-mint/70 inline-flex h-9 min-w-[6.25rem] items-center justify-center gap-2 rounded-full border border-neutral-950/10 bg-neutral-950 px-2.5 text-xs leading-none font-semibold text-white shadow-lg transition hover:-translate-y-0.5 hover:bg-neutral-900 hover:shadow-xl focus-visible:ring-2 focus-visible:outline-none disabled:cursor-not-allowed disabled:border-neutral-950/10 disabled:bg-neutral-950/20 disabled:text-white/75 disabled:shadow-none disabled:hover:translate-y-0`,children:[(0,z.jsx)(De,{active:n===`playing`||n===`loading`}),(0,z.jsx)(`span`,{children:f})]}),o?(0,z.jsx)(_e,{}):null]}),i?(0,z.jsx)(`span`,{role:`status`,className:`max-w-[12rem] text-xs leading-4 text-red-700`,children:i}):null]})
  }
function W(...e){
  return e.filter(Boolean).join(` `)
  }
function G({className:e}){
  return(0,z.jsx)(h,{"aria-hidden":`true`,alt:``,className:e,height:300,src:`/opencode-logo-dark.svg`,width:240})
  }
function ke({className:e}){
  return(0,z.jsx)(h,{"aria-hidden":`true`,alt:``,className:e,height:24,src:`/codex-logo-purple.svg`,width:24})
  }
function Ae({className:e}){
  return(0,z.jsx)(h,{"aria-hidden":`true`,alt:``,className:e,height:24,src:`/claude-code-logo.svg`,width:24})
  }
var je=`https://ai.sulat.com/how-to-use-glm-5-2-inside-codex-when-theres-no-responses-api-4685ec61e074`,Me=`https://ai.sulat.com/claude-code-how-to-run-any-model-gpt-5x-gemini-3-1-stealth-inside-it-e67e957e53c3`,Ne=[`anthropic`,`vercel`,`bedrock`,`vertex`];
function Pe(e){
  return e.toLowerCase().replace(/[^a-z0-9]+/g,``)
  }
function K(e,t){
  let n=[e.key,e.slug,e.name].map(Pe);
  return t.some(e=>n.some(t=>t.includes(e)))
  }
function Fe(e){
  let t=K(e,[`openai`]),n=K(e,Ne),r=[];
  return t||r.push({href:je,id:`codex`,label:`Use it on Codex`,logo:(0,z.jsx)(ke,{className:`size-4`})}),n||r.push({href:Me,id:`claude-code`,label:`Use it on Claude Code`,logo:(0,z.jsx)(Ae,{className:`size-4`})}),r
  }
function Ie({modelName:e,onOpenCode:t,provider:n}){
  let r=(0,R.useId)(),i=(0,R.useRef)(null),a=(0,R.useRef)(null),[o,s]=(0,R.useState)(!1),c=Fe(n),l=c.length>0;
  function u(){
    s(!1),t()
    }
  return(0,R.useEffect)(()=>{
    if(!o)
    return;
    function e(e){
      let t=e.target;
      t instanceof Node&&(i.current?.contains(t)||s(!1))
      }
    function t(e){
      e.key===`Escape`&&(s(!1),a.current?.focus())
      }
    return document.addEventListener(`pointerdown`,e),window.addEventListener(`keydown`,t),()=>{
      document.removeEventListener(`pointerdown`,e),window.removeEventListener(`keydown`,t)
      }
    },[o]),(0,z.jsxs)(`div`,{ref:i,className:W(`focus-within:ring-accent/30 relative inline-flex h-9 min-w-[13rem] items-stretch rounded-full border border-neutral-950/10 bg-white/85 text-xs leading-none font-semibold text-[color:var(--color-ink)] shadow-lg focus-within:ring-2`,o&&`border-[color:var(--color-line-strong)] bg-white`),children:[(0,z.jsxs)(`button`,{"aria-haspopup":`dialog`,className:W(`inline-flex flex-1 items-center justify-center gap-2 py-1.5 pr-3 pl-1.5 hover:bg-white focus-visible:outline-none`,l?`rounded-l-full`:`rounded-full`),title:`Use ${e} on OpenCode`,type:`button`,onClick:u,children:[(0,z.jsx)(`span`,{className:`grid size-7 shrink-0 place-items-center rounded-full bg-neutral-950`,children:(0,z.jsx)(G,{className:`size-4`})}),(0,z.jsx)(`span`,{children:`Use it on OpenCode`})]}),l?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsxs)(`button`,{ref:a,"aria-controls":o?r:void 0,"aria-expanded":o,"aria-haspopup":`menu`,"aria-label":`Show coding tool options`,className:`relative inline-flex w-9 shrink-0 items-center justify-center rounded-r-full border-l border-neutral-950/10 text-[color:var(--color-muted)] hover:bg-white hover:text-[color:var(--color-ink)] focus-visible:outline-none`,title:`Show coding tool options`,type:`button`,onClick:()=>s(e=>!e),children:[(0,z.jsx)(`span`,{"aria-hidden":`true`,className:`absolute top-1/2 left-1/2 size-[max(100%,3rem)] -translate-x-1/2 -translate-y-1/2 pointer-fine:hidden`}),(0,z.jsx)(`span`,{"aria-hidden":`true`,className:W(`h-0 w-0 border-x-[4px] border-t-[5px] border-x-transparent border-t-current transition-transform duration-200`,o&&`rotate-180`)})]}),o?(0,z.jsx)(`div`,{id:r,"aria-label":`Coding tool options`,className:`absolute top-full right-0 z-50 mt-2 grid w-[min(15rem,calc(100vw-2rem))] gap-1 rounded-[1rem] border border-[color:var(--color-line)] bg-white/95 p-2 shadow-2xl dark:shadow-none`,role:`menu`,children:c.map(e=>(0,z.jsxs)(`a`,{className:`focus-visible:ring-accent/30 flex min-h-10 items-center gap-2 rounded-[0.75rem] px-2.5 py-1.5 text-sm leading-5 font-semibold text-[color:var(--color-ink)] hover:bg-neutral-950/[0.04] focus-visible:ring-2 focus-visible:outline-none`,href:e.href,rel:`noreferrer`,role:`menuitem`,target:`_blank`,onClick:()=>s(!1),children:[(0,z.jsx)(`span`,{className:`grid size-7 shrink-0 place-items-center rounded-full bg-neutral-950`,children:e.logo}),(0,z.jsx)(`span`,{children:e.label})]},e.id))}):null]}):null]})
  }
function Le(...e){
  return e.filter(Boolean).join(` `)
  }
function Re({className:e}){
  return(0,z.jsx)(h,{alt:`OpenCode`,className:e,height:115,src:`/opencode-wordmark-dark.svg`,width:641})
  }
function q({children:e,title:t=`OpenCode`}){
  return(0,z.jsxs)(`div`,{className:`overflow-hidden rounded-[1.35rem] border border-white/10 bg-neutral-950 shadow-2xl`,children:[(0,z.jsxs)(`div`,{className:`grid grid-cols-[1fr_auto_1fr] items-center border-b border-white/10 bg-neutral-800 px-3 py-2.5`,children:[(0,z.jsxs)(`div`,{className:`flex gap-1.5`,children:[(0,z.jsx)(`span`,{className:`size-2.5 rounded-full bg-red-400`}),(0,z.jsx)(`span`,{className:`size-2.5 rounded-full bg-yellow-400`}),(0,z.jsx)(`span`,{className:`size-2.5 rounded-full bg-green-500`})]}),(0,z.jsxs)(`div`,{className:`flex items-center gap-1.5 text-[0.75rem] leading-5 font-bold text-white/70`,children:[(0,z.jsx)(G,{className:`size-4`}),(0,z.jsx)(`span`,{children:t})]}),(0,z.jsx)(`div`,{})]}),(0,z.jsx)(`div`,{className:`min-h-[18rem] p-4 text-base/7 text-white sm:p-6 sm:text-sm/6`,children:e})]})
  }
function ze({modelName:e,providerName:t}){
  return(0,z.jsx)(`div`,{className:`border-l-2 border-blue-400 bg-white/10 p-3`,children:(0,z.jsxs)(`p`,{className:`font-mono text-base/7 text-white/95 sm:text-sm/6`,children:[(0,z.jsx)(`span`,{className:`text-blue-400`,children:`Build`}),(0,z.jsx)(`span`,{className:`px-2 text-white/35`,children:`.`}),(0,z.jsx)(`span`,{className:`break-words`,children:e}),(0,z.jsx)(`span`,{className:`pl-2 break-words text-white/40`,children:t})]})})
  }
function J(){
  return(0,z.jsxs)(`p`,{className:`text-right font-mono text-base/7 text-white sm:text-sm/6`,children:[(0,z.jsx)(`span`,{children:`tab`}),(0,z.jsx)(`span`,{className:`px-3 text-white/40`,children:`agents`}),(0,z.jsx)(`span`,{children:`ctrl+p`}),(0,z.jsx)(`span`,{className:`pl-3 text-white/40`,children:`commands`})]})
  }
function Y(){
  return(0,z.jsx)(`span`,{className:`ml-0.5 inline-flex h-5 w-2 translate-y-0.5 bg-orange-300`})
  }
function Be({step:e,modelName:t,providerName:n}){
  return e===0?(0,z.jsx)(q,{children:(0,z.jsxs)(`div`,{className:`flex min-h-[18rem] flex-col justify-center gap-8`,children:[(0,z.jsx)(`div`,{className:`flex justify-center`,children:(0,z.jsx)(Re,{className:`h-auto w-[min(20rem,80%)]`})}),(0,z.jsxs)(`div`,{className:`mx-auto grid w-full max-w-3xl gap-3`,children:[(0,z.jsx)(`div`,{className:`border-l-2 border-blue-400 bg-white/10 p-4 font-mono text-base/7 text-white/55 sm:text-sm/6`,children:`Ask anything... "Fix a TODO in the codebase"`}),(0,z.jsx)(J,{})]})]})}):e===1?(0,z.jsx)(q,{children:(0,z.jsxs)(`div`,{className:`flex min-h-[18rem] flex-col justify-center gap-4`,children:[(0,z.jsxs)(`div`,{className:`relative mx-auto w-full max-w-3xl`,children:[(0,z.jsx)(`div`,{className:`opacity-30`,children:(0,z.jsx)(ze,{modelName:t,providerName:n})}),(0,z.jsxs)(`div`,{className:`absolute top-1/2 left-1/2 w-full max-w-xl -translate-x-1/2 -translate-y-1/2 bg-neutral-900 p-4 font-mono text-base/7 sm:text-sm/6`,children:[(0,z.jsxs)(`div`,{className:`flex justify-between gap-4`,children:[(0,z.jsx)(`p`,{className:`font-bold text-white`,children:`Commands`}),(0,z.jsx)(`p`,{className:`text-white/45`,children:`esc`})]}),(0,z.jsxs)(`p`,{className:`mt-6 text-white/55`,children:[`provi`,(0,z.jsx)(Y,{})]}),(0,z.jsx)(`p`,{className:`mt-7 font-bold text-violet-400`,children:`Provider`}),(0,z.jsx)(`div`,{className:`mt-1 bg-orange-300 px-3 py-1.5 font-bold text-black`,children:`Connect provider`})]})]}),(0,z.jsx)(J,{})]})}):e===2?(0,z.jsx)(q,{children:(0,z.jsx)(`div`,{className:`flex min-h-[18rem] items-center justify-center`,children:(0,z.jsxs)(`div`,{className:`w-full max-w-xl bg-neutral-900 p-4 font-mono text-base/7 sm:text-sm/6`,children:[(0,z.jsxs)(`div`,{className:`flex justify-between gap-4`,children:[(0,z.jsx)(`p`,{className:`font-bold text-white`,children:`Connect a provider`}),(0,z.jsx)(`p`,{className:`text-white/45`,children:`esc`})]}),(0,z.jsxs)(`p`,{className:`mt-6 text-white/55`,children:[n.slice(0,3).toLowerCase(),(0,z.jsx)(Y,{})]}),(0,z.jsx)(`p`,{className:`mt-7 font-bold text-violet-400`,children:`Providers`}),(0,z.jsxs)(l.div,{className:`mt-1 flex min-w-0 items-center gap-2 bg-orange-300 px-3 py-1.5 font-bold text-black`,initial:{opacity:0,x:-18},animate:{opacity:1,x:0},transition:{duration:.3},children:[(0,z.jsx)(`span`,{className:`text-emerald-400`,children:`✓`}),(0,z.jsx)(`span`,{children:n})]})]})})}):e===3?(0,z.jsx)(q,{children:(0,z.jsx)(`div`,{className:`flex min-h-[18rem] items-center justify-center`,children:(0,z.jsxs)(`div`,{className:`w-full max-w-xl bg-neutral-900 p-4 font-mono text-base/7 sm:text-sm/6`,children:[(0,z.jsxs)(`div`,{className:`flex justify-between gap-4`,children:[(0,z.jsx)(`p`,{className:`font-bold text-white`,children:`API key`}),(0,z.jsx)(`p`,{className:`text-white/45`,children:`esc`})]}),(0,z.jsxs)(`p`,{className:`mt-6 text-white/55`,children:[`sk-****************`,(0,z.jsx)(Y,{})]}),(0,z.jsxs)(`p`,{className:`mt-12`,children:[(0,z.jsx)(`span`,{className:`font-bold text-white`,children:`enter`}),(0,z.jsx)(`span`,{className:`pl-2 text-white/45`,children:`submit`})]})]})})}):e===4?(0,z.jsx)(q,{children:(0,z.jsx)(`div`,{className:`flex min-h-[18rem] items-center justify-center`,children:(0,z.jsxs)(`div`,{className:`w-full max-w-2xl bg-neutral-900 p-4 font-mono text-base/7 sm:text-sm/6`,children:[(0,z.jsxs)(`div`,{className:`flex justify-between gap-4`,children:[(0,z.jsx)(`p`,{className:`font-bold text-white`,children:`Select model`}),(0,z.jsx)(`p`,{className:`text-white/45`,children:`esc`})]}),(0,z.jsxs)(`p`,{className:`mt-6 text-white/55`,children:[`Search`,(0,z.jsx)(Y,{})]}),(0,z.jsx)(`p`,{className:`mt-7 font-bold text-violet-400`,children:`Recent`}),(0,z.jsxs)(l.div,{className:`mt-1 flex items-center gap-2 bg-orange-300 px-3 py-1.5 font-bold text-black`,initial:{opacity:0,x:-18},animate:{opacity:1,x:0},transition:{duration:.3},children:[(0,z.jsx)(`span`,{children:`*`}),(0,z.jsx)(`span`,{className:`min-w-0 truncate`,children:t}),(0,z.jsx)(`span`,{className:`shrink-0 text-black/55`,children:n})]}),(0,z.jsx)(`div`,{className:`mt-1 grid gap-1 text-white/90`,children:[`GLM-5V-Turbo`,`DeepSeek V4 Flash`,`GPT-5.5 Fast`].map(e=>(0,z.jsxs)(`p`,{children:[e,` `,(0,z.jsx)(`span`,{className:`text-white/40`,children:`Coding Plan`})]},e))}),(0,z.jsxs)(`p`,{className:`mt-8`,children:[(0,z.jsx)(`span`,{className:`font-bold text-white`,children:`Connect provider`}),(0,z.jsx)(`span`,{className:`px-2 text-white/45`,children:`ctrl+a`}),(0,z.jsx)(`span`,{className:`font-bold text-white`,children:`Favorite`}),(0,z.jsx)(`span`,{className:`pl-2 text-white/45`,children:`ctrl+f`})]})]})})}):(0,z.jsx)(q,{title:`OC | Greeting`,children:(0,z.jsxs)(`div`,{className:`flex min-h-[18rem] flex-col gap-6 font-mono`,children:[(0,z.jsx)(`div`,{className:`border-l-2 border-blue-400 bg-white/10 p-3 text-white`,children:`hello`}),(0,z.jsxs)(`p`,{className:`border-l border-white/10 pl-4 text-white/55`,children:[(0,z.jsx)(`span`,{className:`text-amber-300 italic`,children:`Thinking:`}),` The user just said hello. This is a simple greeting, so respond directly.`]}),(0,z.jsx)(`p`,{className:`text-white`,children:`Hello! How can I help you today?`}),(0,z.jsxs)(`p`,{children:[(0,z.jsx)(`span`,{className:`text-blue-400`,children:`[]`}),(0,z.jsx)(`span`,{className:`px-3 text-white`,children:`Build`}),(0,z.jsx)(`span`,{className:`text-white/35`,children:`.`}),(0,z.jsx)(`span`,{className:`px-3 text-white/70`,children:t}),(0,z.jsx)(`span`,{className:`text-white/40`,children:n})]})]})})
  }
var Ve=[`Launch OpenCode`,`Press ctrl+p`,`Choose provider`,`Add API key`,`Select model`,`Start prompting`];
function He({modelName:e,provider:t,providerName:n}){
  let r=(0,R.useId)(),i=(0,R.useId)(),a=(0,R.useId)(),o=j(e=>e.activeModalId),s=j(e=>e.openModal),c=j(e=>e.closeModal),[u,d]=(0,R.useState)(0),f=o===a;
  function p(){
    c(a)
    }
  function m(){
    d(0),s(a)
    }
  return(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(Ie,{modelName:e,provider:t,onOpenCode:m}),f?(0,z.jsx)(me,{ariaDescribedBy:i,ariaLabelledBy:r,className:`items-center justify-center`,onClose:p,panelClassName:`surface-panel mx-auto max-w-5xl rounded-[1.8rem] p-4 sm:p-5`,children:(0,z.jsxs)(l.div,{initial:{opacity:0,scale:.98,y:16},animate:{opacity:1,scale:1,y:0},transition:{duration:.22},className:`grid gap-4`,children:[(0,z.jsx)(S,{description:`Connect ${n}, select ${e}, then start a prompt in OpenCode.`,descriptionId:i,eyebrow:`OpenCode setup`,onClose:p,title:(0,z.jsxs)(z.Fragment,{children:[`Use `,e,` on OpenCode`]}),titleId:r}),(0,z.jsxs)(`div`,{className:`grid gap-4 lg:grid-cols-[13rem_1fr]`,children:[(0,z.jsx)(`ol`,{className:`grid gap-2 self-start`,children:Ve.map((e,t)=>(0,z.jsx)(`li`,{children:(0,z.jsxs)(`button`,{"aria-label":e,className:Le(`flex w-full items-center gap-2 rounded-full px-3 py-2 text-left text-base/6 font-semibold sm:text-sm/5`,t===u?`bg-neutral-950 text-white`:`bg-white/70 text-[color:var(--color-muted)] hover:bg-white`),type:`button`,onClick:()=>d(t),children:[(0,z.jsx)(`span`,{className:`tabular-nums`,children:t+1}),(0,z.jsx)(`span`,{children:e})]})},e))}),(0,z.jsx)(`div`,{className:`min-w-0`,children:(0,z.jsx)(l.div,{initial:{opacity:0,x:18},animate:{opacity:1,x:0},transition:{duration:.24},children:(0,z.jsx)(Be,{step:u,modelName:e,providerName:n})},u)})]})]})}):null]})
  }
function Ue(e){
  return(0,z.jsx)(a,{children:(0,z.jsx)(He,{...e})})
  }
function We({model:e,overview:t}){
  return(0,z.jsxs)(`div`,{className:`flex flex-wrap items-start gap-2`,children:[(0,z.jsx)(Oe,{modelSlug:e.slug,initialOverview:t}),(0,z.jsx)(Ue,{modelName:e.name,provider:e.provider,providerName:e.provider.name})]})
  }
function Ge({overview:e}){
  return(0,z.jsx)(`div`,{className:`max-w-3xl space-y-3 text-base leading-7 text-[color:var(--color-muted)]`,children:e.paragraphs.map((t,n)=>(0,z.jsx)(`p`,{children:t},`${e.id??e.modelSlug}-${n}`))})
  }
function Ke(e){
  let t=e?.refresh;
  return t&&D(t)?t.id:null
  }
function qe({overview:e,overviewIsFetching:t,overviewIsPending:n,refresh:r}){
  return n||t&&!e||_(e)||D(r)
  }
function Je(e,t){
  return e instanceof B?e.message:t?.errorMessage??t?.refresh?.errorMessage??null
  }
function Ye(e,t){
  return v(e?.refresh)||v(t)
  }
function Xe({modelSlug:e,initialOverview:t}){
  let n=b(),r=O({queryKey:N.modelOverview(e),queryFn:()=>U(e),initialData:t??void 0,refetchOnMount:`always`,refetchInterval:e=>{
    let t=e.state.data;
    return!t||p(t)?!1:_(t)?3e3:3e4
    }}),i=r.data,a=Ke(i),o=O({queryKey:N.modelOverviewRefresh(a??`__inactive__`),queryFn:()=>Se(a),enabled:a!==null,refetchInterval:e=>{
    let t=e.state.data;
    return!t||!D(t)?!1:3e3
    }});
  if((0,R.useEffect)(()=>{
    let t=o.data;
    !t||D(t)||n.invalidateQueries({queryKey:N.modelOverview(e)})
    },[e,n,o.data]),i&&p(i))
  return(0,z.jsx)(Ge,{overview:i});
  if(qe({overview:i,overviewIsFetching:r.isFetching,overviewIsPending:r.isPending,refresh:o.data}))
  return(0,z.jsx)(oe,{});
  let s=Je(r.error,i),c=Ye(i,o.data);
  return(0,z.jsx)(`p`,{className:`max-w-3xl text-base leading-7 text-[color:var(--color-muted)]`,children:s||c?`We couldn't load the overview just now. Please try again in a little while.`:`We haven't written an overview of this model yet. New models can take a few days to gather enough reliable coverage, so check back soon.`})
  }
function Ze({overview:e}){
  return(0,z.jsx)(`div`,{className:`max-w-3xl space-y-3 text-base leading-7 text-[color:var(--color-muted)]`,children:e.paragraphs.map((t,n)=>(0,z.jsx)(`p`,{children:t},`${e.id??e.modelSlug}-${n}`))})
  }
function Qe({modelSlug:e,initialOverview:t,archived:n=!1}){
  return t&&p(t)?(0,z.jsx)(Ze,{overview:t}):n?(0,z.jsx)(`p`,{children:`No overview was recorded for this archived listing.`}):(0,z.jsx)(Xe,{modelSlug:e,initialOverview:t})
  }
var $e={firecrawl:`Firecrawl`,"firecrawl-search":`Firecrawl`,minimax:`MiniMax`,"minimax-search":`MiniMax`,"web-search":`Web search`};
function et({label:e=`Search by`,providers:t}){
  let n=tt(t);
  return(0,z.jsxs)(`a`,{href:`https://promos.reading.sh/firecrawl`,target:`_blank`,rel:`noreferrer sponsored`,"aria-label":`${e} ${n}.`,className:`section-promo-badge section-promo-badge-firecrawl border-firecrawl/25 to-firecrawl-soft mx-auto inline-flex max-w-full flex-wrap items-center justify-center gap-3 rounded-full border bg-linear-to-b from-white px-4 py-3 text-center shadow-sm dark:shadow-none`,children:[(0,z.jsx)(`span`,{className:`text-[0.62rem] leading-none font-semibold tracking-[0.22em] text-[color:var(--color-muted)] uppercase`,children:e}),(0,z.jsx)(`span`,{className:`font-serif text-[1.4rem] leading-none font-semibold text-[color:var(--color-ink)]`,children:n})]})
  }
function tt(e){
  let t=e.map(e=>e?.trim().toLowerCase()).filter(e=>!!e).map(e=>$e[e]??nt(e)),n=Array.from(new Set(t));
  return n.length>0?n.join(` + `):`Web search`
  }
function nt(e){
  return e.split(/[-_\s]+/u).filter(Boolean).map(e=>e.charAt(0).toUpperCase()+e.slice(1)).join(` `)
  }
function rt(e,t=220){
  if(e.length<=t)
  return e;
  let n=e.slice(0,t-1).trimEnd(),r=n.lastIndexOf(` `);
  return`${r>0?n.slice(0,r):n}…`
  }
function X({direction:e,onClick:t}){
  return(0,z.jsx)(`button`,{"aria-label":e===`left`?`Scroll YouTube videos left`:`Scroll YouTube videos right`,className:`button-quiet h-11 w-11 justify-center rounded-full`,onClick:t,type:`button`,children:(0,z.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,fill:`none`,viewBox:`0 0 16 16`,children:(0,z.jsx)(`path`,{d:e===`left`?`M10.75 3.5 6.25 8l4.5 4.5`:`M5.25 3.5 9.75 8l-4.5 4.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.4`})})})
  }
function it(){
  return(0,z.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,fill:`none`,viewBox:`0 0 16 16`,children:[(0,z.jsx)(`rect`,{height:`9.5`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.3`,width:`12`,x:`2`,y:`3.25`}),(0,z.jsx)(`path`,{d:`m7 6 3 2-3 2V6Z`,fill:`currentColor`})]})
  }
function at(){
  return(0,z.jsx)(`svg`,{"aria-hidden":`true`,className:`h-5 w-5`,fill:`none`,viewBox:`0 0 16 16`,children:(0,z.jsx)(`path`,{d:`M5.75 3.75v8.5L12 8 5.75 3.75Z`,fill:`currentColor`})})
  }
function ot(e){
  try{
    let t=new URL(e);
    return t.searchParams.set(`autoplay`,`1`),t.searchParams.set(`controls`,`0`),t.searchParams.set(`disablekb`,`1`),t.searchParams.set(`iv_load_policy`,`3`),t.searchParams.set(`modestbranding`,`1`),t.searchParams.set(`playsinline`,`1`),t.searchParams.set(`rel`,`0`),t.toString()
    }catch{
    return e
    }
  }
var st=`group flex min-w-[20rem] max-w-[25rem] shrink-0 snap-start flex-col overflow-hidden rounded-[1.7rem] border bg-white/70 transition duration-300 motion-reduce:transition-none hover:-translate-y-px motion-reduce:hover:translate-y-0 hover:border-[color:var(--color-line-strong)] hover:bg-white/90 focus-within:border-[color:var(--color-line-strong)] sm:min-w-[23rem]`,ct=`border-[color:var(--color-line-strong)] bg-white/90`,lt=`border-[color:var(--color-line)]`,Z=`h-full w-full object-cover transition duration-500 motion-reduce:transition-none`,ut=`scale-[1.02] opacity-0`,dt=`scale-[1.02] opacity-90 saturate-[0.86] contrast-[0.96]`,ft=`scale-100 opacity-55 grayscale-[0.18] saturate-[0.58] contrast-[0.9] group-hover:scale-[1.02] group-hover:opacity-90 group-hover:saturate-[0.86] group-hover:contrast-[0.96] group-focus-within:scale-[1.02] group-focus-within:opacity-90 group-focus-within:saturate-[0.86] group-focus-within:contrast-[0.96]`,Q=`pointer-events-none absolute inset-0 bg-linear-to-br from-neutral-950/50 via-accent-deep/15 to-white/60 transition-opacity duration-500 motion-reduce:transition-none`,pt=`opacity-100 group-hover:opacity-20 group-focus-within:opacity-20`,mt=`pointer-events-none absolute inset-y-0 -left-1/2 w-1/2 rotate-[18deg] bg-linear-to-r from-white/0 via-white/30 to-white/0 transition duration-700 motion-reduce:transition-none`,ht=`translate-x-0 opacity-65 group-hover:translate-x-[260%] group-hover:opacity-0 group-focus-within:translate-x-[260%] group-focus-within:opacity-0`,gt=`absolute left-1/2 top-1/2 inline-flex h-14 w-14 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border border-white/50 bg-neutral-950/60 pl-0.5 text-white/95 shadow-xl backdrop-blur-md transition duration-300 motion-reduce:transition-none hover:bg-neutral-950/70 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/30`,_t=`pointer-events-none scale-95 opacity-0 group-hover:pointer-events-auto group-hover:scale-100 group-hover:opacity-100 group-focus-within:pointer-events-auto group-focus-within:scale-100 group-focus-within:opacity-100`;
function vt({isTouchActive:e}){
  return`${st} ${e?ct:lt}`
  }
function yt({isPlaying:e,isRevealed:t}){
  return e?`${Z} ${ut}`:t?`${Z} ${dt}`:`${Z} ${ft}`
  }
function bt({isPlaying:e,isRevealed:t}){
  return e?`${Q} opacity-0`:t?`${Q} opacity-20`:`${Q} ${pt}`
  }
function xt({isPlaying:e,isRevealed:t}){
  return t||e?`${mt} translate-x-[260%] opacity-0`:`${mt} ${ht}`
  }
function St({isRevealed:e}){
  return`${gt} ${e?`pointer-events-auto scale-100 opacity-100`:_t}`
  }
function Ct(){
  let[e,t]=(0,R.useState)(!1);
  return(0,R.useEffect)(()=>{
    let e=window.matchMedia(`(hover: none), (pointer: coarse)`),n=()=>t(e.matches);
    return n(),e.addEventListener(`change`,n),()=>e.removeEventListener(`change`,n)
    },[]),e
  }
function wt({videos:e}){
  let t=(0,R.useRef)(null),[n,r]=(0,R.useState)(e[0]?.id??null),[i,a]=(0,R.useState)(null),[o,s]=(0,R.useState)(null),c=Ct(),l=L(),u=e.length>1,d=(0,R.useCallback)(()=>{
    let e=t.current;
    if(!e)
    return;
    let n=e.getBoundingClientRect(),i=n.left+n.width/2,a=e.querySelectorAll(`[data-youtube-video-id]`),o=null,s=1/0;
    for(
    let e
     of a){
      let t=e.getBoundingClientRect(),n=t.left+t.width/2,r=Math.abs(n-i);
      r<s&&(s=r,o=e.dataset.youtubeVideoId??null)
      }
    o&&r(o)
    },[]);
  (0,R.useEffect)(()=>{
    let e=t.current;
    if(!e)
    return;
    let n=0,r=()=>{
      window.cancelAnimationFrame(n),n=window.requestAnimationFrame(d)
      };
    return e.addEventListener(`scroll`,r,{passive:!0}),window.addEventListener(`resize`,r),r(),()=>{
      window.cancelAnimationFrame(n),e.removeEventListener(`scroll`,r),window.removeEventListener(`resize`,r)
      }
    },[d]);
  let f=e=>{
    let n=t.current;
    if(!n)
    return;
    let r=n.clientWidth*.9;
    n.scrollBy({behavior:l?`auto`:`smooth`,left:e===`left`?-r:r})
    },p=e.some(e=>e.id===n)?n:e[0]?.id??null;
  return(0,z.jsxs)(`div`,{className:`grid gap-4`,children:[u?(0,z.jsxs)(`div`,{className:`hidden items-center justify-end gap-2 lg:flex`,children:[(0,z.jsx)(X,{direction:`left`,onClick:()=>f(`left`)}),(0,z.jsx)(X,{direction:`right`,onClick:()=>f(`right`)})]}):null,(0,z.jsx)(`div`,{ref:t,className:`flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 [scrollbar-width:none] motion-reduce:snap-none motion-reduce:scroll-auto [&::-webkit-scrollbar]:hidden`,children:e.map(e=>{
    let t=c&&p===e.id,n=l||i===e.id||t,r=o===e.id,u={isPlaying:r,isRevealed:n,isTouchActive:t};
    return(0,z.jsxs)(`article`,{className:vt(u),"data-youtube-video-id":e.id,onBlur:t=>{
      let n=t.relatedTarget;
      (!(n instanceof Node)||!t.currentTarget.contains(n))&&a(t=>t===e.id?null:t)
      },onFocus:()=>a(e.id),onMouseEnter:()=>a(e.id),onMouseLeave:()=>{
      a(t=>t===e.id?null:t)
      },onPointerEnter:()=>a(e.id),onPointerLeave:()=>{
      a(t=>t===e.id?null:t)
      },children:[(0,z.jsxs)(`div`,{className:`relative aspect-video w-full overflow-hidden bg-linear-to-br from-neutral-950/20 to-white/80`,children:[e.thumbnailUrl?(0,z.jsx)(`img`,{alt:``,className:yt(u),loading:`lazy`,src:e.thumbnailUrl}):(0,z.jsx)(`div`,{className:`h-full w-full bg-linear-to-br from-neutral-950/20 to-white/60`}),(0,z.jsx)(`div`,{"aria-hidden":`true`,className:bt(u)}),(0,z.jsx)(`div`,{"aria-hidden":`true`,className:xt(u)}),(0,z.jsx)(`div`,{"aria-hidden":`true`,className:`pointer-events-none absolute inset-0 shadow-inner`}),r?null:(0,z.jsx)(`button`,{"aria-label":`Play ${e.title}`,className:St(u),onClick:()=>s(e.id),type:`button`,children:(0,z.jsx)(at,{})}),r?(0,z.jsx)(`iframe`,{allow:`accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share`,allowFullScreen:!0,className:`absolute inset-0 h-full w-full`,loading:`lazy`,referrerPolicy:`strict-origin-when-cross-origin`,src:ot(e.embedUrl),title:e.title}):null]}),(0,z.jsxs)(`div`,{className:`flex flex-1 flex-col p-4`,children:[(0,z.jsx)(`a`,{className:`font-serif text-[1.35rem] leading-tight tracking-[-0.04em] text-[color:var(--color-ink)] transition hover:text-[color:var(--color-accent-deep)]`,href:e.url,rel:`noreferrer`,target:`_blank`,children:e.title}),e.description?(0,z.jsx)(`p`,{className:`mt-3 text-sm leading-7 text-[color:var(--color-muted)]`,children:rt(e.description)}):null,(0,z.jsx)(`div`,{className:`mt-auto flex justify-end pt-5`,children:(0,z.jsx)(`a`,{"aria-label":`Watch ${e.title} on YouTube`,className:`inline-flex h-10 w-10 items-center justify-center rounded-full border border-[color:var(--color-line)] bg-white/85 text-[color:var(--color-accent-deep)] transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,href:e.url,rel:`noreferrer`,target:`_blank`,children:(0,z.jsx)(it,{})})})]})]},e.id)
    })})]})
  }
function Tt(e){
  return P(e)&&typeof e.id==`string`&&typeof e.videoId==`string`&&typeof e.title==`string`&&k(e.description)&&k(e.thumbnailUrl)&&typeof e.url==`string`&&typeof e.embedUrl==`string`
  }
function Et(e){
  return!P(e)||typeof e.adapter!=`string`||typeof e.query!=`string`||!Array.isArray(e.videos)||!e.videos.every(Tt)||e.searchProviders!==void 0&&(!Array.isArray(e.searchProviders)||!e.searchProviders.every(e=>typeof e==`string`))?null:{adapter:e.adapter,query:e.query,searchProviders:e.searchProviders,videos:e.videos}
  }
async function Dt(e){
  let t=await fetch(`/_catalog/models/${encodeURIComponent(e)}/youtube-videos`,{headers:{accept:`application/json`}});
  if(!t.ok)
  throw Error(`YouTube video feed request failed.`);
  return Et(await T(t))
  }
var Ot=4320*60*1e3,kt=[`youtube-skeleton-1`,`youtube-skeleton-2`,`youtube-skeleton-3`];
function At({badge:e,children:t,modelName:n}){
  return(0,z.jsxs)(`section`,{className:`surface-panel mt-16 grid gap-5 rounded-[2rem] p-6 sm:p-7`,children:[(0,z.jsx)(`div`,{className:`-mt-14 mb-1 flex justify-center`,children:e}),(0,z.jsx)(E,{title:`Videos about ${n}`}),t]})
  }
function jt(){
  return(0,z.jsx)(`div`,{"aria-hidden":`true`,className:`h-[3.35rem] w-48 animate-pulse rounded-full border border-teal-700/15 bg-linear-to-b from-teal-50/80 to-emerald-50/70 shadow-sm`})
  }
function Mt(){
  return(0,z.jsx)(`div`,{"aria-hidden":`true`,className:`flex gap-4 overflow-x-hidden pb-2`,children:kt.map(e=>(0,z.jsxs)(`div`,{className:`max-w-[25rem] min-w-[20rem] shrink-0 overflow-hidden rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70 sm:min-w-[23rem]`,children:[(0,z.jsxs)(`div`,{className:`relative aspect-video w-full overflow-hidden bg-linear-to-br from-neutral-950/15 to-white/70`,children:[(0,z.jsx)(`div`,{className:`absolute inset-0 animate-pulse bg-neutral-950/10`}),(0,z.jsx)(`div`,{className:`absolute inset-y-0 -left-1/2 w-1/2 rotate-[18deg] bg-linear-to-r from-white/0 via-white/30 to-white/0`}),(0,z.jsx)(`div`,{className:`absolute bottom-4 left-4 h-10 w-10 animate-pulse rounded-full bg-neutral-950/15`})]}),(0,z.jsxs)(`div`,{className:`space-y-3 p-4`,children:[(0,z.jsx)(`div`,{className:`h-6 w-4/5 animate-pulse rounded-full bg-neutral-950/10`}),(0,z.jsx)(`div`,{className:`h-4 w-full animate-pulse rounded-full bg-neutral-500/15`}),(0,z.jsx)(`div`,{className:`h-4 w-11/12 animate-pulse rounded-full bg-neutral-500/15`}),(0,z.jsx)(`div`,{className:`h-4 w-2/3 animate-pulse rounded-full bg-neutral-500/15`}),(0,z.jsx)(`div`,{className:`flex justify-end pt-2`,children:(0,z.jsx)(`div`,{className:`bg-accent/15 h-10 w-10 animate-pulse rounded-full`})})]})]},e))})
  }
function Nt({modelName:e,modelSlug:t}){
  let n=O({queryKey:N.modelYouTubeVideos(t),queryFn:()=>Dt(t),refetchOnMount:!1,staleTime:Ot}),r=n.data;
  return r?.videos.length?(0,z.jsx)(At,{badge:(0,z.jsx)(et,{label:`Video search by`,providers:r.searchProviders?.length?r.searchProviders:[r.adapter]}),modelName:e,children:(0,z.jsx)(wt,{videos:r.videos})}):!n.isPending&&!n.isFetching?null:(0,z.jsx)(At,{badge:(0,z.jsx)(jt,{}),modelName:e,children:(0,z.jsx)(Mt,{})})
  }
function Pt({modelKey:e}){
  let t=e?.trim();
  return(0,z.jsxs)(`a`,{href:t?`https://models.dev/?${new URLSearchParams({search:t}).toString()}`:`https://models.dev/`,target:`_blank`,rel:`noreferrer`,"aria-label":`Powered by Models.dev.`,className:`inline-flex max-w-full items-center gap-1.5 rounded-full border border-neutral-950/10 bg-white/70 px-2 py-1 align-middle shadow-sm transition hover:-translate-y-0.5 hover:border-neutral-950/20 hover:shadow-md dark:border-white/10 dark:shadow-none dark:hover:shadow-none`,children:[(0,z.jsx)(`span`,{className:`text-[0.48rem] leading-none font-semibold tracking-[0.14em] text-[color:var(--color-muted)] uppercase`,children:`Powered by`}),(0,z.jsx)(h,{src:`/models-dev-wordmark.svg`,alt:``,width:318,height:38,"aria-hidden":`true`,className:`h-2 w-auto dark:hidden`}),(0,z.jsx)(h,{src:`/models-dev-wordmark-dark.svg`,alt:``,width:318,height:38,"aria-hidden":`true`,className:`hidden h-2 w-auto dark:block`})]})
  }
function Ft({direction:e,onClick:t}){
  return(0,z.jsx)(`button`,{type:`button`,onClick:t,className:`button-quiet h-11 w-11 justify-center rounded-full`,"aria-label":e===`left`?`Scroll related models left`:`Scroll related models right`,children:(0,z.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,z.jsx)(`path`,{d:e===`left`?`M10.75 3.5 6.25 8l4.5 4.5`:`M5.25 3.5 9.75 8l-4.5 4.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.4`})})})
  }
function It({familyHref:e,currentModelName:t,otherProvidersForCurrent:n,cards:r}){
  let a=(0,R.useRef)(null),o=L(),s=r.length>1,c=e=>{
    let t=a.current;
    if(!t)
    return;
    let n=t.clientWidth*.9;
    t.scrollBy({left:e===`left`?-n:n,behavior:o?`auto`:`smooth`})
    };
  return r.length===0&&n.length===0?null:(0,z.jsxs)(`section`,{className:`surface-panel grid gap-6 rounded-[2rem] p-5 sm:p-6`,children:[(0,z.jsxs)(`div`,{className:`flex flex-wrap items-start justify-between gap-4`,children:[(0,z.jsx)(`div`,{className:`max-w-3xl`,children:(0,z.jsxs)(`h2`,{className:`font-serif text-[2rem] tracking-[-0.05em] text-[color:var(--color-ink)] sm:text-[2.5rem]`,children:[`More models around `,t]})}),(0,z.jsxs)(`div`,{className:`hidden flex-wrap items-center gap-3 lg:flex`,children:[(0,z.jsx)(i,{href:e,className:`button-quiet`,children:`Browse family`}),s?(0,z.jsxs)(`div`,{className:`flex items-center gap-2`,children:[(0,z.jsx)(Ft,{direction:`left`,onClick:()=>c(`left`)}),(0,z.jsx)(Ft,{direction:`right`,onClick:()=>c(`right`)})]}):null]})]}),n.length>0?(0,z.jsxs)(`div`,{className:`hidden rounded-[1.6rem] border border-[color:var(--color-line)] bg-white/70 p-4 lg:block`,children:[(0,z.jsx)(`div`,{className:`eyebrow`,children:`Also served by`}),(0,z.jsxs)(`p`,{className:`mt-2 text-sm leading-7 text-[color:var(--color-muted)]`,children:[`This exact model name is also listed by`,` `,(0,z.jsxs)(`span`,{className:`font-medium text-[color:var(--color-ink)]`,children:[n.length,` `,n.length===1?`other provider`:`other providers`]}),`.`]}),(0,z.jsx)(`div`,{className:`mt-3 flex flex-wrap gap-2`,children:n.map(e=>(0,z.jsx)(i,{href:e.href,className:`inline-flex items-center rounded-full border border-[color:var(--color-line)] bg-white/85 px-3 py-1.5 text-[0.76rem] font-semibold tracking-[0.14em] text-[color:var(--color-muted)] uppercase transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,children:e.name},e.slug))})]}):null,r.length>0?(0,z.jsx)(`div`,{ref:a,className:`flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 [scrollbar-width:none] motion-reduce:snap-none motion-reduce:scroll-auto [&::-webkit-scrollbar]:hidden`,children:r.map(e=>{
    let t=e.providers.slice(0,5),n=Math.max(e.providers.length-t.length,0);
    return(0,z.jsxs)(`article`,{className:`max-w-[21rem] min-w-[18rem] shrink-0 snap-start rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70 p-4 sm:min-w-[20rem]`,children:[(0,z.jsx)(`div`,{children:(0,z.jsxs)(`span`,{className:`inline-flex items-center rounded-full bg-[color:var(--color-accent-soft)] px-3 py-1 text-[0.7rem] font-semibold tracking-[0.16em] text-[color:var(--color-accent-deep)] uppercase`,children:[e.providerCount,` `,e.providerCount===1?`provider`:`providers`]})}),(0,z.jsx)(i,{href:e.href,className:`mt-4 inline-flex font-serif text-[1.7rem] leading-none tracking-[-0.05em] text-[color:var(--color-ink)] transition hover:text-[color:var(--color-accent-deep)]`,children:e.name}),(0,z.jsx)(`p`,{className:`mt-3 text-sm leading-7 text-[color:var(--color-muted)]`,children:e.providerCount===1?`Currently listed through:`:`Currently listed through these providers:`}),(0,z.jsxs)(`div`,{className:`mt-3 flex flex-wrap gap-2`,children:[t.map(e=>(0,z.jsx)(i,{href:e.href,className:`inline-flex items-center rounded-full border border-[color:var(--color-line)] bg-white/85 px-3 py-1.5 text-[0.76rem] font-semibold tracking-[0.14em] text-[color:var(--color-muted)] uppercase transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,children:e.name},e.slug)),n>0?(0,z.jsxs)(i,{href:e.providersHref,className:`inline-flex items-center rounded-full border border-dashed border-[color:var(--color-line)] px-3 py-1.5 text-[0.76rem] font-semibold tracking-[0.14em] text-[color:var(--color-muted)] uppercase transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,children:[`+`,n,` more`]}):null]})]},e.id)
    })}):null]})
  }
function $(e){
  return e.length>0?e.join(`, `):null
  }
function Lt(e){
  if(!e||Array.isArray(e)||typeof e!=`object`||!(`npm`in e))
  return null;
  let t=e.npm;
  return typeof t==`string`&&/^@ai-sdk\/[a-z0-9][a-z0-9._/-]*$/i.test(t)?t:null
  }
function Rt(e){
  return e.filter(e=>{
    let t=typeof e.filterValue==`string`?e.filterValue:typeof e.value==`string`?e.value:null;
    return t!==null&&t.trim()!==``&&!/^unknown$/i.test(t.trim())
    })
  }
function zt({model:e,provider:t,overview:r,news:a,newsRefreshes:l,pricingComparison:d,relatedModels:p,seo:h}){
  let{integrations:_,site:v}=n().props,b=pe(e),S=Lt(e.metadata.providerOverrides),C=`${v.url.replace(/\/$/,``)}${ne(e.slug)}`,w=Rt([{label:`Provider`,value:(0,z.jsx)(i,{className:`focus-visible:ring-accent/15 inline-flex max-w-full items-center rounded-full border border-[color:var(--color-line)] bg-white/80 px-3 py-1.5 text-[0.82rem] leading-none text-[color:var(--color-ink)] transition hover:-translate-y-px hover:border-[color:var(--color-line-strong)] hover:bg-white/95 focus-visible:ring-2 focus-visible:outline-none`,href:I(e.provider.slug),children:e.provider.name}),filterValue:e.provider.name,explainer:(0,z.jsx)(se,{})},{label:`Model key`,value:e.modelKey},{label:`Release date`,value:e.dates.releaseDate?x(e.dates.releaseDate):null},{label:`Last updated`,value:e.dates.lastUpdated?x(e.dates.lastUpdated):null},{label:`Knowledge cutoff`,value:e.knowledgeCutoff,explainer:(0,z.jsx)(ue,{})},{label:`AI SDK package`,value:S?(0,z.jsx)(`code`,{className:`font-mono text-xs break-all`,children:S}):null,filterValue:S,explainer:(0,z.jsx)(de,{})},{label:`Input modalities`,value:(0,z.jsx)(y,{values:e.modalities.input}),filterValue:$(e.modalities.input),explainer:(0,z.jsx)(ce,{})},{label:`Output modalities`,value:(0,z.jsx)(y,{values:e.modalities.output}),filterValue:$(e.modalities.output),explainer:(0,z.jsx)(ie,{})},{label:`Capabilities`,value:(0,z.jsx)(ee,{labels:b,emptyLabel:`Base catalog fields only`}),filterValue:$(b)??`Base catalog fields only`,explainer:(0,z.jsx)(le,{})}]);
  return(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(ge,{seo:h}),(0,z.jsxs)(`main`,{className:`mx-auto grid max-w-7xl gap-8 px-5 py-12 sm:px-8`,children:[e.archivedAt?(0,z.jsxs)(`aside`,{className:`surface-panel grid gap-2 rounded-2xl border p-5`,"aria-label":`Archived model`,children:[(0,z.jsx)(`h2`,{className:`text-lg font-semibold`,children:`No longer listed on models.dev`}),(0,z.jsxs)(`p`,{children:[`This is an archived listing, not confirmation that the provider has discontinued the model. Pricing and specifications are historical, not current offers.`,e.lastSeenAt?` Last observed on ${x(e.lastSeenAt)}.`:e.syncedAt?` Last metadata sync: ${x(e.syncedAt)}. The last upstream observation date is unknown.`:` The last upstream observation date is unknown.`]})]}):null,(0,z.jsxs)(`section`,{className:`surface-panel relative grid gap-8 overflow-hidden rounded-[2rem] p-6 pt-28 sm:pt-24 lg:grid-cols-[auto,1fr] lg:items-start lg:p-8 lg:pt-8`,children:[(0,z.jsx)(c,{deal:o(t.deal)}),(0,z.jsx)(ae,{provider:t,className:`h-28 w-28`}),(0,z.jsxs)(`div`,{className:`grid gap-6 lg:pr-[27rem]`,children:[(0,z.jsx)(E,{as:`h1`,eyebrow:`Model details`,title:e.name,action:(0,z.jsx)(We,{model:e,overview:r}),body:(0,z.jsx)(Qe,{modelSlug:e.slug,initialOverview:r,archived:!!e.archivedAt})}),(0,z.jsxs)(`div`,{className:`flex flex-wrap gap-3`,children:[(0,z.jsx)(A,{tone:`accent`,children:e.provider.name}),(0,z.jsx)(A,{tone:`muted`,children:e.modelKey}),e.family?(0,z.jsx)(A,{tone:`muted`,children:e.family}):null,e.status?(0,z.jsx)(A,{tone:`muted`,children:e.status}):null]}),(0,z.jsxs)(`div`,{className:`flex flex-wrap items-center gap-3 text-sm text-[color:var(--color-muted)]`,children:[(0,z.jsx)(g,{href:I(t.slug),icon:(0,z.jsx)(te,{}),label:`Open provider page`,tone:`provider`}),t.links.documentationUrl?(0,z.jsx)(m,{href:t.links.documentationUrl,icon:(0,z.jsx)(he,{}),label:`Provider docs`,tone:`docs`}):null,(0,z.jsx)(s,{shareTitle:`${e.name} by ${e.provider.name} via ${v.name}`,shareUrl:C})]})]})]}),(0,z.jsx)(re,{titleAccessory:(0,z.jsx)(Pt,{modelKey:e.modelKey}),title:e.archivedAt?`Historical specifications`:`Quick Info`,items:w}),(0,z.jsxs)(`div`,{className:`grid gap-5 lg:grid-cols-2`,children:[e.metadata.cost?(0,z.jsx)(F,{title:e.archivedAt?`Historical cost`:`Cost`,data:e.metadata.cost}):null,e.metadata.limits?(0,z.jsx)(F,{title:e.archivedAt?`Historical limits`:`Limits`,data:e.metadata.limits}):null,e.metadata.experimental?(0,z.jsx)(`div`,{className:`lg:col-span-2`,children:(0,z.jsx)(F,{title:`Experimental`,data:e.metadata.experimental})}):null]}),d?(0,z.jsx)(fe,{comparison:d}):null,(0,z.jsx)(u,{modelSlug:e.slug,modelName:e.name,initialNews:a,initialRefreshes:l}),(0,z.jsx)(Nt,{modelName:e.name,modelSlug:e.slug}),(0,z.jsx)(f,{enabled:_.xApiAvailable,providerName:t.name,socialLinks:t.socialLinks}),p?(0,z.jsx)(It,{familyHref:p.familyHref,currentModelName:e.name,otherProvidersForCurrent:p.otherProvidersForCurrent,cards:p.cards}):null]})]})
  }
export{zt as default};
