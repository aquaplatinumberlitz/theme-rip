const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/not-found-yyJcVEDC.js","assets/react-inertia-runtime.js","assets/seo.js","assets/home.js","assets/preload.js","assets/arrow-icon.js","assets/filter-options.js","assets/hero-format.js","assets/news-ui.js","assets/models-Jle1TdXI.js","assets/explorer-client-CEwPRwo3.js","assets/model-detail.js","assets/model-sections.js","assets/news-4C3bChlY.js","assets/providers-DbU6Pt6x.js","assets/show-D91tR7XN.js"])))=>i.map(i=>d[i]);


import{a as e,c as t,l as n,n as r,o as i,p as a,s as o,t as s}from"./react-inertia-runtime.js";
import{t as c}from"./preload.js";
async function l(e,t){
  for(
  let n
   of Array.isArray(e)?e:[e]){
    let e=t[n];
    if(e!==void 0)
    return typeof e==`function`?e():e
    }
  throw Error(`Page not found: ${e}`)
  }
var u=a(t(),1),d=r(),f=u.createContext(void 0),p=e=>{
  let t=u.useContext(f);
  if(e)
  return e;
  if(!t)
  throw Error(`No QueryClient set, use QueryClientProvider to set one`);
  return t
  },m=({client:e,children:t})=>(u.useEffect(()=>(e.mount(),()=>{
  e.unmount()
  }),[e]),(0,d.jsx)(f.Provider,{value:e,children:t})),h={setTimeout:(e,t)=>setTimeout(e,t),clearTimeout:e=>clearTimeout(e),setInterval:(e,t)=>setInterval(e,t),clearInterval:e=>clearInterval(e)},g=new class{
  #e=h;setTimeoutProvider(e){
    this.#e=e
    }setTimeout(e,t){
    return this.#e.setTimeout(e,t)
    }clearTimeout(e){
    this.#e.clearTimeout(e)
    }setInterval(e,t){
    return this.#e.setInterval(e,t)
    }clearInterval(e){
    this.#e.clearInterval(e)
    }
};
function _(e){
  setTimeout(e,0)
  }
var v=typeof window>`u`||`Deno`in globalThis;
function y(){
  }
function b(e,t){
  return typeof e==`function`?e(t):e
  }
function x(e){
  return typeof e==`number`&&e>=0&&e!==1/0
  }
function S(e,t){
  return Math.max(e+(t||0)-Date.now(),0)
  }
function C(e,t){
  return typeof e==`function`?e(t):e
  }
function w(e,t){
  let{type:n=`all`,exact:r,fetchStatus:i,predicate:a,queryKey:o,stale:s}=e;
  if(o){
    if(r){
      if(t.queryHash!==E(o,t.options))
      return!1
      }else 
    if(!O(t.queryKey,o))
    return!1
    }
  if(n!==`all`){
    let e=t.isActive();
    if(n===`active`&&!e||n===`inactive`&&e)
    return!1
    }
  return!(typeof s==`boolean`&&t.isStale()!==s||i&&i!==t.state.fetchStatus||a&&!a(t))
  }
function T(e,t){
  let{exact:n,status:r,predicate:i,mutationKey:a}=e;
  if(a){
    if(!t.options.mutationKey)
    return!1;
    if(n){
      if(D(t.options.mutationKey)!==D(a))
      return!1
      }else 
    if(!O(t.options.mutationKey,a))
    return!1
    }
  return!(r&&t.state.status!==r||i&&!i(t))
  }
function E(e,t){
  return(t?.queryKeyHashFn||D)(e)
  }
function D(e){
  return JSON.stringify(e,(e,t)=>ie(t)?Object.keys(t).sort().reduce((e,n)=>(e[n]=t[n],e),{}):t)
  }
function O(e,t){
  if(e===t)
  return!0;
  if(typeof e!=typeof t)
  return!1;
  if(e&&t&&typeof e==`object`&&typeof t==`object`){
    if(Array.isArray(e)&&Array.isArray(t)){
      for(
      let n=0
      ;n<t.length;n++)
      if(!O(e[n],t[n]))
      return!1;
      return!0
      }
    let n=Object.keys(t);
    for(
    let r
     of n)
    if(!O(e[r],t[r]))
    return!1;
    return!0
    }
  return!1
  }
var ee=Object.prototype.hasOwnProperty;
function te(e,t,n=0){
  if(e===t)
  return e;
  if(n>500)
  return t;
  let r=re(e)&&re(t);
  if(!r&&!(ie(e)&&ie(t)))
  return t;
  let i=(r?e:Object.keys(e)).length,a=r?t:Object.keys(t),o=a.length,s=r?Array(o):{},c=0;
  for(
  let l=0
  ;l<o;l++){
    let o=r?l:a[l],u=e[o],d=t[o];
    if(u===d){
      s[o]=u,(r?l<i:ee.call(e,o))&&c++;
      continue
      }
    if(u===null||d===null||typeof u!=`object`||typeof d!=`object`){
      s[o]=d;
      continue
      }
    let f=te(u,d,n+1);
    s[o]=f,f===u&&c++
    }
  return i===o&&c===i?e:s
  }
function ne(e,t){
  if(!t||Object.keys(e).length!==Object.keys(t).length)
  return!1;
  for(
  let n
   in e)
  if(e[n]!==t[n])
  return!1;
  return!0
  }
function re(e){
  return Array.isArray(e)&&e.length===Object.keys(e).length
  }
function ie(e){
  if(!ae(e))
  return!1;
  let t=e.constructor;
  if(t===void 0)
  return!0;
  let n=t.prototype;
  return!(!ae(n)||!n.hasOwnProperty(`isPrototypeOf`)||Object.getPrototypeOf(e)!==Object.prototype)
  }
function ae(e){
  return Object.prototype.toString.call(e)===`[object Object]`
  }
function oe(e){
  return new Promise(t=>{
    g.setTimeout(t,e)
    })
  }
function se(e,t,n){
  return typeof n.structuralSharing==`function`?n.structuralSharing(e,t):n.structuralSharing===!1?t:te(e,t)
  }
function ce(e){
  return e
  }
function le(e,t,n=0){
  let r=[...e,t];
  return n&&r.length>n?r.slice(1):r
  }
function ue(e,t,n=0){
  let r=[t,...e];
  return n&&r.length>n?r.slice(0,-1):r
  }
var de=Symbol();
function fe(e,t){
  return!e.queryFn&&t?.initialPromise?()=>t.initialPromise:!e.queryFn||e.queryFn===de?()=>Promise.reject(Error(`Missing queryFn: '${e.queryHash}'`)):e.queryFn
  }
function pe(e,t){
  return typeof e==`function`?e(...t):!!e
  }
function me(e,t,n){
  let r=!1,i;
  return Object.defineProperty(e,"signal",{enumerable:!0,get:()=>(i??=t(),r?i:(r=!0,i.aborted?n():i.addEventListener(`abort`,n,{once:!0}),i))}),e
  }
var he=()=>v,ge=()=>he(),k=class{
  constructor(){
    this.listeners=new Set,this.subscribe=this.subscribe.bind(this)
    }subscribe(e){
    return this.listeners.add(e),this.onSubscribe(),()=>{
      this.listeners.delete(e),this.onUnsubscribe()
      }
    }hasListeners(){
    return this.listeners.size>0
    }onSubscribe(){
    }onUnsubscribe(){
    }
},_e=new class extends k{
  #e;#t;#n;constructor(){
    super(),this.#n=e=>{
      if(typeof window<`u`&&window.addEventListener){
        let t=()=>e();
        return window.addEventListener(`visibilitychange`,t,!1),()=>{
          window.removeEventListener(`visibilitychange`,t)
          }
        }
      }
    }onSubscribe(){
    this.#t||this.setEventListener(this.#n)
    }onUnsubscribe(){
    this.hasListeners()||(this.#t?.(),this.#t=void 0)
    }setEventListener(e){
    this.#n=e,this.#t?.(),this.#t=e(e=>{
      typeof e==`boolean`?this.setFocused(e):this.onFocus()
      })
    }setFocused(e){
    this.#e!==e&&(this.#e=e,this.onFocus())
    }onFocus(){
    let e=this.isFocused();
    this.listeners.forEach(t=>{
      t(e)
      })
    }isFocused(){
    return typeof this.#e==`boolean`?this.#e:globalThis.document?.visibilityState!==`hidden`
    }
};
function ve(e){
  return e.state.status===`success`
  }
var ye=_;
function be(){
  let e=[],t=0,n=e=>{
    e()
    },r=e=>{
    e()
    },i=ye,a=r=>{
    t?e.push(r):i(()=>{
      n(r)
      })
    },o=()=>{
    let t=e;
    e=[],t.length&&i(()=>{
      r(()=>{
        t.forEach(e=>{
          n(e)
          })
        })
      })
    };
  return{batch:e=>{
    let n;
    t++;
    try{
      n=e()
      }finally{
      t--,t||o()
      }
    return n
    },batchCalls:e=>(...t)=>{
    a(()=>{
      e(...t)
      })
    },schedule:a,setNotifyFunction:e=>{
    n=e
    },setBatchNotifyFunction:e=>{
    r=e
    },setScheduler:e=>{
    i=e
    }}
  }
var A=be(),xe=new class extends k{
  #e=!0;#t;#n;constructor(){
    super(),this.#n=e=>{
      if(typeof window<`u`&&window.addEventListener){
        let t=()=>e(!0),n=()=>e(!1);
        return window.addEventListener(`online`,t,!1),window.addEventListener(`offline`,n,!1),()=>{
          window.removeEventListener(`online`,t),window.removeEventListener(`offline`,n)
          }
        }
      }
    }onSubscribe(){
    this.#t||this.setEventListener(this.#n)
    }onUnsubscribe(){
    this.hasListeners()||(this.#t?.(),this.#t=void 0)
    }setEventListener(e){
    this.#n=e,this.#t?.(),this.#t=e(this.setOnline.bind(this))
    }setOnline(e){
    this.#e!==e&&(this.#e=e,this.listeners.forEach(t=>{
      t(e)
      }))
    }isOnline(){
    return this.#e
    }
};
function Se(e){
  return Math.min(1e3*2**e,3e4)
  }
function Ce(e){
  return(e??`online`)!==`online`||xe.isOnline()
  }
var we=class extends Error{
  constructor(e){
    super(`CancelledError`),this.revert=e?.revert,this.silent=e?.silent
    }
};
function Te(e){
  let t=!1,n=0,r,i=`pending`,a,o,s=new Promise((e,t)=>{
    a=e,o=t
    });
  s.catch(y);
  let c=()=>i!==`pending`,l=t=>{
    if(!c()){
      let n=new we(t);
      h(n),e.onCancel?.(n)
      }
    },u=()=>{
    t=!0
    },d=()=>{
    t=!1
    },f=()=>_e.isFocused()&&(e.networkMode===`always`||xe.isOnline())&&e.canRun(),p=()=>Ce(e.networkMode)&&e.canRun(),m=e=>{
    c()||(r?.(),i=`resolved`,a(e))
    },h=e=>{
    c()||(r?.(),i=`rejected`,o(e))
    },g=()=>new Promise(t=>{
    r=e=>{
      (c()||f())&&t(e)
      },e.onPause?.()
    }).then(()=>{
    r=void 0,c()||e.onContinue?.()
    }),_=()=>{
    if(c())
    return;
    let r,i=n===0?e.initialPromise:void 0;
    try{
      r=i??e.fn()
      }catch(e){
      r=Promise.reject(e)
      }
    Promise.resolve(r).then(m).catch(r=>{
      if(c())
      return;
      let i=e.retry??(ge()?0:3),a=e.retryDelay??Se,o=typeof a==`function`?a(n,r):a,s=i===!0||typeof i==`number`&&n<i||typeof i==`function`&&i(n,r);
      if(t||!s){
        h(r);
        return
        }
      n++,e.onFail?.(n,r),oe(o).then(()=>f()?void 0:g()).then(()=>{
        t?h(r):_()
        })
      })
    };
  return{promise:s,status:()=>i,cancel:l,continue:()=>(r?.(),s),cancelRetry:u,continueRetry:d,canStart:p,start:()=>(p()?_():g().then(_),s)}
  }
var Ee=class{
  #e;destroy(){
    this.clearGcTimeout()
    }scheduleGc(){
    this.clearGcTimeout(),x(this.gcTime)&&(this.#e=g.setTimeout(()=>{
      this.optionalRemove()
      },this.gcTime))
    }updateGcTime(e){
    this.gcTime=Math.max(this.gcTime||0,e??(ge()?1/0:3e5))
    }clearGcTimeout(){
    this.#e!==void 0&&(g.clearTimeout(this.#e),this.#e=void 0)
    }
};
function De(e){
  return{onFetch:(t,n)=>{
    let r=t.options,i=t.fetchOptions?.meta?.fetchMore?.direction,a=t.state.data?.pages||[],o=t.state.data?.pageParams||[],s={pages:[],pageParams:[]},c=0,l=async()=>{
      let n=!1,l=e=>{
        me(e,()=>t.signal,()=>n=!0)
        },u=fe(t.options,t.fetchOptions),d=async(e,r,i)=>{
        if(n)
        return Promise.reject(t.signal.reason);
        if(r==null&&e.pages.length)
        return Promise.resolve(e);
        let a=(()=>{
          let e={client:t.client,queryKey:t.queryKey,pageParam:r,direction:i?`backward`:`forward`,meta:t.options.meta};
          return l(e),e
          })(),o=await u(a),{maxPages:s}=t.options,c=i?ue:le;
        return{pages:c(e.pages,o,s),pageParams:c(e.pageParams,r,s)}
        };
      if(i&&a.length){
        let e=i===`backward`,t=e?ke:Oe,n={pages:a,pageParams:o};
        s=await d(n,t(r,n),e)
        }else{
        let t=e??a.length;
        do{
          let e=c===0?o[0]??r.initialPageParam:Oe(r,s);
          if(c>0&&e==null)
          break;
          s=await d(s,e),c++
          }while(c<t)
        }
      return s
      };
    t.options.persister?t.fetchFn=()=>t.options.persister?.(l,{client:t.client,queryKey:t.queryKey,meta:t.options.meta,signal:t.signal},n):t.fetchFn=l
    }}
  }
function Oe(e,{pages:t,pageParams:n}){
  let r=t.length-1;
  return t.length>0?e.getNextPageParam(t[r],t,n[r],n):void 0
  }
function ke(e,{pages:t,pageParams:n}){
  return t.length>0?e.getPreviousPageParam?.(t[0],t,n[0],n):void 0
  }
var Ae=class extends Ee{
  #e;#t;#n;#r;#i;#a;#o;#s;constructor(e){
    super(),this.#s=!1,this.#o=e.defaultOptions,this.setOptions(e.options),this.observers=[],this.#i=e.client,this.#r=this.#i.getQueryCache(),this.queryKey=e.queryKey,this.queryHash=e.queryHash,this.#t=Ne(this.options),this.state=e.state??this.#t,this.scheduleGc()
    }get meta(){
    return this.options.meta
    }get queryType(){
    return this.#e
    }get promise(){
    return this.#a?.promise
    }setOptions(e){
    if(this.options={...this.#o,...e},e?._type&&(this.#e=e._type),this.updateGcTime(this.options.gcTime),this.state&&this.state.data===void 0){
      let e=Ne(this.options);
      e.data!==void 0&&(this.setState(Me(e.data,e.dataUpdatedAt)),this.#t=e)
      }
    }optionalRemove(){
    !this.observers.length&&this.state.fetchStatus===`idle`&&this.#r.remove(this)
    }setData(e,t){
    let n=se(this.state.data,e,this.options);
    return this.#c({data:n,type:`success`,dataUpdatedAt:t?.updatedAt,manual:t?.manual}),n
    }setState(e){
    this.#c({type:`setState`,state:e})
    }cancel(e){
    let t=this.#a?.promise;
    return this.#a?.cancel(e),t?t.then(y).catch(y):Promise.resolve()
    }destroy(){
    super.destroy(),this.cancel({silent:!0})
    }get resetState(){
    return this.#t
    }reset(){
    this.destroy(),this.setState(this.resetState)
    }isActive(){
    return this.observers.some(e=>C(e.options.enabled,this)!==!1)
    }isDisabled(){
    return this.getObserversCount()>0?!this.isActive():this.options.queryFn===de||!this.isFetched()
    }isFetched(){
    return this.state.dataUpdateCount+this.state.errorUpdateCount>0
    }isStatic(){
    return this.getObserversCount()>0&&this.observers.some(e=>C(e.options.staleTime,this)===`static`)
    }isStale(){
    return this.getObserversCount()>0?this.observers.some(e=>e.getCurrentResult().isStale):this.state.data===void 0||this.state.isInvalidated
    }isStaleByTime(e=0){
    return this.state.data===void 0?!0:e===`static`?!1:this.state.isInvalidated?!0:!S(this.state.dataUpdatedAt,e)
    }onFocus(){
    this.observers.find(e=>e.shouldFetchOnWindowFocus())?.refetch({cancelRefetch:!1}),this.#a?.continue()
    }onOnline(){
    this.observers.find(e=>e.shouldFetchOnReconnect())?.refetch({cancelRefetch:!1}),this.#a?.continue()
    }addObserver(e){
    this.observers.includes(e)||(this.observers.push(e),this.clearGcTimeout(),this.#r.notify({type:`observerAdded`,query:this,observer:e}))
    }removeObserver(e){
    let t=this.observers.indexOf(e);
    t!==-1&&(this.observers.splice(t,1),this.observers.length||(this.#a&&(this.#s||this.state.fetchStatus===`paused`&&this.state.status===`pending`?this.#a.cancel({revert:!0}):this.#a.cancelRetry()),this.scheduleGc()),this.#r.notify({type:`observerRemoved`,query:this,observer:e}))
    }getObserversCount(){
    return this.observers.length
    }invalidate(){
    this.state.isInvalidated||this.#c({type:`invalidate`})
    }async fetch(e,t){
    if(this.state.fetchStatus!==`idle`&&this.#a?.status()!==`rejected`){
      if(this.state.data!==void 0&&t?.cancelRefetch)
      this.cancel({silent:!0});
      else 
      if(this.#a)
      return this.#a.continueRetry(),this.#a.promise
      }
    if(e&&this.setOptions(e),!this.options.queryFn){
      let e=this.observers.find(e=>e.options.queryFn);
      e&&this.setOptions(e.options)
      }
    let n=new AbortController,r=e=>{
      Object.defineProperty(e,"signal",{enumerable:!0,get:()=>(this.#s=!0,n.signal)})
      },i=()=>{
      let e=fe(this.options,t),n=(()=>{
        let e={client:this.#i,queryKey:this.queryKey,meta:this.meta};
        return r(e),e
        })();
      return this.#s=!1,this.options.persister?this.options.persister(e,n,this):e(n)
      },a=(()=>{
      let e={fetchOptions:t,options:this.options,queryKey:this.queryKey,client:this.#i,state:this.state,fetchFn:i};
      return r(e),e
      })();
    (this.#e===`infinite`?De(this.options.pages):this.options.behavior)?.onFetch(a,this),this.#n=this.state,(this.state.fetchStatus===`idle`||this.state.fetchMeta!==a.fetchOptions?.meta)&&this.#c({type:`fetch`,meta:a.fetchOptions?.meta});
    let o=this.#a=Te({initialPromise:t?.initialPromise,fn:a.fetchFn,onCancel:e=>{
      e instanceof we&&e.revert&&this.setState({...this.#n,fetchStatus:`idle`}),n.abort()
      },onFail:(e,t)=>{
      this.#c({type:`failed`,failureCount:e,error:t})
      },onPause:()=>{
      this.#c({type:`pause`})
      },onContinue:()=>{
      this.#c({type:`continue`})
      },retry:a.options.retry,retryDelay:a.options.retryDelay,networkMode:a.options.networkMode,canRun:()=>!0});
    try{
      let e=await o.start();
      if(e===void 0)
      throw Error(`${this.queryHash} data is undefined`);
      return this.setData(e),this.#r.config.onSuccess?.(e,this),this.#r.config.onSettled?.(e,this.state.error,this),e
      }catch(e){
      if(e instanceof we){
        if(e.silent)
        return this.#a.promise;
        if(e.revert){
          if(this.state.data===void 0)
          throw e;
          return this.state.data
          }
        }
      throw this.#c({type:`error`,error:e}),this.#r.config.onError?.(e,this),this.#r.config.onSettled?.(this.state.data,e,this),e
      }finally{
      this.#a===o&&(this.#a=void 0),this.scheduleGc()
      }
    }#c(e){
    let t=t=>{
      switch(e.type){case`failed`:
      return{...t,fetchFailureCount:e.failureCount,fetchFailureReason:e.error};
      case`pause`:
      return{...t,fetchStatus:`paused`};
      case`continue`:
      return{...t,fetchStatus:`fetching`};
      case`fetch`:
      return{...t,...je(t.data,this.options),fetchMeta:e.meta??null};
      case`success`:
      let n={...t,...Me(e.data,e.dataUpdatedAt),dataUpdateCount:t.dataUpdateCount+1,...!e.manual&&{fetchStatus:`idle`,fetchFailureCount:0,fetchFailureReason:null}};
      return this.#n=e.manual?n:void 0,n;
      case`error`:
      let r=e.error;
      return{...t,error:r,errorUpdateCount:t.errorUpdateCount+1,errorUpdatedAt:Date.now(),fetchFailureCount:t.fetchFailureCount+1,fetchFailureReason:r,fetchStatus:`idle`,status:`error`,isInvalidated:!0};
      case`invalidate`:
      return{...t,isInvalidated:!0};
      case`setState`:
      return{...t,...e.state}
      }
      };
    this.state=t(this.state),A.batch(()=>{
      this.observers.slice().forEach(e=>{
        e.onQueryUpdate()
        }),this.#r.notify({query:this,type:`updated`,action:e})
      })
    }
};
function je(e,t){
  return{fetchFailureCount:0,fetchFailureReason:null,fetchStatus:Ce(t.networkMode)?`fetching`:`paused`,...e===void 0&&{error:null,status:`pending`}}
  }
function Me(e,t){
  return{data:e,dataUpdatedAt:t??Date.now(),error:null,isInvalidated:!1,status:`success`}
  }
function Ne(e){
  let t=typeof e.initialData==`function`?e.initialData():e.initialData,n=t!==void 0,r=n?typeof e.initialDataUpdatedAt==`function`?e.initialDataUpdatedAt():e.initialDataUpdatedAt:0;
  return{data:t,dataUpdateCount:0,dataUpdatedAt:n?r??Date.now():0,error:null,errorUpdateCount:0,errorUpdatedAt:0,fetchFailureCount:0,fetchFailureReason:null,fetchMeta:null,isInvalidated:!1,status:n?`success`:`pending`,fetchStatus:`idle`}
  }
var Pe=class extends k{
  #e;#t=void 0;#n=void 0;#r=void 0;#i;#a;#o;#s;#c;#l;#u;#d;#f;#p=new Set;constructor(e,t){
    super(),this.options=t,this.#e=e,this.#o=null,this.bindMethods(),this.setOptions(t)
    }bindMethods(){
    this.refetch=this.refetch.bind(this)
    }onSubscribe(){
    this.listeners.size===1&&(this.#t.addObserver(this),Ie(this.#t,this.options)?this.#m():this.updateResult(),this.#y())
    }onUnsubscribe(){
    this.hasListeners()||this.destroy()
    }shouldFetchOnReconnect(){
    return Le(this.#t,this.options,this.options.refetchOnReconnect)
    }shouldFetchOnWindowFocus(){
    return Le(this.#t,this.options,this.options.refetchOnWindowFocus)
    }destroy(){
    this.listeners=new Set,this.#b(),this.#x(),this.#t.removeObserver(this)
    }setOptions(e){
    let t=this.options,n=this.#t;
    if(this.options=this.#e.defaultQueryOptions(e),this.options.enabled!==void 0&&typeof this.options.enabled!=`boolean`&&typeof this.options.enabled!=`function`&&typeof C(this.options.enabled,this.#t)!=`boolean`)
    throw Error(`Expected enabled to be a boolean or a callback that returns a boolean`);
    this.#S(),this.#t.setOptions(this.options),t._defaulted&&!ne(this.options,t)&&this.#e.getQueryCache().notify({type:`observerOptionsUpdated`,query:this.#t,observer:this});
    let r=this.hasListeners();
    r&&Re(this.#t,n,this.options,t)&&this.#m(),this.updateResult(),r&&(this.#t!==n||C(this.options.enabled,this.#t)!==C(t.enabled,this.#t)||C(this.options.staleTime,this.#t)!==C(t.staleTime,this.#t))&&this.#g();
    let i=this.#_();
    r&&(this.#t!==n||C(this.options.enabled,this.#t)!==C(t.enabled,this.#t)||i!==this.#f)&&this.#v(i)
    }getOptimisticResult(e){
    let t=this.#e.getQueryCache().build(this.#e,e),n=this.createResult(t,e);
    return ne(this.getCurrentResult(),n)||(this.#r=n,this.#a=this.options,this.#i=this.#t.state),n
    }getCurrentResult(){
    return this.#r
    }trackResult(e,t){
    return new Proxy(e,{get:(e,n)=>(this.trackProp(n),t?.(n),Reflect.get(e,n))})
    }trackProp(e){
    this.#p.add(e)
    }getCurrentQuery(){
    return this.#t
    }refetch({...e}={}){
    return this.fetch({...e})
    }fetchOptimistic(e){
    let t=this.#e.defaultQueryOptions(e),n=this.#e.getQueryCache().build(this.#e,t),r=()=>{
      },i,a=new Promise(e=>{
      i=e,r=this.#e.getQueryCache().subscribe(i=>{
        i.type===`updated`&&i.query.queryHash===n.queryHash&&n.state.data!==void 0&&(r(),e(this.createResult(n,t)))
        })
      });
    return Promise.race([n.fetch().then(()=>{
      let e=this.createResult(n,t);
      return i?.(e),e
      }).finally(()=>{
      r()
      }),a])
    }fetch(e){
    return this.#m({...e,cancelRefetch:e.cancelRefetch??!0}).then(()=>(this.updateResult(),this.#r))
    }#m(e){
    this.#S();
    let t=this.#t.fetch(this.options,e);
    return e?.throwOnError||(t=t.catch(y)),t
    }#h(e){
    return!ge()&&C(this.options.enabled,this.#t)!==!1&&x(e)
    }#g(){
    this.#b();
    let e=C(this.options.staleTime,this.#t);
    if(this.#r.isStale||!this.#h(e))
    return;
    let t=S(this.#r.dataUpdatedAt,e)+1;
    this.#u=g.setTimeout(()=>{
      this.#r.isStale||this.updateResult()
      },t)
    }#_(){
    return(typeof this.options.refetchInterval==`function`?this.options.refetchInterval(this.#t):this.options.refetchInterval)??!1
    }#v(e){
    this.#x(),this.#f=e,!(this.#f===0||!this.#h(this.#f))&&(this.#d=g.setInterval(()=>{
      (this.options.refetchIntervalInBackground||_e.isFocused())&&this.#m()
      },this.#f))
    }#y(){
    this.#g(),this.#v(this.#_())
    }#b(){
    this.#u!==void 0&&(g.clearTimeout(this.#u),this.#u=void 0)
    }#x(){
    this.#d!==void 0&&(g.clearInterval(this.#d),this.#d=void 0)
    }createResult(e,t){
    let n=this.#t,r=this.options,i=this.#r,a=this.#i,o=this.#a,s=e===n?this.#n:e.state,{state:c}=e,l={...c},u=!1,d;
    if(t._optimisticResults){
      let i=this.hasListeners(),a=!i&&Ie(e,t),o=i&&Re(e,n,t,r);
      (a||o)&&(l={...l,...je(c.data,e.options)}),t._optimisticResults===`isRestoring`&&(l.fetchStatus=`idle`)
      }
    let{error:f,errorUpdatedAt:p,status:m}=l;
    d=l.data;
    let h=!1;
    if(t.placeholderData!==void 0&&d===void 0&&m===`pending`){
      let e;
      i?.isPlaceholderData&&t.placeholderData===o?.placeholderData?(e=i.data,h=!0):e=typeof t.placeholderData==`function`?t.placeholderData(this.#l?.state.data,this.#l):t.placeholderData,e!==void 0&&(m=`success`,d=se(i?.data,e,t),u=!0)
      }
    if(t.select&&d!==void 0&&!h)
    if(i&&d===a?.data&&t.select===this.#s)
    d=this.#c;
    else 
    try{
      this.#s=t.select,d=t.select(d),d=se(i?.data,d,t),this.#c=d,this.#o=null
      }catch(e){
      this.#o=e
      }
    else 
    d===void 0&&(this.#o=null);
    this.#o&&(f=this.#o,d=this.#c,p=Date.now(),m=`error`,u=!1);
    let g=l.fetchStatus===`fetching`,_=m===`pending`,v=m===`error`,y=_&&g,b=d!==void 0;
    return{status:m,fetchStatus:l.fetchStatus,isPending:_,isSuccess:m===`success`,isError:v,isInitialLoading:y,isLoading:y,data:d,dataUpdatedAt:l.dataUpdatedAt,error:f,errorUpdatedAt:p,failureCount:l.fetchFailureCount,failureReason:l.fetchFailureReason,errorUpdateCount:l.errorUpdateCount,isFetched:e.isFetched(),isFetchedAfterMount:l.dataUpdateCount>s.dataUpdateCount||l.errorUpdateCount>s.errorUpdateCount,isFetching:g,isRefetching:g&&!_,isLoadingError:v&&!b,isPaused:l.fetchStatus===`paused`,isPlaceholderData:u,isRefetchError:v&&b,isStale:ze(e,t),refetch:this.refetch,isEnabled:C(t.enabled,e)!==!1}
    }updateResult(){
    let e=this.#r,t=this.createResult(this.#t,this.options);
    if(this.#i=this.#t.state,this.#a=this.options,this.#i.data!==void 0&&(this.#l=this.#t),ne(t,e))
    return;
    this.#r=t;
    let n=(()=>{
      if(!e)
      return!0;
      let{notifyOnChangeProps:t}=this.options,n=typeof t==`function`?t():t;
      if(n===`all`||!n&&!this.#p.size)
      return!0;
      let r=new Set(n??this.#p);
      return this.options.throwOnError&&r.add(`error`),Object.keys(this.#r).some(t=>{
        let n=t;
        return this.#r[n]!==e[n]&&r.has(n)
        })
      })();
    A.batch(()=>{
      n&&this.listeners.forEach(e=>{
        e(this.#r)
        }),this.#e.getQueryCache().notify({query:this.#t,type:`observerResultsUpdated`})
      })
    }#S(){
    let e=this.#e.getQueryCache().build(this.#e,this.options);
    if(e===this.#t)
    return;
    let t=this.#t;
    this.#t=e,this.#n=e.state,this.hasListeners()&&(t?.removeObserver(this),e.addObserver(this))
    }onQueryUpdate(){
    this.updateResult(),this.hasListeners()&&this.#y()
    }
};
function Fe(e,t){
  return C(t.enabled,e)!==!1&&e.state.data===void 0&&!(e.state.status===`error`&&C(t.retryOnMount,e)===!1)
  }
function Ie(e,t){
  return Fe(e,t)||e.state.data!==void 0&&Le(e,t,t.refetchOnMount)
  }
function Le(e,t,n){
  if(C(t.enabled,e)!==!1&&C(t.staleTime,e)!==`static`){
    let r=typeof n==`function`?n(e):n;
    return r===`always`||r!==!1&&ze(e,t)
    }
  return!1
  }
function Re(e,t,n,r){
  return(e!==t||C(r.enabled,e)===!1)&&(!n.suspense||e.state.status!==`error`)&&ze(e,n)
  }
function ze(e,t){
  return C(t.enabled,e)!==!1&&e.isStaleByTime(C(t.staleTime,e))
  }
var Be=class extends Ee{
  #e;#t;#n;#r;constructor(e){
    super(),this.#e=e.client,this.mutationId=e.mutationId,this.#n=e.mutationCache,this.#t=[],this.state=e.state||Ve(),this.setOptions(e.options),this.scheduleGc()
    }setOptions(e){
    this.options=e,this.updateGcTime(this.options.gcTime)
    }get meta(){
    return this.options.meta
    }addObserver(e){
    this.#t.includes(e)||(this.#t.push(e),this.clearGcTimeout(),this.#n.notify({type:`observerAdded`,mutation:this,observer:e}))
    }removeObserver(e){
    this.#t=this.#t.filter(t=>t!==e),this.scheduleGc(),this.#n.notify({type:`observerRemoved`,mutation:this,observer:e})
    }optionalRemove(){
    this.#t.length||(this.state.status===`pending`?this.scheduleGc():this.#n.remove(this))
    }continue(){
    return this.#r?.continue()??(this.state.status===`pending`?this.execute(this.state.variables):Promise.resolve())
    }async execute(e){
    let t=()=>{
      this.#i({type:`continue`})
      },n={client:this.#e,meta:this.options.meta,mutationKey:this.options.mutationKey},r=this.#r=Te({fn:()=>this.options.mutationFn?this.options.mutationFn(e,n):Promise.reject(Error(`No mutationFn found`)),onFail:(e,t)=>{
      this.#i({type:`failed`,failureCount:e,error:t})
      },onPause:()=>{
      this.#i({type:`pause`})
      },onContinue:t,retry:this.options.retry??0,retryDelay:this.options.retryDelay,networkMode:this.options.networkMode,canRun:()=>this.#n.canRun(this)}),i=this.state.status===`pending`,a=!r.canStart();
    try{
      if(i)
      t();
      else{
        this.#i({type:`pending`,variables:e,isPaused:a}),this.#n.config.onMutate&&await this.#n.config.onMutate(e,this,n);
        let t=await this.options.onMutate?.(e,n);
        t!==this.state.context&&this.#i({type:`pending`,context:t,variables:e,isPaused:a})
        }
      let o=await r.start();
      return await this.#n.config.onSuccess?.(o,e,this.state.context,this,n),await this.options.onSuccess?.(o,e,this.state.context,n),await this.#n.config.onSettled?.(o,null,this.state.variables,this.state.context,this,n),await this.options.onSettled?.(o,null,e,this.state.context,n),this.#i({type:`success`,data:o}),o
      }catch(t){
      try{
        await this.#n.config.onError?.(t,e,this.state.context,this,n)
        }catch(e){
        Promise.reject(e)
        }
      try{
        await this.options.onError?.(t,e,this.state.context,n)
        }catch(e){
        Promise.reject(e)
        }
      try{
        await this.#n.config.onSettled?.(void 0,t,this.state.variables,this.state.context,this,n)
        }catch(e){
        Promise.reject(e)
        }
      try{
        await this.options.onSettled?.(void 0,t,e,this.state.context,n)
        }catch(e){
        Promise.reject(e)
        }
      throw this.#i({type:`error`,error:t}),t
      }finally{
      this.#r===r&&(this.#r=void 0),this.#n.runNext(this)
      }
    }#i(e){
    let t=t=>{
      switch(e.type){case`failed`:
      return{...t,failureCount:e.failureCount,failureReason:e.error};
      case`pause`:
      return{...t,isPaused:!0};
      case`continue`:
      return{...t,isPaused:!1};
      case`pending`:
      return{...t,context:e.context,data:void 0,failureCount:0,failureReason:null,error:null,isPaused:e.isPaused,status:`pending`,variables:e.variables,submittedAt:Date.now()};
      case`success`:
      return{...t,data:e.data,failureCount:0,failureReason:null,error:null,status:`success`,isPaused:!1};
      case`error`:
      return{...t,data:void 0,error:e.error,failureCount:t.failureCount+1,failureReason:e.error,isPaused:!1,status:`error`}
      }
      };
    this.state=t(this.state),A.batch(()=>{
      this.#t.forEach(t=>{
        t.onMutationUpdate(e)
        }),this.#n.notify({mutation:this,type:`updated`,action:e})
      })
    }
};
function Ve(){
  return{context:void 0,data:void 0,error:null,failureCount:0,failureReason:null,isPaused:!1,status:`idle`,variables:void 0,submittedAt:0}
  }
var He=class extends k{
  #e;#t;#n;constructor(e={}){
    super(),this.config=e,this.#e=new Set,this.#t=new Map,this.#n=0
    }build(e,t,n){
    let r=new Be({client:e,mutationCache:this,mutationId:++this.#n,options:e.defaultMutationOptions(t),state:n});
    return this.add(r),r
    }add(e){
    this.#e.add(e);
    let t=Ue(e);
    if(typeof t==`string`){
      let n=this.#t.get(t);
      n?n.push(e):this.#t.set(t,[e])
      }
    this.notify({type:`added`,mutation:e})
    }remove(e){
    if(this.#e.delete(e)){
      let t=Ue(e);
      if(typeof t==`string`){
        let n=this.#t.get(t);
        if(n)
        if(n.length>1){
          let t=n.indexOf(e);
          t!==-1&&n.splice(t,1)
          }else 
        n[0]===e&&this.#t.delete(t)
        }
      }
    this.notify({type:`removed`,mutation:e})
    }canRun(e){
    let t=Ue(e);
    if(typeof t==`string`){
      let n=this.#t.get(t)?.find(e=>e.state.status===`pending`);
      return!n||n===e
      }else 
    return!0
    }runNext(e){
    let t=Ue(e);
    return typeof t==`string`?(this.#t.get(t)?.find(t=>t!==e&&t.state.isPaused))?.continue()??Promise.resolve():Promise.resolve()
    }clear(){
    A.batch(()=>{
      this.#e.forEach(e=>{
        this.notify({type:`removed`,mutation:e})
        }),this.#e.clear(),this.#t.clear()
      })
    }getAll(){
    return Array.from(this.#e)
    }find(e){
    let t={exact:!0,...e};
    return this.getAll().find(e=>T(t,e))
    }findAll(e={}){
    return this.getAll().filter(t=>T(e,t))
    }notify(e){
    A.batch(()=>{
      this.listeners.forEach(t=>{
        t(e)
        })
      })
    }resumePausedMutations(){
    let e=this.getAll().filter(e=>e.state.isPaused);
    return A.batch(()=>Promise.all(e.map(e=>e.continue().catch(y))))
    }
};
function Ue(e){
  return e.options.scope?.id
  }
var We=class extends k{
  #e;constructor(e={}){
    super(),this.config=e,this.#e=new Map
    }build(e,t,n){
    let r=t.queryKey,i=t.queryHash??E(r,t),a=this.get(i);
    return a||(a=new Ae({client:e,queryKey:r,queryHash:i,options:e.defaultQueryOptions(t),state:n,defaultOptions:e.getQueryDefaults(r)}),this.add(a)),a
    }add(e){
    this.#e.has(e.queryHash)||(this.#e.set(e.queryHash,e),this.notify({type:`added`,query:e}))
    }remove(e){
    let t=this.#e.get(e.queryHash);
    t&&(e.destroy(),t===e&&this.#e.delete(e.queryHash),this.notify({type:`removed`,query:e}))
    }clear(){
    A.batch(()=>{
      this.getAll().forEach(e=>{
        this.remove(e)
        })
      })
    }get(e){
    return this.#e.get(e)
    }getAll(){
    return[...this.#e.values()]
    }find(e){
    let t={exact:!0,...e};
    return this.getAll().find(e=>w(t,e))
    }findAll(e={}){
    let t=this.getAll();
    return Object.keys(e).length>0?t.filter(t=>w(e,t)):t
    }notify(e){
    A.batch(()=>{
      this.listeners.forEach(t=>{
        t(e)
        })
      })
    }onFocus(){
    A.batch(()=>{
      this.getAll().forEach(e=>{
        e.onFocus()
        })
      })
    }onOnline(){
    A.batch(()=>{
      this.getAll().forEach(e=>{
        e.onOnline()
        })
      })
    }
},Ge=class{
  #e;#t;#n;#r;#i;#a;#o;#s;constructor(e={}){
    this.#e=e.queryCache||new We,this.#t=e.mutationCache||new He,this.#n=e.defaultOptions||{},this.#r=new Map,this.#i=new Map,this.#a=0
    }mount(){
    this.#a++,this.#a===1&&(this.#o=_e.subscribe(async e=>{
      e&&(await this.resumePausedMutations(),this.#e.onFocus())
      }),this.#s=xe.subscribe(async e=>{
      e&&(await this.resumePausedMutations(),this.#e.onOnline())
      }))
    }unmount(){
    this.#a--,this.#a===0&&(this.#o?.(),this.#o=void 0,this.#s?.(),this.#s=void 0)
    }isFetching(e){
    return this.#e.findAll({...e,fetchStatus:`fetching`}).length
    }isMutating(e){
    return this.#t.findAll({...e,status:`pending`}).length
    }getQueryData(e){
    let t=this.defaultQueryOptions({queryKey:e});
    return this.#e.get(t.queryHash)?.state.data
    }ensureQueryData(e){
    let t=this.defaultQueryOptions(e),n=this.#e.build(this,t),r=n.state.data;
    return r===void 0?this.fetchQuery(e):(e.revalidateIfStale&&n.isStaleByTime(C(t.staleTime,n))&&this.prefetchQuery(t),Promise.resolve(r))
    }getQueriesData(e){
    return this.#e.findAll(e).map(({queryKey:e,state:t})=>[e,t.data])
    }setQueryData(e,t,n){
    let r=this.defaultQueryOptions({queryKey:e}),i=this.#e.get(r.queryHash)?.state.data,a=b(t,i);
    if(a!==void 0)
    return this.#e.build(this,r).setData(a,{...n,manual:!0})
    }setQueriesData(e,t,n){
    return A.batch(()=>this.#e.findAll(e).map(({queryKey:e})=>[e,this.setQueryData(e,t,n)]))
    }getQueryState(e){
    let t=this.defaultQueryOptions({queryKey:e});
    return this.#e.get(t.queryHash)?.state
    }removeQueries(e){
    let t=this.#e;
    A.batch(()=>{
      t.findAll(e).forEach(e=>{
        t.remove(e)
        })
      })
    }resetQueries(e,t){
    let n=this.#e;
    return A.batch(()=>{
      let r=n.findAll(e),i=new Set(r);
      return r.forEach(e=>{
        e.reset()
        }),this.refetchQueries({type:`active`,predicate:e=>i.has(e)},t)
      })
    }cancelQueries(e,t={}){
    let n={revert:!0,...t},r=A.batch(()=>this.#e.findAll(e).map(e=>e.cancel(n)));
    return Promise.all(r).then(y).catch(y)
    }invalidateQueries(e,t={}){
    return A.batch(()=>(this.#e.findAll(e).forEach(e=>{
      e.invalidate()
      }),e?.refetchType===`none`?Promise.resolve():this.refetchQueries({...e,type:e?.refetchType??e?.type??`active`},t)))
    }refetchQueries(e,t={}){
    let n={...t,cancelRefetch:t.cancelRefetch??!0},r=A.batch(()=>this.#e.findAll(e).filter(e=>!e.isDisabled()&&!e.isStatic()).map(e=>{
      let t=e.fetch(void 0,n);
      return n.throwOnError||(t=t.catch(y)),e.state.fetchStatus===`paused`?Promise.resolve():t
      }));
    return Promise.all(r).then(y)
    }async query(e){
    let t=this.defaultQueryOptions(e);
    t.retry===void 0&&(t.retry=!1);
    let n=this.#e.build(this,t),r=n.isStaleByTime(C(t.staleTime,n))?await n.fetch(t):n.state.data,i=t.select;
    return i?i(r):r
    }fetchQuery(e){
    let t=this.defaultQueryOptions(e);
    t.retry===void 0&&(t.retry=!1);
    let n=this.#e.build(this,t);
    return n.isStaleByTime(C(t.staleTime,n))?n.fetch(t):Promise.resolve(n.state.data)
    }prefetchQuery(e){
    return this.fetchQuery(e).then(y).catch(y)
    }infiniteQuery(e){
    return e._type=`infinite`,this.query(e)
    }fetchInfiniteQuery(e){
    return e._type=`infinite`,this.fetchQuery(e)
    }prefetchInfiniteQuery(e){
    return this.fetchInfiniteQuery(e).then(y).catch(y)
    }ensureInfiniteQueryData(e){
    return e._type=`infinite`,this.ensureQueryData(e)
    }resumePausedMutations(){
    return xe.isOnline()?this.#t.resumePausedMutations():Promise.resolve()
    }getQueryCache(){
    return this.#e
    }getMutationCache(){
    return this.#t
    }getDefaultOptions(){
    return this.#n
    }setDefaultOptions(e){
    this.#n=e
    }setQueryDefaults(e,t){
    this.#r.set(D(e),{queryKey:e,defaultOptions:t})
    }getQueryDefaults(e){
    let t=[...this.#r.values()],n={};
    return t.forEach(t=>{
      O(e,t.queryKey)&&Object.assign(n,t.defaultOptions)
      }),n
    }setMutationDefaults(e,t){
    this.#i.set(D(e),{mutationKey:e,defaultOptions:t})
    }getMutationDefaults(e){
    let t=[...this.#i.values()],n={};
    return t.forEach(t=>{
      O(e,t.mutationKey)&&Object.assign(n,t.defaultOptions)
      }),n
    }defaultQueryOptions(e){
    if(e._defaulted)
    return e;
    let t={...this.#n.queries,...this.getQueryDefaults(e.queryKey),...e,_defaulted:!0};
    return t.queryHash||=E(t.queryKey,t),t.refetchOnReconnect===void 0&&(t.refetchOnReconnect=t.networkMode!==`always`),t.throwOnError===void 0&&(t.throwOnError=!!t.suspense),!t.networkMode&&t.persister&&(t.networkMode=`offlineFirst`),t.queryFn===de&&(t.enabled=!1),t
    }defaultMutationOptions(e){
    return e?._defaulted?e:{...this.#n.mutations,...e?.mutationKey&&this.getMutationDefaults(e.mutationKey),...e,_defaulted:!0}
    }clear(){
    this.#e.clear(),this.#t.clear()
    }
},Ke=u.createContext(!1),qe=()=>u.useContext(Ke);
Ke.Provider;
function Je(){
  let e=!1;
  return{clearReset:()=>{
    e=!1
    },reset:()=>{
    e=!0
    },isReset:()=>e}
  }
var Ye=u.createContext(Je()),Xe=()=>u.useContext(Ye),Ze=(e,t,n)=>{
  let r=n?.state.error&&typeof e.throwOnError==`function`?pe(e.throwOnError,[n.state.error,n]):e.throwOnError;
  (e.suspense||r)&&(t.isReset()||(e.retryOnMount=!1))
  },Qe=e=>{
  u.useEffect(()=>{
    e.clearReset()
    },[e])
  },$e=({result:e,errorResetBoundary:t,throwOnError:n,query:r,suspense:i})=>e.isError&&!t.isReset()&&!e.isFetching&&r&&(i&&e.data===void 0||pe(n,[e.error,r])),et=e=>{
  if(e.suspense){
    let t=1e3,n=e=>e===`static`?e:Math.max(e??t,t),r=e.staleTime;
    e.staleTime=typeof r==`function`?(...e)=>n(r(...e)):n(r),typeof e.gcTime==`number`&&(e.gcTime=Math.max(e.gcTime,t))
    }
  },tt=(e,t)=>e?.suspense&&t.isPending,nt=(e,t,n)=>t.fetchOptimistic(e).catch(()=>{
  n.clearReset()
  });
function rt(e,t,n){
  let r=qe(),i=Xe(),a=p(n),o=a.defaultQueryOptions(e),s=a.getQueryCache().get(o.queryHash),c=e.subscribed!==!1;
  o._optimisticResults=r?`isRestoring`:c?`optimistic`:void 0,et(o),Ze(o,i,s),Qe(i);
  let[l]=u.useState(()=>new t(a,o)),d=l.getOptimisticResult(o),f=!r&&c;
  if(u.useSyncExternalStore(u.useCallback(e=>{
    let t=f?l.subscribe(A.batchCalls(e)):y;
    return l.updateResult(),t
    },[l,f]),()=>l.getCurrentResult(),()=>l.getCurrentResult()),u.useEffect(()=>{
    l.setOptions(o)
    },[o,l]),tt(o,d))
  throw nt(o,l,i);
  if($e({result:d,errorResetBoundary:i,throwOnError:o.throwOnError,query:s,suspense:o.suspense}))
  throw d.error;
  return o.notifyOnChangeProps?d:l.trackResult(d)
  }
function it(e,t){
  return rt(e,Pe,t)
  }
function at(){
  return new Ge({defaultOptions:{queries:{staleTime:6e4,gcTime:5*6e4,refetchOnWindowFocus:!1},dehydrate:{shouldDehydrateQuery:e=>ve(e)||e.state.status===`pending`,shouldRedactErrors:()=>!1}}})
  }
var ot;
function st(){
  return v?at():(ot||=at(),ot)
  }
function ct({children:e}){
  return(0,d.jsx)(m,{client:st(),children:e})
  }
function lt(){
  if(typeof document>`u`)
  return{};
  let e=document.querySelector(`meta[name="csrf-token"]`)?.content;
  return e?{"x-csrf-token":e}:{}
  }
var ut=new Set;
function dt(e){
  let t=e.split(/[?#]/,1)[0].split(`/`).filter(Boolean);
  return t[0]===`models`&&t[1]?{subjectType:`model`,subjectSlug:t[1]}:t[0]===`providers`&&t[1]?{subjectType:`provider`,subjectSlug:t[1]}:{subjectType:`page`,subjectSlug:null}
  }
function ft(){
  return typeof crypto<`u`&&`randomUUID`in crypto?crypto.randomUUID():`${Date.now()}-${Math.random().toString(16).slice(2)}`
  }
function pt(e,t){
  if(!e)
  return null;
  try{
    let n=e.getItem(t);
    if(n)
    return n;
    let r=ft();
    return e.setItem(t,r),r
    }catch{
    return null
    }
  }
function mt(e){
  try{
    return e===`local`?window.localStorage:window.sessionStorage
    }catch{
    return
    }
  }
function ht(e){
  let t=lt(),n=JSON.stringify({...e,_token:t[`x-csrf-token`]});
  navigator.sendBeacon&&navigator.sendBeacon(`/_catalog/analytics/events`,new Blob([n],{type:`application/json`}))||fetch(`/_catalog/analytics/events`,{method:`POST`,headers:{accept:`application/json`,"content-type":`application/json`,...t},body:n,cache:`no-store`,credentials:`same-origin`,keepalive:!0}).catch(()=>void 0)
  }
function gt(){
  let{url:e}=i();
  return(0,u.useEffect)(()=>{
    let t=e;
    if(ut.has(t))
    return;
    ut.add(t);
    let n=dt(t);
    ht({eventId:ft(),eventName:`page_view`,medium:`web`,source:`web`,subjectType:n.subjectType,subjectSlug:n.subjectSlug,page:{path:t,url:window.location.href,title:document.title},referrerUrl:document.referrer||null,occurredAt:new Date().toISOString(),visitorId:pt(mt(`local`),`sulat.analytics.visitor_id`),sessionId:pt(mt(`session`),`sulat.analytics.session_id`),metadata:{visibilityState:document.visibilityState,timezone:Intl.DateTimeFormat().resolvedOptions().timeZone,screen:{width:window.screen.width,height:window.screen.height,pixelRatio:window.devicePixelRatio}}})
    },[e]),null
  }
function j(e,t={month:`short`,day:`numeric`,year:`numeric`}){
  if(!e)
  return`Unknown`;
  let n=new Date(e);
  return Number.isNaN(n.valueOf())?e:new Intl.DateTimeFormat(`en`,t).format(n)
  }
function M(e){
  return new Intl.NumberFormat(`en`).format(e)
  }
function N(e){
  return new Intl.NumberFormat(`en-US`,{style:`currency`,currency:`USD`,minimumFractionDigits:2,maximumFractionDigits:6}).format(e)
  }
function _t(e){
  return e.replace(/[-_]/g,` `).replace(/([a-z])([A-Z])/g,`$1 $2`).replace(/\b\w/g,e=>e.toUpperCase())
  }
function vt(e){
  let t=xt(e.metadata.cost?.input),n=xt(e.metadata.cost?.output);
  return t===null&&n===null?null:t===0||n===0?`Subscription plan pricing`:t!==null&&n!==null?`In ${N(t)} · Out ${N(n)}`:t===null?`Output ${N(n)}`:`Input ${N(t)}`
  }
function yt(e){
  let t=xt(e.metadata.limits?.context);
  return t===null?null:`${M(t)} token context window`
  }
function bt(e){
  let t=[];
  return e.capabilities.reasoning&&t.push(`Reasoning`),e.capabilities.toolCall&&t.push(`Tool calling`),e.capabilities.structuredOutput&&t.push(`Structured output`),e.capabilities.attachment&&t.push(`Attachments`),e.capabilities.openWeights&&t.push(`Open weights`),e.capabilities.temperature&&t.push(`Temp controls`),t
  }
function xt(e){
  return typeof e==`number`&&Number.isFinite(e)?e:null
  }
function St(...e){
  return e.filter(Boolean).join(` `)
  }
function P(e,t){
  let n=e.meta[t];
  return typeof n==`string`&&n!==``?n:null
  }
var Ct=[{type:`provider`,label:`Providers`,accentClassName:`bg-orange-500 dark:bg-orange-300`},{type:`model`,label:`Models`,accentClassName:`bg-sky-600 dark:bg-sky-300`},{type:`providerProfile`,label:`Provider profiles`,accentClassName:`bg-emerald-600 dark:bg-emerald-300`},{type:`modelNews`,label:`News`,accentClassName:`bg-rose-600 dark:bg-rose-300`}];
function wt({children:e}){
  return(0,d.jsx)(`span`,{className:`inline-flex items-center rounded-full border border-[color:var(--color-line)] bg-white/65 px-2.5 py-1 text-[0.72rem] leading-none text-[color:var(--color-muted)] dark:bg-white/5`,children:e})
  }
function Tt(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M3 8h9m0 0-3.25-3.25M12 8l-3.25 3.25`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})})
  }
function Et(e){
  switch(e.type){case`provider`:
  return[P(e,`providerKey`),P(e,`npmPackage`)].filter(e=>!!e);
  case`model`:{
    let t=P(e,`releaseDate`);
    return[P(e,`status`),t?`Released ${j(t)}`:null].filter(e=>!!e)
    }case`providerProfile`:
  return[P(e,`providerKey`)].filter(e=>!!e);
  case`modelNews`:{
    let t=P(e,`publishedAt`);
    return[P(e,`sourceHost`),t?`Published ${j(t)}`:null].filter(e=>!!e)
    }}
  }
function Dt({activeIndex:e=-1,className:t,emptyState:n,errorState:r,footer:i,getMetaItems:a=Et,hasError:o=!1,isLoading:s=!1,headerDetail:c,headerSummary:l,listClassName:u,listId:f,onResultClick:p,onResultHover:m,results:h,showFooterWhenEmpty:g=!1}){
  let _=i&&!o&&(h.length>0||g),v=Ct.map(e=>({...e,results:h.map((e,t)=>({index:t,result:e})).filter(({result:t})=>t.type===e.type)})).filter(e=>e.results.length>0);
  return(0,d.jsxs)(`div`,{"aria-busy":s,className:St(`catalog-live-results-shell overflow-hidden rounded-[1.45rem] bg-white/92 dark:bg-stone-950/92`,t),children:[(0,d.jsxs)(`div`,{className:`flex flex-wrap items-center justify-between gap-2.5 border-b border-[color:var(--color-line)] px-4 py-3 text-sm text-[color:var(--color-muted)] sm:px-5`,children:[(0,d.jsx)(`div`,{className:`min-w-0 shrink-0`,children:l}),c?(0,d.jsx)(`div`,{className:`min-w-0`,children:c}):null]}),o?(0,d.jsx)(`div`,{id:f,className:`p-5 text-sm leading-7 text-[color:var(--color-muted)]`,children:r}):h.length>0?(0,d.jsx)(`div`,{id:f,className:St(`max-h-[min(30rem,60dvh)] overflow-y-auto overscroll-contain p-2 sm:max-h-[min(34rem,64dvh)] sm:p-2.5`,u),role:`listbox`,tabIndex:-1,children:(0,d.jsx)(`div`,{className:`grid gap-2.5`,children:v.map(t=>{
    let n=f?`${f}-${t.type}-heading`:void 0;
    return(0,d.jsxs)(`section`,{"aria-labelledby":n,className:`overflow-hidden rounded-[1.1rem] border border-[color:var(--color-line)] bg-white/55 dark:bg-white/[0.025]`,role:`group`,children:[(0,d.jsxs)(`div`,{className:`sticky top-0 z-10 flex items-center justify-between gap-3 border-b border-[color:var(--color-line)] bg-[color:var(--color-paper)]/95 px-3.5 py-2 backdrop-blur-md sm:px-4`,children:[(0,d.jsxs)(`div`,{className:`flex items-center gap-2.5`,children:[(0,d.jsx)(`span`,{"aria-hidden":`true`,className:St(`h-4 w-1 rounded-full`,t.accentClassName)}),(0,d.jsx)(`h3`,{id:n,className:`text-[0.7rem] font-bold tracking-[0.16em] text-[color:var(--color-ink)] uppercase`,children:t.label})]}),(0,d.jsx)(`span`,{className:`rounded-full bg-[color:var(--color-soft)] px-2 py-0.5 text-[0.68rem] font-semibold text-[color:var(--color-muted)]`,children:t.results.length})]}),(0,d.jsx)(`div`,{className:`divide-y divide-[color:var(--color-line)]`,children:t.results.map(({index:t,result:n})=>{
      let r=a(n);
      return(0,d.jsxs)(`button`,{id:f?`${f}-result-${n.type}-${n.id}`:void 0,type:`button`,role:`option`,"aria-selected":t===e,className:St(`group grid w-full grid-cols-[minmax(0,1fr)_auto] items-center gap-3 px-3.5 py-3 text-left text-[color:var(--color-ink)] transition sm:px-4`,t===e?`bg-accent-soft/35`:`hover:bg-accent-soft/20`),onClick:()=>p(n),onFocus:()=>m?.(t),onMouseEnter:()=>m?.(t),children:[(0,d.jsxs)(`div`,{className:`min-w-0`,children:[(0,d.jsxs)(`div`,{className:`flex min-w-0 flex-wrap items-baseline gap-x-2 gap-y-0.5`,children:[(0,d.jsx)(`span`,{className:`truncate text-[0.98rem] font-semibold sm:text-base`,children:n.title}),n.subtitle?(0,d.jsx)(`span`,{className:`truncate text-xs text-[color:var(--color-muted)] sm:text-sm`,children:n.subtitle}):null]}),n.description?(0,d.jsx)(`p`,{className:`mt-1 line-clamp-2 hidden max-w-2xl text-xs leading-5 text-[color:var(--color-muted)] sm:block`,children:n.description}):null,r.length>0?(0,d.jsx)(`div`,{className:`mt-2 flex flex-wrap gap-1.5`,children:r.map(e=>(0,d.jsx)(wt,{children:e},e))}):null]}),(0,d.jsx)(`span`,{className:`inline-flex size-8 shrink-0 items-center justify-center rounded-full border border-[color:var(--color-line)] text-[color:var(--color-muted)] transition group-hover:border-[color:var(--color-line-strong)] group-hover:text-[color:var(--color-ink)]`,children:(0,d.jsx)(Tt,{})})]},`${n.type}-${n.id}`)
      })})]},t.type)
    })})}):(0,d.jsx)(`div`,{id:f,className:`p-5 text-sm leading-7 text-[color:var(--color-muted)]`,children:s?(0,d.jsx)(`span`,{role:`status`,children:`Finding matches…`}):n}),_?(0,d.jsx)(`div`,{className:`border-t border-[color:var(--color-line)] bg-white/75 px-5 py-4`,children:i}):null]})
  }
var Ot=o();
function F(...e){
  return e.filter(Boolean).join(` `)
  }
function I({ariaLabel:e,ariaDescribedBy:t,ariaLabelledBy:n,children:r,className:i,onClose:a,overlayClassName:o,panelClassName:s}){
  let c=(0,u.useRef)(null),l=typeof document>`u`?null:document.body;
  return(0,u.useEffect)(()=>{
    if(!l)
    return;
    let e=document.body.style.overflow;
    document.body.style.overflow=`hidden`;
    let t=window.requestAnimationFrame(()=>{
      c.current?.scrollIntoView({block:`center`,inline:`nearest`})
      }),n=e=>{
      e.key===`Escape`&&a()
      };
    return window.addEventListener(`keydown`,n),()=>{
      document.body.style.overflow=e,window.cancelAnimationFrame(t),window.removeEventListener(`keydown`,n)
      }
    },[a,l]),l?(0,Ot.createPortal)((0,d.jsxs)(`div`,{"aria-label":e,"aria-describedby":t,"aria-labelledby":n,"aria-modal":`true`,className:F(`modal-layer fixed inset-0 min-h-full w-full overflow-y-auto overscroll-contain px-4 py-6 sm:px-6 sm:py-10`),role:`dialog`,children:[(0,d.jsx)(`button`,{"aria-label":e?`Close ${e}`:void 0,className:F(`modal-overlay fixed inset-0`,o),type:`button`,onClick:a}),(0,d.jsx)(`div`,{className:F(`relative z-10 flex min-h-full w-full`,i),children:(0,d.jsx)(`div`,{ref:c,className:F(`modal-surface relative max-h-[calc(100dvh-3rem)] w-full overflow-y-auto sm:max-h-[calc(100dvh-5rem)]`,s),children:r})})]}),l):null
  }
function kt(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`size-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`m4.25 4.25 7.5 7.5m0-7.5-7.5 7.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.5`})})
  }
function At({className:e,description:t,descriptionId:n,eyebrow:r,onClose:i,title:a,titleId:o}){
  return(0,d.jsxs)(`div`,{className:F(`grid grid-cols-[minmax(0,1fr)_auto] items-start gap-4`,e),children:[(0,d.jsxs)(`div`,{className:`min-w-0 space-y-2`,children:[(0,d.jsx)(`p`,{className:`eyebrow`,children:r}),(0,d.jsx)(`h4`,{id:o,className:`font-serif text-[1.8rem] leading-tight tracking-[-0.05em] break-words text-[color:var(--color-ink)]`,children:a}),t?(0,d.jsx)(`p`,{id:n,className:`max-w-2xl text-base/7 text-[color:var(--color-muted)] sm:text-sm/6`,children:t}):null]}),(0,d.jsxs)(`button`,{"aria-label":`Close`,className:`focus-visible:ring-accent/20 relative inline-flex size-11 shrink-0 items-center justify-center rounded-full border border-[color:var(--color-line)] bg-white/75 text-[color:var(--color-muted)] transition hover:border-[color:var(--color-line-strong)] hover:bg-white/95 hover:text-[color:var(--color-ink)] focus-visible:ring-2 focus-visible:outline-none sm:h-auto sm:w-auto sm:gap-2 sm:px-3 sm:py-1.5 sm:text-sm`,type:`button`,onClick:i,children:[(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`absolute top-1/2 left-1/2 size-[max(100%,3rem)] -translate-1/2 pointer-fine:hidden`}),(0,d.jsx)(kt,{}),(0,d.jsx)(`span`,{className:`hidden sm:inline`,children:`Close`})]})]})
  }
function L(e){
  if(!e)
  return;
  let t=e.trim().replace(/\s+/g,` `);
  if(!(t.length<2))
  return t
  }
var jt=new Set([`relevance`,`name`,`providerKey`,`slug`,`syncedAt`]),Mt=new Set([`relevance`,`lastUpdated`,`modelKey`,`name`,`providerName`,`providerSlug`,`releaseDate`,`slug`]);
function R(e,t){
  if(e instanceof URLSearchParams){
    let n=e.get(t);
    return n===null?void 0:n
    }
  let n=e[t];
  return Array.isArray(n)?n[0]:n
  }
function Nt(e,t){
  if(e instanceof URLSearchParams)
  return[...e.getAll(t),...e.getAll(`${t}[]`)].filter(Boolean);
  let n=e[t]??e[`${t}[]`];
  return Array.isArray(n)?n.filter(e=>typeof e==`string`):typeof n==`string`?[n]:[]
  }
function z(e,t,n=1){
  let r=R(e,t)?.trim();
  if(!(!r||r.length<n))
  return r
  }
function B(e){
  let t=e.map(e=>e.trim().toLowerCase()).filter(e=>/^[a-z0-9][a-z0-9_-]{0,40}$/.test(e)),n=[...new Set(t)];
  return n.length>0?n:void 0
  }
function Pt(e,t){
  return B(Nt(e,t))
  }
function Ft(e){
  let t=L(e.search);
  return{...e,input:B(e.input??[]),output:B(e.output??[]),search:t||void 0}
  }
function It(e){
  let t=L(e.search);
  return{...e,input:B(e.input??[]),output:B(e.output??[]),search:t||void 0}
  }
function V(e,t){
  let n=R(e,t)?.toLowerCase();
  if(n){
    if([`1`,`true`,`yes`,`on`].includes(n))
    return!0;
    if([`0`,`false`,`no`,`off`].includes(n))
    return!1
    }
  }
function Lt(e,t,n,r,i){
  let a=Number.parseInt(R(e,t)??``,10);
  return Number.isFinite(a)?Math.min(Math.max(a,r),i):n
  }
function Rt(e,t){
  let n=R(e,t)?.trim();
  if(n)
  return/^\d{4}-\d{2}-\d{2}$/.test(n)?n:void 0
  }
function zt(e){
  let t=R(e,`dir`);
  return t===`asc`||t===`desc`?t:void 0
  }
function Bt(e){
  let t=R(e,`sort`);
  return Ft({search:z(e,`search`,2),providerKey:z(e,`providerKey`),slug:z(e,`slug`),name:z(e,`name`,2),npmPackage:z(e,`npmPackage`,2),logoIsDefault:V(e,`logoIsDefault`),input:Pt(e,`input`),output:Pt(e,`output`),family:z(e,`family`),attachment:V(e,`attachment`),reasoning:V(e,`reasoning`),toolCall:V(e,`toolCall`),temperature:V(e,`temperature`),openWeights:V(e,`openWeights`),structuredOutput:V(e,`structuredOutput`),status:z(e,`status`),sort:t&&jt.has(t)?t:void 0,dir:zt(e),page:Lt(e,`page`,1,1,999),itemsPerPage:Lt(e,`itemsPerPage`,24,1,100)})
  }
function Vt(e){
  let t=R(e,`sort`);
  return It({includeArchived:V(e,`includeArchived`),search:z(e,`search`,2),providerKey:z(e,`providerKey`),providerSlug:z(e,`providerSlug`),modelKey:z(e,`modelKey`),slug:z(e,`slug`),name:z(e,`name`,2),family:z(e,`family`,2),attachment:V(e,`attachment`),reasoning:V(e,`reasoning`),toolCall:V(e,`toolCall`),temperature:V(e,`temperature`),openWeights:V(e,`openWeights`),structuredOutput:V(e,`structuredOutput`),input:Pt(e,`input`),output:Pt(e,`output`),status:z(e,`status`),releaseDateAfter:Rt(e,`releaseDateAfter`),releaseDateBefore:Rt(e,`releaseDateBefore`),lastUpdatedAfter:Rt(e,`lastUpdatedAfter`),lastUpdatedBefore:Rt(e,`lastUpdatedBefore`),sort:t&&Mt.has(t)?t:void 0,dir:zt(e),page:Lt(e,`page`,1,1,999),itemsPerPage:Lt(e,`itemsPerPage`,24,1,100)})
  }
function Ht(e,t,n){
  n&&e.set(t,n)
  }
function Ut(e){
  let t=new URLSearchParams;
  Ht(t,`search`,e.search),e.perType&&t.set(`perType`,String(e.perType));
  for(
  let n
   of e.types??[])
  t.append(`types[]`,n);
  return t
  }
function Wt(e){
  let t=new URLSearchParams;
  for(
  let[n,r]
  of Object.entries(e)){
    if(r==null)
    continue;
    if(Array.isArray(r)){
      for(
      let e
       of r)
      e!=null&&t.append(n,String(e));
      continue
      }
    if(typeof r==`object`)
    continue;
    let e=typeof r==`boolean`?r?`1`:`0`:String(r);
    t.set(n,e)
    }
  return t.toString()
  }
function H(e){
  return typeof e==`object`&&!!e&&!Array.isArray(e)
  }
function Gt(e){
  return Array.isArray(e)&&e.every(e=>typeof e==`string`)
  }
function U(e){
  return e===null||typeof e==`boolean`
  }
function Kt(e){
  return e===null||typeof e==`number`
  }
function W(e){
  return e===null||typeof e==`string`
  }
async function qt(e){
  return(e.headers.get(`content-type`)??``).includes(`json`)?e.json().catch(()=>null):e.text()
  }
function Jt(e){
  return H(e)?H(e.error)?{details:e.error.details,message:typeof e.error.message==`string`?e.error.message:void 0,status:typeof e.error.status==`number`?e.error.status:void 0}:{message:typeof e.message==`string`?e.message:void 0,status:typeof e.status==`number`?e.status:void 0}:{}
  }
var Yt=class extends Error{
  status;details;constructor(e,t,n){
    super(e),this.status=t,this.details=n,this.name=`BrowserCatalogError`
    }
};
async function Xt(e,t){
  let n=await qt(e);
  if(e.ok){
    let e=t(n);
    if(e!==null)
    return e;
    throw new Yt(`Catalog service returned invalid data.`,502)
    }
  let r=Jt(n);
  throw new Yt(r.message??`Catalog request failed.`,r.status??e.status,r.details)
  }
function Zt(e){
  return!H(e)||!Array.isArray(e.items)||!H(e.meta)||!H(e.meta.appliedQuery)||typeof e.meta.count!=`number`||typeof e.meta.visibleCount!=`number`||typeof e.meta.page!=`number`||typeof e.meta.itemsPerPage!=`number`||typeof e.meta.hasNextPage!=`boolean`||typeof e.meta.hasPreviousPage!=`boolean`||e.meta.totalPages!==null&&typeof e.meta.totalPages!=`number`?null:e
  }
function Qt(e){
  return H(e)&&W(e.url)&&(e.localUrl===void 0||W(e.localUrl))&&(e.hash===void 0||W(e.hash))&&typeof e.isDefault==`boolean`
  }
function $t(e){
  return e===null||H(e)&&typeof e.dealSlug==`string`&&typeof e.dealName==`string`&&typeof e.category==`string`&&typeof e.label==`string`&&typeof e.ctaLabel==`string`&&typeof e.summary==`string`&&typeof e.affiliateUrl==`string`&&typeof e.officialUrl==`string`&&typeof e.sourceUpdatedAt==`string`
  }
function en(e){
  return H(e)&&typeof e.id==`string`&&typeof e.source==`string`&&typeof e.key==`string`&&typeof e.slug==`string`&&typeof e.name==`string`&&W(e.npmPackage)&&Gt(e.environmentVariables)&&W(e.syncedAt)&&Qt(e.logo)&&H(e.links)&&W(e.links.apiUrl)&&W(e.links.documentationUrl)&&Array.isArray(e.socialLinks)&&e.socialLinks.every(e=>H(e)&&typeof e.platform==`string`&&typeof e.label==`string`&&typeof e.url==`string`)&&$t(e.deal)
  }
function tn(e){
  return H(e)&&typeof e.id==`string`&&typeof e.source==`string`&&typeof e.modelKey==`string`&&typeof e.slug==`string`&&typeof e.name==`string`&&W(e.family)&&W(e.status)&&W(e.knowledgeCutoff)&&W(e.syncedAt)&&H(e.provider)&&typeof e.provider.key==`string`&&typeof e.provider.slug==`string`&&typeof e.provider.name==`string`&&H(e.capabilities)&&U(e.capabilities.attachment)&&U(e.capabilities.reasoning)&&U(e.capabilities.toolCall)&&U(e.capabilities.temperature)&&U(e.capabilities.openWeights)&&U(e.capabilities.structuredOutput)&&H(e.dates)&&W(e.dates.releaseDate)&&W(e.dates.lastUpdated)&&H(e.modalities)&&Gt(e.modalities.input)&&Gt(e.modalities.output)&&H(e.metadata)
  }
function nn(e){
  let t=Zt(e);
  return t?.items.every(en)?t:null
  }
function rn(e){
  let t=Zt(e);
  return t?.items.every(tn)?t:null
  }
function an(e){
  return H(e)&&typeof e.type==`string`&&typeof e.id==`string`&&typeof e.title==`string`&&W(e.subtitle)&&W(e.description)&&typeof e.href==`string`&&(e.slug===null||typeof e.slug==`string`)&&H(e.meta)
  }
function on(e){
  return!H(e)||typeof e.query!=`string`||typeof e.perType!=`number`||!Array.isArray(e.types)||!Array.isArray(e.providers)||!Array.isArray(e.models)||!Array.isArray(e.providerProfiles)||!Array.isArray(e.modelNews)||![...e.providers,...e.models,...e.providerProfiles,...e.modelNews].every(an)?null:e
  }
function sn(e){
  return(e instanceof DOMException||e instanceof Error)&&e.name===`AbortError`
  }
async function cn(e,t,n={},r=e=>e){
  let i=t?`${e}?${t}`:e;
  return Xt(await fetch(i,{cache:`no-store`,headers:{accept:`application/json`},signal:n.signal}).catch(e=>{
    throw sn(e)?e:new Yt(e instanceof Error?e.message:`Unable to reach the catalog service.`,503)
    }),r)
  }
function ln(e,t){
  return cn(`/_catalog/providers`,Wt(e),t,nn)
  }
function un(e,t){
  return cn(`/_catalog/models`,Wt(e),t,rn)
  }
function dn(e,t){
  return cn(`/_catalog/search`,Ut(e).toString(),t,on)
  }
function fn(e,t=200){
  let[n,r]=(0,u.useState)(e);
  return(0,u.useEffect)(()=>{
    let n=window.setTimeout(()=>{
      r(e)
      },t);
    return()=>window.clearTimeout(n)
    },[t,e]),n
  }
var pn={models:e=>[`catalog`,`models`,e],model:e=>[`catalog`,`model`,e],modelOverview:e=>[`catalog`,`model-overview`,e],modelOverviewRefresh:e=>[`catalog`,`model-overview-refresh`,e],modelNews:e=>[`catalog`,`model-news`,e],modelNewsRefreshes:e=>[`catalog`,`model-news-refreshes`,e],modelNewsRefresh:e=>[`catalog`,`model-news-refresh`,e],modelYouTubeVideos:e=>[`catalog`,`model-youtube-videos`,e],providerNews:e=>[`catalog`,`provider-news`,e],providerNewsRefreshes:e=>[`catalog`,`provider-news-refreshes`,e],commandSearch:e=>[`catalog`,`command`,`search`,e],providers:e=>[`catalog`,`providers`,e],provider:e=>[`catalog`,`provider`,e]},mn=e=>{
  let t,n=new Set,r=(e,r)=>{
    let i=typeof e==`function`?e(t):e;
    if(!Object.is(i,t)){
      let e=t;
      t=r??(typeof i!=`object`||!i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))
      }
    },i=()=>t,a={setState:r,getState:i,getInitialState:()=>o,subscribe:e=>(n.add(e),()=>n.delete(e))},o=t=e(r,i,a);
  return a
  },hn=(e=>e?mn(e):mn),gn=e=>e;
function _n(e,t=gn){
  let n=u.useSyncExternalStore(e.subscribe,u.useCallback(()=>t(e.getState()),[e,t]),u.useCallback(()=>t(e.getInitialState()),[e,t]));
  return u.useDebugValue(n),n
  }
var vn=e=>{
  let t=hn(e),n=e=>_n(t,e);
  return Object.assign(n,t),n
  },yn=(e=>e?vn(e):vn),bn=`command-palette`,G=yn()(e=>({activeModalId:null,setActiveModalId:t=>e({activeModalId:t}),openModal:t=>e({activeModalId:t}),closeModal:t=>e(e=>t===void 0||e.activeModalId===t?{activeModalId:null}:e),openCommandPalette:()=>e({activeModalId:bn}),closeCommandPalette:()=>e(e=>e.activeModalId===`command-palette`?{activeModalId:null}:e),toggleCommandPalette:()=>e(e=>({activeModalId:e.activeModalId===`command-palette`?null:bn}))}));
function xn(...e){
  return e.filter(Boolean).join(` `)
  }
var Sn=`⌘K / Ctrl K`;
function Cn(){
  return()=>{
    }
  }
function wn(){
  return Sn
  }
var Tn=[{label:`Providers`,type:`provider`,section:`providers`},{label:`Models`,type:`model`,section:`models`},{label:`Profiles`,type:`providerProfile`,section:`providerProfiles`},{label:`News`,type:`modelNews`,section:`modelNews`}];
function En(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M4 4l8 8M12 4l-8 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.4`})})
  }
function Dn(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4 shrink-0 text-[color:var(--color-muted)]`,viewBox:`0 0 24 24`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M3 10a7 7 0 1 0 14 0 7 7 0 1 0-14 0M21 21l-6-6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`2`})})
  }
function On(){
  if(typeof navigator>`u`)
  return Sn;
  let e=navigator.userAgentData?.platform??navigator.platform;
  return/mac|iphone|ipad|ipod/i.test(e)?`⌘K`:`Ctrl K`
  }
function kn({label:e,className:t}){
  return(0,d.jsx)(`span`,{className:xn(`items-center gap-1 rounded-full border border-[color:var(--color-line)] bg-white/85 px-2.5 py-1 text-[0.7rem] font-semibold tracking-[0.18em] text-[color:var(--color-muted)] uppercase`,t),children:e})
  }
function An(e){
  if(!(e instanceof HTMLElement))
  return!1;
  let t=e.tagName;
  return e.isContentEditable||e.closest(`[contenteditable='true']`)!==null||t===`INPUT`||t===`TEXTAREA`||t===`SELECT`
  }
function jn({activeTypes:e,onToggle:t}){
  return(0,d.jsx)(`div`,{"aria-label":`Filter quick search results by type`,className:`flex flex-wrap items-center justify-end gap-1.5`,children:Tn.map(n=>{
    let r=e.has(n.type);
    return(0,d.jsx)(`button`,{type:`button`,"aria-pressed":r,className:xn(`inline-flex items-center rounded-full border px-2.5 py-1 text-xs font-semibold transition`,r?`bg-accent/15 border-[color:var(--color-accent)] text-[color:var(--color-accent-deep)]`:`border-[color:var(--color-line)] bg-white/70 text-[color:var(--color-muted)] hover:border-[color:var(--color-line-strong)] hover:bg-white/95 hover:text-[color:var(--color-ink)]`),onClick:()=>t(n.type),children:(0,d.jsx)(`span`,{children:n.label})},n.type)
    })})
  }
function Mn({className:e,context:t=`header`}){
  let n=G(e=>e.openCommandPalette),r=(0,u.useSyncExternalStore)(Cn,On,wn);
  return(0,d.jsxs)(`button`,{type:`button`,"aria-label":`Search the catalog`,className:xn(`inline-flex items-center gap-3 rounded-full border border-[color:var(--color-line)] bg-white/85 text-[color:var(--color-ink)] transition hover:border-[color:var(--color-line-strong)] hover:bg-white/95`,t===`header`&&`min-h-11 min-w-11 px-3 py-2 text-sm sm:px-4`,t===`hero`&&`px-4 py-3 text-sm shadow-md`,e),onClick:()=>n(),children:[(0,d.jsx)(Dn,{}),(0,d.jsxs)(`span`,{className:xn(`text-left`,t===`header`&&`hidden sm:block`),children:[(0,d.jsx)(`span`,{className:`block text-sm font-medium lg:hidden`,children:`Search`}),(0,d.jsx)(`span`,{className:`hidden text-[0.68rem] font-semibold tracking-[0.22em] text-[color:var(--color-muted)] uppercase lg:block`,children:`Quick search`})]}),(0,d.jsx)(kn,{label:r,className:`hidden lg:inline-flex`})]})
  }
function Nn(){
  let e=(0,u.useRef)(null),t=G(e=>e.activeModalId===bn),r=G(e=>e.openCommandPalette),i=G(e=>e.closeCommandPalette),[a,o]=(0,u.useState)(``),[s,c]=(0,u.useState)(0),[l,f]=(0,u.useState)(()=>new Set),p=L(fn(a)),m=L(a),h=m!==void 0,g=m!==p,_=l.size>0?Tn.filter(e=>l.has(e.type)).map(e=>e.section):void 0,v=it({queryKey:pn.commandSearch({search:p,perType:3,types:_}),queryFn:({signal:e})=>dn({search:p,perType:3,types:_},{signal:e}),enabled:t&&h&&!g,retry:!1,staleTime:2e4}),y=(0,u.useMemo)(()=>{
    let e=v.data;
    if(!e||g||!h)
    return[];
    let t=new Set(e.providers.map(e=>e.href)),n=e.providerProfiles.filter(e=>!t.has(e.href));
    return[...e.providers,...e.models,...n,...e.modelNews]
    },[v.data,g,h]),b=(0,u.useMemo)(()=>l.size===0?y:y.filter(e=>l.has(e.type)),[l,y]);
  (0,u.useEffect)(()=>{
    if(!t)
    return;
    let n=window.requestAnimationFrame(()=>{
      e.current?.focus(),e.current?.select()
      });
    return()=>window.cancelAnimationFrame(n)
    },[t]);
  let x=()=>{
    f(e=>e.size===0?e:new Set)
    },S=e=>{
    if(i(),e.startsWith(`https://`)||e.startsWith(`http://`)){
      window.location.assign(e);
      return
      }
    (0,u.startTransition)(()=>{
      n.visit(e),o(``),c(0),x()
      })
    },C=e=>{
    f(t=>{
      let n=new Set(t);
      return n.has(e)?n.delete(e):n.add(e),n
      }),c(0)
    };
  if((0,u.useEffect)(()=>{
    let e=e=>{
      if((e.metaKey||e.ctrlKey)&&e.key.toLowerCase()===`k`){
        if(An(e.target))
        return;
        e.preventDefault(),r()
        }
      };
    return window.addEventListener(`keydown`,e),()=>window.removeEventListener(`keydown`,e)
    },[r]),!t)
  return null;
  let w=g||v.isFetching,T=!g&&v.isError,E=b.length>0?Math.min(s,b.length-1):-1,D=E>=0?b[E]:void 0,O=l.size>0;
  return(0,d.jsx)(I,{ariaLabel:`quick search`,className:`items-start justify-center sm:items-center`,onClose:i,panelClassName:`surface-panel max-w-3xl rounded-[1.6rem] p-3 sm:rounded-[2rem] sm:p-5`,children:(0,d.jsxs)(`div`,{className:`grid gap-3.5 sm:gap-5`,children:[(0,d.jsx)(`div`,{className:`rounded-[1.3rem] border border-[color:var(--color-line)] bg-white/90 p-2 sm:rounded-[1.6rem] sm:p-3 dark:bg-white/5`,children:(0,d.jsxs)(`div`,{className:`grid grid-cols-[minmax(0,1fr)_auto] items-center gap-2`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`label`,{className:`sr-only`,htmlFor:`command-search`,children:`Search the catalog`}),(0,d.jsx)(`input`,{ref:e,id:`command-search`,type:`search`,value:a,placeholder:`Search the catalog`,className:`field-input pr-4`,onChange:e=>{
    o(e.target.value),c(0)
    },onKeyDown:e=>{
    if(e.key===`ArrowDown`&&b.length>0){
      e.preventDefault(),c((E+1)%b.length);
      return
      }
    if(e.key===`ArrowUp`&&b.length>0){
      e.preventDefault(),c(E<=0?b.length-1:E-1);
      return
      }
    e.key===`Enter`&&D&&(e.preventDefault(),S(D.href))
    }})]}),(0,d.jsx)(`button`,{type:`button`,"aria-label":`Close quick search`,className:`inline-flex size-10 items-center justify-center rounded-full border border-[color:var(--color-line)] bg-white/75 text-[color:var(--color-muted)] transition hover:border-[color:var(--color-line-strong)] hover:bg-white/95 hover:text-[color:var(--color-ink)] dark:bg-white/5`,onClick:i,children:(0,d.jsx)(En,{})})]})}),(0,d.jsxs)(`div`,{className:`grid gap-4`,children:[h?(0,d.jsx)(Dt,{activeIndex:E,emptyState:O?`No matches for the selected result types. Clear a filter or try a broader search.`:`No matches. Try a broader model name, provider, or exact identifier, or select News to search articles.`,errorState:`Quick search is temporarily unavailable. You can still use the full model and provider explorer pages below.`,hasError:T,isLoading:w,headerDetail:(0,d.jsx)(jn,{activeTypes:l,onToggle:C}),headerSummary:w?`Searching…`:`${b.length} quick matches`,onResultClick:e=>S(e.href),onResultHover:c,results:b}):null,(0,d.jsxs)(`div`,{className:`grid grid-cols-1 gap-2 sm:flex sm:flex-wrap sm:gap-3`,children:[(0,d.jsxs)(`button`,{type:`button`,className:`button-secondary justify-center`,onClick:()=>S(p?`/models?search=${encodeURIComponent(p)}`:`/models`),children:[`Open model explorer`,(0,d.jsx)(Tt,{})]}),(0,d.jsxs)(`button`,{type:`button`,className:`button-secondary justify-center`,onClick:()=>S(p?`/providers?search=${encodeURIComponent(p)}`:`/providers`),children:[`Open provider explorer`,(0,d.jsx)(Tt,{})]})]})]})]})})
  }
function Pn(...e){
  return e.filter(Boolean).join(` `)
  }
function Fn(e){
  return e.trim().toLowerCase()
  }
function In(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M3.5 4.25A1.75 1.75 0 0 1 5.25 2.5h5.5A1.75 1.75 0 0 1 12.5 4.25v4.5A1.75 1.75 0 0 1 10.75 10.5H7.5l-2.5 2v-2H5.25A1.75 1.75 0 0 1 3.5 8.75v-4.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M6 5.75h4M6 7.75h2.75`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`})]})
  }
function Ln(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`rect`,{x:`2.5`,y:`3`,width:`11`,height:`10`,rx:`2`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`circle`,{cx:`5.5`,cy:`6`,r:`1.1`,fill:`currentColor`}),(0,d.jsx)(`path`,{d:`m4 11 2.5-2.5L8.5 10l1.25-1.25L12 11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})]})
  }
function Rn(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M5 2.75h4.5L12.5 5.8v7.45a1.5 1.5 0 0 1-1.5 1.5H5a1.5 1.5 0 0 1-1.5-1.5v-9a1.5 1.5 0 0 1 1.5-1.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M9.5 2.75v3h3`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M5.75 10.25h4.5M5.75 12h3`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`})]})
  }
function zn(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M3.75 9.5V6.5M6 11.25v-6.5M8.25 9.5V6.5M10.5 12V4M12.75 9.5V6.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`})})
  }
function Bn(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`rect`,{x:`2.5`,y:`3.5`,width:`8`,height:`9`,rx:`1.8`,stroke:`currentColor`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`m8 8-2 1.3V6.7L8 8ZM10.5 7l2.5-1.5v5L10.5 9`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})]})
  }
function Vn(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M8 2.75a3.75 3.75 0 0 0-2.6 6.45c.37.34.6.81.6 1.31v.24h4v-.24c0-.5.23-.97.6-1.31A3.75 3.75 0 0 0 8 2.75Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M6.5 12h3M6.75 13.5h2.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M6.8 6.2h2.4L7.8 8.05h1.4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.2`})]})
  }
function Hn(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M6.25 5.25H4.5A1.75 1.75 0 0 0 2.75 7v.5c0 .97.78 1.75 1.75 1.75h1.75M9.75 5.25h1.75c.97 0 1.75.78 1.75 1.75v.5c0 .97-.78 1.75-1.75 1.75H9.75`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M6 8h4`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M6.5 3.25h3v9.5h-3z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`})]})
  }
function Un(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M5 3.5H3.75v9H5M11 3.5h1.25v9H11`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M6.75 5.25h2.5M6.75 8h2.5M6.75 10.75h2.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`})]})
  }
function Wn(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M8 3.25v6.5M5 5.25h6M6 8h4M7 10.75h2`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M8 13a1.5 1.5 0 1 0 0-3 1.5 1.5 0 0 0 0 3Z`,stroke:`currentColor`,strokeWidth:`1.3`})]})
  }
function Gn(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`m6 8.75 3.45-3.45a2 2 0 1 1 2.83 2.83L7.76 12.65a3 3 0 0 1-4.24-4.24l4.4-4.4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})})
  }
function Kn(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M8 2.75 12.5 5v6L8 13.25 3.5 11V5L8 2.75Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M8 2.75V7.9m4.5-2.9L8 7.9 3.5 5`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`})]})
  }
function qn(e){
  switch(Fn(e)){case`text`:
  return{title:`What does text mean?`,accentClasses:`bg-stone-700/15 text-stone-700 dark:bg-stone-200/10 dark:text-stone-200`,icon:(0,d.jsx)(In,{}),entries:[{term:`Text`,description:`means the model can work with written language such as prompts, chat replies, summaries, code, or documents written in words.`},{term:`Think of it like`,description:`passing notes back and forth in a conversation. The model reads your note and replies with another note.`}],note:`If you see this under input modalities, the model can read text. If you see it under output modalities, the model can answer with text.`};
  case`image`:
  return{title:`What does image mean?`,accentClasses:`bg-lime-700/15 text-lime-800 dark:bg-lime-300/12 dark:text-lime-200`,icon:(0,d.jsx)(Ln,{}),entries:[{term:`Image`,description:`means the model can work with pictures, screenshots, diagrams, or photos instead of relying on words alone.`},{term:`Think of it like`,description:`showing an assistant a whiteboard photo or product mockup instead of trying to describe every visual detail out loud.`}],note:`In an input row, this means the model can inspect images. In an output row, it means the model can generate or return images.`};
  case`pdf`:
  return{title:`What does PDF mean?`,accentClasses:`bg-rose-700/15 text-rose-800 dark:bg-rose-300/12 dark:text-rose-200`,icon:(0,d.jsx)(Rn,{}),entries:[{term:`PDF`,description:`means the model can work with PDF documents, which is useful when layout, page structure, or the original file matters.`},{term:`Think of it like`,description:`handing someone the full report binder instead of copy-pasting random paragraphs into a chat box.`}],note:`Provider limits still matter here. A model may support PDFs but cap file size, page count, or total tokenized content.`};
  case`audio`:
  return{title:`What does audio mean?`,accentClasses:`bg-blue-700/15 text-blue-800 dark:bg-blue-300/12 dark:text-blue-200`,icon:(0,d.jsx)(zn,{}),entries:[{term:`Audio`,description:`means the model can work with sound such as spoken language, recordings, voice notes, or other audio clips.`},{term:`Think of it like`,description:`speaking to an assistant instead of typing, or receiving a spoken answer back instead of reading text.`}],note:`In input modalities, audio means the model can listen. In output modalities, it means the model can speak or generate sound.`};
  case`video`:
  return{title:`What does video mean?`,accentClasses:`bg-purple-700/15 text-purple-800 dark:bg-purple-300/12 dark:text-purple-200`,icon:(0,d.jsx)(Bn,{}),entries:[{term:`Video`,description:`means the model can work with moving visual sequences, not just a single still image. That can include clips, demos, or recorded scenes.`},{term:`Think of it like`,description:`handing over a short film clip instead of one photo, so the model can use motion and timing as part of the context.`}],note:`Video support often comes with stricter limits than text or image support, because clips contain much more information.`};
  default:
  return null
  }
  }
function Jn(e){
  switch(Fn(e)){case`reasoning`:
  return{title:`What is reasoning?`,accentClasses:`bg-amber-800/15 text-amber-900 dark:bg-amber-300/12 dark:text-amber-200`,icon:(0,d.jsx)(Vn,{}),entries:[{term:`Reasoning`,description:`means the model can spend extra effort working through a problem before it answers, which often helps with multi-step logic, planning, math, and careful comparisons.`},{term:`Think of it like`,description:`letting someone use scratch paper before they answer instead of forcing an instant response from memory.`}],note:`Reasoning can improve hard tasks, but it may also make the response slower or more expensive depending on the provider.`};
  case`tool calling`:
  return{title:`What is tool calling?`,accentClasses:`bg-sky-800/15 text-sky-800 dark:bg-sky-300/12 dark:text-sky-200`,icon:(0,d.jsx)(Hn,{}),entries:[{term:`Tool calling`,description:`means the model can ask connected software to do a step on its behalf, such as running a search, checking a database, or calling an API.`},{term:`Think of it like`,description:`an assistant who knows when to pick up the phone, ask another department for the missing fact, and then come back with the result.`}],note:`The capability does not grant tools automatically. Your application still has to provide the tools the model is allowed to call.`};
  case`structured output`:
  return{title:`What is structured output?`,accentClasses:`bg-emerald-800/15 text-emerald-800 dark:bg-emerald-300/12 dark:text-emerald-200`,icon:(0,d.jsx)(Un,{}),entries:[{term:`Structured output`,description:`means the model is better suited to return answers in a machine-readable shape, such as fixed fields, JSON objects, or a defined schema.`},{term:`Think of it like`,description:`asking someone to fill in a form with named boxes instead of sending you a free-form email you have to interpret by hand.`}],note:`This is especially useful when software needs to parse the answer automatically instead of showing it only to a human.`};
  case`attachments`:
  return{title:`What are attachments?`,accentClasses:`bg-violet-700/15 text-violet-800 dark:bg-violet-300/12 dark:text-violet-200`,icon:(0,d.jsx)(Gn,{}),entries:[{term:`Attachments`,description:`means the model can work with uploaded files or provider-managed attachments in addition to plain text messages.`},{term:`Think of it like`,description:`handing an assistant the actual folder, image, or document instead of reading every detail aloud line by line.`}],note:`Exact file types, size limits, and upload behavior still vary by provider even when the capability is present.`};
  case`open weights`:
  return{title:`What are open weights?`,accentClasses:`bg-sky-700/15 text-sky-800 dark:bg-sky-300/12 dark:text-sky-200`,icon:(0,d.jsx)(Kn,{}),entries:[{term:`Open weights`,description:`means the model weights are available for others to download, self-host, fine-tune, or inspect more directly than a closed hosted-only model.`},{term:`Think of it like`,description:`getting the recipe and ingredients, not just being served the finished meal at the restaurant.`}],note:`Open weights does not always mean the license is unrestricted. Deployment and commercial rights still depend on the model's terms.`};
  case`temp controls`:
  return{title:`What are temperature controls?`,accentClasses:`bg-orange-700/15 text-orange-800 dark:bg-orange-300/12 dark:text-orange-200`,icon:(0,d.jsx)(Wn,{}),entries:[{term:`Temperature controls`,description:`means the caller can adjust how predictable or varied the model's responses should be, usually with a temperature setting.`},{term:`Think of it like`,description:`a creativity dial: turn it down when you want steadier, repeatable answers, or turn it up when you want more variation and brainstorming.`}],note:`Lower settings usually help with consistency. Higher settings can be useful for ideation, but they can also make outputs less stable.`};
  default:
  return null
  }
  }
function Yn(e){
  let t=qn(e);
  return t===null?null:{accentClasses:t.accentClasses,icon:t.icon}
  }
function Xn(e,t){
  switch(e){case`capability`:
  return Jn(t);
  case`modality`:
  return qn(t)
  }
  }
function Zn({kind:e,value:t}){
  let n=Xn(e,t),r=(0,u.useId)(),i=(0,u.useId)(),a=G(e=>e.activeModalId),o=G(e=>e.openModal),s=G(e=>e.closeModal),c=a===i,l=(0,d.jsxs)(d.Fragment,{children:[n?(0,d.jsx)(`span`,{className:Pn(`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full`,n.accentClasses),children:n.icon}):null,(0,d.jsx)(`span`,{children:t})]}),f=Pn(`inline-flex items-center rounded-full border border-[color:var(--color-line)] bg-white/80 text-[0.82rem] leading-none text-[color:var(--color-ink)]`,n?`gap-1.5 py-1 pl-1.5 pr-2.5`:`px-2.5 py-1`);
  if(!n)
  return(0,d.jsx)(`span`,{className:f,children:l});
  let p=()=>s(i);
  return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`button`,{"aria-controls":i,"aria-expanded":c,"aria-haspopup":`dialog`,"aria-label":n.title,className:Pn(f,`focus-visible:ring-accent/15 cursor-pointer text-left transition hover:-translate-y-px hover:border-[color:var(--color-line-strong)] hover:bg-white/95 focus-visible:ring-2 focus-visible:outline-none`),title:n.title,type:`button`,onClick:()=>o(i),children:l}),c?(0,d.jsx)(I,{ariaLabel:n.title,ariaLabelledBy:r,className:`items-center justify-center`,onClose:p,panelClassName:`surface-panel mx-auto max-w-lg rounded-[2rem] p-5 sm:p-6`,children:(0,d.jsxs)(`div`,{id:i,className:`grid gap-4`,children:[(0,d.jsx)(At,{eyebrow:`Model terminology`,onClose:p,title:n.title,titleId:r}),(0,d.jsxs)(`div`,{className:`text-sm leading-7 text-[color:var(--color-muted)]`,children:[n.entries.map((e,t)=>(0,d.jsxs)(`p`,{className:t===0?void 0:`mt-2`,children:[(0,d.jsx)(`strong`,{className:`text-[color:var(--color-ink)]`,children:e.term}),` `,e.description]},e.term)),(0,d.jsx)(`p`,{className:`mt-2`,children:n.note})]})]})}):null]})
  }
function Qn(...e){
  return e.filter(Boolean).join(` `)
  }
function $n({labels:e,className:t,emptyLabel:n}){
  return e.length===0?n?(0,d.jsx)(`span`,{children:n}):null:(0,d.jsx)(`div`,{className:Qn(`flex flex-wrap gap-2`,t),children:e.map(e=>(0,d.jsx)(Zn,{kind:`capability`,value:e},e))})
  }
function er(...e){
  return e.filter(Boolean).join(` `)
  }
function tr(e){
  switch(e){case`provider`:
  return`bg-blue-700/15 text-blue-800 dark:bg-blue-300/12 dark:text-blue-200`;
  case`docs`:
  return`bg-stone-700/15 text-stone-700 dark:bg-stone-200/10 dark:text-stone-200`;
  case`api`:
  return`bg-lime-700/15 text-lime-800 dark:bg-lime-300/12 dark:text-lime-200`
  }
  }
var nr=`inline-flex items-center gap-1.5 rounded-full border border-[color:var(--color-line)] bg-white/80 py-1 pl-1.5 pr-2.5 text-[0.82rem] leading-none text-[color:var(--color-ink)] transition hover:-translate-y-px hover:border-[color:var(--color-line-strong)] hover:bg-white/95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/15`;
function rr({icon:e,label:t,tone:n}){
  return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`span`,{className:er(`inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full`,tr(n)),children:e}),(0,d.jsx)(`span`,{children:t})]})
  }
function ir(e){
  let[t,n]=(0,u.useState)(!1);
  (0,u.useEffect)(()=>{
    if(!t)
    return;
    let e=window.setTimeout(()=>{
      n(!1)
      },1600);
    return()=>{
      window.clearTimeout(e)
      }
    },[t]);
  async function r(){
    try{
      await navigator.clipboard.writeText(e),n(!0)
      }catch{
      n(!1)
      }
    }
  return{copied:t,handleCopy:r}
  }
function ar({href:e,icon:t,label:n,tone:r}){
  return(0,d.jsx)(s,{className:nr,href:e,children:(0,d.jsx)(rr,{icon:t,label:n,tone:r})})
  }
function or({href:e,icon:t,label:n,tone:r}){
  return(0,d.jsx)(`a`,{className:nr,href:e,rel:`noreferrer`,target:`_blank`,children:(0,d.jsx)(rr,{icon:t,label:n,tone:r})})
  }
function sr({value:e,icon:t,label:n,copiedLabel:r=`Copied`,tone:i}){
  let{copied:a,handleCopy:o}=ir(e);
  return(0,d.jsx)(`button`,{className:nr,onClick:o,title:e,type:`button`,children:(0,d.jsx)(rr,{icon:t,label:a?r:n,tone:i})})
  }
function cr({value:e,label:t,copiedLabel:n=`Copied`}){
  let{copied:r,handleCopy:i}=ir(e);
  return(0,d.jsx)(`button`,{className:`button-quiet`,onClick:i,title:e,type:`button`,children:r?n:t})
  }
function lr(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M4.5 3.25h5.25l1.75 1.9v6.6a1.5 1.5 0 0 1-1.5 1.5h-5.5A1.5 1.5 0 0 1 3 11.75v-7a1.5 1.5 0 0 1 1.5-1.5Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M9.75 3.25v2h1.75M5.25 7h4M5.25 9h4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})]})
  }
function ur(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`4`,cy:`8`,r:`1.4`,fill:`currentColor`}),(0,d.jsx)(`circle`,{cx:`12`,cy:`4`,r:`1.4`,fill:`currentColor`}),(0,d.jsx)(`circle`,{cx:`12`,cy:`12`,r:`1.4`,fill:`currentColor`}),(0,d.jsx)(`path`,{d:`M5.4 7.25 10.6 4.75M5.4 8.75l5.2 2.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`})]})
  }
function dr(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M3 8h6.5m0 0L7 5.5M9.5 8 7 10.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M13 11.25v.25A1.5 1.5 0 0 1 11.5 13h-7A1.5 1.5 0 0 1 3 11.5v-7A1.5 1.5 0 0 1 4.5 3h7A1.5 1.5 0 0 1 13 4.5v.25`,stroke:`currentColor`,strokeWidth:`1.3`})]})
  }
function fr({fill:e=!1,priority:t=!1,unoptimized:n,width:r,height:i,style:a,...o}){
  return(0,d.jsx)(`img`,{...o,width:e?void 0:r,height:e?void 0:i,loading:t?`eager`:o.loading,fetchPriority:t?`high`:o.fetchPriority,style:e?{...a,position:`absolute`,inset:0,width:`100%`,height:`100%`}:a})
  }
function pr(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`circle`,{cx:`8`,cy:`8`,r:`6`,stroke:`currentColor`,strokeWidth:`1.2`}),(0,d.jsx)(`path`,{d:`M8 7.1v3.2M8 5.2h.01`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.2`})]})
  }
function K({eyebrow:e,title:t,triggerLabel:n,entries:r,note:i}){
  let a=(0,u.useId)(),o=(0,u.useId)(),s=(0,u.useId)(),c=G(e=>e.activeModalId),l=G(e=>e.openModal),f=G(e=>e.closeModal),p=c===s,m=()=>f(s);
  return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsxs)(`button`,{className:`button-quiet`,type:`button`,onClick:()=>l(s),children:[(0,d.jsx)(pr,{}),n]}),p?(0,d.jsx)(I,{ariaLabel:t,ariaDescribedBy:a,ariaLabelledBy:o,className:`items-center justify-center`,onClose:m,panelClassName:`surface-panel mx-auto max-w-lg rounded-[2rem] p-5 sm:p-6`,children:(0,d.jsxs)(`div`,{className:`grid gap-4`,children:[(0,d.jsx)(At,{eyebrow:e,onClose:m,title:t,titleId:o}),(0,d.jsxs)(`div`,{id:a,className:`text-sm leading-7 text-[color:var(--color-muted)]`,children:[r.map((e,t)=>(0,d.jsxs)(`p`,{className:t===0?void 0:`mt-2`,children:[(0,d.jsx)(`strong`,{className:`text-[color:var(--color-ink)]`,children:e.term}),` `,e.description]},e.term)),i?(0,d.jsx)(`p`,{className:`mt-2`,children:i}):null]})]})}):null]})
  }
function mr(...e){
  return e.filter(Boolean).join(` `)
  }
function hr({values:e,className:t,emptyLabel:n=`Unknown`}){
  return e.length===0?(0,d.jsx)(`span`,{children:n}):(0,d.jsx)(`div`,{className:mr(`flex flex-wrap gap-2`,t),children:e.map(e=>(0,d.jsx)(Zn,{kind:`modality`,value:e},e))})
  }
var gr=new Set([`queued`,`processing`]),_r=300*1e3;
function vr(e){
  return e?gr.has(e.status):!1
  }
function yr(e){
  return e?gr.has(e.status):!1
  }
function br(e,t=Date.now()){
  if(!e||!yr(e))
  return!1;
  let n=e.startedAt??e.requestedAt;
  if(!n)
  return!1;
  let r=Date.parse(n);
  return Number.isFinite(r)&&t-r>=_r
  }
function xr(e,t=Date.now()){
  return yr(e)&&!br(e,t)
  }
function Sr(e,t=Date.now()){
  return vr(e)?!e?.refresh||xr(e.refresh,t):!1
  }
function Cr(e){
  return(e?.paragraphs.length??0)===2
  }
var wr=Array.from({length:2},(e,t)=>`overview-skeleton-${t}`);
function Tr(e){
  return e===2?wr:Array.from({length:e},(e,t)=>`overview-skeleton-${t}`)
  }
function Er({className:e=``,label:t=`Loading model overview`,rows:n=2}){
  return(0,d.jsxs)(`div`,{"aria-live":`polite`,"aria-label":t,className:[`max-w-3xl space-y-4`,e].filter(Boolean).join(` `),role:`status`,children:[(0,d.jsx)(`span`,{className:`sr-only`,children:t}),Tr(n).map(e=>(0,d.jsxs)(`div`,{className:`space-y-2`,children:[(0,d.jsx)(`div`,{className:`h-4 w-full animate-pulse rounded-full bg-neutral-950/10`}),(0,d.jsx)(`div`,{className:`h-4 w-11/12 animate-pulse rounded-full bg-neutral-500/15`}),(0,d.jsx)(`div`,{className:`h-4 w-4/5 animate-pulse rounded-full bg-neutral-500/15`})]},e))]})
  }
function Dr({label:e}){
  return(0,d.jsx)(`div`,{className:`results-loading-overlay`,children:(0,d.jsx)(Er,{className:`w-full`,label:e})})
  }
function Or({mode:e=`limits`}){
  let t=e===`cost`;
  return(0,d.jsx)(K,{eyebrow:t?`Pricing terminology`:`Model terminology`,title:t?`What these token costs mean`:`What these token terms mean`,triggerLabel:`What do these mean?`,entries:t?[{term:`Input token cost`,description:`is what the provider charges for the tokens you send into the model with your prompt, instructions, or files.`},{term:`Output token cost`,description:`is what the provider charges for the tokens the model generates back in its response.`}]:[{term:`Input tokens`,description:`are the tokens you send into the model with your prompt, instructions, or files.`},{term:`Output tokens`,description:`are the tokens the model can generate back in its response.`},{term:`Context window`,description:`is the total amount of input and output the model can keep in view at once.`}],note:t?`These prices are quoted per 1 million tokens. As a rough sense of scale, 1 million tokens is about 750,000 English words: roughly a 1,500-page single-spaced manuscript, or about the first five Harry Potter novels combined. Providers often price input and output tokens separately, so the two rates can differ.`:void 0})
  }
var kr=`/globe-dark.svg`;
function Ar(e){
  return e.logo.localUrl??e.logo.url??null
  }
function jr(e){
  return Ar(e)??`/globe.svg`
  }
function Mr(e){
  return!!Ar(e)
  }
function q(e){
  "@babel/helpers - typeof";
  return q=typeof Symbol==`function`&&typeof Symbol.iterator==`symbol`?function(e){
    return typeof e
    }:function(e){
    return e&&typeof Symbol==`function`&&e.constructor===Symbol&&e!==Symbol.prototype?`symbol`:typeof e
    },q(e)
  }
var Nr=[`aria-hidden`,`aria-label`,`aria-labelledby`,`tabIndex`,`className`,`fill`,`size`,`verticalAlign`,`id`,`title`,`style`];
function Pr(){
  return Pr=Object.assign?Object.assign.bind():function(e){
    for(
    var t=1
    ;t<arguments.length;t++){
      var n=arguments[t];
      for(
      var r
       in n)
      ({}).hasOwnProperty.call(n,r)&&(e[r]=n[r])
      }
    return e
    },Pr.apply(null,arguments)
  }
function Fr(e,t){
  var n=Object.keys(e);
  if(Object.getOwnPropertySymbols){
    var r=Object.getOwnPropertySymbols(e);
    t&&(r=r.filter(function(t){
      return Object.getOwnPropertyDescriptor(e,t).enumerable
      })),n.push.apply(n,r)
    }
  return n
  }
function Ir(e){
  for(
  var t=1
  ;t<arguments.length;t++){
    var n=arguments[t]==null?{}:arguments[t];
    t%2?Fr(Object(n),!0).forEach(function(t){
      Lr(e,t,n[t])
      }):Object.getOwnPropertyDescriptors?Object.defineProperties(e,Object.getOwnPropertyDescriptors(n)):Fr(Object(n)).forEach(function(t){
      Object.defineProperty(e,t,Object.getOwnPropertyDescriptor(n,t))
      })
    }
  return e
  }
function Lr(e,t,n){
  return(t=Rr(t))in e?Object.defineProperty(e,t,{value:n,enumerable:!0,configurable:!0,writable:!0}):e[t]=n,e
  }
function Rr(e){
  var t=zr(e,`string`);
  return q(t)==`symbol`?t:t+``
  }
function zr(e,t){
  if(q(e)!=`object`||!e)
  return e;
  var n=e[Symbol.toPrimitive];
  if(n!==void 0){
    var r=n.call(e,t||`default`);
    if(q(r)!=`object`)
    return r;
    throw TypeError(`@@toPrimitive must return a primitive value.`)
    }
  return(t===`string`?String:Number)(e)
  }
function Br(e,t){
  if(e==null)
  return{};
  var n,r,i=Vr(e,t);
  if(Object.getOwnPropertySymbols){
    var a=Object.getOwnPropertySymbols(e);
    for(r=0;r<a.length;r++)
    n=a[r],t.indexOf(n)===-1&&{}.propertyIsEnumerable.call(e,n)&&(i[n]=e[n])
    }
  return i
  }
function Vr(e,t){
  if(e==null)
  return{};
  var n={};
  for(
  var r
   in e)
  if({}.hasOwnProperty.call(e,r)){
    if(t.indexOf(r)!==-1)
    continue;
    n[r]=e[r]
    }
  return n
  }
var Hr={small:16,medium:32,large:64};
function Ur(e,t,n,r,i){
  var a=e[`aria-hidden`],o=e[`aria-label`],s=e[`aria-labelledby`],c=e.tabIndex,l=e.className,d=l===void 0?``:l,f=e.fill,p=f===void 0?`currentColor`:f,m=e.size,h=m===void 0?16:m,g=e.verticalAlign,_=g===void 0?`text-bottom`:g,v=e.id,y=e.title,b=e.style,x=Br(e,Nr),S=Hr[h]||h,C=Wr(i,S),w=r[C].width,T=w/C*S,E=r[C].path,D=o||s,O=a===void 0?D?void 0:`true`:a,ee=D&&O!==`true`?`img`:void 0;
  return u.createElement(`svg`,Pr({ref:t,"data-component":`Octicon`},x,{"aria-hidden":O,tabIndex:c,focusable:c>=0?`true`:`false`,"aria-label":o,"aria-labelledby":s,className:`${n} ${d}`.trim(),role:ee,viewBox:`0 0 ${w} ${C}`,width:T,height:S,fill:p,id:v,display:`inline-block`,overflow:`visible`,style:Ir({verticalAlign:_},b)}),y?u.createElement(`title`,null,y):null,E)
  }
function Wr(e,t){
  return e.map(function(e){
    return parseInt(e,10)
    }).reduce(function(e,n){
    return n<=t?n:e
    },e[0])
  }
var Gr=[`12`,`16`,`24`],Kr={12:{width:12,path:u.createElement(`path`,{d:`M3.587 6.025c0 .2.1.4.2.5l3.3 3.3c.3.3.8.3 1.1 0 .3-.3.3-.8 0-1.1l-2.7-2.7 2.7-2.7c.3-.3.3-.8 0-1.1-.3-.3-.8-.3-1.1 0l-3.2 3.2c-.2.2-.3.4-.3.6Z`})},16:{width:16,path:u.createElement(`path`,{d:`M9.78 12.78a.75.75 0 0 1-1.06 0L4.47 8.53a.75.75 0 0 1 0-1.06l4.25-4.25a.751.751 0 0 1 1.042.018.751.751 0 0 1 .018 1.042L6.06 8l3.72 3.72a.75.75 0 0 1 0 1.06Z`})},24:{width:24,path:u.createElement(`path`,{d:`M15.28 5.22a.75.75 0 0 1 0 1.06L9.56 12l5.72 5.72a.749.749 0 0 1-.326 1.275.749.749 0 0 1-.734-.215l-6.25-6.25a.75.75 0 0 1 0-1.06l6.25-6.25a.75.75 0 0 1 1.06 0Z`})}},qr=u.forwardRef(function(e,t){
  return Ur(e,t,`octicon octicon-chevron-left`,Kr,Gr)
  });
qr.displayName=`ChevronLeftIcon`;
var Jr=[`12`,`16`,`24`],Yr={12:{width:12,path:u.createElement(`path`,{d:`M4.7 10c-.2 0-.4-.1-.5-.2-.3-.3-.3-.8 0-1.1L6.9 6 4.2 3.3c-.3-.3-.3-.8 0-1.1.3-.3.8-.3 1.1 0l3.3 3.2c.3.3.3.8 0 1.1L5.3 9.7c-.2.2-.4.3-.6.3Z`})},16:{width:16,path:u.createElement(`path`,{d:`M6.22 3.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.751.751 0 0 1-1.042-.018.751.751 0 0 1-.018-1.042L9.94 8 6.22 4.28a.75.75 0 0 1 0-1.06Z`})},24:{width:24,path:u.createElement(`path`,{d:`M8.72 18.78a.75.75 0 0 1 0-1.06L14.44 12 8.72 6.28a.751.751 0 0 1 .018-1.042.751.751 0 0 1 1.042-.018l6.25 6.25a.75.75 0 0 1 0 1.06l-6.25 6.25a.75.75 0 0 1-1.06 0Z`})}},Xr=u.forwardRef(function(e,t){
  return Ur(e,t,`octicon octicon-chevron-right`,Yr,Jr)
  });
Xr.displayName=`ChevronRightIcon`;
var Zr=[`16`,`24`],Qr={16:{width:16,path:u.createElement(`path`,{d:`M2.002 2.725a.75.75 0 0 1 .797-.699C8.79 2.42 13.58 7.21 13.974 13.201a.75.75 0 0 1-1.497.098 10.502 10.502 0 0 0-9.776-9.776.747.747 0 0 1-.7-.798ZM2.84 7.05h-.002a7.002 7.002 0 0 1 6.113 6.111.75.75 0 0 1-1.49.178 5.503 5.503 0 0 0-4.8-4.8.75.75 0 0 1 .179-1.489ZM2 13a1 1 0 1 1 2 0 1 1 0 0 1-2 0Z`})},24:{width:24,path:u.createElement(`path`,{d:`M3.5 3.25a.75.75 0 0 1 .75-.75C14.053 2.5 22 10.447 22 20.25a.75.75 0 0 1-1.5 0C20.5 11.275 13.225 4 4.25 4a.75.75 0 0 1-.75-.75Zm.75 6.25C10.187 9.5 15 14.313 15 20.25a.75.75 0 0 1-1.5 0A9.25 9.25 0 0 0 4.25 11a.75.75 0 0 1 0-1.5ZM3.5 19a2 2 0 1 1 3.999-.001A2 2 0 0 1 3.5 19Z`})}},$r=u.forwardRef(function(e,t){
  return Ur(e,t,`octicon octicon-rss`,Qr,Zr)
  });
$r.displayName=`RssIcon`;
var ei=`relative inline-flex size-8 items-center justify-center rounded-full text-[color:var(--color-muted)] hover:bg-neutral-950/4 hover:text-[color:var(--color-ink)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/25 disabled:cursor-not-allowed disabled:opacity-35 dark:hover:bg-white/10`;
function ti({ariaLabel:e,ariaControls:t,className:n=``,direction:r,disabled:i=!1,onClick:a}){
  let o=r===`previous`?qr:Xr;
  return(0,d.jsxs)(`button`,{"aria-label":e,"aria-controls":t,className:`${ei} ${n}`.trim(),disabled:i,type:`button`,onClick:a,children:[(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`absolute top-1/2 left-1/2 size-[max(100%,3rem)] -translate-1/2 pointer-fine:hidden`}),(0,d.jsx)(o,{"aria-hidden":`true`,className:`size-4 shrink-0 fill-current`})]})
  }
function ni({className:e}){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:e,viewBox:`0 0 1155 1000`,children:(0,d.jsx)(`path`,{className:`fill-current`,d:`M577.3 0 1155 1000H0z`})})
  }
var ri=`https://models.sulat.com`;
function ii(e,t){
  try{
    return new URL(e).toString().replace(/\/$/,``)
    }catch{
    throw Error(`${t} must be an absolute URL. Received: ${e}`)
    }
  }
function ai(){
  return ii(ri,`VITE_CATALOG_URL`)
  }
var oi={name:`Sulat`,metadataSiteName:`Sulat`,url:ai(),rssPath:`/feed`,rssTitle:`Sulat latest AI model releases RSS feed`,guidesUrl:`https://ai.sulat.com`,guidesTitle:`Sulat AI how-to guides on Medium`,description:`Browse AI models, compare capabilities, pricing, and limits, and see which providers serve each model.`,defaultTitle:`AI models and providers | Sulat`,modelInformationTitle:`AI model information`,providerInformationTitle:`AI model provider information`,modelsDirectoryTitle:`AI models`,providersDirectoryTitle:`AI model providers`,homeHeading:`Find AI models and see which providers serve them.`,homeDescription:`Browse AI models, compare capabilities, pricing, and limits, and open provider pages to see who serves each model.`,keywords:[`AI models`,`AI model directory`,`AI model providers`,`LLM providers`,`model capabilities`,`model pricing`,`model limits`,`OpenAI models`,`Synthetic models`,`MiniMax models`,`Gemini models`,`Sulat`],creator:`JP Caparas`,publisher:`Sulat`};
function si(e){
  return`/models/${e}`
  }
function ci(e){
  return`/providers/${e}`
  }
function li(){
  return oi.rssPath
  }
var ui=`(prefers-reduced-motion: reduce)`;
function di(){
  if(typeof window>`u`||!window.matchMedia)
  return null;
  try{
    return window.matchMedia(ui)
    }catch{
    return null
    }
  }
function fi(e){
  let t=di();
  return t?(t.addEventListener(`change`,e),()=>t.removeEventListener(`change`,e)):()=>{
    }
  }
function pi(){
  return di()?.matches===!0
  }
function mi(){
  return!1
  }
function hi(){
  return(0,u.useSyncExternalStore)(fi,pi,mi)
  }
var gi=`https://www.skills.sh/jpcaparas/skills`,_i=`(max-width: 639px)`,vi=5e3,yi=2,bi=[{destination:`feed`,href:li(),id:`rss`,label:`Open RSS feed`,mobileLabel:`RSS feed`,title:oi.rssTitle},{destination:`external`,href:oi.guidesUrl,id:`medium`,label:`Medium guides`,mobileLabel:`Medium`,title:oi.guidesTitle},{destination:`external`,href:gi,id:`skills`,label:`skills.sh`,mobileLabel:`skills.sh`,title:`Browse free reusable agent playbooks`}],xi=`relative isolate flex min-h-20 w-full min-w-0 items-center justify-center gap-2 overflow-hidden rounded-[1.15rem] border px-2.5 py-3 font-semibold transition-transform hover:-translate-y-px motion-reduce:transition-none motion-reduce:hover:translate-y-0 focus-visible:outline-2 focus-visible:outline-offset-2 max-[359px]:flex-col max-[359px]:gap-1.5 max-[359px]:px-2 sm:min-h-0 sm:w-auto sm:rounded-full sm:px-5 sm:py-3.5`,Si=`border-[color:var(--color-line)] bg-white/70 text-[color:var(--color-ink)] hover:border-[color:var(--color-line-strong)] hover:bg-white/95 focus-visible:outline-[color:var(--color-accent)] dark:bg-[color:var(--color-paper)] dark:hover:bg-[color:var(--color-elevated)]`,Ci=`skills-footer-link border-transparent bg-linear-to-br from-white via-neutral-100 to-neutral-200 text-neutral-950 shadow-sm ring-1 ring-neutral-950/10 hover:brightness-105 focus-visible:outline-neutral-700 dark:from-neutral-100 dark:via-neutral-200 dark:to-neutral-300 dark:shadow-none dark:ring-white/10`;
function wi(...e){
  return e.filter(Boolean).join(` `)
  }
function Ti(){
  let[e,t]=(0,u.useState)(!1);
  return(0,u.useEffect)(()=>{
    let e=window.matchMedia(_i),n=()=>t(e.matches);
    return n(),e.addEventListener(`change`,n),()=>e.removeEventListener(`change`,n)
    },[]),e
  }
function Ei(e,t,n){
  return(e+t+n)%n
  }
function Di(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`size-4 shrink-0 fill-current`,viewBox:`0 0 24 24`,children:(0,d.jsx)(`path`,{d:`M4 7.5a4.5 4.5 0 1 0 0 9 4.5 4.5 0 0 0 0-9Zm8 1a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7Zm7 1.25c-.97 0-1.75 1.46-1.75 3.25s.78 3.25 1.75 3.25 1.75-1.46 1.75-3.25-.78-3.25-1.75-3.25Z`})})
  }
function Oi({id:e}){
  switch(e){case`rss`:
  return(0,d.jsx)(`span`,{className:`bg-accent/10 relative z-10 inline-flex size-8 shrink-0 items-center justify-center rounded-full text-[color:var(--color-accent-deep)]`,children:(0,d.jsx)($r,{"aria-hidden":`true`,className:`size-4 shrink-0 fill-current`})});
  case`medium`:
  return(0,d.jsx)(`span`,{className:`relative z-10 inline-flex size-8 shrink-0 items-center justify-center rounded-full bg-green-600/10 text-green-700 dark:bg-green-300/12 dark:text-green-200`,children:(0,d.jsx)(Di,{})});
  case`skills`:
  return(0,d.jsx)(`span`,{className:`relative z-10 inline-flex size-8 shrink-0 items-center justify-center rounded-lg bg-white ring-1 ring-neutral-950/10`,children:(0,d.jsx)(ni,{className:`h-3 w-auto`})})
  }
  }
function ki({item:e}){
  return(0,d.jsxs)(d.Fragment,{children:[e.id===`skills`?(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`pointer-events-none absolute inset-y-0 left-1/4 w-1/3 -skew-x-12 bg-linear-to-r from-transparent via-white/75 to-transparent`}):null,(0,d.jsx)(Oi,{id:e.id}),(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`relative z-10 min-w-0 truncate sm:hidden`,children:e.mobileLabel}),(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`relative z-10 hidden min-w-0 truncate sm:inline`,children:e.label})]})
  }
function Ai({interactive:e,item:t}){
  let n=wi(xi,t.id===`skills`?Ci:Si),r=(0,d.jsx)(ki,{item:t}),i=e?void 0:-1;
  switch(t.destination){case`feed`:
  return(0,d.jsx)(`a`,{"aria-label":t.label,className:n,href:t.href,tabIndex:i,title:t.title,type:`application/rss+xml`,children:r});
  case`external`:
  return(0,d.jsx)(`a`,{"aria-label":t.label,className:n,href:t.href,rel:`noreferrer`,tabIndex:i,target:`_blank`,title:t.title,children:r})
  }
  }
function ji({className:e=``}){
  let t=bi,n=[t.slice(0,yi),t.slice(yi)],r=n.length,[i,a]=(0,u.useState)(0),[o,s]=(0,u.useState)(!1),[c,l]=(0,u.useState)(!1),f=Ti(),p=hi(),m=o||c,h=n[i],g={"--footer-carousel-offset":`${i*-50}%`};
  (0,u.useEffect)(()=>{
    if(!f||m||p)
    return;
    let e=window.setTimeout(()=>a(Ei(i,1,r)),vi);
    return()=>window.clearTimeout(e)
    },[i,f,m,r,p]);
  function _(e){
    a(t=>Ei(t,e,r))
    }
  function v(e){
    let t=e.relatedTarget;
    t instanceof Node&&e.currentTarget.contains(t)||l(!1)
    }
  return(0,d.jsxs)(`div`,{"aria-label":`Footer resources`,"aria-roledescription":f?`carousel`:void 0,className:wi(`grid gap-3`,e),onBlurCapture:v,onFocusCapture:()=>l(!0),onMouseEnter:()=>s(!0),onMouseLeave:()=>s(!1),role:`region`,children:[(0,d.jsx)(`div`,{className:`overflow-hidden sm:overflow-visible`,children:(0,d.jsx)(`div`,{className:`flex w-[200%] [transform:translateX(var(--footer-carousel-offset))] transition-transform duration-500 ease-in-out motion-reduce:transition-none sm:w-auto sm:[transform:none] sm:flex-wrap sm:gap-3`,style:g,children:n.map((e,t)=>{
    let n=!f||t===i;
    return(0,d.jsx)(`div`,{"aria-hidden":!n||void 0,"aria-label":`Footer links page ${t+1} of ${r}`,className:wi(`grid w-1/2 shrink-0 gap-2.5 sm:contents`,e.length===1?`grid-cols-1`:`grid-cols-2`,t===i?`visible`:`invisible sm:visible`),role:`group`,children:e.map(e=>(0,d.jsx)(`div`,{className:wi(`min-w-0 text-[0.95rem]`,e.id===`skills`?`font-[ui-sans-serif,system-ui,sans-serif]`:`font-serif`),children:(0,d.jsx)(Ai,{interactive:n,item:e})},e.id))},e.map(e=>e.id).join(`-`))
    })})}),(0,d.jsxs)(`div`,{className:`flex items-center justify-between gap-3 sm:hidden`,children:[(0,d.jsxs)(`p`,{"aria-live":`polite`,className:`font-mono text-sm tracking-wide tabular-nums`,children:[`0`,i+1,` / 0`,r,(0,d.jsx)(`span`,{className:`sr-only`,children:h.map(e=>e.label).join(` and `)})]}),(0,d.jsxs)(`div`,{className:`flex items-center gap-0.5 rounded-full border border-[color:var(--color-line)] bg-white/70 p-0.5 dark:bg-neutral-950/50`,children:[(0,d.jsx)(ti,{ariaLabel:`Previous footer links`,direction:`previous`,onClick:()=>_(-1)}),(0,d.jsx)(ti,{ariaLabel:`Next footer links`,direction:`next`,onClick:()=>_(1)})]})]})]})
  }
function Mi(){
  return(0,d.jsx)(`footer`,{className:`relative z-10 border-t border-[color:var(--color-line)]`,children:(0,d.jsx)(`div`,{className:`mx-auto w-full max-w-7xl px-6 py-14 text-sm text-[color:var(--color-muted)] sm:px-8 lg:px-12`,children:(0,d.jsxs)(`div`,{className:`surface-panel w-full rounded-[1.75rem] p-5 sm:p-6`,children:[(0,d.jsx)(`div`,{className:`eyebrow`,children:`Subscribe`}),(0,d.jsx)(`h2`,{className:`mt-3 font-serif text-[1.8rem] tracking-[-0.05em] text-[color:var(--color-ink)]`,children:`Follow catalog updates and new guides`}),(0,d.jsx)(ji,{className:`mt-5`}),(0,d.jsx)(`p`,{className:`mt-4 text-base/7 text-[color:var(--color-muted)] sm:text-sm/6`,children:`RSS covers catalog changes. Medium has guides. Skills.sh has reusable agent playbooks.`})]})})})
  }
function J(...e){
  return e.filter(Boolean).join(` `)
  }
function Ni(e){
  return e.key.trim().toLowerCase()===`synthetic`
  }
function Pi(){
  return(0,d.jsxs)(`span`,{className:`relative inline-flex h-14 w-11 shrink-0 items-center justify-center overflow-hidden rounded-[1.1rem] border border-[color:var(--color-line)] bg-white/80 shadow-lg dark:shadow-none`,children:[(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`via-accent-soft/20 to-accent/10 dark:via-accent-soft/25 dark:to-accent/15 absolute inset-0 bg-linear-to-br from-white/70`}),(0,d.jsx)(fr,{"aria-hidden":`true`,alt:``,className:`relative h-12 w-auto object-contain drop-shadow-sm dark:drop-shadow-none`,height:144,loading:`eager`,src:`/sulat-mark.webp`,unoptimized:!0,width:98})]})
  }
function Y(){
  return(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`M3 8h9m0 0-3.25-3.25M12 8l-3.25 3.25`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})})
  }
function Fi(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M13.2 2.8C8.8 3 5.4 4.2 3.8 6.8c-1.3 2.1-.5 4.4 1.4 5.1 1.8.7 3.8-.3 4.8-2 1.1-1.8 1.8-4 3.2-7.1Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M3 13c1.5-2.4 3.6-4.3 6.4-5.8`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.3`})]})
  }
function Ii(){
  return(0,d.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:[(0,d.jsx)(`path`,{d:`M9.5 3h3.5v3.5M7 9 13 3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`}),(0,d.jsx)(`path`,{d:`M13 8.5v3a1.5 1.5 0 0 1-1.5 1.5h-7A1.5 1.5 0 0 1 3 11.5v-7A1.5 1.5 0 0 1 4.5 3h3`,stroke:`currentColor`,strokeWidth:`1.3`})]})
  }
function Li(){
  return(0,d.jsx)(`header`,{className:`bg-background/80 relative z-20 border-b border-[color:var(--color-line)] backdrop-blur-xl lg:fixed lg:inset-x-0 lg:top-0 lg:z-40 lg:shadow-lg dark:lg:shadow-none`,children:(0,d.jsxs)(`div`,{className:`mx-auto flex w-full max-w-7xl items-center justify-between gap-6 px-6 py-4 sm:px-8 lg:px-12`,children:[(0,d.jsxs)(s,{href:`/`,className:`flex items-center gap-3`,children:[(0,d.jsx)(Pi,{}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`eyebrow`,children:`Sulat.com`}),(0,d.jsx)(`div`,{className:`font-serif text-[1.35rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:`AI models`})]})]}),(0,d.jsxs)(`nav`,{"aria-label":`Main navigation`,className:`flex flex-wrap items-center justify-end gap-3 text-sm text-[color:var(--color-muted)]`,children:[(0,d.jsxs)(s,{href:`/news`,className:`inline-flex min-h-11 shrink-0 items-center gap-2 rounded-full border border-[color:var(--color-accent-deep)] px-4 py-2 font-semibold text-[color:var(--color-accent-deep)]! transition hover:bg-[color:var(--color-accent-soft)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--color-accent-deep)]`,children:[`News`,(0,d.jsx)(Y,{})]}),(0,d.jsx)(Mn,{})]})]})})
  }
function Ri({eyebrow:e,title:t,body:n,action:r,align:i=`left`,as:a=`h2`}){
  return(0,d.jsxs)(`div`,{className:J(`space-y-3`,i===`center`&&`mx-auto max-w-3xl text-center`),children:[e?(0,d.jsx)(`p`,{className:`eyebrow`,children:e}):null,(0,d.jsxs)(`div`,{className:J(`flex flex-wrap items-center gap-3`,i===`center`&&`justify-center`),children:[(0,d.jsx)(a,{className:`min-w-0 font-serif text-[2.25rem] leading-none tracking-[-0.05em] text-[color:var(--color-ink)] sm:text-[3rem]`,children:t}),r?(0,d.jsx)(`div`,{className:`shrink-0`,children:r}):null]}),typeof n==`string`?(0,d.jsx)(`p`,{className:`max-w-3xl text-base leading-7 text-[color:var(--color-muted)]`,children:n}):n||null]})
  }
function zi({items:e}){
  return(0,d.jsx)(`section`,{className:`mx-auto hidden max-w-7xl px-6 py-4 sm:px-8 lg:block lg:px-12`,children:(0,d.jsx)(`div`,{className:`surface-panel grid gap-3 rounded-[1.8rem] p-4 sm:grid-cols-3 sm:p-5`,children:e.map(e=>(0,d.jsxs)(`div`,{className:`rounded-[1.3rem] border border-[color:var(--color-line)] bg-white/65 p-4`,children:[(0,d.jsx)(`div`,{className:`text-[0.72rem] font-semibold tracking-[0.24em] text-[color:var(--color-muted)] uppercase`,children:e.label}),(0,d.jsx)(`div`,{className:`mt-2 font-serif text-[2rem] tracking-[-0.05em] text-[color:var(--color-ink)]`,children:e.value}),(0,d.jsx)(`p`,{className:`mt-2 text-sm leading-6 text-[color:var(--color-muted)]`,children:e.detail})]},e.label))})})
  }
function Bi({provider:e,className:t,compact:n=!1,decorative:r=!1}){
  let i=jr(e),a=Mr(e),o=!r&&a&&e.name!==null;
  return(0,d.jsx)(`div`,{className:J(`inline-flex items-center justify-center border border-[color:var(--color-line)] bg-[color:var(--color-logo-well)]`,n?`rounded-xl p-2.5 sm:rounded-2xl sm:p-3`:`rounded-[1.25rem] p-3`,t),children:(0,d.jsx)(`img`,{src:i,alt:o?`${e.name} logo`:``,"aria-hidden":!o||void 0,className:`h-full w-full object-contain`,loading:`lazy`})})
  }
function X({children:e,tone:t=`default`}){
  return(0,d.jsx)(`span`,{className:J(`catalog-badge inline-flex items-center gap-1.5 rounded-full px-3 py-1 text-[0.7rem] font-semibold tracking-[0.18em] uppercase`,t==="default"&&`catalog-badge-default border border-[color:var(--color-line)] bg-white/75 text-[color:var(--color-ink)]`,t===`accent`&&`catalog-badge-accent bg-[color:var(--color-accent-soft)] text-[color:var(--color-accent-deep)]`,t===`muted`&&`catalog-badge-muted border border-[color:var(--color-line)] bg-white/55 text-[color:var(--color-muted)]`,t===`success`&&`catalog-badge-success border border-emerald-700/20 bg-emerald-100/80 text-emerald-800`),children:e})
  }
function Z({children:e,href:t}){
  let n=`inline-flex items-center rounded-full border border-[color:var(--color-line)] bg-white/70 px-3 py-1.5 text-[0.82rem] leading-none text-[color:var(--color-muted)] transition`;
  return t?(0,d.jsx)(s,{href:t,className:`${n} hover:border-[color:var(--color-line-strong)] hover:bg-white/95 hover:text-[color:var(--color-ink)]`,children:e}):(0,d.jsx)(`span`,{className:n,children:e})
  }
function Vi({models:e,hotModelIds:t=[],loadingLabel:n}){
  let r=new Set(t);
  return(0,d.jsxs)(`div`,{"aria-busy":n?!0:void 0,className:J(`surface-panel relative overflow-hidden rounded-[2rem]`,n&&e.length===0&&`min-h-[24rem]`),children:[(0,d.jsx)(`div`,{className:`divider-list results-loading-content`,"data-loading":n?`true`:void 0,children:e.map(e=>(0,d.jsx)(Hi,{model:e,isHot:r.has(e.id)},e.id))}),n?(0,d.jsx)(Dr,{label:n}):null]})
  }
function Hi({model:e,isHot:t=!1}){
  let n=bt(e),r=vt(e),i=yt(e);
  return(0,d.jsxs)(`article`,{className:J(`relative grid gap-5 px-5 py-5 sm:px-7 sm:py-6 lg:grid-cols-[minmax(0,1fr)_auto]`,t&&`pl-16 sm:pl-20`),children:[t?(0,d.jsxs)(`div`,{className:`border-accent/30 bg-accent-soft/30 absolute inset-y-4 left-3 flex w-9 flex-col items-center justify-center gap-2 rounded-full border text-[color:var(--color-accent-deep)] shadow-md sm:left-5`,children:[(0,d.jsx)(`span`,{"aria-hidden":`true`,className:`text-sm leading-none`,children:`🔥`}),(0,d.jsx)(`span`,{className:`rotate-180 text-[0.62rem] font-semibold tracking-[0.16em] uppercase [writing-mode:vertical-rl]`,children:`Hot`})]}):null,(0,d.jsxs)(`div`,{className:`min-w-0 space-y-4`,children:[(0,d.jsxs)(`div`,{className:`flex flex-wrap items-center gap-2`,children:[(0,d.jsx)(X,{tone:`accent`,children:e.provider.name}),e.archivedAt?(0,d.jsx)(X,{tone:`muted`,children:`Archived · historical specs and pricing`}):null,e.family?(0,d.jsx)(X,{tone:`muted`,children:e.family}):null,e.status?(0,d.jsx)(X,{tone:`muted`,children:e.status}):null]}),(0,d.jsxs)(`div`,{className:`space-y-2`,children:[(0,d.jsxs)(s,{className:`inline-flex items-center gap-2 font-serif text-[2rem] tracking-[-0.05em] text-[color:var(--color-ink)] hover:text-[color:var(--color-accent-deep)]`,href:`/models/${e.slug}`,children:[e.name,(0,d.jsx)(Y,{})]}),(0,d.jsxs)(`div`,{className:`flex flex-wrap gap-x-3 gap-y-2 text-sm break-words text-[color:var(--color-muted)]`,children:[(0,d.jsx)(Z,{children:e.modelKey}),(0,d.jsx)(Z,{href:`/providers/${e.provider.slug}`,children:e.provider.name}),e.dates.releaseDate?(0,d.jsxs)(Z,{children:[`Released `,j(e.dates.releaseDate)]}):null,i?(0,d.jsx)(Z,{children:i}):null,r?(0,d.jsx)(Z,{children:r}):null]})]}),n.length>0?(0,d.jsx)($n,{labels:n}):null]}),(0,d.jsxs)(`div`,{className:`grid gap-3 text-sm text-[color:var(--color-muted)] sm:min-w-[13rem] lg:text-right`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`eyebrow`,children:`Input`}),(0,d.jsx)(`div`,{className:`mt-1`,children:(0,d.jsx)(hr,{values:e.modalities.input,className:`lg:justify-end`})})]}),(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`eyebrow`,children:`Output`}),(0,d.jsx)(`div`,{className:`mt-1`,children:(0,d.jsx)(hr,{values:e.modalities.output,className:`lg:justify-end`})})]})]})]})
  }
function Ui({providers:e,density:t=`editorial`,loadingLabel:n}){
  return(0,d.jsxs)(`div`,{"aria-busy":n?!0:void 0,className:J(`surface-panel relative overflow-hidden rounded-[2rem]`,n&&e.length===0&&`min-h-[24rem]`),children:[(0,d.jsx)(`div`,{className:`divider-list results-loading-content`,"data-loading":n?`true`:void 0,children:e.map(e=>(0,d.jsxs)(`article`,{className:J(`grid gap-5 px-5 py-5 sm:grid-cols-[auto,minmax(0,1fr)] sm:px-7 sm:py-6`,Ni(e)&&`provider-directory-synthetic`),children:[(0,d.jsx)(Bi,{provider:e,className:`h-16 w-16`}),(0,d.jsxs)(`div`,{className:`grid gap-3 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-start`,children:[(0,d.jsxs)(`div`,{className:`space-y-3`,children:[(0,d.jsx)(`div`,{className:`flex flex-wrap items-center gap-2`,children:(0,d.jsx)(X,{tone:`accent`,children:e.key})}),(0,d.jsxs)(`div`,{className:`space-y-2`,children:[(0,d.jsxs)(s,{className:`inline-flex items-center gap-2 font-serif text-[2rem] tracking-[-0.05em] text-[color:var(--color-ink)] hover:text-[color:var(--color-accent-deep)]`,href:`/providers/${e.slug}`,children:[e.name,(0,d.jsx)(Y,{})]}),(0,d.jsxs)(`div`,{className:`flex flex-wrap gap-x-5 gap-y-2 text-sm text-[color:var(--color-muted)]`,children:[(0,d.jsx)(`span`,{children:e.slug}),e.npmPackage?(0,d.jsx)(`span`,{children:e.npmPackage}):null,e.syncedAt?(0,d.jsxs)(`span`,{children:[`Synced `,j(e.syncedAt)]}):null]})]})]}),(0,d.jsxs)(`div`,{className:`flex flex-wrap gap-3 text-sm text-[color:var(--color-muted)] lg:justify-end`,children:[e.links.documentationUrl?(0,d.jsxs)(`a`,{className:`button-quiet`,href:e.links.documentationUrl,rel:`noreferrer`,target:`_blank`,children:[`Docs`,(0,d.jsx)(Ii,{})]}):null,e.links.apiUrl?(0,d.jsx)(cr,{value:e.links.apiUrl,label:`Copy API base`,copiedLabel:`API copied`}):null,t===`editorial`?(0,d.jsx)(s,{className:`button-quiet`,href:`/providers/${e.slug}`,children:`View detail`}):null]})]})]},e.id))}),n?(0,d.jsx)(Dr,{label:n}):null]})
  }
function Wi({eyebrow:e,title:t,body:n,controls:r,children:i}){
  return(0,d.jsxs)(`main`,{className:`mx-auto grid max-w-7xl gap-8 px-6 py-10 sm:px-8 lg:grid-cols-[21rem_minmax(0,1fr)] lg:px-12`,children:[(0,d.jsxs)(`aside`,{className:`grid gap-5 lg:sticky lg:top-24 lg:h-fit`,children:[(0,d.jsx)(`div`,{className:`px-1 sm:px-2`,children:(0,d.jsx)(Ri,{as:`h1`,eyebrow:e,title:t,body:n})}),r]}),(0,d.jsx)(`section`,{className:`grid gap-6`,children:i})]})
  }
function Gi({basePath:e,query:t,page:n,hasNextPage:r,hasPreviousPage:i,totalPages:a,onNavigate:o}){
  if(!r&&!i&&(a===null||a<=1))
  return null;
  let c=n=>`${e}?${Wt({...t,page:n})}`,l=(e,t,n)=>t?(0,d.jsx)(s,{className:`button-quiet`,href:c(n),onClick:e=>{
    o&&e.button===0&&!e.metaKey&&!e.ctrlKey&&!e.altKey&&!e.shiftKey&&(e.preventDefault(),o(n))
    },children:e}):(0,d.jsx)(`span`,{className:`opacity-40`,children:e});
  return(0,d.jsxs)(`div`,{className:`surface-panel flex flex-wrap items-center justify-between gap-3 rounded-[1.6rem] px-5 py-4 text-sm text-[color:var(--color-muted)]`,children:[l(`Previous page`,i,Math.max(1,n-1)),(0,d.jsxs)(`span`,{children:[`Page `,M(n),a?` of ${M(a)}`:``]}),l(`Next page`,r,n+1)]})
  }
function Ki({titleAccessory:e,title:t,items:n}){
  return n.length===0?null:(0,d.jsxs)(`section`,{className:`surface-panel overflow-hidden rounded-[2rem]`,children:[t?(0,d.jsx)(`div`,{className:`px-5 pt-5 sm:px-6`,children:(0,d.jsxs)(`div`,{className:`flex flex-wrap items-center gap-3`,children:[(0,d.jsx)(`h3`,{className:`font-serif text-[1.5rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:t}),e||null]})}):null,(0,d.jsx)(`dl`,{className:t?`pt-3`:void 0,children:n.map(e=>(0,d.jsxs)(`div`,{className:`grid gap-2 border-t border-[color:var(--color-line)] px-5 py-4 first:border-t-0 sm:grid-cols-[12rem,1fr] sm:px-6`,children:[(0,d.jsxs)(`dt`,{className:`space-y-2`,children:[(0,d.jsx)(`div`,{className:`eyebrow text-[color:var(--color-muted)]`,children:e.label}),e.explainer?e.explainer:null]}),(0,d.jsx)(`dd`,{className:`text-sm leading-7 text-[color:var(--color-ink)]`,children:e.value})]},e.label))})]})
  }
function qi({title:e,data:t}){
  let n=e===`Cost`?ea(t):null,r=e===`Limits`?ta(t):null,i=e===`Experimental`?na(t):null;
  return n?(0,d.jsx)(Qi,{data:n}):r?(0,d.jsx)($i,{data:r}):i?(0,d.jsx)(Yi,{data:i}):(0,d.jsxs)(`section`,{className:`surface-panel grid gap-4 rounded-[1.8rem] p-5`,children:[(0,d.jsx)(`h3`,{className:`font-serif text-[1.5rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:e}),(0,d.jsx)(`div`,{className:`overflow-hidden rounded-[1.3rem] border border-[color:var(--color-line)] bg-white/75`,children:(0,d.jsx)(`pre`,{className:`overflow-x-auto p-4 text-sm leading-7 text-[color:var(--color-muted)]`,children:JSON.stringify(t,null,2)})})]})
  }
function Ji({comparison:e}){
  let[t,n]=(0,u.useState)(!1),r=(0,u.useId)(),i=Math.min(...e.items.map(e=>e.combined)),{isCurrentMostExpensive:a}=e,o=e.items.find(e=>e.isCurrent),c=o!==void 0&&e.items.every(e=>e.isCurrent||e.combined<o.combined),l=e.items.some(e=>e.combined>i),f=e=>!c&&l&&e===i;
  return(0,d.jsxs)(`section`,{className:`surface-panel grid min-w-0 gap-4 rounded-[2rem] p-4 sm:gap-5 sm:p-6`,children:[(0,d.jsxs)(`div`,{className:`grid gap-4 sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center`,children:[(0,d.jsxs)(`div`,{className:`max-w-3xl space-y-2`,children:[(0,d.jsx)(`p`,{className:`eyebrow`,children:`Transparent token rates`}),(0,d.jsxs)(`h3`,{className:`font-serif text-[1.9rem] tracking-[-0.05em] text-[color:var(--color-ink)] sm:text-[2.2rem]`,children:[`Compare `,e.modelName,` pricing`]}),(0,d.jsx)(`p`,{className:`text-sm leading-6 text-[color:var(--color-muted)]`,children:`Rates are shown per one million tokens. Combined means one million input plus one million output tokens.`})]}),(0,d.jsxs)(s,{className:`button-quiet w-fit sm:justify-self-end`,href:e.familyHref,children:[`Browse this family`,(0,d.jsx)(Y,{})]})]}),(0,d.jsxs)(`div`,{className:`relative min-w-0`,children:[(0,d.jsx)(`div`,{id:r,children:t?(0,d.jsxs)(`div`,{className:`grid min-w-0 gap-4`,children:[c?(0,d.jsxs)(`p`,{className:`text-sm leading-6 text-[color:var(--color-muted)]`,children:[`Other listed providers are cheaper. Lowest combined rate:`,` `,N(i),`.`]}):null,(0,d.jsx)(`div`,{className:`grid min-w-0 gap-3 sm:grid-cols-2 xl:grid-cols-3`,children:e.items.map(e=>(0,d.jsxs)(`article`,{"aria-label":`${e.name} pricing${e.isCurrent?` (current model)`:``}`,className:J(`grid min-w-0 gap-4 rounded-[1.35rem] border p-4`,f(e.combined)&&`border-emerald-600/60 bg-emerald-50/70 ring-2 ring-emerald-200/80 dark:border-emerald-300/50 dark:bg-emerald-400/[0.055] dark:ring-emerald-300/15`,!f(e.combined)&&`bg-white/65 dark:bg-white/[0.035]`,!f(e.combined)&&e.isCurrent&&`border-[color:var(--color-accent)] ring-2 ring-[color:var(--color-accent-soft)]`,!f(e.combined)&&!e.isCurrent&&`border-[color:var(--color-line)]`),children:[(0,d.jsxs)(`div`,{className:`flex min-w-0 items-start justify-between gap-3`,children:[(0,d.jsxs)(`div`,{className:`min-w-0`,children:[(0,d.jsx)(s,{className:`block truncate font-serif text-[1.35rem] tracking-[-0.04em] text-[color:var(--color-ink)] transition hover:text-[color:var(--color-accent-deep)]`,href:e.href,children:e.name}),(0,d.jsx)(s,{className:`mt-1 block w-fit text-xs text-[color:var(--color-muted)] transition hover:text-[color:var(--color-ink)]`,href:`/providers/${e.provider.slug}`,children:e.provider.name})]}),(0,d.jsxs)(`div`,{className:`flex shrink-0 flex-col items-end gap-2`,children:[f(e.combined)?(0,d.jsxs)(X,{tone:`success`,children:[(0,d.jsx)(Fi,{}),`Cheapest`]}):null,e.isCurrent?(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(X,{tone:`accent`,children:`Current`}),c?(0,d.jsx)(`span`,{className:`text-xs text-[color:var(--color-muted)]`,children:a?`Most expensive`:`Higher priced`}):null]}):null]})]}),(0,d.jsx)(`dl`,{className:`grid grid-cols-2 gap-2`,children:[{label:`Input`,value:e.input,className:``},{label:`Output`,value:e.output,className:``},{label:`1M input + 1M output`,value:e.combined,className:`col-span-2`}].map(e=>(0,d.jsxs)(`div`,{className:J(`rounded-[1rem] border border-[color:var(--color-line)] bg-white/70 p-3 dark:bg-white/[0.035]`,e.className),children:[(0,d.jsx)(`dt`,{className:`text-[0.65rem] font-semibold tracking-[0.15em] text-[color:var(--color-muted)] uppercase`,children:e.label}),(0,d.jsx)(`dd`,{className:`mt-1.5 font-serif text-[1.25rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:N(e.value)})]},e.label))})]},e.id))}),(0,d.jsx)(`aside`,{className:`rounded-[1.2rem] border border-[color:var(--color-line)] bg-[color:var(--color-soft)] px-4 py-3 text-xs leading-5 text-[color:var(--color-muted)] sm:text-sm sm:leading-6`,children:`Only explicit, non-zero input and output rates can be compared like-for-like. Subsidized subscriptions can still be good value, but they do not reveal the full underlying token cost.`})]}):(0,d.jsx)(`div`,{className:`h-28 overflow-hidden rounded-[1.35rem] border border-[color:var(--color-line)] bg-white/45 sm:h-36 dark:bg-white/[0.02]`,children:(0,d.jsx)(`div`,{"aria-hidden":`true`,className:`grid grid-cols-1 gap-3 p-3 sm:grid-cols-2 xl:grid-cols-3`,children:e.items.slice(0,3).map(e=>(0,d.jsxs)(`div`,{className:`grid min-h-28 gap-3 rounded-[1.15rem] border border-[color:var(--color-line)] bg-white/70 p-4 sm:min-h-32 dark:bg-white/[0.04]`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`div`,{className:`truncate font-serif text-lg text-[color:var(--color-ink)]`,children:e.name}),(0,d.jsx)(`div`,{className:`truncate text-xs text-[color:var(--color-muted)]`,children:e.provider.name})]}),(0,d.jsx)(`div`,{className:`grid grid-cols-3 gap-2`,children:[e.input,e.output,e.combined].map((t,n)=>(0,d.jsx)(`div`,{className:`rounded-xl bg-[color:var(--color-soft)] px-2 py-3 font-serif text-sm text-[color:var(--color-ink)]`,children:N(t)},`${e.id}-${n}`))})]},e.id))})})}),t?null:(0,d.jsx)(`div`,{"aria-hidden":`true`,className:`pointer-events-none absolute inset-x-px bottom-px h-14 rounded-b-[1.3rem] bg-linear-to-b from-transparent via-[color:var(--color-paper)]/45 to-[color:var(--color-paper)] [mask-image:linear-gradient(to_bottom,transparent,black_45%)] backdrop-blur-[2px] sm:h-16`}),(0,d.jsx)(`button`,{type:`button`,"aria-controls":r,"aria-expanded":t,"aria-label":t?`Collapse price comparison`:`Show price comparison`,className:J(`z-10 flex size-9 items-center justify-center rounded-full border border-[color:var(--color-line-strong)] bg-[color:var(--color-paper)] text-[color:var(--color-ink)] shadow-md transition hover:-translate-y-0.5 hover:border-[color:var(--color-accent)] hover:text-[color:var(--color-accent-deep)] focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent)] motion-reduce:transition-none motion-reduce:hover:translate-y-0`,t?`relative mx-auto mt-4`:`absolute bottom-2 left-1/2 -translate-x-1/2`),onClick:()=>n(e=>!e),children:(0,d.jsx)(`svg`,{"aria-hidden":`true`,className:J(`h-4 w-4 transition-transform motion-reduce:transition-none`,t&&`rotate-180`),viewBox:`0 0 16 16`,fill:`none`,children:(0,d.jsx)(`path`,{d:`m4 6 4 4 4-4`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})})},`pricing-comparison-toggle`)]})]})
  }
function Yi({data:e}){
  return(0,d.jsxs)(`section`,{className:`surface-panel grid gap-5 rounded-[1.8rem] p-5 sm:p-6`,children:[(0,d.jsxs)(`div`,{className:`flex flex-wrap items-start justify-between gap-3`,children:[(0,d.jsxs)(`div`,{children:[(0,d.jsx)(`p`,{className:`eyebrow`,children:`OpenCode`}),(0,d.jsx)(`h3`,{className:`font-serif text-[1.5rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:`Model variants`})]}),(0,d.jsx)(Xi,{})]}),(0,d.jsx)(`div`,{className:J(`grid gap-4`,e.modes.length>1&&`lg:grid-cols-2`),children:e.modes.map(e=>(0,d.jsxs)(`article`,{className:`grid gap-4 rounded-[1.4rem] border border-[color:var(--color-line)] bg-white/75 p-4`,children:[(0,d.jsx)(`div`,{className:`flex flex-wrap items-baseline justify-between gap-3`,children:(0,d.jsx)(`h4`,{className:`font-serif text-[1.45rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:e.label})}),e.costRows.length>0?(0,d.jsx)(`div`,{className:`grid gap-2 sm:grid-cols-3`,children:e.costRows.map(e=>(0,d.jsxs)(`div`,{className:`rounded-[1rem] border border-[color:var(--color-line)] bg-white/60 p-3`,children:[(0,d.jsx)(`div`,{className:`text-[0.68rem] font-semibold tracking-[0.18em] text-[color:var(--color-muted)] uppercase`,children:e.label}),(0,d.jsx)(`div`,{className:`mt-2 font-serif text-[1.25rem] leading-none tracking-[-0.04em] text-[color:var(--color-ink)]`,children:N(e.value)}),(0,d.jsx)(`div`,{className:`mt-1 text-[0.72rem] text-[color:var(--color-muted)]`,children:`per 1M tokens`})]},e.label))}):null,e.optionRows.length>0?(0,d.jsx)(Zi,{title:`Options`,rows:e.optionRows}):null]},e.key))})]})
  }
function Xi(){
  return(0,d.jsx)(K,{eyebrow:`OpenCode terminology`,title:`What experimental variants mean`,triggerLabel:`What do these mean?`,entries:[{term:`Experimental`,description:`means OpenCode treats this model metadata as under active development. The behavior can change or disappear as OpenCode promotes, renames, or removes the feature.`},{term:`Model variants`,description:`are alternate OpenCode configurations for the same base model. They can adjust request options, headers, or pricing without duplicating the main model entry.`},{term:`Fast`,description:`is a variant name used by OpenCode for models that expose a faster provider-specific mode. When a variant has separate pricing, those prices are shown here instead of the default model prices.`}],note:`This block appears only when Models.dev sends OpenCode-specific experimental mode metadata for the model.`})
  }
function Zi({title:e,rows:t}){
  return(0,d.jsxs)(`div`,{className:`overflow-hidden rounded-[1.1rem] border border-[color:var(--color-line)] bg-white/50`,children:[(0,d.jsx)(`div`,{className:`border-b border-[color:var(--color-line)] px-3 py-2 text-[0.68rem] font-semibold tracking-[0.18em] text-[color:var(--color-muted)] uppercase`,children:e}),(0,d.jsx)(`dl`,{children:t.map(e=>(0,d.jsxs)(`div`,{className:`grid gap-2 border-t border-[color:var(--color-line)] px-3 py-2 first:border-t-0 sm:grid-cols-[minmax(0,1fr)_minmax(0,1fr)]`,children:[(0,d.jsx)(`dt`,{className:`min-w-0 font-mono text-xs break-words text-[color:var(--color-muted)]`,children:e.path}),(0,d.jsx)(`dd`,{className:`min-w-0 font-mono text-xs break-words text-[color:var(--color-ink)]`,children:e.value})]},`${e.path}:${e.value}`))})]})
  }
function Qi({data:e}){
  let t=[{label:`Input token cost`,value:e.input},{label:`Output token cost`,value:e.output}].filter(e=>e.value!==null);
  return(0,d.jsxs)(`section`,{className:`surface-panel grid gap-4 rounded-[1.8rem] p-5`,children:[(0,d.jsxs)(`div`,{className:`flex flex-wrap items-start justify-between gap-3`,children:[(0,d.jsx)(`h3`,{className:`font-serif text-[1.5rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:`Cost`}),!e.isSubscriptionPlan&&t.length>0?(0,d.jsx)(Or,{mode:`cost`}):null]}),e.isSubscriptionPlan?(0,d.jsx)(`p`,{className:`max-w-2xl text-base leading-8 text-[color:var(--color-muted)]`,children:`A provider subscription or plan supersedes token-based pricing for this model.`}):(0,d.jsx)(`dl`,{className:`overflow-hidden rounded-[1.3rem] border border-[color:var(--color-line)] bg-white/75`,children:t.map(e=>(0,d.jsxs)(`div`,{className:`grid gap-1 border-t border-[color:var(--color-line)] px-4 py-3 first:border-t-0 sm:grid-cols-[10rem,1fr] sm:items-center`,children:[(0,d.jsx)(`dt`,{className:`text-[0.72rem] font-semibold tracking-[0.2em] text-[color:var(--color-muted)] uppercase`,children:e.label}),(0,d.jsx)(`dd`,{className:`font-serif text-[1.35rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:N(e.value)})]},e.label))})]})
  }
function $i({data:e}){
  let t=[{label:`Input tokens`,value:e.input},{label:`Output tokens`,value:e.output},{label:`Context window`,value:e.context}].filter(e=>e.value!==null);
  return(0,d.jsxs)(`section`,{className:`surface-panel grid gap-4 rounded-[1.8rem] p-5`,children:[(0,d.jsxs)(`div`,{className:`flex flex-wrap items-start justify-between gap-3`,children:[(0,d.jsx)(`h3`,{className:`font-serif text-[1.5rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:`Limits`}),(0,d.jsx)(Or,{})]}),(0,d.jsx)(`dl`,{className:`overflow-hidden rounded-[1.3rem] border border-[color:var(--color-line)] bg-white/75`,children:t.map(e=>(0,d.jsxs)(`div`,{className:`grid gap-1 border-t border-[color:var(--color-line)] px-4 py-3 first:border-t-0 sm:grid-cols-[10rem,1fr] sm:items-center`,children:[(0,d.jsx)(`dt`,{className:`text-[0.72rem] font-semibold tracking-[0.2em] text-[color:var(--color-muted)] uppercase`,children:e.label}),(0,d.jsxs)(`dd`,{className:`font-serif text-[1.35rem] tracking-[-0.04em] text-[color:var(--color-ink)]`,children:[M(e.value),` tokens`]})]},e.label))})]})
  }
function ea(e){
  let t=Q(e);
  if(!t)
  return null;
  let n=$(t,`input`),r=$(t,`output`);
  return n===null&&r===null?null:{input:n,output:r,isSubscriptionPlan:n===0||r===0}
  }
function ta(e){
  let t=Q(e);
  if(!t)
  return null;
  let n=$(t,`input`),r=$(t,`output`),i=$(t,`context`);
  return n===null&&r===null&&i===null?null:{input:n,output:r,context:i}
  }
function na(e){
  let t=Q(Q(e)?.modes);
  if(!t)
  return null;
  let n=Object.entries(t).map(([e,t])=>{
    let n=Q(t);
    if(!n)
    return null;
    let r=Q(n.cost),i={};
    for(
    let[e,t]
    of Object.entries(n))
    e!==`cost`&&e!==`provider`&&(i[e]=t);
    let a={key:e,label:_t(e),costRows:r?ra(r):[],optionRows:ia(i)};
    return a.costRows.length===0&&a.optionRows.length===0?null:a
    }).filter(e=>e!==null);
  return n.length===0?null:{modes:n}
  }
function ra(e){
  let t=[`input`,`output`,`reasoning`,`cache_read`,`cache_write`,`input_audio`,`output_audio`],n=[],r=new Set;
  for(
  let i
   of t){
    let t=$(e,i);
    t!==null&&(n.push({label:_t(i),value:t}),r.add(i))
    }
  for(
  let{path:t,value:i}
  of aa(e)){
    let e=t.join(`.`);
    r.has(e)||typeof i!=`number`||!Number.isFinite(i)||n.push({label:_t(t.join(` `)),value:i})
    }
  return n
  }
function ia(e){
  return aa(e).map(({path:e,value:t})=>({path:e.join(`.`),value:oa(t)}))
  }
function aa(e,t=[]){
  return Object.entries(e).flatMap(([e,n])=>{
    let r=[...t,e],i=Q(n);
    return i?aa(i,r):[{path:r,value:n}]
    })
  }
function oa(e){
  return typeof e==`string`?e:typeof e==`number`?Number.isInteger(e)?M(e):String(e):typeof e==`boolean`?e?`true`:`false`:e===null?`null`:JSON.stringify(e)??`Unknown`
  }
function Q(e){
  return!e||Array.isArray(e)||typeof e!=`object`?null:e
  }
function $(e,t){
  let n=e[t];
  return typeof n==`number`&&Number.isFinite(n)?n:null
  }
function sa(){
  return(0,d.jsx)(K,{eyebrow:`Model terminology`,title:`What knowledge cutoff means`,triggerLabel:`What does this mean?`,entries:[{term:`Knowledge cutoff`,description:`is the newest point in time the model is generally expected to know from training. It is the line after which its built-in world knowledge may become patchy, outdated, or simply missing.`},{term:`Why it matters`,description:`helps you judge whether a model can answer from memory or whether it should use search, retrieval, or fresh documents. If you ask about events, pricing, regulations, or product changes after the cutoff, the model may sound confident while being wrong.`},{term:`Think of it like`,description:`a newspaper archive that stops on a certain date. The model can often discuss everything in the archive well, but it does not automatically know what happened in later editions.`},{term:`Common scenarios`,description:`matter most when checking current APIs, recent model releases, legal or policy changes, company leadership updates, or any time-sensitive business facts.`}],note:`If this says Unknown, the provider likely has not published a reliable cutoff date. In that case, treat recent factual questions with extra caution and prefer grounding the model with current sources.`})
  }
function ca(){
  return(0,d.jsx)(K,{eyebrow:`Model terminology`,title:`What input modalities mean`,triggerLabel:`What do these mean?`,entries:[{term:`Input modalities`,description:`describe the kinds of content the model can accept, such as text, images, audio, or files.`}]})
  }
function la(){
  return(0,d.jsx)(K,{eyebrow:`Model terminology`,title:`What output modalities mean`,triggerLabel:`What do these mean?`,entries:[{term:`Output modalities`,description:`describe the kinds of responses the model can produce, such as text, images, audio, or structured data.`}]})
  }
function ua(){
  return(0,d.jsx)(K,{eyebrow:`Model terminology`,title:`What capabilities mean`,triggerLabel:`What do these mean?`,entries:[{term:`Capabilities`,description:`are notable features or behaviors the model supports, such as tool calling, structured output, attachments, or temperature controls.`}],note:`These labels describe available features, not an overall quality score.`})
  }
function da(){
  return(0,d.jsx)(K,{eyebrow:`Model terminology`,title:`What a provider means`,triggerLabel:`What is a provider?`,entries:[{term:`Provider`,description:`is the company, platform, or API source that makes a model available for you to use.`},{term:`Same model, different providers`,description:`means the underlying model can stay the same while different services host it, route to it, or package it with their own pricing, limits, regions, and features.`}],note:`Think of the model as the engine and the provider as the service that lets you access it. The provider can be the model maker, but it can also be a third-party service.`})
  }
function fa(){
  return(0,d.jsx)(K,{eyebrow:`SDK terminology`,title:`What this AI SDK package means`,triggerLabel:`What does this mean?`,entries:[{term:`AI SDK package`,description:`is the JavaScript adapter package that tells AI SDK-compatible code which provider implementation to use for this model route.`},{term:`Why it matters`,description:`is that the visible provider name is not always enough. A gateway can expose one company's model through another platform, so this value helps developers check the right request format, options, and provider-specific behavior.`},{term:`In OpenCode`,description:`this maps to the provider npm setting. OpenCode uses the AI SDK and Models.dev, and this value tells OpenCode which AI SDK adapter to load for that provider or model override.`}],note:`This row appears only when Models.dev sends a model-level provider npm override that looks like an @ai-sdk package. Other provider package names are intentionally left out here.`})
  }
function pa({title:e,body:t,actionHref:n,actionLabel:r}){
  return(0,d.jsxs)(`div`,{className:`surface-paper grid place-items-center gap-4 rounded-[1.9rem] p-8 text-center`,children:[(0,d.jsx)(`h2`,{className:`font-serif text-[2rem] tracking-[-0.05em] text-[color:var(--color-ink)]`,children:e}),(0,d.jsx)(`p`,{className:`mx-auto max-w-2xl text-sm leading-7 text-[color:var(--color-muted)]`,children:t}),n&&r?(0,d.jsx)(s,{className:`button-secondary button-compact`,href:n,children:r}):null]})
  }
function ma({children:e}){
  return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(`div`,{className:`site-background`}),(0,d.jsxs)(`div`,{className:`relative flex min-h-screen flex-col`,children:[(0,d.jsx)(Li,{}),(0,d.jsx)(`div`,{className:`flex-1 lg:pt-[5.75rem]`,children:e}),(0,d.jsx)(Mi,{}),(0,d.jsx)(Nn,{}),(0,d.jsx)(gt,{})]})]})
  }
e({title:e=>e||`AI models and providers | Sulat`,resolve:e=>l(`./pages/${e}.tsx`,Object.assign({"./pages/errors/not-found.tsx":()=>c(()=>import(`./not-found-yyJcVEDC.js`),__vite__mapDeps([0,1,2])),"./pages/home.tsx":()=>c(()=>import(`./home.js`),__vite__mapDeps([3,1,4,5,6,7,2,8])),"./pages/models/index.tsx":()=>c(()=>import(`./models-Jle1TdXI.js`),__vite__mapDeps([9,1,2,10,6])),"./pages/models/show.tsx":()=>c(()=>import(`./model-detail.js`),__vite__mapDeps([11,1,12,8,2])),"./pages/news/index.tsx":()=>c(()=>import(`./news-4C3bChlY.js`),__vite__mapDeps([13,1,5,2])),"./pages/providers/index.tsx":()=>c(()=>import(`./providers-DbU6Pt6x.js`),__vite__mapDeps([14,1,2,10,6])),"./pages/providers/show.tsx":()=>c(()=>import(`./show-D91tR7XN.js`),__vite__mapDeps([15,1,12,8,2,10,6]))})).then(e=>e.default),layout:()=>ma,strictMode:!0,withApp(e){
  return(0,d.jsx)(ct,{children:e})
  },progress:{color:`#d97706`}});
export{Hn as $,Cr as A,Ve as At,or as B,ti as C,Dt as Ct,jr as D,_t as Dt,kr as E,M as Et,fr as F,y as Ft,zn as G,cr as H,ar as I,ne as It,Rn as J,Ln as K,ur as L,pe as Lt,Sr as M,k as Mt,br as N,D as Nt,Mr as O,lt as Ot,hr as P,ce as Pt,In as Q,sr as R,p as Rt,ni as S,Tt as St,Ur as T,j as Tt,$n as U,dr as V,Gn as W,Un as X,Vn as Y,Wn as Z,zi as _,Bt as _t,Wi as a,dn as at,si as b,At as bt,Ki as c,Kt as ct,la as d,Gt as dt,Bn as et,Gi as f,qt as ft,Ri as g,Vt as gt,Bi as h,Ft as ht,pa as i,fn as it,xr as j,A as jt,Er as k,it as kt,Vi as l,W as lt,da as m,It as mt,X as n,G as nt,ca as o,un as ot,Ui as p,Jt as pt,Kn as q,ua as r,pn as rt,sa as s,ln as st,fa as t,Yn as tt,Ji as u,H as ut,qi as v,Wt as vt,$r as w,bt as wt,ci as x,I as xt,hi as y,L as yt,lr as z};
