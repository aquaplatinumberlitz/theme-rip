import{Dt as e,Tt as t}from"./app.js";
import{t as n}from"./filter-options.js";
var r=new Intl.NumberFormat(`en`,{notation:`compact`,maximumFractionDigits:1}),i={month:`short`,day:`numeric`,year:`numeric`,timeZone:`UTC`};
function a(e){
  return new Intl.NumberFormat(`en-US`,{style:`currency`,currency:`USD`,minimumFractionDigits:2,maximumFractionDigits:e<1?3:2}).format(e)
  }
function o(e){
  return`${a(e.input)} in · ${a(e.output)} out`
  }
function s(e){
  return`Released ${t(e.releaseDate,i)}`
  }
function c(e){
  return e.contextWindow===null?null:`${r.format(e.contextWindow)} context`
  }
function l(t){
  if(t.input.length===0||t.output.length===0)
  return null;
  let r=t=>t.map(t=>n.find(e=>e.value===t)?.label??e(t)).join(`, `);
  return`${r(t.input)} → ${r(t.output)}`
  }
function u(e){
  return[e.reasoning?`Reasoning`:null,e.toolCall?`Tool calling`:null,e.openWeights?`Open weights`:null].filter(e=>e!==null).join(` · `)
  }
function d(e){
  return[c(e),l(e.modalities)].filter(e=>e!==null).join(` · `)
  }
function f(e){
  return`Cheapest ${e.routes.length} of ${e.providerCount.toLocaleString(`en`)} providers · USD per 1M tokens`
  }
export{f as a,o as i,d as n,a as o,s as r,u as t};
