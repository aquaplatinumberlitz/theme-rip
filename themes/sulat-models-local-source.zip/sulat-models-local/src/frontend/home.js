const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/hero-scene.js","assets/app.js","assets/react-inertia-runtime.js","assets/preload.js","assets/hero-format.js","assets/filter-options.js"])))=>i.map(i=>d[i]);


import{c as e,l as t,n,p as r,r as i,t as a}from"./react-inertia-runtime.js";
import{t as o}from"./preload.js";
import{t as s}from"./arrow-icon.js";
import{C as c,Ct as l,D as u,Dt as d,E as f,O as p,Pt as m,St as h,T as g,Tt as _,_ as v,at as y,g as b,i as x,it as S,kt as C,ot as w,p as T,rt as E,tt as D,w as O,wt as k,y as A,yt as j}from"./app.js";
import{t as M}from"./filter-options.js";
import{a as N,i as ee,n as te,o as P,r as ne,t as F}from"./hero-format.js";
import{t as re}from"./seo.js";
import{n as ie}from"./news-ui.js";
var I=r(e(),1),ae=[`16`,`24`],oe={16:{width:16,path:I.createElement(`path`,{d:`M5 2h1a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1H5a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Zm5 0h1a1 1 0 0 1 1 1v10a1 1 0 0 1-1 1h-1a1 1 0 0 1-1-1V3a1 1 0 0 1 1-1Z`})},24:{width:24,path:I.createElement(`path`,{d:`M9 3H7.5A1.5 1.5 0 0 0 6 4.5v15A1.5 1.5 0 0 0 7.5 21H9a1.5 1.5 0 0 0 1.5-1.5v-15A1.5 1.5 0 0 0 9 3Zm7.5 0H15a1.5 1.5 0 0 0-1.5 1.5v15A1.5 1.5 0 0 0 15 21h1.5a1.5 1.5 0 0 0 1.5-1.5v-15A1.5 1.5 0 0 0 16.5 3Z`})}},L=I.forwardRef(function(e,t){
  return g(e,t,`octicon octicon-pause`,oe,ae)
  });
L.displayName=`PauseIcon`;
var se=[`16`,`24`],ce={16:{width:16,path:I.createElement(`path`,{d:`M8 0a8 8 0 1 1 0 16A8 8 0 0 1 8 0ZM1.5 8a6.5 6.5 0 1 0 13 0 6.5 6.5 0 0 0-13 0Zm4.879-2.773 4.264 2.559a.25.25 0 0 1 0 .428l-4.264 2.559A.25.25 0 0 1 6 10.559V5.442a.25.25 0 0 1 .379-.215Z`})},24:{width:24,path:I.createElement(I.Fragment,null,I.createElement(`path`,{d:`M9.5 15.584V8.416a.5.5 0 0 1 .77-.42l5.576 3.583a.5.5 0 0 1 0 .842l-5.576 3.584a.5.5 0 0 1-.77-.42Z`}),I.createElement(`path`,{d:`M1 12C1 5.925 5.925 1 12 1s11 4.925 11 11-4.925 11-11 11S1 18.075 1 12Zm11-9.5A9.5 9.5 0 0 0 2.5 12a9.5 9.5 0 0 0 9.5 9.5 9.5 9.5 0 0 0 9.5-9.5A9.5 9.5 0 0 0 12 2.5Z`}))}},R=I.forwardRef(function(e,t){
  return g(e,t,`octicon octicon-play`,ce,se)
  });
R.displayName=`PlayIcon`;
var z=n();
function B({children:e}){
  return(0,z.jsx)(`section`,{id:`news`,"aria-labelledby":`home-news-heading`,className:`mx-auto max-w-7xl scroll-mt-28 px-6 py-12 sm:px-8 lg:px-12`,children:(0,z.jsxs)(`div`,{className:`grid gap-8 rounded-[1.8rem] border border-[color:var(--color-line)] bg-[color:var(--color-background-strong)] p-5 sm:p-8 lg:grid-cols-[minmax(0,0.85fr)_minmax(0,1.15fr)]`,children:[(0,z.jsxs)(`div`,{className:`grid content-center justify-items-start gap-5 px-1 py-3 sm:px-3 lg:py-6`,children:[(0,z.jsx)(`p`,{className:`eyebrow`,children:`Sulat news`}),(0,z.jsx)(`h2`,{id:`home-news-heading`,className:`max-w-[11ch] font-serif text-[2.75rem] leading-[1.1] tracking-[-0.045em] text-[color:var(--color-ink)] sm:text-[3.4rem] lg:text-[3.75rem]`,children:`A home for AI news.`}),(0,z.jsx)(`p`,{className:`max-w-sm text-lg leading-7 text-[color:var(--color-muted)]`,children:`Model releases, provider updates, and independent reporting.`}),(0,z.jsxs)(a,{href:`/news`,className:`mt-1 inline-flex min-h-12 items-center justify-center gap-3 rounded-full bg-[color:var(--color-ink)] px-6 py-3.5 text-base font-semibold text-[color:var(--color-background)]! transition hover:bg-[color:var(--color-accent-deep)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--color-accent-deep)]`,children:[`Visit the news page`,(0,z.jsx)(s,{"aria-hidden":`true`,size:20})]}),(0,z.jsxs)(`a`,{href:`/news/feed`,className:`inline-flex min-h-11 items-center gap-3 rounded-md text-base text-[color:var(--color-accent-deep)]! underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--color-accent-deep)]`,children:[(0,z.jsx)(O,{"aria-hidden":`true`,size:22}),`Subscribe via RSS`]})]}),(0,z.jsxs)(`div`,{className:`min-w-0 rounded-[1.35rem] border border-[color:var(--color-line)] bg-[color:var(--color-surface)] px-5 py-6 sm:px-7 sm:py-7`,children:[(0,z.jsx)(`h3`,{className:`eyebrow`,children:`Latest from the newsroom`}),e]})]})})
  }
function le(){
  return(0,z.jsx)(B,{children:(0,z.jsxs)(`div`,{role:`status`,className:`mt-2 divide-y divide-[color:var(--color-line)]`,children:[(0,z.jsx)(`span`,{className:`sr-only`,children:`Loading latest news`}),[1,2,3].map(e=>(0,z.jsxs)(`div`,{"aria-hidden":`true`,className:`space-y-3 py-6`,children:[(0,z.jsx)(`div`,{className:`h-3 w-24 rounded bg-[color:var(--color-line)] motion-safe:animate-pulse`}),(0,z.jsx)(`div`,{className:`h-6 w-5/6 rounded bg-[color:var(--color-line)] motion-safe:animate-pulse`}),(0,z.jsx)(`div`,{className:`h-6 w-2/3 rounded bg-[color:var(--color-line)] motion-safe:animate-pulse`})]},e))]})})
  }
function ue({articles:e}){
  let[t,n]=(0,I.useState)(null),r=e.slice(0,3);
  return(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(B,{children:r.length>0?(0,z.jsx)(`ul`,{className:`mt-2 divide-y divide-[color:var(--color-line)]`,children:r.map(e=>(0,z.jsxs)(`li`,{className:`space-y-2 py-6 last:pb-1`,children:[(0,z.jsx)(`p`,{className:`text-xs font-semibold tracking-[0.16em] break-words text-[color:var(--color-muted)] uppercase`,children:e.sourceName}),(0,z.jsx)(`h4`,{children:(0,z.jsxs)(`button`,{type:`button`,"aria-haspopup":`dialog`,className:`group flex min-h-11 w-full items-center justify-between gap-4 rounded-sm text-left font-serif text-[1.35rem] leading-snug tracking-[-0.03em] text-[color:var(--color-ink)] transition hover:text-[color:var(--color-accent-deep)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--color-accent-deep)] sm:text-[1.55rem]`,onClick:()=>n(e),children:[(0,z.jsx)(`span`,{className:`min-w-0 break-words`,children:e.title}),(0,z.jsx)(s,{"aria-hidden":`true`,size:20,className:`shrink-0 text-[color:var(--color-muted)] group-hover:text-[color:var(--color-accent-deep)]`})]})})]},e.id))}):(0,z.jsx)(`p`,{className:`mt-6 text-base leading-7 text-[color:var(--color-muted)]`,children:`Latest stories will appear here as the newsroom updates. Visit the news page or subscribe via RSS to follow along.`})}),t?(0,z.jsx)(ie,{article:{...t,summaryParagraphs:t.paragraphs,sourceHost:null},onClose:()=>n(null)}):null]})
  }
function de(e){
  return document.addEventListener(`visibilitychange`,e),()=>document.removeEventListener(`visibilitychange`,e)
  }
function fe(){
  return(0,I.useSyncExternalStore)(de,()=>document.visibilityState===`visible`,()=>!0)
  }
function V(e){
  let[t,n]=(0,I.useState)(!1);
  return(0,I.useEffect)(()=>{
    let t=e.current;
    if(!t||typeof IntersectionObserver>`u`)
    return;
    let r=new IntersectionObserver(([e])=>n(e.isIntersecting),{threshold:.15});
    return r.observe(t),()=>r.disconnect()
    },[e]),t
  }
function pe(e){
  let t,n,r=()=>{
    typeof window.requestIdleCallback==`function`?n=window.requestIdleCallback(e,{timeout:2e3}):t=window.setTimeout(e,0)
    };
  return document.readyState===`complete`?r():window.addEventListener(`load`,r,{once:!0}),()=>{
    window.removeEventListener(`load`,r),window.clearTimeout(t),n!==void 0&&window.cancelIdleCallback(n)
    }
  }
function me(){
  return navigator.connection?.saveData===!0
  }
function he({scenes:e,enabled:t,stageRef:n,canvasRef:r,labelsRef:i,onSceneChange:a}){
  let[s,c]=(0,I.useState)(null);
  return(0,I.useEffect)(()=>{
    let s=n.current,l=r.current,u=i.current;
    if(!t||!s||!l||!u||me())
    return;
    let d=!1,f=null,p=window.matchMedia?.(`(prefers-color-scheme: dark)`),m=pe(async()=>{
      try{
        let{createHeroShowcaseScene:t,readHeroShowcaseTheme:n}=await o(async()=>{
          let{createHeroShowcaseScene:e,readHeroShowcaseTheme:t}=await import(`./hero-scene.js`);
          return{createHeroShowcaseScene:e,readHeroShowcaseTheme:t}
          },__vite__mapDeps([0,1,2,3,4,5])),r=await t({canvas:l,labelLayer:u,scenes:e,theme:n(s),onSceneChange:a});
        if(d){
          r.dispose();
          return
          }
        let i=()=>r.setTheme(n(s));
        p?.addEventListener(`change`,i),f={...r,dispose:()=>{
          p?.removeEventListener(`change`,i),r.dispose()
          }},c(f)
        }catch(e){
        console.warn(`Home hero kept its static orbit:`,e)
        }
      });
    return()=>{
      d=!0,m(),f?.dispose(),c(null)
      }
    },[t,e,n,r,i,a]),s
  }
function ge({scene:e}){
  let t=F(e.capabilities),n=e.routes[0];
  return(0,z.jsxs)(`div`,{className:`hero-showcase-fallback absolute inset-0`,children:[(0,z.jsx)(`span`,{className:`hero-showcase-ring`}),e.routes.map((t,n)=>{
    let r=90+n/e.routes.length*360;
    return(0,z.jsx)(`span`,{className:[`hero-showcase-coin flex size-8 items-center justify-center rounded-full p-1.5 sm:size-10`,Math.sin(r*Math.PI/180)>0?`z-20`:`z-0`].join(` `),style:{"--angle":`${r}deg`},children:(0,z.jsx)(`img`,{alt:``,className:`size-full object-contain`,src:u(t)})},t.providerSlug)
    }),(0,z.jsxs)(`div`,{className:`hero-showcase-token absolute top-1/2 left-1/2 z-10 w-[min(62%,23rem)] -translate-x-1/2 -translate-y-1/2 rounded-2xl px-4 py-3 sm:top-[45%] sm:w-[min(56%,22rem)] sm:px-6 sm:py-5`,children:[(0,z.jsxs)(`div`,{className:`flex items-baseline justify-between gap-3 text-[0.72rem] text-[color:var(--hero-3d-muted)]`,children:[(0,z.jsx)(`span`,{className:`hidden truncate sm:inline`,children:ne(e)}),(0,z.jsxs)(`span`,{className:`shrink-0 font-semibold text-[color:var(--hero-3d-accent)]`,children:[e.providerCount.toLocaleString(`en`),` providers`]})]}),(0,z.jsx)(`p`,{className:`mt-1 truncate font-serif text-[1.35rem] leading-tight tracking-[-0.03em] text-[color:var(--hero-3d-ink)] sm:text-[1.9rem]`,children:e.name}),(0,z.jsx)(`p`,{className:`mt-1.5 truncate text-[0.8rem] text-[color:var(--hero-3d-muted)]`,children:te(e)}),t?(0,z.jsx)(`p`,{className:`hidden truncate text-[0.8rem] text-[color:var(--hero-3d-muted)] sm:block`,children:t}):null]}),n?(0,z.jsxs)(`div`,{className:`hero-showcase-label absolute top-[calc(50%+var(--hero-orbit-ry)+1.4rem)] left-1/2 z-20 -translate-x-1/2`,children:[(0,z.jsxs)(`strong`,{children:[n.providerName,(0,z.jsx)(`span`,{className:`hero-showcase-lowest-tag`,children:`Lowest`})]}),(0,z.jsx)(`span`,{children:ee(n)})]}):null]})
  }
function _e({scenes:e}){
  let t=(0,I.useRef)(null),n=(0,I.useRef)(null),r=(0,I.useRef)(null),i=A(),a=V(t),o=fe(),[s,c]=(0,I.useState)(!1),[l,u]=(0,I.useState)(0),d=he({scenes:e,enabled:!i&&e.length>0,stageRef:t,canvasRef:n,labelsRef:r,onSceneChange:u}),f=d?`animated`:`static`,p=d!==null&&a&&o&&!s;
  (0,I.useEffect)(()=>{
    d?.setPlaying(p)
    },[d,p]);
  let m=e[d?l:0];
  return m?(0,z.jsxs)(`div`,{className:`grid gap-3`,children:[(0,z.jsxs)(`div`,{"aria-hidden":`true`,className:`hero-showcase-stage -mx-5 h-[21rem] sm:mx-0 sm:h-[24rem] lg:h-[28rem]`,"data-hero-showcase":!0,"data-status":f,ref:t,children:[(0,z.jsx)(ge,{scene:e[0]}),(0,z.jsx)(`canvas`,{className:`hero-showcase-canvas absolute inset-0 size-full`,ref:n}),(0,z.jsx)(`div`,{className:`hero-showcase-labels pointer-events-none absolute inset-0`,ref:r})]}),(0,z.jsxs)(`div`,{className:`flex min-h-8 items-center justify-between gap-4 text-xs text-[color:var(--color-muted)]`,children:[(0,z.jsx)(`p`,{"aria-hidden":`true`,children:N(m)}),f===`animated`?(0,z.jsx)(`button`,{"aria-label":s?`Play hero animation`:`Pause hero animation`,className:`inline-flex size-8 shrink-0 items-center justify-center rounded-full border border-[color:var(--color-line)] transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)] focus-visible:border-[color:var(--color-accent)] focus-visible:ring-2 focus-visible:ring-[color:var(--color-accent)]/25 focus-visible:outline-none`,onClick:()=>c(e=>!e),type:`button`,children:s?(0,z.jsx)(R,{size:14}):(0,z.jsx)(L,{size:14})}):null]})]}):null
  }
var ve=`/models`,H=10,U=`hero-model-search-results`,W=[`models`];
function G(e){
  return`${ve}?search=${encodeURIComponent(e)}`
  }
function ye(){
  let e=(0,I.useRef)(null),n=(0,I.useRef)(null),r=(0,I.useRef)(null),[i,a]=(0,I.useState)(``),[o,s]=(0,I.useState)(!1),[c,u]=(0,I.useState)(!1),[d,f]=(0,I.useState)(-1),p=i.trim().length>0,g=c||p,_=j(i),v=j(S((0,I.useDeferredValue)(i))),b=_!==void 0,x=C({queryKey:E.commandSearch({search:v,perType:H,types:W}),queryFn:({signal:e})=>y({search:v,perType:H,types:W},{signal:e}),enabled:(o||p)&&v!==void 0,placeholderData:m,retry:!1,staleTime:2e4}),w=x.data?.models??[],T=d>=0&&d<w.length?w[d]:void 0,D=(o||p)&&b,O=D&&(x.isFetching||v!==_),k=(0,I.useCallback)(()=>{
    document.scrollingElement?.scrollTo({top:0,left:0,behavior:`auto`}),document.documentElement.scrollTop=0,document.body.scrollTop=0,window.scrollTo({top:0,left:0,behavior:`auto`})
    },[]);
  (0,I.useLayoutEffect)(()=>{
    let t=document.documentElement,n=t.style.overflow,r=t.style.overscrollBehavior,i=document.body.style.overflow,a=document.body.style.overscrollBehavior,o=document.body.style.position,s=document.body.style.top,c=document.body.style.left,l=document.body.style.right,u=document.body.style.width,d=0,f=t=>{
      if(!(t instanceof Node))
      return null;
      let n=e.current?.querySelector(`[role='listbox']`);
      return n?.contains(t)?n:null
      },p=(e,t)=>t<0?e.scrollTop>0:t>0?e.scrollTop+e.clientHeight<e.scrollHeight:!0,m=e=>{
      let t=f(e.target);
      (!t||!p(t,e.deltaY))&&e.preventDefault()
      },h=e=>{
      e.touches.length===1&&(d=e.touches[0].clientY)
      },_=e=>{
      if(e.touches.length!==1)
      return;
      let t=e.touches[0].clientY,n=d-t,r=f(e.target);
      d=t,(!r||!p(r,n))&&e.preventDefault()
      };
    return g?(document.body.setAttribute(`data-hero-search-active`,`true`),k(),t.style.overflow=`hidden`,t.style.overscrollBehavior=`none`,document.body.style.overflow=`hidden`,document.body.style.overscrollBehavior=`none`,document.body.style.position=`fixed`,document.body.style.top=`0`,document.body.style.left=`0`,document.body.style.right=`0`,document.body.style.width=`100%`,document.addEventListener(`wheel`,m,{passive:!1}),document.addEventListener(`touchstart`,h,{passive:!0}),document.addEventListener(`touchmove`,_,{passive:!1})):document.body.removeAttribute(`data-hero-search-active`),()=>{
      document.body.removeAttribute(`data-hero-search-active`),document.removeEventListener(`wheel`,m),document.removeEventListener(`touchstart`,h),document.removeEventListener(`touchmove`,_),t.style.overflow=n,t.style.overscrollBehavior=r,document.body.style.overflow=i,document.body.style.overscrollBehavior=a,document.body.style.position=o,document.body.style.top=s,document.body.style.left=c,document.body.style.right=l,document.body.style.width=u
      }
    },[g,k]),(0,I.useEffect)(()=>{
    if(!o)
    return;
    function t(t){
      let n=t.target;
      n instanceof Node&&(e.current?.contains(n)||s(!1))
      }
    function n(e){
      e.key===`Escape`&&s(!1)
      }
    return document.addEventListener(`pointerdown`,t),window.addEventListener(`keydown`,n),()=>{
      document.removeEventListener(`pointerdown`,t),window.removeEventListener(`keydown`,n)
      }
    },[o]);
  let A=e=>{
    s(!1),(0,I.startTransition)(()=>{
      t.visit(e)
      })
    },M=()=>{
    a(``),s(!1),u(!1),f(-1),n.current?.blur(),r.current?.blur()
    },N=()=>{
    k(),u(!0),n.current?.focus({preventScroll:!0})
    };
  return(0,z.jsxs)(`div`,{ref:e,className:`hero-search-shell relative z-30`,"data-hero-search-shell":!0,onBlurCapture:t=>{
    let n=t.relatedTarget;
    (!(n instanceof Node)||!e.current?.contains(n))&&u(!1)
    },onFocusCapture:()=>{
    u(!0)
    },children:[(0,z.jsxs)(`div`,{className:`surface-panel rounded-[1.7rem] p-3`,children:[(0,z.jsx)(`label`,{className:`sr-only`,htmlFor:`catalog-search`,children:`Search AI models`}),(0,z.jsxs)(`div`,{className:`relative`,children:[(0,z.jsx)(`input`,{ref:n,id:`catalog-search`,type:`search`,minLength:2,autoComplete:`off`,placeholder:`Search models or providers`,className:`field-input w-full pr-14`,role:`combobox`,"aria-autocomplete":`list`,"aria-controls":D?U:void 0,"aria-expanded":D,"aria-activedescendant":D&&T?`${U}-result-${T.id}`:void 0,value:i,onPointerDown:e=>{
    e.pointerType===`touch`||document.activeElement===n.current||(e.preventDefault(),N())
    },onFocus:()=>{
    b&&s(!0)
    },onChange:e=>{
    let t=e.target.value;
    a(t),f(-1),s(j(t)!==void 0)
    },onKeyDown:e=>{
    if(!D){
      e.key===`Enter`&&_&&(e.preventDefault(),A(G(_)));
      return
      }
    if(e.key===`ArrowDown`&&w.length>0){
      e.preventDefault(),f(d<0||d>=w.length?0:(d+1)%w.length);
      return
      }
    if(e.key===`ArrowUp`&&w.length>0){
      e.preventDefault(),f(d<0||d>=w.length||d===0?w.length-1:d-1);
      return
      }
    if(e.key===`Enter`){
      e.preventDefault(),A(T?.href?T.href:G(_));
      return
      }
    e.key===`Escape`&&(e.preventDefault(),s(!1))
    }}),p?(0,z.jsx)(`button`,{ref:r,type:`button`,"aria-label":`Clear search`,className:`absolute top-1/2 right-2 inline-flex h-9 w-9 -translate-y-1/2 items-center justify-center rounded-full border border-[color:var(--color-line)] bg-white/90 text-[color:var(--color-muted)] transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,onPointerDown:e=>{
    e.preventDefault()
    },onClick:M,children:(0,z.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,z.jsx)(`path`,{d:`M4 4l8 8M12 4l-8 8`,stroke:`currentColor`,strokeLinecap:`round`,strokeWidth:`1.4`})})}):null]})]}),D?(0,z.jsx)(l,{activeIndex:d,className:`absolute inset-x-0 top-full mt-3`,emptyState:O?`Searching models...`:`No quick model matches yet. Try a broader model name or an exact model identifier.`,errorState:`Quick model search is temporarily unavailable. Continue in the full model explorer to see the complete results.`,footer:(0,z.jsxs)(`button`,{type:`button`,className:`button-secondary`,onClick:()=>A(G(_)),children:[`View all model results`,(0,z.jsx)(h,{})]}),hasError:x.isError,headerSummary:O?`Searching…`:`${w.length} quick matches`,listClassName:`max-h-[24rem]`,listId:U,onResultClick:e=>A(e.href),onResultHover:f,results:w}):null]})
  }
function K({provider:e}){
  let t=u(e),n=p(e);
  return(0,z.jsx)(a,{href:`/providers/${e.slug}`,className:`group focus-visible:ring-accent/20 inline-flex h-16 w-16 shrink-0 items-center justify-center rounded-[1.2rem] border border-[color:var(--color-line)] bg-[color:var(--color-logo-well)] p-3 transition hover:-translate-y-0.5 hover:border-[color:var(--color-line-strong)] hover:bg-[color:var(--color-logo-well)] focus-visible:-translate-y-0.5 focus-visible:border-[color:var(--color-accent)] focus-visible:ring-2 focus-visible:outline-none`,title:e.name,"aria-label":`Open provider page for ${e.name}`,children:(0,z.jsxs)(`picture`,{className:`h-full w-full`,children:[n?null:(0,z.jsx)(`source`,{srcSet:f,media:`(prefers-color-scheme: dark)`}),(0,z.jsx)(`img`,{src:t,alt:n?`${e.name} logo`:``,"aria-hidden":!n||void 0,className:`h-full w-full object-contain`,loading:`lazy`})]})})
  }
function be({providers:e,className:t}){
  let n=(0,I.useRef)(null),r=(0,I.useRef)(null),i=(0,I.useRef)(null),a=(0,I.useRef)(!1);
  return(0,I.useEffect)(()=>{
    let e=r.current,t=i.current;
    if(!e||!t)
    return;
    let n=0,o=0,s=0,c=t.scrollWidth,l=()=>{
      if(c=t.scrollWidth,c<=0){
        e.style.transform=`translate3d(0, 0, 0)`;
        return
        }
      s%=c,e.style.transform=`translate3d(${-s}px, 0, 0)`
      },u=new ResizeObserver(()=>{
      l()
      });
    u.observe(t),l();
    let d=t=>{
      o||=t;
      let r=(t-o)/1e3;
      o=t,!a.current&&c>0&&(s+=26*r,s>=c&&(s%=c),e.style.transform=`translate3d(${-s}px, 0, 0)`),n=window.requestAnimationFrame(d)
      };
    return n=window.requestAnimationFrame(d),()=>{
      window.cancelAnimationFrame(n),u.disconnect()
      }
    },[]),e.length===0?null:(0,z.jsxs)(`div`,{className:t?`grid gap-3 ${t}`:`grid gap-3`,children:[(0,z.jsx)(`p`,{className:`eyebrow`,children:`Popular providers`}),(0,z.jsx)(`div`,{ref:n,"aria-label":`Popular providers carousel`,role:`region`,className:`provider-carousel-shell provider-carousel-mask overflow-hidden rounded-[1.8rem] border border-[color:var(--color-line)] bg-white/75 px-2 py-2`,onMouseEnter:()=>{
    a.current=!0
    },onMouseLeave:()=>{
    a.current=!1
    },onFocusCapture:()=>{
    a.current=!0
    },onBlurCapture:()=>{
    let e=n.current;
    window.requestAnimationFrame(()=>{
      a.current=!!(e?.matches(`:hover`)||e?.contains(document.activeElement))
      })
    },children:(0,z.jsxs)(`div`,{ref:r,className:`provider-carousel-marquee flex w-max transform-gpu items-center`,children:[(0,z.jsx)(`div`,{ref:i,className:`provider-carousel-segment flex shrink-0 items-center gap-3 pr-3`,children:e.map(e=>(0,z.jsx)(K,{provider:e},e.id))}),(0,z.jsx)(`div`,{"aria-hidden":`true`,inert:!0,className:`provider-carousel-segment flex shrink-0 items-center gap-3 pr-3`,children:e.map(e=>(0,z.jsx)(K,{provider:e},`${e.id}-clone`))})]})})]})
  }
function xe({featuredProviders:e=[],showcaseScenes:t=[]}){
  return(0,z.jsx)(`section`,{"aria-labelledby":`home-hero-heading`,className:`hero-shell relative`,"data-hero-search-root":!0,children:(0,z.jsxs)(`div`,{className:`mx-auto grid max-w-7xl gap-6 px-6 pt-8 pb-12 sm:px-8 lg:px-12 lg:pt-12`,"data-hero-search-container":!0,children:[(0,z.jsx)(`div`,{className:`hero-search-copy-shell`,"data-hero-search-copy-shell":!0,children:(0,z.jsx)(`div`,{className:`hero-search-copy-inner`,"data-hero-search-copy-inner":!0,children:(0,z.jsxs)(`div`,{className:`hero-showcase-panel grid items-center gap-8 rounded-[min(4vw,2rem)] border border-[color:var(--color-line)] px-5 py-7 sm:gap-10 sm:px-10 sm:py-12 lg:grid-cols-[minmax(0,1fr)_minmax(0,1.1fr)] lg:gap-8 lg:py-8 lg:pr-8 lg:pl-14`,children:[(0,z.jsxs)(`div`,{className:`@container grid content-center gap-4 sm:gap-5`,children:[(0,z.jsx)(`p`,{className:`eyebrow`,children:`The AI model directory`}),(0,z.jsxs)(`h1`,{id:`home-hero-heading`,className:`font-serif text-[length:clamp(1.75rem,10.5cqi,3.75rem)] leading-[1.02] tracking-[-0.045em] text-[color:var(--color-ink)]`,children:[(0,z.jsx)(`span`,{className:`block`,children:`Find AI models.`}),` `,(0,z.jsx)(`span`,{className:`block`,children:`See who serves them.`})]}),(0,z.jsx)(`p`,{className:`max-w-md text-base leading-7 text-[color:var(--color-muted)] sm:text-lg sm:leading-8`,children:`Search the catalog, compare the details, then follow any model to its providers.`})]}),(0,z.jsx)(_e,{scenes:t})]})})}),(0,z.jsxs)(`div`,{className:`grid gap-6`,children:[(0,z.jsxs)(`div`,{className:`grid gap-3`,children:[(0,z.jsx)(`div`,{className:`eyebrow`,children:`Search the model catalog`}),(0,z.jsx)(ye,{})]}),e.length>0?(0,z.jsx)(`div`,{"data-hero-search-dim":!0,children:(0,z.jsx)(be,{providers:e})}):null,(0,z.jsxs)(`div`,{className:`hidden flex-wrap gap-3 lg:flex`,"data-hero-search-dim":!0,children:[(0,z.jsx)(a,{className:`button-secondary`,href:`/models?sort=releaseDate&dir=desc`,children:`Latest model releases`}),(0,z.jsx)(a,{className:`button-secondary`,href:`/providers`,children:`Provider index`})]})]})]})})
  }
function Se(...e){
  return e.filter(Boolean).join(` `)
  }
function q(e){
  return M.find(t=>t.value===e)?.label??d(e)
  }
function J({value:e,direction:t}){
  let[n,r]=(0,I.useState)(!1),[i,a]=(0,I.useState)(!1),[o,s]=(0,I.useState)(!1),c=(n||i)&&!o,l=D(e),u=`${q(e)} ${t}`;
  return(0,z.jsxs)(`span`,{className:`relative inline-flex`,onPointerEnter:()=>{
    r(!0),s(!1)
    },onPointerLeave:()=>r(!1),children:[(0,z.jsx)(`span`,{role:`img`,"aria-label":u,tabIndex:0,className:Se(`inline-flex h-7 min-w-7 items-center justify-center rounded-full focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent-deep)]`,l?l.accentClasses:`border border-[color:var(--color-line)] px-2 text-xs text-[color:var(--color-ink)]`),onBlur:()=>{
    a(!1),s(!1)
    },onFocus:()=>a(!0),onKeyDown:e=>{
    e.key===`Escape`&&s(!0)
    },children:l?l.icon:q(e)}),c?(0,z.jsx)(`span`,{"aria-hidden":`true`,className:`absolute bottom-full left-1/2 z-20 -translate-x-1/2 pb-1.5`,children:(0,z.jsx)(`span`,{className:`block rounded-lg bg-[color:var(--color-ink)] px-2 py-1 text-xs whitespace-nowrap text-[color:var(--color-surface)] shadow-md`,children:u})}):null]})
  }
function Ce({modalities:e}){
  return e.input.length===0||e.output.length===0?null:(0,z.jsxs)(`span`,{className:`inline-flex flex-wrap items-center gap-1.5`,children:[e.input.map(e=>(0,z.jsx)(J,{value:e,direction:`input`},`input:${e}`)),(0,z.jsx)(`span`,{"aria-hidden":`true`,className:`px-0.5 text-[color:var(--color-muted)]`,children:`→`}),e.output.map(e=>(0,z.jsx)(J,{value:e,direction:`output`},`output:${e}`))]})
  }
var we=new Intl.NumberFormat(`en`,{notation:`compact`,maximumFractionDigits:1}),Te={month:`short`,day:`numeric`,year:`numeric`,timeZone:`UTC`};
function Y(e,t){
  return`${e.toLocaleString(`en`)} ${t}${e===1?``:`s`}`
  }
function Ee(e){
  let t=new Set(e.map(e=>e.providerName)).size;
  return t===e.length?Y(t,`provider`):`${Y(e.length,`listing`)} from ${Y(t,`provider`)}`
  }
function De(e){
  return e===null?`No per-token price`:`${P(e.input)} · ${P(e.output)}`
  }
function Oe(e,t,n,r){
  return[e,t,n===null?`no per-token price`:`${P(n.input)} input, ${P(n.output)} output per 1M tokens`,r?`cheapest`:null].filter(e=>e!==null).join(`, `)
  }
function ke(e){
  let t=e.metadata.limits?.context;
  return typeof t==`number`&&t>0?`${we.format(t)} tokens`:`Not listed`
  }
function X(e){
  return typeof e!=`number`||!Number.isFinite(e)||e<0?`Not listed`:e===0?`Subscription`:`${P(e)} / 1M`
  }
function Z(e,t){
  let n=Number.parseFloat(getComputedStyle(e).paddingLeft)||0,r=e.getBoundingClientRect(),i=t.getBoundingClientRect();
  i.left<r.left+n?e.scrollLeft-=r.left+n-i.left:i.right>r.right-n&&(e.scrollLeft+=i.right-(r.right-n))
  }
function Ae(){
  let[e,t]=(0,I.useState)({before:!1,after:!1}),n=(0,I.useRef)(null),r=(0,I.useCallback)(e=>{
    let n=e.scrollWidth-e.clientWidth,r=e.scrollLeft>1,i=e.scrollLeft<n-1;
    t(e=>e.before===r&&e.after===i?e:{before:r,after:i})
    },[]);
  return{overflow:e,ref:(0,I.useCallback)(e=>{
    n.current?.disconnect(),n.current=null,!(e===null||typeof ResizeObserver>`u`)&&(n.current=new ResizeObserver(()=>r(e)),n.current.observe(e),r(e))
    },[r]),measure:r}
  }
function je({marker:e,name:t}){
  let n=e===`sponsored`?`Sponsored provider: ${t}`:`${e===`hot`?`Hot`:`New`} model group: ${t}`,r=e===`sponsored`?`Sponsored provider`:e===`hot`?`Hot model group`:`New release`;
  return(0,z.jsx)(`span`,{className:`release-medallion absolute top-0 left-5 z-10 size-9 -translate-y-1/2 rounded-full border sm:left-7 release-${e}-medallion`,role:`img`,"aria-label":n,title:r,children:(0,z.jsx)(`svg`,{"aria-hidden":`true`,focusable:`false`,className:`absolute -bottom-0.5 left-1/2 h-13 w-10 -translate-x-1/2`,viewBox:`0 0 48 64`,fill:`none`,children:e===`sponsored`?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`path`,{d:`m7 28 10 9 7-17 7 17 10-9-5 22H12Z`,fill:`#eab308`,stroke:`#a16207`,strokeWidth:`1.5`,strokeLinejoin:`round`}),(0,z.jsx)(`path`,{d:`m24 20 7 17-7 7-7-7Z`,fill:`#fef08a`}),(0,z.jsx)(`path`,{d:`M12 47h24v7H12Z`,fill:`#ca8a04`}),(0,z.jsx)(`path`,{d:`M14 49h20`,stroke:`#fef08a`,strokeWidth:`1.5`,strokeLinecap:`round`}),(0,z.jsx)(`path`,{d:`m24 36 3 4-3 4-3-4Z`,fill:`#a16207`}),(0,z.jsx)(`circle`,{cx:`7`,cy:`26`,r:`2.5`,fill:`#facc15`}),(0,z.jsx)(`circle`,{cx:`24`,cy:`18`,r:`2.5`,fill:`#facc15`}),(0,z.jsx)(`circle`,{cx:`41`,cy:`26`,r:`2.5`,fill:`#facc15`})]}):e===`hot`?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`circle`,{cx:`9`,cy:`13`,r:`1.8`,fill:`#d97706`}),(0,z.jsx)(`circle`,{cx:`39`,cy:`17`,r:`1.5`,fill:`#d97706`}),(0,z.jsx)(`path`,{d:`M22 8c2 12-9 17-9 25-3-2-4-5-4-8-3 5-4 10-3 15 1 9 8 14 18 14s17-6 17-15c0-7-4-13-8-17 1 6-1 10-4 12 3-11 1-18-7-26Z`,fill:`#d97706`}),(0,z.jsx)(`path`,{d:`M9 25c0 10 9 13 8 21-1 3 1 6 7 8-10 0-17-5-18-14-1-5 0-10 3-15Z`,fill:`#b45309`}),(0,z.jsx)(`path`,{d:`M24 29c1 8-7 11-7 17 0 5 3 8 7 8s8-3 8-8c0-4-2-7-4-9 0 4-1 6-3 7 2-6 1-11-1-15Z`,fill:`#fbbf24`}),(0,z.jsx)(`path`,{d:`M24 42c0 4-3 6-3 9 0 2 1 3 3 3s4-2 4-4c0-3-2-5-4-8Z`,fill:`#fff0aa`})]}):(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(`path`,{d:`m9 9 2 6 6 2-6 2-2 6-2-6-6-2 6-2Z`,fill:`#0284c7`}),(0,z.jsx)(`path`,{d:`m39 17 1.5 4.5L45 23l-4.5 1.5L39 29l-1.5-4.5L33 23l4.5-1.5Z`,fill:`#7dd3fc`}),(0,z.jsx)(`path`,{d:`m24 20 5 13 13 5-13 5-5 13-5-13-13-5 13-5Z`,fill:`#0284c7`}),(0,z.jsx)(`path`,{d:`m24 20 5 13-5 5-5-5Z`,fill:`#7dd3fc`}),(0,z.jsx)(`path`,{d:`m24 38 5 5-5 13-5-13Z`,fill:`#0369a1`}),(0,z.jsx)(`path`,{d:`m24 31 2 5 5 2-5 2-2 5-2-5-5-2 5-2Z`,fill:`#f0f9ff`})]})})})
  }
function Q({listing:e,label:t,detail:n,showLogo:r,isCheapest:i}){
  return(0,z.jsxs)(`span`,{className:`grid min-w-0 gap-x-2.5 ${r?`grid-cols-[auto_minmax(0,1fr)]`:``}`,children:[r?(0,z.jsx)(`span`,{className:`row-span-3 inline-flex size-8 items-center justify-center self-start rounded-lg border border-[color:var(--color-line)] bg-[color:var(--color-logo-well)] p-1.5`,children:(0,z.jsx)(`img`,{alt:``,className:`size-full object-contain`,height:20,loading:`lazy`,src:u(e),width:20})}):null,(0,z.jsx)(`span`,{className:`line-clamp-2 text-[0.95rem] leading-snug break-words text-[color:var(--color-ink)]`,children:t}),n?(0,z.jsx)(`span`,{className:`truncate text-xs leading-snug text-[color:var(--color-muted)]`,children:n}):null,(0,z.jsx)(`span`,{className:`mt-0.5 text-sm text-[color:var(--color-muted)] tabular-nums`,children:De(e.price)}),i?(0,z.jsx)(`span`,{className:`mt-1 text-xs font-semibold text-[color:var(--color-accent-deep)] ${r?`col-span-2`:``}`,children:`Cheapest`}):null]})
  }
function Me({model:e}){
  return(0,z.jsx)(`dl`,{className:`grid grid-cols-2 gap-x-5 gap-y-4 sm:grid-cols-4 sm:gap-x-0 sm:divide-x sm:divide-[color:var(--color-line)]`,children:[[`Context`,e?ke(e):null],[`Input`,e?X(e.metadata.cost?.input):null],[`Output`,e?X(e.metadata.cost?.output):null],[`Released`,e?e.dates.releaseDate?_(e.dates.releaseDate,Te):`Not listed`:null]].map(([e,t])=>(0,z.jsxs)(`div`,{className:`min-w-0 sm:px-5 sm:first:pl-0`,children:[(0,z.jsx)(`dt`,{className:`text-sm text-[color:var(--color-muted)]`,children:e}),(0,z.jsx)(`dd`,{className:`mt-1 font-serif text-xl tracking-[-0.03em] text-[color:var(--color-ink)] tabular-nums`,children:t??(0,z.jsx)(`span`,{"aria-hidden":`true`,className:`inline-block h-6 w-24 rounded-full bg-neutral-500/15 motion-safe:animate-pulse`})})]},e))})
  }
function Ne({model:e}){
  let t=[e.status?d(e.status):null,...k(e)].filter(e=>e!==null);
  return(0,z.jsxs)(`div`,{className:`mt-5 flex flex-wrap items-center gap-x-4 gap-y-3 border-t border-[color:var(--color-line)] pt-4 text-sm leading-relaxed text-[color:var(--color-muted)]`,children:[(0,z.jsx)(Ce,{modalities:e.modalities}),t.length>0?(0,z.jsx)(`p`,{children:t.join(` · `)}):null]})
  }
function $(e){
  let t=e.type===`sponsor`,n=t?e.sponsor.model:e.release.model,r=t?e.sponsor.models:e.release.variants,i=t?e.sponsor.provider.name:e.release.name,o=t?`sponsored`:e.release.isHot?`hot`:`new`,s=t?null:e.release.cheapestSlug,l=r.length>1,[u,d]=(0,I.useState)(()=>Math.max(0,r.findIndex(e=>e.slug===n.slug))),f=(0,I.useId)(),p=`${f}-heading`,m=`${f}-panel`,h=e=>`${f}-tab-${e}`,g=(0,I.useRef)([]),_=(0,I.useRef)(null),{overflow:v,ref:y,measure:b}=Ae(),x=A(),S=r[u],T=C({queryKey:E.model(S.slug),queryFn:async({signal:e})=>(await w({slug:S.slug,itemsPerPage:1},{signal:e})).items[0]??null,initialData:S.slug===n.slug?n:void 0,enabled:S.slug!==n.slug,staleTime:300*1e3,retry:!1}),D=(0,I.useCallback)(e=>{
    _.current=e,y(e)
    },[y]);
  (0,I.useEffect)(()=>{
    let e=g.current[u];
    _.current&&e&&Z(_.current,e)
    },[u]);
  let O=e=>t?e.name:e.providerName,k=e=>!t&&e.name!==i?e.name:null,j=e=>{
    let t=g.current[e];
    t&&(t.focus({preventScroll:!0}),_.current&&Z(_.current,t))
    },M=(e,t)=>{
    let n=r.length-1,i=e.key===`ArrowRight`?t===n?0:t+1:e.key===`ArrowLeft`?t===0?n:t-1:e.key===`Home`?0:e.key===`End`?n:null;
    i!==null&&(e.preventDefault(),j(i))
    },N=e=>{
    _.current&&_.current.scrollBy({left:e*_.current.clientWidth*.8,behavior:x?`auto`:`smooth`})
    };
  return(0,z.jsxs)(`section`,{"aria-labelledby":p,className:`surface-panel relative mt-4 min-w-0 rounded-[1.5rem] px-5 pt-7 pb-5 sm:rounded-[2rem] sm:px-7 sm:pt-8 sm:pb-6`,"data-model-release":t?void 0:e.release.id,"data-sponsored-provider":t?e.sponsor.provider.slug:void 0,children:[(0,z.jsx)(je,{marker:o,name:i}),(0,z.jsxs)(`div`,{className:`flex flex-wrap items-center gap-x-4 gap-y-1`,children:[(0,z.jsx)(`h3`,{id:p,className:`min-w-0 font-serif text-[1.75rem] leading-tight tracking-[-0.05em] break-words text-[color:var(--color-ink)] sm:text-[2.25rem]`,children:t?(0,z.jsxs)(z.Fragment,{children:[`Sponsored by`,` `,(0,z.jsx)(a,{className:`underline decoration-[color:var(--color-line-strong)] underline-offset-4`,href:`/providers/${e.sponsor.provider.slug}`,children:i})]}):i}),(0,z.jsx)(`p`,{className:`text-sm text-[color:var(--color-muted)] sm:text-base`,children:t?`${Y(r.length,`model`)} · Newest first`:Ee(r)}),v.before||v.after?(0,z.jsxs)(`div`,{className:`ml-auto flex items-center gap-1 pointer-coarse:hidden`,children:[(0,z.jsx)(c,{ariaLabel:`Scroll ${i} ${t?`models`:`providers`} back`,className:`border border-[color:var(--color-line)]`,direction:`previous`,disabled:!v.before,onClick:()=>N(-1)}),(0,z.jsx)(c,{ariaLabel:`Scroll ${i} ${t?`models`:`providers`} forward`,className:`border border-[color:var(--color-line)]`,direction:`next`,disabled:!v.after,onClick:()=>N(1)})]}):null]}),(0,z.jsx)(`div`,{ref:D,role:l?`tablist`:void 0,"aria-label":l?`${i} ${t?`models`:`providers`}`:void 0,className:`-mx-5 mt-3 flex snap-x scroll-px-5 gap-2.5 overflow-x-auto px-5 py-1 [scrollbar-width:none] sm:-mx-7 sm:scroll-px-7 sm:px-7 [&::-webkit-scrollbar]:hidden`,onScroll:e=>b(e.currentTarget),children:l?r.map((e,n)=>{
    let r=n===u,i=e.slug===s,a=O(e),o=k(e);
    return(0,z.jsx)(`button`,{ref:e=>{
      g.current[n]=e
      },id:h(n),type:`button`,role:`tab`,"aria-label":Oe(a,o,e.price,i),"aria-selected":r,"aria-controls":m,tabIndex:r?0:-1,title:o?`${a} · ${o}`:a,className:`flex max-w-60 shrink-0 snap-start items-center rounded-2xl border px-3 py-2.5 text-left transition-colors focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[color:var(--color-accent-deep)] ${r?`border-[color:var(--color-accent-deep)] bg-[color:color-mix(in_srgb,var(--color-accent-soft)_45%,var(--color-elevated))] shadow-[inset_0_0_0_0.5px_var(--color-accent-deep)]`:`border-[color:var(--color-line)] bg-[color:var(--color-elevated)] hover:border-[color:var(--color-line-strong)]`}`,onClick:()=>d(n),onKeyDown:e=>M(e,n),children:(0,z.jsx)(Q,{listing:e,label:a,detail:o,showLogo:!t,isCheapest:i})},e.slug)
    }):(0,z.jsx)(`div`,{className:`flex max-w-60 shrink-0 items-center rounded-2xl border border-[color:var(--color-line)] px-3 py-2.5`,children:(0,z.jsx)(Q,{listing:S,label:O(S),detail:k(S),showLogo:!t,isCheapest:!1})})}),(0,z.jsxs)(`div`,{id:m,role:l?`tabpanel`:void 0,"aria-labelledby":l?h(u):void 0,"aria-busy":T.isPending,className:`mt-5 border-t border-[color:var(--color-line)] pt-5`,children:[(0,z.jsx)(Me,{model:T.data??null}),T.data?(0,z.jsx)(Ne,{model:T.data}):T.isPending?(0,z.jsx)(`p`,{className:`mt-5 border-t border-[color:var(--color-line)] pt-4 text-sm text-[color:var(--color-muted)]`,children:`Loading model details…`}):(0,z.jsxs)(`p`,{className:`mt-5 flex flex-wrap items-center gap-x-4 gap-y-2 border-t border-[color:var(--color-line)] pt-4 text-sm text-[color:var(--color-muted)]`,children:[T.isError?`Model details are temporarily unavailable.`:`This listing is no longer available.`,(0,z.jsx)(`button`,{className:`button-quiet`,type:`button`,onClick:()=>void T.refetch(),children:`Retry`})]}),(0,z.jsx)(`div`,{className:`mt-5 flex sm:justify-end`,children:(0,z.jsxs)(a,{className:`inline-flex min-h-11 w-full items-center justify-center gap-2 rounded-full border border-[color:var(--color-accent-deep)] px-5 py-2 text-center font-semibold text-[color:var(--color-accent-deep)]! transition hover:bg-[color:var(--color-accent-soft)] focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[color:var(--color-accent-deep)] sm:w-auto`,href:`/models/${S.slug}`,children:[t?(0,z.jsxs)(`span`,{children:[`View `,S.name]}):(0,z.jsxs)(`span`,{children:[`View `,(0,z.jsx)(`span`,{className:`max-sm:sr-only`,children:S.name}),` on`,` `,S.providerName]}),(0,z.jsx)(`span`,{"aria-hidden":`true`,children:`→`})]})})]})]})
  }
function Pe({releases:e,sponsoredProvider:t=null}){
  return(0,z.jsxs)(`div`,{className:`grid gap-4 sm:gap-5`,children:[t?(0,z.jsx)($,{type:`sponsor`,sponsor:t},`sponsor:${t.provider.id}`):null,e.map(e=>(0,z.jsx)($,{type:`release`,release:e},e.id))]})
  }
function Fe(e){
  let t=new Set([`synthetic`,`openai`,`minimax`]);
  return[...e].sort((e,n)=>Number(t.has(n.key.toLowerCase()))-Number(t.has(e.key.toLowerCase()))||e.name.localeCompare(n.name)).slice(0,18)
  }
function Ie({stats:e,sponsoredProvider:t,modelReleases:n,providers:r,heroShowcase:o,news:s,seo:c}){
  let l=r.slice(0,10);
  return(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(re,{seo:c}),(0,z.jsxs)(`main`,{"data-home-main":!0,children:[(0,z.jsx)(xe,{featuredProviders:Fe(r),showcaseScenes:o}),(0,z.jsx)(v,{items:[{label:`Models listed`,value:e.models.toLocaleString(`en`),detail:`Search across the full catalog of AI models.`},{label:`Providers listed`,value:e.providers.toLocaleString(`en`),detail:`See which companies and APIs serve each model.`},{label:`Latest release`,value:_(e.latestReleaseDate),detail:`Fresh releases are easy to spot`}]}),(0,z.jsxs)(`section`,{className:`mx-auto grid max-w-7xl gap-6 px-6 pt-6 pb-12 sm:px-8 lg:px-12 lg:pt-12`,children:[(0,z.jsx)(b,{eyebrow:`Hot and latest models`,title:`Start with the hottest and newest AI models`}),t||n.length>0?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(Pe,{releases:n,sponsoredProvider:t}),(0,z.jsx)(`div`,{className:`flex justify-end`,children:(0,z.jsx)(a,{className:`button-secondary`,href:`/models`,children:`View all models`})})]}):(0,z.jsx)(x,{actionHref:`/models`,actionLabel:`Browse all models`,body:`The catalog is live, but it did not return any recent models.`,title:`No recent models found`})]}),(0,z.jsx)(i,{data:`news`,fallback:(0,z.jsx)(le,{}),children:(0,z.jsx)(ue,{articles:s?.items??[]})}),(0,z.jsxs)(`section`,{className:`mx-auto grid max-w-7xl gap-6 px-6 py-12 sm:px-8 lg:px-12`,children:[(0,z.jsx)(b,{eyebrow:`Providers`,title:`Browse the companies and APIs serving these models`,body:`Open a provider page to see links, package names, and the models available through that provider.`}),l.length>0?(0,z.jsxs)(z.Fragment,{children:[(0,z.jsx)(T,{providers:l}),(0,z.jsx)(`div`,{className:`flex justify-end`,children:(0,z.jsx)(a,{className:`button-secondary`,href:`/providers`,children:`View all providers`})})]}):(0,z.jsx)(x,{actionHref:`/providers`,actionLabel:`Browse providers`,body:`The provider catalog is reachable, but this section came back empty.`,title:`No providers found`})]})]})]})
  }
export{Ie as default};
