import{c as e,d as t,f as n,n as r,p as i,s as a,u as o}from"./react-inertia-runtime.js";
import{At as s,C as c,F as l,Ft as u,It as d,Lt as f,Mt as p,Nt as m,Ot as h,Rt as g,S as _,T as v,bt as y,ct as b,dt as x,ft as S,g as C,jt as w,kt as T,lt as E,nt as ee,pt as te,rt as D,ut as ne,xt as re,y as ie}from"./app.js";
import{a as ae,i as oe,n as se,r as ce,t as le}from"./news-ui.js";
var ue=class extends p{
  #e;#t=void 0;#n;#r;constructor(e,t){
    super(),this.#e=e,this.setOptions(t),this.bindMethods(),this.#i()
    }bindMethods(){
    this.mutate=this.mutate.bind(this),this.reset=this.reset.bind(this)
    }setOptions(e){
    let t=this.options;
    this.options=this.#e.defaultMutationOptions(e),d(this.options,t)||this.#e.getMutationCache().notify({type:`observerOptionsUpdated`,mutation:this.#n,observer:this}),t?.mutationKey&&this.options.mutationKey&&m(t.mutationKey)!==m(this.options.mutationKey)?this.reset():this.#n?.state.status===`pending`&&this.#n.setOptions(this.options)
    }onSubscribe(){
    this.listeners.size===1&&this.#n&&(this.#n.addObserver(this),this.#i())
    }onUnsubscribe(){
    this.hasListeners()||this.#n?.removeObserver(this)
    }onMutationUpdate(e){
    this.#i(),this.#a(e)
    }getCurrentResult(){
    return this.#t
    }reset(){
    this.#n?.removeObserver(this),this.#n=void 0,this.#i(),this.#a()
    }mutate(e,t){
    return this.#r=t,this.#n?.removeObserver(this),this.#n=this.#e.getMutationCache().build(this.#e,this.options),this.#n.addObserver(this),this.#n.execute(e)
    }#i(){
    let e=this.#n?.state??s();
    this.#t={...e,isPending:e.status===`pending`,isSuccess:e.status===`success`,isError:e.status===`error`,isIdle:e.status===`idle`,mutate:this.mutate,reset:this.reset}
    }#a(e){
    w.batch(()=>{
      if(this.#r&&this.hasListeners()){
        let t=this.#t.variables,n=this.#t.context,r={client:this.#e,meta:this.options.meta,mutationKey:this.options.mutationKey};
        if(e?.type===`success`){
          try{
            this.#r.onSuccess?.(e.data,t,n,r)
            }catch(e){
            Promise.reject(e)
            }
          try{
            this.#r.onSettled?.(e.data,null,t,n,r)
            }catch(e){
            Promise.reject(e)
            }
          }else 
        if(e?.type===`error`){
          try{
            this.#r.onError?.(e.error,t,n,r)
            }catch(e){
            Promise.reject(e)
            }
          try{
            this.#r.onSettled?.(void 0,e.error,t,n,r)
            }catch(e){
            Promise.reject(e)
            }
          }
        }
      this.listeners.forEach(e=>{
        e(this.#t)
        })
      })
    }
},O=i(e(),1);
function de(e,t){
  let n=g(t),[r]=O.useState(()=>new ue(n,e));
  O.useEffect(()=>{
    r.setOptions(e)
    },[r,e]);
  let i=O.useSyncExternalStore(O.useCallback(e=>r.subscribe(w.batchCalls(e)),[r]),()=>r.getCurrentResult(),()=>r.getCurrentResult()),a=O.useCallback((...e)=>{
    r.mutate(e[0],e[1]).catch(u)
    },[r]);
  if(i.error&&f(r.options.throwOnError,[i.error]))
  throw i.error;
  return{...i,mutate:a,mutateAsync:i.mutate}
  }
var fe=[`16`,`24`],pe={16:{width:16,path:O.createElement(`path`,{d:`M6.766 11.328c-2.063-.25-3.516-1.734-3.516-3.656 0-.781.281-1.625.75-2.188-.203-.515-.172-1.609.063-2.062.625-.078 1.468.25 1.968.703.594-.187 1.219-.281 1.985-.281.765 0 1.39.094 1.953.265.484-.437 1.344-.765 1.969-.687.218.422.25 1.515.046 2.047.5.593.766 1.39.766 2.203 0 1.922-1.453 3.375-3.547 3.64.531.344.89 1.094.89 1.954v1.625c0 .468.391.734.86.547C13.781 14.359 16 11.53 16 8.03 16 3.61 12.406 0 7.984 0 3.563 0 0 3.61 0 8.031a7.88 7.88 0 0 0 5.172 7.422c.422.156.828-.125.828-.547v-1.25c-.219.094-.5.156-.75.156-1.031 0-1.64-.562-2.078-1.609-.172-.422-.36-.672-.719-.719-.187-.015-.25-.093-.25-.187 0-.188.313-.328.625-.328.453 0 .844.281 1.25.86.313.452.64.655 1.031.655s.641-.14 1-.5c.266-.265.47-.5.657-.656`})},24:{width:24,path:O.createElement(`path`,{d:`M10.226 17.284c-2.965-.36-5.054-2.493-5.054-5.256 0-1.123.404-2.336 1.078-3.144-.292-.741-.247-2.314.09-2.965.898-.112 2.111.36 2.83 1.01.853-.269 1.752-.404 2.853-.404 1.1 0 1.999.135 2.807.382.696-.629 1.932-1.1 2.83-.988.315.606.36 2.179.067 2.942.72.854 1.101 2 1.101 3.167 0 2.763-2.089 4.852-5.098 5.234.763.494 1.28 1.572 1.28 2.807v2.336c0 .674.561 1.056 1.235.786 4.066-1.55 7.255-5.615 7.255-10.646C23.5 6.188 18.334 1 11.978 1 5.62 1 .5 6.188.5 12.545c0 4.986 3.167 9.12 7.435 10.669.606.225 1.19-.18 1.19-.786V20.63a2.9 2.9 0 0 1-1.078.224c-1.483 0-2.359-.808-2.987-2.313-.247-.607-.517-.966-1.034-1.033-.27-.023-.359-.135-.359-.27 0-.27.45-.471.898-.471.652 0 1.213.404 1.797 1.235.45.651.921.943 1.483.943.561 0 .92-.202 1.437-.719.382-.381.674-.718.944-.943`})}},me=O.forwardRef(function(e,t){
  return v(e,t,`octicon octicon-mark-github`,pe,fe)
  });
me.displayName=`MarkGithubIcon`;
var he=a(),k=r();
function ge(...e){
  return e.filter(Boolean).join(` `)
  }
function _e(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-[1.1rem] w-[1.1rem]`,fill:`currentColor`,viewBox:`0 0 24 24`,xmlns:`http://www.w3.org/2000/svg`,children:(0,k.jsx)(`path`,{d:`M14.234 10.162 22.977 0h-2.072l-7.591 8.824L7.251 0H.258l9.168 13.343L.258 24H2.33l8.016-9.318L16.749 24h6.993zm-2.837 3.299-.929-1.329L3.076 1.56h3.182l5.965 8.532.929 1.329 7.754 11.09h-3.182z`})})
  }
function ve(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-[1.1rem] w-[1.1rem]`,fill:`currentColor`,viewBox:`0 0 24 24`,xmlns:`http://www.w3.org/2000/svg`,children:(0,k.jsx)(`path`,{d:`M20.447 20.452h-3.554v-5.569c0-1.328-.027-3.037-1.852-3.037-1.853 0-2.136 1.445-2.136 2.939v5.667H9.351V9h3.414v1.561h.046c.477-.9 1.637-1.85 3.37-1.85 3.601 0 4.267 2.37 4.267 5.455v6.286zM5.337 7.433c-1.144 0-2.063-.926-2.063-2.065 0-1.138.92-2.063 2.063-2.063 1.14 0 2.064.925 2.064 2.063 0 1.139-.925 2.065-2.064 2.065zm1.782 13.019H3.555V9h3.564v11.452zM22.225 0H1.771C.792 0 0 .774 0 1.729v20.542C0 23.227.792 24 1.771 24h20.451C23.2 24 24 23.227 24 22.271V1.729C24 .774 23.2 0 22.222 0h.003z`})})
  }
function ye(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-[1.1rem] w-[1.1rem]`,fill:`currentColor`,viewBox:`0 0 24 24`,xmlns:`http://www.w3.org/2000/svg`,children:(0,k.jsx)(`path`,{d:`M24 12.073C24 5.405 18.627 0 12 0S0 5.405 0 12.073c0 6.025 4.388 11.017 10.125 11.927v-8.437H7.078v-3.49h3.047V9.413c0-3.025 1.792-4.697 4.533-4.697 1.312 0 2.686.236 2.686.236v2.971h-1.513c-1.491 0-1.956.931-1.956 1.886v2.264h3.328l-.532 3.49h-2.796V24C19.612 23.09 24 18.098 24 12.073z`})})
  }
function be(){
  return(0,k.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-[1.1rem] w-[1.1rem]`,fill:`currentColor`,viewBox:`0 0 24 24`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,k.jsx)(`path`,{d:`M0 0h24v24H0z`}),(0,k.jsx)(`path`,{d:`m7.1 5.25 4.86 8.92v4.58h1.96v-4.58l4.98-8.92h-2.18l-3.72 6.96-3.71-6.96z`,fill:`var(--color-background)`})]})
  }
function xe(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-[1.1rem] w-[1.1rem]`,fill:`none`,viewBox:`0 0 24 24`,xmlns:`http://www.w3.org/2000/svg`,children:(0,k.jsx)(`path`,{d:`M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`2`})})
  }
function Se(){
  return(0,k.jsxs)(`svg`,{"aria-hidden":`true`,className:`h-[1.1rem] w-[1.1rem]`,fill:`none`,viewBox:`0 0 24 24`,xmlns:`http://www.w3.org/2000/svg`,children:[(0,k.jsx)(`path`,{d:`M4.75 6.75h14.5v10.5H4.75z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`2`}),(0,k.jsx)(`path`,{d:`m5 7 7 6 7-6`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`2`})]})
  }
function Ce(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,fill:`none`,viewBox:`0 0 16 16`,xmlns:`http://www.w3.org/2000/svg`,children:(0,k.jsx)(`path`,{d:`M9.25 2.75h4v4M8 8l5.25-5.25M13.25 8.75v3A1.5 1.5 0 0 1 11.75 13.25h-7A1.5 1.5 0 0 1 3.25 11.75v-7A1.5 1.5 0 0 1 4.75 3.25h3`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})})
  }
function we({className:e}){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:ge(`h-3.5 w-3.5`,e),fill:`none`,viewBox:`0 0 16 16`,xmlns:`http://www.w3.org/2000/svg`,children:(0,k.jsx)(`path`,{d:`m4.25 6.25 3.75 3.75 3.75-3.75`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.3`})})
  }
var Te=`inline-flex items-center gap-1.5 rounded-full border border-[color:var(--color-line)] bg-white/80 py-1 pl-1.5 pr-2.5 text-[0.82rem] leading-none text-[color:var(--color-ink)] transition hover:-translate-y-px hover:border-[color:var(--color-line-strong)] hover:bg-white/95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/15`,Ee=`flex min-h-24 flex-col items-center justify-center gap-1.5 rounded-[1.15rem] border border-[color:var(--color-line)] bg-white/75 px-2 py-3 text-center text-[0.68rem] leading-none font-medium text-[color:var(--color-muted)] transition hover:-translate-y-px hover:border-[color:var(--color-line-strong)] hover:bg-white/95 hover:text-[color:var(--color-ink)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/15`,De=`inline-flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-accent/10 text-[color:var(--color-accent-deep)]`,A=`whitespace-nowrap text-[0.68rem] leading-none`;
function Oe({shareTitle:e,shareUrl:t}){
  let[n,r]=(0,O.useState)(`Copy link`),[i,a]=(0,O.useState)(!1),[o,s]=(0,O.useState)(null),c=(0,O.useId)(),l=(0,O.useRef)(null),u=(0,O.useRef)(null),d=(0,O.useRef)(null),f=typeof document>`u`?null:document.body,p=`https://twitter.com/intent/tweet?text=${encodeURIComponent(e)}&url=${encodeURIComponent(t)}`,m=`https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(t)}`,h=`https://www.facebook.com/sharer/sharer.php?u=${encodeURIComponent(t)}`,g=`https://news.ycombinator.com/submitlink?u=${encodeURIComponent(t)}&t=${encodeURIComponent(e)}`,_=`mailto:?subject=${encodeURIComponent(e)}&body=${encodeURIComponent(`${e}\n\n${t}`)}`,v=o===null?void 0:{"--share-panel-left":`${o.left}px`,"--share-panel-top":`${o.top}px`},y=(0,O.useCallback)(()=>{
    let e=u.current;
    if(!e)
    return;
    let t=e.getBoundingClientRect(),n=Math.min(320,window.innerWidth-32),r=Math.min(Math.max(16,t.right-n),window.innerWidth-n-16),i=t.bottom+224+16>window.innerHeight&&t.top-224-12>=16?t.top-224-12:t.bottom+12;
    s({top:i,left:r})
    },[]),b=(0,O.useCallback)(()=>{
    a(!1),s(null)
    },[]);
  function x(){
    if(i){
      b();
      return
      }
    y(),a(!0)
    }
  (0,O.useEffect)(()=>()=>{
    d.current!==null&&window.clearTimeout(d.current)
    },[]),(0,O.useEffect)(()=>{
    if(!i)
    return;
    y();
    function e(e){
      let t=e.target;
      t instanceof Node&&(l.current?.contains(t)||u.current?.contains(t)||b())
      }
    function t(e){
      e.key===`Escape`&&(b(),u.current?.focus())
      }
    return document.addEventListener(`pointerdown`,e),window.addEventListener(`keydown`,t),window.addEventListener(`resize`,y),window.addEventListener(`scroll`,y,!0),()=>{
      document.removeEventListener(`pointerdown`,e),window.removeEventListener(`keydown`,t),window.removeEventListener(`resize`,y),window.removeEventListener(`scroll`,y,!0)
      }
    },[b,i,y]);
  async function S(){
    try{
      await navigator.clipboard.writeText(t),r(`Copied`)
      }catch{
      r(`Copy failed`)
      }
    d.current!==null&&window.clearTimeout(d.current),d.current=window.setTimeout(()=>{
      r(`Copy link`)
      },1800)
    }
  return(0,k.jsxs)(k.Fragment,{children:[(0,k.jsxs)(`button`,{ref:u,"aria-controls":i?c:void 0,"aria-expanded":i,className:ge(Te,i&&`border-[color:var(--color-line-strong)] bg-white/95`),"aria-haspopup":`dialog`,type:`button`,onClick:x,children:[(0,k.jsx)(`span`,{className:`bg-accent/10 inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-[color:var(--color-accent-deep)]`,children:(0,k.jsx)(Ce,{})}),(0,k.jsx)(`span`,{children:`Share page`}),(0,k.jsx)(we,{className:ge(`text-[color:var(--color-muted)] transition-transform duration-200`,i&&`rotate-180 text-[color:var(--color-accent-deep)]`)})]}),i&&o&&f?(0,he.createPortal)((0,k.jsx)(`div`,{id:c,ref:l,className:`fixed top-(--share-panel-top) left-(--share-panel-left) z-[90] w-[min(20rem,calc(100vw-2rem))] rounded-[1.35rem] border border-[color:var(--color-line)] bg-white/95 p-3 shadow-2xl dark:shadow-none`,role:`dialog`,"aria-label":`Share this page`,style:v,children:(0,k.jsxs)(`div`,{className:`grid grid-cols-3 gap-2`,children:[(0,k.jsxs)(`a`,{"aria-label":`Share this page on X`,className:Ee,href:p,rel:`noreferrer`,target:`_blank`,title:`Share this page on X`,onClick:b,children:[(0,k.jsx)(`span`,{className:De,children:(0,k.jsx)(_e,{})}),(0,k.jsx)(`span`,{className:A,children:`X`})]}),(0,k.jsxs)(`a`,{"aria-label":`Share this page on LinkedIn`,className:Ee,href:m,rel:`noreferrer`,target:`_blank`,title:`Share this page on LinkedIn`,onClick:b,children:[(0,k.jsx)(`span`,{className:De,children:(0,k.jsx)(ve,{})}),(0,k.jsx)(`span`,{className:A,children:`LinkedIn`})]}),(0,k.jsxs)(`a`,{"aria-label":`Share this page on Facebook`,className:Ee,href:h,rel:`noreferrer`,target:`_blank`,title:`Share this page on Facebook`,onClick:b,children:[(0,k.jsx)(`span`,{className:De,children:(0,k.jsx)(ye,{})}),(0,k.jsx)(`span`,{className:A,children:`Facebook`})]}),(0,k.jsxs)(`a`,{"aria-label":`Discuss this page on Hacker News`,className:Ee,href:g,rel:`noreferrer`,target:`_blank`,title:`Discuss this page on Hacker News`,onClick:b,children:[(0,k.jsx)(`span`,{className:De,children:(0,k.jsx)(be,{})}),(0,k.jsx)(`span`,{className:A,children:`Hacker News`})]}),(0,k.jsxs)(`a`,{"aria-label":`Email this page to a friend`,className:Ee,href:_,title:`Email this page to a friend`,onClick:b,children:[(0,k.jsx)(`span`,{className:De,children:(0,k.jsx)(Se,{})}),(0,k.jsx)(`span`,{className:A,children:`Email`})]}),(0,k.jsxs)(`button`,{"aria-label":n,className:ge(Ee,n===`Copied`&&`border-accent/30 bg-accent-soft/45 text-[color:var(--color-accent-deep)]`),title:n,type:`button`,onClick:S,children:[(0,k.jsx)(`span`,{className:De,children:(0,k.jsx)(xe,{})}),(0,k.jsx)(`span`,{className:A,children:n})]})]})}),f):null]})
  }
var ke=`https://promos.reading.sh/synthetic`,j=`$10 off the fastest DeepSeek V4.1 Flash, Kimi K3 and GLM 5.3`,Ae={dealName:`Synthetic`,label:j,ctaLabel:j,desktopCtaLabel:j,affiliateUrl:ke,iconSrc:`/synthetic.svg`,theme:`synthetic`};
function je(e){
  return e?.affiliateUrl.trim()?e.dealName.trim().toLowerCase()===`synthetic`?{...e,label:j,ctaLabel:j,desktopCtaLabel:j,iconSrc:`/synthetic.svg`,theme:`synthetic`}:e:Ae
  }
var Me=(0,O.createContext)({});
function Ne(e){
  let t=(0,O.useRef)(null);
  return t.current===null&&(t.current=e()),t.current
  }
var Pe=typeof window<`u`?O.useLayoutEffect:O.useEffect,Fe=(0,O.createContext)(null);
function Ie(e,t){
  e.indexOf(t)===-1&&e.push(t)
  }
function Le(e,t){
  let n=e.indexOf(t);
  n>-1&&e.splice(n,1)
  }
var M=(e,t,n)=>n>t?t:n<e?e:n,N={},Re=e=>/^-?(?:\d+(?:\.\d+)?|\.\d+)$/u.test(e),ze=e=>typeof e==`object`&&!!e,Be=e=>/^0[^.\s]+$/u.test(e);
function Ve(e){
  let t;
  return()=>(t===void 0&&(t=e()),t)
  }
var He=e=>e,Ue=(...e)=>e.reduce((e,t)=>n=>t(e(n))),We=(e,t,n)=>{
  let r=t-e;
  return r?(n-e)/r:1
  },Ge=class{
  constructor(){
    this.subscriptions=[]
    }add(e){
    return Ie(this.subscriptions,e),()=>Le(this.subscriptions,e)
    }notify(e,t,n){
    let r=this.subscriptions.length;
    if(r)
    if(r===1)
    this.subscriptions[0](e,t,n);
    else 
    for(
    let i=0
    ;i<r;i++){
      let r=this.subscriptions[i];
      r&&r(e,t,n)
      }
    }getSize(){
    return this.subscriptions.length
    }clear(){
    this.subscriptions.length=0
    }
},P=e=>e*1e3,F=e=>e/1e3,Ke=(e,t)=>t?1e3/t*e:0,qe=(e,t,n)=>(((1-3*n+3*t)*e+(3*n-6*t))*e+3*t)*e,Je=1e-7,Ye=12;
function Xe(e,t,n,r,i){
  let a,o,s=0;
  do 
  o=t+(n-t)/2,a=qe(o,r,i)-e,a>0?n=o:t=o;
  while(Math.abs(a)>Je&&++s<Ye);
  return o
  }
function Ze(e,t,n,r){
  if(e===t&&n===r)
  return He;
  let i=t=>Xe(t,0,1,e,n);
  return e=>e===0||e===1?e:qe(i(e),t,r)
  }
var Qe=e=>t=>t<=.5?e(2*t)/2:(2-e(2*(1-t)))/2,$e=e=>t=>1-e(1-t),et=Ze(.33,1.53,.69,.99),tt=$e(et),nt=Qe(tt),rt=e=>e>=1?1:(e*=2)<1?.5*tt(e):.5*(2-2**(-10*(e-1))),it=e=>1-Math.sin(Math.acos(e)),at=$e(it),ot=Qe(it),st=Ze(.42,0,1,1),ct=Ze(0,0,.58,1),lt=Ze(.42,0,.58,1),ut=e=>Array.isArray(e)&&typeof e[0]!=`number`,dt=e=>Array.isArray(e)&&typeof e[0]==`number`,ft={linear:He,easeIn:st,easeInOut:lt,easeOut:ct,circIn:it,circInOut:ot,circOut:at,backIn:tt,backInOut:nt,backOut:et,anticipate:rt},pt=e=>typeof e==`string`,mt=e=>{
  if(dt(e)){
    e.length;
    let[t,n,r,i]=e;
    return Ze(t,n,r,i)
    }else 
  if(pt(e))
  return ft[e],`${e}`,ft[e];
  return e
  },ht=[`setup`,`read`,`resolveKeyframes`,`preUpdate`,`update`,`preRender`,`render`,`postRender`];
function gt(e){
  let t=new Set,n=new Set,r=!1,i=!1,a=new WeakSet,o={delta:0,timestamp:0,isProcessing:!1};
  function s(t){
    a.has(t)&&(c.schedule(t),e()),t(o)
    }
  let c={schedule:(e,i=!1,o=!1)=>{
    let s=o&&r?t:n;
    return i&&a.add(e),s.add(e),e
    },cancel:e=>{
    n.delete(e),a.delete(e)
    },process:e=>{
    if(o=e,r){
      i=!0;
      return
      }
    r=!0;
    let a=t;
    t=n,n=a,t.forEach(s),t.clear(),r=!1,i&&(i=!1,c.process(e))
    }};
  return c
  }
var _t=40;
function vt(e,t){
  let n=!1,r=!0,i={delta:0,timestamp:0,isProcessing:!1},a=()=>n=!0,o=ht.reduce((e,t)=>(e[t]=gt(a),e),{}),{setup:s,read:c,resolveKeyframes:l,preUpdate:u,update:d,preRender:f,render:p,postRender:m}=o,h=()=>{
    let a=N.useManualTiming,o=a?i.timestamp:performance.now();
    n=!1,a||(i.delta=r?1e3/60:Math.max(Math.min(o-i.timestamp,_t),1)),i.timestamp=o,i.isProcessing=!0,s.process(i),c.process(i),l.process(i),u.process(i),d.process(i),f.process(i),p.process(i),m.process(i),i.isProcessing=!1,n&&t&&(r=!1,e(h))
    },g=()=>{
    n=!0,r=!0,i.isProcessing||e(h)
    };
  return{schedule:ht.reduce((e,t)=>{
    let r=o[t];
    return e[t]=(e,t=!1,i=!1)=>(n||g(),r.schedule(e,t,i)),e
    },{}),cancel:e=>{
    for(
    let t=0
    ;t<ht.length;t++)
    o[ht[t]].cancel(e)
    },state:i,steps:o}
  }
var{schedule:I,cancel:yt,state:bt,steps:xt}=vt(typeof requestAnimationFrame<`u`?requestAnimationFrame:He,!0),St;
function Ct(){
  St=void 0
  }
var L={now:()=>(St===void 0&&L.set(bt.isProcessing||N.useManualTiming?bt.timestamp:performance.now()),St),set:e=>{
  St=e,queueMicrotask(Ct)
  }},wt=e=>t=>typeof t==`string`&&t.startsWith(e),Tt=wt(`--`),Et=wt(`var(--`),Dt=e=>Et(e)?Ot.test(e.split(`/*`)[0].trim()):!1,Ot=/var\(--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)$/iu;
function kt(e){
  return typeof e==`string`&&e.split(`/*`)[0].includes(`var(--`)
  }
var At={test:e=>typeof e==`number`,parse:parseFloat,transform:e=>e},jt={...At,transform:e=>M(0,1,e)},Mt={...At,default:1},Nt=e=>Math.round(e*1e5)/1e5,Pt=/-?(?:\d+(?:\.\d+)?|\.\d+)/gu;
function Ft(e){
  return e==null
  }
var It=/^(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))$/iu,Lt=(e,t)=>n=>!!(typeof n==`string`&&It.test(n)&&n.startsWith(e)||t&&!Ft(n)&&Object.prototype.hasOwnProperty.call(n,t)),Rt=(e,t,n)=>r=>{
  if(typeof r!=`string`)
  return r;
  let[i,a,o,s]=r.match(Pt);
  return{[e]:parseFloat(i),[t]:parseFloat(a),[n]:parseFloat(o),alpha:s===void 0?1:parseFloat(s)}
  },zt=e=>M(0,255,e),Bt={...At,transform:e=>Math.round(zt(e))},R={test:Lt(`rgb`,`red`),parse:Rt(`red`,`green`,`blue`),transform:({red:e,green:t,blue:n,alpha:r=1})=>`rgba(`+Bt.transform(e)+`, `+Bt.transform(t)+`, `+Bt.transform(n)+`, `+Nt(jt.transform(r))+`)`};
function Vt(e){
  let t=``,n=``,r=``,i=``;
  return e.length>5?(t=e.substring(1,3),n=e.substring(3,5),r=e.substring(5,7),i=e.substring(7,9)):(t=e.substring(1,2),n=e.substring(2,3),r=e.substring(3,4),i=e.substring(4,5),t+=t,n+=n,r+=r,i+=i),{red:parseInt(t,16),green:parseInt(n,16),blue:parseInt(r,16),alpha:i?parseInt(i,16)/255:1}
  }
var Ht={test:Lt(`#`),parse:Vt,transform:R.transform},Ut=e=>({test:t=>typeof t==`string`&&t.endsWith(e)&&t.split(` `).length===1,parse:parseFloat,transform:t=>`${t}${e}`}),z=Ut(`deg`),B=Ut(`%`),V=Ut(`px`),Wt=Ut(`vh`),Gt=Ut(`vw`),Kt={...B,parse:e=>B.parse(e)/100,transform:e=>B.transform(e*100)},H={test:Lt(`hsl`,`hue`),parse:Rt(`hue`,`saturation`,`lightness`),transform:({hue:e,saturation:t,lightness:n,alpha:r=1})=>`hsla(`+Math.round(e)+`, `+B.transform(Nt(t))+`, `+B.transform(Nt(n))+`, `+Nt(jt.transform(r))+`)`},U={test:e=>R.test(e)||Ht.test(e)||H.test(e),parse:e=>R.test(e)?R.parse(e):H.test(e)?H.parse(e):Ht.parse(e),transform:e=>typeof e==`string`?e:e.hasOwnProperty(`red`)?R.transform(e):H.transform(e),getAnimatableNone:e=>{
  let t=U.parse(e);
  return t.alpha=0,U.transform(t)
  }},qt=/(?:#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\))/giu;
function Jt(e){
  return isNaN(e)&&typeof e==`string`&&(e.match(Pt)?.length||0)+(e.match(qt)?.length||0)>0
  }
var Yt=`number`,Xt=`color`,Zt=`var`,Qt=`var(`,$t="${}",en=/var\s*\(\s*--(?:[\w-]+\s*|[\w-]+\s*,(?:\s*[^)(\s]|\s*\((?:[^)(]|\([^)(]*\))*\))+\s*)\)|#[\da-f]{3,8}|(?:rgb|hsl)a?\((?:-?[\d.]+%?[,\s]+){2}-?[\d.]+%?\s*(?:[,/]\s*)?(?:\b\d+(?:\.\d+)?|\.\d+)?%?\)|-?(?:\d+(?:\.\d+)?|\.\d+)/giu;
function W(e){
  let t=e.toString(),n=[],r={color:[],number:[],var:[]},i=[],a=0;
  return{values:n,split:t.replace(en,e=>(U.test(e)?(r.color.push(a),i.push(Xt),n.push(U.parse(e))):e.startsWith(Qt)?(r.var.push(a),i.push(Zt),n.push(e)):(r.number.push(a),i.push(Yt),n.push(parseFloat(e))),++a,$t)).split($t),indexes:r,types:i}
  }
function tn(e){
  return W(e).values
  }
function nn({split:e,types:t}){
  let n=e.length;
  return r=>{
    let i=``;
    for(
    let a=0
    ;a<n;a++)
    if(i+=e[a],r[a]!==void 0){
      let e=t[a];
      e===Yt?i+=Nt(r[a]):e===Xt?i+=U.transform(r[a]):i+=r[a]
      }
    return i
    }
  }
function rn(e){
  return nn(W(e))
  }
var an=e=>typeof e==`number`?0:U.test(e)?U.getAnimatableNone(e):e,on=(e,t)=>typeof e==`number`?t?.trim().endsWith(`/`)?e:0:an(e);
function sn(e){
  let t=W(e);
  return nn(t)(t.values.map((e,n)=>on(e,t.split[n])))
  }
var G={test:Jt,parse:tn,createTransformer:rn,getAnimatableNone:sn};
function cn(e,t,n){
  return n<0&&(n+=1),n>1&&--n,n<1/6?e+(t-e)*6*n:n<1/2?t:n<2/3?e+(t-e)*(2/3-n)*6:e
  }
function ln({hue:e,saturation:t,lightness:n,alpha:r}){
  e/=360,t/=100,n/=100;
  let i=0,a=0,o=0;
  if(!t)
  i=a=o=n;
  else{
    let r=n<.5?n*(1+t):n+t-n*t,s=2*n-r;
    i=cn(s,r,e+1/3),a=cn(s,r,e),o=cn(s,r,e-1/3)
    }
  return{red:Math.round(i*255),green:Math.round(a*255),blue:Math.round(o*255),alpha:r}
  }
function un(e,t){
  return n=>n>0?t:e
  }
var dn=(e,t,n)=>e+(t-e)*n,fn=(e,t,n)=>{
  let r=e*e,i=n*(t*t-r)+r;
  return i<0?0:Math.sqrt(i)
  },pn=[Ht,R,H],mn=e=>pn.find(t=>t.test(e));
function hn(e){
  let t=mn(e);
  if(`${e}`,!t)
  return!1;
  let n=t.parse(e);
  return t===H&&(n=ln(n)),n
  }
var gn=(e,t)=>{
  let n=hn(e),r=hn(t);
  if(!n||!r)
  return un(e,t);
  let i={...n};
  return e=>(i.red=fn(n.red,r.red,e),i.green=fn(n.green,r.green,e),i.blue=fn(n.blue,r.blue,e),i.alpha=dn(n.alpha,r.alpha,e),R.transform(i))
  },_n=new Set([`none`,`hidden`]);
function vn(e,t){
  return _n.has(e)?n=>n<=0?e:t:n=>n>=1?t:e
  }
function yn(e,t){
  return n=>dn(e,t,n)
  }
function bn(e){
  return typeof e==`number`?yn:typeof e==`string`?Dt(e)?un:U.test(e)?gn:wn:Array.isArray(e)?xn:typeof e==`object`?U.test(e)?gn:Sn:un
  }
function xn(e,t){
  let n=[...e],r=n.length,i=e.map((e,n)=>bn(e)(e,t[n]));
  return e=>{
    for(
    let t=0
    ;t<r;t++)
    n[t]=i[t](e);
    return n
    }
  }
function Sn(e,t){
  let n={...e,...t},r={};
  for(
  let i
   in n)
  e[i]!==void 0&&t[i]!==void 0&&(r[i]=bn(e[i])(e[i],t[i]));
  return e=>{
    for(
    let t
     in r)
    n[t]=r[t](e);
    return n
    }
  }
function Cn(e,t){
  let n=[],r={color:0,var:0,number:0};
  for(
  let i=0
  ;i<t.values.length;i++){
    let a=t.types[i],o=e.indexes[a][r[a]];
    n[i]=e.values[o]??0,r[a]++
    }
  return n
  }
var wn=(e,t)=>{
  let n=G.createTransformer(t),r=W(e),i=W(t);
  return r.indexes.var.length===i.indexes.var.length&&r.indexes.color.length===i.indexes.color.length&&r.indexes.number.length>=i.indexes.number.length?_n.has(e)&&!i.values.length||_n.has(t)&&!r.values.length?vn(e,t):Ue(xn(Cn(r,i),i.values),n):(`${e}${t}`,un(e,t))
  };
function Tn(e,t,n){
  return typeof e==`number`&&typeof t==`number`&&typeof n==`number`?dn(e,t,n):bn(e)(e,t)
  }
var En=e=>{
  let t=({timestamp:t})=>e(t);
  return{start:(e=!0)=>I.update(t,e),stop:()=>yt(t),now:()=>bt.isProcessing?bt.timestamp:L.now()}
  },Dn=(e,t,n=10)=>{
  let r=``,i=Math.max(Math.round(t/n),2);
  for(
  let t=0
  ;t<i;t++)
  r+=Math.round(e(t/(i-1))*1e4)/1e4+`, `;
  return`linear(${r.substring(0,r.length-2)})`
  },On=2e4;
function kn(e){
  let t=0,n=e.next(t);
  for(;!n.done&&t<2e4;)
  t+=50,n=e.next(t);
  return t>=2e4?1/0:t
  }
function An(e,t=100,n){
  let r=n({...e,keyframes:[0,t]}),i=Math.min(kn(r),On);
  return{type:`keyframes`,ease:e=>r.next(i*e).value/t,duration:F(i)}
  }
var K={stiffness:100,damping:10,mass:1,velocity:0,duration:800,bounce:.3,visualDuration:.3,restSpeed:{granular:.01,default:2},restDelta:{granular:.005,default:.5},minDuration:.01,maxDuration:10,minDamping:.05,maxDamping:1};
function jn(e,t){
  return e*Math.sqrt(1-t*t)
  }
var Mn=12;
function Nn(e,t,n){
  let r=n;
  for(
  let n=1
  ;n<Mn;n++)
  r-=e(r)/t(r);
  return r
  }
var Pn=.001;
function Fn({duration:e=K.duration,bounce:t=K.bounce,velocity:n=K.velocity,mass:r=K.mass}){
  let i,a;
  K.maxDuration;
  let o=1-t;
  o=M(K.minDamping,K.maxDamping,o),e=M(K.minDuration,K.maxDuration,F(e)),o<1?(i=t=>{
    let r=t*o,i=r*e,a=r-n,s=jn(t,o),c=Math.exp(-i);
    return Pn-a/s*c
    },a=t=>{
    let r=t*o*e,a=r*n+n,s=o**2*t**2*e,c=Math.exp(-r),l=jn(t**2,o);
    return(-i(t)+Pn>0?-1:1)*((a-s)*c)/l
    }):(i=t=>-.001+Math.exp(-t*e)*((t-n)*e+1),a=t=>Math.exp(-t*e)*((n-t)*(e*e)));
  let s=5/e,c=Nn(i,a,s);
  if(e=P(e),isNaN(c))
  return{stiffness:K.stiffness,damping:K.damping,duration:e};
  {
    let t=c**2*r;
    return{stiffness:t,damping:o*2*Math.sqrt(r*t),duration:e}
    }
}
var In=[`duration`,`bounce`],Ln=[`stiffness`,`damping`,`mass`];
function Rn(e,t){
  return t.some(t=>e[t]!==void 0)
  }
function zn(e){
  let t={velocity:K.velocity,stiffness:K.stiffness,damping:K.damping,mass:K.mass,isResolvedFromDuration:!1,...e};
  if(!Rn(e,Ln)&&Rn(e,In))
  if(t.velocity=0,e.visualDuration){
    let n=e.visualDuration,r=2*Math.PI/(n*1.2),i=r*r,a=2*M(.05,1,1-(e.bounce||0))*Math.sqrt(i);
    t={...t,mass:K.mass,stiffness:i,damping:a}
    }else{
    let n=Fn({...e,velocity:0});
    t={...t,...n,mass:K.mass},t.isResolvedFromDuration=!0
    }
  return t
  }
function Bn(e=K.visualDuration,t=K.bounce){
  let n=typeof e==`object`?e:{visualDuration:e,keyframes:[0,1],bounce:t},{restSpeed:r,restDelta:i}=n,a=n.keyframes[0],o=n.keyframes[n.keyframes.length-1],s={done:!1,value:a},{stiffness:c,damping:l,mass:u,duration:d,velocity:f,isResolvedFromDuration:p}=zn({...n,velocity:-F(n.velocity||0)}),m=f||0,h=l/(2*Math.sqrt(c*u)),g=o-a,_=F(Math.sqrt(c/u)),v=Math.abs(g)<5;
  r||=v?K.restSpeed.granular:K.restSpeed.default,i||=v?K.restDelta.granular:K.restDelta.default;
  let y,b,x,S,C,w;
  if(h<1)
  x=jn(_,h),S=(m+h*_*g)/x,y=e=>{
    let t=Math.exp(-h*_*e);
    return o-t*(S*Math.sin(x*e)+g*Math.cos(x*e))
    },C=h*_*S+g*x,w=h*_*g-S*x,b=e=>Math.exp(-h*_*e)*(C*Math.sin(x*e)+w*Math.cos(x*e));
  else 
  if(h===1){
    y=e=>o-Math.exp(-_*e)*(g+(m+_*g)*e);
    let e=m+_*g;
    b=t=>Math.exp(-_*t)*(_*e*t-m)
    }else{
    let e=_*Math.sqrt(h*h-1);
    y=t=>{
      let n=Math.exp(-h*_*t),r=Math.min(e*t,300);
      return o-n*((m+h*_*g)*Math.sinh(r)+e*g*Math.cosh(r))/e
      };
    let t=(m+h*_*g)/e,n=h*_*t-g*e,r=h*_*g-t*e;
    b=t=>{
      let i=Math.exp(-h*_*t),a=Math.min(e*t,300);
      return i*(n*Math.sinh(a)+r*Math.cosh(a))
      }
    }
  let T={calculatedDuration:p&&d||null,velocity:e=>P(b(e)),next:e=>{
    if(!p&&h<1){
      let t=Math.exp(-h*_*e),n=Math.sin(x*e),a=Math.cos(x*e),c=o-t*(S*n+g*a),l=P(t*(C*n+w*a));
      return s.done=Math.abs(l)<=r&&Math.abs(o-c)<=i,s.value=s.done?o:c,s
      }
    let t=y(e);
    if(p)
    s.done=e>=d;
    else{
      let n=P(b(e));
      s.done=Math.abs(n)<=r&&Math.abs(o-t)<=i
      }
    return s.value=s.done?o:t,s
    },toString:()=>{
    let e=Math.min(kn(T),On),t=Dn(t=>T.next(e*t).value,e,30);
    return e+`ms `+t
    },toTransition:()=>{
    }};
  return T
  }
Bn.applyToOptions=e=>{
  let t=An(e,100,Bn);
  return e.ease=t.ease,e.duration=P(t.duration),e.type=`keyframes`,e
  };
var Vn=5;
function Hn(e,t,n){
  let r=Math.max(t-Vn,0);
  return Ke(n-e(r),t-r)
  }
function Un({keyframes:e,velocity:t=0,power:n=.8,timeConstant:r=325,bounceDamping:i=10,bounceStiffness:a=500,modifyTarget:o,min:s,max:c,restDelta:l=.5,restSpeed:u}){
  let d=e[0],f={done:!1,value:d},p=e=>s!==void 0&&e<s||c!==void 0&&e>c,m=e=>s===void 0?c:c===void 0||Math.abs(s-e)<Math.abs(c-e)?s:c,h=n*t,g=d+h,_=o===void 0?g:o(g);
  _!==g&&(h=_-d);
  let v=e=>-h*Math.exp(-e/r),y=e=>_+v(e),b=e=>{
    let t=v(e),n=y(e);
    f.done=Math.abs(t)<=l,f.value=f.done?_:n
    },x,S,C=e=>{
    p(f.value)&&(x=e,S=Bn({keyframes:[f.value,m(f.value)],velocity:Hn(y,e,f.value),damping:i,stiffness:a,restDelta:l,restSpeed:u}))
    };
  return C(0),{calculatedDuration:null,next:e=>{
    let t=!1;
    return!S&&x===void 0&&(t=!0,b(e),C(e)),x!==void 0&&e>=x?S.next(e-x):(!t&&b(e),f)
    }}
  }
function Wn(e,t,n){
  let r=[],i=n||N.mix||Tn,a=e.length-1;
  for(
  let n=0
  ;n<a;n++){
    let a=i(e[n],e[n+1]);
    t&&(a=Ue(Array.isArray(t)?t[n]||He:t,a)),r.push(a)
    }
  return r
  }
function Gn(e,t,{clamp:n=!0,ease:r,mixer:i}={}){
  let a=e.length;
  if(t.length,a===1)
  return()=>t[0];
  if(a===2&&t[0]===t[1])
  return()=>t[1];
  let o=e[0]===e[1];
  e[0]>e[a-1]&&(e=[...e].reverse(),t=[...t].reverse());
  let s=Wn(t,r,i),c=s.length,l=n=>{
    if(o&&n<e[0])
    return t[0];
    let r=0;
    if(c>1)
    for(;r<e.length-2&&!(n<e[r+1]);r++);
    let i=We(e[r],e[r+1],n);
    return s[r](i)
    };
  return n?t=>l(M(e[0],e[a-1],t)):l
  }
function Kn(e,t){
  let n=e[e.length-1];
  for(
  let r=1
  ;r<=t;r++){
    let i=We(0,t,r);
    e.push(dn(n,1,i))
    }
  }
function qn(e){
  let t=[0];
  return Kn(t,e.length-1),t
  }
function Jn(e,t){
  return e.map(e=>e*t)
  }
function Yn(e,t){
  return e.map(()=>t||lt).splice(0,e.length-1)
  }
function Xn({duration:e=300,keyframes:t,times:n,ease:r=`easeInOut`}){
  let i=ut(r)?r.map(mt):mt(r),a={done:!1,value:t[0]},o=Gn(Jn(n&&n.length===t.length?n:qn(t),e),t,{ease:Array.isArray(i)?i:Yn(t,i)});
  return{calculatedDuration:e,next:t=>(a.value=o(t),a.done=t>=e,a)}
  }
var Zn=e=>e!==null;
function Qn(e,{repeat:t,repeatType:n=`loop`},r,i=1){
  let a=e.filter(Zn),o=i<0||t&&n!==`loop`&&t%2==1?0:a.length-1;
  return!o||r===void 0?a[o]:r
  }
var $n={decay:Un,inertia:Un,tween:Xn,keyframes:Xn,spring:Bn};
function er(e){
  typeof e.type==`string`&&(e.type=$n[e.type])
  }
var tr=class{
  constructor(){
    this.updateFinished()
    }get finished(){
    return this._finished
    }updateFinished(){
    this._finished=new Promise(e=>{
      this.resolve=e
      })
    }notifyFinished(){
    this.resolve()
    }then(e,t){
    return this.finished.then(e,t)
    }
},nr=e=>e/100,rr=class extends tr{
  constructor(e){
    super(),this.state=`idle`,this.startTime=null,this.isStopped=!1,this.currentTime=0,this.holdTime=null,this.playbackSpeed=1,this.delayState={done:!1,value:void 0},this.stop=()=>{
      let{motionValue:e}=this.options;
      e&&e.updatedAt!==L.now()&&this.tick(L.now()),this.isStopped=!0,this.state!==`idle`&&(this.teardown(),this.options.onStop?.())
      },this.options=e,this.initAnimation(),this.play(),e.autoplay===!1&&this.pause()
    }initAnimation(){
    let{options:e}=this;
    er(e);
    let{type:t=Xn,repeat:n=0,repeatDelay:r=0,repeatType:i,velocity:a=0}=e,{keyframes:o}=e,s=t||Xn;
    s!==Xn&&typeof o[0]!=`number`&&(this.mixKeyframes=Ue(nr,Tn(o[0],o[1])),o=[0,100]);
    let c=s({...e,keyframes:o});
    i===`mirror`&&(this.mirroredGenerator=s({...e,keyframes:[...o].reverse(),velocity:-a})),c.calculatedDuration===null&&(c.calculatedDuration=kn(c));
    let{calculatedDuration:l}=c;
    this.calculatedDuration=l,this.resolvedDuration=l+r,this.totalDuration=this.resolvedDuration*(n+1)-r,this.generator=c
    }updateTime(e){
    let t=Math.round(e-this.startTime)*this.playbackSpeed;
    this.holdTime===null?this.currentTime=t:this.currentTime=this.holdTime
    }tick(e,t=!1){
    let{generator:n,totalDuration:r,mixKeyframes:i,mirroredGenerator:a,resolvedDuration:o,calculatedDuration:s}=this;
    if(this.startTime===null)
    return n.next(0);
    let{delay:c=0,keyframes:l,repeat:u,repeatType:d,repeatDelay:f,type:p,onUpdate:m,finalKeyframe:h}=this.options;
    this.speed>0?this.startTime=Math.min(this.startTime,e):this.speed<0&&(this.startTime=Math.min(e-r/this.speed,this.startTime)),t?this.currentTime=e:this.updateTime(e);
    let g=this.currentTime-c*(this.playbackSpeed>=0?1:-1),_=this.playbackSpeed>=0?g<0:g>r;
    this.currentTime=Math.max(g,0),this.state===`finished`&&this.holdTime===null&&(this.currentTime=r);
    let v=this.currentTime,y=n;
    if(u){
      let e=Math.min(this.currentTime,r)/o,t=Math.floor(e),n=e%1;
      !n&&e>=1&&(n=1),n===1&&t--,t=Math.min(t,u+1),t%2&&(d===`reverse`?(n=1-n,f&&(n-=f/o)):d===`mirror`&&(y=a)),v=M(0,1,n)*o
      }
    let b;
    _?(this.delayState.value=l[0],b=this.delayState):b=y.next(v),i&&!_&&(b.value=i(b.value));
    let{done:x}=b;
    !_&&s!==null&&(x=this.playbackSpeed>=0?this.currentTime>=r:this.currentTime<=0);
    let S=this.holdTime===null&&(this.state===`finished`||this.state===`running`&&x);
    return S&&p!==Un&&(b.value=Qn(l,this.options,h,this.speed)),m&&m(b.value),S&&this.finish(),b
    }then(e,t){
    return this.finished.then(e,t)
    }get duration(){
    return F(this.calculatedDuration)
    }get iterationDuration(){
    let{delay:e=0}=this.options||{};
    return this.duration+F(e)
    }get time(){
    return F(this.currentTime)
    }set time(e){
    e=P(e),this.currentTime=e,this.startTime===null||this.holdTime!==null||this.playbackSpeed===0?this.holdTime=e:this.driver&&(this.startTime=this.driver.now()-e/this.playbackSpeed),this.driver?this.driver.start(!1):(this.startTime=0,this.state=`paused`,this.holdTime=e,this.tick(e))
    }getGeneratorVelocity(){
    let e=this.currentTime;
    if(e<=0)
    return this.options.velocity||0;
    if(this.generator.velocity)
    return this.generator.velocity(e);
    let t=this.generator.next(e).value;
    return Hn(e=>this.generator.next(e).value,e,t)
    }get speed(){
    return this.playbackSpeed
    }set speed(e){
    let t=this.playbackSpeed!==e;
    t&&this.driver&&this.updateTime(L.now()),this.playbackSpeed=e,t&&this.driver&&(this.time=F(this.currentTime))
    }play(){
    if(this.isStopped)
    return;
    let{driver:e=En,startTime:t}=this.options;
    this.driver||=e(e=>this.tick(e)),this.options.onPlay?.();
    let n=this.driver.now();
    this.state===`finished`?(this.updateFinished(),this.startTime=n):this.holdTime===null?this.startTime||=t??n:this.startTime=n-this.holdTime,this.state===`finished`&&this.speed<0&&(this.startTime+=this.calculatedDuration),this.holdTime=null,this.state=`running`,this.driver.start()
    }pause(){
    this.state=`paused`,this.updateTime(L.now()),this.holdTime=this.currentTime
    }complete(){
    this.state!==`running`&&this.play(),this.state=`finished`,this.holdTime=null
    }finish(){
    this.notifyFinished(),this.teardown(),this.state=`finished`,this.options.onComplete?.()
    }cancel(){
    this.holdTime=null,this.startTime=0,this.tick(0),this.teardown(),this.options.onCancel?.()
    }teardown(){
    this.state=`idle`,this.stopDriver(),this.startTime=this.holdTime=null
    }stopDriver(){
    this.driver&&=(this.driver.stop(),void 0)
    }sample(e){
    return this.startTime=0,this.tick(e,!0)
    }attachTimeline(e){
    return this.options.allowFlatten&&(this.options.type=`keyframes`,this.options.ease=`linear`,this.initAnimation()),this.driver?.stop(),e.observe(this)
    }
};
function ir(e){
  for(
  let t=1
  ;t<e.length;t++)
  e[t]??(e[t]=e[t-1])
  }
var q=e=>e*180/Math.PI,ar=e=>sr(q(Math.atan2(e[1],e[0]))),or={x:4,y:5,translateX:4,translateY:5,scaleX:0,scaleY:3,scale:e=>(Math.abs(e[0])+Math.abs(e[3]))/2,rotate:ar,rotateZ:ar,skewX:e=>q(Math.atan(e[1])),skewY:e=>q(Math.atan(e[2])),skew:e=>(Math.abs(e[1])+Math.abs(e[2]))/2},sr=e=>(e%=360,e<0&&(e+=360),e),cr=ar,lr=e=>Math.sqrt(e[0]*e[0]+e[1]*e[1]),ur=e=>Math.sqrt(e[4]*e[4]+e[5]*e[5]),dr={x:12,y:13,z:14,translateX:12,translateY:13,translateZ:14,scaleX:lr,scaleY:ur,scale:e=>(lr(e)+ur(e))/2,rotateX:e=>sr(q(Math.atan2(e[6],e[5]))),rotateY:e=>sr(q(Math.atan2(-e[2],e[0]))),rotateZ:cr,rotate:cr,skewX:e=>q(Math.atan(e[4])),skewY:e=>q(Math.atan(e[1])),skew:e=>(Math.abs(e[1])+Math.abs(e[4]))/2};
function fr(e){
  return+!!e.includes(`scale`)
  }
function pr(e,t){
  if(!e||e===`none`)
  return fr(t);
  let n=e.match(/^matrix3d\(([-\d.e\s,]+)\)$/u),r,i;
  if(n)
  r=dr,i=n;
  else{
    let t=e.match(/^matrix\(([-\d.e\s,]+)\)$/u);
    r=or,i=t
    }
  if(!i)
  return fr(t);
  let a=r[t],o=i[1].split(`,`).map(hr);
  return typeof a==`function`?a(o):o[a]
  }
var mr=(e,t)=>{
  let{transform:n=`none`}=getComputedStyle(e);
  return pr(n,t)
  };
function hr(e){
  return parseFloat(e.trim())
  }
var gr=[`transformPerspective`,`x`,`y`,`z`,`translateX`,`translateY`,`translateZ`,`scale`,`scaleX`,`scaleY`,`rotate`,`rotateX`,`rotateY`,`rotateZ`,`skew`,`skewX`,`skewY`],_r=new Set([...gr,`pathRotation`]),vr=e=>e===At||e===V,yr=new Set([`x`,`y`,`z`]),br=gr.filter(e=>!yr.has(e));
function xr(e){
  let t=[];
  return br.forEach(n=>{
    let r=e.getValue(n);
    r!==void 0&&(t.push([n,r.get()]),r.set(+!!n.startsWith(`scale`)))
    }),t
  }
var J={width:({x:e},{paddingLeft:t=`0`,paddingRight:n=`0`,boxSizing:r})=>{
  let i=e.max-e.min;
  return r===`border-box`?i:i-parseFloat(t)-parseFloat(n)
  },height:({y:e},{paddingTop:t=`0`,paddingBottom:n=`0`,boxSizing:r})=>{
  let i=e.max-e.min;
  return r===`border-box`?i:i-parseFloat(t)-parseFloat(n)
  },top:(e,{top:t})=>parseFloat(t),left:(e,{left:t})=>parseFloat(t),bottom:({y:e},{top:t})=>parseFloat(t)+(e.max-e.min),right:({x:e},{left:t})=>parseFloat(t)+(e.max-e.min),x:(e,{transform:t})=>pr(t,`x`),y:(e,{transform:t})=>pr(t,`y`)};
J.translateX=J.x,J.translateY=J.y;
var Y=new Set,Sr=!1,Cr=!1,wr=!1;
function Tr(){
  if(Cr){
    let e=Array.from(Y).filter(e=>e.needsMeasurement),t=new Set(e.map(e=>e.element)),n=new Map;
    t.forEach(e=>{
      let t=xr(e);
      t.length&&(n.set(e,t),e.render())
      }),e.forEach(e=>e.measureInitialState()),t.forEach(e=>{
      e.render();
      let t=n.get(e);
      t&&t.forEach(([t,n])=>{
        e.getValue(t)?.set(n)
        })
      }),e.forEach(e=>e.measureEndState()),e.forEach(e=>{
      e.suspendedScrollY!==void 0&&window.scrollTo(0,e.suspendedScrollY)
      })
    }
  Cr=!1,Sr=!1,Y.forEach(e=>e.complete(wr)),Y.clear()
  }
function Er(){
  Y.forEach(e=>{
    e.readKeyframes(),e.needsMeasurement&&(Cr=!0)
    })
  }
function Dr(){
  wr=!0,Er(),Tr(),wr=!1
  }
var Or=class{
  constructor(e,t,n,r,i,a=!1){
    this.state=`pending`,this.isAsync=!1,this.needsMeasurement=!1,this.unresolvedKeyframes=[...e],this.onComplete=t,this.name=n,this.motionValue=r,this.element=i,this.isAsync=a
    }scheduleResolve(){
    this.state=`scheduled`,this.isAsync?(Y.add(this),Sr||(Sr=!0,I.read(Er),I.resolveKeyframes(Tr))):(this.readKeyframes(),this.complete())
    }readKeyframes(){
    let{unresolvedKeyframes:e,name:t,element:n,motionValue:r}=this;
    if(e[0]===null){
      let i=r?.get(),a=e[e.length-1];
      if(i!==void 0)
      e[0]=i;
      else 
      if(n&&t){
        let r=n.readValue(t,a);
        r!=null&&(e[0]=r)
        }
      e[0]===void 0&&(e[0]=a),r&&i===void 0&&r.set(e[0])
      }
    ir(e)
    }setFinalKeyframe(){
    }measureInitialState(){
    }renderEndStyles(){
    }measureEndState(){
    }complete(e=!1){
    this.state=`complete`,this.onComplete(this.unresolvedKeyframes,this.finalKeyframe,e),Y.delete(this)
    }cancel(){
    this.state===`scheduled`&&(Y.delete(this),this.state=`pending`)
    }resume(){
    this.state===`pending`&&this.scheduleResolve()
    }
},kr=e=>e.startsWith(`--`);
function Ar(e,t,n){
  kr(t)?e.style.setProperty(t,n):e.style[t]=n
  }
var jr={};
function Mr(e,t){
  let n=Ve(e);
  return()=>jr[t]??n()
  }
var Nr=Mr(()=>window.ScrollTimeline!==void 0,`scrollTimeline`),Pr=Mr(()=>{
  try{
    document.createElement(`div`).animate({opacity:0},{easing:`linear(0, 1)`})
    }catch{
    return!1
    }
  return!0
  },`linearEasing`),Fr=([e,t,n,r])=>`cubic-bezier(${e}, ${t}, ${n}, ${r})`,Ir={linear:`linear`,ease:`ease`,easeIn:`ease-in`,easeOut:`ease-out`,easeInOut:`ease-in-out`,circIn:Fr([0,.65,.55,1]),circOut:Fr([.55,0,1,.45]),backIn:Fr([.31,.01,.66,-.59]),backOut:Fr([.33,1.53,.69,.99])};
function Lr(e,t){
  if(e)
  return typeof e==`function`?Pr()?Dn(e,t):`ease-out`:dt(e)?Fr(e):Array.isArray(e)?e.map(e=>Lr(e,t)||Ir.easeOut):Ir[e]
  }
function Rr(e,t,n,{delay:r=0,duration:i=300,repeat:a=0,repeatType:o=`loop`,ease:s=`easeOut`,times:c}={},l=void 0){
  let u={[t]:n};
  c&&(u.offset=c);
  let d=Lr(s,i);
  Array.isArray(d)&&(u.easing=d);
  let f={delay:r,duration:i,easing:Array.isArray(d)?`linear`:d,fill:`both`,iterations:a+1,direction:o===`reverse`?`alternate`:`normal`};
  return l&&(f.pseudoElement=l),e.animate(u,f)
  }
function zr(e){
  return typeof e==`function`&&`applyToOptions`in e
  }
function Br({type:e,...t}){
  return zr(e)&&Pr()?e.applyToOptions(t):(t.duration??=300,t.ease??=`easeOut`,t)
  }
var Vr=class extends tr{
  constructor(e){
    if(super(),this.finishedTime=null,this.isStopped=!1,this.manualStartTime=null,!e)
    return;
    let{element:t,name:n,keyframes:r,pseudoElement:i,allowFlatten:a=!1,finalKeyframe:o,onComplete:s}=e;
    this.isPseudoElement=!!i,this.allowFlatten=a,this.options=e,e.type;
    let c=Br(e);
    this.animation=Rr(t,n,r,c,i),c.autoplay===!1&&this.animation.pause(),this.animation.onfinish=()=>{
      if(this.finishedTime=this.time,!i){
        let e=Qn(r,this.options,o,this.speed);
        this.updateMotionValue&&this.updateMotionValue(e),Ar(t,n,e),this.animation.cancel()
        }
      s?.(),this.notifyFinished()
      }
    }play(){
    this.isStopped||(this.manualStartTime=null,this.animation.play(),this.state===`finished`&&this.updateFinished())
    }pause(){
    this.animation.pause()
    }complete(){
    this.animation.finish?.()
    }cancel(){
    try{
      this.animation.cancel()
      }catch{
      }
    }stop(){
    if(this.isStopped)
    return;
    this.isStopped=!0;
    let{state:e}=this;
    e===`idle`||e===`finished`||(this.updateMotionValue?this.updateMotionValue():this.commitStyles(),this.isPseudoElement||this.cancel())
    }commitStyles(){
    let e=this.options?.element;
    !this.isPseudoElement&&e?.isConnected&&this.animation.commitStyles?.()
    }get duration(){
    let e=this.animation.effect?.getComputedTiming?.().duration||0;
    return F(Number(e))
    }get iterationDuration(){
    let{delay:e=0}=this.options||{};
    return this.duration+F(e)
    }get time(){
    return F(Number(this.animation.currentTime)||0)
    }set time(e){
    let t=this.finishedTime!==null;
    this.manualStartTime=null,this.finishedTime=null,this.animation.currentTime=P(e),t&&this.animation.pause()
    }get speed(){
    return this.animation.playbackRate
    }set speed(e){
    e<0&&(this.finishedTime=null),this.animation.playbackRate=e
    }get state(){
    return this.finishedTime===null?this.animation.playState:`finished`
    }get startTime(){
    return this.manualStartTime??Number(this.animation.startTime)
    }set startTime(e){
    this.manualStartTime=this.animation.startTime=e
    }attachTimeline({timeline:e,rangeStart:t,rangeEnd:n,observe:r}){
    return this.allowFlatten&&this.animation.effect?.updateTiming({easing:`linear`}),this.animation.onfinish=null,e&&Nr()?(this.animation.timeline=e,t&&(this.animation.rangeStart=t),n&&(this.animation.rangeEnd=n),He):r(this)
    }
},Hr={anticipate:rt,backInOut:nt,circInOut:ot};
function Ur(e){
  return e in Hr
  }
function Wr(e){
  typeof e.ease==`string`&&Ur(e.ease)&&(e.ease=Hr[e.ease])
  }
var Gr=10,Kr=class extends Vr{
  constructor(e){
    Wr(e),er(e),super(e),e.startTime!==void 0&&e.autoplay!==!1&&(this.startTime=e.startTime),this.options=e
    }updateMotionValue(e){
    let{motionValue:t,onUpdate:n,onComplete:r,element:i,...a}=this.options;
    if(!t)
    return;
    if(e!==void 0){
      t.set(e);
      return
      }
    let o=new rr({...a,autoplay:!1}),s=Math.max(Gr,L.now()-this.startTime),c=M(0,Gr,s-Gr),l=o.sample(s).value,{name:u}=this.options;
    i&&u&&Ar(i,u,l),t.setWithVelocity(o.sample(Math.max(0,s-c)).value,l,c),o.stop()
    }
},qr=(e,t)=>t!==`zIndex`&&!!(typeof e==`number`||Array.isArray(e)||typeof e==`string`&&(G.test(e)||e===`0`)&&!e.startsWith(`url(`));
function Jr(e){
  let t=e[0];
  if(e.length===1)
  return!0;
  for(
  let n=0
  ;n<e.length;n++)
  if(e[n]!==t)
  return!0
  }
function Yr(e,t,n,r){
  let i=e[0];
  if(i===null)
  return!1;
  if(t===`display`||t===`visibility`)
  return!0;
  let a=e[e.length-1],o=qr(i,t),s=qr(a,t);
  return`${t}${i}${a}${o?a:i}`,!o||!s?!1:Jr(e)||(n===`spring`||zr(n))&&r
  }
function Xr(e){
  e.duration=0,e.type=`keyframes`
  }
var Zr=new Set([`opacity`,`clipPath`,`filter`,`transform`,`backgroundColor`]),Qr=/^(?:oklch|oklab|lab|lch|color|color-mix|light-dark)\(/;
function $r(e){
  for(
  let t=0
  ;t<e.length;t++)
  if(typeof e[t]==`string`&&Qr.test(e[t]))
  return!0;
  return!1
  }
var ei=new Set([`color`,`backgroundColor`,`outlineColor`,`fill`,`stroke`,`borderColor`,`borderTopColor`,`borderRightColor`,`borderBottomColor`,`borderLeftColor`]),ti=Ve(()=>Object.hasOwnProperty.call(Element.prototype,`animate`));
function ni(e){
  let{motionValue:t,name:n,repeatDelay:r,repeatType:i,damping:a,type:o,keyframes:s}=e,c=t?.owner?.current;
  if(!(c instanceof HTMLElement)&&!(c instanceof SVGElement))
  return!1;
  let{onUpdate:l,transformTemplate:u}=t.owner.getProps();
  return ti()&&n&&(Zr.has(n)||ei.has(n)&&$r(s))&&(n!==`transform`||!u)&&!l&&!r&&i!==`mirror`&&a!==0&&o!==`inertia`
  }
var ri=40,ii=class extends tr{
  constructor({autoplay:e=!0,delay:t=0,type:n=`keyframes`,repeat:r=0,repeatDelay:i=0,repeatType:a=`loop`,keyframes:o,name:s,motionValue:c,element:l,...u}){
    super(),this.stop=()=>{
      this._animation&&(this._animation.stop(),this.stopTimeline?.()),this.keyframeResolver?.cancel()
      },this.createdAt=L.now();
    let d={autoplay:e,delay:t,type:n,repeat:r,repeatDelay:i,repeatType:a,name:s,motionValue:c,element:l,...u},f=l?.KeyframeResolver||Or;
    this.keyframeResolver=new f(o,(e,t,n)=>this.onKeyframesResolved(e,t,d,!n),s,c,l),this.keyframeResolver?.scheduleResolve()
    }onKeyframesResolved(e,t,n,r){
    this.keyframeResolver=void 0;
    let{name:i,type:a,velocity:o,delay:s,isHandoff:c,onUpdate:l}=n;
    this.resolvedAt=L.now();
    let u=!0;
    Yr(e,i,a,o)||(u=!1,(N.instantAnimations||!s)&&l?.(Qn(e,n,t)),e[0]=e[e.length-1],Xr(n),n.repeat=0);
    let d={startTime:r?this.resolvedAt&&this.resolvedAt-this.createdAt>ri?this.resolvedAt:this.createdAt:void 0,finalKeyframe:t,...n,keyframes:e},f=u&&!c&&ni(d),p=d.motionValue?.owner?.current,m;
    if(f)
    try{
      m=new Kr({...d,element:p})
      }catch{
      m=new rr(d)
      }
    else 
    m=new rr(d);
    m.finished.then(()=>{
      this.notifyFinished()
      }).catch(He),this.pendingTimeline&&=(this.stopTimeline=m.attachTimeline(this.pendingTimeline),void 0),this._animation=m
    }get finished(){
    return this._animation?this.animation.finished:this._finished
    }then(e,t){
    return this.finished.finally(e).then(()=>{
      })
    }get animation(){
    return this._animation||(this.keyframeResolver?.resume(),Dr()),this._animation
    }get duration(){
    return this.animation.duration
    }get iterationDuration(){
    return this.animation.iterationDuration
    }get time(){
    return this.animation.time
    }set time(e){
    this.animation.time=e
    }get speed(){
    return this.animation.speed
    }get state(){
    return this.animation.state
    }set speed(e){
    this.animation.speed=e
    }get startTime(){
    return this.animation.startTime
    }attachTimeline(e){
    return this._animation?this.stopTimeline=this.animation.attachTimeline(e):this.pendingTimeline=e,()=>this.stop()
    }play(){
    this.animation.play()
    }pause(){
    this.animation.pause()
    }complete(){
    this.animation.complete()
    }cancel(){
    this._animation&&this.animation.cancel(),this.keyframeResolver?.cancel()
    }
};
function ai(e,t,n,r=0,i=1){
  let a=Array.from(e).sort((e,t)=>e.sortNodePosition(t)).indexOf(t),o=e.size,s=(o-1)*r;
  return typeof n==`function`?n(a,o):i===1?a*r:s-a*r
  }
var oi=30,si=e=>!isNaN(parseFloat(e)),ci={current:void 0},li=class{
  constructor(e,t={}){
    this.canTrackVelocity=null,this.events={},this.updateAndNotify=e=>{
      let t=L.now();
      if(this.updatedAt!==t&&this.setPrevFrameValue(),this.prev=this.current,this.setCurrent(e),this.current!==this.prev&&(this.events.change?.notify(this.current),this.dependents))
      for(
      let e
       of this.dependents)
      e.dirty()
      },this.hasAnimated=!1,this.setCurrent(e),this.owner=t.owner
    }setCurrent(e){
    this.current=e,this.updatedAt=L.now(),this.canTrackVelocity===null&&e!==void 0&&(this.canTrackVelocity=si(this.current))
    }setPrevFrameValue(e=this.current){
    this.prevFrameValue=e,this.prevUpdatedAt=this.updatedAt
    }onChange(e){
    return this.on(`change`,e)
    }on(e,t){
    this.events[e]||(this.events[e]=new Ge);
    let n=this.events[e].add(t);
    return e===`change`?()=>{
      n(),I.read(()=>{
        this.events.change.getSize()||this.stop()
        })
      }:n
    }clearListeners(){
    for(
    let e
     in this.events)
    this.events[e].clear()
    }attach(e,t){
    this.passiveEffect=e,this.stopPassiveEffect=t
    }set(e){
    this.passiveEffect?this.passiveEffect(e,this.updateAndNotify):this.updateAndNotify(e)
    }setWithVelocity(e,t,n){
    this.set(t),this.prev=void 0,this.prevFrameValue=e,this.prevUpdatedAt=this.updatedAt-n
    }jump(e,t=!0){
    this.updateAndNotify(e),this.prev=e,this.prevUpdatedAt=this.prevFrameValue=void 0,t&&this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()
    }dirty(){
    this.events.change?.notify(this.current)
    }addDependent(e){
    this.dependents||=new Set,this.dependents.add(e)
    }removeDependent(e){
    this.dependents&&this.dependents.delete(e)
    }get(){
    return ci.current&&ci.current.push(this),this.current
    }getPrevious(){
    return this.prev
    }getVelocity(){
    let e=L.now();
    if(!this.canTrackVelocity||this.prevFrameValue===void 0||e-this.updatedAt>oi)
    return 0;
    let t=Math.min(this.updatedAt-this.prevUpdatedAt,oi);
    return Ke(parseFloat(this.current)-parseFloat(this.prevFrameValue),t)
    }start(e){
    return this.stop(),new Promise(t=>{
      this.hasAnimated=!0,this.animation=e(t),this.events.animationStart&&this.events.animationStart.notify()
      }).then(()=>{
      this.events.animationComplete&&this.events.animationComplete.notify(),this.clearAnimation()
      })
    }stop(){
    this.animation&&(this.animation.stop(),this.events.animationCancel&&this.events.animationCancel.notify()),this.clearAnimation()
    }isAnimating(){
    return!!this.animation
    }clearAnimation(){
    delete this.animation
    }destroy(){
    this.dependents?.clear(),this.events.destroy?.notify(),this.clearListeners(),this.stop(),this.stopPassiveEffect&&this.stopPassiveEffect()
    }
};
function ui(e,t){
  return new li(e,t)
  }
function di(e,t){
  if(e?.inherit&&t){
    let{inherit:n,...r}=e;
    return{...t,...r}
    }
  return e
  }
function fi(e,t){
  let n=e?.[t]??e?.default??e;
  return n===e?n:di(n,e)
  }
var pi={type:`spring`,stiffness:500,damping:25,restSpeed:10},mi=e=>({type:`spring`,stiffness:550,damping:e===0?2*Math.sqrt(550):30,restSpeed:10}),hi={type:`keyframes`,duration:.8},gi={type:`keyframes`,ease:[.25,.1,.35,1],duration:.3},_i=(e,{keyframes:t})=>t.length>2?hi:_r.has(e)?e.startsWith(`scale`)?mi(t[1]):pi:gi,vi=new Set([`when`,`delay`,`delayChildren`,`staggerChildren`,`staggerDirection`,`repeat`,`repeatType`,`repeatDelay`,`from`,`elapsed`]);
function yi(e){
  for(
  let t
   in e)
  if(!vi.has(t))
  return!0;
  return!1
  }
var bi=(e,t,n,r={},i,a)=>o=>{
  let s=fi(r,e)||{},c=s.delay||r.delay||0,{elapsed:l=0}=r;
  l-=P(c);
  let u={keyframes:Array.isArray(n)?n:[null,n],ease:`easeOut`,velocity:t.getVelocity(),...s,delay:-l,onUpdate:e=>{
    t.set(e),s.onUpdate&&s.onUpdate(e)
    },onComplete:()=>{
    o(),s.onComplete&&s.onComplete()
    },name:e,motionValue:t,element:a?void 0:i};
  yi(s)||Object.assign(u,_i(e,u)),u.duration&&=P(u.duration),u.repeatDelay&&=P(u.repeatDelay),u.from!==void 0&&(u.keyframes[0]=u.from);
  let d=!1;
  if((u.type===!1||u.duration===0&&!u.repeatDelay)&&(Xr(u),u.delay===0&&(d=!0)),(N.instantAnimations||N.skipAnimations||i?.shouldSkipAnimations||s.skipAnimations)&&(d=!0,Xr(u),u.delay=0),u.allowFlatten=!s.type&&!s.ease,d&&!a&&t.get()!==void 0){
    let e=Qn(u.keyframes,s);
    if(e!==void 0){
      I.update(()=>{
        u.onUpdate(e),u.onComplete()
        });
      return
      }
    }
  return s.isSync?new rr(u):new ii(u)
  },xi=/^var\(--(?:([\w-]+)|([\w-]+), ?([a-zA-Z\d ()%#.,-]+))\)/u;
function Si(e){
  let t=xi.exec(e);
  if(!t)
  return[,];
  let[,n,r,i]=t;
  return[`--${n??r}`,i]
  }
function Ci(e,t,n=1){
  `${e}`;
  let[r,i]=Si(e);
  if(!r)
  return;
  let a=window.getComputedStyle(t).getPropertyValue(r);
  if(a){
    let e=a.trim();
    return Re(e)?parseFloat(e):e
    }
  return Dt(i)?Ci(i,t,n+1):i
  }
function wi(e){
  let t=[{},{}];
  return e?.values.forEach((e,n)=>{
    t[0][n]=e.get(),t[1][n]=e.getVelocity()
    }),t
  }
function Ti(e,t,n,r){
  if(typeof t==`function`){
    let[i,a]=wi(r);
    t=t(n===void 0?e.custom:n,i,a)
    }
  if(typeof t==`string`&&(t=e.variants&&e.variants[t]),typeof t==`function`){
    let[i,a]=wi(r);
    t=t(n===void 0?e.custom:n,i,a)
    }
  return t
  }
function X(e,t,n){
  let r=e.getProps();
  return Ti(r,t,n===void 0?r.custom:n,e)
  }
var Ei=new Set([`width`,`height`,`top`,`left`,`right`,`bottom`,...gr]),Di=e=>Array.isArray(e);
function Oi(e,t,n){
  e.hasValue(t)?e.getValue(t).set(n):e.addValue(t,ui(n))
  }
function ki(e){
  return Di(e)?e[e.length-1]||0:e
  }
function Ai(e,t){
  let{transitionEnd:n={},transition:r={},...i}=X(e,t)||{};
  i={...i,...n};
  for(
  let t
   in i)
  Oi(e,t,ki(i[t]))
  }
var Z=e=>!!(e&&e.getVelocity);
function ji(e){
  return!!(Z(e)&&e.add)
  }
function Mi(e,t){
  let n=e.getValue(`willChange`);
  if(ji(n))
  return n.add(t);
  if(!n&&N.WillChange){
    let n=new N.WillChange(`auto`);
    e.addValue(`willChange`,n),n.add(t)
    }
  }
function Ni(e){
  return e.replace(/([A-Z])/g,e=>`-${e.toLowerCase()}`)
  }
var Pi=`data-`+Ni(`framerAppearId`);
function Fi(e){
  return e.props[Pi]
  }
function Ii({protectedKeys:e,needsAnimating:t},n){
  let r=e.hasOwnProperty(n)&&t[n]!==!0;
  return t[n]=!1,r
  }
function Li(e,t,{delay:n=0,transitionOverride:r,type:i}={}){
  let{transition:a,transitionEnd:o,...s}=t,c=e.getDefaultTransition();
  a=a?di(a,c):c;
  let l=a?.reduceMotion,u=a?.skipAnimations;
  r&&(a=r);
  let d=[],f=i&&e.animationState&&e.animationState.getState()[i],p=a?.path;
  p&&p.animateVisualElement(e,s,a,n,d);
  for(
  let t
   in s){
    let r=e.getValue(t,e.latestValues[t]??null),i=s[t];
    if(i===void 0||f&&Ii(f,t))
    continue;
    let o={delay:n,...fi(a||{},t)};
    u&&(o.skipAnimations=!0);
    let c=r.get();
    if(c!==void 0&&!r.isAnimating()&&!Array.isArray(i)&&i===c&&!o.velocity){
      I.update(()=>r.set(i));
      continue
      }
    let p=!1;
    if(window.MotionHandoffAnimation){
      let n=Fi(e);
      if(n){
        let e=window.MotionHandoffAnimation(n,t,I);
        e!==null&&(o.startTime=e,p=!0)
        }
      }
    Mi(e,t);
    let m=l??e.shouldReduceMotion;
    r.start(bi(t,r,i,m&&Ei.has(t)?{type:!1}:o,e,p));
    let h=r.animation;
    h&&d.push(h)
    }
  if(o){
    let t=()=>I.update(()=>{
      o&&Ai(e,o)
      });
    d.length?Promise.all(d).then(t):t()
    }
  return d
  }
function Ri(e,t,n={}){
  let r=X(e,t,n.type===`exit`?e.presenceContext?.custom:void 0),{transition:i=e.getDefaultTransition()||{}}=r||{};
  n.transitionOverride&&(i=n.transitionOverride);
  let a=r?()=>Promise.all(Li(e,r,n)):()=>Promise.resolve(),o=e.variantChildren&&e.variantChildren.size?(r=0)=>{
    let{delayChildren:a=0,staggerChildren:o,staggerDirection:s}=i;
    return zi(e,t,r,a,o,s,n)
    }:()=>Promise.resolve(),{when:s}=i;
  if(s){
    let[e,t]=s===`beforeChildren`?[a,o]:[o,a];
    return e().then(()=>t())
    }else 
  return Promise.all([a(),o(n.delay)])
  }
function zi(e,t,n=0,r=0,i=0,a=1,o){
  let s=[];
  for(
  let c
   of e.variantChildren)
  c.notify(`AnimationStart`,t),s.push(Ri(c,t,{...o,delay:n+(typeof r==`function`?0:r)+ai(e.variantChildren,c,r,i,a)}).then(()=>c.notify(`AnimationComplete`,t)));
  return Promise.all(s)
  }
function Bi(e,t,n={}){
  e.notify(`AnimationStart`,t);
  let r;
  if(Array.isArray(t)){
    let i=t.map(t=>Ri(e,t,n));
    r=Promise.all(i)
    }else 
  if(typeof t==`string`)
  r=Ri(e,t,n);
  else{
    let i=typeof t==`function`?X(e,t,n.custom):t;
    r=Promise.all(Li(e,i,n))
    }
  return r.then(()=>{
    e.notify(`AnimationComplete`,t)
    })
  }
var Vi={test:e=>e===`auto`,parse:e=>e},Hi=e=>t=>t.test(e),Ui=[At,V,B,z,Gt,Wt,Vi],Wi=e=>Ui.find(Hi(e));
function Gi(e){
  return typeof e==`number`?e===0:e===null||e===`none`||e===`0`||Be(e)
  }
var Ki=new Set([`brightness`,`contrast`,`saturate`,`opacity`]);
function qi(e){
  let[t,n]=e.slice(0,-1).split(`(`);
  if(t===`drop-shadow`)
  return e;
  let[r]=n.match(Pt)||[];
  if(!r)
  return e;
  let i=n.replace(r,``),a=+!!Ki.has(t);
  return r!==n&&(a*=100),t+`(`+a+i+`)`
  }
var Ji=/\b([a-z-]*)\(.*?\)/gu,Yi={...G,getAnimatableNone:e=>{
  let t=e.match(Ji);
  return t?t.map(qi).join(` `):e
  }},Xi={...G,getAnimatableNone:e=>{
  let t=G.parse(e);
  return G.createTransformer(e)(t.map(e=>typeof e==`number`?0:typeof e==`object`?{...e,alpha:1}:e))
  }},Zi={...At,transform:Math.round},Qi={borderWidth:V,borderTopWidth:V,borderRightWidth:V,borderBottomWidth:V,borderLeftWidth:V,borderRadius:V,borderTopLeftRadius:V,borderTopRightRadius:V,borderBottomRightRadius:V,borderBottomLeftRadius:V,width:V,maxWidth:V,height:V,maxHeight:V,top:V,right:V,bottom:V,left:V,inset:V,insetBlock:V,insetBlockStart:V,insetBlockEnd:V,insetInline:V,insetInlineStart:V,insetInlineEnd:V,padding:V,paddingTop:V,paddingRight:V,paddingBottom:V,paddingLeft:V,paddingBlock:V,paddingBlockStart:V,paddingBlockEnd:V,paddingInline:V,paddingInlineStart:V,paddingInlineEnd:V,margin:V,marginTop:V,marginRight:V,marginBottom:V,marginLeft:V,marginBlock:V,marginBlockStart:V,marginBlockEnd:V,marginInline:V,marginInlineStart:V,marginInlineEnd:V,fontSize:V,backgroundPositionX:V,backgroundPositionY:V,rotate:z,pathRotation:z,rotateX:z,rotateY:z,rotateZ:z,scale:Mt,scaleX:Mt,scaleY:Mt,scaleZ:Mt,skew:z,skewX:z,skewY:z,distance:V,translateX:V,translateY:V,translateZ:V,x:V,y:V,z:V,perspective:V,transformPerspective:V,opacity:jt,originX:Kt,originY:Kt,originZ:V,zIndex:Zi,fillOpacity:jt,strokeOpacity:jt,numOctaves:Zi},$i={...Qi,color:U,backgroundColor:U,outlineColor:U,fill:U,stroke:U,borderColor:U,borderTopColor:U,borderRightColor:U,borderBottomColor:U,borderLeftColor:U,filter:Yi,WebkitFilter:Yi,mask:Xi,WebkitMask:Xi},ea=e=>$i[e],ta=new Set([Yi,Xi]);
function na(e,t){
  let n=ea(e);
  return ta.has(n)||(n=G),n.getAnimatableNone?n.getAnimatableNone(t):void 0
  }
var ra=new Set([`auto`,`none`,`0`]);
function ia(e,t,n){
  let r=0,i;
  for(;r<e.length&&!i;){
    let t=e[r];
    typeof t==`string`&&!ra.has(t)&&W(t).values.length&&(i=e[r]),r++
    }
  if(i&&n)
  for(
  let r
   of t)
  e[r]=na(n,i)
  }
var aa=class extends Or{
  constructor(e,t,n,r,i){
    super(e,t,n,r,i,!0)
    }readKeyframes(){
    let{unresolvedKeyframes:e,element:t,name:n}=this;
    if(!t||!t.current)
    return;
    super.readKeyframes();
    for(
    let n=0
    ;n<e.length;n++){
      let r=e[n];
      if(typeof r==`string`&&(r=r.trim(),Dt(r))){
        let i=Ci(r,t.current);
        i!==void 0&&(e[n]=i),n===e.length-1&&(this.finalKeyframe=r)
        }
      }
    if(this.resolveNoneKeyframes(),!Ei.has(n)||e.length!==2)
    return;
    let[r,i]=e,a=Wi(r),o=Wi(i);
    if(kt(r)!==kt(i)&&J[n]){
      this.needsMeasurement=!0;
      return
      }
    if(a!==o)
    if(vr(a)&&vr(o))
    for(
    let t=0
    ;t<e.length;t++){
      let n=e[t];
      typeof n==`string`&&(e[t]=parseFloat(n))
      }
    else 
    J[n]&&(this.needsMeasurement=!0)
    }resolveNoneKeyframes(){
    let{unresolvedKeyframes:e,name:t}=this,n=[];
    for(
    let t=0
    ;t<e.length;t++)
    (e[t]===null||Gi(e[t]))&&n.push(t);
    n.length&&ia(e,n,t)
    }measureInitialState(){
    let{element:e,unresolvedKeyframes:t,name:n}=this;
    if(!e||!e.current)
    return;
    n===`height`&&(this.suspendedScrollY=window.pageYOffset),this.measuredOrigin=J[n](e.measureViewportBox(),window.getComputedStyle(e.current)),t[0]=this.measuredOrigin;
    let r=t[t.length-1];
    r!==void 0&&e.getValue(n,r).jump(r,!1)
    }measureEndState(){
    let{element:e,name:t,unresolvedKeyframes:n}=this;
    if(!e||!e.current)
    return;
    let r=e.getValue(t);
    r&&r.jump(this.measuredOrigin,!1);
    let i=n.length-1,a=n[i];
    n[i]=J[t](e.measureViewportBox(),window.getComputedStyle(e.current)),a!==null&&this.finalKeyframe===void 0&&(this.finalKeyframe=a),this.removedTransforms?.length&&this.removedTransforms.forEach(([t,n])=>{
      e.getValue(t).set(n)
      }),this.resolveNoneKeyframes()
    }
},oa=[`borderTopLeftRadius`,`borderTopRightRadius`,`borderBottomRightRadius`,`borderBottomLeftRadius`];
function sa(e,t,n){
  if(e==null)
  return[];
  if(e instanceof EventTarget)
  return[e];
  if(typeof e==`string`){
    let r=document;
    t&&(r=t.current);
    let i=n?.[e]??r.querySelectorAll(e);
    return i?Array.from(i):[]
    }
  return Array.from(e).filter(e=>e!=null)
  }
var ca=(e,t)=>t&&typeof e==`number`?t.transform(e):e;
function la(e){
  return ze(e)&&`offsetHeight`in e&&!(`ownerSVGElement`in e)
  }
var{schedule:ua,cancel:da}=vt(queueMicrotask,!1),fa={x:!1,y:!1};
function pa(){
  return fa.x||fa.y
  }
function ma(e,t){
  let n=sa(e),r=new AbortController;
  return[n,{passive:!0,...t,signal:r.signal},()=>r.abort()]
  }
function ha(e){
  return!(e.pointerType===`touch`||pa())
  }
function ga(e,t,n={}){
  let[r,i,a]=ma(e,n);
  return r.forEach(e=>{
    let n=!1,r=!1,a,o=()=>{
      e.removeEventListener(`pointerleave`,u)
      },s=e=>{
      a&&=(a(e),void 0),o()
      },c=e=>{
      n=!1,window.removeEventListener(`pointerup`,c),window.removeEventListener(`pointercancel`,c),r&&(r=!1,s(e))
      },l=()=>{
      n=!0,window.addEventListener(`pointerup`,c,i),window.addEventListener(`pointercancel`,c,i)
      },u=e=>{
      if(e.pointerType!==`touch`){
        if(n){
          r=!0;
          return
          }
        s(e)
        }
      };
    e.addEventListener(`pointerenter`,n=>{
      if(!ha(n))
      return;
      r=!1;
      let o=t(e,n);
      typeof o==`function`&&(a=o,e.addEventListener(`pointerleave`,u,i))
      },i),e.addEventListener(`pointerdown`,l,i)
    }),a
  }
var _a=(e,t)=>t?e===t||_a(e,t.parentElement):!1,va=e=>e.pointerType===`mouse`?typeof e.button!=`number`||e.button<=0:e.isPrimary!==!1,ya=new Set([`BUTTON`,`INPUT`,`SELECT`,`TEXTAREA`,`A`]);
function ba(e){
  return ya.has(e.tagName)||e.isContentEditable===!0
  }
var xa=new WeakSet;
function Sa(e){
  return t=>{
    t.key===`Enter`&&e(t)
    }
  }
function Ca(e,t){
  e.dispatchEvent(new PointerEvent(`pointer`+t,{isPrimary:!0,bubbles:!0}))
  }
var wa=(e,t)=>{
  let n=e.currentTarget;
  if(!n)
  return;
  let r=Sa(()=>{
    if(xa.has(n))
    return;
    Ca(n,`down`);
    let e=Sa(()=>{
      Ca(n,`up`)
      });
    n.addEventListener(`keyup`,e,t),n.addEventListener(`blur`,()=>Ca(n,`cancel`),t)
    });
  n.addEventListener(`keydown`,r,t),n.addEventListener(`blur`,()=>n.removeEventListener(`keydown`,r),t)
  };
function Ta(e){
  return va(e)&&!pa()
  }
var Ea=new WeakSet;
function Da(e,t,n={}){
  let[r,i,a]=ma(e,n),o=e=>{
    let r=e.currentTarget;
    if(!Ta(e)||Ea.has(e))
    return;
    xa.add(r),n.stopPropagation&&Ea.add(e);
    let a=t(r,e),o={...i,capture:!0},s=(e,t)=>{
      window.removeEventListener(`pointerup`,c,o),window.removeEventListener(`pointercancel`,l,o),xa.has(r)&&xa.delete(r),Ta(e)&&typeof a==`function`&&a(e,{success:t})
      },c=e=>{
      s(e,r===window||r===document||n.useGlobalTarget||_a(r,e.target))
      },l=e=>{
      s(e,!1)
      };
    window.addEventListener(`pointerup`,c,o),window.addEventListener(`pointercancel`,l,o)
    };
  return r.forEach(e=>{
    (n.useGlobalTarget?window:e).addEventListener(`pointerdown`,o,i),la(e)&&(e.addEventListener(`focus`,e=>wa(e,i)),!ba(e)&&!e.hasAttribute(`tabindex`)&&(e.tabIndex=0))
    }),a
  }
var Oa=[...Ui,U,G],ka=e=>Oa.find(Hi(e)),Aa=()=>({min:0,max:0}),ja=()=>({x:Aa(),y:Aa()}),Ma=new WeakMap;
function Na(e){
  return typeof e==`object`&&!!e&&typeof e.start==`function`
  }
function Pa(e){
  return typeof e==`string`||Array.isArray(e)
  }
var Fa=[`animate`,`whileInView`,`whileFocus`,`whileHover`,`whileTap`,`whileDrag`,`exit`],Ia=[`initial`,...Fa];
function La(e){
  return Na(e.animate)||Ia.some(t=>Pa(e[t]))
  }
function Ra(e){
  return!!(La(e)||e.variants)
  }
function za(e,t,n){
  for(
  let r
   in t){
    let i=t[r],a=n[r];
    if(Z(i))
    e.addValue(r,i);
    else 
    if(Z(a))
    e.addValue(r,ui(i,{owner:e}));
    else 
    if(a!==i)
    if(e.hasValue(r)){
      let t=e.getValue(r);
      t.liveStyle===!0?t.jump(i):t.hasAnimated||t.set(i)
      }else{
      let t=e.getStaticValue(r);
      e.addValue(r,ui(t===void 0?i:t,{owner:e}))
      }
    }
  for(
  let r
   in n)
  t[r]===void 0&&e.removeValue(r);
  return t
  }
var Ba={current:null},Va={current:!1},Ha=typeof window<`u`;
function Ua(){
  if(Va.current=!0,Ha)
  if(window.matchMedia){
    let e=window.matchMedia(`(prefers-reduced-motion)`),t=()=>Ba.current=e.matches;
    e.addEventListener(`change`,t),t()
    }else 
  Ba.current=!1
  }
var Wa=[`AnimationStart`,`AnimationComplete`,`Update`,`BeforeLayoutMeasure`,`LayoutMeasure`,`LayoutAnimationStart`,`LayoutAnimationComplete`],Ga={};
function Ka(e){
  Ga=e
  }
function qa(){
  return Ga
  }
var Ja=class{
  scrapeMotionValuesFromProps(e,t,n){
    return{}
    }constructor({parent:e,props:t,presenceContext:n,reducedMotionConfig:r,skipAnimations:i,blockInitialAnimation:a,visualState:o},s={}){
    this.current=null,this.children=new Set,this.isVariantNode=!1,this.isControllingVariants=!1,this.shouldReduceMotion=null,this.shouldSkipAnimations=!1,this.values=new Map,this.KeyframeResolver=Or,this.features={},this.valueSubscriptions=new Map,this.prevMotionValues={},this.hasBeenMounted=!1,this.events={},this.propEventSubscriptions={},this.notifyUpdate=()=>this.notify(`Update`,this.latestValues),this.render=()=>{
      this.current&&(this.triggerBuild(),this.renderInstance(this.current,this.renderState,this.props.style,this.projection))
      },this.renderScheduledAt=0,this.scheduleRender=()=>{
      let e=L.now();
      this.renderScheduledAt<e&&(this.renderScheduledAt=e,I.render(this.render,!1,!0))
      };
    let{latestValues:c,renderState:l}=o;
    this.latestValues=c,this.baseTarget={...c},this.initialValues=t.initial?{...c}:{},this.renderState=l,this.parent=e,this.props=t,this.presenceContext=n,this.depth=e?e.depth+1:0,this.reducedMotionConfig=r,this.skipAnimationsConfig=i,this.options=s,this.blockInitialAnimation=!!a,this.isControllingVariants=La(t),this.isVariantNode=Ra(t),this.isVariantNode&&(this.variantChildren=new Set),this.manuallyAnimateOnMount=!!(e&&e.current);
    let{willChange:u,...d}=this.scrapeMotionValuesFromProps(t,{},this);
    for(
    let e
     in d){
      let t=d[e];
      c[e]!==void 0&&Z(t)&&t.set(c[e])
      }
    }mount(e){
    if(this.hasBeenMounted)
    for(
    let e
     in this.initialValues)
    this.values.get(e)?.jump(this.initialValues[e]),this.latestValues[e]=this.initialValues[e];
    this.current=e,Ma.set(e,this),this.projection&&!this.projection.instance&&this.projection.mount(e),this.parent&&this.isVariantNode&&!this.isControllingVariants&&(this.removeFromVariantTree=this.parent.addVariantChild(this)),this.values.forEach((e,t)=>this.bindToMotionValue(t,e)),this.reducedMotionConfig===`never`?this.shouldReduceMotion=!1:this.reducedMotionConfig===`always`?this.shouldReduceMotion=!0:(Va.current||Ua(),this.shouldReduceMotion=Ba.current),this.shouldSkipAnimations=this.skipAnimationsConfig??!1,this.parent?.addChild(this),this.update(this.props,this.presenceContext),this.hasBeenMounted=!0
    }unmount(){
    this.projection&&this.projection.unmount(),yt(this.notifyUpdate),yt(this.render),this.valueSubscriptions.forEach(e=>e()),this.valueSubscriptions.clear(),this.removeFromVariantTree&&this.removeFromVariantTree(),this.parent?.removeChild(this);
    for(
    let e
     in this.events)
    this.events[e].clear();
    for(
    let e
     in this.features){
      let t=this.features[e];
      t&&(t.unmount(),t.isMounted=!1)
      }
    this.current=null
    }addChild(e){
    this.children.add(e),this.enteringChildren??=new Set,this.enteringChildren.add(e)
    }removeChild(e){
    this.children.delete(e),this.enteringChildren&&this.enteringChildren.delete(e)
    }bindToMotionValue(e,t){
    if(this.valueSubscriptions.has(e)&&this.valueSubscriptions.get(e)(),t.accelerate&&Zr.has(e)&&this.current instanceof HTMLElement){
      let{factory:n,keyframes:r,times:i,ease:a,duration:o}=t.accelerate,s=new Vr({element:this.current,name:e,keyframes:r,times:i,ease:a,duration:P(o)}),c=n(s);
      this.valueSubscriptions.set(e,()=>{
        c(),s.cancel()
        });
      return
      }
    let n=_r.has(e);
    n&&this.onBindTransform&&this.onBindTransform();
    let r=t.on(`change`,t=>{
      this.latestValues[e]=t,this.props.onUpdate&&I.preRender(this.notifyUpdate),n&&this.projection&&(this.projection.isTransformDirty=!0),this.scheduleRender()
      }),i;
    typeof window<`u`&&window.MotionCheckAppearSync&&(i=window.MotionCheckAppearSync(this,e,t)),this.valueSubscriptions.set(e,()=>{
      r(),i&&i()
      })
    }sortNodePosition(e){
    return!this.current||!this.sortInstanceNodePosition||this.type!==e.type?0:this.sortInstanceNodePosition(this.current,e.current)
    }updateFeatures(){
    let e=`animation`;
    for(e in Ga){
      let t=Ga[e];
      if(!t)
      continue;
      let{isEnabled:n,Feature:r}=t;
      if(!this.features[e]&&r&&n(this.props)&&(this.features[e]=new r(this)),this.features[e]){
        let t=this.features[e];
        t.isMounted?t.update():(t.mount(),t.isMounted=!0)
        }
      }
    }triggerBuild(){
    this.build(this.renderState,this.latestValues,this.props)
    }measureViewportBox(){
    return this.current?this.measureInstanceViewportBox(this.current,this.props):ja()
    }getStaticValue(e){
    return this.latestValues[e]
    }setStaticValue(e,t){
    this.latestValues[e]=t
    }update(e,t){
    (e.transformTemplate||this.props.transformTemplate)&&this.scheduleRender(),this.prevProps=this.props,this.props=e,this.prevPresenceContext=this.presenceContext,this.presenceContext=t;
    for(
    let t=0
    ;t<Wa.length;t++){
      let n=Wa[t];
      this.propEventSubscriptions[n]&&(this.propEventSubscriptions[n](),delete this.propEventSubscriptions[n]);
      let r=e[`on`+n];
      r&&(this.propEventSubscriptions[n]=this.on(n,r))
      }
    this.prevMotionValues=za(this,this.scrapeMotionValuesFromProps(e,this.prevProps||{},this),this.prevMotionValues),this.handleChildMotionValue&&this.handleChildMotionValue()
    }getProps(){
    return this.props
    }getVariant(e){
    return this.props.variants?this.props.variants[e]:void 0
    }getDefaultTransition(){
    return this.props.transition
    }getTransformPagePoint(){
    return this.props.transformPagePoint
    }getClosestVariantNode(){
    return this.isVariantNode?this:this.parent?this.parent.getClosestVariantNode():void 0
    }addVariantChild(e){
    let t=this.getClosestVariantNode();
    if(t)
    return t.variantChildren&&t.variantChildren.add(e),()=>t.variantChildren.delete(e)
    }addValue(e,t){
    let n=this.values.get(e);
    t!==n&&(n&&this.removeValue(e),this.bindToMotionValue(e,t),this.values.set(e,t),this.latestValues[e]=t.get())
    }removeValue(e){
    this.values.delete(e);
    let t=this.valueSubscriptions.get(e);
    t&&(t(),this.valueSubscriptions.delete(e)),delete this.latestValues[e],this.removeValueFromRenderState(e,this.renderState)
    }hasValue(e){
    return this.values.has(e)
    }getValue(e,t){
    if(this.props.values&&this.props.values[e])
    return this.props.values[e];
    let n=this.values.get(e);
    return n===void 0&&t!==void 0&&(n=ui(t===null?void 0:t,{owner:this}),this.addValue(e,n)),n
    }readValue(e,t){
    let n=this.latestValues[e]!==void 0||!this.current?this.latestValues[e]:this.getBaseTargetFromProps(this.props,e)??this.readValueFromInstance(this.current,e,this.options);
    return n!=null&&(typeof n==`string`&&(Re(n)||Be(n))?n=parseFloat(n):!ka(n)&&G.test(t)&&(n=na(e,t)),this.setBaseTarget(e,Z(n)?n.get():n)),Z(n)?n.get():n
    }setBaseTarget(e,t){
    this.baseTarget[e]=t
    }getBaseTarget(e){
    let{initial:t}=this.props,n;
    if(typeof t==`string`||typeof t==`object`){
      let r=Ti(this.props,t,this.presenceContext?.custom);
      r&&(n=r[e])
      }
    if(t&&n!==void 0)
    return n;
    let r=this.getBaseTargetFromProps(this.props,e);
    return r!==void 0&&!Z(r)?r:this.initialValues[e]!==void 0&&n===void 0?void 0:this.baseTarget[e]
    }on(e,t){
    return this.events[e]||(this.events[e]=new Ge),this.events[e].add(t)
    }notify(e,...t){
    this.events[e]&&this.events[e].notify(...t)
    }scheduleRenderMicrotask(){
    ua.render(this.render)
    }
},Ya=class extends Ja{
  constructor(){
    super(...arguments),this.KeyframeResolver=aa
    }sortInstanceNodePosition(e,t){
    return e.compareDocumentPosition(t)&2?1:-1
    }getBaseTargetFromProps(e,t){
    let n=e.style;
    return n?n[t]:void 0
    }removeValueFromRenderState(e,{vars:t,style:n}){
    delete t[e],delete n[e]
    }handleChildMotionValue(){
    this.childSubscription&&(this.childSubscription(),delete this.childSubscription);
    let{children:e}=this.props;
    Z(e)&&(this.childSubscription=e.on(`change`,e=>{
      this.current&&(this.current.textContent=`${e}`)
      }))
    }
},Xa=class{
  constructor(e){
    this.isMounted=!1,this.node=e
    }update(){
    }
};
function Za({top:e,left:t,right:n,bottom:r}){
  return{x:{min:t,max:n},y:{min:e,max:r}}
  }
function Qa(e,t){
  if(!t)
  return e;
  let n=t({x:e.left,y:e.top}),r=t({x:e.right,y:e.bottom});
  return{top:n.y,left:n.x,bottom:r.y,right:r.x}
  }
function $a(e,t){
  return Za(Qa(e.getBoundingClientRect(),t))
  }
var eo={x:`translateX`,y:`translateY`,z:`translateZ`,transformPerspective:`perspective`},to=gr.length;
function no(e,t,n){
  let r=``,i=!0;
  for(
  let a=0
  ;a<to;a++){
    let o=gr[a],s=e[o];
    if(s===void 0)
    continue;
    let c=!0;
    if(typeof s==`number`)
    c=s===+!!o.startsWith(`scale`);
    else{
      let e=parseFloat(s);
      c=o.startsWith(`scale`)?e===1:e===0
      }
    if(!c||n){
      let e=ca(s,Qi[o]);
      if(!c){
        i=!1;
        let t=eo[o]||o;
        r+=`${t}(${e}) `
        }
      n&&(t[o]=e)
      }
    }
  let a=e.pathRotation;
  return a&&(i=!1,r+=`rotate(${ca(a,Qi.pathRotation)}) `),r=r.trim(),n?r=n(t,i?``:r):i&&(r=`none`),r
  }
function ro(e,t,n){
  let{style:r,vars:i,transformOrigin:a}=e,o=!1,s=!1;
  for(
  let e
   in t){
    let n=t[e];
    if(_r.has(e)){
      o=!0;
      continue
      }else 
    if(Tt(e)){
      i[e]=n;
      continue
      }else{
      let t=ca(n,Qi[e]);
      e.startsWith(`origin`)?(s=!0,a[e]=t):r[e]=t
      }
    }
  if(t.transform||(o||n?r.transform=no(t,e.transform,n):r.transform&&=`none`),s){
    let{originX:e=`50%`,originY:t=`50%`,originZ:n=0}=a;
    r.transformOrigin=`${e} ${t} ${n}`
    }
  }
function io(e,{style:t,vars:n},r,i){
  let a=e.style,o;
  for(o in t)
  a[o]=t[o];
  for(o in i?.applyProjectionStyles(a,r),n)
  a.setProperty(o,n[o])
  }
function ao(e,t){
  return t.max===t.min?0:e/(t.max-t.min)*100
  }
var oo={correct:(e,t)=>{
  if(!t.target)
  return e;
  if(typeof e==`string`)
  if(V.test(e))
  e=parseFloat(e);
  else 
  return e;
  return`${ao(e,t.target.x)}% ${ao(e,t.target.y)}%`
  }},so={correct:(e,{treeScale:t,projectionDelta:n})=>{
  let r=e,i=G.parse(e);
  if(i.length>5)
  return r;
  let a=G.createTransformer(e),o=typeof i[0]==`number`?0:1,s=n.x.scale*t.x,c=n.y.scale*t.y;
  i[0+o]/=s,i[1+o]/=c;
  let l=dn(s,c,.5);
  return typeof i[2+o]==`number`&&(i[2+o]/=l),typeof i[3+o]==`number`&&(i[3+o]/=l),a(i)
  }},co={borderRadius:{...oo,applyTo:[...oa]},borderTopLeftRadius:oo,borderTopRightRadius:oo,borderBottomLeftRadius:oo,borderBottomRightRadius:oo,boxShadow:so};
function lo(e,{layout:t,layoutId:n}){
  return _r.has(e)||e.startsWith(`origin`)||(t||n!==void 0)&&(!!co[e]||e===`opacity`)
  }
function uo(e,t,n){
  let r=e.style,i=t?.style,a={};
  if(!r)
  return a;
  for(
  let t
   in r)
  (Z(r[t])||i&&Z(i[t])||lo(t,e)||n?.getValue(t)?.liveStyle!==void 0)&&(a[t]=r[t]);
  return a
  }
function fo(e){
  return window.getComputedStyle(e)
  }
var po=class extends Ya{
  constructor(){
    super(...arguments),this.type=`html`,this.renderInstance=io
    }mount(e){
    e.style,super.mount(e)
    }readValueFromInstance(e,t){
    if(_r.has(t))
    return this.projection?.isProjecting?fr(t):mr(e,t);
    {
      let n=fo(e),r=(Tt(t)?n.getPropertyValue(t):n[t])||0;
      return typeof r==`string`?r.trim():r
      }
  }measureInstanceViewportBox(e,{transformPagePoint:t}){
    return $a(e,t)
    }build(e,t,n){
    ro(e,t,n.transformTemplate)
    }scrapeMotionValuesFromProps(e,t,n){
    return uo(e,t,n)
    }
},mo={offset:`stroke-dashoffset`,array:`stroke-dasharray`},ho={offset:`strokeDashoffset`,array:`strokeDasharray`};
function go(e,t,n=1,r=0,i=!0){
  e.pathLength=1;
  let a=i?mo:ho;
  e[a.offset]=`${-r}`,e[a.array]=`${t} ${n}`
  }
var _o=[`offsetDistance`,`offsetPath`,`offsetRotate`,`offsetAnchor`];
function vo(e,{attrX:t,attrY:n,attrScale:r,pathLength:i,pathSpacing:a=1,pathOffset:o=0,...s},c,l,u){
  if(ro(e,s,l),c){
    e.style.viewBox&&(e.attrs.viewBox=e.style.viewBox);
    return
    }
  e.attrs=e.style,e.style={};
  let{attrs:d,style:f}=e;
  d.transform&&(f.transform=d.transform,delete d.transform),(f.transform||d.transformOrigin)&&(f.transformOrigin=d.transformOrigin??`50% 50%`,delete d.transformOrigin),f.transform&&(f.transformBox=u?.transformBox??`fill-box`,delete d.transformBox);
  for(
  let e
   of _o)
  d[e]!==void 0&&(f[e]=d[e],delete d[e]);
  t!==void 0&&(d.x=t),n!==void 0&&(d.y=n),r!==void 0&&(d.scale=r),i!==void 0&&go(d,i,a,o,!1)
  }
var yo=new Set([`baseFrequency`,`diffuseConstant`,`kernelMatrix`,`kernelUnitLength`,`keySplines`,`keyTimes`,`limitingConeAngle`,`markerHeight`,`markerWidth`,`numOctaves`,`targetX`,`targetY`,`surfaceScale`,`specularConstant`,`specularExponent`,`stdDeviation`,`tableValues`,`viewBox`,`gradientTransform`,`pathLength`,`startOffset`,`textLength`,`lengthAdjust`]),bo=e=>typeof e==`string`&&e.toLowerCase()===`svg`;
function xo(e,t,n,r){
  io(e,t,void 0,r);
  for(
  let n
   in t.attrs)
  e.setAttribute(yo.has(n)?n:Ni(n),t.attrs[n])
  }
function So(e,t,n){
  let r=uo(e,t,n);
  for(
  let n
   in e)
  if(Z(e[n])||Z(t[n])){
    let t=gr.indexOf(n)===-1?n:`attr`+n.charAt(0).toUpperCase()+n.substring(1);
    r[t]=e[n]
    }
  return r
  }
var Co=class extends Ya{
  constructor(){
    super(...arguments),this.type=`svg`,this.isSVGTag=!1,this.measureInstanceViewportBox=ja
    }getBaseTargetFromProps(e,t){
    return e[t]
    }readValueFromInstance(e,t){
    if(_r.has(t)){
      let e=ea(t);
      return e&&e.default||0
      }
    return t=yo.has(t)?t:Ni(t),e.getAttribute(t)
    }scrapeMotionValuesFromProps(e,t,n){
    return So(e,t,n)
    }build(e,t,n){
    vo(e,t,this.isSVGTag,n.transformTemplate,n.style)
    }renderInstance(e,t,n,r){
    xo(e,t,n,r)
    }mount(e){
    this.isSVGTag=bo(e.tagName),super.mount(e)
    }
},wo=Ia.length;
function To(e){
  if(!e)
  return;
  if(!e.isControllingVariants){
    let t=e.parent&&To(e.parent)||{};
    return e.props.initial!==void 0&&(t.initial=e.props.initial),t
    }
  let t={};
  for(
  let n=0
  ;n<wo;n++){
    let r=Ia[n],i=e.props[r];
    (Pa(i)||i===!1)&&(t[r]=i)
    }
  return t
  }
function Eo(e,t){
  if(!Array.isArray(t))
  return!1;
  let n=t.length;
  if(n!==e.length)
  return!1;
  for(
  let r=0
  ;r<n;r++)
  if(t[r]!==e[r])
  return!1;
  return!0
  }
var Do=[...Fa].reverse(),Oo=Fa.length;
function ko(e){
  return t=>Promise.all(t.map(({animation:t,options:n})=>Bi(e,t,n)))
  }
function Ao(e){
  let t=ko(e),n=Mo(),r=!0,i=!1,a=t=>(n,r)=>{
    let i=X(e,r,t===`exit`?e.presenceContext?.custom:void 0);
    if(i){
      let{transition:e,transitionEnd:t,...r}=i;
      n={...n,...r,...t}
      }
    return n
    };
  function o(n){
    t=n(e)
    }
  function s(o){
    let{props:s}=e,c=To(e.parent)||{},l=[],u=new Set,d={},f=1/0;
    for(
    let t=0
    ;t<Oo;t++){
      let p=Do[t],m=n[p],h=s[p]===void 0?c[p]:s[p],g=Pa(h),_=p===o?m.isActive:null;
      _===!1&&(f=t);
      let v=h===c[p]&&h!==s[p]&&g;
      if(v&&(r||i)&&e.manuallyAnimateOnMount&&(v=!1),m.protectedKeys={...d},!m.isActive&&_===null||!h&&!m.prevProp||Na(h)||typeof h==`boolean`)
      continue;
      if(p===`exit`&&m.isActive&&_!==!0){
        m.prevResolvedValues&&(d={...d,...m.prevResolvedValues});
        continue
        }
      let y=jo(m.prevProp,h),b=y||p===o&&m.isActive&&!v&&g||t>f&&g,x=!1,S=Array.isArray(h)?h:[h],C=S.reduce(a(p),{});
      _===!1&&(C={});
      let{prevResolvedValues:w={}}=m,T={...w,...C},E=t=>{
        b=!0,u.has(t)&&(x=!0,u.delete(t)),m.needsAnimating[t]=!0;
        let n=e.getValue(t);
        n&&(n.liveStyle=!1)
        };
      for(
      let e
       in T){
        let t=C[e],n=w[e];
        if(d.hasOwnProperty(e))
        continue;
        let r=!1;
        r=Di(t)&&Di(n)?!Eo(t,n)||y:t!==n,r?t==null?u.add(e):E(e):t!==void 0&&u.has(e)?E(e):m.protectedKeys[e]=!0
        }
      m.prevProp=h,m.prevResolvedValues=C,m.isActive&&(d={...d,...C}),(r||i)&&e.blockInitialAnimation&&(b=!1);
      let ee=v&&y;
      b&&(!ee||x)&&l.push(...S.map(t=>{
        let n={type:p};
        if(typeof t==`string`&&(r||i)&&!ee&&e.manuallyAnimateOnMount&&e.parent){
          let{parent:r}=e,i=X(r,t);
          if(r.enteringChildren&&i){
            let{delayChildren:t}=i.transition||{};
            n.delay=ai(r.enteringChildren,e,t)
            }
          }
        return{animation:t,options:n}
        }))
      }
    if(u.size){
      let t={};
      if(typeof s.initial!=`boolean`){
        let n=X(e,Array.isArray(s.initial)?s.initial[0]:s.initial);
        n&&n.transition&&(t.transition=n.transition)
        }
      u.forEach(n=>{
        let r=e.getBaseTarget(n),i=e.getValue(n);
        i&&(i.liveStyle=!0),t[n]=r??null
        }),l.push({animation:t})
      }
    let p=!!l.length;
    return r&&(s.initial===!1||s.initial===s.animate)&&!e.manuallyAnimateOnMount&&(p=!1),r=!1,i=!1,p?t(l):Promise.resolve()
    }
  function c(t,r){
    if(n[t].isActive===r)
    return Promise.resolve();
    e.variantChildren?.forEach(e=>e.animationState?.setActive(t,r)),n[t].isActive=r;
    let i=s(t);
    for(
    let e
     in n)
    n[e].protectedKeys={};
    return i
    }
  return{animateChanges:s,setActive:c,setAnimateFunction:o,getState:()=>n,reset:()=>{
    n=Mo(),i=!0
    }}
  }
function jo(e,t){
  return typeof t==`string`?t!==e:Array.isArray(t)?!Eo(t,e):!1
  }
function Q(e=!1){
  return{isActive:e,protectedKeys:{},needsAnimating:{},prevResolvedValues:{}}
  }
function Mo(){
  return{animate:Q(!0),whileInView:Q(),whileHover:Q(),whileTap:Q(),whileDrag:Q(),whileFocus:Q(),exit:Q()}
  }
function No(e,t,n,r={passive:!0}){
  return e.addEventListener(t,n,r),()=>e.removeEventListener(t,n,r)
  }
function Po(e){
  return Z(e)?e.get():e
  }
var Fo=(0,O.createContext)({transformPagePoint:e=>e,isStatic:!1,reducedMotion:`never`});
function Io(e,t){
  if(typeof e==`function`)
  return e(t);
  e!=null&&(e.current=t)
  }
function Lo(...e){
  return t=>{
    let n=!1,r=e.map(e=>{
      let r=Io(e,t);
      return!n&&typeof r==`function`&&(n=!0),r
      });
    if(n)
    return()=>{
      for(
      let t=0
      ;t<r.length;t++){
        let n=r[t];
        typeof n==`function`?n():Io(e[t],null)
        }
      }
    }
  }
function Ro(...e){
  return O.useCallback(Lo(...e),e)
  }
var zo=class extends O.Component{
  getSnapshotBeforeUpdate(e){
    let t=this.props.childRef.current;
    if(la(t)&&e.isPresent&&!this.props.isPresent&&this.props.pop!==!1){
      let e=t.offsetParent,n=la(e)&&e.offsetWidth||0,r=la(e)&&e.offsetHeight||0,i=getComputedStyle(t),a=this.props.sizeRef.current;
      a.height=parseFloat(i.height),a.width=parseFloat(i.width),a.top=t.offsetTop,a.left=t.offsetLeft,a.right=n-a.width-a.left,a.bottom=r-a.height-a.top,a.direction=i.direction
      }
    return null
    }componentDidUpdate(){
    }render(){
    return this.props.children
    }
};
function Bo({children:e,isPresent:t,anchorX:n,anchorY:r,root:i,pop:a}){
  let o=(0,O.useId)(),s=(0,O.useRef)(null),c=(0,O.useRef)({width:0,height:0,top:0,left:0,right:0,bottom:0,direction:`ltr`}),{nonce:l}=(0,O.useContext)(Fo),u=Ro(s,a===!1?void 0:e.props?.ref??e?.ref);
  return(0,O.useInsertionEffect)(()=>{
    let{width:e,height:u,top:d,left:f,right:p,bottom:m,direction:h}=c.current;
    if(t||a===!1||!s.current||!e||!u)
    return;
    let g=h===`rtl`,_=n===`left`?g?`right: ${p}`:`left: ${f}`:g?`left: ${f}`:`right: ${p}`,v=r===`bottom`?`bottom: ${m}`:`top: ${d}`;
    s.current.dataset.motionPopId=o;
    let y=document.createElement(`style`);
    l&&(y.nonce=l);
    let b=i??document.head;
    return b.appendChild(y),y.sheet&&y.sheet.insertRule(`
          [data-motion-pop-id="${o}"] {
            position: absolute !important;
            width: ${e}px !important;
            height: ${u}px !important;
            ${_}px !important;
            ${v}px !important;
          }
        `),()=>{
      s.current?.removeAttribute(`data-motion-pop-id`),b.contains(y)&&b.removeChild(y)
      }
    },[t]),(0,k.jsx)(zo,{isPresent:t,childRef:s,sizeRef:c,pop:a,children:a===!1?e:O.cloneElement(e,{ref:u})})
  }
var Vo=({children:e,initial:t,isPresent:n,onExitComplete:r,custom:i,presenceAffectsLayout:a,mode:o,anchorX:s,anchorY:c,root:l})=>{
  let u=Ne(Ho),d=(0,O.useId)(),f=(0,O.useRef)(n),p=(0,O.useRef)(r);
  Pe(()=>{
    f.current=n,p.current=r
    });
  let m=!0,h=(0,O.useMemo)(()=>(m=!1,{id:d,initial:t,isPresent:n,custom:i,onExitComplete:e=>{
    u.set(e,!0);
    for(
    let e
     of u.values())
    if(!e)
    return;
    r&&r()
    },register:e=>(u.set(e,!1),()=>{
    u.delete(e),!f.current&&!u.size&&p.current?.()
    })}),[n,u,r]);
  return a&&m&&(h={...h}),(0,O.useMemo)(()=>{
    u.forEach((e,t)=>u.set(t,!1))
    },[n]),O.useEffect(()=>{
    !n&&!u.size&&r&&r()
    },[n]),e=(0,k.jsx)(Bo,{pop:o===`popLayout`,isPresent:n,anchorX:s,anchorY:c,root:l,children:e}),(0,k.jsx)(Fe.Provider,{value:h,children:e})
  };
function Ho(){
  return new Map
  }
function Uo(e=!0){
  let t=(0,O.useContext)(Fe);
  if(t===null)
  return[!0,null];
  let{isPresent:n,onExitComplete:r,register:i}=t,a=(0,O.useId)();
  (0,O.useEffect)(()=>{
    if(e)
    return i(a)
    },[e]);
  let o=(0,O.useCallback)(()=>e&&r&&r(a),[a,r,e]);
  return!n&&r?[!1,o]:[!0]
  }
var Wo=e=>e.key||``;
function Go(e){
  let t=[];
  return O.Children.forEach(e,e=>{
    (0,O.isValidElement)(e)&&t.push(e)
    }),t
  }
var Ko=({children:e,custom:t,initial:n=!0,onExitComplete:r,presenceAffectsLayout:i=!0,mode:a=`sync`,propagate:o=!1,anchorX:s=`left`,anchorY:c=`top`,root:l})=>{
  let[u,d]=Uo(o),f=(0,O.useMemo)(()=>Go(e),[e]),p=o&&!u?[]:f.map(Wo),m=(0,O.useRef)(!0),h=(0,O.useRef)(f),g=Ne(()=>new Map),_=(0,O.useRef)(new Set),[v,y]=(0,O.useState)(f),[b,x]=(0,O.useState)(f);
  Pe(()=>{
    m.current=!1,h.current=f;
    for(
    let e=0
    ;e<b.length;e++){
      let t=Wo(b[e]);
      p.includes(t)?(g.delete(t),_.current.delete(t)):g.get(t)!==!0&&g.set(t,!1)
      }
    },[b,p.length,p.join(`-`)]);
  let S=[];
  if(f!==v){
    let e=[...f];
    for(
    let t=0
    ;t<b.length;t++){
      let n=b[t],r=Wo(n);
      p.includes(r)||(e.splice(t,0,n),S.push(n))
      }
    return a===`wait`&&S.length&&(e=S),x(Go(e)),y(f),null
    }
  let{forceRender:C}=(0,O.useContext)(Me);
  return(0,k.jsx)(k.Fragment,{children:b.map(e=>{
    let v=Wo(e),y=o&&!u?!1:f===b||p.includes(v);
    return(0,k.jsx)(Vo,{isPresent:y,initial:!m.current||n?void 0:!1,custom:t,presenceAffectsLayout:i,mode:a,root:l,onExitComplete:y?void 0:()=>{
      if(_.current.has(v))
      return;
      if(g.has(v))
      _.current.add(v),g.set(v,!0);
      else 
      return;
      let e=!0;
      g.forEach(t=>{
        t||(e=!1)
        }),e&&(C?.(),x(h.current),o&&d?.(),r&&r())
      },anchorX:s,anchorY:c,children:e},v)
    })})
  },qo=(0,O.createContext)({strict:!1}),Jo={animation:[`animate`,`variants`,`whileHover`,`whileTap`,`exit`,`whileInView`,`whileFocus`,`whileDrag`],exit:[`exit`],drag:[`drag`,`dragControls`],focus:[`whileFocus`],hover:[`whileHover`,`onHoverStart`,`onHoverEnd`],tap:[`whileTap`,`onTap`,`onTapStart`,`onTapCancel`],pan:[`onPan`,`onPanStart`,`onPanSessionStart`,`onPanEnd`],inView:[`whileInView`,`onViewportEnter`,`onViewportLeave`],layout:[`layout`,`layoutId`]},Yo=!1;
function Xo(){
  if(Yo)
  return;
  let e={};
  for(
  let t
   in Jo)
  e[t]={isEnabled:e=>Jo[t].some(t=>!!e[t])};
  Ka(e),Yo=!0
  }
function Zo(){
  return Xo(),qa()
  }
function Qo(e){
  let t=Zo();
  for(
  let n
   in e)
  t[n]={...t[n],...e[n]};
  Ka(t)
  }
function $o({children:e,features:t,strict:n=!1}){
  let[,r]=(0,O.useState)(!es(t)),i=(0,O.useRef)(void 0);
  if(!es(t)){
    let{renderer:e,...n}=t;
    i.current=e,Qo(n)
    }
  return(0,O.useEffect)(()=>{
    es(t)&&t().then(({renderer:e,...t})=>{
      Qo(t),i.current=e,r(!0)
      })
    },[]),(0,k.jsx)(qo.Provider,{value:{renderer:i.current,strict:n},children:e})
  }
function es(e){
  return typeof e==`function`
  }
var ts=new Set(`animate.exit.variants.initial.style.values.variants.transition.transformTemplate.custom.inherit.onBeforeLayoutMeasure.onAnimationStart.onAnimationComplete.onUpdate.onDragStart.onDrag.onDragEnd.onMeasureDragConstraints.onDirectionLock.onDragTransitionEnd._dragX._dragY.onHoverStart.onHoverEnd.onViewportEnter.onViewportLeave.globalTapTarget.propagate.ignoreStrict.viewport`.split(`.`));
function ns(e){
  return e.startsWith(`while`)||e.startsWith(`drag`)&&e!==`draggable`||e.startsWith(`layout`)||e.startsWith(`onTap`)||e.startsWith(`onPan`)||e.startsWith(`onLayout`)||ts.has(e)
  }
var rs=t({default:()=>is}),is,as=o((()=>{
  throw is={},Error(`Could not resolve "@emotion/is-prop-valid" imported by "framer-motion". Is it installed?`)
  })),os=e=>!ns(e);
function ss(e){
  typeof e==`function`&&(os=t=>t.startsWith(`on`)?!ns(t):e(t))
  }
try{
  ss((as(),n(rs)).default)
  }catch{
  }
function cs(e,t,n){
  let r={};
  for(
  let i
   in e)
  i===`values`&&typeof e.values==`object`||Z(e[i])||(os(i)||n===!0&&ns(i)||!t&&!ns(i)||e.draggable&&i.startsWith(`onDrag`))&&(r[i]=e[i]);
  return r
  }
var ls=(0,O.createContext)({});
function us(e,t){
  if(La(e)){
    let{initial:t,animate:n}=e;
    return{initial:t===!1||Pa(t)?t:void 0,animate:Pa(n)?n:void 0}
    }
  return e.inherit===!1?{}:t
  }
function ds(e){
  let{initial:t,animate:n}=us(e,(0,O.useContext)(ls));
  return(0,O.useMemo)(()=>({initial:t,animate:n}),[fs(t),fs(n)])
  }
function fs(e){
  return Array.isArray(e)?e.join(` `):e
  }
var ps=()=>({style:{},transform:{},transformOrigin:{},vars:{}});
function ms(e,t,n){
  for(
  let r
   in t)
  !Z(t[r])&&!lo(r,n)&&(e[r]=t[r])
  }
function hs({transformTemplate:e},t){
  return(0,O.useMemo)(()=>{
    let n=ps();
    return ro(n,t,e),Object.assign({},n.vars,n.style)
    },[t])
  }
function gs(e,t){
  let n=e.style||{},r={};
  return ms(r,n,e),Object.assign(r,hs(e,t)),r
  }
function _s(e,t){
  let n={},r=gs(e,t);
  return e.drag&&e.dragListener!==!1&&(n.draggable=!1,r.userSelect=r.WebkitUserSelect=r.WebkitTouchCallout=`none`,r.touchAction=e.drag===!0?`none`:`pan-${e.drag===`x`?`y`:`x`}`),e.tabIndex===void 0&&(e.onTap||e.onTapStart||e.whileTap)&&(n.tabIndex=0),n.style=r,n
  }
var vs=()=>({...ps(),attrs:{}});
function ys(e,t,n,r){
  let i=(0,O.useMemo)(()=>{
    let n=vs();
    return vo(n,t,bo(r),e.transformTemplate,e.style),{...n.attrs,style:{...n.style}}
    },[t]);
  if(e.style){
    let t={};
    ms(t,e.style,e),i.style={...t,...i.style}
    }
  return i
  }
var bs=[`animate`,`circle`,`defs`,`desc`,`ellipse`,`g`,`image`,`line`,`filter`,`marker`,`mask`,`metadata`,`path`,`pattern`,`polygon`,`polyline`,`rect`,`stop`,`switch`,`symbol`,`svg`,`text`,`tspan`,`use`,`view`];
function xs(e){
  return typeof e!=`string`||e.includes(`-`)?!1:!!(bs.indexOf(e)>-1||/[A-Z]/u.test(e))
  }
function Ss(e,t,n,{latestValues:r},i,a=!1,o){
  let s=(o??xs(e)?ys:_s)(t,r,i,e),c=cs(t,typeof e==`string`,a),l=e===O.Fragment?{}:{...c,...s,ref:n},{children:u}=t,d=(0,O.useMemo)(()=>Z(u)?u.get():u,[u]);
  return(0,O.createElement)(e,{...l,children:d})
  }
function Cs({scrapeMotionValuesFromProps:e,createRenderState:t},n,r,i){
  return{latestValues:ws(n,r,i,e),renderState:t()}
  }
function ws(e,t,n,r){
  let i={},a=r(e,{});
  for(
  let e
   in a)
  i[e]=Po(a[e]);
  let{initial:o,animate:s}=e,c=La(e),l=Ra(e);
  t&&l&&!c&&e.inherit!==!1&&(o===void 0&&(o=t.initial),s===void 0&&(s=t.animate));
  let u=n?n.initial===!1:!1;
  u||=o===!1;
  let d=u?s:o;
  if(d&&typeof d!=`boolean`&&!Na(d)){
    let t=Array.isArray(d)?d:[d];
    for(
    let n=0
    ;n<t.length;n++){
      let r=Ti(e,t[n]);
      if(r){
        let{transitionEnd:e,transition:t,...n}=r;
        for(
        let e
         in n){
          let t=n[e];
          if(Array.isArray(t)){
            let e=u?t.length-1:0;
            t=t[e]
            }
          t!==null&&(i[e]=t)
          }
        for(
        let t
         in e)
        i[t]=e[t]
        }
      }
    }
  return i
  }
var Ts=e=>(t,n)=>{
  let r=(0,O.useContext)(ls),i=(0,O.useContext)(Fe),a=()=>Cs(e,t,r,i);
  return n?a():Ne(a)
  },Es=Ts({scrapeMotionValuesFromProps:uo,createRenderState:ps}),Ds=Ts({scrapeMotionValuesFromProps:So,createRenderState:vs}),Os=Symbol.for(`motionComponentSymbol`);
function ks(e,t,n){
  let r=(0,O.useRef)(n);
  (0,O.useInsertionEffect)(()=>{
    r.current=n
    });
  let i=(0,O.useRef)(null);
  return(0,O.useCallback)(n=>{
    n&&e.onMount?.(n),t&&(n?t.mount(n):t.unmount());
    let a=r.current;
    if(typeof a==`function`)
    if(n){
      let e=a(n);
      typeof e==`function`&&(i.current=e)
      }else 
    i.current?(i.current(),i.current=null):a(n);
    else 
    a&&(a.current=n)
    },[t])
  }
var As=(0,O.createContext)({});
function js(e){
  return e&&typeof e==`object`&&Object.prototype.hasOwnProperty.call(e,`current`)
  }
function Ms(e,t,n,r,i,a){
  let{visualElement:o}=(0,O.useContext)(ls),s=(0,O.useContext)(qo),c=(0,O.useContext)(Fe),l=(0,O.useContext)(Fo),u=l.reducedMotion,d=l.skipAnimations,f=(0,O.useRef)(null),p=(0,O.useRef)(!1);
  r||=s.renderer,!f.current&&r&&(f.current=r(e,{visualState:t,parent:o,props:n,presenceContext:c,blockInitialAnimation:c?c.initial===!1:!1,reducedMotionConfig:u,skipAnimations:d,isSVG:a}),p.current&&f.current&&(f.current.manuallyAnimateOnMount=!0));
  let m=f.current,h=(0,O.useContext)(As);
  m&&!m.projection&&i&&(m.type===`html`||m.type===`svg`)&&Ns(f.current,n,i,h);
  let g=(0,O.useRef)(!1);
  (0,O.useInsertionEffect)(()=>{
    m&&g.current&&m.update(n,c)
    });
  let _=n[Pi],v=(0,O.useRef)(!!_&&typeof window<`u`&&!window.MotionHandoffIsComplete?.(_)&&window.MotionHasOptimisedAnimation?.(_));
  return Pe(()=>{
    p.current=!0,m&&(g.current=!0,window.MotionIsMounted=!0,m.updateFeatures(),m.scheduleRenderMicrotask(),v.current&&m.animationState&&m.animationState.animateChanges())
    }),(0,O.useEffect)(()=>{
    m&&(!v.current&&m.animationState&&m.animationState.animateChanges(),v.current&&=(queueMicrotask(()=>{
      window.MotionHandoffMarkAsComplete?.(_)
      }),!1),m.enteringChildren=void 0)
    }),m
  }
function Ns(e,t,n,r){
  let{layoutId:i,layout:a,drag:o,dragConstraints:s,layoutScroll:c,layoutRoot:l,layoutAnchor:u,layoutCrossfade:d}=t;
  e.projection=new n(e.latestValues,t[`data-framer-portal-id`]?void 0:Ps(e.parent)),e.projection.setOptions({layoutId:i,layout:a,alwaysMeasureLayout:!!o||s&&js(s),visualElement:e,animationType:typeof a==`string`?a:`both`,initialPromotionConfig:r,crossfade:d,layoutScroll:c,layoutRoot:l,layoutAnchor:u})
  }
function Ps(e){
  if(e)
  return e.options.allowProjection===!1?Ps(e.parent):e.projection
  }
function Fs(e,{forwardMotionProps:t=!1,type:n}={},r,i){
  r&&Qo(r);
  let a=n?n===`svg`:xs(e),o=a?Ds:Es;
  function s(n,s){
    let c,l={...(0,O.useContext)(Fo),...n,layoutId:Is(n)},{isStatic:u}=l,d=ds(n),f=o(n,u);
    if(!u&&typeof window<`u`){
      Ls(l,r);
      let t=Rs(l);
      c=t.MeasureLayout,d.visualElement=Ms(e,f,l,i,t.ProjectionNode,a)
      }
    return(0,k.jsxs)(ls.Provider,{value:d,children:[c&&d.visualElement?(0,k.jsx)(c,{visualElement:d.visualElement,...l}):null,Ss(e,n,ks(f,d.visualElement,s),f,u,t,a)]})
    }
  s.displayName=`motion.${typeof e==`string`?e:`create(${e.displayName??e.name??``})`}`;
  let c=(0,O.forwardRef)(s);
  return c[Os]=e,c
  }
function Is({layoutId:e}){
  let t=(0,O.useContext)(Me).id;
  return t&&e!==void 0?t+`-`+e:e
  }
function Ls(e,t){
  (0,O.useContext)(qo).strict
  }
function Rs(e){
  let{drag:t,layout:n}=Zo();
  if(!t&&!n)
  return{};
  let r={...t,...n};
  return{MeasureLayout:t?.isEnabled(e)||n?.isEnabled(e)?r.MeasureLayout:void 0,ProjectionNode:r.ProjectionNode}
  }
function zs(e,t){
  if(typeof Proxy>`u`)
  return Fs;
  let n=new Map,r=(n,r)=>Fs(n,r,e,t);
  return new Proxy((e,t)=>r(e,t),{get:(i,a)=>a===`create`?r:(n.has(a)||n.set(a,Fs(a,void 0,e,t)),n.get(a))})
  }
var Bs=zs(),Vs=(e,t)=>t.isSVG??xs(e)?new Co(t):new po(t,{allowProjection:e!==O.Fragment}),Hs=class extends Xa{
  constructor(e){
    super(e),e.animationState||=Ao(e)
    }updateAnimationControlsSubscription(){
    let{animate:e}=this.node.getProps();
    Na(e)&&(this.unmountControls=e.subscribe(this.node))
    }mount(){
    this.updateAnimationControlsSubscription()
    }update(){
    let{animate:e}=this.node.getProps(),{animate:t}=this.node.prevProps||{};
    e!==t&&this.updateAnimationControlsSubscription()
    }unmount(){
    this.node.animationState.reset(),this.unmountControls?.()
    }
},Us=0,Ws={animation:{Feature:Hs},exit:{Feature:class extends Xa{
  constructor(){
    super(...arguments),this.id=Us++,this.isExitComplete=!1
    }update(){
    if(!this.node.presenceContext)
    return;
    let{isPresent:e,onExitComplete:t}=this.node.presenceContext,{isPresent:n}=this.node.prevPresenceContext||{};
    if(!this.node.animationState||e===n)
    return;
    if(e&&n===!1){
      if(this.isExitComplete){
        let{initial:e,custom:t}=this.node.getProps();
        if(typeof e==`string`||typeof e==`object`&&e&&!Array.isArray(e)){
          let n=X(this.node,e,t);
          if(n){
            let{transition:e,transitionEnd:t,...r}=n;
            for(
            let e
             in r)
            this.node.getValue(e)?.jump(r[e])
            }
          }
        this.node.animationState.reset(),this.node.animationState.animateChanges()
        }else 
      this.node.animationState.setActive(`exit`,!1);
      this.isExitComplete=!1;
      return
      }
    let r=this.node.animationState.setActive(`exit`,!e);
    t&&!e&&r.then(()=>{
      this.isExitComplete=!0,t(this.id)
      })
    }mount(){
    let{register:e,onExitComplete:t}=this.node.presenceContext||{};
    t&&t(this.id),e&&(this.unmount=e(this.id))
    }unmount(){
    }
}}};
function Gs(e){
  return{point:{x:e.pageX,y:e.pageY}}
  }
function Ks(e,t,n){
  let{props:r}=e;
  e.animationState&&r.whileHover&&e.animationState.setActive(`whileHover`,n===`Start`);
  let i=r[`onHover`+n];
  i&&I.postRender(()=>i(t,Gs(t)))
  }
var qs=class extends Xa{
  mount(){
    let{current:e}=this.node;
    e&&(this.unmount=ga(e,(e,t)=>(Ks(this.node,t,`Start`),e=>Ks(this.node,e,`End`))))
    }unmount(){
    }
},Js=class extends Xa{
  constructor(){
    super(...arguments),this.isActive=!1
    }onFocus(){
    let e=!1;
    try{
      e=this.node.current.matches(`:focus-visible`)
      }catch{
      e=!0
      }
    !e||!this.node.animationState||(this.node.animationState.setActive(`whileFocus`,!0),this.isActive=!0)
    }onBlur(){
    !this.isActive||!this.node.animationState||(this.node.animationState.setActive(`whileFocus`,!1),this.isActive=!1)
    }mount(){
    this.unmount=Ue(No(this.node.current,`focus`,()=>this.onFocus()),No(this.node.current,`blur`,()=>this.onBlur()))
    }unmount(){
    }
};
function Ys(e,t,n){
  let{props:r}=e;
  if(e.current instanceof HTMLButtonElement&&e.current.disabled)
  return;
  e.animationState&&r.whileTap&&e.animationState.setActive(`whileTap`,n===`Start`);
  let i=r[`onTap`+(n===`End`?``:n)];
  i&&I.postRender(()=>i(t,Gs(t)))
  }
var Xs=class extends Xa{
  mount(){
    let{current:e}=this.node;
    if(!e)
    return;
    let{globalTapTarget:t,propagate:n}=this.node.props;
    this.unmount=Da(e,(e,t)=>(Ys(this.node,t,`Start`),(e,{success:t})=>Ys(this.node,e,t?`End`:`Cancel`)),{useGlobalTarget:t,stopPropagation:n?.tap===!1})
    }unmount(){
    }
},Zs=new WeakMap,Qs=new WeakMap,$s=e=>{
  let t=Zs.get(e.target);
  t&&t(e)
  },ec=e=>{
  e.forEach($s)
  };
function tc({root:e,...t}){
  let n=e||document;
  Qs.has(n)||Qs.set(n,{});
  let r=Qs.get(n),i=JSON.stringify(t);
  return r[i]||(r[i]=new IntersectionObserver(ec,{root:e,...t})),r[i]
  }
function nc(e,t,n){
  let r=tc(t);
  return Zs.set(e,n),r.observe(e),()=>{
    Zs.delete(e),r.unobserve(e)
    }
  }
var rc={some:0,all:1},ic=class extends Xa{
  constructor(){
    super(...arguments),this.hasEnteredView=!1,this.isInView=!1
    }startObserver(){
    this.stopObserver?.();
    let{viewport:e={}}=this.node.getProps(),{root:t,margin:n,amount:r=`some`,once:i}=e,a={root:t?t.current:void 0,rootMargin:n,threshold:typeof r==`number`?r:rc[r]},o=e=>{
      let{isIntersecting:t}=e;
      if(this.isInView===t||(this.isInView=t,i&&!t&&this.hasEnteredView))
      return;
      t&&(this.hasEnteredView=!0),this.node.animationState&&this.node.animationState.setActive(`whileInView`,t);
      let{onViewportEnter:n,onViewportLeave:r}=this.node.getProps(),a=t?n:r;
      a&&a(e)
      };
    this.stopObserver=nc(this.node.current,a,o)
    }mount(){
    this.startObserver()
    }update(){
    if(typeof IntersectionObserver>`u`)
    return;
    let{props:e,prevProps:t}=this.node;
    [`amount`,`margin`,`root`].some(ac(e,t))&&this.startObserver()
    }unmount(){
    this.stopObserver?.(),this.hasEnteredView=!1,this.isInView=!1
    }
};
function ac({viewport:e={}},{viewport:t={}}={}){
  return n=>e[n]!==t[n]
  }
var oc={inView:{Feature:ic},tap:{Feature:Xs},focus:{Feature:Js},hover:{Feature:qs}},sc={renderer:Vs,...Ws,...oc},cc=Bs;
function lc({children:e}){
  return(0,k.jsx)($o,{features:sc,strict:!0,children:e})
  }
var uc=`https://promos.reading.sh/firecrawl`;
function dc({label:e=`Powered by`}){
  return(0,k.jsxs)(`a`,{href:uc,target:`_blank`,rel:`noreferrer sponsored`,"aria-label":`${e} Firecrawl. Use it for free.`,className:`section-promo-badge section-promo-badge-firecrawl border-firecrawl/25 to-firecrawl-soft hover:border-firecrawl/35 mx-auto inline-flex max-w-full flex-wrap items-center justify-center gap-3 rounded-full border bg-linear-to-b from-white px-4 py-3 text-center shadow-sm transition hover:-translate-y-0.5 hover:shadow-md dark:shadow-none dark:hover:shadow-none`,children:[(0,k.jsx)(`span`,{className:`text-[0.62rem] leading-none font-semibold tracking-[0.22em] text-[color:var(--color-muted)] uppercase`,children:e}),(0,k.jsx)(l,{src:`/firecrawl-wordmark.svg`,alt:``,width:172,height:40,"aria-hidden":`true`,className:`h-7 w-auto dark:hidden`}),(0,k.jsx)(l,{src:`/firecrawl-wordmark-dark.svg`,alt:``,width:172,height:40,"aria-hidden":`true`,className:`hidden h-7 w-auto dark:block`}),(0,k.jsx)(`span`,{"aria-hidden":`true`,className:`hidden h-4 w-px bg-neutral-950/10 sm:block dark:bg-white/15`}),(0,k.jsx)(`span`,{className:`text-accent-deep text-[0.76rem] leading-none font-medium tracking-[0.01em]`,children:`Use it for free`})]})
  }
var fc=`x-sulat-news-refresh-intent`,pc=class extends Error{
  status;details;constructor(e,t,n){
    super(e),this.status=t,this.details=n,this.name=`BrowserModelNewsError`
    }
};
async function mc(e,t){
  let n=await S(e);
  if(e.ok){
    let e=t(n);
    if(e!==null)
    return e;
    throw new pc(`Model news service returned invalid data.`,502)
    }
  let r=te(n);
  throw new pc(r.message??`Model news request failed.`,r.status??e.status,r.details)
  }
async function $(e,t,n){
  return mc(await fetch(e,{...n,headers:{accept:`application/json`,...n?.method&&n.method!==`GET`?h():{},...n?.headers??{}}}).catch(e=>{
    throw new pc(e instanceof Error?e.message:`Unable to reach the news service.`,503)
    }),t)
  }
function hc(e,t){
  return!ne(e)||!Array.isArray(e.items)||!e.items.every(t)||typeof e.totalItems!=`number`?null:e
  }
function gc(e){
  return ne(e)&&typeof e.id==`string`&&E(e.subjectType)&&E(e.subjectKey)&&typeof e.providerKey==`string`&&typeof e.providerSlug==`string`&&typeof e.providerName==`string`&&ne(e.providerLogo)&&E(e.providerLogo.url)&&typeof e.providerLogo.isDefault==`boolean`&&E(e.modelKey)&&E(e.modelSlug)&&E(e.modelName)&&E(e.sourceName)&&E(e.sourceHost)&&E(e.searchProvider)&&E(e.articleKind)&&typeof e.isOfficial==`boolean`&&typeof e.title==`string`&&E(e.summary)&&(e.summaryParagraphs===null||x(e.summaryParagraphs))&&typeof e.url==`string`&&E(e.publishedAt)&&E(e.firstSeenAt)&&E(e.lastSeenAt)
  }
function _c(e){
  return ne(e)&&typeof e.id==`string`&&E(e.subjectType)&&E(e.subjectKey)&&typeof e.providerKey==`string`&&typeof e.providerSlug==`string`&&typeof e.providerName==`string`&&E(e.modelKey)&&E(e.modelSlug)&&E(e.modelName)&&typeof e.source==`string`&&typeof e.status==`string`&&E(e.requestedAt)&&E(e.startedAt)&&E(e.finishedAt)&&b(e.itemsUpserted)&&b(e.totalItems)&&E(e.errorMessage)
  }
function vc(e){
  return hc(e,gc)
  }
function yc(e){
  return hc(e,_c)
  }
function bc(e){
  return _c(e)?e:null
  }
function xc(e){
  return!ne(e)||typeof e.id!=`string`||typeof e.status!=`string`||typeof e.pollUrl!=`string`||typeof e.source!=`string`||E(e.subjectType)===!1||E(e.subjectKey)===!1||E(e.modelSlug)===!1||E(e.modelName)===!1||E(e.providerSlug)===!1||typeof e.providerName!=`string`||E(e.requestedAt)===!1?null:e
  }
function Sc(e){
  return $(`/_catalog/models/${encodeURIComponent(e)}/news`,vc)
  }
function Cc(e){
  return $(`/_catalog/providers/${encodeURIComponent(e)}/news`,vc)
  }
function wc(e){
  return $(`/_catalog/models/${encodeURIComponent(e)}/news-refreshes`,yc)
  }
function Tc(e){
  return $(`/_catalog/providers/${encodeURIComponent(e)}/news-refreshes`,yc)
  }
function Ec(e){
  return $(`/_catalog/news-refreshes/${encodeURIComponent(e)}`,bc)
  }
function Dc(e){
  return $(`/_catalog/models/${encodeURIComponent(e)}/news-refreshes`,xc,{method:`POST`,cache:`no-store`,headers:{[fc]:`manual`}})
  }
function Oc(e){
  return $(`/_catalog/providers/${encodeURIComponent(e)}/news-refreshes`,xc,{method:`POST`,cache:`no-store`,headers:{[fc]:`manual`}})
  }
function kc(e){
  if(!e)
  return 0;
  let t=new Date(e).valueOf();
  return Number.isFinite(t)?t:0
  }
function Ac(e){
  return e.isOfficial&&e.articleKind?.trim().toLowerCase()===`announcement`
  }
function jc(e,t){
  return kc(t.publishedAt)-kc(e.publishedAt)||kc(t.firstSeenAt)-kc(e.firstSeenAt)
  }
function Mc(e){
  return e.map((e,t)=>({article:e,index:t})).sort((e,t)=>{
    let n=Ac(e.article),r=Ac(t.article);
    return n===r?n&&r&&jc(e.article,t.article)||e.index-t.index:n?-1:1
    }).map(({article:e})=>e)
  }
var Nc=new Set([`queued`,`processing`]),Pc=300*1e3;
function Fc(e){
  if(!e)
  return null;
  let t=Date.parse(e);
  return Number.isFinite(t)?t:null
  }
function Ic(e){
  return e?Nc.has(e.status):!1
  }
function Lc(e,t=Date.now()){
  if(!Ic(e))
  return!1;
  let n=Fc(e?.startedAt??e?.requestedAt);
  return n!==null&&t-n>=Pc
  }
function Rc(e,t=Date.now()){
  return Ic(e)&&!Lc(e,t)
  }
function zc(e){
  return{id:e.id,subjectType:e.subjectType,subjectKey:e.subjectKey,providerKey:``,providerSlug:e.providerSlug??``,providerName:e.providerName,modelKey:null,modelSlug:e.modelSlug,modelName:e.modelName,source:e.source,status:e.status,requestedAt:e.requestedAt,startedAt:null,finishedAt:null,itemsUpserted:null,totalItems:null,errorMessage:null}
  }
function Bc(e,t){
  return e===`provider`?D.providerNews(t):D.modelNews(t)
  }
function Vc(e,t){
  return e===`provider`?D.providerNewsRefreshes(t):D.modelNewsRefreshes(t)
  }
function Hc(e,t){
  return e===`provider`?Cc(t):Sc(t)
  }
function Uc(e,t){
  return e===`provider`?Tc(t):wc(t)
  }
function Wc(e,t){
  return e===`provider`?Oc(t):Dc(t)
  }
function Gc(e){
  if(!e)
  return 0;
  let t=new Date(e).valueOf();
  return Number.isFinite(t)?t:0
  }
function Kc(e,t){
  let n=e?[...e.items]:[],r=n.findIndex(e=>e.id===t.id);
  return r>=0?n[r]=t:n.unshift(t),n.sort((e,t)=>Gc(t.requestedAt)-Gc(e.requestedAt)),{items:n,totalItems:Math.max(e?.totalItems??0,n.length)}
  }
function qc({id:e,status:t,finishedAt:n,totalItems:r}){
  return[e,t,n??``,r??``].join(`:`)
  }
function Jc(e){
  let t=e?.items[0];
  return t&&!Rc(t)?qc(t):null
  }
function Yc(e){
  return e&&Ic(e)?e.id:null
  }
function Xc({currentRefresh:e,isRefreshStatusFetching:t,isRequestPending:n}){
  return n||Rc(e)||t&&!Lc(e)
  }
function Zc({articleCount:e,currentRefresh:t,showSkeleton:n,showUnavailable:r}){
  return e===0&&!n&&!r&&!Rc(t)&&!Lc(t)
  }
function Qc({articleCount:e,currentRefresh:t,showSkeleton:n,showUnavailable:r}){
  return e===0&&!n&&!r&&Lc(t)
  }
function $c({hasSearched:e,subjectName:t,subjectType:n}){
  return e?n===`model`?`We haven't found any news about ${t} yet. New models can take a few days to get coverage, so check back soon or look again now.`:`We haven't found any news about ${t} yet. Check back soon or look again now.`:`We haven't checked for news about ${t} yet. Fetch the latest news to see it here.`
  }
function el({subjectType:e,subjectSlug:t,subjectName:n,initialNews:r,initialRefreshes:i}){
  let a=g(),o=(0,O.useRef)(Jc(i)),[s,c]=(0,O.useState)(null),l=!!r?.items.length,u=(0,O.useMemo)(()=>Bc(e,t),[t,e]),d=(0,O.useMemo)(()=>Vc(e,t),[t,e]),f=T({queryKey:d,queryFn:()=>Uc(e,t),initialData:i??void 0}),p=de({mutationFn:()=>Wc(e,t),onSuccess:e=>{
    let t=zc(e);
    a.setQueryData(D.modelNewsRefresh(t.id),t),a.setQueryData(d,e=>Kc(e,t)),o.current=null
    },onError:()=>{
    a.invalidateQueries({queryKey:u}),a.invalidateQueries({queryKey:d})
    }}),m=f.data,h=m?.items[0]??null,_=(m?.items.length??0)>0,v=l||_,y=T({queryKey:u,queryFn:()=>Hc(e,t),initialData:r??void 0,enabled:v}),b=y.data,x=Mc(b?.items??[]),S=Yc(h),w=T({queryKey:D.modelNewsRefresh(S??`__inactive__`),queryFn:()=>{
    if(!S)
    throw Error(`No active news refresh is available.`);
    return Ec(S)
    },enabled:S!==null,initialData:S?h??void 0:void 0,refetchInterval:e=>{
    let t=e.state.data;
    return!t||!Ic(t)?!1:Rc(t)?3e3:3e4
    }}),E=S?w.data??h:h,ee=!!m&&(!v||!!b),te=x.length===0&&!E&&((f.isPending||f.isFetching)&&!m||v&&(y.isPending||y.isFetching)&&!b)&&!y.isError&&!f.isError,ne=x.length===0&&!E&&!_&&!y.isError&&!f.isError&&(!ee||f.isFetching||v&&y.isFetching);
  (0,O.useEffect)(()=>{
    E&&a.setQueryData(d,e=>Kc(e,E))
    },[E,a,d]),(0,O.useEffect)(()=>{
    if(!E||Rc(E))
    return;
    let e=qc(E);
    o.current!==e&&(o.current=e,a.invalidateQueries({queryKey:u}),a.invalidateQueries({queryKey:d}))
    },[E,a,u,d]);
  let re=p.error instanceof pc?p.error.message:null,ie=y.error instanceof pc?y.error.message:f.error instanceof pc?f.error.message:null,ue=Xc({currentRefresh:E,isRefreshStatusFetching:w.isFetching,isRequestPending:p.isPending}),fe=x.length===0&&(te||ue||ne),pe=x.length===0&&!fe&&!E&&(y.isError&&!b||f.isError&&!m),me=Zc({articleCount:x.length,currentRefresh:E,showSkeleton:fe,showUnavailable:pe}),he=Qc({articleCount:x.length,currentRefresh:E,showSkeleton:fe,showUnavailable:pe}),ge=x.length>0;
  return(0,k.jsxs)(`section`,{className:`surface-panel grid gap-6 rounded-[2rem] p-5 sm:p-6 ${ge?`mt-16`:``}`,children:[ge?(0,k.jsx)(`div`,{className:`-mt-14 mb-1 flex justify-center`,children:(0,k.jsx)(dc,{label:`News search by`})}):null,(0,k.jsx)(C,{title:`Latest news about ${n}`}),x.length>0?(0,k.jsx)(`div`,{className:`overflow-hidden rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70`,children:(0,k.jsx)(`div`,{className:`divider-list`,children:x.map(e=>(0,k.jsx)(le,{article:e,onOpen:c},e.id))})}):null,fe?(0,k.jsx)(ce,{}):null,me?(0,k.jsx)(oe,{message:$c({hasSearched:E!==null,subjectName:n,subjectType:e}),detail:re,onRequest:()=>p.mutate()}):null,pe?(0,k.jsx)(ae,{title:`We couldn't load the news`,body:`Something went wrong while loading news for this page. Reload the page to try again.`,detail:ie}):null,he?(0,k.jsx)(ae,{title:`Finding news is taking longer than usual`,body:`The latest search is still waiting to run. Check back shortly for new articles.`,detail:re}):null,s?(0,k.jsx)(se,{article:s,onClose:()=>c(null)}):null]})
  }
function tl({modelSlug:e,modelName:t,initialNews:n,initialRefreshes:r}){
  return(0,k.jsx)(el,{subjectType:`model`,subjectSlug:e,subjectName:t,initialNews:n,initialRefreshes:r})
  }
function nl({providerSlug:e,providerName:t,initialNews:n,initialRefreshes:r}){
  return(0,k.jsx)(el,{subjectType:`provider`,subjectSlug:e,subjectName:t,initialNews:n,initialRefreshes:r})
  }
var rl=[{fileName:`Order.php`,id:`nullability`,lines:[{at:0,content:`Refactor receipt selection.`,id:`prompt`,prefix:`›`,tone:`prompt`,until:6},{at:1,content:`public function receipt(): ?Receipt`,id:`draft-signature`,prefix:`LLM`,tone:`code`,until:6},{at:2,content:`$receipt = $this->invoice ?? $this->quote ?? null;`,id:`draft-fallback`,prefix:`LLM`,tone:`code`,until:6},{at:3,content:`return $receipt;`,id:`draft-return`,prefix:`LLM`,tone:`code`,until:6},{at:4,content:`nullable return + hidden fallback policy`,id:`detection`,prefix:`⚠`,tone:`warning`,until:9},{at:5,content:`$maintainable-code intercepted the response`,id:`skill`,prefix:`◆`,tone:`monitor`,until:10},{at:6,content:`name policy · return Receipt · fail explicitly`,id:`guidance`,prefix:`→`,tone:`monitor`,until:10},{at:7,content:`public function receipt(): Receipt`,id:`revision-signature`,prefix:`LLM↻`,tone:`agent`},{at:8,content:`return $this->invoice ?? $this->quote`,id:`revision-fallback`,prefix:`LLM↻`,tone:`agent`},{at:9,content:`?? throw ReceiptMissing::for($this->id);`,id:`revision-failure`,prefix:`LLM↻`,tone:`agent`},{at:11,content:`phpstan · 0 errors`,id:`analysis`,prefix:`✓`,tone:`check`},{at:12,content:`pest · 18 passed`,id:`tests`,prefix:`✓`,tone:`check`}]},{fileName:`CreateInvoice.php`,id:`boundary-types`,lines:[{at:0,content:`Create an invoice from webhook JSON.`,id:`prompt`,prefix:`›`,tone:`prompt`,until:6},{at:1,content:`function create(array $payload): array`,id:`draft-signature`,prefix:`LLM`,tone:`code`,until:6},{at:2,content:`$total = $payload['total'];`,id:`draft-total`,prefix:`LLM`,tone:`code`,until:6},{at:3,content:`return ['id' => Str::uuid(), 'total' => $total];`,id:`draft-return`,prefix:`LLM`,tone:`code`,until:6},{at:4,content:`raw boundary array + ambiguous return shape`,id:`detection`,prefix:`⚠`,tone:`warning`,until:9},{at:5,content:`$maintainable-code intercepted the response`,id:`skill`,prefix:`◆`,tone:`monitor`,until:10},{at:6,content:`parse once · typed DTO · return Invoice`,id:`guidance`,prefix:`→`,tone:`monitor`,until:10},{at:7,content:`public function create(InvoiceInput $input): Invoice`,id:`revision-signature`,prefix:`LLM↻`,tone:`agent`},{at:8,content:`return Invoice::issue(`,id:`revision-start`,prefix:`LLM↻`,tone:`agent`},{at:9,content:`$input->customerId, $input->total);`,id:`revision-end`,prefix:`LLM↻`,tone:`agent`},{at:11,content:`phpstan level 9 · clean`,id:`analysis`,prefix:`✓`,tone:`check`},{at:12,content:`invalid payload rejected at boundary`,id:`tests`,prefix:`✓`,tone:`check`}]},{fileName:`SendReceiptJob.php`,id:`retry-safety`,lines:[{at:0,content:`Retry receipt delivery after a timeout.`,id:`prompt`,prefix:`›`,tone:`prompt`,until:6},{at:1,content:`catch (Throwable) {`,id:`draft-catch`,prefix:`LLM`,tone:`code`,until:6},{at:2,content:`$this->release(30);`,id:`draft-release`,prefix:`LLM`,tone:`code`,until:6},{at:3,content:`}`,id:`draft-end`,prefix:`LLM`,tone:`code`,until:6},{at:4,content:`unbounded retry + duplicate send risk`,id:`detection`,prefix:`⚠`,tone:`warning`,until:9},{at:5,content:`$maintainable-code intercepted the response`,id:`skill`,prefix:`◆`,tone:`monitor`,until:10},{at:6,content:`stable work key · capped backoff · preserve cause`,id:`guidance`,prefix:`→`,tone:`monitor`,until:10},{at:7,content:`$mailer->send($receipt, key: "receipt:{$order->id}");`,id:`revision-send`,prefix:`LLM↻`,tone:`agent`},{at:8,content:`public function retryPolicy(): RetryPolicy`,id:`revision-signature`,prefix:`LLM↻`,tone:`agent`},{at:9,content:`return RetryPolicy::capped(10, 30, 90);`,id:`revision-policy`,prefix:`LLM↻`,tone:`agent`},{at:11,content:`replay test · no duplicate email`,id:`tests`,prefix:`✓`,tone:`check`},{at:12,content:`timeout cause remains inspectable`,id:`failure`,prefix:`✓`,tone:`check`}]},{fileName:`BillingDecision.php`,id:`domain-states`,lines:[{at:0,content:`Decide whether a subscription can be billed.`,id:`prompt`,prefix:`›`,tone:`prompt`,until:6},{at:1,content:`if ($status === 'active') {`,id:`draft-condition`,prefix:`LLM`,tone:`code`,until:6},{at:2,content:`return true;`,id:`draft-active`,prefix:`LLM`,tone:`code`,until:6},{at:3,content:`} return false;`,id:`draft-fallback`,prefix:`LLM`,tone:`code`,until:6},{at:4,content:`magic string + boolean erases billing reason`,id:`detection`,prefix:`⚠`,tone:`warning`,until:9},{at:5,content:`$maintainable-code intercepted the response`,id:`skill`,prefix:`◆`,tone:`monitor`,until:10},{at:6,content:`enum state · exhaustive match · typed decision`,id:`guidance`,prefix:`→`,tone:`monitor`,until:10},{at:7,content:`return match ($subscription->status) {`,id:`revision-match`,prefix:`LLM↻`,tone:`agent`},{at:8,content:`Status::Active => BillingDecision::charge(),`,id:`revision-active`,prefix:`LLM↻`,tone:`agent`},{at:9,content:`Status::Paused, Status::Canceled => BillingDecision::skip(),`,id:`revision-inactive`,prefix:`LLM↻`,tone:`agent`},{at:11,content:`exhaustive enum handling`,id:`analysis`,prefix:`✓`,tone:`check`},{at:12,content:`pest · every state covered`,id:`tests`,prefix:`✓`,tone:`check`}]}],il=700,al=1050,ol={agent:`text-violet-200`,check:`text-emerald-300`,code:`text-white/65`,monitor:`text-amber-200`,prompt:`text-white`,warning:`text-red-300`};
function sl({exampleIndex:e}){
  let t=rl[e];
  return(0,k.jsxs)(`div`,{className:`grid grid-cols-[1fr_auto_1fr] items-center border-b border-white/10 bg-white/5 px-3 py-2.5 sm:px-4`,children:[(0,k.jsxs)(`div`,{"aria-hidden":`true`,className:`flex gap-1.5`,children:[(0,k.jsx)(`span`,{className:`size-2.5 rounded-full bg-red-400/90`}),(0,k.jsx)(`span`,{className:`size-2.5 rounded-full bg-amber-300/90`}),(0,k.jsx)(`span`,{className:`size-2.5 rounded-full bg-emerald-400/90`})]}),(0,k.jsxs)(`p`,{className:`font-mono text-[0.6875rem]/4 text-white/55`,children:[`agent · `,t.fileName]}),(0,k.jsxs)(`p`,{className:`justify-self-end font-mono text-[0.625rem]/3 text-white/35 tabular-nums`,children:[e+1,`/`,rl.length]})]})
  }
function cl({playback:e,reducedMotion:t}){
  let n=rl[e.exampleIndex];
  return(0,k.jsx)(`div`,{className:`relative grid min-h-64 content-end overflow-hidden p-3 sm:min-h-56 sm:p-4`,children:(0,k.jsxs)(`div`,{"aria-live":`off`,className:`grid gap-1.5 font-mono text-[0.6875rem]/5 sm:text-xs/5`,children:[(0,k.jsx)(Ko,{initial:!1,children:n.lines.filter(t=>t.at<=e.tick&&(t.until===void 0||e.tick<=t.until)).map(e=>(0,k.jsxs)(cc.p,{animate:{opacity:1,x:0},className:[`grid grid-cols-[2.5rem_minmax(0,1fr)] gap-2`,ol[e.tone]].join(` `),exit:t?{opacity:0}:{opacity:0,x:-10},initial:!t&&{opacity:0,x:10},transition:{duration:t?0:.22},children:[(0,k.jsx)(`span`,{className:`text-right text-white/35`,children:e.prefix}),(0,k.jsx)(`span`,{className:`min-w-0 break-words`,children:e.content})]},`${n.id}-${e.id}`))}),(0,k.jsxs)(`p`,{"aria-hidden":`true`,className:`grid grid-cols-[2.5rem_minmax(0,1fr)] gap-2 text-white/35`,children:[(0,k.jsx)(`span`,{className:`text-right`,children:`·`}),(0,k.jsx)(cc.span,{animate:t?void 0:{opacity:[1,0,1]},className:`inline-block h-3.5 w-1.5 bg-white/55`,transition:{duration:.8,repeat:1/0}})]})]})})
  }
function ll({reducedMotion:e}){
  let[t,n]=(0,O.useState)({exampleIndex:0,tick:0});
  return(0,O.useEffect)(()=>{
    let t=e?al:il,r=window.setInterval(()=>{
      n(e=>{
        if(e.tick<13)
        return{...e,tick:e.tick+1};
        let t=rl.length-1;
        return{exampleIndex:e.exampleIndex<t?e.exampleIndex+1:0,tick:0}
        })
      },t);
    return()=>window.clearInterval(r)
    },[e]),(0,k.jsxs)(`div`,{className:`overflow-hidden rounded-xl bg-neutral-950 text-white shadow-2xl ring-1 shadow-neutral-950/20 ring-white/10 dark:shadow-none`,children:[(0,k.jsx)(sl,{exampleIndex:t.exampleIndex}),(0,k.jsx)(cl,{playback:t,reducedMotion:e})]})
  }
function ul(e){
  return(0,k.jsx)(lc,{children:(0,k.jsx)(ll,{...e})})
  }
var dl=`https://www.skills.sh/jpcaparas/skills`,fl=`https://github.com/jpcaparas/skills`,pl=`group relative isolate inline-flex min-h-12 items-center justify-center overflow-hidden rounded-xl bg-linear-to-b from-white via-neutral-100 to-neutral-300 font-semibold text-neutral-950! shadow-xl shadow-white/15 ring-1 ring-white transition-transform hover:-translate-y-0.5 hover:shadow-2xl hover:shadow-white/25 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white motion-reduce:transition-none motion-reduce:hover:translate-y-0`;
function ml({onClose:e,open:t}){
  let n=ie(),r=(0,O.useId)(),i=(0,O.useId)();
  return t?(0,k.jsx)(re,{ariaDescribedBy:i,ariaLabelledBy:r,className:`items-center justify-center`,onClose:e,panelClassName:`surface-panel mx-auto max-w-3xl rounded-2xl p-4 sm:p-5`,children:(0,k.jsxs)(cc.div,{animate:{opacity:1,scale:1,y:0},className:`grid gap-5`,initial:!n&&{opacity:0,scale:.98,y:16},transition:n?{duration:0}:{duration:.22},children:[(0,k.jsx)(y,{description:`Reusable instructions for coding, reviews, and repeat work.`,descriptionId:i,eyebrow:`Coding agent skills`,onClose:e,title:(0,k.jsx)(k.Fragment,{children:`Give your coding agent better instructions`}),titleId:r}),(0,k.jsx)(`div`,{className:`rounded-xl border border-neutral-950 bg-neutral-950 p-4 text-white dark:border-white/20`,children:(0,k.jsxs)(`div`,{className:`flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between`,children:[(0,k.jsxs)(`div`,{children:[(0,k.jsxs)(`div`,{className:`flex items-center gap-2 font-mono text-sm text-white/60`,children:[(0,k.jsx)(_,{className:`h-2.5 w-auto text-white`}),(0,k.jsx)(`span`,{children:`skills.sh`})]}),(0,k.jsx)(`p`,{className:`pt-3 text-xl/7 font-semibold text-white`,children:`A skill tells your coding agent how to work.`}),(0,k.jsx)(`p`,{className:`max-w-[52ch] pt-1 text-base/7 text-pretty text-white/65 sm:text-sm/6`,children:`Give your agent reusable standards, steps, and tools. It loads them when needed.`})]}),(0,k.jsxs)(`div`,{className:`flex w-full flex-row items-stretch gap-2 text-base sm:w-auto`,children:[(0,k.jsxs)(`a`,{className:[pl,`gap-2 py-2.5 pr-4 pl-3`].join(` `),href:dl,rel:`noreferrer`,target:`_blank`,children:[(0,k.jsx)(`span`,{"aria-hidden":`true`,className:`absolute inset-y-0 -left-1/3 w-1/3 skew-x-[-20deg] bg-linear-to-r from-transparent via-white/90 to-transparent transition-transform duration-500 group-hover:translate-x-[420%] motion-reduce:transition-none`}),(0,k.jsx)(_,{className:`relative h-3.5 w-auto`}),(0,k.jsx)(`span`,{className:`relative`,children:`Browse coding skills`})]}),(0,k.jsxs)(`a`,{"aria-label":`View coding skills source on GitHub`,className:[pl,`size-12 p-0`].join(` `),href:fl,rel:`noreferrer`,target:`_blank`,title:`View source on GitHub`,children:[(0,k.jsx)(`span`,{"aria-hidden":`true`,className:`absolute inset-y-0 -left-1/3 w-1/3 skew-x-[-20deg] bg-linear-to-r from-transparent via-white/90 to-transparent transition-transform duration-500 group-hover:translate-x-[420%] motion-reduce:transition-none`}),(0,k.jsx)(me,{"aria-hidden":`true`,className:`relative size-4 shrink-0 fill-neutral-950`})]})]})]})}),(0,k.jsx)(ul,{reducedMotion:n})]})}):null
  }
function hl(e){
  return(0,k.jsx)(lc,{children:(0,k.jsx)(ml,{...e})})
  }
var gl=5e3,_l={offers:[{id:`provider-deal`,intervalMs:1e4},{id:`skills`}],slideWidthClass:`w-1/2`,trackWidthClass:`w-[200%]`};
function vl(e,t){
  let n=e.findIndex(e=>e.id===t);
  return n===-1?0:n
  }
function yl(e,t,n){
  return e[(vl(e,t)+n+e.length)%e.length].id
  }
function bl(e){
  return e.intervalMs??gl
  }
var xl=`agent-skills`;
function Sl(...e){
  return e.filter(Boolean).join(` `)
  }
function Cl(e,t){
  switch(e){case`skills`:
  return`FREE coding agent skills from skills.sh`;
  case`provider-deal`:
  return`${t.ctaLabel} from ${t.dealName}`
  }
  }
function wl(e){
  return e?{desktopLabel:`hidden min-w-0 flex-1 text-balance md:block md:max-w-[27rem] md:leading-tight lg:max-w-[31rem]`,icon:`grid h-7 w-7 shrink-0 place-items-center rounded-full border border-[color:var(--color-line)] bg-accent-soft/45 text-[color:var(--color-accent-deep)] shadow-sm dark:shadow-none sm:h-6 sm:w-6`,iconImage:`h-5 w-5 sm:h-4 sm:w-4`,mobileLabel:`min-w-0 flex-1 text-balance break-words leading-tight md:hidden`,singleLabel:`min-w-0 truncate`,slide:`provider-deal-ribbon-synthetic flex shrink-0 items-center gap-2.5 overflow-hidden rounded-tr-[1.95rem] rounded-bl-[1.2rem] border border-[color:var(--color-line-strong)] bg-[color:var(--color-surface)] px-4 py-2.5 font-serif text-[1.02rem]/5 font-semibold text-[color:var(--color-ink)] transition-transform hover:-translate-y-px hover:bg-white motion-reduce:transition-none motion-reduce:hover:translate-y-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/25 sm:px-5 sm:py-3 sm:text-base/5`}:{desktopLabel:`hidden min-w-0 truncate lg:inline`,icon:`grid h-5 w-5 shrink-0 place-items-center rounded-full bg-amber-950/10 text-amber-900 dark:bg-amber-950/20`,iconImage:`h-3.5 w-3.5`,mobileLabel:`min-w-0 truncate lg:hidden`,singleLabel:`min-w-0 truncate`,slide:`flex shrink-0 items-center gap-2 rounded-tr-[1.95rem] rounded-bl-[1.15rem] bg-linear-to-br from-amber-100 via-amber-300 to-accent px-4 py-3 text-sm leading-none font-semibold text-amber-950 transition-transform hover:-translate-y-px hover:brightness-105 motion-reduce:transition-none motion-reduce:hover:translate-y-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-accent/35`}
  }
function Tl({isSyntheticTheme:e,label:t}){
  return e?(0,k.jsx)(k.Fragment,{children:t.split(/(\$10 off|fastest|Kimi K3)/g).map(e=>e===`$10 off`?(0,k.jsx)(`strong`,{className:`synthetic-discount-shine tabular-nums`,children:e},`discount`):e===`fastest`?(0,k.jsx)(`span`,{className:`animated-fastest-underline`,children:e},`fastest`):e===`Kimi K3`?(0,k.jsx)(`strong`,{className:`synthetic-kimi-shine`,children:e},`kimi-k3`):e)}):t
  }
function El({className:e,src:t}){
  let n=t===`/synthetic.svg`?`/synthetic-dark.svg`:null;
  return(0,k.jsxs)(`picture`,{children:[n?(0,k.jsx)(`source`,{media:`(prefers-color-scheme: dark)`,srcSet:n}):null,(0,k.jsx)(`img`,{"aria-hidden":`true`,alt:``,className:e,src:t})]})
  }
function Dl({className:e}){
  return(0,k.jsxs)(`svg`,{"aria-hidden":`true`,className:e,viewBox:`0 0 16 16`,fill:`none`,children:[(0,k.jsx)(`path`,{d:`M2.75 6.25h10.5v6a1 1 0 0 1-1 1H3.75a1 1 0 0 1-1-1v-6Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.35`}),(0,k.jsx)(`path`,{d:`M2.25 6.25h11.5v-1.5a.75.75 0 0 0-.75-.75H3a.75.75 0 0 0-.75.75v1.5ZM8 4v9.25M8 4H5.75a1.25 1.25 0 1 1 1.1-1.85L8 4Zm0 0h2.25a1.25 1.25 0 1 0-1.1-1.85L8 4Z`,stroke:`currentColor`,strokeLinejoin:`round`,strokeWidth:`1.35`})]})
  }
function Ol({deal:e,hasControls:t,isActive:n,slideWidthClass:r}){
  let i=e.desktopCtaLabel?.trim()??``,a=e.theme===`synthetic`,o=wl(a),s=i?i.includes(e.ctaLabel)?i:`${e.ctaLabel}; ${i}`:e.ctaLabel;
  return(0,k.jsxs)(`a`,{"aria-hidden":!n,"aria-label":`${s} from ${e.dealName}`,className:Sl(o.slide,r,t&&`pr-[5.75rem] sm:pr-24`),href:e.affiliateUrl,rel:`noreferrer sponsored`,tabIndex:n?0:-1,target:`_blank`,title:`${e.dealName}: ${e.label}`,children:[(0,k.jsx)(`span`,{className:o.icon,children:e.iconSrc?(0,k.jsx)(El,{className:o.iconImage,src:e.iconSrc}):(0,k.jsx)(Dl,{className:o.iconImage})}),i?(0,k.jsxs)(k.Fragment,{children:[(0,k.jsx)(`span`,{className:o.mobileLabel,children:(0,k.jsx)(Tl,{isSyntheticTheme:a,label:e.ctaLabel})}),(0,k.jsx)(`span`,{className:o.desktopLabel,children:(0,k.jsx)(Tl,{isSyntheticTheme:a,label:i})})]}):(0,k.jsx)(`span`,{className:o.singleLabel,children:(0,k.jsx)(Tl,{isSyntheticTheme:a,label:e.ctaLabel})})]})
  }
function kl({hasControls:e,isActive:t,onOpen:n,slideWidthClass:r}){
  return(0,k.jsxs)(`button`,{"aria-hidden":!t,"aria-label":`FREE coding agent skills from skills.sh (opens a dialog)`,className:Sl(`group relative isolate flex shrink-0 items-center gap-3 overflow-hidden rounded-tr-[1.95rem] rounded-bl-[1.2rem] border border-white/25 bg-linear-to-br from-neutral-500 via-neutral-700 to-neutral-900 px-4 py-2.5 text-left text-[1.02rem]/5 font-medium text-white shadow-lg shadow-neutral-950/15 transition-transform before:absolute before:inset-x-0 before:top-0 before:h-px before:bg-linear-to-r before:from-transparent before:via-white/80 before:to-transparent hover:-translate-y-px hover:brightness-110 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-neutral-700 motion-reduce:transition-none motion-reduce:hover:translate-y-0 sm:px-5 sm:py-3 sm:text-base/5 dark:border-white/25 dark:from-neutral-500 dark:via-neutral-700 dark:to-neutral-900 dark:focus-visible:outline-white`,r,e&&`pr-[5.75rem] sm:pr-24`),onClick:n,tabIndex:t?0:-1,type:`button`,children:[(0,k.jsx)(`span`,{"aria-hidden":`true`,className:`pointer-events-none absolute inset-y-0 left-1/4 w-1/3 -skew-x-12 bg-linear-to-r from-transparent via-white/12 to-transparent`}),(0,k.jsx)(`span`,{className:`relative z-10 grid size-7 shrink-0 place-items-center rounded-md border border-white/35 bg-white text-neutral-950 shadow-sm sm:size-6`,children:(0,k.jsx)(_,{className:`h-3.5 w-auto sm:h-3`})}),(0,k.jsx)(`span`,{className:`relative z-10 min-w-0 flex-1`,children:(0,k.jsxs)(`span`,{className:`flex items-baseline gap-2`,children:[(0,k.jsxs)(`span`,{className:`truncate`,children:[(0,k.jsx)(`strong`,{className:`font-semibold`,children:`FREE`}),` coding agent skills`]}),(0,k.jsx)(`span`,{className:`hidden shrink-0 font-mono text-[0.6875rem] font-normal tracking-[-0.02em] text-white/55 sm:inline`,children:`skills.sh`})]})})]})
  }
function Al({deal:e}){
  let{offers:t,slideWidthClass:n,trackWidthClass:r}=_l,[i,a]=(0,O.useState)(t[0].id),[o,s]=(0,O.useState)(!1),[l,u]=(0,O.useState)(!1),d=ie(),f=ee(e=>e.activeModalId),p=ee(e=>e.openModal),m=ee(e=>e.closeModal),h=(0,O.useRef)(null),g=o||l||f!==null,_=vl(t,i),v=t[_];
  (0,O.useEffect)(()=>{
    if(g||d)
    return;
    let e=window.setTimeout(()=>a(e=>yl(t,e,1)),bl(v));
    return()=>window.clearTimeout(e)
    },[v,g,t,d]);
  function y(e){
    let t=e.relatedTarget;
    h.current&&t&&h.current.contains(t)||u(!1)
    }
  return(0,k.jsxs)(k.Fragment,{children:[(0,k.jsxs)(`div`,{ref:h,"aria-label":`Provider offers`,"aria-roledescription":`carousel`,className:`absolute inset-x-3 top-3 z-40 rounded-tr-[1.95rem] rounded-bl-[1.2rem] shadow-xl shadow-neutral-950/10 sm:inset-x-auto sm:right-3 sm:left-auto sm:w-[min(32rem,calc(100%-1.5rem))] lg:top-px lg:right-px lg:w-[min(34rem,calc(100%-1.5rem))] dark:shadow-none`,onMouseEnter:()=>s(!0),onMouseLeave:()=>s(!1),onFocusCapture:()=>u(!0),onBlurCapture:y,role:`region`,children:[(0,k.jsx)(`div`,{className:`overflow-hidden rounded-tr-[1.95rem] rounded-bl-[1.2rem]`,children:(0,k.jsx)(cc.div,{animate:{x:`${-_*(100/t.length)}%`},className:Sl(`flex transform-gpu`,r),transition:d?{duration:0}:{duration:.4,ease:`easeInOut`},children:t.map(t=>{
    switch(t.id){case`provider-deal`:
    return(0,k.jsx)(Ol,{deal:e,hasControls:d,isActive:v.id===t.id,slideWidthClass:n},t.id);
    case`skills`:
    return(0,k.jsx)(kl,{hasControls:d,isActive:v.id===t.id,onOpen:()=>p(xl),slideWidthClass:n},t.id)
    }
    })})}),d?(0,k.jsxs)(`div`,{className:`absolute top-1/2 right-2 z-10 flex -translate-y-1/2 items-center gap-0.5 rounded-full border border-[color:var(--color-line)] bg-white/85 p-0.5 shadow-sm backdrop-blur dark:bg-neutral-950/75 dark:shadow-none`,children:[(0,k.jsx)(c,{ariaLabel:`Previous offer`,direction:`previous`,onClick:()=>a(e=>yl(t,e,-1))}),(0,k.jsx)(c,{ariaLabel:`Next offer`,direction:`next`,onClick:()=>a(e=>yl(t,e,1))})]}):null,(0,k.jsx)(`div`,{"aria-atomic":`true`,"aria-live":`polite`,className:`sr-only`,children:Cl(v.id,e)})]}),(0,k.jsx)(hl,{onClose:()=>m(xl),open:f===xl},f===xl?`open`:void 0)]})
  }
function jl(e){
  return(0,k.jsx)(lc,{children:(0,k.jsx)(Al,{...e})})
  }
function Ml(e,t=280){
  if(e.length<=t)
  return e;
  let n=e.slice(0,t-1).trimEnd(),r=n.lastIndexOf(` `);
  return`${r>0?n.slice(0,r):n}…`
  }
function Nl({direction:e,onClick:t}){
  return(0,k.jsx)(`button`,{type:`button`,onClick:t,className:`button-quiet h-11 w-11 justify-center rounded-full`,"aria-label":e===`left`?`Scroll recent X posts left`:`Scroll recent X posts right`,children:(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,k.jsx)(`path`,{d:e===`left`?`M10.75 3.5 6.25 8l4.5 4.5`:`M5.25 3.5 9.75 8l-4.5 4.5`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.4`})})})
  }
function Pl(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-3.5 w-3.5`,viewBox:`0 0 24 24`,fill:`none`,children:(0,k.jsx)(`path`,{d:`M7 3.75v2.5M17 3.75v2.5M4.75 9.25h14.5M6.75 6h10.5a2 2 0 0 1 2 2v9.25a2 2 0 0 1-2 2H6.75a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2Z`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.4`})})
  }
function Fl(){
  return()=>{
    }
  }
function Il(){
  return`UTC`
  }
function Ll(){
  return Intl.DateTimeFormat().resolvedOptions().timeZone??`UTC`
  }
function Rl(){
  return!1
  }
function zl(){
  return!0
  }
function Bl(e,t,n){
  let r=new Date(e);
  if(Number.isNaN(r.valueOf()))
  return{label:e,timeZoneLabel:n===`local`?t:`UTC`};
  try{
    let e=new Intl.DateTimeFormat(`en`,{month:`short`,day:`numeric`,year:`numeric`,hour:`numeric`,minute:`2-digit`,timeZone:t}).format(r);
    return n===`utc`?{label:e,timeZoneLabel:`UTC`}:{label:e,timeZoneLabel:t}
    }catch{
    return t===`UTC`?{label:r.toISOString(),timeZoneLabel:`UTC`}:Bl(e,`UTC`,`utc`)
    }
  }
function Vl({value:e}){
  let t=Bl(e,(0,O.useSyncExternalStore)(Fl,Ll,Il),(0,O.useSyncExternalStore)(Fl,zl,Rl)?`local`:`utc`);
  return(0,k.jsxs)(`time`,{dateTime:e,className:`inline-flex items-center gap-2 rounded-full border border-[color:var(--color-line)] bg-white/85 px-3 py-2 text-[0.78rem] font-medium text-[color:var(--color-ink)]`,children:[(0,k.jsx)(`span`,{className:`bg-accent/10 inline-flex h-7 w-7 shrink-0 items-center justify-center rounded-full text-[color:var(--color-accent-deep)]`,children:(0,k.jsx)(Pl,{})}),(0,k.jsxs)(`span`,{className:`min-w-0`,children:[(0,k.jsx)(`span`,{className:`block leading-tight`,children:t.label}),(0,k.jsx)(`span`,{className:`mt-1 block text-[0.68rem] leading-tight text-[color:var(--color-muted)]`,children:t.timeZoneLabel})]})]})
  }
function Hl(){
  return(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`pointer-events-none absolute bottom-1 left-1 h-40 w-40 rotate-[-10deg] text-sky-500/15 sm:bottom-2 sm:left-2 sm:h-44 sm:w-44`,viewBox:`0 0 24 24`,fill:`currentColor`,children:(0,k.jsx)(`path`,{d:`M23.953 4.57a10 10 0 0 1-2.825.775 4.958 4.958 0 0 0 2.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 0 0-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 0 0-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 0 1-2.228-.616v.06a4.923 4.923 0 0 0 3.946 4.827 4.996 4.996 0 0 1-2.212.085 4.936 4.936 0 0 0 4.604 3.417A9.867 9.867 0 0 1 0 19.54a13.94 13.94 0 0 0 7.548 2.212c9.057 0 14.01-7.502 14.01-14.01 0-.213-.005-.425-.014-.636A10.025 10.025 0 0 0 24 4.59z`})})
  }
function Ul({posts:e}){
  let t=(0,O.useRef)(null),n=ie(),r=e.length>1,i=e=>{
    let r=t.current;
    if(!r)
    return;
    let i=r.clientWidth*.9;
    r.scrollBy({left:e===`left`?-i:i,behavior:n?`auto`:`smooth`})
    };
  return(0,k.jsxs)(`div`,{className:`grid gap-4`,children:[r?(0,k.jsxs)(`div`,{className:`hidden items-center justify-end gap-2 lg:flex`,children:[(0,k.jsx)(Nl,{direction:`left`,onClick:()=>i(`left`)}),(0,k.jsx)(Nl,{direction:`right`,onClick:()=>i(`right`)})]}):null,(0,k.jsx)(`div`,{ref:t,className:`flex snap-x snap-mandatory gap-4 overflow-x-auto pb-2 [scrollbar-width:none] motion-reduce:snap-none motion-reduce:scroll-auto [&::-webkit-scrollbar]:hidden`,children:e.map(e=>(0,k.jsxs)(`article`,{className:`relative flex max-w-[21rem] min-w-[18rem] shrink-0 snap-start flex-col self-stretch overflow-hidden rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70 p-4 sm:min-w-[20rem]`,children:[(0,k.jsx)(Hl,{}),(0,k.jsxs)(`div`,{className:`relative z-10 flex flex-1 flex-col`,children:[e.publishedAt?(0,k.jsx)(Vl,{value:e.publishedAt}):null,(0,k.jsx)(`p`,{className:`mt-4 text-sm leading-7 whitespace-pre-line text-[color:var(--color-ink)]`,children:Ml(e.text)}),(0,k.jsx)(`div`,{className:`mt-auto flex justify-end pt-6`,children:(0,k.jsxs)(`a`,{href:e.url,rel:`noreferrer`,target:`_blank`,"aria-label":`Open post on X`,className:`inline-flex h-10 w-10 items-center justify-center rounded-full border border-[color:var(--color-line)] bg-white/85 text-[color:var(--color-accent-deep)] transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,children:[(0,k.jsx)(`span`,{className:`sr-only`,children:`Open post on X`}),(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,k.jsx)(`path`,{d:`M3.25 8h8.5M8.5 3.75 12.75 8 8.5 12.25`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.4`})})]})})]})]},e.id))})]})
  }
var Wl=new Set([`x.com`,`twitter.com`]),Gl=new Set([`explore`,`home`,`i`,`intent`,`login`,`messages`,`search`,`settings`,`share`]),Kl=/^[a-z0-9_]{1,15}$/i;
function ql(e){
  return e.toLowerCase().replace(/^www\./,``)
  }
function Jl(e){
  try{
    let t=new URL(e),n=ql(t.hostname);
    if(![`http:`,`https:`].includes(t.protocol)||t.username||t.password||t.port||!Wl.has(n))
    return null;
    let[r]=t.pathname.split(`/`).filter(Boolean),i=r?.replace(/^@/,``)??``;
    return!Kl.test(i)||Gl.has(i.toLowerCase())?null:i
    }catch{
    return null
    }
  }
var Yl=5,Xl=10;
function Zl(e){
  return typeof e==`object`&&!!e&&!Array.isArray(e)
  }
function Ql(e){
  return!e||!Number.isFinite(e)?Yl:Math.min(Xl,Math.max(1,Math.round(e)))
  }
function $l(e){
  return e===null||typeof e!=`string`||Number.isNaN(Date.parse(e))?null:e
  }
function eu(e){
  return!Zl(e)||typeof e.id!=`string`||!/^\d{1,19}$/.test(e.id)||typeof e.text!=`string`||!e.text.trim()||typeof e.url!=`string`||!Jl(e.url)||typeof e.isReply!=`boolean`||typeof e.isRetweet!=`boolean`?null:{id:e.id,text:e.text.trim(),url:e.url,publishedAt:$l(e.publishedAt),isReply:e.isReply,isRetweet:e.isRetweet}
  }
function tu(e,t){
  if(!Zl(e)||typeof e.adapter!=`string`||!e.adapter.trim()||e.accountName!==null&&typeof e.accountName!=`string`||typeof e.handle!=`string`||!e.handle.trim()||typeof e.profileUrl!=`string`||!Jl(e.profileUrl)||typeof e.sourceUrl!=`string`||!Jl(e.sourceUrl)||!Array.isArray(e.posts))
  return null;
  let n=new Set,r=e.posts.map(eu).filter(e=>!e||n.has(e.id)?!1:(n.add(e.id),!0)).slice(0,t);
  return r.length===0?null:{adapter:e.adapter,accountName:typeof e.accountName==`string`&&e.accountName.trim()||null,handle:e.handle,profileUrl:e.profileUrl,sourceUrl:e.sourceUrl,posts:r}
  }
function nu(e,t){
  let n=new URL(`/_catalog/social/x/posts`,window.location.origin);
  return n.searchParams.set(`url`,e),n.searchParams.set(`limit`,String(t)),n.toString()
  }
async function ru(e,t){
  try{
    let n=await fetch(nu(e,t),{cache:`no-store`,headers:{Accept:`application/json`}});
    if(!n.ok)
    return null;
    let r=await n.json();
    return tu(Zl(r)?r.data:null,t)
    }catch{
    return null
    }
  }
async function iu({profileUrl:e,limit:t}){
  let n=e.trim(),r=Ql(t);
  return Jl(n)?ru(n,r):null
  }
var au=[`x-post-skeleton-1`,`x-post-skeleton-2`,`x-post-skeleton-3`];
function ou(){
  return(0,k.jsx)(`div`,{"aria-hidden":`true`,className:`flex gap-4 overflow-x-hidden pb-2`,children:au.map(e=>(0,k.jsxs)(`div`,{className:`max-w-[21rem] min-w-[18rem] shrink-0 rounded-[1.7rem] border border-[color:var(--color-line)] bg-white/70 p-4 sm:min-w-[20rem]`,children:[(0,k.jsx)(`div`,{className:`h-3 w-24 animate-pulse rounded-full bg-neutral-500/15`}),(0,k.jsxs)(`div`,{className:`mt-4 space-y-3`,children:[(0,k.jsx)(`div`,{className:`h-4 w-full animate-pulse rounded-full bg-neutral-950/10`}),(0,k.jsx)(`div`,{className:`h-4 w-11/12 animate-pulse rounded-full bg-neutral-950/10`}),(0,k.jsx)(`div`,{className:`h-4 w-4/5 animate-pulse rounded-full bg-neutral-950/10`}),(0,k.jsx)(`div`,{className:`h-4 w-3/5 animate-pulse rounded-full bg-neutral-950/10`})]}),(0,k.jsx)(`div`,{className:`mt-6 flex justify-end`,children:(0,k.jsx)(`div`,{className:`bg-accent/15 h-10 w-10 animate-pulse rounded-full`})})]},e))})
  }
function su({profileUrl:e}){
  return(0,k.jsxs)(`div`,{className:`flex items-center justify-between gap-4 rounded-[1.7rem] border border-dashed border-[color:var(--color-line-strong)] bg-white/60 p-5 text-sm leading-7 text-[color:var(--color-muted)]`,children:[(0,k.jsx)(`p`,{children:`Recent posts are unavailable right now.`}),(0,k.jsxs)(`a`,{href:e,rel:`noreferrer`,target:`_blank`,"aria-label":`Open profile on X`,className:`inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full border border-[color:var(--color-line)] bg-white/85 text-[color:var(--color-accent-deep)] transition hover:border-[color:var(--color-line-strong)] hover:text-[color:var(--color-ink)]`,children:[(0,k.jsx)(`span`,{className:`sr-only`,children:`Open profile on X`}),(0,k.jsx)(`svg`,{"aria-hidden":`true`,className:`h-4 w-4`,viewBox:`0 0 16 16`,fill:`none`,children:(0,k.jsx)(`path`,{d:`M3.25 8h8.5M8.5 3.75 12.75 8 8.5 12.25`,stroke:`currentColor`,strokeLinecap:`round`,strokeLinejoin:`round`,strokeWidth:`1.4`})})]})]})
  }
function cu({children:e,providerName:t}){
  return(0,k.jsxs)(`section`,{className:`surface-panel grid gap-5 rounded-[2rem] p-6 sm:p-7`,children:[(0,k.jsx)(C,{title:`Recent tweets and retweets from ${t}`}),e]})
  }
function lu({providerName:e,profileUrl:t}){
  let n=T({queryKey:[`catalog`,`x-posts`,t],queryFn:()=>iu({profileUrl:t,limit:5}),staleTime:4320*60*1e3,retry:!1}),r=n.data;
  return n.isPending?(0,k.jsx)(cu,{providerName:e,children:(0,k.jsx)(ou,{})}):r?.posts.length?(0,k.jsx)(cu,{providerName:e,children:(0,k.jsx)(Ul,{posts:r.posts})}):(0,k.jsx)(cu,{providerName:e,children:(0,k.jsx)(su,{profileUrl:t})})
  }
function uu({enabled:e,providerName:t,socialLinks:n}){
  if(!e)
  return null;
  let r=n.find(e=>e.platform===`x`)??null;
  return r?(0,k.jsx)(lu,{providerName:t,profileUrl:r.url},r.url):null
  }
export{lc as a,je as c,nl as i,Oe as l,jl as n,cc as o,tl as r,ke as s,uu as t};
