# Verification

Chromium 153.0.8010.52, 2026-10-26.

- Both pages compared with the originals at 1440 × 1000, 1024 × 768, 390 × 844 and 320 × 740.
- Header, heading, hero stage and search field coordinates/dimensions match within 0.6 CSS pixels. Font family, size, line height and color match for these elements. No horizontal overflow.
- Display resources are served locally. Browser checks block requests outside the local origin; there are no page errors, failed local resources or remote display requests in the final QA report.
- Canvas screenshots differ 500ms apart with normal motion, and remain identical while paused. Resume works.
- The production build cycles through all three hero scenes: 83-provider GLM-5.2, 75-provider Kimi K3 and 60-provider DeepSeek V4.1 Flash.
- Quick search finds Grok 4.5 and opens the local detail route through Inertia. Browser Back restores the homepage.
- Sponsored model selection, coding-tool menu, share menu, terminology dialog and animated skills dialog pass. Search and the coding-tool menu also pass at 390px.
- Dark-mode detail view is exercised.
- The eleven sponsored-model listing responses resolve to the correct saved model slug in the independent build.
- HTML/module/style routes and Inertia JSON responses return 200 in `dist/`.

Reports: `report.json`, `build-report.json`. Browser screenshots remain in this workspace directory; source archives omit large screenshot files.

Evidence:

- Layout comparison: `ev_5ca9d954494276ba2095eaea1ae274a75468d47ef9289194ddc089be190c91b9`.
- Final interaction/resource checks: `ev_86b1ed289d4d344cbae6cce64678f8883a8d9e73e37aa405ec133f0851eeb95f`.
- Independent build and full hero scene cycle: `ev_57fa36148e671ad831926bd34cd887fd97b8007f8d6e8de5674659d3a7bfb7d5`.

Visual comparison uses reduced motion to avoid comparing different moments of a moving 3D scene. Normal-motion behavior is tested separately. These checks establish fidelity for the two saved pages in the tested Chromium environment, not identical rendering on every graphics driver or a full copy of the live catalog.
