import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
const { server } = await import('../dist/server/index.mjs');

const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
const base=`http://127.0.0.1:${server.address().port}`;
const report={routes:{},sponsoredListings:[],heroCaptions:[],errors:[],failed:[]};
const out=resolve(import.meta.dirname,'../verification');await mkdir(out,{recursive:true});
try{
 for(const path of ['/','/models/xai-grok-45-97244c89','/build/assets/app.js','/build/assets/app.css','/build/assets/hero-scene.js','/synthetic-dark.svg']){
  const response=await fetch(base+path);report.routes[path]=response.status;assert.equal(response.status,200);
 }
 const detail=await fetch(base+'/models/xai-grok-45-97244c89',{headers:{'X-Inertia':'true'}});
 assert.equal(detail.headers.get('x-inertia'),'true');assert.equal((await detail.json()).component,'models/show');
 const home=JSON.parse(await readFile(resolve(import.meta.dirname,'../data/home.json'),'utf8'));
 for(const model of home.props.sponsoredProvider.models){
  const response=await fetch(base+'/_catalog/models?'+new URLSearchParams({slug:model.slug,itemsPerPage:'1'}));
  const body=await response.json();assert.equal(body.items[0]?.slug,model.slug);report.sponsoredListings.push({name:model.name,matched:true});
 }
 const page=await browser.newPage({viewport:{width:1440,height:1000},reducedMotion:'no-preference'});
 page.on('pageerror',e=>report.errors.push(e.message));page.on('response',r=>{if(r.status()>=400)report.failed.push({url:r.url(),status:r.status()})});
 await page.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());
 await page.goto(base,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>document.querySelector('[data-hero-showcase]')?.dataset.status==='animated',null,{timeout:20000});
 const started=Date.now(),captions=new Set();
 while(Date.now()-started<60000&&captions.size<3){
  const text=await page.locator('[data-hero-showcase]').evaluate(e=>e.parentElement.lastElementChild.innerText.replace(/\s+/g,' ').trim());
  if(text)captions.add(text);await page.waitForTimeout(700);
 }
 report.heroCaptions=[...captions];assert.equal(captions.size,3,'The hero did not cycle through all three saved scenes');
 await page.screenshot({path:resolve(out,'hero-third-scene.png')});
 assert.equal(report.errors.length,0);assert.equal(report.failed.length,0);
 report.status='passed';
}catch(error){report.status='failed';report.error=error.stack;process.exitCode=1}
finally{await writeFile(resolve(out,'build-report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report,null,2));await browser.close();await new Promise(done=>server.close(done));}
