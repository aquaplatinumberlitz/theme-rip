import assert from 'node:assert/strict';
import { writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { once } from 'node:events';
const {server}=await import('../dist/server/index.mjs');
if(!server.listening)await once(server,'listening');
const base=`http://127.0.0.1:${server.address().port}`;
try{
 const response=await fetch(base+'/models?search=grok',{headers:{'X-Inertia':'true'}});
 assert.equal(response.status,409);
 assert.equal(response.headers.get('x-inertia-location'),'https://models.sulat.com/models?search=grok');
 const home=await fetch(base+'/',{headers:{'X-Inertia':'true','X-Inertia-Partial-Data':'news'}});
 assert.equal(home.headers.get('x-inertia'),'true');
 const data=await home.json();assert(Array.isArray(data.props.news.items));
 const detail=await fetch(base+'/models/xai-grok-45-97244c89',{headers:{'X-Inertia':'true'}});
 assert.equal((await detail.json()).props.model.slug,'xai-grok-45-97244c89');
 const result={status:'passed',unarchivedInertiaLocation:true,deferredNews:true,savedModel:true};
 await writeFile(resolve(import.meta.dirname,'../verification/protocol-report.json'),JSON.stringify(result,null,2));console.log(JSON.stringify(result));
}finally{await new Promise(done=>server.close(done))}
