import { server } from '../server/index.mjs';
import { writeFile } from 'node:fs/promises';
const {chromium}=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const browser=await chromium.launch({executablePath:'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const page=await browser.newPage({viewport:{width:1440,height:1000}});
page.on('response',async response=>{if(response.url().includes('/_catalog/search'))console.log('SEARCH',response.url(),(await response.text()).slice(0,4000))});
try{
await page.goto(`http://127.0.0.1:${server.address().port}`);
await page.getByRole('button',{name:'Search the catalog',exact:true}).click();
await page.locator('#command-search').fill('grok');await page.waitForTimeout(1500);
console.log('DIALOG',await page.getByRole('dialog').innerText());
await page.screenshot({path:'verification/debug-search.png'});
await writeFile('verification/debug-search.html',await page.content());
}finally{await browser.close();await new Promise(r=>server.close(r))}
