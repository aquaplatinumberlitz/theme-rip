import { readdir, readFile, stat } from 'node:fs/promises';
import { resolve, dirname } from 'node:path';
import { spawnSync } from 'node:child_process';
import assert from 'node:assert/strict';

const root=resolve(import.meta.dirname,'..');
let modules=0,assets=0;
async function inspect(directory){
 for(const entry of await readdir(directory,{withFileTypes:true})){
  const file=resolve(directory,entry.name);
  if(entry.isDirectory())await inspect(file);
  else if(/\.(?:js|mjs|cjs)$/.test(entry.name)){
   const result=spawnSync(process.execPath,['--check',file],{encoding:'utf8'});
   assert.equal(result.status,0,`${file}\n${result.stderr}`);modules++;
   const source=await readFile(file,'utf8');
   for(const match of source.matchAll(/from\s*["'](\.[^"']+)["']/g))assert((await stat(resolve(dirname(file),match[1]))).isFile(),`Missing static import ${match[1]}`);
  }
 }
}
await inspect(resolve(root,'src'));await inspect(resolve(root,'server'));await inspect(resolve(root,'tools'));
for(const name of ['home','model']){
 const page=JSON.parse(await readFile(resolve(root,`data/${name}.json`),'utf8'));
 assert(page.component&&page.props&&page.version);
 const html=await readFile(resolve(root,`src/templates/${name}.html`),'utf8');
 assert.equal((html.match(/@@PAGE_JSON@@/g)||[]).length,1);
 assert(!/__CF\$|cloudflareinsights|googletagmanager/.test(html),'Remote tracking script');
 for(const match of html.matchAll(/(?:src|href)=["'](\/[^"'#?]+)["']/g)){
  const path=match[1];
  if(path.startsWith('/models')&&!/\.(svg|webp|png)$/.test(path))continue;
  if(path.startsWith('/providers')||path.startsWith('/news')||path==='/feed'||path==='/')continue;
  let file;
  if(path==='/local-runtime.js')file=resolve(root,'src/local-runtime.js');
  else if(path==='/build/assets/app.css')file=resolve(root,'src/styles/app.css');
  else if(path.startsWith('/build/assets/'))file=resolve(root,'src/frontend',path.slice('/build/assets/'.length));
  else file=resolve(root,'public',`.${path}`);
  assert((await stat(file)).isFile(),`Missing displayed asset ${path}`);assets++;
 }
}
for(const path of Object.values(JSON.parse(await readFile(resolve(root,'reference/asset-url-map.json'),'utf8')))){
 assert((await stat(resolve(root,'public',`.${path}`))).isFile(),`Missing archived resource ${path}`);
}
console.log(`Passed: ${modules} JavaScript modules, ${assets} page asset references, two demo pages, local asset map.`);
