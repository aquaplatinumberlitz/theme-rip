import assert from 'node:assert/strict';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
import { server } from '../server/index.mjs';

const { chromium }=await import(process.env.PLAYWRIGHT_MODULE||'playwright-core');
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox','--enable-unsafe-swiftshader']});
const base=`http://127.0.0.1:${server.address().port}`;
const out=resolve(import.meta.dirname,'../verification');await mkdir(out,{recursive:true});
const detail='/models/xai-grok-45-97244c89';
const report={comparisons:[],interactions:[],errors:[],failed:[],remote:[]};
if(process.env.QA_INTERACTIONS_ONLY)report.comparisons=JSON.parse(await readFile(resolve(out,'report.json'),'utf8')).comparisons;
function attach(page){
 page.on('pageerror',e=>report.errors.push({url:page.url(),message:e.message}));
 page.on('console',m=>{if(m.type()==='error')report.errors.push({url:page.url(),message:m.text()})});
 page.on('response',r=>{if(r.status()>=400)report.failed.push({url:r.url(),status:r.status()})});
}
const metrics=()=>{
 const selectors=['header','h1','main','[data-hero-showcase]','input[type=search]'];
 return Object.fromEntries(selectors.map(selector=>{
  const node=document.querySelector(selector);if(!node)return [selector,null];
  const r=node.getBoundingClientRect(),s=getComputedStyle(node);
  return [selector,{x:r.x,y:r.y+scrollY,width:r.width,height:r.height,fontFamily:s.fontFamily,fontSize:s.fontSize,lineHeight:s.lineHeight,color:s.color,background:s.backgroundColor}];
 }));
};
async function ready(page){await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(1100)}
async function screenshot(page,name){await page.screenshot({path:resolve(out,`${name}.png`)})}
async function close(page){
 const search=page.getByRole('button',{name:'Close quick search',exact:true});
 if(await search.count())await search.last().click();else await page.keyboard.press('Escape');
 await page.waitForTimeout(180);
}
async function reveal(page){
 await page.evaluate(async()=>{for(let top=0;top<document.documentElement.scrollHeight;top+=800){scrollTo({top,behavior:'instant'});await new Promise(done=>setTimeout(done,90))}scrollTo({top:0,behavior:'instant'})});
 await page.waitForTimeout(500);
}
try{
 for(const viewport of process.env.QA_INTERACTIONS_ONLY?[]:[{width:1440,height:1000},{width:1024,height:768},{width:390,height:844},{width:320,height:740}]){
  const context=await browser.newContext({viewport,colorScheme:'light',reducedMotion:'reduce'});
  const original=await context.newPage(),local=await context.newPage();attach(local);
  await local.route('**/*',route=>{if(!route.request().url().startsWith(base)){report.remote.push(route.request().url());return route.abort()}return route.continue()});
  for(const [name,path] of [['home','/'],['detail',detail]]){
   await original.goto('https://models.sulat.com'+path,{waitUntil:'domcontentloaded'});
   await local.goto(base+path,{waitUntil:'domcontentloaded'});
   await Promise.all([ready(original),ready(local)]);
   const a=await original.evaluate(metrics),b=await local.evaluate(metrics),diff=[];
   for(const selector of ['header','h1','[data-hero-showcase]','input[type=search]']){
    if(!a[selector]&&!b[selector])continue;
    assert(a[selector]&&b[selector],`Missing ${selector}`);
    for(const property of ['x','y','width','height'])if(Math.abs(a[selector][property]-b[selector][property])>.6)diff.push({selector,property,original:a[selector][property],local:b[selector][property]});
    for(const property of ['fontFamily','fontSize','lineHeight','color'])if(a[selector][property]!==b[selector][property])diff.push({selector,property,original:a[selector][property],local:b[selector][property]});
   }
   const overflow=await local.evaluate(()=>document.documentElement.scrollWidth>innerWidth);
   report.comparisons.push({name,viewport,differences:diff,overflow,original:a,local:b});
   await screenshot(original,`original-${name}-${viewport.width}`);await screenshot(local,`local-${name}-${viewport.width}`);
   assert.equal(diff.length,0,`${name} layout differs at ${viewport.width}px`);assert(!overflow);
   if(viewport.width===1440||viewport.width===390){
    await Promise.all([reveal(original),reveal(local)]);
    await original.screenshot({path:resolve(out,`original-${name}-${viewport.width}-full.png`),fullPage:true});
    await local.screenshot({path:resolve(out,`local-${name}-${viewport.width}-full.png`),fullPage:true});
    assert.equal(await local.locator('img').evaluateAll(images=>images.filter(i=>i.complete&&!i.naturalWidth).length),0,'Broken image');
   }
  }
  await context.close();
 }
 const context=await browser.newContext({viewport:{width:1440,height:1000},colorScheme:'light',reducedMotion:'no-preference'});
 const page=await context.newPage();attach(page);
 await page.route('**/*',route=>route.request().url().startsWith(base)?route.continue():route.abort());
 await page.goto(base,{waitUntil:'domcontentloaded'});
 await page.waitForFunction(()=>document.querySelector('[data-hero-showcase]')?.dataset.status==='animated',null,{timeout:20000});
 await page.waitForTimeout(1000);
 const stage=page.locator('[data-hero-showcase]');
 const a=createHash('sha256').update(await stage.screenshot()).digest('hex');await page.waitForTimeout(500);
 const b=createHash('sha256').update(await stage.screenshot()).digest('hex');assert.notEqual(a,b,'3D hero remained static');
 report.hero={animated:true,frameHashes:[a,b]};
 await page.getByRole('button',{name:'Pause hero animation',exact:true}).click();
 assert(await page.getByRole('button',{name:'Play hero animation',exact:true}).isVisible());
 const stillA=await stage.screenshot();await page.waitForTimeout(300);const stillB=await stage.screenshot();
 assert(stillA.equals(stillB),'Pause did not stop the hero');
 await page.getByRole('button',{name:'Play hero animation',exact:true}).click();report.hero.pauseResume='passed';
 await screenshot(page,'animated-home-desktop');

 await page.getByRole('button',{name:'Search the catalog',exact:true}).click();
 await page.locator('#command-search').fill('grok');
 const result=page.getByRole('dialog').getByRole('option').filter({hasText:'Grok 4.5'}).first();await result.waitFor();
 await screenshot(page,'search-desktop');await result.click();
 await page.waitForURL(base+detail);assert.equal(await page.locator('h1').textContent(),'Grok 4.5');
 report.interactions.push('Search opens the saved model through Inertia navigation');
 await page.goBack();await page.waitForURL(base+'/');
 await page.locator('button[title="Kimi K3"]').click();await page.waitForTimeout(500);
 const selected=page.locator('button[title="Kimi K3"]');
 assert((await selected.getAttribute('class')).includes('shadow-'));report.interactions.push('Sponsored model selector updates its active card');
 await page.goto(base+detail,{waitUntil:'domcontentloaded'});await ready(page);
 await page.getByRole('button',{name:'Show coding tool options',exact:true}).click();assert(await page.getByRole('menu').isVisible());await screenshot(page,'coding-menu-desktop');await close(page);
 await page.getByRole('button',{name:'Share page',exact:true}).click();assert(await page.getByRole('button',{name:'Copy link',exact:true}).isVisible());await screenshot(page,'share-desktop');await close(page);
 await page.getByRole('button',{name:'What is a provider?',exact:true}).click();assert(await page.getByRole('dialog').isVisible());await screenshot(page,'terminology-desktop');await close(page);
 await page.getByRole('button',{name:'FREE coding agent skills from skills.sh (opens a dialog)',exact:true}).click();assert(await page.getByRole('dialog').isVisible());
 const codeA=await page.getByRole('dialog').innerText();await page.waitForTimeout(1800);const codeB=await page.getByRole('dialog').innerText();assert.notEqual(codeA,codeB,'Skills animation did not advance');await screenshot(page,'skills-desktop');await close(page);
 report.interactions.push('Coding menu, sharing, terminology dialog and animated skills modal');
 await page.setViewportSize({width:390,height:844});await page.getByRole('button',{name:'Search the catalog',exact:true}).click();await page.locator('#command-search').fill('grok');await page.waitForTimeout(500);await screenshot(page,'search-mobile');await close(page);
 await page.getByRole('button',{name:'Show coding tool options',exact:true}).click();assert(await page.getByRole('menu').isVisible());await screenshot(page,'coding-menu-mobile');await close(page);
 report.interactions.push('Search and coding menu at 390px');
 await context.close();
 const dark=await browser.newContext({viewport:{width:390,height:844},colorScheme:'dark',reducedMotion:'reduce'});const darkPage=await dark.newPage();attach(darkPage);await darkPage.goto(base+detail,{waitUntil:'domcontentloaded'});await ready(darkPage);await screenshot(darkPage,'detail-dark-mobile');await dark.close();
 assert.equal(report.errors.length,0,'JavaScript/browser console errors');assert.equal(report.failed.length,0,'Missing local resources');assert.equal(report.remote.length,0,'Page tried to fetch remote display resources');report.status='passed';
}catch(error){report.status='failed';report.error=error.stack;process.exitCode=1}
finally{await writeFile(resolve(out,'report.json'),JSON.stringify(report,null,2));console.log(JSON.stringify({status:report.status,comparisons:report.comparisons.map(({name,viewport,differences,overflow})=>({name,viewport,differences,overflow})),hero:report.hero,interactions:report.interactions,errors:report.errors,failed:report.failed,remote:report.remote,error:report.error},null,2));await browser.close();await new Promise(done=>server.close(done));}
