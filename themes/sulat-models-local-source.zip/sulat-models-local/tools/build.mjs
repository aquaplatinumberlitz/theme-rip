import { cp, mkdir, readFile, rm, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';

const root=resolve(import.meta.dirname,'..'),dist=resolve(root,'dist');
await rm(dist,{recursive:true,force:true});await mkdir(dist,{recursive:true});
for(const directory of ['server','src','data','public'])await cp(resolve(root,directory),resolve(dist,directory),{recursive:true});
await mkdir(resolve(dist,'reference'),{recursive:true});
await cp(resolve(root,'reference/asset-url-map.json'),resolve(dist,'reference/asset-url-map.json'));
const pkg=JSON.parse(await readFile(resolve(root,'package.json'),'utf8'));
await writeFile(resolve(dist,'package.json'),JSON.stringify({name:pkg.name,version:pkg.version,private:true,type:'module',engines:pkg.engines,scripts:{start:'node server/index.mjs'}},null,2));
await writeFile(resolve(dist,'README.md'),'# Sulat Models local build\n\nRequires Node.js 22 or newer. No dependency installation or API key is needed.\n\nRun `npm start`, then open http://localhost:4174/ or http://localhost:4174/models/xai-grok-45-97244c89.\n\nSet PORT to change the port. Keep server/, src/, data/, public/ and reference/ together. The two saved pages use JSON on disk. Unarchived links open the original website when selected; external video playback requires internet.\n');
console.log('Built standalone Node application in dist/. Run: cd dist && npm start');
