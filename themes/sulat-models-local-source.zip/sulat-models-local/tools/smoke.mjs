const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright-core');
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { server } from '../server/index.mjs';

const out=resolve(import.meta.dirname,'../verification');await mkdir(out,{recursive:true});
const browser=await chromium.launch({executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox']});
const base=`http://127.0.0.1:${server.address().port}`;
const report={pages:[],errors:[],failed:[],remote:[]};
try{
 for(const width of [1440,390]){
  const context=await browser.newContext({viewport:{width,height:width===1440?1000:844}});
  const page=await context.newPage();
  page.on('pageerror',e=>report.errors.push(e.message));
  page.on('console',m=>{if(m.type()==='error')report.errors.push(m.text())});
  page.on('response',r=>{if(r.status()>=400)report.failed.push({url:r.url(),status:r.status()})});
  await page.route('**/*',route=>{if(!route.request().url().startsWith(base)){report.remote.push(route.request().url());return route.abort();}return route.continue();});
  for(const [name,path] of [['home','/'],['detail','/models/xai-grok-45-97244c89']]){
   await page.goto(base+path,{waitUntil:'domcontentloaded'});
   await page.evaluate(()=>document.fonts.ready);await page.waitForTimeout(3000);
   await page.screenshot({path:resolve(out,`${name}-${width}.png`)});
   const values=await page.evaluate(()=>({title:document.title,h1:document.querySelector('h1')?.textContent,text:document.body.innerText.slice(0,250),hero:document.querySelector('[data-hero-showcase]')?.dataset.status,canvases:document.querySelectorAll('canvas').length,overflow:document.documentElement.scrollWidth>innerWidth,images:[...document.images].filter(i=>i.complete&&!i.naturalWidth).map(i=>i.src)}));
   report.pages.push({name,width,...values});
  }
  await context.close();
 }
}catch(error){report.error=error.stack;process.exitCode=1}
finally{await writeFile(resolve(out,'smoke.json'),JSON.stringify(report,null,2));await browser.close();await new Promise(r=>server.close(r));console.log(JSON.stringify(report,null,2));}
