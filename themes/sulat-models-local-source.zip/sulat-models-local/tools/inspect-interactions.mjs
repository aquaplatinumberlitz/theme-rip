const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright-core');
import { readFile, writeFile, mkdir } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash } from 'node:crypto';

const reference = resolve(import.meta.dirname, '../reference');
const manifest = new Map(JSON.parse(await readFile(resolve(reference,'resources.json'),'utf8')).map(e=>[e.url,e]));
const tasks = [], summaries = [];
const browser = await chromium.launch({ executablePath:process.env.CHROMIUM_PATH||'/usr/bin/chromium',headless:true,args:['--no-sandbox'] });
const context = await browser.newContext({viewport:{width:1440,height:1000}});
const page = await context.newPage();
page.on('response',response=>{
  const url=response.url(), parsed=new URL(url);
  if(!['models.sulat.com','api-models.sulat.com','i.ytimg.com'].includes(parsed.hostname)||response.request().method()!=='GET'||response.status()!==200)return;
  const type=response.headers()['content-type']||'';
  if(manifest.has(url)&&!type.includes('json'))return;
  tasks.push((async()=>{
    try{
      const bytes=await response.body(),sha256=createHash('sha256').update(bytes).digest('hex');
      const ext=extname(parsed.pathname).match(/^\.[a-z0-9]{1,5}$/i)?.[0]||(type.includes('json')?'.json':type.includes('html')?'.html':'.bin');
      const path=`resources/${sha256.slice(0,16)}${ext}`;
      await writeFile(resolve(reference,path),bytes);
      manifest.set(url,{url,status:200,type,path,bytes:bytes.length,sha256});
    }catch{}
  })());
});
async function snap(name){
  await page.waitForTimeout(500);
  await writeFile(resolve(reference,`${name}.html`),await page.content());
  await page.screenshot({path:resolve(reference,`${name}.png`)});
  const value=await page.evaluate(()=>({text:document.body.innerText.slice(-18000),dialogs:[...document.querySelectorAll('[role=dialog],[role=menu],[role=tooltip]')].map(e=>({role:e.role,text:e.innerText,class:e.className})),images:[...document.images].map(e=>({src:e.currentSrc||e.src,loading:e.loading,loaded:e.complete&&e.naturalWidth>0}))}));
  await writeFile(resolve(reference,`${name}.json`),JSON.stringify(value,null,2));
  summaries.push({name,dialogs:value.dialogs,textEnd:value.text.slice(-900)});
}
async function dismiss(){await page.keyboard.press('Escape');await page.waitForTimeout(200);}
async function scrollAll(){await page.evaluate(async()=>{for(let y=0;y<document.documentElement.scrollHeight;y+=700){scrollTo({top:y,behavior:'instant'});await new Promise(r=>setTimeout(r,120));}scrollTo({top:0,behavior:'instant'});});await page.waitForTimeout(700);}
try{
  await page.goto('https://models.sulat.com/',{waitUntil:'domcontentloaded'});await page.waitForTimeout(2200);
  await page.getByRole('button',{name:'Search the catalog',exact:true}).click();
  await snap('search-empty-desktop');
  await page.locator('#command-search').fill('grok');await page.waitForTimeout(1000);await snap('search-grok-desktop');
  await dismiss();
  const sponsor=page.locator('button[title="Kimi K3"]');
  if(await sponsor.count()){await sponsor.first().click();await snap('sponsor-kimi-desktop');}
  await scrollAll();await snap('home-scrolled-desktop');
  await writeFile(resolve(reference,'home-complete.html'),await page.content());
  await page.goto('https://models.sulat.com/models/xai-grok-45-97244c89',{waitUntil:'domcontentloaded'});await page.waitForTimeout(1600);
  await page.getByRole('button',{name:'Show coding tool options',exact:true}).click();await snap('coding-menu-desktop');await dismiss();
  await page.getByRole('button',{name:'Share page',exact:true}).click();await snap('share-menu-desktop');await dismiss();
  await page.getByRole('button',{name:'What is a provider?',exact:true}).click();await snap('provider-help-desktop');await dismiss();
  await page.getByRole('button',{name:'Show price comparison',exact:true}).click();await snap('price-comparison-desktop');await dismiss();
  await page.getByRole('button',{name:'FREE coding agent skills from skills.sh (opens a dialog)',exact:true}).click();await snap('skills-dialog-desktop');await dismiss();
  await scrollAll();await snap('detail-scrolled-desktop');
  await writeFile(resolve(reference,'detail-complete.html'),await page.content());
  await page.setViewportSize({width:390,height:844});
  await page.getByRole('button',{name:'Search the catalog',exact:true}).click();await snap('search-empty-mobile');
  await page.locator('#command-search').fill('grok');await page.waitForTimeout(800);await snap('search-grok-mobile');await dismiss();
  await page.getByRole('button',{name:'Show coding tool options',exact:true}).click();await snap('coding-menu-mobile');await dismiss();
}catch(error){console.log('Inspection step stopped:',error.message)}
finally{
  await Promise.allSettled(tasks);await writeFile(resolve(reference,'resources.json'),JSON.stringify([...manifest.values()],null,2));
  await writeFile(resolve(reference,'interactions.json'),JSON.stringify(summaries,null,2));await browser.close();
  console.log(JSON.stringify({states:summaries.map(s=>({name:s.name,dialogs:s.dialogs.map(d=>({role:d.role,text:d.text.slice(0,1400)}))})),resources:manifest.size},null,2));
}
