// Development-only formatting. BABEL_PARSER points to an installed parser.
const fs=require('node:fs');
const path=require('node:path');
const parser=require(process.env.BABEL_PARSER);
const root=path.resolve(__dirname,'..');
const fingerprints=[];
function syntax(node){return JSON.stringify(node,(key,value)=>['start','end','loc','extra','comments','leadingComments','trailingComments','innerComments'].includes(key)?undefined:value)}
for(const file of fs.readdirSync(path.join(root,'src/frontend')).filter(file=>file.endsWith('.js'))){
 const filename=path.join(root,'src/frontend',file);
 const source=fs.readFileSync(filename,'utf8');
 const tree=parser.parse(source,{sourceType:'module'});
 const breaks=new Map();
 const mark=(pos,depth)=>breaks.set(pos,Math.max(breaks.get(pos)??0,depth));
 function walk(node,depth=0){
  if(!node||typeof node!=='object'||typeof node.type!=='string')return;
  if(node.type==='BlockStatement'||node.type==='ClassBody'){mark(node.start+1,depth+1);mark(node.end-1,depth);depth++}
  if(/Statement$|Declaration$/.test(node.type)&&!['BlockStatement','EmptyStatement'].includes(node.type)){mark(node.start,depth);mark(node.end,depth)}
  for(const [key,value] of Object.entries(node)){
   if(['start','end','loc','extra','comments','tokens'].includes(key))continue;
   if(Array.isArray(value))value.forEach(entry=>walk(entry,depth));else walk(value,depth);
  }
 }
 walk(tree.program);
 let formatted='';
 for(let i=0;i<source.length;i++){if(breaks.has(i))formatted+='\n'+'  '.repeat(breaks.get(i));formatted+=source[i]}
 const same=syntax(tree.program)===syntax(parser.parse(formatted,{sourceType:'module'}).program);
 if(!same)throw new Error(`Formatting changed syntax: ${file}`);
 fs.writeFileSync(filename,formatted.trim()+'\n');
 fingerprints.push({module:file,syntaxPreserved:true,lines:formatted.split('\n').length});
}
function formatCSS(text){
 let out='',depth=0,parens=0,quote='',comment=false;
 const nl=()=>{out=out.trimEnd()+'\n'+'  '.repeat(depth)};
 for(let i=0;i<text.length;i++){
  const c=text[i],next=text[i+1];
  if(comment){out+=c;if(c==='*'&&next==='/'){out+=next;i++;comment=false}continue}
  if(quote){out+=c;if(c==='\\')out+=text[++i];else if(c===quote)quote='';continue}
  if(c==='/'&&next==='*'){out+=c+next;i++;comment=true;continue}
  if(c==='"'||c==="'"){quote=c;out+=c;continue}
  if(c==='\\'){out+=c+next;i++;continue}
  if(c==='(')parens++;if(c===')')parens--;
  if(!parens&&c==='{'){out+=' {';depth++;nl()}
  else if(!parens&&c==='}'){depth--;nl();out+='}';nl()}
  else if(!parens&&c===';'){out+=';';nl()}
  else out+=c;
 }
 return out.trim()+'\n';
}
const css=path.join(root,'src/styles/app.css');fs.writeFileSync(css,formatCSS(fs.readFileSync(css,'utf8')));
fs.writeFileSync(path.join(root,'reference/source-formatting.json'),JSON.stringify(fingerprints,null,2));
console.log(JSON.stringify(fingerprints));
