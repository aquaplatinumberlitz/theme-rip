import { readFile, writeFile, mkdir, stat, readdir } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash } from 'node:crypto';

const root=resolve(import.meta.dirname,'..');
const mapping=JSON.parse(await readFile(resolve(root,'reference/asset-url-map.json'),'utf8'));
const candidates=new Map();
const extensions=/\.(?:svg|webp|png|jpe?g|avif|woff2?|ico)(?:[?#]|$)/i;
function add(value){
  if(typeof value!=='string'||!extensions.test(value))return;
  let url;
  try{url=new URL(value,'https://models.sulat.com')}catch{return}
  if(!['http:','https:'].includes(url.protocol))return;
  if(url.hostname==='models.dev')return; // localUrl is the site's cached logo.
  const path=url.hostname==='models.sulat.com'?url.pathname:'/archive/media/'+createHash('sha256').update(url.href).digest('hex').slice(0,16)+extname(url.pathname);
  candidates.set(url.href,mapping[url.href]||path);
}
function walk(value){
  if(typeof value==='string')add(value);
  else if(Array.isArray(value))value.forEach(walk);
  else if(value&&typeof value==='object')Object.values(value).forEach(walk);
}
async function scan(dir){
  for(const e of await readdir(dir,{withFileTypes:true})){
    const path=resolve(dir,e.name);
    if(e.isDirectory())await scan(path);
    else if(e.name.endsWith('.json'))walk(JSON.parse(await readFile(path,'utf8')));
  }
}
await scan(resolve(root,'data'));
for(const file of ['src/styles/app.css','src/templates/home.html','src/templates/model.html']){
  const s=await readFile(resolve(root,file),'utf8');
  for(const match of s.matchAll(/(?:src|srcset|href)=["']([^"']+)["']|url\(["']?([^)'"\s]+)["']?\)/g))add(match[1]||match[2]);
}
for(const file of await readdir(resolve(root,'src/frontend'))){
 if(!file.endsWith('.js'))continue;
 const source=await readFile(resolve(root,'src/frontend',file),'utf8');
 for(const match of source.matchAll(/["'`]([^"'`\s$]+\.(?:svg|png|webp|jpe?g|woff2?))["'`]/g))if(match[1].startsWith('/'))add(match[1]);
}
const todo=[];
for(const [url,path] of candidates){
  try{await stat(resolve(root,'public',`.${path}`));mapping[url]=path;}catch{todo.push([url,path]);}
}
const records=[];
let next=0;
async function worker(){
  while(next<todo.length){
    const [url,path]=todo[next++];
    try{
      const response=await fetch(url,{signal:AbortSignal.timeout(20000)});
      if(!response.ok)throw new Error(String(response.status));
      const bytes=Buffer.from(await response.arrayBuffer());
      const filename=resolve(root,'public',`.${path}`);
      await mkdir(resolve(filename,'..'),{recursive:true});await writeFile(filename,bytes);
      mapping[url]=path;records.push({url,path,bytes:bytes.length,sha256:createHash('sha256').update(bytes).digest('hex')});
    }catch(error){records.push({url,error:error.message})}
  }
}
await Promise.all(Array.from({length:6},worker));
await writeFile(resolve(root,'reference/asset-url-map.json'),JSON.stringify(mapping,null,2));
let previous=[];
try{previous=JSON.parse(await readFile(resolve(root,'reference/additional-assets.json'),'utf8'))}catch{}
await writeFile(resolve(root,'reference/additional-assets.json'),JSON.stringify([...previous,...records],null,2));
console.log(JSON.stringify({candidates:candidates.size,downloaded:records.filter(r=>!r.error).length,errors:records.filter(r=>r.error)}));
