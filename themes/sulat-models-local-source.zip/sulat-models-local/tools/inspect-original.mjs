const { chromium } = await import(process.env.PLAYWRIGHT_MODULE || 'playwright-core');
import { mkdir, writeFile } from 'node:fs/promises';
import { resolve, extname } from 'node:path';
import { createHash } from 'node:crypto';

const root = resolve(import.meta.dirname, '..');
const reference = resolve(root, 'reference');
await mkdir(resolve(reference, 'resources'), { recursive: true });
const browser = await chromium.launch({ executablePath: process.env.CHROMIUM_PATH || '/usr/bin/chromium', headless: true, args: ['--no-sandbox'] });
const resources = new Map();
const pending = [];
const summaries = [];
function capture(page) {
  page.on('response', (response) => {
    const url = response.url();
    const parsed = new URL(url);
    if (!['models.sulat.com','api-models.sulat.com','fonts.googleapis.com','fonts.gstatic.com'].includes(parsed.hostname) || response.request().method() !== 'GET' || response.status() !== 200 || resources.has(url)) return;
    resources.set(url, { url, status: response.status(), type: response.headers()['content-type'] || '' });
    pending.push((async () => {
      try {
        const bytes = await response.body();
        const record = resources.get(url);
        const hash = createHash('sha256').update(bytes).digest('hex');
        const ext = extname(parsed.pathname).match(/^\.[a-z0-9]{1,5}$/i)?.[0] || (record.type.includes('json') ? '.json' : record.type.includes('html') ? '.html' : '.bin');
        record.path = `resources/${hash.slice(0,16)}${ext}`;
        record.bytes = bytes.length;
        record.sha256 = hash;
        await writeFile(resolve(reference, record.path), bytes);
      } catch (error) { resources.get(url).error = error.message; }
    })());
  });
}
async function snapshot(page, name) {
  await page.evaluate(() => document.fonts.ready);
  await page.waitForTimeout(2500);
  await writeFile(resolve(reference, `${name}.html`), await page.content());
  await page.screenshot({ path: resolve(reference, `${name}.png`) });
  await page.screenshot({ path: resolve(reference, `${name}-full.png`), fullPage: true });
  const info = await page.evaluate(() => ({
    url: location.href, title: document.title, viewport: { width: innerWidth, height: innerHeight },
    height: document.documentElement.scrollHeight, text: document.body.innerText,
    buttons: [...document.querySelectorAll('button')].map(e=>({text:e.innerText,aria:e.getAttribute('aria-label'),title:e.title,class:e.className})),
    inputs: [...document.querySelectorAll('input,select')].map(e=>({tag:e.tagName,type:e.type,placeholder:e.placeholder,aria:e.getAttribute('aria-label')})),
    styles: [...document.styleSheets].map(e=>e.href), scripts: [...document.scripts].map(e=>e.src),
    animations: document.getAnimations().map(a=>({target:a.effect?.target?.tagName,class:a.effect?.target?.className,keyframes:a.effect?.getKeyframes(),timing:a.effect?.getTiming()})),
    fonts: [...new Set([...document.querySelectorAll('h1,h2,p,button,a')].map(e=>getComputedStyle(e).fontFamily))],
    canvases: document.querySelectorAll('canvas').length,
  }));
  await writeFile(resolve(reference, `${name}.json`), JSON.stringify(info, null, 2));
  summaries.push({ name, title: info.title, height: info.height, fonts: info.fonts, buttons: info.buttons.slice(0,30), inputs: info.inputs, animations: info.animations.length, canvases: info.canvases, text:info.text.slice(0,3000) });
}
try {
  for (const viewport of [{ width:1440,height:1000 }, { width:390,height:844 }]) {
    const context = await browser.newContext({ viewport, reducedMotion:'no-preference' });
    const page = await context.newPage();
    capture(page);
    await page.goto('https://models.sulat.com/', { waitUntil:'domcontentloaded' });
    await snapshot(page, `home-${viewport.width}`);
    await page.goto('https://models.sulat.com/models/xai-grok-45-97244c89', { waitUntil:'domcontentloaded' });
    await snapshot(page, `detail-${viewport.width}`);
    await context.close();
  }
  await Promise.allSettled(pending);
} finally {
  await writeFile(resolve(reference, 'resources.json'), JSON.stringify([...resources.values()], null, 2));
  await writeFile(resolve(reference, 'inspection.json'), JSON.stringify(summaries,null,2));
  await browser.close();
  console.log(JSON.stringify({ pages:summaries, resources:resources.size, totalBytes:[...resources.values()].reduce((s,r)=>s+(r.bytes||0),0) },null,2));
}
