"""Prepare two editable page templates, snapshot data, assets and browser modules."""
from pathlib import Path
from urllib.parse import urlparse
from bs4 import BeautifulSoup
import json, re, shutil

ROOT=Path(__file__).resolve().parents[1]
REF=ROOT/'reference'
records=json.loads((REF/'resources.json').read_text())
for name in ['public','src/frontend','src/styles','src/templates','data/responses','server','verification']:
    (ROOT/name).mkdir(parents=True,exist_ok=True)
names={
 'app-BvsUmf8j.js':'app.js', 'home-B_UFhVQ-.js':'home.js',
 'show-DhAsywXn.js':'model-detail.js','link-0_m2czf7.js':'react-inertia-runtime.js',
 'preload-helper-B6JZccWF.js':'preload.js','ArrowRightIcon-D0oP0UQC.js':'arrow-icon.js',
 'catalog-filter-options-Bz8B_VcL.js':'filter-options.js',
 'hero-showcase-format-BfKZeMQ-.js':'hero-format.js',
 'hero-showcase-scene-DHcOnNM3.js':'hero-scene.js',
 'model-news-section-ui-BPy_PkT5.js':'news-ui.js',
 'provider-social-showcase-GdGyge4N.js':'model-sections.js',
 'seo-head-4Ym2c5mD.js':'seo.js', 'app-D1SWX7Lk.css':'app.css',
}
def rename(text):
    for old,new in names.items():text=text.replace(old,new)
    return text
url_map={}
responses=[]
for item in records:
    if not item.get('path'):continue
    parsed=urlparse(item['url']); original=REF/item['path']
    if parsed.hostname=='models.sulat.com' and parsed.path.startswith('/build/assets/'):
        if original.suffix=='.js': destination=ROOT/'src/frontend'/names.get(Path(parsed.path).name,Path(parsed.path).name)
        elif original.suffix=='.css':destination=ROOT/'src/styles/app.css'
        else:continue
        destination.write_text(rename(original.read_text()))
    elif item['type'].startswith('application/json'):
        destination=ROOT/'data/responses'/original.name
        shutil.copy2(original,destination)
        responses.append({'url':parsed.path+('?' + parsed.query if parsed.query else ''),'file':destination.relative_to(ROOT).as_posix()})
    elif item['type'].startswith(('image/','font/')):
        if parsed.hostname=='models.sulat.com':path=parsed.path
        else:path='/archive/media/'+original.name
        destination=ROOT/'public'/path.lstrip('/')
        destination.parent.mkdir(parents=True,exist_ok=True)
        shutil.copy2(original,destination)
        url_map[item['url']]=path

def localize(value):
    if isinstance(value,dict):return {k:localize(v) for k,v in value.items()}
    if isinstance(value,list):return [localize(v) for v in value]
    if isinstance(value,str):
        if value in url_map:return url_map[value]
        if value.startswith('https://models.sulat.com/models-dev/'):
            return value.removeprefix('https://models.sulat.com')
    return value

pages={}
for path in sorted((REF/'resources').glob('*.html')):
    html=path.read_text()
    if '<!DOCTYPE' not in html[:100] and '<!doctype' not in html[:100]:continue
    soup=BeautifulSoup(html,'html.parser')
    tag=soup.select_one('script[data-page="app"]')
    if not tag:continue
    data=json.loads(tag.string or tag.text)
    if data['component'] not in ['home','models/show']:continue
    key='home' if data['component']=='home' else 'model'
    if key in pages:continue
    pages[key]=localize(data)
    # Preserve all original SSR text/React markers. Only integration and resource
    # references are changed, so hydration sees the same document structure.
    html=html.replace(tag.string or tag.text,'@@PAGE_JSON@@')
    html=re.sub(r'<script\b[^>]*src=["\'][^"\']*(?:cloudflareinsights|googletagmanager)[^"\']*["\'][^>]*>.*?</script>','',html,flags=re.S|re.I)
    html=re.sub(r'<script\b[^>]*>\s*\(function\(\)\{function c\(\).*?__CF\$cv\$params.*?</script>','',html,flags=re.S)
    html=re.sub(r'(<meta\s+name="csrf-token"\s+content=")[^"]*(")',r'\1local-demo\2',html)
    html=html.replace('https://models.sulat.com/build/','/build/')
    html=rename(html)
    for url,local in url_map.items():html=html.replace(url,local)
    html=html.replace('</head>','<script src="/local-runtime.js"></script></head>')
    (ROOT/f'src/templates/{key}.html').write_text(html)
    (ROOT/f'data/{key}.json').write_text(json.dumps(pages[key],ensure_ascii=False,indent=2))

assert set(pages)=={'home','model'},'Both original server HTML responses are needed'
for key,filename in [('home','home-news.json')]:
    match=next((r for r in records if r['url']=='https://models.sulat.com/' and r['type'].startswith('application/json')),None)
    value=json.loads((REF/match['path']).read_text())['props'].get('news',{'items':[]}) if match else {'items':[]}
    (ROOT/'data'/filename).write_text(json.dumps(localize(value),ensure_ascii=False,indent=2))
(ROOT/'data/responses.json').write_text(json.dumps(responses,indent=2))
(ROOT/'reference/asset-url-map.json').write_text(json.dumps(url_map,indent=2))
(ROOT/'reference/module-names.json').write_text(json.dumps(names,indent=2))
print(json.dumps({'pages':list(pages),'modules':len(list((ROOT/'src/frontend').glob('*.js'))),'assets':len(url_map),'responses':len(responses)}))
