// Capture the eleven listings selectable on the archived homepage.
import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { createHash } from 'node:crypto';
const root=resolve(import.meta.dirname,'..');
const home=JSON.parse(await readFile(resolve(root,'data/home.json'),'utf8'));
const responses=JSON.parse(await readFile(resolve(root,'data/responses.json'),'utf8'));
const records=[];
for(const model of home.props.sponsoredProvider.models){
 const path='/_catalog/models?'+new URLSearchParams({slug:model.slug,itemsPerPage:'1'});
 if(responses.some(entry=>entry.url===path))continue;
 const url='https://models.sulat.com'+path;
 const response=await fetch(url,{headers:{accept:'application/json'},signal:AbortSignal.timeout(20000)});
 if(!response.ok)throw new Error(`${model.name}: ${response.status}`);
 const bytes=Buffer.from(await response.arrayBuffer());
 const data=JSON.parse(bytes);if(!data.items?.length)throw new Error(`Missing listing ${model.slug}`);
 const sha256=createHash('sha256').update(bytes).digest('hex');
 const file=`data/responses/${sha256.slice(0,16)}.json`;
 await writeFile(resolve(root,file),JSON.stringify(data,null,2));responses.push({url:path,file});
 records.push({url,file,bytes:bytes.length,sha256});
}
await writeFile(resolve(root,'data/responses.json'),JSON.stringify(responses,null,2));
await writeFile(resolve(root,'reference/card-data-capture.json'),JSON.stringify(records,null,2));
console.log(JSON.stringify({added:records.length,totalResponses:responses.length}));
