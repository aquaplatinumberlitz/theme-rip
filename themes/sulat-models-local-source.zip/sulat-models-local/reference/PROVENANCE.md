# Reference and reconstruction record

Targets supplied by the user:

- https://models.sulat.com/
- https://models.sulat.com/models/xai-grok-45-97244c89

Captured on 2026-10-26 in Chromium. The HTML, published frontend modules, CSS, images, font files and demo catalog content originate from these public pages and their declared display resources. Original branding/assets and bundled libraries retain their original ownership and license terms; no new license is asserted for them.

## Evidence

- `ev_9c6572d280b99248645ee0aedb015580b9e5483c6d01f175606103074e04e8c3`: desktop/mobile page visits, DOM, resource response bytes, initial screenshots and visible UI inventory.
- `ev_79d76d5a503321d4c58924cb9d70dc03084e54e1fb1be015c0ed929ba71b97ca`: controlled UI observations covering quick search, model selection, coding menu, sharing, terminology, pricing, animated skills dialog and mobile menus.
- `ev_3b1a2cd93d441b6ac5bcb0658f959a5e085a431a5bea12738c586be84f131d44`: supplementary declared image/font resources saved locally, with hashes in `additional-assets.json`.
- `ev_7337efab291dcf13c1729536f1a59f8932d678e1594ae8fa6c4544eebff8bbce`: additional resources declared by the recovered modules, including dark-mode variants.
- `ev_ba71c371b253e2ad3d70b4979f2454428aa3c95731ce0f0700939768722a6ef4`: the remaining ten selectable sponsored listing JSON responses, recorded in `card-data-capture.json`. Together with the first captured listing they support all eleven homepage choices without another catalog service.

`resources.json` maps original URLs to retained byte snapshots, content types and SHA-256 digests under `resources/`. Screenshot/DOM files record observed states. `module-names.json` records the published-to-local file names. `asset-url-map.json` maps displayed image/font URLs to local files.

## Reconstruction

The authored local server replaces Laravel/catalog services with filesystem JSON responses and handles the Inertia protocol for the two archived pages. Search works over the retained demo subset. The local runtime keeps unarchived navigation explicit and implements optional OS speech without remote TTS.

The recovered browser modules preserve the published UI and Three.js renderer. File imports and Vite preload names are renamed consistently. Frontend files and CSS are formatted for inspection. `source-formatting.json` records successful AST equivalence checks before and after whitespace formatting; this does not recover the author's original TypeScript names or prove runtime identity on every GPU.

The local build disables hover prefetch of unarchived routes. HTML integrations for analytics/challenges are removed. The archived HTML is available as initial fallback markup, while the browser creates the React tree from local JSON rather than hydrating stale server-rendered markup. This avoids server/browser text mismatches in a saved snapshot.

## Boundaries

- Two archived pages and snapshot content, not the full live catalog or its administration/backend.
- The original model/provider counts and captured copy are archival demo data.
- Native speech replaces the original paid/server audio path. Video playback stays external; poster images are local.
- Unarchived destinations open the original website only when selected by the user.
- Animation frames depend on time, pointer position, device pixel ratio and graphics driver. Layout and interaction checks are separate from claims of pixel identity across every environment.
