# Sulat Models — bản lưu local

Bản chạy local của hai trang:

- `https://models.sulat.com/`
- `https://models.sulat.com/models/xai-grok-45-97244c89`

Giữ giao diện responsive, font Spectral/Lora, cảnh 3D, các hiệu ứng CSS, menu, tìm kiếm nhanh, popup, chia sẻ, bảng giá, carousel và dialog minh họa coding agent của frontend tham chiếu. Nội dung là snapshot demo, không đồng bộ với catalog trực tuyến.

## Chạy ngay

Cần **Node.js 22 trở lên**. Không cần `npm install`, PHP, database hoặc API key để chạy.

```sh
cd /home/admin/sulat-models-local
npm run dev
```

Mở:

- **http://localhost:4174/**
- **http://localhost:4174/models/xai-grok-45-97244c89**

Đổi cổng: `npm run dev -- --port 8080`, hoặc đặt biến môi trường `PORT`.

Hãy mở bằng HTTP qua server trên. `file://` không hỗ trợ ES modules và các endpoint dữ liệu của bản này.

## Build và lưu trữ

```sh
npm run check
npm run build
npm run preview
```

`dist/` là ứng dụng Node độc lập. Có thể chép nguyên thư mục đó sang máy khác, chạy `npm start` bên trong và mở cổng đã chọn. Server đọc JSON trên đĩa; không gọi API của Sulat khi hiển thị hai trang đã lưu.

Có thể backup toàn bộ thư mục project hoặc file ZIP source. Nội dung được lưu trong `data/`, các hình/logo/font trong `public/`, frontend và CSS trong `src/`.

## Source để sửa

| File/thư mục | Nội dung |
| --- | --- |
| `src/frontend/home.js` | Trang chủ, chọn model/provider, tìm kiếm tại hero, carousel |
| `src/frontend/model-detail.js` | Trang model, thông số, giới hạn, giá và video |
| `src/frontend/app.js` | Layout, header/footer, quick search, dialog và các UI dùng chung |
| `src/frontend/hero-scene.js` | Engine Three.js/WebGL của cảnh 3D: thẻ, logo, quỹ đạo, ánh sáng, chuyển cảnh và tương tác chuột |
| `src/frontend/hero-format.js` | Định dạng chữ, giá, context và metadata trên thẻ 3D |
| `src/frontend/model-sections.js` | Tin tức, menu chia sẻ, các khối nội dung và UI liên quan |
| `src/frontend/react-inertia-runtime.js` | React/Inertia runtime đã được bundle bởi website gốc |
| `src/styles/app.css` | Toàn bộ style, breakpoint và CSS keyframes, đã định dạng |
| `src/templates/` | Hai HTML snapshot dùng cho nội dung ban đầu và thẻ SEO |
| `src/local-runtime.js` | Điều hướng ngoài phạm vi archive và tích hợp giọng đọc local |
| `server/index.mjs` | HTTP server, trả HTML, assets và response Inertia |
| `server/catalog.mjs` | Tìm kiếm trong dữ liệu demo và API snapshot local |
| `data/home.json`, `data/model.json` | Dữ liệu hai trang; có thể chỉnh trực tiếp |
| `data/home-news.json`, `data/responses/` | Tin tức, video và response tham chiếu |
| `public/` | Tài nguyên hiển thị được lưu tại chỗ |

Các module frontend được khôi phục từ JavaScript công khai mà trình duyệt tải xuống. Chúng được đổi tên file để dễ tìm và định dạng lại; tên biến ngắn trong bundle vẫn còn. **Đây không phải repository React/TypeScript nguyên bản của tác giả.** Logic frontend/animation được giữ để độ khớp cao; server local và lớp dữ liệu được viết riêng. Xem `reference/PROVENANCE.md`.

## Animation và responsive

- Cảnh hero chạy bằng WebGL thật, gồm thẻ 3D, các provider quay theo quỹ đạo, chuyển model, hiệu ứng ánh sáng và chuyển động theo con trỏ.
- Nút Pause/Play điều khiển cảnh. Engine theo dõi viewport, trạng thái tab và resize.
- `prefers-reduced-motion` hoặc thiết bị không chạy được WebGL sẽ dùng hình orbit dự phòng của frontend gốc.
- CSS có breakpoint desktop/mobile, light/dark theo hệ điều hành, ticker, hiệu ứng chữ sáng, hover và animation trong dialog skills.
- Không thay canvas bằng ảnh chụp nếu muốn giữ chuyển động.

## Phạm vi nội dung demo

Hai trang trên được lưu để chạy local. Tìm kiếm trả về dữ liệu demo đã có; Grok 4.5 của xAI mở trang chi tiết local. Các trang model/provider/news khác mở website gốc khi người xem bấm liên kết. Số lượng model/provider trên trang chủ là số liệu tại thời điểm snapshot.

Các nút/khối tin tức đọc dữ liệu lưu sẵn. Phát YouTube và các liên kết bên ngoài cần internet khi người xem chủ động mở chúng; thumbnail video đã lưu local. Nút Listen dùng giọng đọc của hệ điều hành qua Web Speech API, không gọi dịch vụ TTS của website gốc. Khả năng đọc phụ thuộc voice có sẵn trên máy.

Analytics/challenge của bên thứ ba được loại khỏi HTML. Endpoint analytics local trả 204 và không lưu sự kiện.

## Kiểm tra

`npm run check` kiểm tra cú pháp, import tĩnh, các tài nguyên HTML, dữ liệu demo và asset map.

Các công cụ đối chiếu trình duyệt trong `tools/qa.mjs` cần Playwright Core và Chromium đã cài. Đặt `PLAYWRIGHT_MODULE` thành đường dẫn module và `CHROMIUM_PATH` thành đường dẫn Chromium nếu cần. Sau đó chạy `node tools/qa.mjs`. Ảnh và báo cáo nằm trong `verification/`.

Các công cụ `tools/inspect-*.mjs`, `prepare-local.py`, `fetch-assets.mjs`, `format-sources.cjs` phục vụ thu thập/khôi phục ban đầu; không cần chạy chúng để dùng bản local. Công cụ Python cần BeautifulSoup; công cụ định dạng dùng @babel/parser qua `BABEL_PARSER`.
