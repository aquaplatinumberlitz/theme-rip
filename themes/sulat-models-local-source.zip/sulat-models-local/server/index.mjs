import { createServer } from 'node:http';
import { readFile, stat } from 'node:fs/promises';
import { resolve, extname, sep } from 'node:path';
import { root, archivedPaths, catalogResponse, pageResponse } from './catalog.mjs';

const arg = process.argv.indexOf('--port');
const port = Number(arg >= 0 ? process.argv[arg + 1] : process.env.PORT || 4174);
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.avif': 'image/avif', '.ico': 'image/x-icon' };
function json(response, data, status = 200, headers = {}) {
  const text = JSON.stringify(data);
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...headers });
  response.end(text);
}
async function file(response, path, allowedRoot) {
  const filename = resolve(path);
  if (!filename.startsWith(resolve(allowedRoot) + sep)) return response.writeHead(403).end();
  if (!(await stat(filename)).isFile()) return response.writeHead(404).end();
  const bytes = await readFile(filename);
  response.writeHead(200, { 'Content-Type': mime[extname(filename)] || 'application/octet-stream', 'Content-Length': bytes.length, 'Cache-Control': 'no-store' });
  response.end(bytes);
}

export const server = createServer(async (request, response) => {
  try {
    const url = new URL(request.url, 'http://localhost');
    const path = decodeURIComponent(url.pathname).replace(/\/$/, '') || '/';
    if (path.startsWith('/_catalog/')) {
      const result = await catalogResponse(url, request.method);
      if (result.status === 204) return response.writeHead(204).end();
      return json(response, result.data, result.status || 200);
    }
    if (archivedPaths.has(path)) {
      const partial = request.headers['x-inertia-partial-data'] || '';
      const { key, page } = await pageResponse(path, partial);
      if (request.headers['x-inertia']) return json(response, page, 200, { 'X-Inertia': 'true', Vary: 'X-Inertia' });
      const template = await readFile(resolve(root, 'src/templates', `${key}.html`), 'utf8');
      const serialized = JSON.stringify(page).replace(/</g, '\\u003c');
      const html = template.replace('@@PAGE_JSON@@', () => serialized);
      response.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store', Vary: 'X-Inertia' });
      return response.end(html);
    }
    if (path === '/build/assets/app.css') return await file(response, resolve(root, 'src/styles/app.css'), resolve(root, 'src'));
    if (path.startsWith('/build/assets/')) return await file(response, resolve(root, 'src/frontend', path.slice('/build/assets/'.length)), resolve(root, 'src/frontend'));
    if (path === '/local-runtime.js') return await file(response, resolve(root, 'src/local-runtime.js'), resolve(root, 'src'));
    if (request.headers['x-inertia'] && /^\/(?:models|providers|news)(?:\/|$)/.test(path)) {
      response.writeHead(409, { 'X-Inertia-Location': 'https://models.sulat.com' + url.pathname + url.search + url.hash });
      return response.end();
    }
    const publicPath = resolve(root, 'public', `.${path}`);
    try { return await file(response, publicPath, resolve(root, 'public')); } catch (error) { if (error.code !== 'ENOENT' && error.code !== 'ENOTDIR') throw error; }
    response.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
    response.end('<!doctype html><meta name="viewport" content="width=device-width"><title>Page outside local archive</title><body style="font:18px Georgia;background:#f5e5cc;color:#241d16;padding:48px"><h1>This page is outside the local archive.</h1><p><a href="/">Open the saved homepage</a></p><p><a href="https://models.sulat.com' + encodeURI(path).replace(/"/g, '%22') + '">Open this page on the original website</a></p>');
  } catch (error) {
    console.error('Local request:', error.message);
    if (!response.headersSent) json(response, { message: 'The local file is unavailable.' }, 500);
    else response.end();
  }
});
server.listen(port, '0.0.0.0', () => console.log(`Sulat local: http://localhost:${port}/`));
for (const signal of ['SIGINT', 'SIGTERM']) process.on(signal, () => server.close(() => process.exit(0)));
