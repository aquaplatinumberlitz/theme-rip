import { readFile } from 'node:fs/promises';
import { resolve } from 'node:path';

export const root = resolve(import.meta.dirname, '..');
export const modelPath = '/models/xai-grok-45-97244c89';
export const archivedPaths = new Set(['/', modelPath]);
const assets = JSON.parse(await readFile(resolve(root, 'reference/asset-url-map.json'), 'utf8'));
const fixtures = JSON.parse(await readFile(resolve(root, 'data/responses.json'), 'utf8'));

export function localize(value) {
  if (Array.isArray(value)) return value.map(localize);
  if (value && typeof value === 'object') return Object.fromEntries(Object.entries(value).map(([key, item]) => [key, localize(item)]));
  if (typeof value === 'string' && assets[value]) return assets[value];
  return value;
}
export async function readData(file) {
  return localize(JSON.parse(await readFile(resolve(root, 'data', file), 'utf8')));
}
export async function pageData(pathname) {
  const key = pathname === modelPath ? 'model' : 'home';
  return { key, page: await readData(`${key}.json`) };
}
function normalizeQuery(url) {
  const params = [...url.searchParams.entries()].sort(([a, b], [c, d]) => a.localeCompare(c) || b.localeCompare(d));
  return url.pathname + '?' + new URLSearchParams(params);
}
async function fixtureFor(url) {
  const key = normalizeQuery(url);
  const entry = fixtures.find((item) => normalizeQuery(new URL(item.url, 'http://local')) === key);
  return entry ? localize(JSON.parse(await readFile(resolve(root, entry.file), 'utf8'))) : undefined;
}

function resultForModel(model) {
  return {
    type: 'model', id: String(model.id), title: model.name,
    subtitle: `${model.provider.name} | ${model.modelKey}`,
    description: `${model.family || ''} | ${model.dates.releaseDate || ''} | reasoning, tool calling, structured output`,
    href: `/models/${model.slug}`, slug: model.slug,
    meta: { modelKey: model.modelKey, providerKey: model.provider.key, providerSlug: model.provider.slug, releaseDate: model.dates.releaseDate, status: model.status, capabilities: Object.keys(model.capabilities).filter((key) => model.capabilities[key]) },
  };
}
async function search(url) {
  const query = (url.searchParams.get('search') || '').trim();
  const perType = Math.min(20, Math.max(1, Number(url.searchParams.get('perType')) || 3));
  const captured = fixtures.find((item) => item.url.startsWith('/_catalog/search?'));
  const saved = captured ? JSON.parse(await readFile(resolve(root, captured.file), 'utf8')) : {};
  const detail = (await readData('model.json')).props;
  const home = (await readData('home.json')).props;
  const preferred = resultForModel(detail.model);
  const models = [preferred, ...(saved.models || []).filter((item) => item.title !== preferred.title)];
  for (const item of home.sponsoredProvider?.models || []) {
    if (models.some((model) => model.slug === item.slug)) continue;
    models.push({ type: 'model', id: String(item.id || item.slug), title: item.name, subtitle: `Synthetic | ${item.modelKey || item.name}`, description: null, href: `/models/${item.slug}`, slug: item.slug, meta: { releaseDate: item.releaseDate || null } });
  }
  const matches = (item) => !query || `${item.title} ${item.subtitle} ${item.description || ''}`.toLowerCase().includes(query.toLowerCase());
  const types = [...url.searchParams.entries()].filter(([key]) => /^types(?:\[.*\])?$/.test(key)).map(([, value]) => value);
  const enabled = types.length ? types : ['providers', 'models', 'providerProfiles'];
  const providers = home.providers.map((provider) => ({ type: 'provider', id: String(provider.id), title: provider.name, subtitle: provider.key, description: null, href: `/providers/${provider.slug}`, slug: provider.slug, meta: { providerKey: provider.key, logo: provider.logo } }));
  return {
    query, perType, types: enabled,
    providers: enabled.includes('providers') ? providers.filter(matches).slice(0, perType) : [],
    models: enabled.includes('models') ? models.filter(matches).slice(0, perType) : [],
    providerProfiles: enabled.includes('providerProfiles') ? (saved.providerProfiles || []).filter(matches).slice(0, perType) : [],
    modelNews: [],
  };
}

/** Serve captured demo content; every endpoint stays on the local filesystem. */
export async function catalogResponse(url, method) {
  const path = url.pathname;
  if (path === '/_catalog/analytics/events') return { status: 204 };
  if (path === '/_catalog/search') return { data: await search(url) };
  const exact = await fixtureFor(url);
  if (exact !== undefined) return { data: exact };
  const detail = (await readData('model.json')).props;
  if (path.endsWith('/youtube-videos')) {
    const fixture = fixtures.find((item) => item.url.endsWith('/youtube-videos'));
    return { data: fixture ? localize(JSON.parse(await readFile(resolve(root, fixture.file), 'utf8'))) : { adapter: 'youtube', query: detail.model.name, searchProviders: [], videos: [] } };
  }
  if (path.endsWith('/overview')) return { data: { ...detail.overview, sourceUrls: detail.overview.sourceUrls || [], sources: detail.overview.sources || [] } };
  if (path.endsWith('/news')) return { data: detail.news };
  if (path.endsWith('/news-refreshes')) return { data: method === 'POST' ? detail.newsRefreshes.items[0] || null : detail.newsRefreshes };
  if (path === '/_catalog/social/x/posts') return { data: { data: null } };
  if (path === '/_catalog/models') {
    const saved = fixtures.find((item) => item.url.startsWith('/_catalog/models?'));
    const sample = saved ? JSON.parse(await readFile(resolve(root, saved.file), 'utf8')) : { items: [detail.model], meta: { page: 1, itemsPerPage: 1, totalItems: 1, totalPages: 1 } };
    const slug = url.searchParams.get('slug');
    sample.items = slug === detail.model.slug ? [detail.model] : [];
    sample.meta.count = sample.items.length;
    sample.meta.visibleCount = sample.items.length;
    sample.meta.appliedQuery = { ...sample.meta.appliedQuery, slug };
    return { data: localize(sample) };
  }
  if (path === '/_catalog/providers') {
    const home = (await readData('home.json')).props;
    return { data: { items: home.providers, meta: { page: 1, itemsPerPage: 21, totalItems: home.providers.length, totalPages: 1 } } };
  }
  return { status: 404, data: { message: 'This endpoint is outside the saved demo.' } };
}

export async function pageResponse(pathname, partialKeys = '') {
  const { key, page } = await pageData(pathname);
  if (partialKeys) {
    const keys = partialKeys.split(',');
    const props = { ...page.props, ...(key === 'home' ? { news: await readData('home-news.json') } : {}) };
    page.props = Object.fromEntries(keys.filter((item) => item in props).map((item) => [item, props[item]]));
    delete page.deferredProps;
  }
  return { key, page };
}
