(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,51778,e=>{
  "use strict";
  var t=e.i(71645),r=e.i(89970),a=e.i(83495),l=e.i(91672);
  r.default.registerPlugin(a.ScrollTrigger);
  let n={autoAlpha:0,y:28,filter:"blur(8px)"},i={autoAlpha:1,y:0,filter:"blur(0px)",duration:.9,ease:"power3.out",overwrite:!0,clearProps:"all"};
  e.s(["default",0,function(){
    return(0,t.useEffect)(()=>{
      let e=r.default.matchMedia();
      return e.add("(prefers-reduced-motion: no-preference)",()=>{
        r.default.utils.toArray("[data-choreo]").forEach(e=>{
          let t=e.querySelector("[data-draw-rule]"),l=e.querySelectorAll("[data-draw-tick]"),s=e.querySelector("[data-draw-eyebrow]");
          t&&r.default.set(t,{scaleX:0}),l.length&&r.default.set(l,{scale:0,opacity:0}),s&&r.default.set(s,n),a.ScrollTrigger.create({trigger:e,start:"top 88%",once:!0,onEnter:()=>{
            let e=r.default.timeline();
            t&&e.to(t,{scaleX:1,duration:.7,ease:"power2.out",clearProps:"all"},0),s&&e.to(s,{...i},.15),l.length&&e.to(l,{scale:1,opacity:1,duration:.35,ease:"power3.out",stagger:.06,clearProps:"all"},.35)
            }})
          }),r.default.utils.toArray("[data-reveal]:not([data-reveal-group] [data-reveal])").forEach(e=>{
          r.default.set(e,n),a.ScrollTrigger.create({trigger:e,start:"top 85%",once:!0,onEnter:()=>r.default.to(e,i)})
          });
        let e=[];
        return r.default.utils.toArray("[data-reveal-group]").forEach(t=>{
          let s=Array.from(t.querySelectorAll("[data-reveal]"));
          if(!s.length)
          return;
          if(r.default.set(s,n),t.closest("#hero")){
            let t=null,a=()=>{
              t&&r.default.ticker.remove(t),r.default.set(s,n);
              let e=()=>{
                l.introClock.t<l.introTuner.read().copyAt||(r.default.to(s,{...i,stagger:.08}),r.default.ticker.remove(e),t===e&&(t=null))
                };
              t=e,r.default.ticker.add(e)
              };
            a(),e.push((0,l.onIntroReplay)(a)),e.push(()=>{
              t&&r.default.ticker.remove(t)
              });
            return
            }
          let o=t.getBoundingClientRect();
          s.forEach(e=>{
            let t=o.width>0?(e.getBoundingClientRect().left-o.left)/o.width*.18:0;
            a.ScrollTrigger.create({trigger:e,start:"top 88%",once:!0,onEnter:()=>r.default.to(e,{...i,delay:t})})
            })
          }),()=>{
          e.forEach(e=>e())
          }
        }),()=>e.revert()
      },[]),null
    }])
  },76727,e=>{
  "use strict";
  let t=(0,e.i(56420).default)("apple",[["path",{d:"M12 6.528V3a1 1 0 0 1 1-1h0",key:"11qiee"}],["path",{d:"M18.237 21A15 15 0 0 0 22 11a6 6 0 0 0-10-4.472A6 6 0 0 0 2 11a15.1 15.1 0 0 0 3.763 10 3 3 0 0 0 3.648.648 5.5 5.5 0 0 1 5.178 0A3 3 0 0 0 18.237 21",key:"110c12"}]]);
  e.s(["AppleIcon",0,t],76727)
  },94227,e=>{
  "use strict";
  let t=(0,e.i(56420).default)("arrow-down-to-line",[["path",{d:"M12 17V3",key:"1cwfxf"}],["path",{d:"m6 11 6 6 6-6",key:"12ii2o"}],["path",{d:"M19 21H5",key:"150jfl"}]]);
  e.s(["ArrowDownToLineIcon",0,t],94227)
  },55243,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645),a=e.i(76727),l=e.i(56420);
  let n=(0,l.default)("arrow-down",[["path",{d:"M12 5v14",key:"s699le"}],["path",{d:"m19 12-7 7-7-7",key:"1idqje"}]]);
  var i=e.i(94227),s=e.i(3636);
  let o=(0,l.default)("square-terminal",[["path",{d:"m7 11 2-2-2-2",key:"1lz0vl"}],["path",{d:"M11 13h4",key:"1p7l4v"}],["rect",{width:"18",height:"18",x:"3",y:"3",rx:"2",ry:"2",key:"1m3agn"}]]);
  var d=e.i(19056),c=e.i(8164);
  e.i(16787);
  var u=e.i(19455),h=e.i(76964),f=e.i(75001);
  let m=`${f.CRAFTING_APPS_GITHUB_ORG}/craft-launcher`,p={macOS:(0,t.jsx)(a.AppleIcon,{"aria-hidden":!0,className:"h-5 w-5"}),Windows:(0,t.jsx)(c.WindowsIcon,{className:"h-5 w-5"}),Linux:(0,t.jsx)(o,{"aria-hidden":!0,className:"h-5 w-5"})};
  function x({download:e,className:r}){
    return(0,t.jsxs)("a",{href:e.href,title:e.fileName,className:(0,d.twMerge)("group/file flex items-center justify-between gap-4 py-3 hover:bg-bg-sunken",r),children:[(0,t.jsxs)("span",{className:"min-w-0",children:[(0,t.jsx)("span",{className:"block text-sm text-ink",children:e.label}),(0,t.jsx)("span",{className:"block text-sm text-muted",children:e.description}),(0,t.jsx)("span",{className:"mt-1 block truncate font-mono text-[11px] text-faint",children:e.fileName})]}),(0,t.jsx)(i.ArrowDownToLineIcon,{"aria-hidden":!0,className:"h-4 w-4 shrink-0 text-muted group-hover/file:text-ink"})]})
    }
  function g(e){
    return e.endsWith(".flatpak")?1:e.endsWith(".AppImage")?2:e.endsWith(".deb")?3:e.endsWith(".rpm")?4:e.endsWith(".tar.gz")?5:6
    }
  function w(){
    let[e,t]=(0,r.useState)(null);
    return(0,r.useEffect)(()=>{
      let e;
      t((e=navigator.userAgent,/Android|iPhone|iPad|iPod|Mobile|CrOS/i.test(e)?null:/Windows/i.test(e)?{platform:"Windows"}:/Macintosh|Mac OS X/i.test(e)?navigator.maxTouchPoints>1?null:{platform:"macOS"}:/Linux/i.test(e)?{platform:"Linux",arch:/aarch64|arm64|armv8/i.test(e)?"aarch64":"x86_64"}:null))
      },[]),e
    }
  function b(e,{platform:t,arch:r}){
    let a=e.filter(e=>e.group===t&&e.recommended);
    return a.find(e=>r&&e.arch===r)??a[0]
    }
  e.s(["AppHeroDownloadButton",0,function({recommended:e,name:r}){
    let a=w(),l=a&&b(e,a);
    return(0,t.jsxs)(u.Button,{href:l?l.href:"#get-it",size:"lg",children:[(0,t.jsx)(i.ArrowDownToLineIcon,{"aria-hidden":!0,className:"h-4 w-4"}),l?`Download for ${l.group}`:`Download ${r}`]})
    },"AppHeroOtherDownloadsLink",0,function(){
    return w()?(0,t.jsxs)("a",{href:"#get-it",className:"hud-label flex items-center gap-1.5 text-muted hover:text-ink",children:["Other platforms and downloads",(0,t.jsx)(n,{"aria-hidden":!0,className:"h-3.5 w-3.5"})]}):null
    },"AppPlatformDownloads",0,function({name:e,downloads:r}){
    let a=w();
    return(0,t.jsx)("div",{className:"grid gap-px bg-line md:grid-cols-3",children:h.CRAFT_DESKTOP_PLATFORMS.map((l,n)=>{
      let s=r.filter(e=>e.group===l),o=a?.platform===l,d=b(s,o?a:{platform:l});
      if(!d)
      return null;
      let c=s.filter(e=>e!==d);
      return(0,t.jsxs)("article",{"data-reveal":!0,className:"flex min-w-0 flex-col bg-bg",children:[(0,t.jsxs)("div",{className:"flex items-center justify-between gap-4 border-b border-line px-6 py-2.5 md:px-8",children:[(0,t.jsx)("p",{className:"hud-label text-muted",children:o?(0,t.jsx)("span",{className:"text-(--app-ink,var(--accent-ink))",children:"Your system"}):"Platform"}),(0,t.jsx)("p",{className:"hud-label text-faint",children:String(n+1).padStart(2,"0")})]}),(0,t.jsxs)("div",{className:"flex flex-1 flex-col p-6 md:p-8",children:[(0,t.jsxs)("div",{className:"flex items-center gap-3",children:[(0,t.jsx)("span",{className:"flex h-10 w-10 items-center justify-center border border-line text-ink",children:p[l]}),(0,t.jsx)("h3",{className:"font-display text-2xl font-medium tracking-[-0.02em] text-ink-strong",children:l})]}),(0,t.jsx)("p",{className:"mt-5 text-sm text-ink",children:d.label}),(0,t.jsx)("p",{className:"mt-1 text-sm text-muted",children:d.description}),(0,t.jsxs)(u.Button,{href:d.href,variant:o?"primary":"secondary",className:"mt-6 w-full whitespace-normal text-center",children:[(0,t.jsx)(i.ArrowDownToLineIcon,{"aria-hidden":!0,className:"h-4 w-4"}),"Standalone for ",l]}),c.length>0&&(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("p",{className:"hud-label mt-8 text-faint",children:["Other ",e," files for ",l]}),(0,t.jsx)("ul",{className:"mt-2 border-t border-line",children:c.map(e=>(0,t.jsx)("li",{className:"border-b border-line",children:(0,t.jsx)(x,{download:e})},e.href))})]})]})]},l)
      })})
    },"DownloadRow",0,x,"LauncherDownloadButton",0,function({recommended:e,allDownloads:a,fallbackHref:l,size:n="lg",variant:o="primary",fullWidth:c=!1,className:p}){
    let x=w(),N=x&&b(e,x),[j,v]=(0,r.useState)(!1),k=(0,r.useRef)(null),[y,A]=(0,r.useState)(null);
    (0,r.useEffect)(()=>{
      if(!j)
      return;
      let e=e=>{
        k.current?.contains(e.target)||v(!1)
        },t=e=>{
        "Escape"===e.key&&v(!1)
        };
      return document.addEventListener("pointerdown",e),document.addEventListener("keydown",t),()=>{
        document.removeEventListener("pointerdown",e),document.removeEventListener("keydown",t)
        }
      },[j]);
    let L=x?.platform==="Linux",E=a??(L&&h.CRAFT_LAUNCHER_RELEASE?(0,f.releaseDownloads)(m,"artcraft-launcher",h.CRAFT_LAUNCHER_RELEASE):[]),S=L?E.filter(e=>"Linux"===e.group&&(!x.arch||!e.arch||e.arch===x.arch)):[],T=L?[...S].sort((e,t)=>g(e.fileName)-g(t.fileName)):[],D=T.find(e=>e.fileName.endsWith(".flatpak"))??N,M=y??D??N;
    if(L&&T.length>0&&M){
      let e="primary"===o;
      return(0,t.jsxs)("span",{className:(0,d.twMerge)("flex flex-col gap-2",p),children:[(0,t.jsxs)("div",{ref:k,className:(0,d.twMerge)("relative inline-flex items-stretch",c?"w-full":"w-fit"),children:[(0,t.jsxs)(u.Button,{href:M.href,size:n,variant:o,className:(0,d.twMerge)(c?"flex-1 w-full":void 0,"pr-4"),children:[(0,t.jsx)(i.ArrowDownToLineIcon,{"aria-hidden":!0,className:"h-4 w-4"}),"Download Launcher"]}),(0,t.jsx)("button",{type:"button",onClick:()=>v(e=>!e),"aria-expanded":j,"aria-haspopup":"menu","aria-label":"Other Linux download formats",className:(0,d.twMerge)("flex items-center justify-center transition-colors duration-150 cursor-pointer","lg"===n?"h-12 px-3.5":"sm"===n?"px-2 py-1.5":"px-3 py-2",e?"bg-invert-bg text-invert-fg border-l border-invert-fg/20 hover:opacity-80":"border border-line-strong border-l-0 bg-bg text-ink hover:bg-invert-bg hover:text-invert-fg"),children:(0,t.jsx)(s.ChevronDownIcon,{"aria-hidden":!0,className:(0,d.twMerge)("h-4 w-4 transition-transform duration-150",j&&"rotate-180")})}),j&&(0,t.jsxs)("div",{role:"menu",className:"absolute top-full left-0 z-50 mt-1 w-full min-w-[280px] border border-line bg-bg-raised p-1 shadow-lg text-left",children:[(0,t.jsx)("div",{className:"border-b border-line px-3 py-2",children:(0,t.jsx)("p",{className:"hud-label text-[11px] text-faint",children:"Select Linux format"})}),(0,t.jsx)("ul",{className:"flex flex-col",children:T.map(e=>{
        let r=e.fileName.endsWith(".flatpak"),a=M.fileName===e.fileName;
        return(0,t.jsx)("li",{children:(0,t.jsxs)("a",{href:e.href,download:e.fileName,role:"menuitem",onClick:()=>{
          A(e),v(!1)
          },className:(0,d.twMerge)("group/opt flex items-center justify-between gap-3 p-2.5 text-left transition-colors duration-150 hover:bg-bg-sunken",a&&"bg-ink/5"),children:[(0,t.jsxs)("span",{className:"min-w-0 flex-1",children:[(0,t.jsxs)("span",{className:"flex items-center gap-2",children:[(0,t.jsx)("span",{className:"block text-sm font-medium text-ink",children:e.label}),r&&(0,t.jsx)("span",{className:"hud-label text-[10px] text-(--app-ink,var(--accent-ink))",children:"Default"})]}),(0,t.jsx)("span",{className:"block text-xs text-muted",children:e.description}),(0,t.jsx)("span",{className:"mt-0.5 block truncate font-mono text-[10px] text-faint",children:e.fileName})]}),(0,t.jsx)(i.ArrowDownToLineIcon,{"aria-hidden":!0,className:"h-4 w-4 shrink-0 text-muted group-hover/opt:text-ink"})]})},e.href)
        })})]})]}),(0,t.jsx)("span",{"aria-hidden":!M,className:"hud-label min-h-4 w-0 min-w-full whitespace-nowrap text-faint",children:M?`For Linux \xb7 ${M.label}`:" "})]})
      }
    return(0,t.jsxs)("span",{className:(0,d.twMerge)("flex flex-col gap-2",p),children:[(0,t.jsxs)(u.Button,{href:N?N.href:l,size:n,variant:o,className:c?"w-full":void 0,children:[(0,t.jsx)(i.ArrowDownToLineIcon,{"aria-hidden":!0,className:"h-4 w-4"}),"Download Launcher"]}),(0,t.jsx)("span",{"aria-hidden":!N,className:"hud-label min-h-4 w-0 min-w-full whitespace-nowrap text-faint",children:N?`For ${N.group} \xb7 ${N.label}`:" "})]})
    }],55243)
  }]);
