(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,8560,e=>{
  "use strict";
  var n=e.i(90072);
  function t(){
    let e=null,n=!1,t=null,r=null;
    function i(n,a){
      t(n,a),r=e.requestAnimationFrame(i)
      }
    return{start:function(){
      !0===n||null===t||null!==e&&(r=e.requestAnimationFrame(i),n=!0)
      },stop:function(){
      null!==e&&e.cancelAnimationFrame(r),n=!1
      },setAnimationLoop:function(e){
      t=e
      },setContext:function(n){
      e=n
      }}
    }
  function r(e){
    let n=new WeakMap;
    return{get:function(e){
      return e.isInterleavedBufferAttribute&&(e=e.data),n.get(e)
      },remove:function(t){
      t.isInterleavedBufferAttribute&&(t=t.data);
      let r=n.get(t);
      r&&(e.deleteBuffer(r.buffer),n.delete(t))
      },update:function(t,r){
      if(t.isInterleavedBufferAttribute&&(t=t.data),t.isGLBufferAttribute){
        let e=n.get(t);
        (!e||e.version<t.version)&&n.set(t,{buffer:t.buffer,type:t.type,bytesPerElement:t.elementSize,version:t.version});
        return
        }
      let i=n.get(t);
      if(void 0===i)
      n.set(t,function(n,t){
        let r,i=n.array,a=n.usage,o=i.byteLength,l=e.createBuffer();
        if(e.bindBuffer(t,l),e.bufferData(t,i,a),n.onUploadCallback(),i instanceof Float32Array)
        r=e.FLOAT;
        else 
        if("u">typeof Float16Array&&i instanceof Float16Array)
        r=e.HALF_FLOAT;
        else 
        if(i instanceof Uint16Array)
        r=n.isFloat16BufferAttribute?e.HALF_FLOAT:e.UNSIGNED_SHORT;
        else 
        if(i instanceof Int16Array)
        r=e.SHORT;
        else 
        if(i instanceof Uint32Array)
        r=e.UNSIGNED_INT;
        else 
        if(i instanceof Int32Array)
        r=e.INT;
        else 
        if(i instanceof Int8Array)
        r=e.BYTE;
        else 
        if(i instanceof Uint8Array)
        r=e.UNSIGNED_BYTE;
        else 
        if(i instanceof Uint8ClampedArray)
        r=e.UNSIGNED_BYTE;
        else 
        throw Error("THREE.WebGLAttributes: Unsupported buffer data format: "+i);
        return{buffer:l,type:r,bytesPerElement:i.BYTES_PER_ELEMENT,version:n.version,size:o}
        }(t,r));
      else 
      if(i.version<t.version){
        if(i.size!==t.array.byteLength)
        throw Error("THREE.WebGLAttributes: The size of the buffer attribute's array buffer does not match the original size. Resizing buffer attributes is not supported.");
        !function(n,t,r){
          let i=t.array,a=t.updateRanges;
          if(e.bindBuffer(r,n),0===a.length)
          e.bufferSubData(r,0,i);
          else{
            a.sort((e,n)=>e.start-n.start);
            let n=0;
            for(
            let e=1
            ;e<a.length;e++){
              let t=a[n],r=a[e];
              r.start<=t.start+t.count+1?t.count=Math.max(t.count,r.start+r.count-t.start):a[++n]=r
              }
            a.length=n+1;
            for(
            let n=0,t=a.length
            ;n<t;n++){
              let t=a[n];
              e.bufferSubData(r,t.start*i.BYTES_PER_ELEMENT,i,t.start,t.count)
              }
            t.clearUpdateRanges()
            }
          t.onUploadCallback()
          }(i.buffer,t,r),i.version=t.version
        }
      }}
    }
  let i={alphahash_fragment:"#ifdef USE_ALPHAHASH\n	if ( diffuseColor.a < getAlphaHashThreshold( vPosition ) ) discard;\n#endif",alphahash_pars_fragment:"#ifdef USE_ALPHAHASH\n	const float ALPHA_HASH_SCALE = 0.05;\n	float hash2D( vec2 value ) {\n		return fract( 1.0e4 * sin( 17.0 * value.x + 0.1 * value.y ) * ( 0.1 + abs( sin( 13.0 * value.y + value.x ) ) ) );\n	}\n	float hash3D( vec3 value ) {\n		return hash2D( vec2( hash2D( value.xy ), value.z ) );\n	}\n	float getAlphaHashThreshold( vec3 position ) {\n		float maxDeriv = max(\n			length( dFdx( position.xyz ) ),\n			length( dFdy( position.xyz ) )\n		);\n		float pixScale = 1.0 / ( ALPHA_HASH_SCALE * maxDeriv );\n		vec2 pixScales = vec2(\n			exp2( floor( log2( pixScale ) ) ),\n			exp2( ceil( log2( pixScale ) ) )\n		);\n		vec2 alpha = vec2(\n			hash3D( floor( pixScales.x * position.xyz ) ),\n			hash3D( floor( pixScales.y * position.xyz ) )\n		);\n		float lerpFactor = fract( log2( pixScale ) );\n		float x = ( 1.0 - lerpFactor ) * alpha.x + lerpFactor * alpha.y;\n		float a = min( lerpFactor, 1.0 - lerpFactor );\n		vec3 cases = vec3(\n			x * x / ( 2.0 * a * ( 1.0 - a ) ),\n			( x - 0.5 * a ) / ( 1.0 - a ),\n			1.0 - ( ( 1.0 - x ) * ( 1.0 - x ) / ( 2.0 * a * ( 1.0 - a ) ) )\n		);\n		float threshold = ( x < ( 1.0 - a ) )\n			? ( ( x < a ) ? cases.x : cases.y )\n			: cases.z;\n		return clamp( threshold , 1.0e-6, 1.0 );\n	}\n#endif",alphamap_fragment:"#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, vAlphaMapUv ).g;\n#endif",alphamap_pars_fragment:"#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",alphatest_fragment:"#ifdef USE_ALPHATEST\n	#ifdef ALPHA_TO_COVERAGE\n	diffuseColor.a = smoothstep( alphaTest, alphaTest + fwidth( diffuseColor.a ), diffuseColor.a );\n	if ( diffuseColor.a == 0.0 ) discard;\n	#else\n	if ( diffuseColor.a < alphaTest ) discard;\n	#endif\n#endif",alphatest_pars_fragment:"#ifdef USE_ALPHATEST\n	uniform float alphaTest;\n#endif",aomap_fragment:"#ifdef USE_AOMAP\n	float ambientOcclusion = ( texture2D( aoMap, vAoMapUv ).r - 1.0 ) * aoMapIntensity + 1.0;\n	reflectedLight.indirectDiffuse *= ambientOcclusion;\n	#if defined( USE_CLEARCOAT ) \n		clearcoatSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_SHEEN ) \n		sheenSpecularIndirect *= ambientOcclusion;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( STANDARD )\n		float dotNV = saturate( dot( geometryNormal, geometryViewDir ) );\n		reflectedLight.indirectSpecular *= computeSpecularOcclusion( dotNV, ambientOcclusion, material.roughness );\n	#endif\n#endif",aomap_pars_fragment:"#ifdef USE_AOMAP\n	uniform sampler2D aoMap;\n	uniform float aoMapIntensity;\n#endif",batching_pars_vertex:"#ifdef USE_BATCHING\n	#if ! defined( GL_ANGLE_multi_draw )\n	#define gl_DrawID _gl_DrawID\n	uniform int _gl_DrawID;\n	#endif\n	uniform highp sampler2D batchingTexture;\n	uniform highp usampler2D batchingIdTexture;\n	mat4 getBatchingMatrix( const in float i ) {\n		int size = textureSize( batchingTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( batchingTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( batchingTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( batchingTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( batchingTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n	float getIndirectIndex( const in int i ) {\n		int size = textureSize( batchingIdTexture, 0 ).x;\n		int x = i % size;\n		int y = i / size;\n		return float( texelFetch( batchingIdTexture, ivec2( x, y ), 0 ).r );\n	}\n#endif\n#ifdef USE_BATCHING_COLOR\n	uniform sampler2D batchingColorTexture;\n	vec4 getBatchingColor( const in float i ) {\n		int size = textureSize( batchingColorTexture, 0 ).x;\n		int j = int( i );\n		int x = j % size;\n		int y = j / size;\n		return texelFetch( batchingColorTexture, ivec2( x, y ), 0 );\n	}\n#endif",batching_vertex:"#ifdef USE_BATCHING\n	mat4 batchingMatrix = getBatchingMatrix( getIndirectIndex( gl_DrawID ) );\n#endif",begin_vertex:"vec3 transformed = vec3( position );\n#ifdef USE_ALPHAHASH\n	vPosition = vec3( position );\n#endif",beginnormal_vertex:"vec3 objectNormal = vec3( normal );\n#ifdef USE_TANGENT\n	vec3 objectTangent = vec3( tangent.xyz );\n#endif",bsdfs:"float G_BlinnPhong_Implicit( ) {\n	return 0.25;\n}\nfloat D_BlinnPhong( const in float shininess, const in float dotNH ) {\n	return RECIPROCAL_PI * ( shininess * 0.5 + 1.0 ) * pow( dotNH, shininess );\n}\nvec3 BRDF_BlinnPhong( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in vec3 specularColor, const in float shininess ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( specularColor, 1.0, dotVH );\n	float G = G_BlinnPhong_Implicit( );\n	float D = D_BlinnPhong( shininess, dotNH );\n	return F * ( G * D );\n} // validated",iridescence_fragment:"#ifdef USE_IRIDESCENCE\n	const mat3 XYZ_TO_REC709 = mat3(\n		 3.2404542, -0.9692660,  0.0556434,\n		-1.5371385,  1.8760108, -0.2040259,\n		-0.4985314,  0.0415560,  1.0572252\n	);\n	vec3 Fresnel0ToIor( vec3 fresnel0 ) {\n		vec3 sqrtF0 = sqrt( fresnel0 );\n		return ( vec3( 1.0 ) + sqrtF0 ) / ( vec3( 1.0 ) - sqrtF0 );\n	}\n	vec3 IorToFresnel0( vec3 transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - vec3( incidentIor ) ) / ( transmittedIor + vec3( incidentIor ) ) );\n	}\n	float IorToFresnel0( float transmittedIor, float incidentIor ) {\n		return pow2( ( transmittedIor - incidentIor ) / ( transmittedIor + incidentIor ));\n	}\n	vec3 evalSensitivity( float OPD, vec3 shift ) {\n		float phase = 2.0 * PI * OPD * 1.0e-9;\n		vec3 val = vec3( 5.4856e-13, 4.4201e-13, 5.2481e-13 );\n		vec3 pos = vec3( 1.6810e+06, 1.7953e+06, 2.2084e+06 );\n		vec3 var = vec3( 4.3278e+09, 9.3046e+09, 6.6121e+09 );\n		vec3 xyz = val * sqrt( 2.0 * PI * var ) * cos( pos * phase + shift ) * exp( - pow2( phase ) * var );\n		xyz.x += 9.7470e-14 * sqrt( 2.0 * PI * 4.5282e+09 ) * cos( 2.2399e+06 * phase + shift[ 0 ] ) * exp( - 4.5282e+09 * pow2( phase ) );\n		xyz /= 1.0685e-7;\n		vec3 rgb = XYZ_TO_REC709 * xyz;\n		return rgb;\n	}\n	vec3 evalIridescence( float outsideIOR, float eta2, float cosTheta1, float thinFilmThickness, vec3 baseF0 ) {\n		vec3 I;\n		float iridescenceIOR = mix( outsideIOR, eta2, smoothstep( 0.0, 0.03, thinFilmThickness ) );\n		float sinTheta2Sq = pow2( outsideIOR / iridescenceIOR ) * ( 1.0 - pow2( cosTheta1 ) );\n		float cosTheta2Sq = 1.0 - sinTheta2Sq;\n		if ( cosTheta2Sq < 0.0 ) {\n			return vec3( 1.0 );\n		}\n		float cosTheta2 = sqrt( cosTheta2Sq );\n		float R0 = IorToFresnel0( iridescenceIOR, outsideIOR );\n		float R12 = F_Schlick( R0, 1.0, cosTheta1 );\n		float T121 = 1.0 - R12;\n		float phi12 = 0.0;\n		if ( iridescenceIOR < outsideIOR ) phi12 = PI;\n		float phi21 = PI - phi12;\n		vec3 baseIOR = Fresnel0ToIor( clamp( baseF0, 0.0, 0.9999 ) );		vec3 R1 = IorToFresnel0( baseIOR, iridescenceIOR );\n		vec3 R23 = F_Schlick( R1, 1.0, cosTheta2 );\n		vec3 phi23 = vec3( 0.0 );\n		if ( baseIOR[ 0 ] < iridescenceIOR ) phi23[ 0 ] = PI;\n		if ( baseIOR[ 1 ] < iridescenceIOR ) phi23[ 1 ] = PI;\n		if ( baseIOR[ 2 ] < iridescenceIOR ) phi23[ 2 ] = PI;\n		float OPD = 2.0 * iridescenceIOR * thinFilmThickness * cosTheta2;\n		vec3 phi = vec3( phi21 ) + phi23;\n		vec3 R123 = clamp( R12 * R23, 1e-5, 0.9999 );\n		vec3 r123 = sqrt( R123 );\n		vec3 Rs = pow2( T121 ) * R23 / ( vec3( 1.0 ) - R123 );\n		vec3 C0 = R12 + Rs;\n		I = C0;\n		vec3 Cm = Rs - T121;\n		for ( int m = 1; m <= 2; ++ m ) {\n			Cm *= r123;\n			vec3 Sm = 2.0 * evalSensitivity( float( m ) * OPD, float( m ) * phi );\n			I += Cm * Sm;\n		}\n		return max( I, vec3( 0.0 ) );\n	}\n#endif",bumpmap_pars_fragment:"#ifdef USE_BUMPMAP\n	uniform sampler2D bumpMap;\n	uniform float bumpScale;\n	vec2 dHdxy_fwd() {\n		vec2 dSTdx = dFdx( vBumpMapUv );\n		vec2 dSTdy = dFdy( vBumpMapUv );\n		float Hll = bumpScale * texture2D( bumpMap, vBumpMapUv ).x;\n		float dBx = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdx ).x - Hll;\n		float dBy = bumpScale * texture2D( bumpMap, vBumpMapUv + dSTdy ).x - Hll;\n		return vec2( dBx, dBy );\n	}\n	vec3 perturbNormalArb( vec3 surf_pos, vec3 surf_norm, vec2 dHdxy, float faceDirection ) {\n		vec3 vSigmaX = normalize( dFdx( surf_pos.xyz ) );\n		vec3 vSigmaY = normalize( dFdy( surf_pos.xyz ) );\n		vec3 vN = surf_norm;\n		vec3 R1 = cross( vSigmaY, vN );\n		vec3 R2 = cross( vN, vSigmaX );\n		float fDet = dot( vSigmaX, R1 ) * faceDirection;\n		vec3 vGrad = sign( fDet ) * ( dHdxy.x * R1 + dHdxy.y * R2 );\n		return normalize( abs( fDet ) * surf_norm - vGrad );\n	}\n#endif",clipping_planes_fragment:"#if NUM_CLIPPING_PLANES > 0\n	vec4 plane;\n	#ifdef ALPHA_TO_COVERAGE\n		float distanceToPlane, distanceGradient;\n		float clipOpacity = 1.0;\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n			distanceGradient = fwidth( distanceToPlane ) / 2.0;\n			clipOpacity *= smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			if ( clipOpacity == 0.0 ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			float unionClipOpacity = 1.0;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				distanceToPlane = - dot( vClipPosition, plane.xyz ) + plane.w;\n				distanceGradient = fwidth( distanceToPlane ) / 2.0;\n				unionClipOpacity *= 1.0 - smoothstep( - distanceGradient, distanceGradient, distanceToPlane );\n			}\n			#pragma unroll_loop_end\n			clipOpacity *= 1.0 - unionClipOpacity;\n		#endif\n		diffuseColor.a *= clipOpacity;\n		if ( diffuseColor.a == 0.0 ) discard;\n	#else\n		#pragma unroll_loop_start\n		for ( int i = 0; i < UNION_CLIPPING_PLANES; i ++ ) {\n			plane = clippingPlanes[ i ];\n			if ( dot( vClipPosition, plane.xyz ) > plane.w ) discard;\n		}\n		#pragma unroll_loop_end\n		#if UNION_CLIPPING_PLANES < NUM_CLIPPING_PLANES\n			bool clipped = true;\n			#pragma unroll_loop_start\n			for ( int i = UNION_CLIPPING_PLANES; i < NUM_CLIPPING_PLANES; i ++ ) {\n				plane = clippingPlanes[ i ];\n				clipped = ( dot( vClipPosition, plane.xyz ) > plane.w ) && clipped;\n			}\n			#pragma unroll_loop_end\n			if ( clipped ) discard;\n		#endif\n	#endif\n#endif",clipping_planes_pars_fragment:"#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n	uniform vec4 clippingPlanes[ NUM_CLIPPING_PLANES ];\n#endif",clipping_planes_pars_vertex:"#if NUM_CLIPPING_PLANES > 0\n	varying vec3 vClipPosition;\n#endif",clipping_planes_vertex:"#if NUM_CLIPPING_PLANES > 0\n	vClipPosition = - mvPosition.xyz;\n#endif",color_fragment:"#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\n	diffuseColor *= vColor;\n#endif",color_pars_fragment:"#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA )\n	varying vec4 vColor;\n#endif",color_pars_vertex:"#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	varying vec4 vColor;\n#endif",color_vertex:"#if defined( USE_COLOR ) || defined( USE_COLOR_ALPHA ) || defined( USE_INSTANCING_COLOR ) || defined( USE_BATCHING_COLOR )\n	vColor = vec4( 1.0 );\n#endif\n#ifdef USE_COLOR_ALPHA\n	vColor *= color;\n#elif defined( USE_COLOR )\n	vColor.rgb *= color;\n#endif\n#ifdef USE_INSTANCING_COLOR\n	vColor.rgb *= instanceColor.rgb;\n#endif\n#ifdef USE_BATCHING_COLOR\n	vColor *= getBatchingColor( getIndirectIndex( gl_DrawID ) );\n#endif",common:"#define PI 3.141592653589793\n#define PI2 6.283185307179586\n#define PI_HALF 1.5707963267948966\n#define RECIPROCAL_PI 0.3183098861837907\n#define RECIPROCAL_PI2 0.15915494309189535\n#define EPSILON 1e-6\n#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\n#define whiteComplement( a ) ( 1.0 - saturate( a ) )\nfloat pow2( const in float x ) { return x*x; }\nvec3 pow2( const in vec3 x ) { return x*x; }\nfloat pow3( const in float x ) { return x*x*x; }\nfloat pow4( const in float x ) { float x2 = x*x; return x2*x2; }\nfloat max3( const in vec3 v ) { return max( max( v.x, v.y ), v.z ); }\nfloat average( const in vec3 v ) { return dot( v, vec3( 0.3333333 ) ); }\nhighp float rand( const in vec2 uv ) {\n	const highp float a = 12.9898, b = 78.233, c = 43758.5453;\n	highp float dt = dot( uv.xy, vec2( a,b ) ), sn = mod( dt, PI );\n	return fract( sin( sn ) * c );\n}\n#ifdef HIGH_PRECISION\n	float precisionSafeLength( vec3 v ) { return length( v ); }\n#else\n	float precisionSafeLength( vec3 v ) {\n		float maxComponent = max3( abs( v ) );\n		return length( v / maxComponent ) * maxComponent;\n	}\n#endif\nstruct IncidentLight {\n	vec3 color;\n	vec3 direction;\n	bool visible;\n};\nstruct ReflectedLight {\n	vec3 directDiffuse;\n	vec3 directSpecular;\n	vec3 indirectDiffuse;\n	vec3 indirectSpecular;\n};\n#ifdef USE_ALPHAHASH\n	varying vec3 vPosition;\n#endif\nvec3 transformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );\n}\nvec3 inverseTransformDirection( in vec3 dir, in mat4 matrix ) {\n	return normalize( ( vec4( dir, 0.0 ) * matrix ).xyz );\n}\nbool isPerspectiveMatrix( mat4 m ) {\n	return m[ 2 ][ 3 ] == - 1.0;\n}\nvec2 equirectUv( in vec3 dir ) {\n	float u = atan( dir.z, dir.x ) * RECIPROCAL_PI2 + 0.5;\n	float v = asin( clamp( dir.y, - 1.0, 1.0 ) ) * RECIPROCAL_PI + 0.5;\n	return vec2( u, v );\n}\nvec3 BRDF_Lambert( const in vec3 diffuseColor ) {\n	return RECIPROCAL_PI * diffuseColor;\n}\nvec3 F_Schlick( const in vec3 f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n}\nfloat F_Schlick( const in float f0, const in float f90, const in float dotVH ) {\n	float fresnel = exp2( ( - 5.55473 * dotVH - 6.98316 ) * dotVH );\n	return f0 * ( 1.0 - fresnel ) + ( f90 * fresnel );\n} // validated",cube_uv_reflection_fragment:"#ifdef ENVMAP_TYPE_CUBE_UV\n	#define cubeUV_minMipLevel 4.0\n	#define cubeUV_minTileSize 16.0\n	float getFace( vec3 direction ) {\n		vec3 absDirection = abs( direction );\n		float face = - 1.0;\n		if ( absDirection.x > absDirection.z ) {\n			if ( absDirection.x > absDirection.y )\n				face = direction.x > 0.0 ? 0.0 : 3.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		} else {\n			if ( absDirection.z > absDirection.y )\n				face = direction.z > 0.0 ? 2.0 : 5.0;\n			else\n				face = direction.y > 0.0 ? 1.0 : 4.0;\n		}\n		return face;\n	}\n	vec2 getUV( vec3 direction, float face ) {\n		vec2 uv;\n		if ( face == 0.0 ) {\n			uv = vec2( direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 1.0 ) {\n			uv = vec2( - direction.x, - direction.z ) / abs( direction.y );\n		} else if ( face == 2.0 ) {\n			uv = vec2( - direction.x, direction.y ) / abs( direction.z );\n		} else if ( face == 3.0 ) {\n			uv = vec2( - direction.z, direction.y ) / abs( direction.x );\n		} else if ( face == 4.0 ) {\n			uv = vec2( - direction.x, direction.z ) / abs( direction.y );\n		} else {\n			uv = vec2( direction.x, direction.y ) / abs( direction.z );\n		}\n		return 0.5 * ( uv + 1.0 );\n	}\n	vec3 bilinearCubeUV( sampler2D envMap, vec3 direction, float mipInt ) {\n		float face = getFace( direction );\n		float filterInt = max( cubeUV_minMipLevel - mipInt, 0.0 );\n		mipInt = max( mipInt, cubeUV_minMipLevel );\n		float faceSize = exp2( mipInt );\n		highp vec2 uv = getUV( direction, face ) * ( faceSize - 2.0 ) + 1.0;\n		if ( face > 2.0 ) {\n			uv.y += faceSize;\n			face -= 3.0;\n		}\n		uv.x += face * faceSize;\n		uv.x += filterInt * 3.0 * cubeUV_minTileSize;\n		uv.y += 4.0 * ( exp2( CUBEUV_MAX_MIP ) - faceSize );\n		uv.x *= CUBEUV_TEXEL_WIDTH;\n		uv.y *= CUBEUV_TEXEL_HEIGHT;\n		#ifdef texture2DGradEXT\n			return texture2DGradEXT( envMap, uv, vec2( 0.0 ), vec2( 0.0 ) ).rgb;\n		#else\n			return texture2D( envMap, uv ).rgb;\n		#endif\n	}\n	#define cubeUV_r0 1.0\n	#define cubeUV_m0 - 2.0\n	#define cubeUV_r1 0.8\n	#define cubeUV_m1 - 1.0\n	#define cubeUV_r4 0.4\n	#define cubeUV_m4 2.0\n	#define cubeUV_r5 0.305\n	#define cubeUV_m5 3.0\n	#define cubeUV_r6 0.21\n	#define cubeUV_m6 4.0\n	float roughnessToMip( float roughness ) {\n		float mip = 0.0;\n		if ( roughness >= cubeUV_r1 ) {\n			mip = ( cubeUV_r0 - roughness ) * ( cubeUV_m1 - cubeUV_m0 ) / ( cubeUV_r0 - cubeUV_r1 ) + cubeUV_m0;\n		} else if ( roughness >= cubeUV_r4 ) {\n			mip = ( cubeUV_r1 - roughness ) * ( cubeUV_m4 - cubeUV_m1 ) / ( cubeUV_r1 - cubeUV_r4 ) + cubeUV_m1;\n		} else if ( roughness >= cubeUV_r5 ) {\n			mip = ( cubeUV_r4 - roughness ) * ( cubeUV_m5 - cubeUV_m4 ) / ( cubeUV_r4 - cubeUV_r5 ) + cubeUV_m4;\n		} else if ( roughness >= cubeUV_r6 ) {\n			mip = ( cubeUV_r5 - roughness ) * ( cubeUV_m6 - cubeUV_m5 ) / ( cubeUV_r5 - cubeUV_r6 ) + cubeUV_m5;\n		} else {\n			mip = - 2.0 * log2( 1.16 * roughness );		}\n		return mip;\n	}\n	vec4 textureCubeUV( sampler2D envMap, vec3 sampleDir, float roughness ) {\n		float mip = clamp( roughnessToMip( roughness ), cubeUV_m0, CUBEUV_MAX_MIP );\n		float mipF = fract( mip );\n		float mipInt = floor( mip );\n		vec3 color0 = bilinearCubeUV( envMap, sampleDir, mipInt );\n		if ( mipF == 0.0 ) {\n			return vec4( color0, 1.0 );\n		} else {\n			vec3 color1 = bilinearCubeUV( envMap, sampleDir, mipInt + 1.0 );\n			return vec4( mix( color0, color1, mipF ), 1.0 );\n		}\n	}\n#endif",defaultnormal_vertex:"vec3 transformedNormal = objectNormal;\n#ifdef USE_TANGENT\n	vec3 transformedTangent = objectTangent;\n#endif\n#ifdef USE_BATCHING\n	mat3 bm = mat3( batchingMatrix );\n	transformedNormal /= vec3( dot( bm[ 0 ], bm[ 0 ] ), dot( bm[ 1 ], bm[ 1 ] ), dot( bm[ 2 ], bm[ 2 ] ) );\n	transformedNormal = bm * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = bm * transformedTangent;\n	#endif\n#endif\n#ifdef USE_INSTANCING\n	mat3 im = mat3( instanceMatrix );\n	transformedNormal /= vec3( dot( im[ 0 ], im[ 0 ] ), dot( im[ 1 ], im[ 1 ] ), dot( im[ 2 ], im[ 2 ] ) );\n	transformedNormal = im * transformedNormal;\n	#ifdef USE_TANGENT\n		transformedTangent = im * transformedTangent;\n	#endif\n#endif\ntransformedNormal = normalMatrix * transformedNormal;\n#ifdef FLIP_SIDED\n	transformedNormal = - transformedNormal;\n#endif\n#ifdef USE_TANGENT\n	transformedTangent = ( modelViewMatrix * vec4( transformedTangent, 0.0 ) ).xyz;\n	#ifdef FLIP_SIDED\n		transformedTangent = - transformedTangent;\n	#endif\n#endif",displacementmap_pars_vertex:"#ifdef USE_DISPLACEMENTMAP\n	uniform sampler2D displacementMap;\n	uniform float displacementScale;\n	uniform float displacementBias;\n#endif",displacementmap_vertex:"#ifdef USE_DISPLACEMENTMAP\n	transformed += normalize( objectNormal ) * ( texture2D( displacementMap, vDisplacementMapUv ).x * displacementScale + displacementBias );\n#endif",emissivemap_fragment:"#ifdef USE_EMISSIVEMAP\n	vec4 emissiveColor = texture2D( emissiveMap, vEmissiveMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE_EMISSIVE\n		emissiveColor = sRGBTransferEOTF( emissiveColor );\n	#endif\n	totalEmissiveRadiance *= emissiveColor.rgb;\n#endif",emissivemap_pars_fragment:"#ifdef USE_EMISSIVEMAP\n	uniform sampler2D emissiveMap;\n#endif",colorspace_fragment:"gl_FragColor = linearToOutputTexel( gl_FragColor );",colorspace_pars_fragment:"vec4 LinearTransferOETF( in vec4 value ) {\n	return value;\n}\nvec4 sRGBTransferEOTF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), value.rgb * 0.0773993808, vec3( lessThanEqual( value.rgb, vec3( 0.04045 ) ) ) ), value.a );\n}\nvec4 sRGBTransferOETF( in vec4 value ) {\n	return vec4( mix( pow( value.rgb, vec3( 0.41666 ) ) * 1.055 - vec3( 0.055 ), value.rgb * 12.92, vec3( lessThanEqual( value.rgb, vec3( 0.0031308 ) ) ) ), value.a );\n}",envmap_fragment:"#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vec3 cameraToFrag;\n		if ( isOrthographic ) {\n			cameraToFrag = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToFrag = normalize( vWorldPosition - cameraPosition );\n		}\n		vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vec3 reflectVec = reflect( cameraToFrag, worldNormal );\n		#else\n			vec3 reflectVec = refract( cameraToFrag, worldNormal, refractionRatio );\n		#endif\n	#else\n		vec3 reflectVec = vReflect;\n	#endif\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 envColor = textureCube( envMap, envMapRotation * reflectVec );\n		#ifdef ENVMAP_BLENDING_MULTIPLY\n			outgoingLight = mix( outgoingLight, outgoingLight * envColor.xyz, specularStrength * reflectivity );\n		#elif defined( ENVMAP_BLENDING_MIX )\n			outgoingLight = mix( outgoingLight, envColor.xyz, specularStrength * reflectivity );\n		#elif defined( ENVMAP_BLENDING_ADD )\n			outgoingLight += envColor.xyz * specularStrength * reflectivity;\n		#endif\n	#endif\n#endif",envmap_common_pars_fragment:"#ifdef USE_ENVMAP\n	uniform float envMapIntensity;\n	uniform mat3 envMapRotation;\n	#ifdef ENVMAP_TYPE_CUBE\n		uniform samplerCube envMap;\n	#else\n		uniform sampler2D envMap;\n	#endif\n#endif",envmap_pars_fragment:"#ifdef USE_ENVMAP\n	uniform float reflectivity;\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		varying vec3 vWorldPosition;\n		uniform float refractionRatio;\n	#else\n		varying vec3 vReflect;\n	#endif\n#endif",envmap_pars_vertex:"#ifdef USE_ENVMAP\n	#if defined( USE_BUMPMAP ) || defined( USE_NORMALMAP ) || defined( PHONG ) || defined( LAMBERT )\n		#define ENV_WORLDPOS\n	#endif\n	#ifdef ENV_WORLDPOS\n		\n		varying vec3 vWorldPosition;\n	#else\n		varying vec3 vReflect;\n		uniform float refractionRatio;\n	#endif\n#endif",envmap_physical_pars_fragment:"#ifdef USE_ENVMAP\n	vec3 getIBLIrradiance( const in vec3 normal ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * worldNormal, 1.0 );\n			return PI * envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	vec3 getIBLRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness ) {\n		#ifdef ENVMAP_TYPE_CUBE_UV\n			vec3 reflectVec = reflect( - viewDir, normal );\n			reflectVec = normalize( mix( reflectVec, normal, pow4( roughness ) ) );\n			reflectVec = inverseTransformDirection( reflectVec, viewMatrix );\n			vec4 envMapColor = textureCubeUV( envMap, envMapRotation * reflectVec, roughness );\n			return envMapColor.rgb * envMapIntensity;\n		#else\n			return vec3( 0.0 );\n		#endif\n	}\n	#ifdef USE_ANISOTROPY\n		vec3 getIBLAnisotropyRadiance( const in vec3 viewDir, const in vec3 normal, const in float roughness, const in vec3 bitangent, const in float anisotropy ) {\n			#ifdef ENVMAP_TYPE_CUBE_UV\n				vec3 bentNormal = cross( bitangent, viewDir );\n				bentNormal = normalize( cross( bentNormal, bitangent ) );\n				bentNormal = normalize( mix( bentNormal, normal, pow2( pow2( 1.0 - anisotropy * ( 1.0 - roughness ) ) ) ) );\n				return getIBLRadiance( viewDir, bentNormal, roughness );\n			#else\n				return vec3( 0.0 );\n			#endif\n		}\n	#endif\n#endif",envmap_vertex:"#ifdef USE_ENVMAP\n	#ifdef ENV_WORLDPOS\n		vWorldPosition = worldPosition.xyz;\n	#else\n		vec3 cameraToVertex;\n		if ( isOrthographic ) {\n			cameraToVertex = normalize( vec3( - viewMatrix[ 0 ][ 2 ], - viewMatrix[ 1 ][ 2 ], - viewMatrix[ 2 ][ 2 ] ) );\n		} else {\n			cameraToVertex = normalize( worldPosition.xyz - cameraPosition );\n		}\n		vec3 worldNormal = inverseTransformDirection( transformedNormal, viewMatrix );\n		#ifdef ENVMAP_MODE_REFLECTION\n			vReflect = reflect( cameraToVertex, worldNormal );\n		#else\n			vReflect = refract( cameraToVertex, worldNormal, refractionRatio );\n		#endif\n	#endif\n#endif",fog_vertex:"#ifdef USE_FOG\n	vFogDepth = - mvPosition.z;\n#endif",fog_pars_vertex:"#ifdef USE_FOG\n	varying float vFogDepth;\n#endif",fog_fragment:"#ifdef USE_FOG\n	#ifdef FOG_EXP2\n		float fogFactor = 1.0 - exp( - fogDensity * fogDensity * vFogDepth * vFogDepth );\n	#else\n		float fogFactor = smoothstep( fogNear, fogFar, vFogDepth );\n	#endif\n	gl_FragColor.rgb = mix( gl_FragColor.rgb, fogColor, fogFactor );\n#endif",fog_pars_fragment:"#ifdef USE_FOG\n	uniform vec3 fogColor;\n	varying float vFogDepth;\n	#ifdef FOG_EXP2\n		uniform float fogDensity;\n	#else\n		uniform float fogNear;\n		uniform float fogFar;\n	#endif\n#endif",gradientmap_pars_fragment:"#ifdef USE_GRADIENTMAP\n	uniform sampler2D gradientMap;\n#endif\nvec3 getGradientIrradiance( vec3 normal, vec3 lightDirection ) {\n	float dotNL = dot( normal, lightDirection );\n	vec2 coord = vec2( dotNL * 0.5 + 0.5, 0.0 );\n	#ifdef USE_GRADIENTMAP\n		return vec3( texture2D( gradientMap, coord ).r );\n	#else\n		vec2 fw = fwidth( coord ) * 0.5;\n		return mix( vec3( 0.7 ), vec3( 1.0 ), smoothstep( 0.7 - fw.x, 0.7 + fw.x, coord.x ) );\n	#endif\n}",lightmap_pars_fragment:"#ifdef USE_LIGHTMAP\n	uniform sampler2D lightMap;\n	uniform float lightMapIntensity;\n#endif",lights_lambert_fragment:"LambertMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularStrength = specularStrength;",lights_lambert_pars_fragment:"varying vec3 vViewPosition;\nstruct LambertMaterial {\n	vec3 diffuseColor;\n	float specularStrength;\n};\nvoid RE_Direct_Lambert( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Lambert( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in LambertMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Lambert\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Lambert",lights_pars_begin:"uniform bool receiveShadow;\nuniform vec3 ambientLightColor;\n#if defined( USE_LIGHT_PROBES )\n	uniform vec3 lightProbe[ 9 ];\n#endif\nvec3 shGetIrradianceAt( in vec3 normal, in vec3 shCoefficients[ 9 ] ) {\n	float x = normal.x, y = normal.y, z = normal.z;\n	vec3 result = shCoefficients[ 0 ] * 0.886227;\n	result += shCoefficients[ 1 ] * 2.0 * 0.511664 * y;\n	result += shCoefficients[ 2 ] * 2.0 * 0.511664 * z;\n	result += shCoefficients[ 3 ] * 2.0 * 0.511664 * x;\n	result += shCoefficients[ 4 ] * 2.0 * 0.429043 * x * y;\n	result += shCoefficients[ 5 ] * 2.0 * 0.429043 * y * z;\n	result += shCoefficients[ 6 ] * ( 0.743125 * z * z - 0.247708 );\n	result += shCoefficients[ 7 ] * 2.0 * 0.429043 * x * z;\n	result += shCoefficients[ 8 ] * 0.429043 * ( x * x - y * y );\n	return result;\n}\nvec3 getLightProbeIrradiance( const in vec3 lightProbe[ 9 ], const in vec3 normal ) {\n	vec3 worldNormal = inverseTransformDirection( normal, viewMatrix );\n	vec3 irradiance = shGetIrradianceAt( worldNormal, lightProbe );\n	return irradiance;\n}\nvec3 getAmbientLightIrradiance( const in vec3 ambientLightColor ) {\n	vec3 irradiance = ambientLightColor;\n	return irradiance;\n}\nfloat getDistanceAttenuation( const in float lightDistance, const in float cutoffDistance, const in float decayExponent ) {\n	float distanceFalloff = 1.0 / max( pow( lightDistance, decayExponent ), 0.01 );\n	if ( cutoffDistance > 0.0 ) {\n		distanceFalloff *= pow2( saturate( 1.0 - pow4( lightDistance / cutoffDistance ) ) );\n	}\n	return distanceFalloff;\n}\nfloat getSpotAttenuation( const in float coneCosine, const in float penumbraCosine, const in float angleCosine ) {\n	return smoothstep( coneCosine, penumbraCosine, angleCosine );\n}\n#if NUM_DIR_LIGHTS > 0\n	struct DirectionalLight {\n		vec3 direction;\n		vec3 color;\n	};\n	uniform DirectionalLight directionalLights[ NUM_DIR_LIGHTS ];\n	void getDirectionalLightInfo( const in DirectionalLight directionalLight, out IncidentLight light ) {\n		light.color = directionalLight.color;\n		light.direction = directionalLight.direction;\n		light.visible = true;\n	}\n#endif\n#if NUM_POINT_LIGHTS > 0\n	struct PointLight {\n		vec3 position;\n		vec3 color;\n		float distance;\n		float decay;\n	};\n	uniform PointLight pointLights[ NUM_POINT_LIGHTS ];\n	void getPointLightInfo( const in PointLight pointLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = pointLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float lightDistance = length( lVector );\n		light.color = pointLight.color;\n		light.color *= getDistanceAttenuation( lightDistance, pointLight.distance, pointLight.decay );\n		light.visible = ( light.color != vec3( 0.0 ) );\n	}\n#endif\n#if NUM_SPOT_LIGHTS > 0\n	struct SpotLight {\n		vec3 position;\n		vec3 direction;\n		vec3 color;\n		float distance;\n		float decay;\n		float coneCos;\n		float penumbraCos;\n	};\n	uniform SpotLight spotLights[ NUM_SPOT_LIGHTS ];\n	void getSpotLightInfo( const in SpotLight spotLight, const in vec3 geometryPosition, out IncidentLight light ) {\n		vec3 lVector = spotLight.position - geometryPosition;\n		light.direction = normalize( lVector );\n		float angleCos = dot( light.direction, spotLight.direction );\n		float spotAttenuation = getSpotAttenuation( spotLight.coneCos, spotLight.penumbraCos, angleCos );\n		if ( spotAttenuation > 0.0 ) {\n			float lightDistance = length( lVector );\n			light.color = spotLight.color * spotAttenuation;\n			light.color *= getDistanceAttenuation( lightDistance, spotLight.distance, spotLight.decay );\n			light.visible = ( light.color != vec3( 0.0 ) );\n		} else {\n			light.color = vec3( 0.0 );\n			light.visible = false;\n		}\n	}\n#endif\n#if NUM_RECT_AREA_LIGHTS > 0\n	struct RectAreaLight {\n		vec3 color;\n		vec3 position;\n		vec3 halfWidth;\n		vec3 halfHeight;\n	};\n	uniform sampler2D ltc_1;	uniform sampler2D ltc_2;\n	uniform RectAreaLight rectAreaLights[ NUM_RECT_AREA_LIGHTS ];\n#endif\n#if NUM_HEMI_LIGHTS > 0\n	struct HemisphereLight {\n		vec3 direction;\n		vec3 skyColor;\n		vec3 groundColor;\n	};\n	uniform HemisphereLight hemisphereLights[ NUM_HEMI_LIGHTS ];\n	vec3 getHemisphereLightIrradiance( const in HemisphereLight hemiLight, const in vec3 normal ) {\n		float dotNL = dot( normal, hemiLight.direction );\n		float hemiDiffuseWeight = 0.5 * dotNL + 0.5;\n		vec3 irradiance = mix( hemiLight.groundColor, hemiLight.skyColor, hemiDiffuseWeight );\n		return irradiance;\n	}\n#endif\n#include <lightprobes_pars_fragment>",lights_toon_fragment:"ToonMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;",lights_toon_pars_fragment:"varying vec3 vViewPosition;\nstruct ToonMaterial {\n	vec3 diffuseColor;\n};\nvoid RE_Direct_Toon( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 irradiance = getGradientIrradiance( geometryNormal, directLight.direction ) * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\nvoid RE_IndirectDiffuse_Toon( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in ToonMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_Toon\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Toon",lights_phong_fragment:"BlinnPhongMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.specularColor = specular;\nmaterial.specularShininess = shininess;\nmaterial.specularStrength = specularStrength;",lights_phong_pars_fragment:"varying vec3 vViewPosition;\nstruct BlinnPhongMaterial {\n	vec3 diffuseColor;\n	vec3 specularColor;\n	float specularShininess;\n	float specularStrength;\n};\nvoid RE_Direct_BlinnPhong( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n	reflectedLight.directSpecular += irradiance * BRDF_BlinnPhong( directLight.direction, geometryViewDir, geometryNormal, material.specularColor, material.specularShininess ) * material.specularStrength;\n}\nvoid RE_IndirectDiffuse_BlinnPhong( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in BlinnPhongMaterial material, inout ReflectedLight reflectedLight ) {\n	reflectedLight.indirectDiffuse += irradiance * BRDF_Lambert( material.diffuseColor );\n}\n#define RE_Direct				RE_Direct_BlinnPhong\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_BlinnPhong",lights_physical_fragment:"PhysicalMaterial material;\nmaterial.diffuseColor = diffuseColor.rgb;\nmaterial.diffuseContribution = diffuseColor.rgb * ( 1.0 - metalnessFactor );\nmaterial.metalness = metalnessFactor;\nvec3 dxy = max( abs( dFdx( nonPerturbedNormal ) ), abs( dFdy( nonPerturbedNormal ) ) );\nfloat geometryRoughness = max( max( dxy.x, dxy.y ), dxy.z );\nmaterial.roughness = max( roughnessFactor, 0.0525 );material.roughness += geometryRoughness;\nmaterial.roughness = min( material.roughness, 1.0 );\n#ifdef IOR\n	material.ior = ior;\n	#ifdef USE_SPECULAR\n		float specularIntensityFactor = specularIntensity;\n		vec3 specularColorFactor = specularColor;\n		#ifdef USE_SPECULAR_COLORMAP\n			specularColorFactor *= texture2D( specularColorMap, vSpecularColorMapUv ).rgb;\n		#endif\n		#ifdef USE_SPECULAR_INTENSITYMAP\n			specularIntensityFactor *= texture2D( specularIntensityMap, vSpecularIntensityMapUv ).a;\n		#endif\n		material.specularF90 = mix( specularIntensityFactor, 1.0, metalnessFactor );\n	#else\n		float specularIntensityFactor = 1.0;\n		vec3 specularColorFactor = vec3( 1.0 );\n		material.specularF90 = 1.0;\n	#endif\n	material.specularColor = min( pow2( ( material.ior - 1.0 ) / ( material.ior + 1.0 ) ) * specularColorFactor, vec3( 1.0 ) ) * specularIntensityFactor;\n	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );\n#else\n	material.specularColor = vec3( 0.04 );\n	material.specularColorBlended = mix( material.specularColor, diffuseColor.rgb, metalnessFactor );\n	material.specularF90 = 1.0;\n#endif\n#ifdef USE_CLEARCOAT\n	material.clearcoat = clearcoat;\n	material.clearcoatRoughness = clearcoatRoughness;\n	material.clearcoatF0 = vec3( 0.04 );\n	material.clearcoatF90 = 1.0;\n	#ifdef USE_CLEARCOATMAP\n		material.clearcoat *= texture2D( clearcoatMap, vClearcoatMapUv ).x;\n	#endif\n	#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n		material.clearcoatRoughness *= texture2D( clearcoatRoughnessMap, vClearcoatRoughnessMapUv ).y;\n	#endif\n	material.clearcoat = saturate( material.clearcoat );	material.clearcoatRoughness = max( material.clearcoatRoughness, 0.0525 );\n	material.clearcoatRoughness += geometryRoughness;\n	material.clearcoatRoughness = min( material.clearcoatRoughness, 1.0 );\n#endif\n#ifdef USE_DISPERSION\n	material.dispersion = dispersion;\n#endif\n#ifdef USE_IRIDESCENCE\n	material.iridescence = iridescence;\n	material.iridescenceIOR = iridescenceIOR;\n	#ifdef USE_IRIDESCENCEMAP\n		material.iridescence *= texture2D( iridescenceMap, vIridescenceMapUv ).r;\n	#endif\n	#ifdef USE_IRIDESCENCE_THICKNESSMAP\n		material.iridescenceThickness = (iridescenceThicknessMaximum - iridescenceThicknessMinimum) * texture2D( iridescenceThicknessMap, vIridescenceThicknessMapUv ).g + iridescenceThicknessMinimum;\n	#else\n		material.iridescenceThickness = iridescenceThicknessMaximum;\n	#endif\n#endif\n#ifdef USE_SHEEN\n	material.sheenColor = sheenColor;\n	#ifdef USE_SHEEN_COLORMAP\n		material.sheenColor *= texture2D( sheenColorMap, vSheenColorMapUv ).rgb;\n	#endif\n	material.sheenRoughness = clamp( sheenRoughness, 0.0001, 1.0 );\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		material.sheenRoughness *= texture2D( sheenRoughnessMap, vSheenRoughnessMapUv ).a;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	#ifdef USE_ANISOTROPYMAP\n		mat2 anisotropyMat = mat2( anisotropyVector.x, anisotropyVector.y, - anisotropyVector.y, anisotropyVector.x );\n		vec3 anisotropyPolar = texture2D( anisotropyMap, vAnisotropyMapUv ).rgb;\n		vec2 anisotropyV = anisotropyMat * normalize( 2.0 * anisotropyPolar.rg - vec2( 1.0 ) ) * anisotropyPolar.b;\n	#else\n		vec2 anisotropyV = anisotropyVector;\n	#endif\n	material.anisotropy = length( anisotropyV );\n	if( material.anisotropy == 0.0 ) {\n		anisotropyV = vec2( 1.0, 0.0 );\n	} else {\n		anisotropyV /= material.anisotropy;\n		material.anisotropy = saturate( material.anisotropy );\n	}\n	material.alphaT = mix( pow2( material.roughness ), 1.0, pow2( material.anisotropy ) );\n	material.anisotropyT = tbn[ 0 ] * anisotropyV.x + tbn[ 1 ] * anisotropyV.y;\n	material.anisotropyB = tbn[ 1 ] * anisotropyV.x - tbn[ 0 ] * anisotropyV.y;\n#endif",lights_physical_pars_fragment:"uniform sampler2D dfgLUT;\nstruct PhysicalMaterial {\n	vec3 diffuseColor;\n	vec3 diffuseContribution;\n	vec3 specularColor;\n	vec3 specularColorBlended;\n	float roughness;\n	float metalness;\n	float specularF90;\n	float dispersion;\n	#ifdef USE_CLEARCOAT\n		float clearcoat;\n		float clearcoatRoughness;\n		vec3 clearcoatF0;\n		float clearcoatF90;\n	#endif\n	#ifdef USE_IRIDESCENCE\n		float iridescence;\n		float iridescenceIOR;\n		float iridescenceThickness;\n		vec3 iridescenceFresnel;\n		vec3 iridescenceF0;\n		vec3 iridescenceFresnelDielectric;\n		vec3 iridescenceFresnelMetallic;\n	#endif\n	#ifdef USE_SHEEN\n		vec3 sheenColor;\n		float sheenRoughness;\n	#endif\n	#ifdef IOR\n		float ior;\n	#endif\n	#ifdef USE_TRANSMISSION\n		float transmission;\n		float transmissionAlpha;\n		float thickness;\n		float attenuationDistance;\n		vec3 attenuationColor;\n	#endif\n	#ifdef USE_ANISOTROPY\n		float anisotropy;\n		float alphaT;\n		vec3 anisotropyT;\n		vec3 anisotropyB;\n	#endif\n};\nvec3 clearcoatSpecularDirect = vec3( 0.0 );\nvec3 clearcoatSpecularIndirect = vec3( 0.0 );\nvec3 sheenSpecularDirect = vec3( 0.0 );\nvec3 sheenSpecularIndirect = vec3(0.0 );\nvec3 Schlick_to_F0( const in vec3 f, const in float f90, const in float dotVH ) {\n    float x = clamp( 1.0 - dotVH, 0.0, 1.0 );\n    float x2 = x * x;\n    float x5 = clamp( x * x2 * x2, 0.0, 0.9999 );\n    return ( f - vec3( f90 ) * x5 ) / ( 1.0 - x5 );\n}\nfloat V_GGX_SmithCorrelated( const in float alpha, const in float dotNL, const in float dotNV ) {\n	float a2 = pow2( alpha );\n	float gv = dotNL * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNV ) );\n	float gl = dotNV * sqrt( a2 + ( 1.0 - a2 ) * pow2( dotNL ) );\n	return 0.5 / max( gv + gl, EPSILON );\n}\nfloat D_GGX( const in float alpha, const in float dotNH ) {\n	float a2 = pow2( alpha );\n	float denom = pow2( dotNH ) * ( a2 - 1.0 ) + 1.0;\n	return RECIPROCAL_PI * a2 / pow2( denom );\n}\n#ifdef USE_ANISOTROPY\n	float V_GGX_SmithCorrelated_Anisotropic( const in float alphaT, const in float alphaB, const in float dotTV, const in float dotBV, const in float dotTL, const in float dotBL, const in float dotNV, const in float dotNL ) {\n		float gv = dotNL * length( vec3( alphaT * dotTV, alphaB * dotBV, dotNV ) );\n		float gl = dotNV * length( vec3( alphaT * dotTL, alphaB * dotBL, dotNL ) );\n		return 0.5 / max( gv + gl, EPSILON );\n	}\n	float D_GGX_Anisotropic( const in float alphaT, const in float alphaB, const in float dotNH, const in float dotTH, const in float dotBH ) {\n		float a2 = alphaT * alphaB;\n		highp vec3 v = vec3( alphaB * dotTH, alphaT * dotBH, a2 * dotNH );\n		highp float v2 = dot( v, v );\n		float w2 = a2 / v2;\n		return RECIPROCAL_PI * a2 * pow2 ( w2 );\n	}\n#endif\n#ifdef USE_CLEARCOAT\n	vec3 BRDF_GGX_Clearcoat( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material) {\n		vec3 f0 = material.clearcoatF0;\n		float f90 = material.clearcoatF90;\n		float roughness = material.clearcoatRoughness;\n		float alpha = pow2( roughness );\n		vec3 halfDir = normalize( lightDir + viewDir );\n		float dotNL = saturate( dot( normal, lightDir ) );\n		float dotNV = saturate( dot( normal, viewDir ) );\n		float dotNH = saturate( dot( normal, halfDir ) );\n		float dotVH = saturate( dot( viewDir, halfDir ) );\n		vec3 F = F_Schlick( f0, f90, dotVH );\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n		return F * ( V * D );\n	}\n#endif\nvec3 BRDF_GGX( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {\n	vec3 f0 = material.specularColorBlended;\n	float f90 = material.specularF90;\n	float roughness = material.roughness;\n	float alpha = pow2( roughness );\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float dotVH = saturate( dot( viewDir, halfDir ) );\n	vec3 F = F_Schlick( f0, f90, dotVH );\n	#ifdef USE_IRIDESCENCE\n		F = mix( F, material.iridescenceFresnel, material.iridescence );\n	#endif\n	#ifdef USE_ANISOTROPY\n		float dotTL = dot( material.anisotropyT, lightDir );\n		float dotTV = dot( material.anisotropyT, viewDir );\n		float dotTH = dot( material.anisotropyT, halfDir );\n		float dotBL = dot( material.anisotropyB, lightDir );\n		float dotBV = dot( material.anisotropyB, viewDir );\n		float dotBH = dot( material.anisotropyB, halfDir );\n		float V = V_GGX_SmithCorrelated_Anisotropic( material.alphaT, alpha, dotTV, dotBV, dotTL, dotBL, dotNV, dotNL );\n		float D = D_GGX_Anisotropic( material.alphaT, alpha, dotNH, dotTH, dotBH );\n	#else\n		float V = V_GGX_SmithCorrelated( alpha, dotNL, dotNV );\n		float D = D_GGX( alpha, dotNH );\n	#endif\n	return F * ( V * D );\n}\nvec2 LTC_Uv( const in vec3 N, const in vec3 V, const in float roughness ) {\n	const float LUT_SIZE = 64.0;\n	const float LUT_SCALE = ( LUT_SIZE - 1.0 ) / LUT_SIZE;\n	const float LUT_BIAS = 0.5 / LUT_SIZE;\n	float dotNV = saturate( dot( N, V ) );\n	vec2 uv = vec2( roughness, sqrt( 1.0 - dotNV ) );\n	uv = uv * LUT_SCALE + LUT_BIAS;\n	return uv;\n}\nfloat LTC_ClippedSphereFormFactor( const in vec3 f ) {\n	float l = length( f );\n	return max( ( l * l + f.z ) / ( l + 1.0 ), 0.0 );\n}\nvec3 LTC_EdgeVectorFormFactor( const in vec3 v1, const in vec3 v2 ) {\n	float x = dot( v1, v2 );\n	float y = abs( x );\n	float a = 0.8543985 + ( 0.4965155 + 0.0145206 * y ) * y;\n	float b = 3.4175940 + ( 4.1616724 + y ) * y;\n	float v = a / b;\n	float theta_sintheta = ( x > 0.0 ) ? v : 0.5 * inversesqrt( max( 1.0 - x * x, 1e-7 ) ) - v;\n	return cross( v1, v2 ) * theta_sintheta;\n}\nvec3 LTC_Evaluate( const in vec3 N, const in vec3 V, const in vec3 P, const in mat3 mInv, const in vec3 rectCoords[ 4 ] ) {\n	vec3 v1 = rectCoords[ 1 ] - rectCoords[ 0 ];\n	vec3 v2 = rectCoords[ 3 ] - rectCoords[ 0 ];\n	vec3 lightNormal = cross( v1, v2 );\n	if( dot( lightNormal, P - rectCoords[ 0 ] ) < 0.0 ) return vec3( 0.0 );\n	vec3 T1, T2;\n	T1 = normalize( V - N * dot( V, N ) );\n	T2 = - cross( N, T1 );\n	mat3 mat = mInv * transpose( mat3( T1, T2, N ) );\n	vec3 coords[ 4 ];\n	coords[ 0 ] = mat * ( rectCoords[ 0 ] - P );\n	coords[ 1 ] = mat * ( rectCoords[ 1 ] - P );\n	coords[ 2 ] = mat * ( rectCoords[ 2 ] - P );\n	coords[ 3 ] = mat * ( rectCoords[ 3 ] - P );\n	coords[ 0 ] = normalize( coords[ 0 ] );\n	coords[ 1 ] = normalize( coords[ 1 ] );\n	coords[ 2 ] = normalize( coords[ 2 ] );\n	coords[ 3 ] = normalize( coords[ 3 ] );\n	vec3 vectorFormFactor = vec3( 0.0 );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 0 ], coords[ 1 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 1 ], coords[ 2 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 2 ], coords[ 3 ] );\n	vectorFormFactor += LTC_EdgeVectorFormFactor( coords[ 3 ], coords[ 0 ] );\n	float result = LTC_ClippedSphereFormFactor( vectorFormFactor );\n	return vec3( result );\n}\n#if defined( USE_SHEEN )\nfloat D_Charlie( float roughness, float dotNH ) {\n	float alpha = pow2( roughness );\n	float invAlpha = 1.0 / alpha;\n	float cos2h = dotNH * dotNH;\n	float sin2h = max( 1.0 - cos2h, 0.0078125 );\n	return ( 2.0 + invAlpha ) * pow( sin2h, invAlpha * 0.5 ) / ( 2.0 * PI );\n}\nfloat V_Neubelt( float dotNV, float dotNL ) {\n	return saturate( 1.0 / ( 4.0 * ( dotNL + dotNV - dotNL * dotNV ) ) );\n}\nvec3 BRDF_Sheen( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, vec3 sheenColor, const in float sheenRoughness ) {\n	vec3 halfDir = normalize( lightDir + viewDir );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float dotNH = saturate( dot( normal, halfDir ) );\n	float D = D_Charlie( sheenRoughness, dotNH );\n	float V = V_Neubelt( dotNV, dotNL );\n	return sheenColor * ( D * V );\n}\n#endif\nfloat IBLSheenBRDF( const in vec3 normal, const in vec3 viewDir, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	float r2 = roughness * roughness;\n	float rInv = 1.0 / ( roughness + 0.1 );\n	float a = -1.9362 + 1.0678 * roughness + 0.4573 * r2 - 0.8469 * rInv;\n	float b = -0.6014 + 0.5538 * roughness - 0.4670 * r2 - 0.1255 * rInv;\n	float DG = exp( a * dotNV + b );\n	return saturate( DG );\n}\nvec3 EnvironmentBRDF( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness ) {\n	float dotNV = saturate( dot( normal, viewDir ) );\n	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;\n	return specularColor * fab.x + specularF90 * fab.y;\n}\n#ifdef USE_IRIDESCENCE\nvoid computeMultiscatteringIridescence( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float iridescence, const in vec3 iridescenceF0, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#else\nvoid computeMultiscattering( const in vec3 normal, const in vec3 viewDir, const in vec3 specularColor, const in float specularF90, const in float roughness, inout vec3 singleScatter, inout vec3 multiScatter ) {\n#endif\n	float dotNV = saturate( dot( normal, viewDir ) );\n	vec2 fab = texture2D( dfgLUT, vec2( roughness, dotNV ) ).rg;\n	#ifdef USE_IRIDESCENCE\n		vec3 Fr = mix( specularColor, iridescenceF0, iridescence );\n	#else\n		vec3 Fr = specularColor;\n	#endif\n	vec3 FssEss = Fr * fab.x + specularF90 * fab.y;\n	float Ess = fab.x + fab.y;\n	float Ems = 1.0 - Ess;\n	vec3 Favg = Fr + ( 1.0 - Fr ) * 0.047619;	vec3 Fms = FssEss * Favg / ( 1.0 - Ems * Favg );\n	singleScatter += FssEss;\n	multiScatter += Fms * Ems;\n}\nvec3 BRDF_GGX_Multiscatter( const in vec3 lightDir, const in vec3 viewDir, const in vec3 normal, const in PhysicalMaterial material ) {\n	vec3 singleScatter = BRDF_GGX( lightDir, viewDir, normal, material );\n	float dotNL = saturate( dot( normal, lightDir ) );\n	float dotNV = saturate( dot( normal, viewDir ) );\n	vec2 dfgV = texture2D( dfgLUT, vec2( material.roughness, dotNV ) ).rg;\n	vec2 dfgL = texture2D( dfgLUT, vec2( material.roughness, dotNL ) ).rg;\n	vec3 FssEss_V = material.specularColorBlended * dfgV.x + material.specularF90 * dfgV.y;\n	vec3 FssEss_L = material.specularColorBlended * dfgL.x + material.specularF90 * dfgL.y;\n	float Ess_V = dfgV.x + dfgV.y;\n	float Ess_L = dfgL.x + dfgL.y;\n	float Ems_V = 1.0 - Ess_V;\n	float Ems_L = 1.0 - Ess_L;\n	vec3 Favg = material.specularColorBlended + ( 1.0 - material.specularColorBlended ) * 0.047619;\n	vec3 Fms = FssEss_V * FssEss_L * Favg / ( 1.0 - Ems_V * Ems_L * Favg + EPSILON );\n	float compensationFactor = Ems_V * Ems_L;\n	vec3 multiScatter = Fms * compensationFactor;\n	return singleScatter + multiScatter;\n}\n#if NUM_RECT_AREA_LIGHTS > 0\n	void RE_Direct_RectArea_Physical( const in RectAreaLight rectAreaLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n		vec3 normal = geometryNormal;\n		vec3 viewDir = geometryViewDir;\n		vec3 position = geometryPosition;\n		vec3 lightPos = rectAreaLight.position;\n		vec3 halfWidth = rectAreaLight.halfWidth;\n		vec3 halfHeight = rectAreaLight.halfHeight;\n		vec3 lightColor = rectAreaLight.color;\n		float roughness = material.roughness;\n		vec3 rectCoords[ 4 ];\n		rectCoords[ 0 ] = lightPos + halfWidth - halfHeight;		rectCoords[ 1 ] = lightPos - halfWidth - halfHeight;\n		rectCoords[ 2 ] = lightPos - halfWidth + halfHeight;\n		rectCoords[ 3 ] = lightPos + halfWidth + halfHeight;\n		vec2 uv = LTC_Uv( normal, viewDir, roughness );\n		vec4 t1 = texture2D( ltc_1, uv );\n		vec4 t2 = texture2D( ltc_2, uv );\n		mat3 mInv = mat3(\n			vec3( t1.x, 0, t1.y ),\n			vec3(    0, 1,    0 ),\n			vec3( t1.z, 0, t1.w )\n		);\n		vec3 fresnel = ( material.specularColorBlended * t2.x + ( material.specularF90 - material.specularColorBlended ) * t2.y );\n		reflectedLight.directSpecular += lightColor * fresnel * LTC_Evaluate( normal, viewDir, position, mInv, rectCoords );\n		reflectedLight.directDiffuse += lightColor * material.diffuseContribution * LTC_Evaluate( normal, viewDir, position, mat3( 1.0 ), rectCoords );\n		#ifdef USE_CLEARCOAT\n			vec3 Ncc = geometryClearcoatNormal;\n			vec2 uvClearcoat = LTC_Uv( Ncc, viewDir, material.clearcoatRoughness );\n			vec4 t1Clearcoat = texture2D( ltc_1, uvClearcoat );\n			vec4 t2Clearcoat = texture2D( ltc_2, uvClearcoat );\n			mat3 mInvClearcoat = mat3(\n				vec3( t1Clearcoat.x, 0, t1Clearcoat.y ),\n				vec3(             0, 1,             0 ),\n				vec3( t1Clearcoat.z, 0, t1Clearcoat.w )\n			);\n			vec3 fresnelClearcoat = material.clearcoatF0 * t2Clearcoat.x + ( material.clearcoatF90 - material.clearcoatF0 ) * t2Clearcoat.y;\n			clearcoatSpecularDirect += lightColor * fresnelClearcoat * LTC_Evaluate( Ncc, viewDir, position, mInvClearcoat, rectCoords );\n		#endif\n	}\n#endif\nvoid RE_Direct_Physical( const in IncidentLight directLight, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	float dotNL = saturate( dot( geometryNormal, directLight.direction ) );\n	vec3 irradiance = dotNL * directLight.color;\n	#ifdef USE_CLEARCOAT\n		float dotNLcc = saturate( dot( geometryClearcoatNormal, directLight.direction ) );\n		vec3 ccIrradiance = dotNLcc * directLight.color;\n		clearcoatSpecularDirect += ccIrradiance * BRDF_GGX_Clearcoat( directLight.direction, geometryViewDir, geometryClearcoatNormal, material );\n	#endif\n	#ifdef USE_SHEEN\n \n 		sheenSpecularDirect += irradiance * BRDF_Sheen( directLight.direction, geometryViewDir, geometryNormal, material.sheenColor, material.sheenRoughness );\n \n 		float sheenAlbedoV = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n 		float sheenAlbedoL = IBLSheenBRDF( geometryNormal, directLight.direction, material.sheenRoughness );\n \n 		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * max( sheenAlbedoV, sheenAlbedoL );\n \n 		irradiance *= sheenEnergyComp;\n \n 	#endif\n	reflectedLight.directSpecular += irradiance * BRDF_GGX_Multiscatter( directLight.direction, geometryViewDir, geometryNormal, material );\n	reflectedLight.directDiffuse += irradiance * BRDF_Lambert( material.diffuseContribution );\n}\nvoid RE_IndirectDiffuse_Physical( const in vec3 irradiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight ) {\n	vec3 diffuse = irradiance * BRDF_Lambert( material.diffuseContribution );\n	#ifdef USE_SHEEN\n		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;\n		diffuse *= sheenEnergyComp;\n	#endif\n	reflectedLight.indirectDiffuse += diffuse;\n}\nvoid RE_IndirectSpecular_Physical( const in vec3 radiance, const in vec3 irradiance, const in vec3 clearcoatRadiance, const in vec3 geometryPosition, const in vec3 geometryNormal, const in vec3 geometryViewDir, const in vec3 geometryClearcoatNormal, const in PhysicalMaterial material, inout ReflectedLight reflectedLight) {\n	#ifdef USE_CLEARCOAT\n		clearcoatSpecularIndirect += clearcoatRadiance * EnvironmentBRDF( geometryClearcoatNormal, geometryViewDir, material.clearcoatF0, material.clearcoatF90, material.clearcoatRoughness );\n	#endif\n	#ifdef USE_SHEEN\n		sheenSpecularIndirect += irradiance * material.sheenColor * IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness ) * RECIPROCAL_PI;\n 	#endif\n	vec3 singleScatteringDielectric = vec3( 0.0 );\n	vec3 multiScatteringDielectric = vec3( 0.0 );\n	vec3 singleScatteringMetallic = vec3( 0.0 );\n	vec3 multiScatteringMetallic = vec3( 0.0 );\n	#ifdef USE_IRIDESCENCE\n		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.iridescence, material.iridescenceFresnelDielectric, material.roughness, singleScatteringDielectric, multiScatteringDielectric );\n		computeMultiscatteringIridescence( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.iridescence, material.iridescenceFresnelMetallic, material.roughness, singleScatteringMetallic, multiScatteringMetallic );\n	#else\n		computeMultiscattering( geometryNormal, geometryViewDir, material.specularColor, material.specularF90, material.roughness, singleScatteringDielectric, multiScatteringDielectric );\n		computeMultiscattering( geometryNormal, geometryViewDir, material.diffuseColor, material.specularF90, material.roughness, singleScatteringMetallic, multiScatteringMetallic );\n	#endif\n	vec3 singleScattering = mix( singleScatteringDielectric, singleScatteringMetallic, material.metalness );\n	vec3 multiScattering = mix( multiScatteringDielectric, multiScatteringMetallic, material.metalness );\n	vec3 totalScatteringDielectric = singleScatteringDielectric + multiScatteringDielectric;\n	vec3 diffuse = material.diffuseContribution * ( 1.0 - totalScatteringDielectric );\n	vec3 cosineWeightedIrradiance = irradiance * RECIPROCAL_PI;\n	vec3 indirectSpecular = radiance * singleScattering;\n	indirectSpecular += multiScattering * cosineWeightedIrradiance;\n	vec3 indirectDiffuse = diffuse * cosineWeightedIrradiance;\n	#ifdef USE_SHEEN\n		float sheenAlbedo = IBLSheenBRDF( geometryNormal, geometryViewDir, material.sheenRoughness );\n		float sheenEnergyComp = 1.0 - max3( material.sheenColor ) * sheenAlbedo;\n		indirectSpecular *= sheenEnergyComp;\n		indirectDiffuse *= sheenEnergyComp;\n	#endif\n	reflectedLight.indirectSpecular += indirectSpecular;\n	reflectedLight.indirectDiffuse += indirectDiffuse;\n}\n#define RE_Direct				RE_Direct_Physical\n#define RE_Direct_RectArea		RE_Direct_RectArea_Physical\n#define RE_IndirectDiffuse		RE_IndirectDiffuse_Physical\n#define RE_IndirectSpecular		RE_IndirectSpecular_Physical\nfloat computeSpecularOcclusion( const in float dotNV, const in float ambientOcclusion, const in float roughness ) {\n	return saturate( pow( dotNV + ambientOcclusion, exp2( - 16.0 * roughness - 1.0 ) ) - 1.0 + ambientOcclusion );\n}",lights_fragment_begin:"\nvec3 geometryPosition = - vViewPosition;\nvec3 geometryNormal = normal;\nvec3 geometryViewDir = ( isOrthographic ) ? vec3( 0, 0, 1 ) : normalize( vViewPosition );\nvec3 geometryClearcoatNormal = vec3( 0.0 );\n#ifdef USE_CLEARCOAT\n	geometryClearcoatNormal = clearcoatNormal;\n#endif\n#ifdef USE_IRIDESCENCE\n	float dotNVi = saturate( dot( normal, geometryViewDir ) );\n	if ( material.iridescenceThickness == 0.0 ) {\n		material.iridescence = 0.0;\n	} else {\n		material.iridescence = saturate( material.iridescence );\n	}\n	if ( material.iridescence > 0.0 ) {\n		material.iridescenceFresnelDielectric = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.specularColor );\n		material.iridescenceFresnelMetallic = evalIridescence( 1.0, material.iridescenceIOR, dotNVi, material.iridescenceThickness, material.diffuseColor );\n		material.iridescenceFresnel = mix( material.iridescenceFresnelDielectric, material.iridescenceFresnelMetallic, material.metalness );\n		material.iridescenceF0 = Schlick_to_F0( material.iridescenceFresnel, 1.0, dotNVi );\n	}\n#endif\nIncidentLight directLight;\n#if ( NUM_POINT_LIGHTS > 0 ) && defined( RE_Direct )\n	PointLight pointLight;\n	#if defined( USE_SHADOWMAP ) && NUM_POINT_LIGHT_SHADOWS > 0\n	PointLightShadow pointLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHTS; i ++ ) {\n		pointLight = pointLights[ i ];\n		getPointLightInfo( pointLight, geometryPosition, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_POINT_LIGHT_SHADOWS ) && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )\n		pointLightShadow = pointLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getPointShadow( pointShadowMap[ i ], pointLightShadow.shadowMapSize, pointLightShadow.shadowIntensity, pointLightShadow.shadowBias, pointLightShadow.shadowRadius, vPointShadowCoord[ i ], pointLightShadow.shadowCameraNear, pointLightShadow.shadowCameraFar ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_SPOT_LIGHTS > 0 ) && defined( RE_Direct )\n	SpotLight spotLight;\n	vec4 spotColor;\n	vec3 spotLightCoord;\n	bool inSpotLightMap;\n	#if defined( USE_SHADOWMAP ) && NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHTS; i ++ ) {\n		spotLight = spotLights[ i ];\n		getSpotLightInfo( spotLight, geometryPosition, directLight );\n		#if ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#define SPOT_LIGHT_MAP_INDEX UNROLLED_LOOP_INDEX\n		#elif ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		#define SPOT_LIGHT_MAP_INDEX NUM_SPOT_LIGHT_MAPS\n		#else\n		#define SPOT_LIGHT_MAP_INDEX ( UNROLLED_LOOP_INDEX - NUM_SPOT_LIGHT_SHADOWS + NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS )\n		#endif\n		#if ( SPOT_LIGHT_MAP_INDEX < NUM_SPOT_LIGHT_MAPS )\n			spotLightCoord = vSpotLightCoord[ i ].xyz / vSpotLightCoord[ i ].w;\n			inSpotLightMap = all( lessThan( abs( spotLightCoord * 2. - 1. ), vec3( 1.0 ) ) );\n			spotColor = texture2D( spotLightMap[ SPOT_LIGHT_MAP_INDEX ], spotLightCoord.xy );\n			directLight.color = inSpotLightMap ? directLight.color * spotColor.rgb : directLight.color;\n		#endif\n		#undef SPOT_LIGHT_MAP_INDEX\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n		spotLightShadow = spotLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( spotShadowMap[ i ], spotLightShadow.shadowMapSize, spotLightShadow.shadowIntensity, spotLightShadow.shadowBias, spotLightShadow.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_DIR_LIGHTS > 0 ) && defined( RE_Direct )\n	DirectionalLight directionalLight;\n	#if defined( USE_SHADOWMAP ) && NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLightShadow;\n	#endif\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHTS; i ++ ) {\n		directionalLight = directionalLights[ i ];\n		getDirectionalLightInfo( directionalLight, directLight );\n		#if defined( USE_SHADOWMAP ) && ( UNROLLED_LOOP_INDEX < NUM_DIR_LIGHT_SHADOWS )\n		directionalLightShadow = directionalLightShadows[ i ];\n		directLight.color *= ( directLight.visible && receiveShadow ) ? getShadow( directionalShadowMap[ i ], directionalLightShadow.shadowMapSize, directionalLightShadow.shadowIntensity, directionalLightShadow.shadowBias, directionalLightShadow.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n		#endif\n		RE_Direct( directLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if ( NUM_RECT_AREA_LIGHTS > 0 ) && defined( RE_Direct_RectArea )\n	RectAreaLight rectAreaLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_RECT_AREA_LIGHTS; i ++ ) {\n		rectAreaLight = rectAreaLights[ i ];\n		RE_Direct_RectArea( rectAreaLight, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n	}\n	#pragma unroll_loop_end\n#endif\n#if defined( RE_IndirectDiffuse )\n	vec3 iblIrradiance = vec3( 0.0 );\n	vec3 irradiance = getAmbientLightIrradiance( ambientLightColor );\n	#if defined( USE_LIGHT_PROBES )\n		irradiance += getLightProbeIrradiance( lightProbe, geometryNormal );\n	#endif\n	#if ( NUM_HEMI_LIGHTS > 0 )\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_HEMI_LIGHTS; i ++ ) {\n			irradiance += getHemisphereLightIrradiance( hemisphereLights[ i ], geometryNormal );\n		}\n		#pragma unroll_loop_end\n	#endif\n	#ifdef USE_LIGHT_PROBES_GRID\n		vec3 probeWorldPos = ( ( vec4( geometryPosition, 1.0 ) - viewMatrix[ 3 ] ) * viewMatrix ).xyz;\n		vec3 probeWorldNormal = inverseTransformDirection( geometryNormal, viewMatrix );\n		irradiance += getLightProbeGridIrradiance( probeWorldPos, probeWorldNormal );\n	#endif\n#endif\n#if defined( RE_IndirectSpecular )\n	vec3 radiance = vec3( 0.0 );\n	vec3 clearcoatRadiance = vec3( 0.0 );\n#endif",lights_fragment_maps:"#if defined( RE_IndirectDiffuse )\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		vec3 lightMapIrradiance = lightMapTexel.rgb * lightMapIntensity;\n		irradiance += lightMapIrradiance;\n	#endif\n	#if defined( USE_ENVMAP ) && defined( ENVMAP_TYPE_CUBE_UV )\n		#if defined( STANDARD ) || defined( LAMBERT ) || defined( PHONG )\n			iblIrradiance += getIBLIrradiance( geometryNormal );\n		#endif\n	#endif\n#endif\n#if defined( USE_ENVMAP ) && defined( RE_IndirectSpecular )\n	#ifdef USE_ANISOTROPY\n		radiance += getIBLAnisotropyRadiance( geometryViewDir, geometryNormal, material.roughness, material.anisotropyB, material.anisotropy );\n	#else\n		radiance += getIBLRadiance( geometryViewDir, geometryNormal, material.roughness );\n	#endif\n	#ifdef USE_CLEARCOAT\n		clearcoatRadiance += getIBLRadiance( geometryViewDir, geometryClearcoatNormal, material.clearcoatRoughness );\n	#endif\n#endif",lights_fragment_end:"#if defined( RE_IndirectDiffuse )\n	#if defined( LAMBERT ) || defined( PHONG )\n		irradiance += iblIrradiance;\n	#endif\n	RE_IndirectDiffuse( irradiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif\n#if defined( RE_IndirectSpecular )\n	RE_IndirectSpecular( radiance, iblIrradiance, clearcoatRadiance, geometryPosition, geometryNormal, geometryViewDir, geometryClearcoatNormal, material, reflectedLight );\n#endif",lightprobes_pars_fragment:"#ifdef USE_LIGHT_PROBES_GRID\nuniform highp sampler3D probesSH;\nuniform vec3 probesMin;\nuniform vec3 probesMax;\nuniform vec3 probesResolution;\nvec3 getLightProbeGridIrradiance( vec3 worldPos, vec3 worldNormal ) {\n	vec3 res = probesResolution;\n	vec3 gridRange = probesMax - probesMin;\n	vec3 resMinusOne = res - 1.0;\n	vec3 probeSpacing = gridRange / resMinusOne;\n	vec3 samplePos = worldPos + worldNormal * probeSpacing * 0.5;\n	vec3 uvw = clamp( ( samplePos - probesMin ) / gridRange, 0.0, 1.0 );\n	uvw = uvw * resMinusOne / res + 0.5 / res;\n	float nz          = res.z;\n	float paddedSlices = nz + 2.0;\n	float atlasDepth  = 7.0 * paddedSlices;\n	float uvZBase     = uvw.z * nz + 1.0;\n	vec4 s0 = texture( probesSH, vec3( uvw.xy, ( uvZBase                       ) / atlasDepth ) );\n	vec4 s1 = texture( probesSH, vec3( uvw.xy, ( uvZBase +       paddedSlices   ) / atlasDepth ) );\n	vec4 s2 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 2.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s3 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 3.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s4 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 4.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s5 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 5.0 * paddedSlices   ) / atlasDepth ) );\n	vec4 s6 = texture( probesSH, vec3( uvw.xy, ( uvZBase + 6.0 * paddedSlices   ) / atlasDepth ) );\n	vec3 c0 = s0.xyz;\n	vec3 c1 = vec3( s0.w, s1.xy );\n	vec3 c2 = vec3( s1.zw, s2.x );\n	vec3 c3 = s2.yzw;\n	vec3 c4 = s3.xyz;\n	vec3 c5 = vec3( s3.w, s4.xy );\n	vec3 c6 = vec3( s4.zw, s5.x );\n	vec3 c7 = s5.yzw;\n	vec3 c8 = s6.xyz;\n	float x = worldNormal.x, y = worldNormal.y, z = worldNormal.z;\n	vec3 result = c0 * 0.886227;\n	result += c1 * 2.0 * 0.511664 * y;\n	result += c2 * 2.0 * 0.511664 * z;\n	result += c3 * 2.0 * 0.511664 * x;\n	result += c4 * 2.0 * 0.429043 * x * y;\n	result += c5 * 2.0 * 0.429043 * y * z;\n	result += c6 * ( 0.743125 * z * z - 0.247708 );\n	result += c7 * 2.0 * 0.429043 * x * z;\n	result += c8 * 0.429043 * ( x * x - y * y );\n	return max( result, vec3( 0.0 ) );\n}\n#endif",logdepthbuf_fragment:"#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )\n	gl_FragDepth = vIsPerspective == 0.0 ? gl_FragCoord.z : log2( vFragDepth ) * logDepthBufFC * 0.5;\n#endif",logdepthbuf_pars_fragment:"#if defined( USE_LOGARITHMIC_DEPTH_BUFFER )\n	uniform float logDepthBufFC;\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",logdepthbuf_pars_vertex:"#ifdef USE_LOGARITHMIC_DEPTH_BUFFER\n	varying float vFragDepth;\n	varying float vIsPerspective;\n#endif",logdepthbuf_vertex:"#ifdef USE_LOGARITHMIC_DEPTH_BUFFER\n	vFragDepth = 1.0 + gl_Position.w;\n	vIsPerspective = float( isPerspectiveMatrix( projectionMatrix ) );\n#endif",map_fragment:"#ifdef USE_MAP\n	vec4 sampledDiffuseColor = texture2D( map, vMapUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		sampledDiffuseColor = sRGBTransferEOTF( sampledDiffuseColor );\n	#endif\n	diffuseColor *= sampledDiffuseColor;\n#endif",map_pars_fragment:"#ifdef USE_MAP\n	uniform sampler2D map;\n#endif",map_particle_fragment:"#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n	#if defined( USE_POINTS_UV )\n		vec2 uv = vUv;\n	#else\n		vec2 uv = ( uvTransform * vec3( gl_PointCoord.x, 1.0 - gl_PointCoord.y, 1 ) ).xy;\n	#endif\n#endif\n#ifdef USE_MAP\n	diffuseColor *= texture2D( map, uv );\n#endif\n#ifdef USE_ALPHAMAP\n	diffuseColor.a *= texture2D( alphaMap, uv ).g;\n#endif",map_particle_pars_fragment:"#if defined( USE_POINTS_UV )\n	varying vec2 vUv;\n#else\n	#if defined( USE_MAP ) || defined( USE_ALPHAMAP )\n		uniform mat3 uvTransform;\n	#endif\n#endif\n#ifdef USE_MAP\n	uniform sampler2D map;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform sampler2D alphaMap;\n#endif",metalnessmap_fragment:"float metalnessFactor = metalness;\n#ifdef USE_METALNESSMAP\n	vec4 texelMetalness = texture2D( metalnessMap, vMetalnessMapUv );\n	metalnessFactor *= texelMetalness.b;\n#endif",metalnessmap_pars_fragment:"#ifdef USE_METALNESSMAP\n	uniform sampler2D metalnessMap;\n#endif",morphinstance_vertex:"#ifdef USE_INSTANCING_MORPH\n	float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	float morphTargetBaseInfluence = texelFetch( morphTexture, ivec2( 0, gl_InstanceID ), 0 ).r;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		morphTargetInfluences[i] =  texelFetch( morphTexture, ivec2( i + 1, gl_InstanceID ), 0 ).r;\n	}\n#endif",morphcolor_vertex:"#if defined( USE_MORPHCOLORS )\n	vColor *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		#if defined( USE_COLOR_ALPHA )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ) * morphTargetInfluences[ i ];\n		#elif defined( USE_COLOR )\n			if ( morphTargetInfluences[ i ] != 0.0 ) vColor += getMorph( gl_VertexID, i, 2 ).rgb * morphTargetInfluences[ i ];\n		#endif\n	}\n#endif",morphnormal_vertex:"#ifdef USE_MORPHNORMALS\n	objectNormal *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) objectNormal += getMorph( gl_VertexID, i, 1 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",morphtarget_pars_vertex:"#ifdef USE_MORPHTARGETS\n	#ifndef USE_INSTANCING_MORPH\n		uniform float morphTargetBaseInfluence;\n		uniform float morphTargetInfluences[ MORPHTARGETS_COUNT ];\n	#endif\n	uniform sampler2DArray morphTargetsTexture;\n	uniform ivec2 morphTargetsTextureSize;\n	vec4 getMorph( const in int vertexIndex, const in int morphTargetIndex, const in int offset ) {\n		int texelIndex = vertexIndex * MORPHTARGETS_TEXTURE_STRIDE + offset;\n		int y = texelIndex / morphTargetsTextureSize.x;\n		int x = texelIndex - y * morphTargetsTextureSize.x;\n		ivec3 morphUV = ivec3( x, y, morphTargetIndex );\n		return texelFetch( morphTargetsTexture, morphUV, 0 );\n	}\n#endif",morphtarget_vertex:"#ifdef USE_MORPHTARGETS\n	transformed *= morphTargetBaseInfluence;\n	for ( int i = 0; i < MORPHTARGETS_COUNT; i ++ ) {\n		if ( morphTargetInfluences[ i ] != 0.0 ) transformed += getMorph( gl_VertexID, i, 0 ).xyz * morphTargetInfluences[ i ];\n	}\n#endif",normal_fragment_begin:"float faceDirection = gl_FrontFacing ? 1.0 : - 1.0;\n#ifdef FLAT_SHADED\n	vec3 fdx = dFdx( vViewPosition );\n	vec3 fdy = dFdy( vViewPosition );\n	vec3 normal = normalize( cross( fdx, fdy ) );\n#else\n	vec3 normal = normalize( vNormal );\n	#ifdef DOUBLE_SIDED\n		normal *= faceDirection;\n	#endif\n#endif\n#if defined( USE_NORMALMAP_TANGENTSPACE ) || defined( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY )\n	#ifdef USE_TANGENT\n		mat3 tbn = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn = getTangentFrame( - vViewPosition, normal,\n		#if defined( USE_NORMALMAP )\n			vNormalMapUv\n		#elif defined( USE_CLEARCOAT_NORMALMAP )\n			vClearcoatNormalMapUv\n		#else\n			vUv\n		#endif\n		);\n	#endif\n	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n		tbn[0] *= faceDirection;\n		tbn[1] *= faceDirection;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	#ifdef USE_TANGENT\n		mat3 tbn2 = mat3( normalize( vTangent ), normalize( vBitangent ), normal );\n	#else\n		mat3 tbn2 = getTangentFrame( - vViewPosition, normal, vClearcoatNormalMapUv );\n	#endif\n	#if defined( DOUBLE_SIDED ) && ! defined( FLAT_SHADED )\n		tbn2[0] *= faceDirection;\n		tbn2[1] *= faceDirection;\n	#endif\n#endif\nvec3 nonPerturbedNormal = normal;",normal_fragment_maps:"#ifdef USE_NORMALMAP_OBJECTSPACE\n	normal = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#ifdef FLIP_SIDED\n		normal = - normal;\n	#endif\n	#ifdef DOUBLE_SIDED\n		normal = normal * faceDirection;\n	#endif\n	normal = normalize( normalMatrix * normal );\n#elif defined( USE_NORMALMAP_TANGENTSPACE )\n	vec3 mapN = texture2D( normalMap, vNormalMapUv ).xyz * 2.0 - 1.0;\n	#if defined( USE_PACKED_NORMALMAP )\n		mapN = vec3( mapN.xy, sqrt( saturate( 1.0 - dot( mapN.xy, mapN.xy ) ) ) );\n	#endif\n	mapN.xy *= normalScale;\n	normal = normalize( tbn * mapN );\n#elif defined( USE_BUMPMAP )\n	normal = perturbNormalArb( - vViewPosition, normal, dHdxy_fwd(), faceDirection );\n#endif",normal_pars_fragment:"#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",normal_pars_vertex:"#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n	#ifdef USE_TANGENT\n		varying vec3 vTangent;\n		varying vec3 vBitangent;\n	#endif\n#endif",normal_vertex:"#ifndef FLAT_SHADED\n	vNormal = normalize( transformedNormal );\n	#ifdef USE_TANGENT\n		vTangent = normalize( transformedTangent );\n		vBitangent = normalize( cross( vNormal, vTangent ) * tangent.w );\n	#endif\n#endif",normalmap_pars_fragment:"#ifdef USE_NORMALMAP\n	uniform sampler2D normalMap;\n	uniform vec2 normalScale;\n#endif\n#ifdef USE_NORMALMAP_OBJECTSPACE\n	uniform mat3 normalMatrix;\n#endif\n#if ! defined ( USE_TANGENT ) && ( defined ( USE_NORMALMAP_TANGENTSPACE ) || defined ( USE_CLEARCOAT_NORMALMAP ) || defined( USE_ANISOTROPY ) )\n	mat3 getTangentFrame( vec3 eye_pos, vec3 surf_norm, vec2 uv ) {\n		vec3 q0 = dFdx( eye_pos.xyz );\n		vec3 q1 = dFdy( eye_pos.xyz );\n		vec2 st0 = dFdx( uv.st );\n		vec2 st1 = dFdy( uv.st );\n		vec3 N = surf_norm;\n		vec3 q1perp = cross( q1, N );\n		vec3 q0perp = cross( N, q0 );\n		vec3 T = q1perp * st0.x + q0perp * st1.x;\n		vec3 B = q1perp * st0.y + q0perp * st1.y;\n		float det = max( dot( T, T ), dot( B, B ) );\n		float scale = ( det == 0.0 ) ? 0.0 : inversesqrt( det );\n		return mat3( T * scale, B * scale, N );\n	}\n#endif",clearcoat_normal_fragment_begin:"#ifdef USE_CLEARCOAT\n	vec3 clearcoatNormal = nonPerturbedNormal;\n#endif",clearcoat_normal_fragment_maps:"#ifdef USE_CLEARCOAT_NORMALMAP\n	vec3 clearcoatMapN = texture2D( clearcoatNormalMap, vClearcoatNormalMapUv ).xyz * 2.0 - 1.0;\n	clearcoatMapN.xy *= clearcoatNormalScale;\n	clearcoatNormal = normalize( tbn2 * clearcoatMapN );\n#endif",clearcoat_pars_fragment:"#ifdef USE_CLEARCOATMAP\n	uniform sampler2D clearcoatMap;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform sampler2D clearcoatNormalMap;\n	uniform vec2 clearcoatNormalScale;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform sampler2D clearcoatRoughnessMap;\n#endif",iridescence_pars_fragment:"#ifdef USE_IRIDESCENCEMAP\n	uniform sampler2D iridescenceMap;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform sampler2D iridescenceThicknessMap;\n#endif",opaque_fragment:"#ifdef OPAQUE\ndiffuseColor.a = 1.0;\n#endif\n#ifdef USE_TRANSMISSION\ndiffuseColor.a *= material.transmissionAlpha;\n#endif\ngl_FragColor = vec4( outgoingLight, diffuseColor.a );",packing:"vec3 packNormalToRGB( const in vec3 normal ) {\n	return normalize( normal ) * 0.5 + 0.5;\n}\nvec3 unpackRGBToNormal( const in vec3 rgb ) {\n	return 2.0 * rgb.xyz - 1.0;\n}\nconst float PackUpscale = 256. / 255.;const float UnpackDownscale = 255. / 256.;const float ShiftRight8 = 1. / 256.;\nconst float Inv255 = 1. / 255.;\nconst vec4 PackFactors = vec4( 1.0, 256.0, 256.0 * 256.0, 256.0 * 256.0 * 256.0 );\nconst vec2 UnpackFactors2 = vec2( UnpackDownscale, 1.0 / PackFactors.g );\nconst vec3 UnpackFactors3 = vec3( UnpackDownscale / PackFactors.rg, 1.0 / PackFactors.b );\nconst vec4 UnpackFactors4 = vec4( UnpackDownscale / PackFactors.rgb, 1.0 / PackFactors.a );\nvec4 packDepthToRGBA( const in float v ) {\n	if( v <= 0.0 )\n		return vec4( 0., 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec4( 1., 1., 1., 1. );\n	float vuf;\n	float af = modf( v * PackFactors.a, vuf );\n	float bf = modf( vuf * ShiftRight8, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec4( vuf * Inv255, gf * PackUpscale, bf * PackUpscale, af );\n}\nvec3 packDepthToRGB( const in float v ) {\n	if( v <= 0.0 )\n		return vec3( 0., 0., 0. );\n	if( v >= 1.0 )\n		return vec3( 1., 1., 1. );\n	float vuf;\n	float bf = modf( v * PackFactors.b, vuf );\n	float gf = modf( vuf * ShiftRight8, vuf );\n	return vec3( vuf * Inv255, gf * PackUpscale, bf );\n}\nvec2 packDepthToRG( const in float v ) {\n	if( v <= 0.0 )\n		return vec2( 0., 0. );\n	if( v >= 1.0 )\n		return vec2( 1., 1. );\n	float vuf;\n	float gf = modf( v * 256., vuf );\n	return vec2( vuf * Inv255, gf );\n}\nfloat unpackRGBAToDepth( const in vec4 v ) {\n	return dot( v, UnpackFactors4 );\n}\nfloat unpackRGBToDepth( const in vec3 v ) {\n	return dot( v, UnpackFactors3 );\n}\nfloat unpackRGToDepth( const in vec2 v ) {\n	return v.r * UnpackFactors2.r + v.g * UnpackFactors2.g;\n}\nvec4 pack2HalfToRGBA( const in vec2 v ) {\n	vec4 r = vec4( v.x, fract( v.x * 255.0 ), v.y, fract( v.y * 255.0 ) );\n	return vec4( r.x - r.y / 255.0, r.y, r.z - r.w / 255.0, r.w );\n}\nvec2 unpackRGBATo2Half( const in vec4 v ) {\n	return vec2( v.x + ( v.y / 255.0 ), v.z + ( v.w / 255.0 ) );\n}\nfloat viewZToOrthographicDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( viewZ + near ) / ( near - far );\n}\nfloat orthographicDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n	\n		return depth * ( far - near ) - far;\n	#else\n		return depth * ( near - far ) - near;\n	#endif\n}\nfloat viewZToPerspectiveDepth( const in float viewZ, const in float near, const in float far ) {\n	return ( ( near + viewZ ) * far ) / ( ( far - near ) * viewZ );\n}\nfloat perspectiveDepthToViewZ( const in float depth, const in float near, const in float far ) {\n	\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n		return ( near * far ) / ( ( near - far ) * depth - near );\n	#else\n		return ( near * far ) / ( ( far - near ) * depth - far );\n	#endif\n}",premultiplied_alpha_fragment:"#ifdef PREMULTIPLIED_ALPHA\n	gl_FragColor.rgb *= gl_FragColor.a;\n#endif",project_vertex:"vec4 mvPosition = vec4( transformed, 1.0 );\n#ifdef USE_BATCHING\n	mvPosition = batchingMatrix * mvPosition;\n#endif\n#ifdef USE_INSTANCING\n	mvPosition = instanceMatrix * mvPosition;\n#endif\nmvPosition = modelViewMatrix * mvPosition;\ngl_Position = projectionMatrix * mvPosition;",dithering_fragment:"#ifdef DITHERING\n	gl_FragColor.rgb = dithering( gl_FragColor.rgb );\n#endif",dithering_pars_fragment:"#ifdef DITHERING\n	vec3 dithering( vec3 color ) {\n		float grid_position = rand( gl_FragCoord.xy );\n		vec3 dither_shift_RGB = vec3( 0.25 / 255.0, -0.25 / 255.0, 0.25 / 255.0 );\n		dither_shift_RGB = mix( 2.0 * dither_shift_RGB, -2.0 * dither_shift_RGB, grid_position );\n		return color + dither_shift_RGB;\n	}\n#endif",roughnessmap_fragment:"float roughnessFactor = roughness;\n#ifdef USE_ROUGHNESSMAP\n	vec4 texelRoughness = texture2D( roughnessMap, vRoughnessMapUv );\n	roughnessFactor *= texelRoughness.g;\n#endif",roughnessmap_pars_fragment:"#ifdef USE_ROUGHNESSMAP\n	uniform sampler2D roughnessMap;\n#endif",shadowmap_pars_fragment:"#if NUM_SPOT_LIGHT_COORDS > 0\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#if NUM_SPOT_LIGHT_MAPS > 0\n	uniform sampler2D spotLightMap[ NUM_SPOT_LIGHT_MAPS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D directionalShadowMap[ NUM_DIR_LIGHT_SHADOWS ];\n		#endif\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform sampler2DShadow spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		#else\n			uniform sampler2D spotShadowMap[ NUM_SPOT_LIGHT_SHADOWS ];\n		#endif\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#if defined( SHADOWMAP_TYPE_PCF )\n			uniform samplerCubeShadow pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		#elif defined( SHADOWMAP_TYPE_BASIC )\n			uniform samplerCube pointShadowMap[ NUM_POINT_LIGHT_SHADOWS ];\n		#endif\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n	#if defined( SHADOWMAP_TYPE_PCF )\n		float interleavedGradientNoise( vec2 position ) {\n			return fract( 52.9829189 * fract( dot( position, vec2( 0.06711056, 0.00583715 ) ) ) );\n		}\n		vec2 vogelDiskSample( int sampleIndex, int samplesCount, float phi ) {\n			const float goldenAngle = 2.399963229728653;\n			float r = sqrt( ( float( sampleIndex ) + 0.5 ) / float( samplesCount ) );\n			float theta = float( sampleIndex ) * goldenAngle + phi;\n			return vec2( cos( theta ), sin( theta ) ) * r;\n		}\n	#endif\n	#if defined( SHADOWMAP_TYPE_PCF )\n		float getShadow( sampler2DShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			shadowCoord.z += shadowBias;\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				vec2 texelSize = vec2( 1.0 ) / shadowMapSize;\n				float radius = shadowRadius * texelSize.x;\n				float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;\n				shadow = (\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 0, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 1, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 2, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 3, 5, phi ) * radius, shadowCoord.z ) ) +\n					texture( shadowMap, vec3( shadowCoord.xy + vogelDiskSample( 4, 5, phi ) * radius, shadowCoord.z ) )\n				) * 0.2;\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#elif defined( SHADOWMAP_TYPE_VSM )\n		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				shadowCoord.z -= shadowBias;\n			#else\n				shadowCoord.z += shadowBias;\n			#endif\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				vec2 distribution = texture2D( shadowMap, shadowCoord.xy ).rg;\n				float mean = distribution.x;\n				float variance = distribution.y * distribution.y;\n				#ifdef USE_REVERSED_DEPTH_BUFFER\n					float hard_shadow = step( mean, shadowCoord.z );\n				#else\n					float hard_shadow = step( shadowCoord.z, mean );\n				#endif\n				\n				if ( hard_shadow == 1.0 ) {\n					shadow = 1.0;\n				} else {\n					variance = max( variance, 0.0000001 );\n					float d = shadowCoord.z - mean;\n					float p_max = variance / ( variance + d * d );\n					p_max = clamp( ( p_max - 0.3 ) / 0.65, 0.0, 1.0 );\n					shadow = max( hard_shadow, p_max );\n				}\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#else\n		float getShadow( sampler2D shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord ) {\n			float shadow = 1.0;\n			shadowCoord.xyz /= shadowCoord.w;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				shadowCoord.z -= shadowBias;\n			#else\n				shadowCoord.z += shadowBias;\n			#endif\n			bool inFrustum = shadowCoord.x >= 0.0 && shadowCoord.x <= 1.0 && shadowCoord.y >= 0.0 && shadowCoord.y <= 1.0;\n			bool frustumTest = inFrustum && shadowCoord.z <= 1.0;\n			if ( frustumTest ) {\n				float depth = texture2D( shadowMap, shadowCoord.xy ).r;\n				#ifdef USE_REVERSED_DEPTH_BUFFER\n					shadow = step( depth, shadowCoord.z );\n				#else\n					shadow = step( shadowCoord.z, depth );\n				#endif\n			}\n			return mix( 1.0, shadow, shadowIntensity );\n		}\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n	#if defined( SHADOWMAP_TYPE_PCF )\n	float getPointShadow( samplerCubeShadow shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		vec3 bd3D = normalize( lightToPosition );\n		vec3 absVec = abs( lightToPosition );\n		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );\n		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				float dp = ( shadowCameraNear * ( shadowCameraFar - viewSpaceZ ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n				dp -= shadowBias;\n			#else\n				float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n				dp += shadowBias;\n			#endif\n			float texelSize = shadowRadius / shadowMapSize.x;\n			vec3 absDir = abs( bd3D );\n			vec3 tangent = absDir.x > absDir.z ? vec3( 0.0, 1.0, 0.0 ) : vec3( 1.0, 0.0, 0.0 );\n			tangent = normalize( cross( bd3D, tangent ) );\n			vec3 bitangent = cross( bd3D, tangent );\n			float phi = interleavedGradientNoise( gl_FragCoord.xy ) * PI2;\n			vec2 sample0 = vogelDiskSample( 0, 5, phi );\n			vec2 sample1 = vogelDiskSample( 1, 5, phi );\n			vec2 sample2 = vogelDiskSample( 2, 5, phi );\n			vec2 sample3 = vogelDiskSample( 3, 5, phi );\n			vec2 sample4 = vogelDiskSample( 4, 5, phi );\n			shadow = (\n				texture( shadowMap, vec4( bd3D + ( tangent * sample0.x + bitangent * sample0.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample1.x + bitangent * sample1.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample2.x + bitangent * sample2.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample3.x + bitangent * sample3.y ) * texelSize, dp ) ) +\n				texture( shadowMap, vec4( bd3D + ( tangent * sample4.x + bitangent * sample4.y ) * texelSize, dp ) )\n			) * 0.2;\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	#elif defined( SHADOWMAP_TYPE_BASIC )\n	float getPointShadow( samplerCube shadowMap, vec2 shadowMapSize, float shadowIntensity, float shadowBias, float shadowRadius, vec4 shadowCoord, float shadowCameraNear, float shadowCameraFar ) {\n		float shadow = 1.0;\n		vec3 lightToPosition = shadowCoord.xyz;\n		vec3 absVec = abs( lightToPosition );\n		float viewSpaceZ = max( max( absVec.x, absVec.y ), absVec.z );\n		if ( viewSpaceZ - shadowCameraFar <= 0.0 && viewSpaceZ - shadowCameraNear >= 0.0 ) {\n			float dp = ( shadowCameraFar * ( viewSpaceZ - shadowCameraNear ) ) / ( viewSpaceZ * ( shadowCameraFar - shadowCameraNear ) );\n			dp += shadowBias;\n			vec3 bd3D = normalize( lightToPosition );\n			float depth = textureCube( shadowMap, bd3D ).r;\n			#ifdef USE_REVERSED_DEPTH_BUFFER\n				depth = 1.0 - depth;\n			#endif\n			shadow = step( dp, depth );\n		}\n		return mix( 1.0, shadow, shadowIntensity );\n	}\n	#endif\n	#endif\n#endif",shadowmap_pars_vertex:"#if NUM_SPOT_LIGHT_COORDS > 0\n	uniform mat4 spotLightMatrix[ NUM_SPOT_LIGHT_COORDS ];\n	varying vec4 vSpotLightCoord[ NUM_SPOT_LIGHT_COORDS ];\n#endif\n#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		uniform mat4 directionalShadowMatrix[ NUM_DIR_LIGHT_SHADOWS ];\n		varying vec4 vDirectionalShadowCoord[ NUM_DIR_LIGHT_SHADOWS ];\n		struct DirectionalLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform DirectionalLightShadow directionalLightShadows[ NUM_DIR_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n		struct SpotLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n		};\n		uniform SpotLightShadow spotLightShadows[ NUM_SPOT_LIGHT_SHADOWS ];\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		uniform mat4 pointShadowMatrix[ NUM_POINT_LIGHT_SHADOWS ];\n		varying vec4 vPointShadowCoord[ NUM_POINT_LIGHT_SHADOWS ];\n		struct PointLightShadow {\n			float shadowIntensity;\n			float shadowBias;\n			float shadowNormalBias;\n			float shadowRadius;\n			vec2 shadowMapSize;\n			float shadowCameraNear;\n			float shadowCameraFar;\n		};\n		uniform PointLightShadow pointLightShadows[ NUM_POINT_LIGHT_SHADOWS ];\n	#endif\n#endif",shadowmap_vertex:"#if ( defined( USE_SHADOWMAP ) && ( NUM_DIR_LIGHT_SHADOWS > 0 || NUM_POINT_LIGHT_SHADOWS > 0 ) ) || ( NUM_SPOT_LIGHT_COORDS > 0 )\n	#ifdef HAS_NORMAL\n		vec3 shadowWorldNormal = inverseTransformDirection( transformedNormal, viewMatrix );\n	#else\n		vec3 shadowWorldNormal = vec3( 0.0 );\n	#endif\n	vec4 shadowWorldPosition;\n#endif\n#if defined( USE_SHADOWMAP )\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * directionalLightShadows[ i ].shadowNormalBias, 0 );\n			vDirectionalShadowCoord[ i ] = directionalShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0\n		#pragma unroll_loop_start\n		for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n			shadowWorldPosition = worldPosition + vec4( shadowWorldNormal * pointLightShadows[ i ].shadowNormalBias, 0 );\n			vPointShadowCoord[ i ] = pointShadowMatrix[ i ] * shadowWorldPosition;\n		}\n		#pragma unroll_loop_end\n	#endif\n#endif\n#if NUM_SPOT_LIGHT_COORDS > 0\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_COORDS; i ++ ) {\n		shadowWorldPosition = worldPosition;\n		#if ( defined( USE_SHADOWMAP ) && UNROLLED_LOOP_INDEX < NUM_SPOT_LIGHT_SHADOWS )\n			shadowWorldPosition.xyz += shadowWorldNormal * spotLightShadows[ i ].shadowNormalBias;\n		#endif\n		vSpotLightCoord[ i ] = spotLightMatrix[ i ] * shadowWorldPosition;\n	}\n	#pragma unroll_loop_end\n#endif",shadowmask_pars_fragment:"float getShadowMask() {\n	float shadow = 1.0;\n	#ifdef USE_SHADOWMAP\n	#if NUM_DIR_LIGHT_SHADOWS > 0\n	DirectionalLightShadow directionalLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_DIR_LIGHT_SHADOWS; i ++ ) {\n		directionalLight = directionalLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( directionalShadowMap[ i ], directionalLight.shadowMapSize, directionalLight.shadowIntensity, directionalLight.shadowBias, directionalLight.shadowRadius, vDirectionalShadowCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_SPOT_LIGHT_SHADOWS > 0\n	SpotLightShadow spotLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_SPOT_LIGHT_SHADOWS; i ++ ) {\n		spotLight = spotLightShadows[ i ];\n		shadow *= receiveShadow ? getShadow( spotShadowMap[ i ], spotLight.shadowMapSize, spotLight.shadowIntensity, spotLight.shadowBias, spotLight.shadowRadius, vSpotLightCoord[ i ] ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#if NUM_POINT_LIGHT_SHADOWS > 0 && ( defined( SHADOWMAP_TYPE_PCF ) || defined( SHADOWMAP_TYPE_BASIC ) )\n	PointLightShadow pointLight;\n	#pragma unroll_loop_start\n	for ( int i = 0; i < NUM_POINT_LIGHT_SHADOWS; i ++ ) {\n		pointLight = pointLightShadows[ i ];\n		shadow *= receiveShadow ? getPointShadow( pointShadowMap[ i ], pointLight.shadowMapSize, pointLight.shadowIntensity, pointLight.shadowBias, pointLight.shadowRadius, vPointShadowCoord[ i ], pointLight.shadowCameraNear, pointLight.shadowCameraFar ) : 1.0;\n	}\n	#pragma unroll_loop_end\n	#endif\n	#endif\n	return shadow;\n}",skinbase_vertex:"#ifdef USE_SKINNING\n	mat4 boneMatX = getBoneMatrix( skinIndex.x );\n	mat4 boneMatY = getBoneMatrix( skinIndex.y );\n	mat4 boneMatZ = getBoneMatrix( skinIndex.z );\n	mat4 boneMatW = getBoneMatrix( skinIndex.w );\n#endif",skinning_pars_vertex:"#ifdef USE_SKINNING\n	uniform mat4 bindMatrix;\n	uniform mat4 bindMatrixInverse;\n	uniform highp sampler2D boneTexture;\n	mat4 getBoneMatrix( const in float i ) {\n		int size = textureSize( boneTexture, 0 ).x;\n		int j = int( i ) * 4;\n		int x = j % size;\n		int y = j / size;\n		vec4 v1 = texelFetch( boneTexture, ivec2( x, y ), 0 );\n		vec4 v2 = texelFetch( boneTexture, ivec2( x + 1, y ), 0 );\n		vec4 v3 = texelFetch( boneTexture, ivec2( x + 2, y ), 0 );\n		vec4 v4 = texelFetch( boneTexture, ivec2( x + 3, y ), 0 );\n		return mat4( v1, v2, v3, v4 );\n	}\n#endif",skinning_vertex:"#ifdef USE_SKINNING\n	vec4 skinVertex = bindMatrix * vec4( transformed, 1.0 );\n	vec4 skinned = vec4( 0.0 );\n	skinned += boneMatX * skinVertex * skinWeight.x;\n	skinned += boneMatY * skinVertex * skinWeight.y;\n	skinned += boneMatZ * skinVertex * skinWeight.z;\n	skinned += boneMatW * skinVertex * skinWeight.w;\n	transformed = ( bindMatrixInverse * skinned ).xyz;\n#endif",skinnormal_vertex:"#ifdef USE_SKINNING\n	mat4 skinMatrix = mat4( 0.0 );\n	skinMatrix += skinWeight.x * boneMatX;\n	skinMatrix += skinWeight.y * boneMatY;\n	skinMatrix += skinWeight.z * boneMatZ;\n	skinMatrix += skinWeight.w * boneMatW;\n	skinMatrix = bindMatrixInverse * skinMatrix * bindMatrix;\n	objectNormal = vec4( skinMatrix * vec4( objectNormal, 0.0 ) ).xyz;\n	#ifdef USE_TANGENT\n		objectTangent = vec4( skinMatrix * vec4( objectTangent, 0.0 ) ).xyz;\n	#endif\n#endif",specularmap_fragment:"float specularStrength;\n#ifdef USE_SPECULARMAP\n	vec4 texelSpecular = texture2D( specularMap, vSpecularMapUv );\n	specularStrength = texelSpecular.r;\n#else\n	specularStrength = 1.0;\n#endif",specularmap_pars_fragment:"#ifdef USE_SPECULARMAP\n	uniform sampler2D specularMap;\n#endif",tonemapping_fragment:"#if defined( TONE_MAPPING )\n	gl_FragColor.rgb = toneMapping( gl_FragColor.rgb );\n#endif",tonemapping_pars_fragment:"#ifndef saturate\n#define saturate( a ) clamp( a, 0.0, 1.0 )\n#endif\nuniform float toneMappingExposure;\nvec3 LinearToneMapping( vec3 color ) {\n	return saturate( toneMappingExposure * color );\n}\nvec3 ReinhardToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	return saturate( color / ( vec3( 1.0 ) + color ) );\n}\nvec3 CineonToneMapping( vec3 color ) {\n	color *= toneMappingExposure;\n	color = max( vec3( 0.0 ), color - 0.004 );\n	return pow( ( color * ( 6.2 * color + 0.5 ) ) / ( color * ( 6.2 * color + 1.7 ) + 0.06 ), vec3( 2.2 ) );\n}\nvec3 RRTAndODTFit( vec3 v ) {\n	vec3 a = v * ( v + 0.0245786 ) - 0.000090537;\n	vec3 b = v * ( 0.983729 * v + 0.4329510 ) + 0.238081;\n	return a / b;\n}\nvec3 ACESFilmicToneMapping( vec3 color ) {\n	const mat3 ACESInputMat = mat3(\n		vec3( 0.59719, 0.07600, 0.02840 ),		vec3( 0.35458, 0.90834, 0.13383 ),\n		vec3( 0.04823, 0.01566, 0.83777 )\n	);\n	const mat3 ACESOutputMat = mat3(\n		vec3(  1.60475, -0.10208, -0.00327 ),		vec3( -0.53108,  1.10813, -0.07276 ),\n		vec3( -0.07367, -0.00605,  1.07602 )\n	);\n	color *= toneMappingExposure / 0.6;\n	color = ACESInputMat * color;\n	color = RRTAndODTFit( color );\n	color = ACESOutputMat * color;\n	return saturate( color );\n}\nconst mat3 LINEAR_REC2020_TO_LINEAR_SRGB = mat3(\n	vec3( 1.6605, - 0.1246, - 0.0182 ),\n	vec3( - 0.5876, 1.1329, - 0.1006 ),\n	vec3( - 0.0728, - 0.0083, 1.1187 )\n);\nconst mat3 LINEAR_SRGB_TO_LINEAR_REC2020 = mat3(\n	vec3( 0.6274, 0.0691, 0.0164 ),\n	vec3( 0.3293, 0.9195, 0.0880 ),\n	vec3( 0.0433, 0.0113, 0.8956 )\n);\nvec3 agxDefaultContrastApprox( vec3 x ) {\n	vec3 x2 = x * x;\n	vec3 x4 = x2 * x2;\n	return + 15.5 * x4 * x2\n		- 40.14 * x4 * x\n		+ 31.96 * x4\n		- 6.868 * x2 * x\n		+ 0.4298 * x2\n		+ 0.1191 * x\n		- 0.00232;\n}\nvec3 AgXToneMapping( vec3 color ) {\n	const mat3 AgXInsetMatrix = mat3(\n		vec3( 0.856627153315983, 0.137318972929847, 0.11189821299995 ),\n		vec3( 0.0951212405381588, 0.761241990602591, 0.0767994186031903 ),\n		vec3( 0.0482516061458583, 0.101439036467562, 0.811302368396859 )\n	);\n	const mat3 AgXOutsetMatrix = mat3(\n		vec3( 1.1271005818144368, - 0.1413297634984383, - 0.14132976349843826 ),\n		vec3( - 0.11060664309660323, 1.157823702216272, - 0.11060664309660294 ),\n		vec3( - 0.016493938717834573, - 0.016493938717834257, 1.2519364065950405 )\n	);\n	const float AgxMinEv = - 12.47393;	const float AgxMaxEv = 4.026069;\n	color *= toneMappingExposure;\n	color = LINEAR_SRGB_TO_LINEAR_REC2020 * color;\n	color = AgXInsetMatrix * color;\n	color = max( color, 1e-10 );	color = log2( color );\n	color = ( color - AgxMinEv ) / ( AgxMaxEv - AgxMinEv );\n	color = clamp( color, 0.0, 1.0 );\n	color = agxDefaultContrastApprox( color );\n	color = AgXOutsetMatrix * color;\n	color = pow( max( vec3( 0.0 ), color ), vec3( 2.2 ) );\n	color = LINEAR_REC2020_TO_LINEAR_SRGB * color;\n	color = clamp( color, 0.0, 1.0 );\n	return color;\n}\nvec3 NeutralToneMapping( vec3 color ) {\n	const float StartCompression = 0.8 - 0.04;\n	const float Desaturation = 0.15;\n	color *= toneMappingExposure;\n	float x = min( color.r, min( color.g, color.b ) );\n	float offset = x < 0.08 ? x - 6.25 * x * x : 0.04;\n	color -= offset;\n	float peak = max( color.r, max( color.g, color.b ) );\n	if ( peak < StartCompression ) return color;\n	float d = 1. - StartCompression;\n	float newPeak = 1. - d * d / ( peak + d - StartCompression );\n	color *= newPeak / peak;\n	float g = 1. - 1. / ( Desaturation * ( peak - newPeak ) + 1. );\n	return mix( color, vec3( newPeak ), g );\n}\nvec3 CustomToneMapping( vec3 color ) { return color; }",transmission_fragment:"#ifdef USE_TRANSMISSION\n	material.transmission = transmission;\n	material.transmissionAlpha = 1.0;\n	material.thickness = thickness;\n	material.attenuationDistance = attenuationDistance;\n	material.attenuationColor = attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		material.transmission *= texture2D( transmissionMap, vTransmissionMapUv ).r;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		material.thickness *= texture2D( thicknessMap, vThicknessMapUv ).g;\n	#endif\n	vec3 pos = vWorldPosition;\n	vec3 v = normalize( cameraPosition - pos );\n	vec3 n = inverseTransformDirection( normal, viewMatrix );\n	vec4 transmitted = getIBLVolumeRefraction(\n		n, v, material.roughness, material.diffuseContribution, material.specularColorBlended, material.specularF90,\n		pos, modelMatrix, viewMatrix, projectionMatrix, material.dispersion, material.ior, material.thickness,\n		material.attenuationColor, material.attenuationDistance );\n	material.transmissionAlpha = mix( material.transmissionAlpha, transmitted.a, material.transmission );\n	totalDiffuse = mix( totalDiffuse, transmitted.rgb, material.transmission );\n#endif",transmission_pars_fragment:"#ifdef USE_TRANSMISSION\n	uniform float transmission;\n	uniform float thickness;\n	uniform float attenuationDistance;\n	uniform vec3 attenuationColor;\n	#ifdef USE_TRANSMISSIONMAP\n		uniform sampler2D transmissionMap;\n	#endif\n	#ifdef USE_THICKNESSMAP\n		uniform sampler2D thicknessMap;\n	#endif\n	uniform vec2 transmissionSamplerSize;\n	uniform sampler2D transmissionSamplerMap;\n	uniform mat4 modelMatrix;\n	uniform mat4 projectionMatrix;\n	varying vec3 vWorldPosition;\n	float w0( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - a + 3.0 ) - 3.0 ) + 1.0 );\n	}\n	float w1( float a ) {\n		return ( 1.0 / 6.0 ) * ( a *  a * ( 3.0 * a - 6.0 ) + 4.0 );\n	}\n	float w2( float a ){\n		return ( 1.0 / 6.0 ) * ( a * ( a * ( - 3.0 * a + 3.0 ) + 3.0 ) + 1.0 );\n	}\n	float w3( float a ) {\n		return ( 1.0 / 6.0 ) * ( a * a * a );\n	}\n	float g0( float a ) {\n		return w0( a ) + w1( a );\n	}\n	float g1( float a ) {\n		return w2( a ) + w3( a );\n	}\n	float h0( float a ) {\n		return - 1.0 + w1( a ) / ( w0( a ) + w1( a ) );\n	}\n	float h1( float a ) {\n		return 1.0 + w3( a ) / ( w2( a ) + w3( a ) );\n	}\n	vec4 bicubic( sampler2D tex, vec2 uv, vec4 texelSize, float lod ) {\n		uv = uv * texelSize.zw + 0.5;\n		vec2 iuv = floor( uv );\n		vec2 fuv = fract( uv );\n		float g0x = g0( fuv.x );\n		float g1x = g1( fuv.x );\n		float h0x = h0( fuv.x );\n		float h1x = h1( fuv.x );\n		float h0y = h0( fuv.y );\n		float h1y = h1( fuv.y );\n		vec2 p0 = ( vec2( iuv.x + h0x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p1 = ( vec2( iuv.x + h1x, iuv.y + h0y ) - 0.5 ) * texelSize.xy;\n		vec2 p2 = ( vec2( iuv.x + h0x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		vec2 p3 = ( vec2( iuv.x + h1x, iuv.y + h1y ) - 0.5 ) * texelSize.xy;\n		return g0( fuv.y ) * ( g0x * textureLod( tex, p0, lod ) + g1x * textureLod( tex, p1, lod ) ) +\n			g1( fuv.y ) * ( g0x * textureLod( tex, p2, lod ) + g1x * textureLod( tex, p3, lod ) );\n	}\n	vec4 textureBicubic( sampler2D sampler, vec2 uv, float lod ) {\n		vec2 fLodSize = vec2( textureSize( sampler, int( lod ) ) );\n		vec2 cLodSize = vec2( textureSize( sampler, int( lod + 1.0 ) ) );\n		vec2 fLodSizeInv = 1.0 / fLodSize;\n		vec2 cLodSizeInv = 1.0 / cLodSize;\n		vec4 fSample = bicubic( sampler, uv, vec4( fLodSizeInv, fLodSize ), floor( lod ) );\n		vec4 cSample = bicubic( sampler, uv, vec4( cLodSizeInv, cLodSize ), ceil( lod ) );\n		return mix( fSample, cSample, fract( lod ) );\n	}\n	vec3 getVolumeTransmissionRay( const in vec3 n, const in vec3 v, const in float thickness, const in float ior, const in mat4 modelMatrix ) {\n		vec3 refractionVector = refract( - v, normalize( n ), 1.0 / ior );\n		vec3 modelScale;\n		modelScale.x = length( vec3( modelMatrix[ 0 ].xyz ) );\n		modelScale.y = length( vec3( modelMatrix[ 1 ].xyz ) );\n		modelScale.z = length( vec3( modelMatrix[ 2 ].xyz ) );\n		return normalize( refractionVector ) * thickness * modelScale;\n	}\n	float applyIorToRoughness( const in float roughness, const in float ior ) {\n		return roughness * clamp( ior * 2.0 - 2.0, 0.0, 1.0 );\n	}\n	vec4 getTransmissionSample( const in vec2 fragCoord, const in float roughness, const in float ior ) {\n		float lod = log2( transmissionSamplerSize.x ) * applyIorToRoughness( roughness, ior );\n		return textureBicubic( transmissionSamplerMap, fragCoord.xy, lod );\n	}\n	vec3 volumeAttenuation( const in float transmissionDistance, const in vec3 attenuationColor, const in float attenuationDistance ) {\n		if ( isinf( attenuationDistance ) ) {\n			return vec3( 1.0 );\n		} else {\n			vec3 attenuationCoefficient = -log( attenuationColor ) / attenuationDistance;\n			vec3 transmittance = exp( - attenuationCoefficient * transmissionDistance );			return transmittance;\n		}\n	}\n	vec4 getIBLVolumeRefraction( const in vec3 n, const in vec3 v, const in float roughness, const in vec3 diffuseColor,\n		const in vec3 specularColor, const in float specularF90, const in vec3 position, const in mat4 modelMatrix,\n		const in mat4 viewMatrix, const in mat4 projMatrix, const in float dispersion, const in float ior, const in float thickness,\n		const in vec3 attenuationColor, const in float attenuationDistance ) {\n		vec4 transmittedLight;\n		vec3 transmittance;\n		#ifdef USE_DISPERSION\n			float halfSpread = ( ior - 1.0 ) * 0.025 * dispersion;\n			vec3 iors = vec3( ior - halfSpread, ior, ior + halfSpread );\n			for ( int i = 0; i < 3; i ++ ) {\n				vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, iors[ i ], modelMatrix );\n				vec3 refractedRayExit = position + transmissionRay;\n				vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n				vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n				refractionCoords += 1.0;\n				refractionCoords /= 2.0;\n				vec4 transmissionSample = getTransmissionSample( refractionCoords, roughness, iors[ i ] );\n				transmittedLight[ i ] = transmissionSample[ i ];\n				transmittedLight.a += transmissionSample.a;\n				transmittance[ i ] = diffuseColor[ i ] * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance )[ i ];\n			}\n			transmittedLight.a /= 3.0;\n		#else\n			vec3 transmissionRay = getVolumeTransmissionRay( n, v, thickness, ior, modelMatrix );\n			vec3 refractedRayExit = position + transmissionRay;\n			vec4 ndcPos = projMatrix * viewMatrix * vec4( refractedRayExit, 1.0 );\n			vec2 refractionCoords = ndcPos.xy / ndcPos.w;\n			refractionCoords += 1.0;\n			refractionCoords /= 2.0;\n			transmittedLight = getTransmissionSample( refractionCoords, roughness, ior );\n			transmittance = diffuseColor * volumeAttenuation( length( transmissionRay ), attenuationColor, attenuationDistance );\n		#endif\n		vec3 attenuatedColor = transmittance * transmittedLight.rgb;\n		vec3 F = EnvironmentBRDF( n, v, specularColor, specularF90, roughness );\n		float transmittanceFactor = ( transmittance.r + transmittance.g + transmittance.b ) / 3.0;\n		return vec4( ( 1.0 - F ) * attenuatedColor, 1.0 - ( 1.0 - transmittedLight.a ) * transmittanceFactor );\n	}\n#endif",uv_pars_fragment:"#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",uv_pars_vertex:"#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	varying vec2 vUv;\n#endif\n#ifdef USE_MAP\n	uniform mat3 mapTransform;\n	varying vec2 vMapUv;\n#endif\n#ifdef USE_ALPHAMAP\n	uniform mat3 alphaMapTransform;\n	varying vec2 vAlphaMapUv;\n#endif\n#ifdef USE_LIGHTMAP\n	uniform mat3 lightMapTransform;\n	varying vec2 vLightMapUv;\n#endif\n#ifdef USE_AOMAP\n	uniform mat3 aoMapTransform;\n	varying vec2 vAoMapUv;\n#endif\n#ifdef USE_BUMPMAP\n	uniform mat3 bumpMapTransform;\n	varying vec2 vBumpMapUv;\n#endif\n#ifdef USE_NORMALMAP\n	uniform mat3 normalMapTransform;\n	varying vec2 vNormalMapUv;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	uniform mat3 displacementMapTransform;\n	varying vec2 vDisplacementMapUv;\n#endif\n#ifdef USE_EMISSIVEMAP\n	uniform mat3 emissiveMapTransform;\n	varying vec2 vEmissiveMapUv;\n#endif\n#ifdef USE_METALNESSMAP\n	uniform mat3 metalnessMapTransform;\n	varying vec2 vMetalnessMapUv;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	uniform mat3 roughnessMapTransform;\n	varying vec2 vRoughnessMapUv;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	uniform mat3 anisotropyMapTransform;\n	varying vec2 vAnisotropyMapUv;\n#endif\n#ifdef USE_CLEARCOATMAP\n	uniform mat3 clearcoatMapTransform;\n	varying vec2 vClearcoatMapUv;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	uniform mat3 clearcoatNormalMapTransform;\n	varying vec2 vClearcoatNormalMapUv;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	uniform mat3 clearcoatRoughnessMapTransform;\n	varying vec2 vClearcoatRoughnessMapUv;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	uniform mat3 sheenColorMapTransform;\n	varying vec2 vSheenColorMapUv;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	uniform mat3 sheenRoughnessMapTransform;\n	varying vec2 vSheenRoughnessMapUv;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	uniform mat3 iridescenceMapTransform;\n	varying vec2 vIridescenceMapUv;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	uniform mat3 iridescenceThicknessMapTransform;\n	varying vec2 vIridescenceThicknessMapUv;\n#endif\n#ifdef USE_SPECULARMAP\n	uniform mat3 specularMapTransform;\n	varying vec2 vSpecularMapUv;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	uniform mat3 specularColorMapTransform;\n	varying vec2 vSpecularColorMapUv;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	uniform mat3 specularIntensityMapTransform;\n	varying vec2 vSpecularIntensityMapUv;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	uniform mat3 transmissionMapTransform;\n	varying vec2 vTransmissionMapUv;\n#endif\n#ifdef USE_THICKNESSMAP\n	uniform mat3 thicknessMapTransform;\n	varying vec2 vThicknessMapUv;\n#endif",uv_vertex:"#if defined( USE_UV ) || defined( USE_ANISOTROPY )\n	vUv = vec3( uv, 1 ).xy;\n#endif\n#ifdef USE_MAP\n	vMapUv = ( mapTransform * vec3( MAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ALPHAMAP\n	vAlphaMapUv = ( alphaMapTransform * vec3( ALPHAMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_LIGHTMAP\n	vLightMapUv = ( lightMapTransform * vec3( LIGHTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_AOMAP\n	vAoMapUv = ( aoMapTransform * vec3( AOMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_BUMPMAP\n	vBumpMapUv = ( bumpMapTransform * vec3( BUMPMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_NORMALMAP\n	vNormalMapUv = ( normalMapTransform * vec3( NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_DISPLACEMENTMAP\n	vDisplacementMapUv = ( displacementMapTransform * vec3( DISPLACEMENTMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_EMISSIVEMAP\n	vEmissiveMapUv = ( emissiveMapTransform * vec3( EMISSIVEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_METALNESSMAP\n	vMetalnessMapUv = ( metalnessMapTransform * vec3( METALNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ROUGHNESSMAP\n	vRoughnessMapUv = ( roughnessMapTransform * vec3( ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_ANISOTROPYMAP\n	vAnisotropyMapUv = ( anisotropyMapTransform * vec3( ANISOTROPYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOATMAP\n	vClearcoatMapUv = ( clearcoatMapTransform * vec3( CLEARCOATMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_NORMALMAP\n	vClearcoatNormalMapUv = ( clearcoatNormalMapTransform * vec3( CLEARCOAT_NORMALMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_CLEARCOAT_ROUGHNESSMAP\n	vClearcoatRoughnessMapUv = ( clearcoatRoughnessMapTransform * vec3( CLEARCOAT_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCEMAP\n	vIridescenceMapUv = ( iridescenceMapTransform * vec3( IRIDESCENCEMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_IRIDESCENCE_THICKNESSMAP\n	vIridescenceThicknessMapUv = ( iridescenceThicknessMapTransform * vec3( IRIDESCENCE_THICKNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_COLORMAP\n	vSheenColorMapUv = ( sheenColorMapTransform * vec3( SHEEN_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SHEEN_ROUGHNESSMAP\n	vSheenRoughnessMapUv = ( sheenRoughnessMapTransform * vec3( SHEEN_ROUGHNESSMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULARMAP\n	vSpecularMapUv = ( specularMapTransform * vec3( SPECULARMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_COLORMAP\n	vSpecularColorMapUv = ( specularColorMapTransform * vec3( SPECULAR_COLORMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_SPECULAR_INTENSITYMAP\n	vSpecularIntensityMapUv = ( specularIntensityMapTransform * vec3( SPECULAR_INTENSITYMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_TRANSMISSIONMAP\n	vTransmissionMapUv = ( transmissionMapTransform * vec3( TRANSMISSIONMAP_UV, 1 ) ).xy;\n#endif\n#ifdef USE_THICKNESSMAP\n	vThicknessMapUv = ( thicknessMapTransform * vec3( THICKNESSMAP_UV, 1 ) ).xy;\n#endif",worldpos_vertex:"#if defined( USE_ENVMAP ) || defined( DISTANCE ) || defined ( USE_SHADOWMAP ) || defined ( USE_TRANSMISSION ) || NUM_SPOT_LIGHT_COORDS > 0\n	vec4 worldPosition = vec4( transformed, 1.0 );\n	#ifdef USE_BATCHING\n		worldPosition = batchingMatrix * worldPosition;\n	#endif\n	#ifdef USE_INSTANCING\n		worldPosition = instanceMatrix * worldPosition;\n	#endif\n	worldPosition = modelMatrix * worldPosition;\n#endif",background_vert:"varying vec2 vUv;\nuniform mat3 uvTransform;\nvoid main() {\n	vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	gl_Position = vec4( position.xy, 1.0, 1.0 );\n}",background_frag:"uniform sampler2D t2D;\nuniform float backgroundIntensity;\nvarying vec2 vUv;\nvoid main() {\n	vec4 texColor = texture2D( t2D, vUv );\n	#ifdef DECODE_VIDEO_TEXTURE\n		texColor = vec4( mix( pow( texColor.rgb * 0.9478672986 + vec3( 0.0521327014 ), vec3( 2.4 ) ), texColor.rgb * 0.0773993808, vec3( lessThanEqual( texColor.rgb, vec3( 0.04045 ) ) ) ), texColor.w );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",backgroundCube_vert:"varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",backgroundCube_frag:"#ifdef ENVMAP_TYPE_CUBE\n	uniform samplerCube envMap;\n#elif defined( ENVMAP_TYPE_CUBE_UV )\n	uniform sampler2D envMap;\n#endif\nuniform float backgroundBlurriness;\nuniform float backgroundIntensity;\nuniform mat3 backgroundRotation;\nvarying vec3 vWorldDirection;\n#include <cube_uv_reflection_fragment>\nvoid main() {\n	#ifdef ENVMAP_TYPE_CUBE\n		vec4 texColor = textureCube( envMap, backgroundRotation * vWorldDirection );\n	#elif defined( ENVMAP_TYPE_CUBE_UV )\n		vec4 texColor = textureCubeUV( envMap, backgroundRotation * vWorldDirection, backgroundBlurriness );\n	#else\n		vec4 texColor = vec4( 0.0, 0.0, 0.0, 1.0 );\n	#endif\n	texColor.rgb *= backgroundIntensity;\n	gl_FragColor = texColor;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",cube_vert:"varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n	gl_Position.z = gl_Position.w;\n}",cube_frag:"uniform samplerCube tCube;\nuniform float tFlip;\nuniform float opacity;\nvarying vec3 vWorldDirection;\nvoid main() {\n	vec4 texColor = textureCube( tCube, vec3( tFlip * vWorldDirection.x, vWorldDirection.yz ) );\n	gl_FragColor = texColor;\n	gl_FragColor.a *= opacity;\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",depth_vert:"#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vHighPrecisionZW = gl_Position.zw;\n}",depth_frag:"#if DEPTH_PACKING == 3200\n	uniform float opacity;\n#endif\n#include <common>\n#include <packing>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvarying vec2 vHighPrecisionZW;\nvoid main() {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#if DEPTH_PACKING == 3200\n		diffuseColor.a = opacity;\n	#endif\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <logdepthbuf_fragment>\n	#ifdef USE_REVERSED_DEPTH_BUFFER\n		float fragCoordZ = vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ];\n	#else\n		float fragCoordZ = 0.5 * vHighPrecisionZW[ 0 ] / vHighPrecisionZW[ 1 ] + 0.5;\n	#endif\n	#if DEPTH_PACKING == 3200\n		gl_FragColor = vec4( vec3( 1.0 - fragCoordZ ), opacity );\n	#elif DEPTH_PACKING == 3201\n		gl_FragColor = packDepthToRGBA( fragCoordZ );\n	#elif DEPTH_PACKING == 3202\n		gl_FragColor = vec4( packDepthToRGB( fragCoordZ ), 1.0 );\n	#elif DEPTH_PACKING == 3203\n		gl_FragColor = vec4( packDepthToRG( fragCoordZ ), 0.0, 1.0 );\n	#endif\n}",distance_vert:"#define DISTANCE\nvarying vec3 vWorldPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <skinbase_vertex>\n	#include <morphinstance_vertex>\n	#ifdef USE_DISPLACEMENTMAP\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <worldpos_vertex>\n	#include <clipping_planes_vertex>\n	vWorldPosition = worldPosition.xyz;\n}",distance_frag:"#define DISTANCE\nuniform vec3 referencePosition;\nuniform float nearDistance;\nuniform float farDistance;\nvarying vec3 vWorldPosition;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main () {\n	vec4 diffuseColor = vec4( 1.0 );\n	#include <clipping_planes_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	float dist = length( vWorldPosition - referencePosition );\n	dist = ( dist - nearDistance ) / ( farDistance - nearDistance );\n	dist = saturate( dist );\n	gl_FragColor = vec4( dist, 0.0, 0.0, 1.0 );\n}",equirect_vert:"varying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vWorldDirection = transformDirection( position, modelMatrix );\n	#include <begin_vertex>\n	#include <project_vertex>\n}",equirect_frag:"uniform sampler2D tEquirect;\nvarying vec3 vWorldDirection;\n#include <common>\nvoid main() {\n	vec3 direction = normalize( vWorldDirection );\n	vec2 sampleUV = equirectUv( direction );\n	gl_FragColor = texture2D( tEquirect, sampleUV );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n}",linedashed_vert:"uniform float scale;\nattribute float lineDistance;\nvarying float vLineDistance;\n#include <common>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	vLineDistance = scale * lineDistance;\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",linedashed_frag:"uniform vec3 diffuse;\nuniform float opacity;\nuniform float dashSize;\nuniform float totalSize;\nvarying float vLineDistance;\n#include <common>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	if ( mod( vLineDistance, totalSize ) > dashSize ) {\n		discard;\n	}\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",meshbasic_vert:"#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#if defined ( USE_ENVMAP ) || defined ( USE_SKINNING )\n		#include <beginnormal_vertex>\n		#include <morphnormal_vertex>\n		#include <skinbase_vertex>\n		#include <skinnormal_vertex>\n		#include <defaultnormal_vertex>\n	#endif\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <fog_vertex>\n}",meshbasic_frag:"uniform vec3 diffuse;\nuniform float opacity;\n#ifndef FLAT_SHADED\n	varying vec3 vNormal;\n#endif\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	#ifdef USE_LIGHTMAP\n		vec4 lightMapTexel = texture2D( lightMap, vLightMapUv );\n		reflectedLight.indirectDiffuse += lightMapTexel.rgb * lightMapIntensity * RECIPROCAL_PI;\n	#else\n		reflectedLight.indirectDiffuse += vec3( 1.0 );\n	#endif\n	#include <aomap_fragment>\n	reflectedLight.indirectDiffuse *= diffuseColor.rgb;\n	vec3 outgoingLight = reflectedLight.indirectDiffuse;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",meshlambert_vert:"#define LAMBERT\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",meshlambert_frag:"#define LAMBERT\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_lambert_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_lambert_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",meshmatcap_vert:"#define MATCAP\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <color_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n	vViewPosition = - mvPosition.xyz;\n}",meshmatcap_frag:"#define MATCAP\nuniform vec3 diffuse;\nuniform float opacity;\nuniform sampler2D matcap;\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	vec3 viewDir = normalize( vViewPosition );\n	vec3 x = normalize( vec3( viewDir.z, 0.0, - viewDir.x ) );\n	vec3 y = cross( viewDir, x );\n	vec2 uv = vec2( dot( x, normal ), dot( y, normal ) ) * 0.495 + 0.5;\n	#ifdef USE_MATCAP\n		vec4 matcapColor = texture2D( matcap, uv );\n	#else\n		vec4 matcapColor = vec4( vec3( mix( 0.2, 0.8, uv.y ) ), 1.0 );\n	#endif\n	vec3 outgoingLight = diffuseColor.rgb * matcapColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",meshnormal_vert:"#define NORMAL\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	vViewPosition = - mvPosition.xyz;\n#endif\n}",meshnormal_frag:"#define NORMAL\nuniform float opacity;\n#if defined( FLAT_SHADED ) || defined( USE_BUMPMAP ) || defined( USE_NORMALMAP_TANGENTSPACE )\n	varying vec3 vViewPosition;\n#endif\n#include <uv_pars_fragment>\n#include <normal_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( 0.0, 0.0, 0.0, opacity );\n	#include <clipping_planes_fragment>\n	#include <logdepthbuf_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	gl_FragColor = vec4( normalize( normal ) * 0.5 + 0.5, diffuseColor.a );\n	#ifdef OPAQUE\n		gl_FragColor.a = 1.0;\n	#endif\n}",meshphong_vert:"#define PHONG\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <envmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <envmap_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",meshphong_frag:"#define PHONG\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform vec3 specular;\nuniform float shininess;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_phong_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <specularmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <specularmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_phong_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + reflectedLight.directSpecular + reflectedLight.indirectSpecular + totalEmissiveRadiance;\n	#include <envmap_fragment>\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",meshphysical_vert:"#define STANDARD\nvarying vec3 vViewPosition;\n#ifdef USE_TRANSMISSION\n	varying vec3 vWorldPosition;\n#endif\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n#ifdef USE_TRANSMISSION\n	vWorldPosition = worldPosition.xyz;\n#endif\n}",meshphysical_frag:"#define STANDARD\n#ifdef PHYSICAL\n	#define IOR\n	#define USE_SPECULAR\n#endif\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float roughness;\nuniform float metalness;\nuniform float opacity;\n#ifdef IOR\n	uniform float ior;\n#endif\n#ifdef USE_SPECULAR\n	uniform float specularIntensity;\n	uniform vec3 specularColor;\n	#ifdef USE_SPECULAR_COLORMAP\n		uniform sampler2D specularColorMap;\n	#endif\n	#ifdef USE_SPECULAR_INTENSITYMAP\n		uniform sampler2D specularIntensityMap;\n	#endif\n#endif\n#ifdef USE_CLEARCOAT\n	uniform float clearcoat;\n	uniform float clearcoatRoughness;\n#endif\n#ifdef USE_DISPERSION\n	uniform float dispersion;\n#endif\n#ifdef USE_IRIDESCENCE\n	uniform float iridescence;\n	uniform float iridescenceIOR;\n	uniform float iridescenceThicknessMinimum;\n	uniform float iridescenceThicknessMaximum;\n#endif\n#ifdef USE_SHEEN\n	uniform vec3 sheenColor;\n	uniform float sheenRoughness;\n	#ifdef USE_SHEEN_COLORMAP\n		uniform sampler2D sheenColorMap;\n	#endif\n	#ifdef USE_SHEEN_ROUGHNESSMAP\n		uniform sampler2D sheenRoughnessMap;\n	#endif\n#endif\n#ifdef USE_ANISOTROPY\n	uniform vec2 anisotropyVector;\n	#ifdef USE_ANISOTROPYMAP\n		uniform sampler2D anisotropyMap;\n	#endif\n#endif\nvarying vec3 vViewPosition;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <iridescence_fragment>\n#include <cube_uv_reflection_fragment>\n#include <envmap_common_pars_fragment>\n#include <envmap_physical_pars_fragment>\n#include <fog_pars_fragment>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_physical_pars_fragment>\n#include <transmission_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <clearcoat_pars_fragment>\n#include <iridescence_pars_fragment>\n#include <roughnessmap_pars_fragment>\n#include <metalnessmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <roughnessmap_fragment>\n	#include <metalnessmap_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <clearcoat_normal_fragment_begin>\n	#include <clearcoat_normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_physical_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 totalDiffuse = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse;\n	vec3 totalSpecular = reflectedLight.directSpecular + reflectedLight.indirectSpecular;\n	#include <transmission_fragment>\n	vec3 outgoingLight = totalDiffuse + totalSpecular + totalEmissiveRadiance;\n	#ifdef USE_SHEEN\n \n		outgoingLight = outgoingLight + sheenSpecularDirect + sheenSpecularIndirect;\n \n 	#endif\n	#ifdef USE_CLEARCOAT\n		float dotNVcc = saturate( dot( geometryClearcoatNormal, geometryViewDir ) );\n		vec3 Fcc = F_Schlick( material.clearcoatF0, material.clearcoatF90, dotNVcc );\n		outgoingLight = outgoingLight * ( 1.0 - material.clearcoat * Fcc ) + ( clearcoatSpecularDirect + clearcoatSpecularIndirect ) * material.clearcoat;\n	#endif\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",meshtoon_vert:"#define TOON\nvarying vec3 vViewPosition;\n#include <common>\n#include <batching_pars_vertex>\n#include <uv_pars_vertex>\n#include <displacementmap_pars_vertex>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <normal_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <shadowmap_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <normal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <displacementmap_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	vViewPosition = - mvPosition.xyz;\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",meshtoon_frag:"#define TOON\nuniform vec3 diffuse;\nuniform vec3 emissive;\nuniform float opacity;\n#include <common>\n#include <dithering_pars_fragment>\n#include <color_pars_fragment>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <aomap_pars_fragment>\n#include <lightmap_pars_fragment>\n#include <emissivemap_pars_fragment>\n#include <gradientmap_pars_fragment>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <normal_pars_fragment>\n#include <lights_toon_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <bumpmap_pars_fragment>\n#include <normalmap_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	ReflectedLight reflectedLight = ReflectedLight( vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ), vec3( 0.0 ) );\n	vec3 totalEmissiveRadiance = emissive;\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <color_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	#include <normal_fragment_begin>\n	#include <normal_fragment_maps>\n	#include <emissivemap_fragment>\n	#include <lights_toon_fragment>\n	#include <lights_fragment_begin>\n	#include <lights_fragment_maps>\n	#include <lights_fragment_end>\n	#include <aomap_fragment>\n	vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n	#include <dithering_fragment>\n}",points_vert:"uniform float size;\nuniform float scale;\n#include <common>\n#include <color_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\n#ifdef USE_POINTS_UV\n	varying vec2 vUv;\n	uniform mat3 uvTransform;\n#endif\nvoid main() {\n	#ifdef USE_POINTS_UV\n		vUv = ( uvTransform * vec3( uv, 1 ) ).xy;\n	#endif\n	#include <color_vertex>\n	#include <morphinstance_vertex>\n	#include <morphcolor_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <project_vertex>\n	gl_PointSize = size;\n	#ifdef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) gl_PointSize *= ( scale / - mvPosition.z );\n	#endif\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <worldpos_vertex>\n	#include <fog_vertex>\n}",points_frag:"uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <color_pars_fragment>\n#include <map_particle_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_particle_fragment>\n	#include <color_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",shadow_vert:"#include <common>\n#include <batching_pars_vertex>\n#include <fog_pars_vertex>\n#include <morphtarget_pars_vertex>\n#include <skinning_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <shadowmap_pars_vertex>\nvoid main() {\n	#include <batching_vertex>\n	#include <beginnormal_vertex>\n	#include <morphinstance_vertex>\n	#include <morphnormal_vertex>\n	#include <skinbase_vertex>\n	#include <skinnormal_vertex>\n	#include <defaultnormal_vertex>\n	#include <begin_vertex>\n	#include <morphtarget_vertex>\n	#include <skinning_vertex>\n	#include <project_vertex>\n	#include <logdepthbuf_vertex>\n	#include <worldpos_vertex>\n	#include <shadowmap_vertex>\n	#include <fog_vertex>\n}",shadow_frag:"uniform vec3 color;\nuniform float opacity;\n#include <common>\n#include <fog_pars_fragment>\n#include <bsdfs>\n#include <lights_pars_begin>\n#include <logdepthbuf_pars_fragment>\n#include <shadowmap_pars_fragment>\n#include <shadowmask_pars_fragment>\nvoid main() {\n	#include <logdepthbuf_fragment>\n	gl_FragColor = vec4( color, opacity * ( 1.0 - getShadowMask() ) );\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n	#include <premultiplied_alpha_fragment>\n}",sprite_vert:"uniform float rotation;\nuniform vec2 center;\n#include <common>\n#include <uv_pars_vertex>\n#include <fog_pars_vertex>\n#include <logdepthbuf_pars_vertex>\n#include <clipping_planes_pars_vertex>\nvoid main() {\n	#include <uv_vertex>\n	vec4 mvPosition = modelViewMatrix[ 3 ];\n	vec2 scale = vec2( length( modelMatrix[ 0 ].xyz ), length( modelMatrix[ 1 ].xyz ) );\n	#ifndef USE_SIZEATTENUATION\n		bool isPerspective = isPerspectiveMatrix( projectionMatrix );\n		if ( isPerspective ) scale *= - mvPosition.z;\n	#endif\n	vec2 alignedPosition = ( position.xy - ( center - vec2( 0.5 ) ) ) * scale;\n	vec2 rotatedPosition;\n	rotatedPosition.x = cos( rotation ) * alignedPosition.x - sin( rotation ) * alignedPosition.y;\n	rotatedPosition.y = sin( rotation ) * alignedPosition.x + cos( rotation ) * alignedPosition.y;\n	mvPosition.xy += rotatedPosition;\n	gl_Position = projectionMatrix * mvPosition;\n	#include <logdepthbuf_vertex>\n	#include <clipping_planes_vertex>\n	#include <fog_vertex>\n}",sprite_frag:"uniform vec3 diffuse;\nuniform float opacity;\n#include <common>\n#include <uv_pars_fragment>\n#include <map_pars_fragment>\n#include <alphamap_pars_fragment>\n#include <alphatest_pars_fragment>\n#include <alphahash_pars_fragment>\n#include <fog_pars_fragment>\n#include <logdepthbuf_pars_fragment>\n#include <clipping_planes_pars_fragment>\nvoid main() {\n	vec4 diffuseColor = vec4( diffuse, opacity );\n	#include <clipping_planes_fragment>\n	vec3 outgoingLight = vec3( 0.0 );\n	#include <logdepthbuf_fragment>\n	#include <map_fragment>\n	#include <alphamap_fragment>\n	#include <alphatest_fragment>\n	#include <alphahash_fragment>\n	outgoingLight = diffuseColor.rgb;\n	#include <opaque_fragment>\n	#include <tonemapping_fragment>\n	#include <colorspace_fragment>\n	#include <fog_fragment>\n}"},a={common:{diffuse:{value:new n.Color(0xffffff)},opacity:{value:1},map:{value:null},mapTransform:{value:new n.Matrix3},alphaMap:{value:null},alphaMapTransform:{value:new n.Matrix3},alphaTest:{value:0}},specularmap:{specularMap:{value:null},specularMapTransform:{value:new n.Matrix3}},envmap:{envMap:{value:null},envMapRotation:{value:new n.Matrix3},reflectivity:{value:1},ior:{value:1.5},refractionRatio:{value:.98},dfgLUT:{value:null}},aomap:{aoMap:{value:null},aoMapIntensity:{value:1},aoMapTransform:{value:new n.Matrix3}},lightmap:{lightMap:{value:null},lightMapIntensity:{value:1},lightMapTransform:{value:new n.Matrix3}},bumpmap:{bumpMap:{value:null},bumpMapTransform:{value:new n.Matrix3},bumpScale:{value:1}},normalmap:{normalMap:{value:null},normalMapTransform:{value:new n.Matrix3},normalScale:{value:new n.Vector2(1,1)}},displacementmap:{displacementMap:{value:null},displacementMapTransform:{value:new n.Matrix3},displacementScale:{value:1},displacementBias:{value:0}},emissivemap:{emissiveMap:{value:null},emissiveMapTransform:{value:new n.Matrix3}},metalnessmap:{metalnessMap:{value:null},metalnessMapTransform:{value:new n.Matrix3}},roughnessmap:{roughnessMap:{value:null},roughnessMapTransform:{value:new n.Matrix3}},gradientmap:{gradientMap:{value:null}},fog:{fogDensity:{value:25e-5},fogNear:{value:1},fogFar:{value:2e3},fogColor:{value:new n.Color(0xffffff)}},lights:{ambientLightColor:{value:[]},lightProbe:{value:[]},directionalLights:{value:[],properties:{direction:{},color:{}}},directionalLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},directionalShadowMatrix:{value:[]},spotLights:{value:[],properties:{color:{},position:{},direction:{},distance:{},coneCos:{},penumbraCos:{},decay:{}}},spotLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{}}},spotLightMap:{value:[]},spotLightMatrix:{value:[]},pointLights:{value:[],properties:{color:{},position:{},decay:{},distance:{}}},pointLightShadows:{value:[],properties:{shadowIntensity:1,shadowBias:{},shadowNormalBias:{},shadowRadius:{},shadowMapSize:{},shadowCameraNear:{},shadowCameraFar:{}}},pointShadowMatrix:{value:[]},hemisphereLights:{value:[],properties:{direction:{},skyColor:{},groundColor:{}}},rectAreaLights:{value:[],properties:{color:{},position:{},width:{},height:{}}},ltc_1:{value:null},ltc_2:{value:null},probesSH:{value:null},probesMin:{value:new n.Vector3},probesMax:{value:new n.Vector3},probesResolution:{value:new n.Vector3}},points:{diffuse:{value:new n.Color(0xffffff)},opacity:{value:1},size:{value:1},scale:{value:1},map:{value:null},alphaMap:{value:null},alphaMapTransform:{value:new n.Matrix3},alphaTest:{value:0},uvTransform:{value:new n.Matrix3}},sprite:{diffuse:{value:new n.Color(0xffffff)},opacity:{value:1},center:{value:new n.Vector2(.5,.5)},rotation:{value:0},map:{value:null},mapTransform:{value:new n.Matrix3},alphaMap:{value:null},alphaMapTransform:{value:new n.Matrix3},alphaTest:{value:0}}},o={basic:{uniforms:(0,n.mergeUniforms)([a.common,a.specularmap,a.envmap,a.aomap,a.lightmap,a.fog]),vertexShader:i.meshbasic_vert,fragmentShader:i.meshbasic_frag},lambert:{uniforms:(0,n.mergeUniforms)([a.common,a.specularmap,a.envmap,a.aomap,a.lightmap,a.emissivemap,a.bumpmap,a.normalmap,a.displacementmap,a.fog,a.lights,{emissive:{value:new n.Color(0)},envMapIntensity:{value:1}}]),vertexShader:i.meshlambert_vert,fragmentShader:i.meshlambert_frag},phong:{uniforms:(0,n.mergeUniforms)([a.common,a.specularmap,a.envmap,a.aomap,a.lightmap,a.emissivemap,a.bumpmap,a.normalmap,a.displacementmap,a.fog,a.lights,{emissive:{value:new n.Color(0)},specular:{value:new n.Color(1118481)},shininess:{value:30},envMapIntensity:{value:1}}]),vertexShader:i.meshphong_vert,fragmentShader:i.meshphong_frag},standard:{uniforms:(0,n.mergeUniforms)([a.common,a.envmap,a.aomap,a.lightmap,a.emissivemap,a.bumpmap,a.normalmap,a.displacementmap,a.roughnessmap,a.metalnessmap,a.fog,a.lights,{emissive:{value:new n.Color(0)},roughness:{value:1},metalness:{value:0},envMapIntensity:{value:1}}]),vertexShader:i.meshphysical_vert,fragmentShader:i.meshphysical_frag},toon:{uniforms:(0,n.mergeUniforms)([a.common,a.aomap,a.lightmap,a.emissivemap,a.bumpmap,a.normalmap,a.displacementmap,a.gradientmap,a.fog,a.lights,{emissive:{value:new n.Color(0)}}]),vertexShader:i.meshtoon_vert,fragmentShader:i.meshtoon_frag},matcap:{uniforms:(0,n.mergeUniforms)([a.common,a.bumpmap,a.normalmap,a.displacementmap,a.fog,{matcap:{value:null}}]),vertexShader:i.meshmatcap_vert,fragmentShader:i.meshmatcap_frag},points:{uniforms:(0,n.mergeUniforms)([a.points,a.fog]),vertexShader:i.points_vert,fragmentShader:i.points_frag},dashed:{uniforms:(0,n.mergeUniforms)([a.common,a.fog,{scale:{value:1},dashSize:{value:1},totalSize:{value:2}}]),vertexShader:i.linedashed_vert,fragmentShader:i.linedashed_frag},depth:{uniforms:(0,n.mergeUniforms)([a.common,a.displacementmap]),vertexShader:i.depth_vert,fragmentShader:i.depth_frag},normal:{uniforms:(0,n.mergeUniforms)([a.common,a.bumpmap,a.normalmap,a.displacementmap,{opacity:{value:1}}]),vertexShader:i.meshnormal_vert,fragmentShader:i.meshnormal_frag},sprite:{uniforms:(0,n.mergeUniforms)([a.sprite,a.fog]),vertexShader:i.sprite_vert,fragmentShader:i.sprite_frag},background:{uniforms:{uvTransform:{value:new n.Matrix3},t2D:{value:null},backgroundIntensity:{value:1}},vertexShader:i.background_vert,fragmentShader:i.background_frag},backgroundCube:{uniforms:{envMap:{value:null},backgroundBlurriness:{value:0},backgroundIntensity:{value:1},backgroundRotation:{value:new n.Matrix3}},vertexShader:i.backgroundCube_vert,fragmentShader:i.backgroundCube_frag},cube:{uniforms:{tCube:{value:null},tFlip:{value:-1},opacity:{value:1}},vertexShader:i.cube_vert,fragmentShader:i.cube_frag},equirect:{uniforms:{tEquirect:{value:null}},vertexShader:i.equirect_vert,fragmentShader:i.equirect_frag},distance:{uniforms:(0,n.mergeUniforms)([a.common,a.displacementmap,{referencePosition:{value:new n.Vector3},nearDistance:{value:1},farDistance:{value:1e3}}]),vertexShader:i.distance_vert,fragmentShader:i.distance_frag},shadow:{uniforms:(0,n.mergeUniforms)([a.lights,a.fog,{color:{value:new n.Color(0)},opacity:{value:1}}]),vertexShader:i.shadow_vert,fragmentShader:i.shadow_frag}};
  o.physical={uniforms:(0,n.mergeUniforms)([o.standard.uniforms,{clearcoat:{value:0},clearcoatMap:{value:null},clearcoatMapTransform:{value:new n.Matrix3},clearcoatNormalMap:{value:null},clearcoatNormalMapTransform:{value:new n.Matrix3},clearcoatNormalScale:{value:new n.Vector2(1,1)},clearcoatRoughness:{value:0},clearcoatRoughnessMap:{value:null},clearcoatRoughnessMapTransform:{value:new n.Matrix3},dispersion:{value:0},iridescence:{value:0},iridescenceMap:{value:null},iridescenceMapTransform:{value:new n.Matrix3},iridescenceIOR:{value:1.3},iridescenceThicknessMinimum:{value:100},iridescenceThicknessMaximum:{value:400},iridescenceThicknessMap:{value:null},iridescenceThicknessMapTransform:{value:new n.Matrix3},sheen:{value:0},sheenColor:{value:new n.Color(0)},sheenColorMap:{value:null},sheenColorMapTransform:{value:new n.Matrix3},sheenRoughness:{value:1},sheenRoughnessMap:{value:null},sheenRoughnessMapTransform:{value:new n.Matrix3},transmission:{value:0},transmissionMap:{value:null},transmissionMapTransform:{value:new n.Matrix3},transmissionSamplerSize:{value:new n.Vector2},transmissionSamplerMap:{value:null},thickness:{value:0},thicknessMap:{value:null},thicknessMapTransform:{value:new n.Matrix3},attenuationDistance:{value:0},attenuationColor:{value:new n.Color(0)},specularColor:{value:new n.Color(1,1,1)},specularColorMap:{value:null},specularColorMapTransform:{value:new n.Matrix3},specularIntensity:{value:1},specularIntensityMap:{value:null},specularIntensityMapTransform:{value:new n.Matrix3},anisotropyVector:{value:new n.Vector2},anisotropyMap:{value:null},anisotropyMapTransform:{value:new n.Matrix3}}]),vertexShader:i.meshphysical_vert,fragmentShader:i.meshphysical_frag};
  let l={r:0,b:0,g:0},s=new n.Matrix4,c=new n.Matrix3;
  function d(e,t,r,i,a,d){
    let u,f,p=new n.Color(0),m=+(!0!==a),_=null,h=0,g=null;
    function v(e){
      let n=!0===e.isScene?e.background:null;
      if(n&&n.isTexture){
        let r=e.backgroundBlurriness>0;
        n=t.get(n,r)
        }
      return n
      }
    function S(t,i){
      t.getRGB(l,(0,n.getUnlitUniformColorSpace)(e)),r.buffers.color.setClear(l.r,l.g,l.b,i,d)
      }
    return{getClearColor:function(){
      return p
      },setClearColor:function(e,n=1){
      p.set(e),S(p,m=n)
      },getClearAlpha:function(){
      return m
      },setClearAlpha:function(e){
      S(p,m=e)
      },render:function(n){
      let t=!1,i=v(n);
      null===i?S(p,m):i&&i.isColor&&(S(i,1),t=!0);
      let a=e.xr.getEnvironmentBlendMode();
      "additive"===a?r.buffers.color.setClear(0,0,0,1,d):"alpha-blend"===a&&r.buffers.color.setClear(0,0,0,0,d),(e.autoClear||t)&&(r.buffers.depth.setTest(!0),r.buffers.depth.setMask(!0),r.buffers.color.setMask(!0),e.clear(e.autoClearColor,e.autoClearDepth,e.autoClearStencil))
      },addToRenderList:function(t,r){
      let a=v(r);
      a&&(a.isCubeTexture||a.mapping===n.CubeUVReflectionMapping)?(void 0===f&&((f=new n.Mesh(new n.BoxGeometry(1,1,1),new n.ShaderMaterial({name:"BackgroundCubeMaterial",uniforms:(0,n.cloneUniforms)(o.backgroundCube.uniforms),vertexShader:o.backgroundCube.vertexShader,fragmentShader:o.backgroundCube.fragmentShader,side:n.BackSide,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1}))).geometry.deleteAttribute("normal"),f.geometry.deleteAttribute("uv"),f.onBeforeRender=function(e,n,t){
        this.matrixWorld.copyPosition(t.matrixWorld)
        },Object.defineProperty(f.material,"envMap",{get:function(){
        return this.uniforms.envMap.value
        }}),i.update(f)),f.material.uniforms.envMap.value=a,f.material.uniforms.backgroundBlurriness.value=r.backgroundBlurriness,f.material.uniforms.backgroundIntensity.value=r.backgroundIntensity,f.material.uniforms.backgroundRotation.value.setFromMatrix4(s.makeRotationFromEuler(r.backgroundRotation)).transpose(),a.isCubeTexture&&!1===a.isRenderTargetTexture&&f.material.uniforms.backgroundRotation.value.premultiply(c),f.material.toneMapped=n.ColorManagement.getTransfer(a.colorSpace)!==n.SRGBTransfer,(_!==a||h!==a.version||g!==e.toneMapping)&&(f.material.needsUpdate=!0,_=a,h=a.version,g=e.toneMapping),f.layers.enableAll(),t.unshift(f,f.geometry,f.material,0,0,null)):a&&a.isTexture&&(void 0===u&&((u=new n.Mesh(new n.PlaneGeometry(2,2),new n.ShaderMaterial({name:"BackgroundMaterial",uniforms:(0,n.cloneUniforms)(o.background.uniforms),vertexShader:o.background.vertexShader,fragmentShader:o.background.fragmentShader,side:n.FrontSide,depthTest:!1,depthWrite:!1,fog:!1,allowOverride:!1}))).geometry.deleteAttribute("normal"),Object.defineProperty(u.material,"map",{get:function(){
        return this.uniforms.t2D.value
        }}),i.update(u)),u.material.uniforms.t2D.value=a,u.material.uniforms.backgroundIntensity.value=r.backgroundIntensity,u.material.toneMapped=n.ColorManagement.getTransfer(a.colorSpace)!==n.SRGBTransfer,!0===a.matrixAutoUpdate&&a.updateMatrix(),u.material.uniforms.uvTransform.value.copy(a.matrix),(_!==a||h!==a.version||g!==e.toneMapping)&&(u.material.needsUpdate=!0,_=a,h=a.version,g=e.toneMapping),u.layers.enableAll(),t.unshift(u,u.geometry,u.material,0,0,null))
      },dispose:function(){
      void 0!==f&&(f.geometry.dispose(),f.material.dispose(),f=void 0),void 0!==u&&(u.geometry.dispose(),u.material.dispose(),u=void 0)
      }}
    }
  function u(e,t){
    let r=e.getParameter(e.MAX_VERTEX_ATTRIBS),i={},a=d(null),o=a,l=!1;
    function s(n){
      return e.bindVertexArray(n)
      }
    function c(n){
      return e.deleteVertexArray(n)
      }
    function d(e){
      let n=[],t=[],i=[];
      for(
      let e=0
      ;e<r;e++)
      n[e]=0,t[e]=0,i[e]=0;
      return{geometry:null,program:null,wireframe:!1,newAttributes:n,enabledAttributes:t,attributeDivisors:i,object:e,attributes:{},index:null}
      }
    function u(){
      let e=o.newAttributes;
      for(
      let n=0,t=e.length
      ;n<t;n++)
      e[n]=0
      }
    function f(e){
      p(e,0)
      }
    function p(n,t){
      let r=o.newAttributes,i=o.enabledAttributes,a=o.attributeDivisors;
      r[n]=1,0===i[n]&&(e.enableVertexAttribArray(n),i[n]=1),a[n]!==t&&(e.vertexAttribDivisor(n,t),a[n]=t)
      }
    function m(){
      let n=o.newAttributes,t=o.enabledAttributes;
      for(
      let r=0,i=t.length
      ;r<i;r++)
      t[r]!==n[r]&&(e.disableVertexAttribArray(r),t[r]=0)
      }
    function _(n,t,r,i,a,o,l){
      !0===l?e.vertexAttribIPointer(n,t,r,a,o):e.vertexAttribPointer(n,t,r,i,a,o)
      }
    function h(){
      g(),l=!0,o!==a&&s((o=a).object)
      }
    function g(){
      a.geometry=null,a.program=null,a.wireframe=!1
      }
    return{setup:function(r,a,c,h,g){
      var v,S,E;
      let T,M,x,R,A,C,b=!1,P=(v=r,S=h,E=c,T=!0===a.wireframe,void 0===(M=i[S.id])&&(M={},i[S.id]=M),void 0===(R=M[x=!0===v.isInstancedMesh?v.id:0])&&(R={},M[x]=R),void 0===(A=R[E.id])&&(A={},R[E.id]=A),void 0===(C=A[T])&&(C=d(e.createVertexArray()),A[T]=C),C);
      o!==P&&s((o=P).object),(b=function(e,n,t,r){
        let i=o.attributes,a=n.attributes,l=0,s=t.getAttributes();
        for(
        let n
         in s)
        if(s[n].location>=0){
          let t=i[n],r=a[n];
          if(void 0===r&&("instanceMatrix"===n&&e.instanceMatrix&&(r=e.instanceMatrix),"instanceColor"===n&&e.instanceColor&&(r=e.instanceColor)),void 0===t||t.attribute!==r||r&&t.data!==r.data)
          return!0;
          l++
          }
        return o.attributesNum!==l||o.index!==r
        }(r,h,c,g))&&function(e,n,t,r){
        let i={},a=n.attributes,l=0,s=t.getAttributes();
        for(
        let n
         in s)
        if(s[n].location>=0){
          let t=a[n];
          void 0===t&&("instanceMatrix"===n&&e.instanceMatrix&&(t=e.instanceMatrix),"instanceColor"===n&&e.instanceColor&&(t=e.instanceColor));
          let r={};
          r.attribute=t,t&&t.data&&(r.data=t.data),i[n]=r,l++
          }
        o.attributes=i,o.attributesNum=l,o.index=r
        }(r,h,c,g),null!==g&&t.update(g,e.ELEMENT_ARRAY_BUFFER),(b||l)&&(l=!1,function(r,i,a,o){
        u();
        let l=o.attributes,s=a.getAttributes(),c=i.defaultAttributeValues;
        for(
        let i
         in s){
          let a=s[i];
          if(a.location>=0){
            let s=l[i];
            if(void 0===s&&("instanceMatrix"===i&&r.instanceMatrix&&(s=r.instanceMatrix),"instanceColor"===i&&r.instanceColor&&(s=r.instanceColor)),void 0!==s){
              let i=s.normalized,l=s.itemSize,c=t.get(s);
              if(void 0===c)
              continue;
              let d=c.buffer,u=c.type,m=c.bytesPerElement,h=u===e.INT||u===e.UNSIGNED_INT||s.gpuType===n.IntType;
              if(s.isInterleavedBufferAttribute){
                let n=s.data,t=n.stride,c=s.offset;
                if(n.isInstancedInterleavedBuffer){
                  for(
                  let e=0
                  ;e<a.locationSize;e++)
                  p(a.location+e,n.meshPerAttribute);
                  !0!==r.isInstancedMesh&&void 0===o._maxInstanceCount&&(o._maxInstanceCount=n.meshPerAttribute*n.count)
                  }else 
                for(
                let e=0
                ;e<a.locationSize;e++)
                f(a.location+e);
                e.bindBuffer(e.ARRAY_BUFFER,d);
                for(
                let e=0
                ;e<a.locationSize;e++)
                _(a.location+e,l/a.locationSize,u,i,t*m,(c+l/a.locationSize*e)*m,h)
                }else{
                if(s.isInstancedBufferAttribute){
                  for(
                  let e=0
                  ;e<a.locationSize;e++)
                  p(a.location+e,s.meshPerAttribute);
                  !0!==r.isInstancedMesh&&void 0===o._maxInstanceCount&&(o._maxInstanceCount=s.meshPerAttribute*s.count)
                  }else 
                for(
                let e=0
                ;e<a.locationSize;e++)
                f(a.location+e);
                e.bindBuffer(e.ARRAY_BUFFER,d);
                for(
                let e=0
                ;e<a.locationSize;e++)
                _(a.location+e,l/a.locationSize,u,i,l*m,l/a.locationSize*e*m,h)
                }
              }else 
            if(void 0!==c){
              let n=c[i];
              if(void 0!==n)
              switch(n.length){case 2:
              e.vertexAttrib2fv(a.location,n);
              break;
              case 3:
              e.vertexAttrib3fv(a.location,n);
              break;
              case 4:
              e.vertexAttrib4fv(a.location,n);
              break;
              default:
              e.vertexAttrib1fv(a.location,n)
              }
              }
            }
          }
        m()
        }(r,a,c,h),null!==g&&e.bindBuffer(e.ELEMENT_ARRAY_BUFFER,t.get(g).buffer))
      },reset:h,resetDefaultState:g,dispose:function(){
      for(
      let e
       in h(),i){
        let n=i[e];
        for(
        let e
         in n){
          let t=n[e];
          for(
          let e
           in t){
            let n=t[e];
            for(
            let e
             in n)
            c(n[e].object),delete n[e];
            delete t[e]
            }
          }
        delete i[e]
        }
      },releaseStatesOfGeometry:function(e){
      if(void 0===i[e.id])
      return;
      let n=i[e.id];
      for(
      let e
       in n){
        let t=n[e];
        for(
        let e
         in t){
          let n=t[e];
          for(
          let e
           in n)
          c(n[e].object),delete n[e];
          delete t[e]
          }
        }
      delete i[e.id]
      },releaseStatesOfObject:function(e){
      for(
      let n
       in i){
        let t=i[n],r=!0===e.isInstancedMesh?e.id:0,a=t[r];
        if(void 0!==a){
          for(
          let e
           in a){
            let n=a[e];
            for(
            let e
             in n)
            c(n[e].object),delete n[e];
            delete a[e]
            }
          delete t[r],0===Object.keys(t).length&&delete i[n]
          }
        }
      },releaseStatesOfProgram:function(e){
      for(
      let n
       in i){
        let t=i[n];
        for(
        let n
         in t){
          let r=t[n];
          if(void 0===r[e.id])
          continue;
          let i=r[e.id];
          for(
          let e
           in i)
          c(i[e].object),delete i[e];
          delete r[e.id]
          }
        }
      },initAttributes:u,enableAttribute:f,disableUnusedAttributes:m}
    }
  function f(e,n,t){
    let r;
    this.setMode=function(e){
      r=e
      },this.render=function(n,i){
      e.drawArrays(r,n,i),t.update(i,r,1)
      },this.renderInstances=function(n,i,a){
      0!==a&&(e.drawArraysInstanced(r,n,i,a),t.update(i,r,a))
      },this.renderMultiDraw=function(e,i,a){
      if(0===a)
      return;
      n.get("WEBGL_multi_draw").multiDrawArraysWEBGL(r,e,0,i,0,a);
      let o=0;
      for(
      let e=0
      ;e<a;e++)
      o+=i[e];
      t.update(o,r,1)
      }
    }
  function p(e,t,r,i){
    let a;
    function o(n){
      if("highp"===n){
        if(e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.HIGH_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.HIGH_FLOAT).precision>0)
        return"highp";
        n="mediump"
        }
      return"mediump"===n&&e.getShaderPrecisionFormat(e.VERTEX_SHADER,e.MEDIUM_FLOAT).precision>0&&e.getShaderPrecisionFormat(e.FRAGMENT_SHADER,e.MEDIUM_FLOAT).precision>0?"mediump":"lowp"
      }
    let l=void 0!==r.precision?r.precision:"highp",s=o(l);
    s!==l&&((0,n.warn)("WebGLRenderer:",l,"not supported, using",s,"instead."),l=s);
    let c=!0===r.logarithmicDepthBuffer,d=!0===r.reversedDepthBuffer&&t.has("EXT_clip_control");
    return!0===r.reversedDepthBuffer&&!1===d&&(0,n.warn)("WebGLRenderer: Unable to use reversed depth buffer due to missing EXT_clip_control extension. Fallback to default depth buffer."),{isWebGL2:!0,getMaxAnisotropy:function(){
      if(void 0!==a)
      return a;
      if(!0===t.has("EXT_texture_filter_anisotropic")){
        let n=t.get("EXT_texture_filter_anisotropic");
        a=e.getParameter(n.MAX_TEXTURE_MAX_ANISOTROPY_EXT)
        }else 
      a=0;
      return a
      },getMaxPrecision:o,textureFormatReadable:function(t){
      return t===n.RGBAFormat||i.convert(t)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_FORMAT)
      },textureTypeReadable:function(r){
      let a=r===n.HalfFloatType&&(t.has("EXT_color_buffer_half_float")||t.has("EXT_color_buffer_float"));
      return r===n.UnsignedByteType||i.convert(r)===e.getParameter(e.IMPLEMENTATION_COLOR_READ_TYPE)||r===n.FloatType||!!a
      },precision:l,logarithmicDepthBuffer:c,reversedDepthBuffer:d,maxTextures:e.getParameter(e.MAX_TEXTURE_IMAGE_UNITS),maxVertexTextures:e.getParameter(e.MAX_VERTEX_TEXTURE_IMAGE_UNITS),maxTextureSize:e.getParameter(e.MAX_TEXTURE_SIZE),maxCubemapSize:e.getParameter(e.MAX_CUBE_MAP_TEXTURE_SIZE),maxAttributes:e.getParameter(e.MAX_VERTEX_ATTRIBS),maxVertexUniforms:e.getParameter(e.MAX_VERTEX_UNIFORM_VECTORS),maxVaryings:e.getParameter(e.MAX_VARYING_VECTORS),maxFragmentUniforms:e.getParameter(e.MAX_FRAGMENT_UNIFORM_VECTORS),maxSamples:e.getParameter(e.MAX_SAMPLES),samples:e.getParameter(e.SAMPLES)}
    }
  function m(e){
    let t=this,r=null,i=0,a=!1,o=!1,l=new n.Plane,s=new n.Matrix3,c={value:null,needsUpdate:!1};
    function d(e,n,r,i){
      let a=null!==e?e.length:0,o=null;
      if(0!==a){
        if(o=c.value,!0!==i||null===o){
          let t=r+4*a,i=n.matrixWorldInverse;
          s.getNormalMatrix(i),(null===o||o.length<t)&&(o=new Float32Array(t));
          for(
          let n=0,t=r
          ;n!==a;++n,t+=4)
          l.copy(e[n]).applyMatrix4(i,s),l.normal.toArray(o,t),o[t+3]=l.constant
          }
        c.value=o,c.needsUpdate=!0
        }
      return t.numPlanes=a,t.numIntersection=0,o
      }
    this.uniform=c,this.numPlanes=0,this.numIntersection=0,this.init=function(e,n){
      let t=0!==e.length||n||0!==i||a;
      return a=n,i=e.length,t
      },this.beginShadows=function(){
      o=!0,d(null)
      },this.endShadows=function(){
      o=!1
      },this.setGlobalState=function(e,n){
      r=d(e,n,0)
      },this.setState=function(n,l,s){
      let u=n.clippingPlanes,f=n.clipIntersection,p=n.clipShadows,m=e.get(n);
      if(a&&null!==u&&0!==u.length&&(!o||p)){
        let e=o?0:i,n=4*e,t=m.clippingState||null;
        c.value=t,t=d(u,l,n,s);
        for(
        let e=0
        ;e!==n;++e)
        t[e]=r[e];
        m.clippingState=t,this.numIntersection=f?this.numPlanes:0,this.numPlanes+=e
        }else 
      o?d(null):(c.value!==r&&(c.value=r,c.needsUpdate=i>0),t.numPlanes=i,t.numIntersection=0)
      }
    }
  c.set(-1,0,0,0,1,0,0,0,1);
  let _=[.125,.215,.35,.446,.526,.582],h=new n.OrthographicCamera,g=new n.Color,v=null,S=0,E=0,T=!1,M=new n.Vector3;
  class x{
    constructor(e){
      this._renderer=e,this._pingPongRenderTarget=null,this._lodMax=0,this._cubeSize=0,this._sizeLods=[],this._sigmas=[],this._lodMeshes=[],this._backgroundBox=null,this._cubemapMaterial=null,this._equirectMaterial=null,this._blurMaterial=null,this._ggxMaterial=null
      }fromScene(e,n=0,t=.1,r=100,i={}){
      let{size:a=256,position:o=M}=i;
      v=this._renderer.getRenderTarget(),S=this._renderer.getActiveCubeFace(),E=this._renderer.getActiveMipmapLevel(),T=this._renderer.xr.enabled,this._renderer.xr.enabled=!1,this._setSize(a);
      let l=this._allocateTargets();
      return l.depthBuffer=!0,this._sceneToCubeUV(e,t,r,l,o),n>0&&this._blur(l,0,0,n),this._applyPMREM(l),this._cleanup(l),l
      }fromEquirectangular(e,n=null){
      return this._fromTexture(e,n)
      }fromCubemap(e,n=null){
      return this._fromTexture(e,n)
      }compileCubemapShader(){
      null===this._cubemapMaterial&&(this._cubemapMaterial=b(),this._compileMaterial(this._cubemapMaterial))
      }compileEquirectangularShader(){
      null===this._equirectMaterial&&(this._equirectMaterial=C(),this._compileMaterial(this._equirectMaterial))
      }dispose(){
      this._dispose(),null!==this._cubemapMaterial&&this._cubemapMaterial.dispose(),null!==this._equirectMaterial&&this._equirectMaterial.dispose(),null!==this._backgroundBox&&(this._backgroundBox.geometry.dispose(),this._backgroundBox.material.dispose())
      }_setSize(e){
      this._lodMax=Math.floor(Math.log2(e)),this._cubeSize=Math.pow(2,this._lodMax)
      }_dispose(){
      null!==this._blurMaterial&&this._blurMaterial.dispose(),null!==this._ggxMaterial&&this._ggxMaterial.dispose(),null!==this._pingPongRenderTarget&&this._pingPongRenderTarget.dispose();
      for(
      let e=0
      ;e<this._lodMeshes.length;e++)
      this._lodMeshes[e].geometry.dispose()
      }_cleanup(e){
      this._renderer.setRenderTarget(v,S,E),this._renderer.xr.enabled=T,e.scissorTest=!1,A(e,0,0,e.width,e.height)
      }_fromTexture(e,t){
      e.mapping===n.CubeReflectionMapping||e.mapping===n.CubeRefractionMapping?this._setSize(0===e.image.length?16:e.image[0].width||e.image[0].image.width):this._setSize(e.image.width/4),v=this._renderer.getRenderTarget(),S=this._renderer.getActiveCubeFace(),E=this._renderer.getActiveMipmapLevel(),T=this._renderer.xr.enabled,this._renderer.xr.enabled=!1;
      let r=t||this._allocateTargets();
      return this._textureToCubeUV(e,r),this._applyPMREM(r),this._cleanup(r),r
      }_allocateTargets(){
      let e=3*Math.max(this._cubeSize,112),t=4*this._cubeSize,r={magFilter:n.LinearFilter,minFilter:n.LinearFilter,generateMipmaps:!1,type:n.HalfFloatType,format:n.RGBAFormat,colorSpace:n.LinearSRGBColorSpace,depthBuffer:!1},i=R(e,t,r);
      if(null===this._pingPongRenderTarget||this._pingPongRenderTarget.width!==e||this._pingPongRenderTarget.height!==t){
        var a,o,l,s,c,d;
        let i,u;
        null!==this._pingPongRenderTarget&&this._dispose(),this._pingPongRenderTarget=R(e,t,r);
        let{_lodMax:f}=this;
        ({lodMeshes:this._lodMeshes,sizeLods:this._sizeLods,sigmas:this._sigmas}=function(e){
          let t=[],r=[],i=[],a=e,o=e-4+1+_.length;
          for(
          let l=0
          ;l<o;l++){
            let o=Math.pow(2,a);
            t.push(o);
            let s=1/o;
            l>e-4?s=_[l-e+4-1]:0===l&&(s=0),r.push(s);
            let c=1/(o-2),d=-c,u=1+c,f=[d,d,u,d,u,u,d,d,u,u,d,u],p=new Float32Array(108),m=new Float32Array(72),h=new Float32Array(36);
            for(
            let e=0
            ;e<6;e++){
              let n=e%3*2/3-1,t=e>2?0:-1,r=[n,t,0,n+2/3,t,0,n+2/3,t+1,0,n,t,0,n+2/3,t+1,0,n,t+1,0];
              p.set(r,18*e),m.set(f,12*e);
              let i=[e,e,e,e,e,e];
              h.set(i,6*e)
              }
            let g=new n.BufferGeometry;
            g.setAttribute("position",new n.BufferAttribute(p,3)),g.setAttribute("uv",new n.BufferAttribute(m,2)),g.setAttribute("faceIndex",new n.BufferAttribute(h,1)),i.push(new n.Mesh(g,null)),a>4&&a--
            }
          return{lodMeshes:i,sizeLods:t,sigmas:r}
          }(f)),this._blurMaterial=(a=f,o=e,l=t,i=new Float32Array(20),u=new n.Vector3(0,1,0),new n.ShaderMaterial({name:"SphericalGaussianBlur",defines:{n:20,CUBEUV_TEXEL_WIDTH:1/o,CUBEUV_TEXEL_HEIGHT:1/l,CUBEUV_MAX_MIP:`${a}.0`},uniforms:{envMap:{value:null},samples:{value:1},weights:{value:i},latitudinal:{value:!1},dTheta:{value:0},mipInt:{value:0},poleAxis:{value:u}},vertexShader:P(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform int samples;
			uniform float weights[ n ];
			uniform bool latitudinal;
			uniform float dTheta;
			uniform float mipInt;
			uniform vec3 poleAxis;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			vec3 getSample( float theta, vec3 axis ) {

				float cosTheta = cos( theta );
				// Rodrigues' axis-angle rotation
				vec3 sampleDirection = vOutputDirection * cosTheta
					+ cross( axis, vOutputDirection ) * sin( theta )
					+ axis * dot( axis, vOutputDirection ) * ( 1.0 - cosTheta );

				return bilinearCubeUV( envMap, sampleDirection, mipInt );

			}

			void main() {

				vec3 axis = latitudinal ? poleAxis : cross( poleAxis, vOutputDirection );

				if ( all( equal( axis, vec3( 0.0 ) ) ) ) {

					axis = vec3( vOutputDirection.z, 0.0, - vOutputDirection.x );

				}

				axis = normalize( axis );

				gl_FragColor = vec4( 0.0, 0.0, 0.0, 1.0 );
				gl_FragColor.rgb += weights[ 0 ] * getSample( 0.0, axis );

				for ( int i = 1; i < n; i++ ) {

					if ( i >= samples ) {

						break;

					}

					float theta = dTheta * float( i );
					gl_FragColor.rgb += weights[ i ] * getSample( -1.0 * theta, axis );
					gl_FragColor.rgb += weights[ i ] * getSample( theta, axis );

				}

			}
		`,blending:n.NoBlending,depthTest:!1,depthWrite:!1})),this._ggxMaterial=(s=f,c=e,d=t,new n.ShaderMaterial({name:"PMREMGGXConvolution",defines:{GGX_SAMPLES:256,CUBEUV_TEXEL_WIDTH:1/c,CUBEUV_TEXEL_HEIGHT:1/d,CUBEUV_MAX_MIP:`${s}.0`},uniforms:{envMap:{value:null},roughness:{value:0},mipInt:{value:0}},vertexShader:P(),fragmentShader:`

			precision highp float;
			precision highp int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;
			uniform float roughness;
			uniform float mipInt;

			#define ENVMAP_TYPE_CUBE_UV
			#include <cube_uv_reflection_fragment>

			#define PI 3.14159265359

			// Van der Corput radical inverse
			float radicalInverse_VdC(uint bits) {
				bits = (bits << 16u) | (bits >> 16u);
				bits = ((bits & 0x55555555u) << 1u) | ((bits & 0xAAAAAAAAu) >> 1u);
				bits = ((bits & 0x33333333u) << 2u) | ((bits & 0xCCCCCCCCu) >> 2u);
				bits = ((bits & 0x0F0F0F0Fu) << 4u) | ((bits & 0xF0F0F0F0u) >> 4u);
				bits = ((bits & 0x00FF00FFu) << 8u) | ((bits & 0xFF00FF00u) >> 8u);
				return float(bits) * 2.3283064365386963e-10; // / 0x100000000
			}

			// Hammersley sequence
			vec2 hammersley(uint i, uint N) {
				return vec2(float(i) / float(N), radicalInverse_VdC(i));
			}

			// GGX VNDF importance sampling (Eric Heitz 2018)
			// "Sampling the GGX Distribution of Visible Normals"
			// https://jcgt.org/published/0007/04/01/
			vec3 importanceSampleGGX_VNDF(vec2 Xi, vec3 V, float roughness) {
				float alpha = roughness * roughness;

				// Section 4.1: Orthonormal basis
				vec3 T1 = vec3(1.0, 0.0, 0.0);
				vec3 T2 = cross(V, T1);

				// Section 4.2: Parameterization of projected area
				float r = sqrt(Xi.x);
				float phi = 2.0 * PI * Xi.y;
				float t1 = r * cos(phi);
				float t2 = r * sin(phi);
				float s = 0.5 * (1.0 + V.z);
				t2 = (1.0 - s) * sqrt(1.0 - t1 * t1) + s * t2;

				// Section 4.3: Reprojection onto hemisphere
				vec3 Nh = t1 * T1 + t2 * T2 + sqrt(max(0.0, 1.0 - t1 * t1 - t2 * t2)) * V;

				// Section 3.4: Transform back to ellipsoid configuration
				return normalize(vec3(alpha * Nh.x, alpha * Nh.y, max(0.0, Nh.z)));
			}

			void main() {
				vec3 N = normalize(vOutputDirection);
				vec3 V = N; // Assume view direction equals normal for pre-filtering

				vec3 prefilteredColor = vec3(0.0);
				float totalWeight = 0.0;

				// For very low roughness, just sample the environment directly
				if (roughness < 0.001) {
					gl_FragColor = vec4(bilinearCubeUV(envMap, N, mipInt), 1.0);
					return;
				}

				// Tangent space basis for VNDF sampling
				vec3 up = abs(N.z) < 0.999 ? vec3(0.0, 0.0, 1.0) : vec3(1.0, 0.0, 0.0);
				vec3 tangent = normalize(cross(up, N));
				vec3 bitangent = cross(N, tangent);

				for(uint i = 0u; i < uint(GGX_SAMPLES); i++) {
					vec2 Xi = hammersley(i, uint(GGX_SAMPLES));

					// For PMREM, V = N, so in tangent space V is always (0, 0, 1)
					vec3 H_tangent = importanceSampleGGX_VNDF(Xi, vec3(0.0, 0.0, 1.0), roughness);

					// Transform H back to world space
					vec3 H = normalize(tangent * H_tangent.x + bitangent * H_tangent.y + N * H_tangent.z);
					vec3 L = normalize(2.0 * dot(V, H) * H - V);

					float NdotL = max(dot(N, L), 0.0);

					if(NdotL > 0.0) {
						// Sample environment at fixed mip level
						// VNDF importance sampling handles the distribution filtering
						vec3 sampleColor = bilinearCubeUV(envMap, L, mipInt);

						// Weight by NdotL for the split-sum approximation
						// VNDF PDF naturally accounts for the visible microfacet distribution
						prefilteredColor += sampleColor * NdotL;
						totalWeight += NdotL;
					}
				}

				if (totalWeight > 0.0) {
					prefilteredColor = prefilteredColor / totalWeight;
				}

				gl_FragColor = vec4(prefilteredColor, 1.0);
			}
		`,blending:n.NoBlending,depthTest:!1,depthWrite:!1}))
        }
      return i
      }_compileMaterial(e){
      let t=new n.Mesh(new n.BufferGeometry,e);
      this._renderer.compile(t,h)
      }_sceneToCubeUV(e,t,r,i,a){
      let o=new n.PerspectiveCamera(90,1,t,r),l=[1,-1,1,1,1,1],s=[1,1,1,-1,-1,-1],c=this._renderer,d=c.autoClear,u=c.toneMapping;
      c.getClearColor(g),c.toneMapping=n.NoToneMapping,c.autoClear=!1,c.state.buffers.depth.getReversed()&&(c.setRenderTarget(i),c.clearDepth(),c.setRenderTarget(null)),null===this._backgroundBox&&(this._backgroundBox=new n.Mesh(new n.BoxGeometry,new n.MeshBasicMaterial({name:"PMREM.Background",side:n.BackSide,depthWrite:!1,depthTest:!1})));
      let f=this._backgroundBox,p=f.material,m=!1,_=e.background;
      _?_.isColor&&(p.color.copy(_),e.background=null,m=!0):(p.color.copy(g),m=!0);
      for(
      let n=0
      ;n<6;n++){
        let t=n%3;
        0===t?(o.up.set(0,l[n],0),o.position.set(a.x,a.y,a.z),o.lookAt(a.x+s[n],a.y,a.z)):1===t?(o.up.set(0,0,l[n]),o.position.set(a.x,a.y,a.z),o.lookAt(a.x,a.y+s[n],a.z)):(o.up.set(0,l[n],0),o.position.set(a.x,a.y,a.z),o.lookAt(a.x,a.y,a.z+s[n]));
        let r=this._cubeSize;
        A(i,t*r,n>2?r:0,r,r),c.setRenderTarget(i),m&&c.render(f,o),c.render(e,o)
        }
      c.toneMapping=u,c.autoClear=d,e.background=_
      }_textureToCubeUV(e,t){
      let r=this._renderer,i=e.mapping===n.CubeReflectionMapping||e.mapping===n.CubeRefractionMapping;
      i?(null===this._cubemapMaterial&&(this._cubemapMaterial=b()),this._cubemapMaterial.uniforms.flipEnvMap.value=!1===e.isRenderTargetTexture?-1:1):null===this._equirectMaterial&&(this._equirectMaterial=C());
      let a=i?this._cubemapMaterial:this._equirectMaterial,o=this._lodMeshes[0];
      o.material=a,a.uniforms.envMap.value=e;
      let l=this._cubeSize;
      A(t,0,0,3*l,2*l),r.setRenderTarget(t),r.render(o,h)
      }_applyPMREM(e){
      let n=this._renderer,t=n.autoClear;
      n.autoClear=!1;
      let r=this._lodMeshes.length;
      for(
      let n=1
      ;n<r;n++)
      this._applyGGXFilter(e,n-1,n);
      n.autoClear=t
      }_applyGGXFilter(e,n,t){
      let r=this._renderer,i=this._pingPongRenderTarget,a=this._ggxMaterial,o=this._lodMeshes[t];
      o.material=a;
      let l=a.uniforms,s=t/(this._lodMeshes.length-1),c=n/(this._lodMeshes.length-1),d=Math.sqrt(s*s-c*c),{_lodMax:u}=this,f=this._sizeLods[t],p=3*f*(t>u-4?t-u+4:0),m=4*(this._cubeSize-f);
      l.envMap.value=e.texture,l.roughness.value=d*(0+1.25*s),l.mipInt.value=u-n,A(i,p,m,3*f,2*f),r.setRenderTarget(i),r.render(o,h),l.envMap.value=i.texture,l.roughness.value=0,l.mipInt.value=u-t,A(e,p,m,3*f,2*f),r.setRenderTarget(e),r.render(o,h)
      }_blur(e,n,t,r,i){
      let a=this._pingPongRenderTarget;
      this._halfBlur(e,a,n,t,r,"latitudinal",i),this._halfBlur(a,e,t,t,r,"longitudinal",i)
      }_halfBlur(e,t,r,i,a,o,l){
      let s=this._renderer,c=this._blurMaterial;
      "latitudinal"!==o&&"longitudinal"!==o&&(0,n.error)("blur direction must be either latitudinal or longitudinal!");
      let d=this._lodMeshes[i];
      d.material=c;
      let u=c.uniforms,f=this._sizeLods[r]-1,p=isFinite(a)?Math.PI/(2*f):2*Math.PI/39,m=a/p,_=isFinite(a)?1+Math.floor(3*m):20;
      _>20&&(0,n.warn)(`sigmaRadians, ${a}, is too large and will clip, as it requested ${_} samples when the maximum is set to 20`);
      let g=[],v=0;
      for(
      let e=0
      ;e<20;++e){
        let n=e/m,t=Math.exp(-n*n/2);
        g.push(t),0===e?v+=t:e<_&&(v+=2*t)
        }
      for(
      let e=0
      ;e<g.length;e++)
      g[e]=g[e]/v;
      u.envMap.value=e.texture,u.samples.value=_,u.weights.value=g,u.latitudinal.value="latitudinal"===o,l&&(u.poleAxis.value=l);
      let{_lodMax:S}=this;
      u.dTheta.value=p,u.mipInt.value=S-r;
      let E=this._sizeLods[i],T=4*(this._cubeSize-E);
      A(t,3*E*(i>S-4?i-S+4:0),T,3*E,2*E),s.setRenderTarget(t),s.render(d,h)
      }
  }
  function R(e,t,r){
    let i=new n.WebGLRenderTarget(e,t,r);
    return i.texture.mapping=n.CubeUVReflectionMapping,i.texture.name="PMREM.cubeUv",i.scissorTest=!0,i
    }
  function A(e,n,t,r,i){
    e.viewport.set(n,t,r,i),e.scissor.set(n,t,r,i)
    }
  function C(){
    return new n.ShaderMaterial({name:"EquirectangularToCubeUV",uniforms:{envMap:{value:null}},vertexShader:P(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			varying vec3 vOutputDirection;

			uniform sampler2D envMap;

			#include <common>

			void main() {

				vec3 outputDirection = normalize( vOutputDirection );
				vec2 uv = equirectUv( outputDirection );

				gl_FragColor = vec4( texture2D ( envMap, uv ).rgb, 1.0 );

			}
		`,blending:n.NoBlending,depthTest:!1,depthWrite:!1})
    }
  function b(){
    return new n.ShaderMaterial({name:"CubemapToCubeUV",uniforms:{envMap:{value:null},flipEnvMap:{value:-1}},vertexShader:P(),fragmentShader:`

			precision mediump float;
			precision mediump int;

			uniform float flipEnvMap;

			varying vec3 vOutputDirection;

			uniform samplerCube envMap;

			void main() {

				gl_FragColor = textureCube( envMap, vec3( flipEnvMap * vOutputDirection.x, vOutputDirection.yz ) );

			}
		`,blending:n.NoBlending,depthTest:!1,depthWrite:!1})
    }
  function P(){
    return`

		precision mediump float;
		precision mediump int;

		attribute float faceIndex;

		varying vec3 vOutputDirection;

		// RH coordinate system; PMREM face-indexing convention
		vec3 getDirection( vec2 uv, float face ) {

			uv = 2.0 * uv - 1.0;

			vec3 direction = vec3( uv, 1.0 );

			if ( face == 0.0 ) {

				direction = direction.zyx; // ( 1, v, u ) pos x

			} else if ( face == 1.0 ) {

				direction = direction.xzy;
				direction.xz *= -1.0; // ( -u, 1, -v ) pos y

			} else if ( face == 2.0 ) {

				direction.x *= -1.0; // ( -u, v, 1 ) pos z

			} else if ( face == 3.0 ) {

				direction = direction.zyx;
				direction.xz *= -1.0; // ( -1, v, -u ) neg x

			} else if ( face == 4.0 ) {

				direction = direction.xzy;
				direction.xy *= -1.0; // ( -u, -1, v ) neg y

			} else if ( face == 5.0 ) {

				direction.z *= -1.0; // ( u, v, -1 ) neg z

			}

			return direction;

		}

		void main() {

			vOutputDirection = getDirection( uv, faceIndex );
			gl_Position = vec4( position, 1.0 );

		}
	`
    }
  class L extends n.WebGLRenderTarget{
    constructor(e=1,t={}){
      super(e,e,t),this.isWebGLCubeRenderTarget=!0;
      const r={width:e,height:e,depth:1};
      this.texture=new n.CubeTexture([r,r,r,r,r,r]),this._setTextureOptions(t),this.texture.isRenderTargetTexture=!0
      }fromEquirectangularTexture(e,t){
      this.texture.type=t.type,this.texture.colorSpace=t.colorSpace,this.texture.generateMipmaps=t.generateMipmaps,this.texture.minFilter=t.minFilter,this.texture.magFilter=t.magFilter;
      let r={uniforms:{tEquirect:{value:null}},vertexShader:`

				varying vec3 vWorldDirection;

				vec3 transformDirection( in vec3 dir, in mat4 matrix ) {

					return normalize( ( matrix * vec4( dir, 0.0 ) ).xyz );

				}

				void main() {

					vWorldDirection = transformDirection( position, modelMatrix );

					#include <begin_vertex>
					#include <project_vertex>

				}
			`,fragmentShader:`

				uniform sampler2D tEquirect;

				varying vec3 vWorldDirection;

				#include <common>

				void main() {

					vec3 direction = normalize( vWorldDirection );

					vec2 sampleUV = equirectUv( direction );

					gl_FragColor = texture2D( tEquirect, sampleUV );

				}
			`},i=new n.BoxGeometry(5,5,5),a=new n.ShaderMaterial({name:"CubemapFromEquirect",uniforms:(0,n.cloneUniforms)(r.uniforms),vertexShader:r.vertexShader,fragmentShader:r.fragmentShader,side:n.BackSide,blending:n.NoBlending});
      a.uniforms.tEquirect.value=t;
      let o=new n.Mesh(i,a),l=t.minFilter;
      return t.minFilter===n.LinearMipmapLinearFilter&&(t.minFilter=n.LinearFilter),new n.CubeCamera(1,10,this).update(e,o),t.minFilter=l,o.geometry.dispose(),o.material.dispose(),this
      }clear(e,n=!0,t=!0,r=!0){
      let i=e.getRenderTarget();
      for(
      let i=0
      ;i<6;i++)
      e.setRenderTarget(this,i),e.clear(n,t,r);
      e.setRenderTarget(i)
      }
  }
  function U(e){
    let t=new WeakMap,r=new WeakMap,i=null;
    function a(e,t){
      return t===n.EquirectangularReflectionMapping?e.mapping=n.CubeReflectionMapping:t===n.EquirectangularRefractionMapping&&(e.mapping=n.CubeRefractionMapping),e
      }
    function o(e){
      let n=e.target;
      n.removeEventListener("dispose",o);
      let r=t.get(n);
      void 0!==r&&(t.delete(n),r.dispose())
      }
    function l(e){
      let n=e.target;
      n.removeEventListener("dispose",l);
      let t=r.get(n);
      void 0!==t&&(r.delete(n),t.dispose())
      }
    return{get:function(s,c=!1){
      return null==s?null:c?function(t){
        if(t&&t.isTexture){
          let a=t.mapping,o=a===n.EquirectangularReflectionMapping||a===n.EquirectangularRefractionMapping,s=a===n.CubeReflectionMapping||a===n.CubeRefractionMapping;
          if(o||s){
            let n=r.get(t),a=void 0!==n?n.texture.pmremVersion:0;
            if(t.isRenderTargetTexture&&t.pmremVersion!==a)
            return null===i&&(i=new x(e)),(n=o?i.fromEquirectangular(t,n):i.fromCubemap(t,n)).texture.pmremVersion=t.pmremVersion,r.set(t,n),n.texture;
            {
              if(void 0!==n)
              return n.texture;
              let a=t.image;
              return o&&a&&a.height>0||s&&a&&function(e){
                let n=0;
                for(
                let t=0
                ;t<6;t++)
                void 0!==e[t]&&n++;
                return 6===n
                }(a)?(null===i&&(i=new x(e)),(n=o?i.fromEquirectangular(t):i.fromCubemap(t)).texture.pmremVersion=t.pmremVersion,r.set(t,n),t.addEventListener("dispose",l),n.texture):null
              }
          }
          }
        return t
        }(s):function(r){
        if(r&&r.isTexture){
          let i=r.mapping;
          if(i===n.EquirectangularReflectionMapping||i===n.EquirectangularRefractionMapping)
          if(t.has(r))
          return a(t.get(r).texture,r.mapping);
          else{
            let n=r.image;
            if(!n||!(n.height>0))
            return null;
            {
              let i=new L(n.height);
              return i.fromEquirectangularTexture(e,r),t.set(r,i),r.addEventListener("dispose",o),a(i.texture,r.mapping)
              }
          }
          }
        return r
        }(s)
      },dispose:function(){
      t=new WeakMap,r=new WeakMap,null!==i&&(i.dispose(),i=null)
      }}
    }
  function D(e){
    let t={};
    function r(n){
      if(void 0!==t[n])
      return t[n];
      let r=e.getExtension(n);
      return t[n]=r,r
      }
    return{has:function(e){
      return null!==r(e)
      },init:function(){
      r("EXT_color_buffer_float"),r("WEBGL_clip_cull_distance"),r("OES_texture_float_linear"),r("EXT_color_buffer_half_float"),r("WEBGL_multisampled_render_to_texture"),r("WEBGL_render_shared_exponent")
      },get:function(e){
      let t=r(e);
      return null===t&&(0,n.warnOnce)("WebGLRenderer: "+e+" extension not supported."),t
      }}
    }
  function w(e,t,r,i){
    let a={},o=new WeakMap;
    function l(e){
      let n=e.target;
      for(
      let e
       in null!==n.index&&t.remove(n.index),n.attributes)
      t.remove(n.attributes[e]);
      n.removeEventListener("dispose",l),delete a[n.id];
      let s=o.get(n);
      s&&(t.remove(s),o.delete(n)),i.releaseStatesOfGeometry(n),!0===n.isInstancedBufferGeometry&&delete n._maxInstanceCount,r.memory.geometries--
      }
    function s(e){
      let r=[],i=e.index,a=e.attributes.position,l=0;
      if(void 0===a)
      return;
      if(null!==i){
        let e=i.array;
        l=i.version;
        for(
        let n=0,t=e.length
        ;n<t;n+=3){
          let t=e[n+0],i=e[n+1],a=e[n+2];
          r.push(t,i,i,a,a,t)
          }
        }else{
        let e=a.array;
        l=a.version;
        for(
        let n=0,t=e.length/3-1
        ;n<t;n+=3){
          let e=n+0,t=n+1,i=n+2;
          r.push(e,t,t,i,i,e)
          }
        }
      let s=new(a.count>=65535?n.Uint32BufferAttribute:n.Uint16BufferAttribute)(r,1);
      s.version=l;
      let c=o.get(e);
      c&&t.remove(c),o.set(e,s)
      }
    return{get:function(e,n){
      return!0===a[n.id]||(n.addEventListener("dispose",l),a[n.id]=!0,r.memory.geometries++),n
      },update:function(n){
      let r=n.attributes;
      for(
      let n
       in r)
      t.update(r[n],e.ARRAY_BUFFER)
      },getWireframeAttribute:function(e){
      let n=o.get(e);
      if(n){
        let t=e.index;
        null!==t&&n.version<t.version&&s(e)
        }else 
      s(e);
      return o.get(e)
      }}
    }
  function N(e,n,t){
    let r,i,a;
    this.setMode=function(e){
      r=e
      },this.setIndex=function(e){
      i=e.type,a=e.bytesPerElement
      },this.render=function(n,o){
      e.drawElements(r,o,i,n*a),t.update(o,r,1)
      },this.renderInstances=function(n,o,l){
      0!==l&&(e.drawElementsInstanced(r,o,i,n*a,l),t.update(o,r,l))
      },this.renderMultiDraw=function(e,a,o){
      if(0===o)
      return;
      n.get("WEBGL_multi_draw").multiDrawElementsWEBGL(r,a,0,i,e,0,o);
      let l=0;
      for(
      let e=0
      ;e<o;e++)
      l+=a[e];
      t.update(l,r,1)
      }
    }
  function I(e){
    let t={frame:0,calls:0,triangles:0,points:0,lines:0};
    return{memory:{geometries:0,textures:0},render:t,programs:null,autoReset:!0,reset:function(){
      t.calls=0,t.triangles=0,t.points=0,t.lines=0
      },update:function(r,i,a){
      switch(t.calls++,i){case e.TRIANGLES:
      t.triangles+=r/3*a;
      break;
      case e.LINES:
      t.lines+=r/2*a;
      break;
      case e.LINE_STRIP:
      t.lines+=a*(r-1);
      break;
      case e.LINE_LOOP:
      t.lines+=a*r;
      break;
      case e.POINTS:
      t.points+=a*r;
      break;
      default:
      (0,n.error)("WebGLInfo: Unknown draw mode:",i)
      }
      }}
    }
  function y(e,t,r){
    let i=new WeakMap,a=new n.Vector4;
    return{update:function(o,l,s){
      let c=o.morphTargetInfluences,d=l.morphAttributes.position||l.morphAttributes.normal||l.morphAttributes.color,u=void 0!==d?d.length:0,f=i.get(l);
      if(void 0===f||f.count!==u){
        void 0!==f&&f.texture.dispose();
        let e=void 0!==l.morphAttributes.position,r=void 0!==l.morphAttributes.normal,o=void 0!==l.morphAttributes.color,s=l.morphAttributes.position||[],c=l.morphAttributes.normal||[],d=l.morphAttributes.color||[],p=0;
        !0===e&&(p=1),!0===r&&(p=2),!0===o&&(p=3);
        let m=l.attributes.position.count*p,_=1;
        m>t.maxTextureSize&&(_=Math.ceil(m/t.maxTextureSize),m=t.maxTextureSize);
        let h=new Float32Array(m*_*4*u),g=new n.DataArrayTexture(h,m,_,u);
        g.type=n.FloatType,g.needsUpdate=!0;
        let v=4*p;
        for(
        let n=0
        ;n<u;n++){
          let t=s[n],i=c[n],l=d[n],u=m*_*4*n;
          for(
          let n=0
          ;n<t.count;n++){
            let s=n*v;
            !0===e&&(a.fromBufferAttribute(t,n),h[u+s+0]=a.x,h[u+s+1]=a.y,h[u+s+2]=a.z,h[u+s+3]=0),!0===r&&(a.fromBufferAttribute(i,n),h[u+s+4]=a.x,h[u+s+5]=a.y,h[u+s+6]=a.z,h[u+s+7]=0),!0===o&&(a.fromBufferAttribute(l,n),h[u+s+8]=a.x,h[u+s+9]=a.y,h[u+s+10]=a.z,h[u+s+11]=4===l.itemSize?a.w:1)
            }
          }
        f={count:u,texture:g,size:new n.Vector2(m,_)},i.set(l,f),l.addEventListener("dispose",function e(){
          g.dispose(),i.delete(l),l.removeEventListener("dispose",e)
          })
        }
      if(!0===o.isInstancedMesh&&null!==o.morphTexture)
      s.getUniforms().setValue(e,"morphTexture",o.morphTexture,r);
      else{
        let n=0;
        for(
        let e=0
        ;e<c.length;e++)
        n+=c[e];
        let t=l.morphTargetsRelative?1:1-n;
        s.getUniforms().setValue(e,"morphTargetBaseInfluence",t),s.getUniforms().setValue(e,"morphTargetInfluences",c)
        }
      s.getUniforms().setValue(e,"morphTargetsTexture",f.texture,r),s.getUniforms().setValue(e,"morphTargetsTextureSize",f.size)
      }}
    }
  function F(e,n,t,r,i){
    let a=new WeakMap;
    function o(e){
      let n=e.target;
      n.removeEventListener("dispose",o),r.releaseStatesOfObject(n),t.remove(n.instanceMatrix),null!==n.instanceColor&&t.remove(n.instanceColor)
      }
    return{update:function(r){
      let l=i.render.frame,s=r.geometry,c=n.get(r,s);
      if(a.get(c)!==l&&(n.update(c),a.set(c,l)),r.isInstancedMesh&&(!1===r.hasEventListener("dispose",o)&&r.addEventListener("dispose",o),a.get(r)!==l&&(t.update(r.instanceMatrix,e.ARRAY_BUFFER),null!==r.instanceColor&&t.update(r.instanceColor,e.ARRAY_BUFFER),a.set(r,l))),r.isSkinnedMesh){
        let e=r.skeleton;
        a.get(e)!==l&&(e.update(),a.set(e,l))
        }
      return c
      },dispose:function(){
      a=new WeakMap
      }}
    }
  let O={[n.LinearToneMapping]:"LINEAR_TONE_MAPPING",[n.ReinhardToneMapping]:"REINHARD_TONE_MAPPING",[n.CineonToneMapping]:"CINEON_TONE_MAPPING",[n.ACESFilmicToneMapping]:"ACES_FILMIC_TONE_MAPPING",[n.AgXToneMapping]:"AGX_TONE_MAPPING",[n.NeutralToneMapping]:"NEUTRAL_TONE_MAPPING",[n.CustomToneMapping]:"CUSTOM_TONE_MAPPING"};
  function B(e,t,r,i,a){
    let o,l=new n.WebGLRenderTarget(t,r,{type:e,depthBuffer:i,stencilBuffer:a,depthTexture:i?new n.DepthTexture(t,r):void 0}),s=new n.WebGLRenderTarget(t,r,{type:n.HalfFloatType,depthBuffer:!1,stencilBuffer:!1}),c=new n.BufferGeometry;
    c.setAttribute("position",new n.Float32BufferAttribute([-1,3,0,-1,-1,0,3,-1,0],3)),c.setAttribute("uv",new n.Float32BufferAttribute([0,2,0,0,2,0],2));
    let d=new n.RawShaderMaterial({uniforms:{tDiffuse:{value:null}},vertexShader:`
			precision highp float;

			uniform mat4 modelViewMatrix;
			uniform mat4 projectionMatrix;

			attribute vec3 position;
			attribute vec2 uv;

			varying vec2 vUv;

			void main() {
				vUv = uv;
				gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );
			}`,fragmentShader:`
			precision highp float;

			uniform sampler2D tDiffuse;

			varying vec2 vUv;

			#include <tonemapping_pars_fragment>
			#include <colorspace_pars_fragment>

			void main() {
				gl_FragColor = texture2D( tDiffuse, vUv );

				#ifdef LINEAR_TONE_MAPPING
					gl_FragColor.rgb = LinearToneMapping( gl_FragColor.rgb );
				#elif defined( REINHARD_TONE_MAPPING )
					gl_FragColor.rgb = ReinhardToneMapping( gl_FragColor.rgb );
				#elif defined( CINEON_TONE_MAPPING )
					gl_FragColor.rgb = CineonToneMapping( gl_FragColor.rgb );
				#elif defined( ACES_FILMIC_TONE_MAPPING )
					gl_FragColor.rgb = ACESFilmicToneMapping( gl_FragColor.rgb );
				#elif defined( AGX_TONE_MAPPING )
					gl_FragColor.rgb = AgXToneMapping( gl_FragColor.rgb );
				#elif defined( NEUTRAL_TONE_MAPPING )
					gl_FragColor.rgb = NeutralToneMapping( gl_FragColor.rgb );
				#elif defined( CUSTOM_TONE_MAPPING )
					gl_FragColor.rgb = CustomToneMapping( gl_FragColor.rgb );
				#endif

				#ifdef SRGB_TRANSFER
					gl_FragColor = sRGBTransferOETF( gl_FragColor );
				#endif
			}`,depthTest:!1,depthWrite:!1}),u=new n.Mesh(c,d),f=new n.OrthographicCamera(-1,1,1,-1,0,1),p=null,m=null,_=!1,h=null,g=[],v=!1;
    this.setSize=function(e,n){
      l.setSize(e,n),s.setSize(e,n);
      for(
      let t=0
      ;t<g.length;t++){
        let r=g[t];
        r.setSize&&r.setSize(e,n)
        }
      },this.setEffects=function(e){
      v=(g=e).length>0&&!0===g[0].isRenderPass;
      let n=l.width,t=l.height;
      for(
      let e=0
      ;e<g.length;e++){
        let r=g[e];
        r.setSize&&r.setSize(n,t)
        }
      },this.begin=function(e,t){
      if(_||e.toneMapping===n.NoToneMapping&&0===g.length)
      return!1;
      if(h=t,null!==t){
        let e=t.width,n=t.height;
        (l.width!==e||l.height!==n)&&this.setSize(e,n)
        }
      return!1===v&&e.setRenderTarget(l),o=e.toneMapping,e.toneMapping=n.NoToneMapping,!0
      },this.hasRenderPass=function(){
      return v
      },this.end=function(e,t){
      e.toneMapping=o,_=!0;
      let r=l,i=s;
      for(
      let n=0
      ;n<g.length;n++){
        let a=g[n];
        if(!1!==a.enabled&&(a.render(e,i,r,t),!1!==a.needsSwap)){
          let e=r;
          r=i,i=e
          }
        }
      if(p!==e.outputColorSpace||m!==e.toneMapping){
        p=e.outputColorSpace,m=e.toneMapping,d.defines={},n.ColorManagement.getTransfer(p)===n.SRGBTransfer&&(d.defines.SRGB_TRANSFER="");
        let t=O[m];
        t&&(d.defines[t]=""),d.needsUpdate=!0
        }
      d.uniforms.tDiffuse.value=r.texture,e.setRenderTarget(h),e.render(u,f),h=null,_=!1
      },this.isCompositing=function(){
      return _
      },this.dispose=function(){
      l.depthTexture&&l.depthTexture.dispose(),l.dispose(),s.dispose(),c.dispose(),d.dispose()
      }
    }
  let G=new n.Texture,H=new n.DepthTexture(1,1),V=new n.DataArrayTexture,W=new n.Data3DTexture,z=new n.CubeTexture,k=[],X=[],q=new Float32Array(16),K=new Float32Array(9),Y=new Float32Array(4);
  function j(e,n,t){
    let r=e[0];
    if(r<=0||r>0)
    return e;
    let i=n*t,a=k[i];
    if(void 0===a&&(a=new Float32Array(i),k[i]=a),0!==n){
      r.toArray(a,0);
      for(
      let r=1,i=0
      ;r!==n;++r)
      i+=t,e[r].toArray(a,i)
      }
    return a
    }
  function Z(e,n){
    if(e.length!==n.length)
    return!1;
    for(
    let t=0,r=e.length
    ;t<r;t++)
    if(e[t]!==n[t])
    return!1;
    return!0
    }
  function $(e,n){
    for(
    let t=0,r=n.length
    ;t<r;t++)
    e[t]=n[t]
    }
  function Q(e,n){
    let t=X[n];
    void 0===t&&(t=new Int32Array(n),X[n]=t);
    for(
    let r=0
    ;r!==n;++r)
    t[r]=e.allocateTextureUnit();
    return t
    }
  function J(e,n){
    let t=this.cache;
    t[0]!==n&&(e.uniform1f(this.addr,n),t[0]=n)
    }
  function ee(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y)&&(e.uniform2f(this.addr,n.x,n.y),t[0]=n.x,t[1]=n.y);
    else{
      if(Z(t,n))
      return;
      e.uniform2fv(this.addr,n),$(t,n)
      }
    }
  function en(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y||t[2]!==n.z)&&(e.uniform3f(this.addr,n.x,n.y,n.z),t[0]=n.x,t[1]=n.y,t[2]=n.z);
    else 
    if(void 0!==n.r)
    (t[0]!==n.r||t[1]!==n.g||t[2]!==n.b)&&(e.uniform3f(this.addr,n.r,n.g,n.b),t[0]=n.r,t[1]=n.g,t[2]=n.b);
    else{
      if(Z(t,n))
      return;
      e.uniform3fv(this.addr,n),$(t,n)
      }
    }
  function et(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y||t[2]!==n.z||t[3]!==n.w)&&(e.uniform4f(this.addr,n.x,n.y,n.z,n.w),t[0]=n.x,t[1]=n.y,t[2]=n.z,t[3]=n.w);
    else{
      if(Z(t,n))
      return;
      e.uniform4fv(this.addr,n),$(t,n)
      }
    }
  function er(e,n){
    let t=this.cache,r=n.elements;
    if(void 0===r){
      if(Z(t,n))
      return;
      e.uniformMatrix2fv(this.addr,!1,n),$(t,n)
      }else{
      if(Z(t,r))
      return;
      Y.set(r),e.uniformMatrix2fv(this.addr,!1,Y),$(t,r)
      }
    }
  function ei(e,n){
    let t=this.cache,r=n.elements;
    if(void 0===r){
      if(Z(t,n))
      return;
      e.uniformMatrix3fv(this.addr,!1,n),$(t,n)
      }else{
      if(Z(t,r))
      return;
      K.set(r),e.uniformMatrix3fv(this.addr,!1,K),$(t,r)
      }
    }
  function ea(e,n){
    let t=this.cache,r=n.elements;
    if(void 0===r){
      if(Z(t,n))
      return;
      e.uniformMatrix4fv(this.addr,!1,n),$(t,n)
      }else{
      if(Z(t,r))
      return;
      q.set(r),e.uniformMatrix4fv(this.addr,!1,q),$(t,r)
      }
    }
  function eo(e,n){
    let t=this.cache;
    t[0]!==n&&(e.uniform1i(this.addr,n),t[0]=n)
    }
  function el(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y)&&(e.uniform2i(this.addr,n.x,n.y),t[0]=n.x,t[1]=n.y);
    else{
      if(Z(t,n))
      return;
      e.uniform2iv(this.addr,n),$(t,n)
      }
    }
  function es(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y||t[2]!==n.z)&&(e.uniform3i(this.addr,n.x,n.y,n.z),t[0]=n.x,t[1]=n.y,t[2]=n.z);
    else{
      if(Z(t,n))
      return;
      e.uniform3iv(this.addr,n),$(t,n)
      }
    }
  function ec(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y||t[2]!==n.z||t[3]!==n.w)&&(e.uniform4i(this.addr,n.x,n.y,n.z,n.w),t[0]=n.x,t[1]=n.y,t[2]=n.z,t[3]=n.w);
    else{
      if(Z(t,n))
      return;
      e.uniform4iv(this.addr,n),$(t,n)
      }
    }
  function ed(e,n){
    let t=this.cache;
    t[0]!==n&&(e.uniform1ui(this.addr,n),t[0]=n)
    }
  function eu(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y)&&(e.uniform2ui(this.addr,n.x,n.y),t[0]=n.x,t[1]=n.y);
    else{
      if(Z(t,n))
      return;
      e.uniform2uiv(this.addr,n),$(t,n)
      }
    }
  function ef(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y||t[2]!==n.z)&&(e.uniform3ui(this.addr,n.x,n.y,n.z),t[0]=n.x,t[1]=n.y,t[2]=n.z);
    else{
      if(Z(t,n))
      return;
      e.uniform3uiv(this.addr,n),$(t,n)
      }
    }
  function ep(e,n){
    let t=this.cache;
    if(void 0!==n.x)
    (t[0]!==n.x||t[1]!==n.y||t[2]!==n.z||t[3]!==n.w)&&(e.uniform4ui(this.addr,n.x,n.y,n.z,n.w),t[0]=n.x,t[1]=n.y,t[2]=n.z,t[3]=n.w);
    else{
      if(Z(t,n))
      return;
      e.uniform4uiv(this.addr,n),$(t,n)
      }
    }
  function em(e,t,r){
    let i,a=this.cache,o=r.allocateTextureUnit();
    a[0]!==o&&(e.uniform1i(this.addr,o),a[0]=o),this.type===e.SAMPLER_2D_SHADOW?(H.compareFunction=r.isReversedDepthBuffer()?n.GreaterEqualCompare:n.LessEqualCompare,i=H):i=G,r.setTexture2D(t||i,o)
    }
  function e_(e,n,t){
    let r=this.cache,i=t.allocateTextureUnit();
    r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),t.setTexture3D(n||W,i)
    }
  function eh(e,n,t){
    let r=this.cache,i=t.allocateTextureUnit();
    r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),t.setTextureCube(n||z,i)
    }
  function eg(e,n,t){
    let r=this.cache,i=t.allocateTextureUnit();
    r[0]!==i&&(e.uniform1i(this.addr,i),r[0]=i),t.setTexture2DArray(n||V,i)
    }
  function ev(e,n){
    e.uniform1fv(this.addr,n)
    }
  function eS(e,n){
    let t=j(n,this.size,2);
    e.uniform2fv(this.addr,t)
    }
  function eE(e,n){
    let t=j(n,this.size,3);
    e.uniform3fv(this.addr,t)
    }
  function eT(e,n){
    let t=j(n,this.size,4);
    e.uniform4fv(this.addr,t)
    }
  function eM(e,n){
    let t=j(n,this.size,4);
    e.uniformMatrix2fv(this.addr,!1,t)
    }
  function ex(e,n){
    let t=j(n,this.size,9);
    e.uniformMatrix3fv(this.addr,!1,t)
    }
  function eR(e,n){
    let t=j(n,this.size,16);
    e.uniformMatrix4fv(this.addr,!1,t)
    }
  function eA(e,n){
    e.uniform1iv(this.addr,n)
    }
  function eC(e,n){
    e.uniform2iv(this.addr,n)
    }
  function eb(e,n){
    e.uniform3iv(this.addr,n)
    }
  function eP(e,n){
    e.uniform4iv(this.addr,n)
    }
  function eL(e,n){
    e.uniform1uiv(this.addr,n)
    }
  function eU(e,n){
    e.uniform2uiv(this.addr,n)
    }
  function eD(e,n){
    e.uniform3uiv(this.addr,n)
    }
  function ew(e,n){
    e.uniform4uiv(this.addr,n)
    }
  function eN(e,n,t){
    let r,i=this.cache,a=n.length,o=Q(t,a);
    Z(i,o)||(e.uniform1iv(this.addr,o),$(i,o)),r=this.type===e.SAMPLER_2D_SHADOW?H:G;
    for(
    let e=0
    ;e!==a;++e)
    t.setTexture2D(n[e]||r,o[e])
    }
  function eI(e,n,t){
    let r=this.cache,i=n.length,a=Q(t,i);
    Z(r,a)||(e.uniform1iv(this.addr,a),$(r,a));
    for(
    let e=0
    ;e!==i;++e)
    t.setTexture3D(n[e]||W,a[e])
    }
  function ey(e,n,t){
    let r=this.cache,i=n.length,a=Q(t,i);
    Z(r,a)||(e.uniform1iv(this.addr,a),$(r,a));
    for(
    let e=0
    ;e!==i;++e)
    t.setTextureCube(n[e]||z,a[e])
    }
  function eF(e,n,t){
    let r=this.cache,i=n.length,a=Q(t,i);
    Z(r,a)||(e.uniform1iv(this.addr,a),$(r,a));
    for(
    let e=0
    ;e!==i;++e)
    t.setTexture2DArray(n[e]||V,a[e])
    }
  class eO{
    constructor(e,n,t){
      this.id=e,this.addr=t,this.cache=[],this.type=n.type,this.setValue=function(e){
        switch(e){case 5126:
        return J;
        case 35664:
        return ee;
        case 35665:
        return en;
        case 35666:
        return et;
        case 35674:
        return er;
        case 35675:
        return ei;
        case 35676:
        return ea;
        case 5124:case 35670:
        return eo;
        case 35667:case 35671:
        return el;
        case 35668:case 35672:
        return es;
        case 35669:case 35673:
        return ec;
        case 5125:
        return ed;
        case 36294:
        return eu;
        case 36295:
        return ef;
        case 36296:
        return ep;
        case 35678:case 36198:case 36298:case 36306:case 35682:
        return em;
        case 35679:case 36299:case 36307:
        return e_;
        case 35680:case 36300:case 36308:case 36293:
        return eh;
        case 36289:case 36303:case 36311:case 36292:
        return eg
        }
        }(n.type)
      }
  }
  class eB{
    constructor(e,n,t){
      this.id=e,this.addr=t,this.cache=[],this.type=n.type,this.size=n.size,this.setValue=function(e){
        switch(e){case 5126:
        return ev;
        case 35664:
        return eS;
        case 35665:
        return eE;
        case 35666:
        return eT;
        case 35674:
        return eM;
        case 35675:
        return ex;
        case 35676:
        return eR;
        case 5124:case 35670:
        return eA;
        case 35667:case 35671:
        return eC;
        case 35668:case 35672:
        return eb;
        case 35669:case 35673:
        return eP;
        case 5125:
        return eL;
        case 36294:
        return eU;
        case 36295:
        return eD;
        case 36296:
        return ew;
        case 35678:case 36198:case 36298:case 36306:case 35682:
        return eN;
        case 35679:case 36299:case 36307:
        return eI;
        case 35680:case 36300:case 36308:case 36293:
        return ey;
        case 36289:case 36303:case 36311:case 36292:
        return eF
        }
        }(n.type)
      }
  }
  class eG{
    constructor(e){
      this.id=e,this.seq=[],this.map={}
      }setValue(e,n,t){
      let r=this.seq;
      for(
      let i=0,a=r.length
      ;i!==a;++i){
        let a=r[i];
        a.setValue(e,n[a.id],t)
        }
      }
  }
  let eH=/(\w+)(\])?(\[|\.)?/g;
  function eV(e,n){
    e.seq.push(n),e.map[n.id]=n
    }
  class eW{
    constructor(e,n){
      this.seq=[],this.map={};
      const t=e.getProgramParameter(n,e.ACTIVE_UNIFORMS);
      for(
      let r=0
      ;r<t;++r){
        const t=e.getActiveUniform(n,r),i=e.getUniformLocation(n,t.name);
        !function(e,n,t){
          let r=e.name,i=r.length;
          for(eH.lastIndex=0;;){
            let a=eH.exec(r),o=eH.lastIndex,l=a[1],s="]"===a[2],c=a[3];
            if(s&&(l|=0),void 0===c||"["===c&&o+2===i){
              eV(t,void 0===c?new eO(l,e,n):new eB(l,e,n));
              break
              }
            {
              let e=t.map[l];
              void 0===e&&eV(t,e=new eG(l)),t=e
              }
          }
          }(t,i,this)
        }
      const r=[],i=[];
      for(
      const n
       of this.seq)
      n.type===e.SAMPLER_2D_SHADOW||n.type===e.SAMPLER_CUBE_SHADOW||n.type===e.SAMPLER_2D_ARRAY_SHADOW?r.push(n):i.push(n);
      r.length>0&&(this.seq=r.concat(i))
      }setValue(e,n,t,r){
      let i=this.map[n];
      void 0!==i&&i.setValue(e,t,r)
      }setOptional(e,n,t){
      let r=n[t];
      void 0!==r&&this.setValue(e,t,r)
      }static upload(e,n,t,r){
      for(
      let i=0,a=n.length
      ;i!==a;++i){
        let a=n[i],o=t[a.id];
        !1!==o.needsUpdate&&a.setValue(e,o.value,r)
        }
      }static seqWithValue(e,n){
      let t=[];
      for(
      let r=0,i=e.length
      ;r!==i;++r){
        let i=e[r];
        i.id in n&&t.push(i)
        }
      return t
      }
  }
  function ez(e,n,t){
    let r=e.createShader(n);
    return e.shaderSource(r,t),e.compileShader(r),r
    }
  let ek=0,eX=new n.Matrix3;
  function eq(e,n,t){
    let r=e.getShaderParameter(n,e.COMPILE_STATUS),i=(e.getShaderInfoLog(n)||"").trim();
    if(r&&""===i)
    return"";
    let a=/ERROR: 0:(\d+)/.exec(i);
    if(!a)
    return i;
    {
      let r=parseInt(a[1]);
      return t.toUpperCase()+"\n\n"+i+"\n\n"+function(e,n){
        let t=e.split("\n"),r=[],i=Math.max(n-6,0),a=Math.min(n+6,t.length);
        for(
        let e=i
        ;e<a;e++){
          let i=e+1;
          r.push(`${i===n?">":" "} ${i}: ${t[e]}`)
          }
        return r.join("\n")
        }(e.getShaderSource(n),r)
      }
  }
  let eK={[n.LinearToneMapping]:"Linear",[n.ReinhardToneMapping]:"Reinhard",[n.CineonToneMapping]:"Cineon",[n.ACESFilmicToneMapping]:"ACESFilmic",[n.AgXToneMapping]:"AgX",[n.NeutralToneMapping]:"Neutral",[n.CustomToneMapping]:"Custom"},eY=new n.Vector3;
  function ej(e){
    return""!==e
    }
  function eZ(e,n){
    let t=n.numSpotLightShadows+n.numSpotLightMaps-n.numSpotLightShadowsWithMaps;
    return e.replace(/NUM_DIR_LIGHTS/g,n.numDirLights).replace(/NUM_SPOT_LIGHTS/g,n.numSpotLights).replace(/NUM_SPOT_LIGHT_MAPS/g,n.numSpotLightMaps).replace(/NUM_SPOT_LIGHT_COORDS/g,t).replace(/NUM_RECT_AREA_LIGHTS/g,n.numRectAreaLights).replace(/NUM_POINT_LIGHTS/g,n.numPointLights).replace(/NUM_HEMI_LIGHTS/g,n.numHemiLights).replace(/NUM_DIR_LIGHT_SHADOWS/g,n.numDirLightShadows).replace(/NUM_SPOT_LIGHT_SHADOWS_WITH_MAPS/g,n.numSpotLightShadowsWithMaps).replace(/NUM_SPOT_LIGHT_SHADOWS/g,n.numSpotLightShadows).replace(/NUM_POINT_LIGHT_SHADOWS/g,n.numPointLightShadows)
    }
  function e$(e,n){
    return e.replace(/NUM_CLIPPING_PLANES/g,n.numClippingPlanes).replace(/UNION_CLIPPING_PLANES/g,n.numClippingPlanes-n.numClipIntersection)
    }
  let eQ=/^[ \t]*#include +<([\w\d./]+)>/gm;
  function eJ(e){
    return e.replace(eQ,e1)
    }
  let e0=new Map;
  function e1(e,t){
    let r=i[t];
    if(void 0===r){
      let e=e0.get(t);
      if(void 0!==e)
      r=i[e],(0,n.warn)('WebGLRenderer: Shader chunk "%s" has been deprecated. Use "%s" instead.',t,e);
      else 
      throw Error("Can not resolve #include <"+t+">")
      }
    return eJ(r)
    }
  let e3=/#pragma unroll_loop_start\s+for\s*\(\s*int\s+i\s*=\s*(\d+)\s*;\s*i\s*<\s*(\d+)\s*;\s*i\s*\+\+\s*\)\s*{([\s\S]+?)}\s+#pragma unroll_loop_end/g;
  function e2(e){
    return e.replace(e3,e4)
    }
  function e4(e,n,t,r){
    let i="";
    for(
    let e=parseInt(n)
    ;e<parseInt(t);e++)
    i+=r.replace(/\[\s*i\s*\]/g,"[ "+e+" ]").replace(/UNROLLED_LOOP_INDEX/g,e);
    return i
    }
  function e5(e){
    let n=`precision ${e.precision} float;
	precision ${e.precision} int;
	precision ${e.precision} sampler2D;
	precision ${e.precision} samplerCube;
	precision ${e.precision} sampler3D;
	precision ${e.precision} sampler2DArray;
	precision ${e.precision} sampler2DShadow;
	precision ${e.precision} samplerCubeShadow;
	precision ${e.precision} sampler2DArrayShadow;
	precision ${e.precision} isampler2D;
	precision ${e.precision} isampler3D;
	precision ${e.precision} isamplerCube;
	precision ${e.precision} isampler2DArray;
	precision ${e.precision} usampler2D;
	precision ${e.precision} usampler3D;
	precision ${e.precision} usamplerCube;
	precision ${e.precision} usampler2DArray;
	`;
    return"highp"===e.precision?n+="\n#define HIGH_PRECISION":"mediump"===e.precision?n+="\n#define MEDIUM_PRECISION":"lowp"===e.precision&&(n+="\n#define LOW_PRECISION"),n
    }
  let e6={[n.PCFShadowMap]:"SHADOWMAP_TYPE_PCF",[n.VSMShadowMap]:"SHADOWMAP_TYPE_VSM"},e8={[n.CubeReflectionMapping]:"ENVMAP_TYPE_CUBE",[n.CubeRefractionMapping]:"ENVMAP_TYPE_CUBE",[n.CubeUVReflectionMapping]:"ENVMAP_TYPE_CUBE_UV"},e9={[n.CubeRefractionMapping]:"ENVMAP_MODE_REFRACTION"},e7={[n.MultiplyOperation]:"ENVMAP_BLENDING_MULTIPLY",[n.MixOperation]:"ENVMAP_BLENDING_MIX",[n.AddOperation]:"ENVMAP_BLENDING_ADD"};
  function ne(e,t,r,a){
    var o,l;
    let s,c,d,u,f=e.getContext(),p=r.defines,m=r.vertexShader,_=r.fragmentShader,h=e6[r.shadowMapType]||"SHADOWMAP_TYPE_BASIC",g=!1===r.envMap?"ENVMAP_TYPE_CUBE":e8[r.envMapMode]||"ENVMAP_TYPE_CUBE",v=!1===r.envMap?"ENVMAP_MODE_REFLECTION":e9[r.envMapMode]||"ENVMAP_MODE_REFLECTION",S=!1===r.envMap?"ENVMAP_BLENDING_NONE":e7[r.combine]||"ENVMAP_BLENDING_NONE",E=function(e){
      let n=e.envMapCubeUVHeight;
      if(null===n)
      return null;
      let t=Math.log2(n)-2;
      return{texelWidth:1/(3*Math.max(Math.pow(2,t),112)),texelHeight:1/n,maxMip:t}
      }(r),T=[r.extensionClipCullDistance?"#extension GL_ANGLE_clip_cull_distance : require":"",r.extensionMultiDraw?"#extension GL_ANGLE_multi_draw : require":""].filter(ej).join("\n"),M=function(e){
      let n=[];
      for(
      let t
       in e){
        let r=e[t];
        !1!==r&&n.push("#define "+t+" "+r)
        }
      return n.join("\n")
      }(p),x=f.createProgram(),R=r.glslVersion?"#version "+r.glslVersion+"\n":"";
    if(r.isRawShaderMaterial)
    (s=["#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,M].filter(ej).join("\n")).length>0&&(s+="\n"),(c=["#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,M].filter(ej).join("\n")).length>0&&(c+="\n");
    else{
      let e,t,a,d,u;
      s=[e5(r),"#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,M,r.extensionClipCullDistance?"#define USE_CLIP_DISTANCE":"",r.batching?"#define USE_BATCHING":"",r.batchingColor?"#define USE_BATCHING_COLOR":"",r.instancing?"#define USE_INSTANCING":"",r.instancingColor?"#define USE_INSTANCING_COLOR":"",r.instancingMorph?"#define USE_INSTANCING_MORPH":"",r.useFog&&r.fog?"#define USE_FOG":"",r.useFog&&r.fogExp2?"#define FOG_EXP2":"",r.map?"#define USE_MAP":"",r.envMap?"#define USE_ENVMAP":"",r.envMap?"#define "+v:"",r.lightMap?"#define USE_LIGHTMAP":"",r.aoMap?"#define USE_AOMAP":"",r.bumpMap?"#define USE_BUMPMAP":"",r.normalMap?"#define USE_NORMALMAP":"",r.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",r.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",r.displacementMap?"#define USE_DISPLACEMENTMAP":"",r.emissiveMap?"#define USE_EMISSIVEMAP":"",r.anisotropy?"#define USE_ANISOTROPY":"",r.anisotropyMap?"#define USE_ANISOTROPYMAP":"",r.clearcoatMap?"#define USE_CLEARCOATMAP":"",r.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",r.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",r.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",r.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",r.specularMap?"#define USE_SPECULARMAP":"",r.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",r.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",r.roughnessMap?"#define USE_ROUGHNESSMAP":"",r.metalnessMap?"#define USE_METALNESSMAP":"",r.alphaMap?"#define USE_ALPHAMAP":"",r.alphaHash?"#define USE_ALPHAHASH":"",r.transmission?"#define USE_TRANSMISSION":"",r.transmissionMap?"#define USE_TRANSMISSIONMAP":"",r.thicknessMap?"#define USE_THICKNESSMAP":"",r.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",r.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",r.mapUv?"#define MAP_UV "+r.mapUv:"",r.alphaMapUv?"#define ALPHAMAP_UV "+r.alphaMapUv:"",r.lightMapUv?"#define LIGHTMAP_UV "+r.lightMapUv:"",r.aoMapUv?"#define AOMAP_UV "+r.aoMapUv:"",r.emissiveMapUv?"#define EMISSIVEMAP_UV "+r.emissiveMapUv:"",r.bumpMapUv?"#define BUMPMAP_UV "+r.bumpMapUv:"",r.normalMapUv?"#define NORMALMAP_UV "+r.normalMapUv:"",r.displacementMapUv?"#define DISPLACEMENTMAP_UV "+r.displacementMapUv:"",r.metalnessMapUv?"#define METALNESSMAP_UV "+r.metalnessMapUv:"",r.roughnessMapUv?"#define ROUGHNESSMAP_UV "+r.roughnessMapUv:"",r.anisotropyMapUv?"#define ANISOTROPYMAP_UV "+r.anisotropyMapUv:"",r.clearcoatMapUv?"#define CLEARCOATMAP_UV "+r.clearcoatMapUv:"",r.clearcoatNormalMapUv?"#define CLEARCOAT_NORMALMAP_UV "+r.clearcoatNormalMapUv:"",r.clearcoatRoughnessMapUv?"#define CLEARCOAT_ROUGHNESSMAP_UV "+r.clearcoatRoughnessMapUv:"",r.iridescenceMapUv?"#define IRIDESCENCEMAP_UV "+r.iridescenceMapUv:"",r.iridescenceThicknessMapUv?"#define IRIDESCENCE_THICKNESSMAP_UV "+r.iridescenceThicknessMapUv:"",r.sheenColorMapUv?"#define SHEEN_COLORMAP_UV "+r.sheenColorMapUv:"",r.sheenRoughnessMapUv?"#define SHEEN_ROUGHNESSMAP_UV "+r.sheenRoughnessMapUv:"",r.specularMapUv?"#define SPECULARMAP_UV "+r.specularMapUv:"",r.specularColorMapUv?"#define SPECULAR_COLORMAP_UV "+r.specularColorMapUv:"",r.specularIntensityMapUv?"#define SPECULAR_INTENSITYMAP_UV "+r.specularIntensityMapUv:"",r.transmissionMapUv?"#define TRANSMISSIONMAP_UV "+r.transmissionMapUv:"",r.thicknessMapUv?"#define THICKNESSMAP_UV "+r.thicknessMapUv:"",r.vertexTangents&&!1===r.flatShading?"#define USE_TANGENT":"",r.vertexNormals?"#define HAS_NORMAL":"",r.vertexColors?"#define USE_COLOR":"",r.vertexAlphas?"#define USE_COLOR_ALPHA":"",r.vertexUv1s?"#define USE_UV1":"",r.vertexUv2s?"#define USE_UV2":"",r.vertexUv3s?"#define USE_UV3":"",r.pointsUvs?"#define USE_POINTS_UV":"",r.flatShading?"#define FLAT_SHADED":"",r.skinning?"#define USE_SKINNING":"",r.morphTargets?"#define USE_MORPHTARGETS":"",r.morphNormals&&!1===r.flatShading?"#define USE_MORPHNORMALS":"",r.morphColors?"#define USE_MORPHCOLORS":"",r.morphTargetsCount>0?"#define MORPHTARGETS_TEXTURE_STRIDE "+r.morphTextureStride:"",r.morphTargetsCount>0?"#define MORPHTARGETS_COUNT "+r.morphTargetsCount:"",r.doubleSided?"#define DOUBLE_SIDED":"",r.flipSided?"#define FLIP_SIDED":"",r.shadowMapEnabled?"#define USE_SHADOWMAP":"",r.shadowMapEnabled?"#define "+h:"",r.sizeAttenuation?"#define USE_SIZEATTENUATION":"",r.numLightProbes>0?"#define USE_LIGHT_PROBES":"",r.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",r.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 modelMatrix;","uniform mat4 modelViewMatrix;","uniform mat4 projectionMatrix;","uniform mat4 viewMatrix;","uniform mat3 normalMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;","#ifdef USE_INSTANCING","	attribute mat4 instanceMatrix;","#endif","#ifdef USE_INSTANCING_COLOR","	attribute vec3 instanceColor;","#endif","#ifdef USE_INSTANCING_MORPH","	uniform sampler2D morphTexture;","#endif","attribute vec3 position;","attribute vec3 normal;","attribute vec2 uv;","#ifdef USE_UV1","	attribute vec2 uv1;","#endif","#ifdef USE_UV2","	attribute vec2 uv2;","#endif","#ifdef USE_UV3","	attribute vec2 uv3;","#endif","#ifdef USE_TANGENT","	attribute vec4 tangent;","#endif","#if defined( USE_COLOR_ALPHA )","	attribute vec4 color;","#elif defined( USE_COLOR )","	attribute vec3 color;","#endif","#ifdef USE_SKINNING","	attribute vec4 skinIndex;","	attribute vec4 skinWeight;","#endif","\n"].filter(ej).join("\n"),c=[e5(r),"#define SHADER_TYPE "+r.shaderType,"#define SHADER_NAME "+r.shaderName,M,r.useFog&&r.fog?"#define USE_FOG":"",r.useFog&&r.fogExp2?"#define FOG_EXP2":"",r.alphaToCoverage?"#define ALPHA_TO_COVERAGE":"",r.map?"#define USE_MAP":"",r.matcap?"#define USE_MATCAP":"",r.envMap?"#define USE_ENVMAP":"",r.envMap?"#define "+g:"",r.envMap?"#define "+v:"",r.envMap?"#define "+S:"",E?"#define CUBEUV_TEXEL_WIDTH "+E.texelWidth:"",E?"#define CUBEUV_TEXEL_HEIGHT "+E.texelHeight:"",E?"#define CUBEUV_MAX_MIP "+E.maxMip+".0":"",r.lightMap?"#define USE_LIGHTMAP":"",r.aoMap?"#define USE_AOMAP":"",r.bumpMap?"#define USE_BUMPMAP":"",r.normalMap?"#define USE_NORMALMAP":"",r.normalMapObjectSpace?"#define USE_NORMALMAP_OBJECTSPACE":"",r.normalMapTangentSpace?"#define USE_NORMALMAP_TANGENTSPACE":"",r.packedNormalMap?"#define USE_PACKED_NORMALMAP":"",r.emissiveMap?"#define USE_EMISSIVEMAP":"",r.anisotropy?"#define USE_ANISOTROPY":"",r.anisotropyMap?"#define USE_ANISOTROPYMAP":"",r.clearcoat?"#define USE_CLEARCOAT":"",r.clearcoatMap?"#define USE_CLEARCOATMAP":"",r.clearcoatRoughnessMap?"#define USE_CLEARCOAT_ROUGHNESSMAP":"",r.clearcoatNormalMap?"#define USE_CLEARCOAT_NORMALMAP":"",r.dispersion?"#define USE_DISPERSION":"",r.iridescence?"#define USE_IRIDESCENCE":"",r.iridescenceMap?"#define USE_IRIDESCENCEMAP":"",r.iridescenceThicknessMap?"#define USE_IRIDESCENCE_THICKNESSMAP":"",r.specularMap?"#define USE_SPECULARMAP":"",r.specularColorMap?"#define USE_SPECULAR_COLORMAP":"",r.specularIntensityMap?"#define USE_SPECULAR_INTENSITYMAP":"",r.roughnessMap?"#define USE_ROUGHNESSMAP":"",r.metalnessMap?"#define USE_METALNESSMAP":"",r.alphaMap?"#define USE_ALPHAMAP":"",r.alphaTest?"#define USE_ALPHATEST":"",r.alphaHash?"#define USE_ALPHAHASH":"",r.sheen?"#define USE_SHEEN":"",r.sheenColorMap?"#define USE_SHEEN_COLORMAP":"",r.sheenRoughnessMap?"#define USE_SHEEN_ROUGHNESSMAP":"",r.transmission?"#define USE_TRANSMISSION":"",r.transmissionMap?"#define USE_TRANSMISSIONMAP":"",r.thicknessMap?"#define USE_THICKNESSMAP":"",r.vertexTangents&&!1===r.flatShading?"#define USE_TANGENT":"",r.vertexColors||r.instancingColor?"#define USE_COLOR":"",r.vertexAlphas||r.batchingColor?"#define USE_COLOR_ALPHA":"",r.vertexUv1s?"#define USE_UV1":"",r.vertexUv2s?"#define USE_UV2":"",r.vertexUv3s?"#define USE_UV3":"",r.pointsUvs?"#define USE_POINTS_UV":"",r.gradientMap?"#define USE_GRADIENTMAP":"",r.flatShading?"#define FLAT_SHADED":"",r.doubleSided?"#define DOUBLE_SIDED":"",r.flipSided?"#define FLIP_SIDED":"",r.shadowMapEnabled?"#define USE_SHADOWMAP":"",r.shadowMapEnabled?"#define "+h:"",r.premultipliedAlpha?"#define PREMULTIPLIED_ALPHA":"",r.numLightProbes>0?"#define USE_LIGHT_PROBES":"",r.numLightProbeGrids>0?"#define USE_LIGHT_PROBES_GRID":"",r.decodeVideoTexture?"#define DECODE_VIDEO_TEXTURE":"",r.decodeVideoTextureEmissive?"#define DECODE_VIDEO_TEXTURE_EMISSIVE":"",r.logarithmicDepthBuffer?"#define USE_LOGARITHMIC_DEPTH_BUFFER":"",r.reversedDepthBuffer?"#define USE_REVERSED_DEPTH_BUFFER":"","uniform mat4 viewMatrix;","uniform vec3 cameraPosition;","uniform bool isOrthographic;",r.toneMapping!==n.NoToneMapping?"#define TONE_MAPPING":"",r.toneMapping!==n.NoToneMapping?i.tonemapping_pars_fragment:"",r.toneMapping!==n.NoToneMapping?(o="toneMapping",void 0===(e=eK[l=r.toneMapping])?((0,n.warn)("WebGLProgram: Unsupported toneMapping:",l),"vec3 "+o+"( vec3 color ) { return LinearToneMapping( color ); }"):"vec3 "+o+"( vec3 color ) { return "+e+"ToneMapping( color ); }"):"",r.dithering?"#define DITHERING":"",r.opaque?"#define OPAQUE":"",i.colorspace_pars_fragment,(t=function(e){
        n.ColorManagement._getMatrix(eX,n.ColorManagement.workingColorSpace,e);
        let t=`mat3( ${eX.elements.map(e=>e.toFixed(4))} )`;
        switch(n.ColorManagement.getTransfer(e)){case n.LinearTransfer:
        return[t,"LinearTransferOETF"];
        case n.SRGBTransfer:
        return[t,"sRGBTransferOETF"];
        default:
        return(0,n.warn)("WebGLProgram: Unsupported color space: ",e),[t,"LinearTransferOETF"]
        }
        }(r.outputColorSpace),`vec4 linearToOutputTexel( vec4 value ) {
	return ${t[1]}( vec4( value.rgb * ${t[0]}, value.a ) );
}`),(n.ColorManagement.getLuminanceCoefficients(eY),a=eY.x.toFixed(4),d=eY.y.toFixed(4),u=eY.z.toFixed(4),`float luminance( const in vec3 rgb ) {
	const vec3 weights = vec3( ${a}, ${d}, ${u} );
	return dot( weights, rgb );
}`),r.useDepthPacking?"#define DEPTH_PACKING "+r.depthPacking:"","\n"].filter(ej).join("\n")
      }
    m=e$(m=eZ(m=eJ(m),r),r),_=e$(_=eZ(_=eJ(_),r),r),m=e2(m),_=e2(_),!0!==r.isRawShaderMaterial&&(R="#version 300 es\n",s=[T,"#define attribute in\n#define varying out\n#define texture2D texture"].join("\n")+"\n"+s,c=["#define varying in",r.glslVersion===n.GLSL3?"":"layout(location = 0) out highp vec4 pc_fragColor;",r.glslVersion===n.GLSL3?"":"#define gl_FragColor pc_fragColor","#define gl_FragDepthEXT gl_FragDepth\n#define texture2D texture\n#define textureCube texture\n#define texture2DProj textureProj\n#define texture2DLodEXT textureLod\n#define texture2DProjLodEXT textureProjLod\n#define textureCubeLodEXT textureLod\n#define texture2DGradEXT textureGrad\n#define texture2DProjGradEXT textureProjGrad\n#define textureCubeGradEXT textureGrad"].join("\n")+"\n"+c);
    let A=R+s+m,C=R+c+_,b=ez(f,f.VERTEX_SHADER,A),P=ez(f,f.FRAGMENT_SHADER,C);
    function L(t){
      if(e.debug.checkShaderErrors){
        let r=f.getProgramInfoLog(x)||"",i=f.getShaderInfoLog(b)||"",a=f.getShaderInfoLog(P)||"",o=r.trim(),l=i.trim(),d=a.trim(),u=!0,p=!0;
        if(!1===f.getProgramParameter(x,f.LINK_STATUS))
        if(u=!1,"function"==typeof e.debug.onShaderError)
        e.debug.onShaderError(f,x,b,P);
        else{
          let e=eq(f,b,"vertex"),r=eq(f,P,"fragment");
          (0,n.error)("THREE.WebGLProgram: Shader Error "+f.getError()+" - VALIDATE_STATUS "+f.getProgramParameter(x,f.VALIDATE_STATUS)+"\n\nMaterial Name: "+t.name+"\nMaterial Type: "+t.type+"\n\nProgram Info Log: "+o+"\n"+e+"\n"+r)
          }
        else
        ""!==o?(0,n.warn)("WebGLProgram: Program Info Log:",o):(""===l||""===d)&&(p=!1);
        p&&(t.diagnostics={runnable:u,programLog:o,vertexShader:{log:l,prefix:s},fragmentShader:{log:d,prefix:c}})
        }
      f.deleteShader(b),f.deleteShader(P),d=new eW(f,x),u=function(e,n){
        let t={},r=e.getProgramParameter(n,e.ACTIVE_ATTRIBUTES);
        for(
        let i=0
        ;i<r;i++){
          let r=e.getActiveAttrib(n,i),a=r.name,o=1;
          r.type===e.FLOAT_MAT2&&(o=2),r.type===e.FLOAT_MAT3&&(o=3),r.type===e.FLOAT_MAT4&&(o=4),t[a]={type:r.type,location:e.getAttribLocation(n,a),locationSize:o}
          }
        return t
        }(f,x)
      }
    f.attachShader(x,b),f.attachShader(x,P),void 0!==r.index0AttributeName?f.bindAttribLocation(x,0,r.index0AttributeName):!0===r.morphTargets&&f.bindAttribLocation(x,0,"position"),f.linkProgram(x),this.getUniforms=function(){
      return void 0===d&&L(this),d
      },this.getAttributes=function(){
      return void 0===u&&L(this),u
      };
    let U=!1===r.rendererExtensionParallelShaderCompile;
    return this.isReady=function(){
      return!1===U&&(U=f.getProgramParameter(x,37297)),U
      },this.destroy=function(){
      a.releaseStatesOfProgram(this),f.deleteProgram(x),this.program=void 0
      },this.type=r.shaderType,this.name=r.shaderName,this.id=ek++,this.cacheKey=t,this.usedTimes=1,this.program=x,this.vertexShader=b,this.fragmentShader=P,this
    }
  let nn=0;
  class nt{
    constructor(){
      this.shaderCache=new Map,this.materialCache=new Map
      }update(e){
      let n=e.vertexShader,t=e.fragmentShader,r=this._getShaderStage(n),i=this._getShaderStage(t),a=this._getShaderCacheForMaterial(e);
      return!1===a.has(r)&&(a.add(r),r.usedTimes++),!1===a.has(i)&&(a.add(i),i.usedTimes++),this
      }remove(e){
      for(
      let n
       of this.materialCache.get(e))
      n.usedTimes--,0===n.usedTimes&&this.shaderCache.delete(n.code);
      return this.materialCache.delete(e),this
      }getVertexShaderID(e){
      return this._getShaderStage(e.vertexShader).id
      }getFragmentShaderID(e){
      return this._getShaderStage(e.fragmentShader).id
      }dispose(){
      this.shaderCache.clear(),this.materialCache.clear()
      }_getShaderCacheForMaterial(e){
      let n=this.materialCache,t=n.get(e);
      return void 0===t&&(t=new Set,n.set(e,t)),t
      }_getShaderStage(e){
      let n=this.shaderCache,t=n.get(e);
      return void 0===t&&(t=new nr(e),n.set(e,t)),t
      }
  }
  class nr{
    constructor(e){
      this.id=nn++,this.code=e,this.usedTimes=0
      }
  }
  function ni(e,t,r,i,a,l){
    let s=new n.Layers,c=new nt,d=new Set,u=[],f=new Map,p=i.logarithmicDepthBuffer,m=i.precision,_={MeshDepthMaterial:"depth",MeshDistanceMaterial:"distance",MeshNormalMaterial:"normal",MeshBasicMaterial:"basic",MeshLambertMaterial:"lambert",MeshPhongMaterial:"phong",MeshToonMaterial:"toon",MeshStandardMaterial:"physical",MeshPhysicalMaterial:"physical",MeshMatcapMaterial:"matcap",LineBasicMaterial:"basic",LineDashedMaterial:"dashed",PointsMaterial:"points",ShadowMaterial:"shadow",SpriteMaterial:"sprite"};
    function h(e){
      return(d.add(e),0===e)?"uv":`uv${e}`
      }
    return{getParameters:function(a,s,u,f,g,v){
      var S;
      let E,T,M,x,R=f.fog,A=g.geometry,C=a.isMeshStandardMaterial||a.isMeshLambertMaterial||a.isMeshPhongMaterial?f.environment:null,b=a.isMeshStandardMaterial||a.isMeshLambertMaterial&&!a.envMap||a.isMeshPhongMaterial&&!a.envMap,P=t.get(a.envMap||C,b),L=P&&P.mapping===n.CubeUVReflectionMapping?P.image.height:null,U=_[a.type];
      null!==a.precision&&(m=i.getMaxPrecision(a.precision))!==a.precision&&(0,n.warn)("WebGLProgram.getParameters:",a.precision,"not supported, using",m,"instead.");
      let D=A.morphAttributes.position||A.morphAttributes.normal||A.morphAttributes.color,w=void 0!==D?D.length:0,N=0;
      if(void 0!==A.morphAttributes.position&&(N=1),void 0!==A.morphAttributes.normal&&(N=2),void 0!==A.morphAttributes.color&&(N=3),U){
        let e=o[U];
        E=e.vertexShader,T=e.fragmentShader
        }else 
      E=a.vertexShader,T=a.fragmentShader,c.update(a),M=c.getVertexShaderID(a),x=c.getFragmentShaderID(a);
      let I=e.getRenderTarget(),y=e.state.buffers.depth.getReversed(),F=!0===g.isInstancedMesh,O=!0===g.isBatchedMesh,B=!!a.map,G=!!a.matcap,H=!!P,V=!!a.aoMap,W=!!a.lightMap,z=!!a.bumpMap,k=!!a.normalMap,X=!!a.displacementMap,q=!!a.emissiveMap,K=!!a.metalnessMap,Y=!!a.roughnessMap,j=a.anisotropy>0,Z=a.clearcoat>0,$=a.dispersion>0,Q=a.iridescence>0,J=a.sheen>0,ee=a.transmission>0,en=j&&!!a.anisotropyMap,et=Z&&!!a.clearcoatMap,er=Z&&!!a.clearcoatNormalMap,ei=Z&&!!a.clearcoatRoughnessMap,ea=Q&&!!a.iridescenceMap,eo=Q&&!!a.iridescenceThicknessMap,el=J&&!!a.sheenColorMap,es=J&&!!a.sheenRoughnessMap,ec=!!a.specularMap,ed=!!a.specularColorMap,eu=!!a.specularIntensityMap,ef=ee&&!!a.transmissionMap,ep=ee&&!!a.thicknessMap,em=!!a.gradientMap,e_=!!a.alphaMap,eh=a.alphaTest>0,eg=!!a.alphaHash,ev=!!a.extensions,eS=n.NoToneMapping;
      a.toneMapped&&(null===I||!0===I.isXRRenderTarget)&&(eS=e.toneMapping);
      let eE={shaderID:U,shaderType:a.type,shaderName:a.name,vertexShader:E,fragmentShader:T,defines:a.defines,customVertexShaderID:M,customFragmentShaderID:x,isRawShaderMaterial:!0===a.isRawShaderMaterial,glslVersion:a.glslVersion,precision:m,batching:O,batchingColor:O&&null!==g._colorsTexture,instancing:F,instancingColor:F&&null!==g.instanceColor,instancingMorph:F&&null!==g.morphTexture,outputColorSpace:null===I?e.outputColorSpace:!0===I.isXRRenderTarget?I.texture.colorSpace:n.ColorManagement.workingColorSpace,alphaToCoverage:!!a.alphaToCoverage,map:B,matcap:G,envMap:H,envMapMode:H&&P.mapping,envMapCubeUVHeight:L,aoMap:V,lightMap:W,bumpMap:z,normalMap:k,displacementMap:X,emissiveMap:q,normalMapObjectSpace:k&&a.normalMapType===n.ObjectSpaceNormalMap,normalMapTangentSpace:k&&a.normalMapType===n.TangentSpaceNormalMap,packedNormalMap:k&&a.normalMapType===n.TangentSpaceNormalMap&&((S=a.normalMap.format)===n.RGFormat||S===n.RG11_EAC_Format||S===n.RED_GREEN_RGTC2_Format),metalnessMap:K,roughnessMap:Y,anisotropy:j,anisotropyMap:en,clearcoat:Z,clearcoatMap:et,clearcoatNormalMap:er,clearcoatRoughnessMap:ei,dispersion:$,iridescence:Q,iridescenceMap:ea,iridescenceThicknessMap:eo,sheen:J,sheenColorMap:el,sheenRoughnessMap:es,specularMap:ec,specularColorMap:ed,specularIntensityMap:eu,transmission:ee,transmissionMap:ef,thicknessMap:ep,gradientMap:em,opaque:!1===a.transparent&&a.blending===n.NormalBlending&&!1===a.alphaToCoverage,alphaMap:e_,alphaTest:eh,alphaHash:eg,combine:a.combine,mapUv:B&&h(a.map.channel),aoMapUv:V&&h(a.aoMap.channel),lightMapUv:W&&h(a.lightMap.channel),bumpMapUv:z&&h(a.bumpMap.channel),normalMapUv:k&&h(a.normalMap.channel),displacementMapUv:X&&h(a.displacementMap.channel),emissiveMapUv:q&&h(a.emissiveMap.channel),metalnessMapUv:K&&h(a.metalnessMap.channel),roughnessMapUv:Y&&h(a.roughnessMap.channel),anisotropyMapUv:en&&h(a.anisotropyMap.channel),clearcoatMapUv:et&&h(a.clearcoatMap.channel),clearcoatNormalMapUv:er&&h(a.clearcoatNormalMap.channel),clearcoatRoughnessMapUv:ei&&h(a.clearcoatRoughnessMap.channel),iridescenceMapUv:ea&&h(a.iridescenceMap.channel),iridescenceThicknessMapUv:eo&&h(a.iridescenceThicknessMap.channel),sheenColorMapUv:el&&h(a.sheenColorMap.channel),sheenRoughnessMapUv:es&&h(a.sheenRoughnessMap.channel),specularMapUv:ec&&h(a.specularMap.channel),specularColorMapUv:ed&&h(a.specularColorMap.channel),specularIntensityMapUv:eu&&h(a.specularIntensityMap.channel),transmissionMapUv:ef&&h(a.transmissionMap.channel),thicknessMapUv:ep&&h(a.thicknessMap.channel),alphaMapUv:e_&&h(a.alphaMap.channel),vertexTangents:!!A.attributes.tangent&&(k||j),vertexNormals:!!A.attributes.normal,vertexColors:a.vertexColors,vertexAlphas:!0===a.vertexColors&&!!A.attributes.color&&4===A.attributes.color.itemSize,pointsUvs:!0===g.isPoints&&!!A.attributes.uv&&(B||e_),fog:!!R,useFog:!0===a.fog,fogExp2:!!R&&R.isFogExp2,flatShading:!1===a.wireframe&&(!0===a.flatShading||void 0===A.attributes.normal&&!1===k&&(a.isMeshLambertMaterial||a.isMeshPhongMaterial||a.isMeshStandardMaterial||a.isMeshPhysicalMaterial)),sizeAttenuation:!0===a.sizeAttenuation,logarithmicDepthBuffer:p,reversedDepthBuffer:y,skinning:!0===g.isSkinnedMesh,morphTargets:void 0!==A.morphAttributes.position,morphNormals:void 0!==A.morphAttributes.normal,morphColors:void 0!==A.morphAttributes.color,morphTargetsCount:w,morphTextureStride:N,numDirLights:s.directional.length,numPointLights:s.point.length,numSpotLights:s.spot.length,numSpotLightMaps:s.spotLightMap.length,numRectAreaLights:s.rectArea.length,numHemiLights:s.hemi.length,numDirLightShadows:s.directionalShadowMap.length,numPointLightShadows:s.pointShadowMap.length,numSpotLightShadows:s.spotShadowMap.length,numSpotLightShadowsWithMaps:s.numSpotLightShadowsWithMaps,numLightProbes:s.numLightProbes,numLightProbeGrids:v.length,numClippingPlanes:l.numPlanes,numClipIntersection:l.numIntersection,dithering:a.dithering,shadowMapEnabled:e.shadowMap.enabled&&u.length>0,shadowMapType:e.shadowMap.type,toneMapping:eS,decodeVideoTexture:B&&!0===a.map.isVideoTexture&&n.ColorManagement.getTransfer(a.map.colorSpace)===n.SRGBTransfer,decodeVideoTextureEmissive:q&&!0===a.emissiveMap.isVideoTexture&&n.ColorManagement.getTransfer(a.emissiveMap.colorSpace)===n.SRGBTransfer,premultipliedAlpha:a.premultipliedAlpha,doubleSided:a.side===n.DoubleSide,flipSided:a.side===n.BackSide,useDepthPacking:a.depthPacking>=0,depthPacking:a.depthPacking||0,index0AttributeName:a.index0AttributeName,extensionClipCullDistance:ev&&!0===a.extensions.clipCullDistance&&r.has("WEBGL_clip_cull_distance"),extensionMultiDraw:(ev&&!0===a.extensions.multiDraw||O)&&r.has("WEBGL_multi_draw"),rendererExtensionParallelShaderCompile:r.has("KHR_parallel_shader_compile"),customProgramCacheKey:a.customProgramCacheKey()};
      return eE.vertexUv1s=d.has(1),eE.vertexUv2s=d.has(2),eE.vertexUv3s=d.has(3),d.clear(),eE
      },getProgramCacheKey:function(n){
      var t,r,i,a;
      let o=[];
      if(n.shaderID?o.push(n.shaderID):(o.push(n.customVertexShaderID),o.push(n.customFragmentShaderID)),void 0!==n.defines)
      for(
      let e
       in n.defines)
      o.push(e),o.push(n.defines[e]);
      return!1===n.isRawShaderMaterial&&(t=o,r=n,t.push(r.precision),t.push(r.outputColorSpace),t.push(r.envMapMode),t.push(r.envMapCubeUVHeight),t.push(r.mapUv),t.push(r.alphaMapUv),t.push(r.lightMapUv),t.push(r.aoMapUv),t.push(r.bumpMapUv),t.push(r.normalMapUv),t.push(r.displacementMapUv),t.push(r.emissiveMapUv),t.push(r.metalnessMapUv),t.push(r.roughnessMapUv),t.push(r.anisotropyMapUv),t.push(r.clearcoatMapUv),t.push(r.clearcoatNormalMapUv),t.push(r.clearcoatRoughnessMapUv),t.push(r.iridescenceMapUv),t.push(r.iridescenceThicknessMapUv),t.push(r.sheenColorMapUv),t.push(r.sheenRoughnessMapUv),t.push(r.specularMapUv),t.push(r.specularColorMapUv),t.push(r.specularIntensityMapUv),t.push(r.transmissionMapUv),t.push(r.thicknessMapUv),t.push(r.combine),t.push(r.fogExp2),t.push(r.sizeAttenuation),t.push(r.morphTargetsCount),t.push(r.morphAttributeCount),t.push(r.numDirLights),t.push(r.numPointLights),t.push(r.numSpotLights),t.push(r.numSpotLightMaps),t.push(r.numHemiLights),t.push(r.numRectAreaLights),t.push(r.numDirLightShadows),t.push(r.numPointLightShadows),t.push(r.numSpotLightShadows),t.push(r.numSpotLightShadowsWithMaps),t.push(r.numLightProbes),t.push(r.shadowMapType),t.push(r.toneMapping),t.push(r.numClippingPlanes),t.push(r.numClipIntersection),t.push(r.depthPacking),i=o,a=n,s.disableAll(),a.instancing&&s.enable(0),a.instancingColor&&s.enable(1),a.instancingMorph&&s.enable(2),a.matcap&&s.enable(3),a.envMap&&s.enable(4),a.normalMapObjectSpace&&s.enable(5),a.normalMapTangentSpace&&s.enable(6),a.clearcoat&&s.enable(7),a.iridescence&&s.enable(8),a.alphaTest&&s.enable(9),a.vertexColors&&s.enable(10),a.vertexAlphas&&s.enable(11),a.vertexUv1s&&s.enable(12),a.vertexUv2s&&s.enable(13),a.vertexUv3s&&s.enable(14),a.vertexTangents&&s.enable(15),a.anisotropy&&s.enable(16),a.alphaHash&&s.enable(17),a.batching&&s.enable(18),a.dispersion&&s.enable(19),a.batchingColor&&s.enable(20),a.gradientMap&&s.enable(21),a.packedNormalMap&&s.enable(22),a.vertexNormals&&s.enable(23),i.push(s.mask),s.disableAll(),a.fog&&s.enable(0),a.useFog&&s.enable(1),a.flatShading&&s.enable(2),a.logarithmicDepthBuffer&&s.enable(3),a.reversedDepthBuffer&&s.enable(4),a.skinning&&s.enable(5),a.morphTargets&&s.enable(6),a.morphNormals&&s.enable(7),a.morphColors&&s.enable(8),a.premultipliedAlpha&&s.enable(9),a.shadowMapEnabled&&s.enable(10),a.doubleSided&&s.enable(11),a.flipSided&&s.enable(12),a.useDepthPacking&&s.enable(13),a.dithering&&s.enable(14),a.transmission&&s.enable(15),a.sheen&&s.enable(16),a.opaque&&s.enable(17),a.pointsUvs&&s.enable(18),a.decodeVideoTexture&&s.enable(19),a.decodeVideoTextureEmissive&&s.enable(20),a.alphaToCoverage&&s.enable(21),a.numLightProbeGrids>0&&s.enable(22),i.push(s.mask),o.push(e.outputColorSpace)),o.push(n.customProgramCacheKey),o.join()
      },getUniforms:function(e){
      let t,r=_[e.type];
      if(r){
        let e=o[r];
        t=n.UniformsUtils.clone(e.uniforms)
        }else 
      t=e.uniforms;
      return t
      },acquireProgram:function(n,t){
      let r=f.get(t);
      return void 0!==r?++r.usedTimes:(r=new ne(e,t,n,a),u.push(r),f.set(t,r)),r
      },releaseProgram:function(e){
      if(0==--e.usedTimes){
        let n=u.indexOf(e);
        u[n]=u[u.length-1],u.pop(),f.delete(e.cacheKey),e.destroy()
        }
      },releaseShaderCache:function(e){
      c.remove(e)
      },programs:u,dispose:function(){
      c.dispose()
      }}
    }
  function na(){
    let e=new WeakMap;
    return{has:function(n){
      return e.has(n)
      },get:function(n){
      let t=e.get(n);
      return void 0===t&&(t={},e.set(n,t)),t
      },remove:function(n){
      e.delete(n)
      },update:function(n,t,r){
      e.get(n)[t]=r
      },dispose:function(){
      e=new WeakMap
      }}
    }
  function no(e,n){
    if(e.groupOrder!==n.groupOrder)
    return e.groupOrder-n.groupOrder;
    if(e.renderOrder!==n.renderOrder)
    return e.renderOrder-n.renderOrder;
    if(e.material.id!==n.material.id)
    return e.material.id-n.material.id;
    if(e.materialVariant!==n.materialVariant)
    return e.materialVariant-n.materialVariant;
    if(e.z!==n.z)
    return e.z-n.z;
    else 
    return e.id-n.id
    }
  function nl(e,n){
    return e.groupOrder!==n.groupOrder?e.groupOrder-n.groupOrder:e.renderOrder!==n.renderOrder?e.renderOrder-n.renderOrder:e.z!==n.z?n.z-e.z:e.id-n.id
    }
  function ns(){
    let e=[],n=0,t=[],r=[],i=[];
    function a(e){
      let n=0;
      return e.isInstancedMesh&&(n+=2),e.isSkinnedMesh&&(n+=1),n
      }
    function o(t,r,i,o,l,s){
      let c=e[n];
      return void 0===c?(c={id:t.id,object:t,geometry:r,material:i,materialVariant:a(t),groupOrder:o,renderOrder:t.renderOrder,z:l,group:s},e[n]=c):(c.id=t.id,c.object=t,c.geometry=r,c.material=i,c.materialVariant=a(t),c.groupOrder=o,c.renderOrder=t.renderOrder,c.z=l,c.group=s),n++,c
      }
    return{opaque:t,transmissive:r,transparent:i,init:function(){
      n=0,t.length=0,r.length=0,i.length=0
      },push:function(e,n,a,l,s,c){
      let d=o(e,n,a,l,s,c);
      a.transmission>0?r.push(d):!0===a.transparent?i.push(d):t.push(d)
      },unshift:function(e,n,a,l,s,c){
      let d=o(e,n,a,l,s,c);
      a.transmission>0?r.unshift(d):!0===a.transparent?i.unshift(d):t.unshift(d)
      },finish:function(){
      for(
      let t=n,r=e.length
      ;t<r;t++){
        let n=e[t];
        if(null===n.id)
        break;
        n.id=null,n.object=null,n.geometry=null,n.material=null,n.group=null
        }
      },sort:function(e,n){
      t.length>1&&t.sort(e||no),r.length>1&&r.sort(n||nl),i.length>1&&i.sort(n||nl)
      }}
    }
  function nc(){
    let e=new WeakMap;
    return{get:function(n,t){
      let r,i=e.get(n);
      return void 0===i?(r=new ns,e.set(n,[r])):t>=i.length?(r=new ns,i.push(r)):r=i[t],r
      },dispose:function(){
      e=new WeakMap
      }}
    }
  function nd(){
    let e={};
    return{get:function(t){
      let r;
      if(void 0!==e[t.id])
      return e[t.id];
      switch(t.type){case"DirectionalLight":
      r={direction:new n.Vector3,color:new n.Color};
      break;
      case"SpotLight":
      r={position:new n.Vector3,direction:new n.Vector3,color:new n.Color,distance:0,coneCos:0,penumbraCos:0,decay:0};
      break;
      case"PointLight":
      r={position:new n.Vector3,color:new n.Color,distance:0,decay:0};
      break;
      case"HemisphereLight":
      r={direction:new n.Vector3,skyColor:new n.Color,groundColor:new n.Color};
      break;
      case"RectAreaLight":
      r={color:new n.Color,position:new n.Vector3,halfWidth:new n.Vector3,halfHeight:new n.Vector3}
      }
      return e[t.id]=r,r
      }}
    }
  let nu=0;
  function nf(e,n){
    return 2*!!n.castShadow-2*!!e.castShadow+ +!!n.map-!!e.map
    }
  function np(e){
    let t,r=new nd,i=(t={},{get:function(e){
      let r;
      if(void 0!==t[e.id])
      return t[e.id];
      switch(e.type){case"DirectionalLight":case"SpotLight":
      r={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new n.Vector2};
      break;
      case"PointLight":
      r={shadowIntensity:1,shadowBias:0,shadowNormalBias:0,shadowRadius:1,shadowMapSize:new n.Vector2,shadowCameraNear:1,shadowCameraFar:1e3}
      }
      return t[e.id]=r,r
      }}),o={version:0,hash:{directionalLength:-1,pointLength:-1,spotLength:-1,rectAreaLength:-1,hemiLength:-1,numDirectionalShadows:-1,numPointShadows:-1,numSpotShadows:-1,numSpotMaps:-1,numLightProbes:-1},ambient:[0,0,0],probe:[],directional:[],directionalShadow:[],directionalShadowMap:[],directionalShadowMatrix:[],spot:[],spotLightMap:[],spotShadow:[],spotShadowMap:[],spotLightMatrix:[],rectArea:[],rectAreaLTC1:null,rectAreaLTC2:null,point:[],pointShadow:[],pointShadowMap:[],pointShadowMatrix:[],hemi:[],numSpotLightShadowsWithMaps:0,numLightProbes:0};
    for(
    let e=0
    ;e<9;e++)
    o.probe.push(new n.Vector3);
    let l=new n.Vector3,s=new n.Matrix4,c=new n.Matrix4;
    return{setup:function(t){
      let l=0,s=0,c=0;
      for(
      let e=0
      ;e<9;e++)
      o.probe[e].set(0,0,0);
      let d=0,u=0,f=0,p=0,m=0,_=0,h=0,g=0,v=0,S=0,E=0;
      t.sort(nf);
      for(
      let e=0,a=t.length
      ;e<a;e++){
        let a=t[e],T=a.color,M=a.intensity,x=a.distance,R=null;
        if(a.shadow&&a.shadow.map&&(R=a.shadow.map.texture.format===n.RGFormat?a.shadow.map.texture:a.shadow.map.depthTexture||a.shadow.map.texture),a.isAmbientLight)
        l+=T.r*M,s+=T.g*M,c+=T.b*M;
        else 
        if(a.isLightProbe){
          for(
          let e=0
          ;e<9;e++)
          o.probe[e].addScaledVector(a.sh.coefficients[e],M);
          E++
          }else 
        if(a.isDirectionalLight){
          let e=r.get(a);
          if(e.color.copy(a.color).multiplyScalar(a.intensity),a.castShadow){
            let e=a.shadow,n=i.get(a);
            n.shadowIntensity=e.intensity,n.shadowBias=e.bias,n.shadowNormalBias=e.normalBias,n.shadowRadius=e.radius,n.shadowMapSize=e.mapSize,o.directionalShadow[d]=n,o.directionalShadowMap[d]=R,o.directionalShadowMatrix[d]=a.shadow.matrix,_++
            }
          o.directional[d]=e,d++
          }else 
        if(a.isSpotLight){
          let e=r.get(a);
          e.position.setFromMatrixPosition(a.matrixWorld),e.color.copy(T).multiplyScalar(M),e.distance=x,e.coneCos=Math.cos(a.angle),e.penumbraCos=Math.cos(a.angle*(1-a.penumbra)),e.decay=a.decay,o.spot[f]=e;
          let n=a.shadow;
          if(a.map&&(o.spotLightMap[v]=a.map,v++,n.updateMatrices(a),a.castShadow&&S++),o.spotLightMatrix[f]=n.matrix,a.castShadow){
            let e=i.get(a);
            e.shadowIntensity=n.intensity,e.shadowBias=n.bias,e.shadowNormalBias=n.normalBias,e.shadowRadius=n.radius,e.shadowMapSize=n.mapSize,o.spotShadow[f]=e,o.spotShadowMap[f]=R,g++
            }
          f++
          }else 
        if(a.isRectAreaLight){
          let e=r.get(a);
          e.color.copy(T).multiplyScalar(M),e.halfWidth.set(.5*a.width,0,0),e.halfHeight.set(0,.5*a.height,0),o.rectArea[p]=e,p++
          }else 
        if(a.isPointLight){
          let e=r.get(a);
          if(e.color.copy(a.color).multiplyScalar(a.intensity),e.distance=a.distance,e.decay=a.decay,a.castShadow){
            let e=a.shadow,n=i.get(a);
            n.shadowIntensity=e.intensity,n.shadowBias=e.bias,n.shadowNormalBias=e.normalBias,n.shadowRadius=e.radius,n.shadowMapSize=e.mapSize,n.shadowCameraNear=e.camera.near,n.shadowCameraFar=e.camera.far,o.pointShadow[u]=n,o.pointShadowMap[u]=R,o.pointShadowMatrix[u]=a.shadow.matrix,h++
            }
          o.point[u]=e,u++
          }else 
        if(a.isHemisphereLight){
          let e=r.get(a);
          e.skyColor.copy(a.color).multiplyScalar(M),e.groundColor.copy(a.groundColor).multiplyScalar(M),o.hemi[m]=e,m++
          }
        }
      p>0&&(!0===e.has("OES_texture_float_linear")?(o.rectAreaLTC1=a.LTC_FLOAT_1,o.rectAreaLTC2=a.LTC_FLOAT_2):(o.rectAreaLTC1=a.LTC_HALF_1,o.rectAreaLTC2=a.LTC_HALF_2)),o.ambient[0]=l,o.ambient[1]=s,o.ambient[2]=c;
      let T=o.hash;
      (T.directionalLength!==d||T.pointLength!==u||T.spotLength!==f||T.rectAreaLength!==p||T.hemiLength!==m||T.numDirectionalShadows!==_||T.numPointShadows!==h||T.numSpotShadows!==g||T.numSpotMaps!==v||T.numLightProbes!==E)&&(o.directional.length=d,o.spot.length=f,o.rectArea.length=p,o.point.length=u,o.hemi.length=m,o.directionalShadow.length=_,o.directionalShadowMap.length=_,o.pointShadow.length=h,o.pointShadowMap.length=h,o.spotShadow.length=g,o.spotShadowMap.length=g,o.directionalShadowMatrix.length=_,o.pointShadowMatrix.length=h,o.spotLightMatrix.length=g+v-S,o.spotLightMap.length=v,o.numSpotLightShadowsWithMaps=S,o.numLightProbes=E,T.directionalLength=d,T.pointLength=u,T.spotLength=f,T.rectAreaLength=p,T.hemiLength=m,T.numDirectionalShadows=_,T.numPointShadows=h,T.numSpotShadows=g,T.numSpotMaps=v,T.numLightProbes=E,o.version=nu++)
      },setupView:function(e,n){
      let t=0,r=0,i=0,a=0,d=0,u=n.matrixWorldInverse;
      for(
      let n=0,f=e.length
      ;n<f;n++){
        let f=e[n];
        if(f.isDirectionalLight){
          let e=o.directional[t];
          e.direction.setFromMatrixPosition(f.matrixWorld),l.setFromMatrixPosition(f.target.matrixWorld),e.direction.sub(l),e.direction.transformDirection(u),t++
          }else 
        if(f.isSpotLight){
          let e=o.spot[i];
          e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(u),e.direction.setFromMatrixPosition(f.matrixWorld),l.setFromMatrixPosition(f.target.matrixWorld),e.direction.sub(l),e.direction.transformDirection(u),i++
          }else 
        if(f.isRectAreaLight){
          let e=o.rectArea[a];
          e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(u),c.identity(),s.copy(f.matrixWorld),s.premultiply(u),c.extractRotation(s),e.halfWidth.set(.5*f.width,0,0),e.halfHeight.set(0,.5*f.height,0),e.halfWidth.applyMatrix4(c),e.halfHeight.applyMatrix4(c),a++
          }else 
        if(f.isPointLight){
          let e=o.point[r];
          e.position.setFromMatrixPosition(f.matrixWorld),e.position.applyMatrix4(u),r++
          }else 
        if(f.isHemisphereLight){
          let e=o.hemi[d];
          e.direction.setFromMatrixPosition(f.matrixWorld),e.direction.transformDirection(u),d++
          }
        }
      },state:o}
    }
  function nm(e){
    let n=new np(e),t=[],r=[],i=[],a={lightsArray:t,shadowsArray:r,lightProbeGridArray:i,camera:null,lights:n,transmissionRenderTarget:{},textureUnits:0};
    return{init:function(e){
      a.camera=e,t.length=0,r.length=0,i.length=0
      },state:a,setupLights:function(){
      n.setup(t)
      },setupLightsView:function(e){
      n.setupView(t,e)
      },pushLight:function(e){
      t.push(e)
      },pushShadow:function(e){
      r.push(e)
      },pushLightProbeGrid:function(e){
      i.push(e)
      }}
    }
  function n_(e){
    let n=new WeakMap;
    return{get:function(t,r=0){
      let i,a=n.get(t);
      return void 0===a?(i=new nm(e),n.set(t,[i])):r>=a.length?(i=new nm(e),a.push(i)):i=a[r],i
      },dispose:function(){
      n=new WeakMap
      }}
    }
  let nh=[new n.Vector3(1,0,0),new n.Vector3(-1,0,0),new n.Vector3(0,1,0),new n.Vector3(0,-1,0),new n.Vector3(0,0,1),new n.Vector3(0,0,-1)],ng=[new n.Vector3(0,-1,0),new n.Vector3(0,-1,0),new n.Vector3(0,0,1),new n.Vector3(0,0,-1),new n.Vector3(0,-1,0),new n.Vector3(0,-1,0)],nv=new n.Matrix4,nS=new n.Vector3,nE=new n.Vector3;
  function nT(e,t,r){
    let i=new n.Frustum,a=new n.Vector2,o=new n.Vector2,l=new n.Vector4,s=new n.MeshDepthMaterial,c=new n.MeshDistanceMaterial,d={},u=r.maxTextureSize,f={[n.FrontSide]:n.BackSide,[n.BackSide]:n.FrontSide,[n.DoubleSide]:n.DoubleSide},p=new n.ShaderMaterial({defines:{VSM_SAMPLES:8},uniforms:{shadow_pass:{value:null},resolution:{value:new n.Vector2},radius:{value:4}},vertexShader:"void main() {\n	gl_Position = vec4( position, 1.0 );\n}",fragmentShader:"uniform sampler2D shadow_pass;\nuniform vec2 resolution;\nuniform float radius;\nvoid main() {\n	const float samples = float( VSM_SAMPLES );\n	float mean = 0.0;\n	float squared_mean = 0.0;\n	float uvStride = samples <= 1.0 ? 0.0 : 2.0 / ( samples - 1.0 );\n	float uvStart = samples <= 1.0 ? 0.0 : - 1.0;\n	for ( float i = 0.0; i < samples; i ++ ) {\n		float uvOffset = uvStart + i * uvStride;\n		#ifdef HORIZONTAL_PASS\n			vec2 distribution = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( uvOffset, 0.0 ) * radius ) / resolution ).rg;\n			mean += distribution.x;\n			squared_mean += distribution.y * distribution.y + distribution.x * distribution.x;\n		#else\n			float depth = texture2D( shadow_pass, ( gl_FragCoord.xy + vec2( 0.0, uvOffset ) * radius ) / resolution ).r;\n			mean += depth;\n			squared_mean += depth * depth;\n		#endif\n	}\n	mean = mean / samples;\n	squared_mean = squared_mean / samples;\n	float std_dev = sqrt( max( 0.0, squared_mean - mean * mean ) );\n	gl_FragColor = vec4( mean, std_dev, 0.0, 1.0 );\n}"}),m=p.clone();
    m.defines.HORIZONTAL_PASS=1;
    let _=new n.BufferGeometry;
    _.setAttribute("position",new n.BufferAttribute(new Float32Array([-1,-1,.5,3,-1,.5,-1,3,.5]),3));
    let h=new n.Mesh(_,p),g=this;
    this.enabled=!1,this.autoUpdate=!0,this.needsUpdate=!1,this.type=n.PCFShadowMap;
    let v=this.type;
    function S(t,r,i,a){
      let o=null,l=!0===i.isPointLight?t.customDistanceMaterial:t.customDepthMaterial;
      if(void 0!==l)
      o=l;
      else 
      if(o=!0===i.isPointLight?c:s,e.localClippingEnabled&&!0===r.clipShadows&&Array.isArray(r.clippingPlanes)&&0!==r.clippingPlanes.length||r.displacementMap&&0!==r.displacementScale||r.alphaMap&&r.alphaTest>0||r.map&&r.alphaTest>0||!0===r.alphaToCoverage){
        let e=o.uuid,n=r.uuid,t=d[e];
        void 0===t&&(t={},d[e]=t);
        let i=t[n];
        void 0===i&&(i=o.clone(),t[n]=i,r.addEventListener("dispose",E)),o=i
        }
      return o.visible=r.visible,o.wireframe=r.wireframe,a===n.VSMShadowMap?o.side=null!==r.shadowSide?r.shadowSide:r.side:o.side=null!==r.shadowSide?r.shadowSide:f[r.side],o.alphaMap=r.alphaMap,o.alphaTest=!0===r.alphaToCoverage?.5:r.alphaTest,o.map=r.map,o.clipShadows=r.clipShadows,o.clippingPlanes=r.clippingPlanes,o.clipIntersection=r.clipIntersection,o.displacementMap=r.displacementMap,o.displacementScale=r.displacementScale,o.displacementBias=r.displacementBias,o.wireframeLinewidth=r.wireframeLinewidth,o.linewidth=r.linewidth,!0===i.isPointLight&&!0===o.isMeshDistanceMaterial&&(e.properties.get(o).light=i),o
      }
    function E(e){
      for(
      let n
       in e.target.removeEventListener("dispose",E),d){
        let t=d[n],r=e.target.uuid;
        r in t&&(t[r].dispose(),delete t[r])
        }
      }
    this.render=function(r,s,c){
      if(!1===g.enabled||!1===g.autoUpdate&&!1===g.needsUpdate||0===r.length)
      return;
      this.type===n.PCFSoftShadowMap&&((0,n.warn)("WebGLShadowMap: PCFSoftShadowMap has been deprecated. Using PCFShadowMap instead."),this.type=n.PCFShadowMap);
      let d=e.getRenderTarget(),f=e.getActiveCubeFace(),_=e.getActiveMipmapLevel(),E=e.state;
      E.setBlending(n.NoBlending),!0===E.buffers.depth.getReversed()?E.buffers.color.setClear(0,0,0,0):E.buffers.color.setClear(1,1,1,1),E.buffers.depth.setTest(!0),E.setScissorTest(!1);
      let T=v!==this.type;
      T&&s.traverse(function(e){
        e.material&&(Array.isArray(e.material)?e.material.forEach(e=>e.needsUpdate=!0):e.material.needsUpdate=!0)
        });
      for(
      let d=0,f=r.length
      ;d<f;d++){
        let f=r[d],_=f.shadow;
        if(void 0===_){
          (0,n.warn)("WebGLShadowMap:",f,"has no shadow.");
          continue
          }
        if(!1===_.autoUpdate&&!1===_.needsUpdate)
        continue;
        a.copy(_.mapSize);
        let g=_.getFrameExtents();
        a.multiply(g),o.copy(_.mapSize),(a.x>u||a.y>u)&&(a.x>u&&(o.x=Math.floor(u/g.x),a.x=o.x*g.x,_.mapSize.x=o.x),a.y>u&&(o.y=Math.floor(u/g.y),a.y=o.y*g.y,_.mapSize.y=o.y));
        let v=e.state.buffers.depth.getReversed();
        if(_.camera._reversedDepth=v,null===_.map||!0===T){
          if(null!==_.map&&(null!==_.map.depthTexture&&(_.map.depthTexture.dispose(),_.map.depthTexture=null),_.map.dispose()),this.type===n.VSMShadowMap){
            if(f.isPointLight){
              (0,n.warn)("WebGLShadowMap: VSM shadow maps are not supported for PointLights. Use PCF or BasicShadowMap instead.");
              continue
              }
            _.map=new n.WebGLRenderTarget(a.x,a.y,{format:n.RGFormat,type:n.HalfFloatType,minFilter:n.LinearFilter,magFilter:n.LinearFilter,generateMipmaps:!1}),_.map.texture.name=f.name+".shadowMap",_.map.depthTexture=new n.DepthTexture(a.x,a.y,n.FloatType),_.map.depthTexture.name=f.name+".shadowMapDepth",_.map.depthTexture.format=n.DepthFormat,_.map.depthTexture.compareFunction=null,_.map.depthTexture.minFilter=n.NearestFilter,_.map.depthTexture.magFilter=n.NearestFilter
            }else 
          f.isPointLight?(_.map=new L(a.x),_.map.depthTexture=new n.CubeDepthTexture(a.x,n.UnsignedIntType)):(_.map=new n.WebGLRenderTarget(a.x,a.y),_.map.depthTexture=new n.DepthTexture(a.x,a.y,n.UnsignedIntType)),_.map.depthTexture.name=f.name+".shadowMap",_.map.depthTexture.format=n.DepthFormat,this.type===n.PCFShadowMap?(_.map.depthTexture.compareFunction=v?n.GreaterEqualCompare:n.LessEqualCompare,_.map.depthTexture.minFilter=n.LinearFilter,_.map.depthTexture.magFilter=n.LinearFilter):(_.map.depthTexture.compareFunction=null,_.map.depthTexture.minFilter=n.NearestFilter,_.map.depthTexture.magFilter=n.NearestFilter);
          _.camera.updateProjectionMatrix()
          }
        let M=_.map.isWebGLCubeRenderTarget?6:1;
        for(
        let r=0
        ;r<M;r++){
          if(_.map.isWebGLCubeRenderTarget)
          e.setRenderTarget(_.map,r),e.clear();
          else{
            0===r&&(e.setRenderTarget(_.map),e.clear());
            let n=_.getViewport(r);
            l.set(o.x*n.x,o.y*n.y,o.x*n.z,o.y*n.w),E.viewport(l)
            }
          if(f.isPointLight){
            let e=_.camera,n=_.matrix,t=f.distance||e.far;
            t!==e.far&&(e.far=t,e.updateProjectionMatrix()),nS.setFromMatrixPosition(f.matrixWorld),e.position.copy(nS),nE.copy(e.position),nE.add(nh[r]),e.up.copy(ng[r]),e.lookAt(nE),e.updateMatrixWorld(),n.makeTranslation(-nS.x,-nS.y,-nS.z),nv.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),_._frustum.setFromProjectionMatrix(nv,e.coordinateSystem,e.reversedDepth)
            }else 
          _.updateMatrices(f);
          i=_.getFrustum(),function r(a,o,l,s,c){
            if(!1===a.visible)
            return;
            if(a.layers.test(o.layers)&&(a.isMesh||a.isLine||a.isPoints)&&(a.castShadow||a.receiveShadow&&c===n.VSMShadowMap)&&(!a.frustumCulled||i.intersectsObject(a))){
              a.modelViewMatrix.multiplyMatrices(l.matrixWorldInverse,a.matrixWorld);
              let n=t.update(a),r=a.material;
              if(Array.isArray(r)){
                let t=n.groups;
                for(
                let i=0,d=t.length
                ;i<d;i++){
                  let d=t[i],u=r[d.materialIndex];
                  if(u&&u.visible){
                    let t=S(a,u,s,c);
                    a.onBeforeShadow(e,a,o,l,n,t,d),e.renderBufferDirect(l,null,n,t,a,d),a.onAfterShadow(e,a,o,l,n,t,d)
                    }
                  }
                }else 
              if(r.visible){
                let t=S(a,r,s,c);
                a.onBeforeShadow(e,a,o,l,n,t,null),e.renderBufferDirect(l,null,n,t,a,null),a.onAfterShadow(e,a,o,l,n,t,null)
                }
              }
            let d=a.children;
            for(
            let e=0,n=d.length
            ;e<n;e++)
            r(d[e],o,l,s,c)
            }(s,c,_.camera,f,this.type)
          }
        !0!==_.isPointLightShadow&&this.type===n.VSMShadowMap&&function(r,i){
          let o=t.update(h);
          p.defines.VSM_SAMPLES!==r.blurSamples&&(p.defines.VSM_SAMPLES=r.blurSamples,m.defines.VSM_SAMPLES=r.blurSamples,p.needsUpdate=!0,m.needsUpdate=!0),null===r.mapPass&&(r.mapPass=new n.WebGLRenderTarget(a.x,a.y,{format:n.RGFormat,type:n.HalfFloatType})),p.uniforms.shadow_pass.value=r.map.depthTexture,p.uniforms.resolution.value=r.mapSize,p.uniforms.radius.value=r.radius,e.setRenderTarget(r.mapPass),e.clear(),e.renderBufferDirect(i,null,o,p,h,null),m.uniforms.shadow_pass.value=r.mapPass.texture,m.uniforms.resolution.value=r.mapSize,m.uniforms.radius.value=r.radius,e.setRenderTarget(r.map),e.clear(),e.renderBufferDirect(i,null,o,m,h,null)
          }(_,c),_.needsUpdate=!1
        }
      v=this.type,g.needsUpdate=!1,e.setRenderTarget(d,f,_)
      }
    }
  function nM(e,t){
    let r=new function(){
      let t=!1,r=new n.Vector4,i=null,a=new n.Vector4(0,0,0,0);
      return{setMask:function(n){
        i===n||t||(e.colorMask(n,n,n,n),i=n)
        },setLocked:function(e){
        t=e
        },setClear:function(n,t,i,o,l){
        !0===l&&(n*=o,t*=o,i*=o),r.set(n,t,i,o),!1===a.equals(r)&&(e.clearColor(n,t,i,o),a.copy(r))
        },reset:function(){
        t=!1,i=null,a.set(-1,0,0,0)
        }}
      },i=new function(){
      let r=!1,i=!1,a=null,o=null,l=null;
      return{setReversed:function(e){
        if(i!==e){
          let n=t.get("EXT_clip_control");
          e?n.clipControlEXT(n.LOWER_LEFT_EXT,n.ZERO_TO_ONE_EXT):n.clipControlEXT(n.LOWER_LEFT_EXT,n.NEGATIVE_ONE_TO_ONE_EXT),i=e;
          let r=l;
          l=null,this.setClear(r)
          }
        },getReversed:function(){
        return i
        },setTest:function(n){
        n?V(e.DEPTH_TEST):W(e.DEPTH_TEST)
        },setMask:function(n){
        a===n||r||(e.depthMask(n),a=n)
        },setFunc:function(t){
        if(i&&(t=n.ReversedDepthFuncs[t]),o!==t){
          switch(t){case n.NeverDepth:
          e.depthFunc(e.NEVER);
          break;
          case n.AlwaysDepth:
          e.depthFunc(e.ALWAYS);
          break;
          case n.LessDepth:
          e.depthFunc(e.LESS);
          break;
          case n.LessEqualDepth:
          e.depthFunc(e.LEQUAL);
          break;
          case n.EqualDepth:
          e.depthFunc(e.EQUAL);
          break;
          case n.GreaterEqualDepth:
          e.depthFunc(e.GEQUAL);
          break;
          case n.GreaterDepth:
          e.depthFunc(e.GREATER);
          break;
          case n.NotEqualDepth:
          e.depthFunc(e.NOTEQUAL);
          break;
          default:
          e.depthFunc(e.LEQUAL)
          }
          o=t
          }
        },setLocked:function(e){
        r=e
        },setClear:function(n){
        l!==n&&(l=n,i&&(n=1-n),e.clearDepth(n))
        },reset:function(){
        r=!1,a=null,o=null,l=null,i=!1
        }}
      },a=new function(){
      let n=!1,t=null,r=null,i=null,a=null,o=null,l=null,s=null,c=null;
      return{setTest:function(t){
        n||(t?V(e.STENCIL_TEST):W(e.STENCIL_TEST))
        },setMask:function(r){
        t===r||n||(e.stencilMask(r),t=r)
        },setFunc:function(n,t,o){
        (r!==n||i!==t||a!==o)&&(e.stencilFunc(n,t,o),r=n,i=t,a=o)
        },setOp:function(n,t,r){
        (o!==n||l!==t||s!==r)&&(e.stencilOp(n,t,r),o=n,l=t,s=r)
        },setLocked:function(e){
        n=e
        },setClear:function(n){
        c!==n&&(e.clearStencil(n),c=n)
        },reset:function(){
        n=!1,t=null,r=null,i=null,a=null,o=null,l=null,s=null,c=null
        }}
      },o=new WeakMap,l=new WeakMap,s={},c={},d={},u=new WeakMap,f=[],p=null,m=!1,_=null,h=null,g=null,v=null,S=null,E=null,T=null,M=new n.Color(0,0,0),x=0,R=!1,A=null,C=null,b=null,P=null,L=null,U=e.getParameter(e.MAX_COMBINED_TEXTURE_IMAGE_UNITS),D=!1,w=e.getParameter(e.VERSION);
    -1!==w.indexOf("WebGL")?D=parseFloat(/^WebGL (\d)/.exec(w)[1])>=1:-1!==w.indexOf("OpenGL ES")&&(D=parseFloat(/^OpenGL ES (\d)/.exec(w)[1])>=2);
    let N=null,I={},y=e.getParameter(e.SCISSOR_BOX),F=e.getParameter(e.VIEWPORT),O=new n.Vector4().fromArray(y),B=new n.Vector4().fromArray(F);
    function G(n,t,r,i){
      let a=new Uint8Array(4),o=e.createTexture();
      e.bindTexture(n,o),e.texParameteri(n,e.TEXTURE_MIN_FILTER,e.NEAREST),e.texParameteri(n,e.TEXTURE_MAG_FILTER,e.NEAREST);
      for(
      let o=0
      ;o<r;o++)
      n===e.TEXTURE_3D||n===e.TEXTURE_2D_ARRAY?e.texImage3D(t,0,e.RGBA,1,1,i,0,e.RGBA,e.UNSIGNED_BYTE,a):e.texImage2D(t+o,0,e.RGBA,1,1,0,e.RGBA,e.UNSIGNED_BYTE,a);
      return o
      }
    let H={};
    function V(n){
      !0!==s[n]&&(e.enable(n),s[n]=!0)
      }
    function W(n){
      !1!==s[n]&&(e.disable(n),s[n]=!1)
      }
    H[e.TEXTURE_2D]=G(e.TEXTURE_2D,e.TEXTURE_2D,1),H[e.TEXTURE_CUBE_MAP]=G(e.TEXTURE_CUBE_MAP,e.TEXTURE_CUBE_MAP_POSITIVE_X,6),H[e.TEXTURE_2D_ARRAY]=G(e.TEXTURE_2D_ARRAY,e.TEXTURE_2D_ARRAY,1,1),H[e.TEXTURE_3D]=G(e.TEXTURE_3D,e.TEXTURE_3D,1,1),r.setClear(0,0,0,1),i.setClear(1),a.setClear(0),V(e.DEPTH_TEST),i.setFunc(n.LessEqualDepth),q(!1),K(n.CullFaceBack),V(e.CULL_FACE),X(n.NoBlending);
    let z={[n.AddEquation]:e.FUNC_ADD,[n.SubtractEquation]:e.FUNC_SUBTRACT,[n.ReverseSubtractEquation]:e.FUNC_REVERSE_SUBTRACT};
    z[n.MinEquation]=e.MIN,z[n.MaxEquation]=e.MAX;
    let k={[n.ZeroFactor]:e.ZERO,[n.OneFactor]:e.ONE,[n.SrcColorFactor]:e.SRC_COLOR,[n.SrcAlphaFactor]:e.SRC_ALPHA,[n.SrcAlphaSaturateFactor]:e.SRC_ALPHA_SATURATE,[n.DstColorFactor]:e.DST_COLOR,[n.DstAlphaFactor]:e.DST_ALPHA,[n.OneMinusSrcColorFactor]:e.ONE_MINUS_SRC_COLOR,[n.OneMinusSrcAlphaFactor]:e.ONE_MINUS_SRC_ALPHA,[n.OneMinusDstColorFactor]:e.ONE_MINUS_DST_COLOR,[n.OneMinusDstAlphaFactor]:e.ONE_MINUS_DST_ALPHA,[n.ConstantColorFactor]:e.CONSTANT_COLOR,[n.OneMinusConstantColorFactor]:e.ONE_MINUS_CONSTANT_COLOR,[n.ConstantAlphaFactor]:e.CONSTANT_ALPHA,[n.OneMinusConstantAlphaFactor]:e.ONE_MINUS_CONSTANT_ALPHA};
    function X(t,r,i,a,o,l,s,c,d,u){
      if(t===n.NoBlending){
        !0===m&&(W(e.BLEND),m=!1);
        return
        }
      if(!1===m&&(V(e.BLEND),m=!0),t!==n.CustomBlending){
        if(t!==_||u!==R){
          if((h!==n.AddEquation||S!==n.AddEquation)&&(e.blendEquation(e.FUNC_ADD),h=n.AddEquation,S=n.AddEquation),u)
          switch(t){case n.NormalBlending:
          e.blendFuncSeparate(e.ONE,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);
          break;
          case n.AdditiveBlending:
          e.blendFunc(e.ONE,e.ONE);
          break;
          case n.SubtractiveBlending:
          e.blendFuncSeparate(e.ZERO,e.ONE_MINUS_SRC_COLOR,e.ZERO,e.ONE);
          break;
          case n.MultiplyBlending:
          e.blendFuncSeparate(e.DST_COLOR,e.ONE_MINUS_SRC_ALPHA,e.ZERO,e.ONE);
          break;
          default:
          (0,n.error)("WebGLState: Invalid blending: ",t)
          }
          else 
          switch(t){case n.NormalBlending:
          e.blendFuncSeparate(e.SRC_ALPHA,e.ONE_MINUS_SRC_ALPHA,e.ONE,e.ONE_MINUS_SRC_ALPHA);
          break;
          case n.AdditiveBlending:
          e.blendFuncSeparate(e.SRC_ALPHA,e.ONE,e.ONE,e.ONE);
          break;
          case n.SubtractiveBlending:
          (0,n.error)("WebGLState: SubtractiveBlending requires material.premultipliedAlpha = true");
          break;
          case n.MultiplyBlending:
          (0,n.error)("WebGLState: MultiplyBlending requires material.premultipliedAlpha = true");
          break;
          default:
          (0,n.error)("WebGLState: Invalid blending: ",t)
          }
          g=null,v=null,E=null,T=null,M.set(0,0,0),x=0,_=t,R=u
          }
        return
        }
      o=o||r,l=l||i,s=s||a,(r!==h||o!==S)&&(e.blendEquationSeparate(z[r],z[o]),h=r,S=o),(i!==g||a!==v||l!==E||s!==T)&&(e.blendFuncSeparate(k[i],k[a],k[l],k[s]),g=i,v=a,E=l,T=s),(!1===c.equals(M)||d!==x)&&(e.blendColor(c.r,c.g,c.b,d),M.copy(c),x=d),_=t,R=!1
      }
    function q(n){
      A!==n&&(n?e.frontFace(e.CW):e.frontFace(e.CCW),A=n)
      }
    function K(t){
      t!==n.CullFaceNone?(V(e.CULL_FACE),t!==C&&(t===n.CullFaceBack?e.cullFace(e.BACK):t===n.CullFaceFront?e.cullFace(e.FRONT):e.cullFace(e.FRONT_AND_BACK))):W(e.CULL_FACE),C=t
      }
    function Y(n,t,r){
      n?(V(e.POLYGON_OFFSET_FILL),(P!==t||L!==r)&&(P=t,L=r,i.getReversed()&&(t=-t),e.polygonOffset(t,r))):W(e.POLYGON_OFFSET_FILL)
      }
    return{buffers:{color:r,depth:i,stencil:a},enable:V,disable:W,bindFramebuffer:function(n,t){
      return d[n]!==t&&(e.bindFramebuffer(n,t),d[n]=t,n===e.DRAW_FRAMEBUFFER&&(d[e.FRAMEBUFFER]=t),n===e.FRAMEBUFFER&&(d[e.DRAW_FRAMEBUFFER]=t),!0)
      },drawBuffers:function(n,t){
      let r=f,i=!1;
      if(n){
        void 0===(r=u.get(t))&&(r=[],u.set(t,r));
        let a=n.textures;
        if(r.length!==a.length||r[0]!==e.COLOR_ATTACHMENT0){
          for(
          let n=0,t=a.length
          ;n<t;n++)
          r[n]=e.COLOR_ATTACHMENT0+n;
          r.length=a.length,i=!0
          }
        }else 
      r[0]!==e.BACK&&(r[0]=e.BACK,i=!0);
      i&&e.drawBuffers(r)
      },useProgram:function(n){
      return p!==n&&(e.useProgram(n),p=n,!0)
      },setBlending:X,setMaterial:function(t,o){
      t.side===n.DoubleSide?W(e.CULL_FACE):V(e.CULL_FACE);
      let l=t.side===n.BackSide;
      o&&(l=!l),q(l),t.blending===n.NormalBlending&&!1===t.transparent?X(n.NoBlending):X(t.blending,t.blendEquation,t.blendSrc,t.blendDst,t.blendEquationAlpha,t.blendSrcAlpha,t.blendDstAlpha,t.blendColor,t.blendAlpha,t.premultipliedAlpha),i.setFunc(t.depthFunc),i.setTest(t.depthTest),i.setMask(t.depthWrite),r.setMask(t.colorWrite);
      let s=t.stencilWrite;
      a.setTest(s),s&&(a.setMask(t.stencilWriteMask),a.setFunc(t.stencilFunc,t.stencilRef,t.stencilFuncMask),a.setOp(t.stencilFail,t.stencilZFail,t.stencilZPass)),Y(t.polygonOffset,t.polygonOffsetFactor,t.polygonOffsetUnits),!0===t.alphaToCoverage?V(e.SAMPLE_ALPHA_TO_COVERAGE):W(e.SAMPLE_ALPHA_TO_COVERAGE)
      },setFlipSided:q,setCullFace:K,setLineWidth:function(n){
      n!==b&&(D&&e.lineWidth(n),b=n)
      },setPolygonOffset:Y,setScissorTest:function(n){
      n?V(e.SCISSOR_TEST):W(e.SCISSOR_TEST)
      },activeTexture:function(n){
      void 0===n&&(n=e.TEXTURE0+U-1),N!==n&&(e.activeTexture(n),N=n)
      },bindTexture:function(n,t,r){
      void 0===r&&(r=null===N?e.TEXTURE0+U-1:N);
      let i=I[r];
      void 0===i&&(i={type:void 0,texture:void 0},I[r]=i),(i.type!==n||i.texture!==t)&&(N!==r&&(e.activeTexture(r),N=r),e.bindTexture(n,t||H[n]),i.type=n,i.texture=t)
      },unbindTexture:function(){
      let n=I[N];
      void 0!==n&&void 0!==n.type&&(e.bindTexture(n.type,null),n.type=void 0,n.texture=void 0)
      },compressedTexImage2D:function(){
      try{
        e.compressedTexImage2D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },compressedTexImage3D:function(){
      try{
        e.compressedTexImage3D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },texImage2D:function(){
      try{
        e.texImage2D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },texImage3D:function(){
      try{
        e.texImage3D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },pixelStorei:function(n,t){
      c[n]!==t&&(e.pixelStorei(n,t),c[n]=t)
      },getParameter:function(n){
      return void 0!==c[n]?c[n]:e.getParameter(n)
      },updateUBOMapping:function(n,t){
      let r=l.get(t);
      void 0===r&&(r=new WeakMap,l.set(t,r));
      let i=r.get(n);
      void 0===i&&(i=e.getUniformBlockIndex(t,n.name),r.set(n,i))
      },uniformBlockBinding:function(n,t){
      let r=l.get(t).get(n);
      o.get(t)!==r&&(e.uniformBlockBinding(t,r,n.__bindingPointIndex),o.set(t,r))
      },texStorage2D:function(){
      try{
        e.texStorage2D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },texStorage3D:function(){
      try{
        e.texStorage3D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },texSubImage2D:function(){
      try{
        e.texSubImage2D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },texSubImage3D:function(){
      try{
        e.texSubImage3D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },compressedTexSubImage2D:function(){
      try{
        e.compressedTexSubImage2D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },compressedTexSubImage3D:function(){
      try{
        e.compressedTexSubImage3D(...arguments)
        }catch(e){
        (0,n.error)("WebGLState:",e)
        }
      },scissor:function(n){
      !1===O.equals(n)&&(e.scissor(n.x,n.y,n.z,n.w),O.copy(n))
      },viewport:function(n){
      !1===B.equals(n)&&(e.viewport(n.x,n.y,n.z,n.w),B.copy(n))
      },reset:function(){
      e.disable(e.BLEND),e.disable(e.CULL_FACE),e.disable(e.DEPTH_TEST),e.disable(e.POLYGON_OFFSET_FILL),e.disable(e.SCISSOR_TEST),e.disable(e.STENCIL_TEST),e.disable(e.SAMPLE_ALPHA_TO_COVERAGE),e.blendEquation(e.FUNC_ADD),e.blendFunc(e.ONE,e.ZERO),e.blendFuncSeparate(e.ONE,e.ZERO,e.ONE,e.ZERO),e.blendColor(0,0,0,0),e.colorMask(!0,!0,!0,!0),e.clearColor(0,0,0,0),e.depthMask(!0),e.depthFunc(e.LESS),i.setReversed(!1),e.clearDepth(1),e.stencilMask(0xffffffff),e.stencilFunc(e.ALWAYS,0,0xffffffff),e.stencilOp(e.KEEP,e.KEEP,e.KEEP),e.clearStencil(0),e.cullFace(e.BACK),e.frontFace(e.CCW),e.polygonOffset(0,0),e.activeTexture(e.TEXTURE0),e.bindFramebuffer(e.FRAMEBUFFER,null),e.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),e.bindFramebuffer(e.READ_FRAMEBUFFER,null),e.useProgram(null),e.lineWidth(1),e.scissor(0,0,e.canvas.width,e.canvas.height),e.viewport(0,0,e.canvas.width,e.canvas.height),e.pixelStorei(e.PACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_ALIGNMENT,4),e.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,!1),e.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,!1),e.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,e.BROWSER_DEFAULT_WEBGL),e.pixelStorei(e.PACK_ROW_LENGTH,0),e.pixelStorei(e.PACK_SKIP_PIXELS,0),e.pixelStorei(e.PACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_ROW_LENGTH,0),e.pixelStorei(e.UNPACK_IMAGE_HEIGHT,0),e.pixelStorei(e.UNPACK_SKIP_PIXELS,0),e.pixelStorei(e.UNPACK_SKIP_ROWS,0),e.pixelStorei(e.UNPACK_SKIP_IMAGES,0),s={},c={},N=null,I={},d={},u=new WeakMap,f=[],p=null,m=!1,_=null,h=null,g=null,v=null,S=null,E=null,T=null,M=new n.Color(0,0,0),x=0,R=!1,A=null,C=null,b=null,P=null,L=null,O.set(0,0,e.canvas.width,e.canvas.height),B.set(0,0,e.canvas.width,e.canvas.height),r.reset(),i.reset(),a.reset()
      }}
    }
  function nx(e,t,r,i,a,o,l){
    let s,c=t.has("WEBGL_multisampled_render_to_texture")?t.get("WEBGL_multisampled_render_to_texture"):null,d="u">typeof navigator&&/OculusBrowser/g.test(navigator.userAgent),u=new n.Vector2,f=new WeakMap,p=new Set,m=new WeakMap,_=!1;
    try{
      _="u">typeof OffscreenCanvas&&null!==new OffscreenCanvas(1,1).getContext("2d")
      }catch(e){
      }
    function h(e,t){
      return _?new OffscreenCanvas(e,t):(0,n.createElementNS)("canvas")
      }
    function g(e,t,r){
      let i=1,a=k(e);
      if((a.width>r||a.height>r)&&(i=r/Math.max(a.width,a.height)),i<1)
      if("u">typeof HTMLImageElement&&e instanceof HTMLImageElement||"u">typeof HTMLCanvasElement&&e instanceof HTMLCanvasElement||"u">typeof ImageBitmap&&e instanceof ImageBitmap||"u">typeof VideoFrame&&e instanceof VideoFrame){
        let r=Math.floor(i*a.width),o=Math.floor(i*a.height);
        void 0===s&&(s=h(r,o));
        let l=t?h(r,o):s;
        return l.width=r,l.height=o,l.getContext("2d").drawImage(e,0,0,r,o),(0,n.warn)("WebGLRenderer: Texture has been resized from ("+a.width+"x"+a.height+") to ("+r+"x"+o+")."),l
        }else
      "data"in e&&(0,n.warn)("WebGLRenderer: Image in DataTexture is too big ("+a.width+"x"+a.height+").");
      return e
      }
    function v(e){
      return e.generateMipmaps
      }
    function S(n){
      e.generateMipmap(n)
      }
    function E(r,i,a,o,l,s=!1){
      let c;
      if(null!==r){
        if(void 0!==e[r])
        return e[r];
        (0,n.warn)("WebGLRenderer: Attempt to use non-existing WebGL internal format '"+r+"'")
        }
      o&&((c=t.get("EXT_texture_norm16"))||(0,n.warn)("WebGLRenderer: Unable to use normalized textures without EXT_texture_norm16 extension"));
      let d=i;
      if(i===e.RED&&(a===e.FLOAT&&(d=e.R32F),a===e.HALF_FLOAT&&(d=e.R16F),a===e.UNSIGNED_BYTE&&(d=e.R8),a===e.UNSIGNED_SHORT&&c&&(d=c.R16_EXT),a===e.SHORT&&c&&(d=c.R16_SNORM_EXT)),i===e.RED_INTEGER&&(a===e.UNSIGNED_BYTE&&(d=e.R8UI),a===e.UNSIGNED_SHORT&&(d=e.R16UI),a===e.UNSIGNED_INT&&(d=e.R32UI),a===e.BYTE&&(d=e.R8I),a===e.SHORT&&(d=e.R16I),a===e.INT&&(d=e.R32I)),i===e.RG&&(a===e.FLOAT&&(d=e.RG32F),a===e.HALF_FLOAT&&(d=e.RG16F),a===e.UNSIGNED_BYTE&&(d=e.RG8),a===e.UNSIGNED_SHORT&&c&&(d=c.RG16_EXT),a===e.SHORT&&c&&(d=c.RG16_SNORM_EXT)),i===e.RG_INTEGER&&(a===e.UNSIGNED_BYTE&&(d=e.RG8UI),a===e.UNSIGNED_SHORT&&(d=e.RG16UI),a===e.UNSIGNED_INT&&(d=e.RG32UI),a===e.BYTE&&(d=e.RG8I),a===e.SHORT&&(d=e.RG16I),a===e.INT&&(d=e.RG32I)),i===e.RGB_INTEGER&&(a===e.UNSIGNED_BYTE&&(d=e.RGB8UI),a===e.UNSIGNED_SHORT&&(d=e.RGB16UI),a===e.UNSIGNED_INT&&(d=e.RGB32UI),a===e.BYTE&&(d=e.RGB8I),a===e.SHORT&&(d=e.RGB16I),a===e.INT&&(d=e.RGB32I)),i===e.RGBA_INTEGER&&(a===e.UNSIGNED_BYTE&&(d=e.RGBA8UI),a===e.UNSIGNED_SHORT&&(d=e.RGBA16UI),a===e.UNSIGNED_INT&&(d=e.RGBA32UI),a===e.BYTE&&(d=e.RGBA8I),a===e.SHORT&&(d=e.RGBA16I),a===e.INT&&(d=e.RGBA32I)),i===e.RGB&&(a===e.UNSIGNED_SHORT&&c&&(d=c.RGB16_EXT),a===e.SHORT&&c&&(d=c.RGB16_SNORM_EXT),a===e.UNSIGNED_INT_5_9_9_9_REV&&(d=e.RGB9_E5),a===e.UNSIGNED_INT_10F_11F_11F_REV&&(d=e.R11F_G11F_B10F)),i===e.RGBA){
        let t=s?n.LinearTransfer:n.ColorManagement.getTransfer(l);
        a===e.FLOAT&&(d=e.RGBA32F),a===e.HALF_FLOAT&&(d=e.RGBA16F),a===e.UNSIGNED_BYTE&&(d=t===n.SRGBTransfer?e.SRGB8_ALPHA8:e.RGBA8),a===e.UNSIGNED_SHORT&&c&&(d=c.RGBA16_EXT),a===e.SHORT&&c&&(d=c.RGBA16_SNORM_EXT),a===e.UNSIGNED_SHORT_4_4_4_4&&(d=e.RGBA4),a===e.UNSIGNED_SHORT_5_5_5_1&&(d=e.RGB5_A1)
        }
      return(d===e.R16F||d===e.R32F||d===e.RG16F||d===e.RG32F||d===e.RGBA16F||d===e.RGBA32F)&&t.get("EXT_color_buffer_float"),d
      }
    function T(t,r){
      let i;
      return t?null===r||r===n.UnsignedIntType||r===n.UnsignedInt248Type?i=e.DEPTH24_STENCIL8:r===n.FloatType?i=e.DEPTH32F_STENCIL8:r===n.UnsignedShortType&&(i=e.DEPTH24_STENCIL8,(0,n.warn)("DepthTexture: 16 bit depth attachment is not supported with stencil. Using 24-bit attachment.")):null===r||r===n.UnsignedIntType||r===n.UnsignedInt248Type?i=e.DEPTH_COMPONENT24:r===n.FloatType?i=e.DEPTH_COMPONENT32F:r===n.UnsignedShortType&&(i=e.DEPTH_COMPONENT16),i
      }
    function M(e,t){
      return!0===v(e)||e.isFramebufferTexture&&e.minFilter!==n.NearestFilter&&e.minFilter!==n.LinearFilter?Math.log2(Math.max(t.width,t.height))+1:void 0!==e.mipmaps&&e.mipmaps.length>0?e.mipmaps.length:e.isCompressedTexture&&Array.isArray(e.image)?t.mipmaps.length:1
      }
    function x(e){
      let n=e.target;
      n.removeEventListener("dispose",x),function(e){
        let n=i.get(e);
        if(void 0===n.__webglInit)
        return;
        let t=e.source,r=m.get(t);
        if(r){
          let i=r[n.__cacheKey];
          i.usedTimes--,0===i.usedTimes&&A(e),0===Object.keys(r).length&&m.delete(t)
          }
        i.remove(e)
        }(n),n.isVideoTexture&&f.delete(n),n.isHTMLTexture&&p.delete(n)
      }
    function R(n){
      let t=n.target;
      t.removeEventListener("dispose",R),function(n){
        let t=i.get(n);
        if(n.depthTexture&&(n.depthTexture.dispose(),i.remove(n.depthTexture)),n.isWebGLCubeRenderTarget)
        for(
        let n=0
        ;n<6;n++){
          if(Array.isArray(t.__webglFramebuffer[n]))
          for(
          let r=0
          ;r<t.__webglFramebuffer[n].length;r++)
          e.deleteFramebuffer(t.__webglFramebuffer[n][r]);
          else 
          e.deleteFramebuffer(t.__webglFramebuffer[n]);
          t.__webglDepthbuffer&&e.deleteRenderbuffer(t.__webglDepthbuffer[n])
          }
        else{
          if(Array.isArray(t.__webglFramebuffer))
          for(
          let n=0
          ;n<t.__webglFramebuffer.length;n++)
          e.deleteFramebuffer(t.__webglFramebuffer[n]);
          else 
          e.deleteFramebuffer(t.__webglFramebuffer);
          if(t.__webglDepthbuffer&&e.deleteRenderbuffer(t.__webglDepthbuffer),t.__webglMultisampledFramebuffer&&e.deleteFramebuffer(t.__webglMultisampledFramebuffer),t.__webglColorRenderbuffer)
          for(
          let n=0
          ;n<t.__webglColorRenderbuffer.length;n++)
          t.__webglColorRenderbuffer[n]&&e.deleteRenderbuffer(t.__webglColorRenderbuffer[n]);
          t.__webglDepthRenderbuffer&&e.deleteRenderbuffer(t.__webglDepthRenderbuffer)
          }
        let r=n.textures;
        for(
        let n=0,t=r.length
        ;n<t;n++){
          let t=i.get(r[n]);
          t.__webglTexture&&(e.deleteTexture(t.__webglTexture),l.memory.textures--),i.remove(r[n])
          }
        i.remove(n)
        }(t)
      }
    function A(n){
      let t=i.get(n);
      e.deleteTexture(t.__webglTexture);
      let r=n.source,a=m.get(r);
      delete a[t.__cacheKey],l.memory.textures--
      }
    let C=0;
    function b(t,a){
      var o;
      let s,c=i.get(t);
      if(t.isVideoTexture&&(o=t,s=l.render.frame,f.get(o)!==s&&(f.set(o,s),o.update())),!1===t.isRenderTargetTexture&&!0!==t.isExternalTexture&&t.version>0&&c.__version!==t.version){
        let e=t.image;
        if(null===e)
        (0,n.warn)("WebGLRenderer: Texture marked for update but no image data found.");
        else{
          if(!1!==e.complete)
          return void I(c,t,a);
          (0,n.warn)("WebGLRenderer: Texture marked for update but image is incomplete")
          }
        }else 
      t.isExternalTexture&&(c.__webglTexture=t.sourceTexture?t.sourceTexture:null);
      r.bindTexture(e.TEXTURE_2D,c.__webglTexture,e.TEXTURE0+a)
      }
    let P={[n.RepeatWrapping]:e.REPEAT,[n.ClampToEdgeWrapping]:e.CLAMP_TO_EDGE,[n.MirroredRepeatWrapping]:e.MIRRORED_REPEAT},L={[n.NearestFilter]:e.NEAREST,[n.NearestMipmapNearestFilter]:e.NEAREST_MIPMAP_NEAREST,[n.NearestMipmapLinearFilter]:e.NEAREST_MIPMAP_LINEAR,[n.LinearFilter]:e.LINEAR,[n.LinearMipmapNearestFilter]:e.LINEAR_MIPMAP_NEAREST,[n.LinearMipmapLinearFilter]:e.LINEAR_MIPMAP_LINEAR},U={[n.NeverCompare]:e.NEVER,[n.AlwaysCompare]:e.ALWAYS,[n.LessCompare]:e.LESS,[n.LessEqualCompare]:e.LEQUAL,[n.EqualCompare]:e.EQUAL,[n.GreaterEqualCompare]:e.GEQUAL,[n.GreaterCompare]:e.GREATER,[n.NotEqualCompare]:e.NOTEQUAL};
    function D(r,o){
      if((o.type===n.FloatType&&!1===t.has("OES_texture_float_linear")&&(o.magFilter===n.LinearFilter||o.magFilter===n.LinearMipmapNearestFilter||o.magFilter===n.NearestMipmapLinearFilter||o.magFilter===n.LinearMipmapLinearFilter||o.minFilter===n.LinearFilter||o.minFilter===n.LinearMipmapNearestFilter||o.minFilter===n.NearestMipmapLinearFilter||o.minFilter===n.LinearMipmapLinearFilter)&&(0,n.warn)("WebGLRenderer: Unable to use linear filtering with floating point textures. OES_texture_float_linear not supported on this device."),e.texParameteri(r,e.TEXTURE_WRAP_S,P[o.wrapS]),e.texParameteri(r,e.TEXTURE_WRAP_T,P[o.wrapT]),(r===e.TEXTURE_3D||r===e.TEXTURE_2D_ARRAY)&&e.texParameteri(r,e.TEXTURE_WRAP_R,P[o.wrapR]),e.texParameteri(r,e.TEXTURE_MAG_FILTER,L[o.magFilter]),e.texParameteri(r,e.TEXTURE_MIN_FILTER,L[o.minFilter]),o.compareFunction&&(e.texParameteri(r,e.TEXTURE_COMPARE_MODE,e.COMPARE_REF_TO_TEXTURE),e.texParameteri(r,e.TEXTURE_COMPARE_FUNC,U[o.compareFunction])),!0===t.has("EXT_texture_filter_anisotropic"))&&o.magFilter!==n.NearestFilter&&(o.minFilter===n.NearestMipmapLinearFilter||o.minFilter===n.LinearMipmapLinearFilter)&&(o.type!==n.FloatType||!1!==t.has("OES_texture_float_linear"))&&(o.anisotropy>1||i.get(o).__currentAnisotropy)){
        let n=t.get("EXT_texture_filter_anisotropic");
        e.texParameterf(r,n.TEXTURE_MAX_ANISOTROPY_EXT,Math.min(o.anisotropy,a.getMaxAnisotropy())),i.get(o).__currentAnisotropy=o.anisotropy
        }
      }
    function w(n,t){
      let r,i=!1;
      void 0===n.__webglInit&&(n.__webglInit=!0,t.addEventListener("dispose",x));
      let a=t.source,o=m.get(a);
      void 0===o&&(o={},m.set(a,o));
      let s=((r=[]).push(t.wrapS),r.push(t.wrapT),r.push(t.wrapR||0),r.push(t.magFilter),r.push(t.minFilter),r.push(t.anisotropy),r.push(t.internalFormat),r.push(t.format),r.push(t.type),r.push(t.generateMipmaps),r.push(t.premultiplyAlpha),r.push(t.flipY),r.push(t.unpackAlignment),r.push(t.colorSpace),r.join());
      if(s!==n.__cacheKey){
        void 0===o[s]&&(o[s]={texture:e.createTexture(),usedTimes:0},l.memory.textures++,i=!0),o[s].usedTimes++;
        let r=o[n.__cacheKey];
        void 0!==r&&(o[n.__cacheKey].usedTimes--,0===r.usedTimes&&A(t)),n.__cacheKey=s,n.__webglTexture=o[s].texture
        }
      return i
      }
    function N(e,n,t){
      return Math.floor(Math.floor(e/t)/n)
      }
    function I(t,l,s){
      let c=e.TEXTURE_2D;
      (l.isDataArrayTexture||l.isCompressedArrayTexture)&&(c=e.TEXTURE_2D_ARRAY),l.isData3DTexture&&(c=e.TEXTURE_3D);
      let d=w(t,l),u=l.source;
      r.bindTexture(c,t.__webglTexture,e.TEXTURE0+s);
      let f=i.get(u);
      if(u.version!==f.__version||!0===d){
        let t;
        if(r.activeTexture(e.TEXTURE0+s),!1==("u">typeof ImageBitmap&&l.image instanceof ImageBitmap)){
          let t=n.ColorManagement.getPrimaries(n.ColorManagement.workingColorSpace),i=l.colorSpace===n.NoColorSpace?null:n.ColorManagement.getPrimaries(l.colorSpace),a=l.colorSpace===n.NoColorSpace||t===i?e.NONE:e.BROWSER_DEFAULT_WEBGL;
          r.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,l.flipY),r.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,l.premultiplyAlpha),r.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,a)
          }
        r.pixelStorei(e.UNPACK_ALIGNMENT,l.unpackAlignment);
        let i=g(l.image,!1,a.maxTextureSize);
        i=z(l,i);
        let m=o.convert(l.format,l.colorSpace),_=o.convert(l.type),h=E(l.internalFormat,m,_,l.normalized,l.colorSpace,l.isVideoTexture);
        D(c,l);
        let x=l.mipmaps,R=!0!==l.isVideoTexture,A=void 0===f.__version||!0===d,C=u.dataReady,b=M(l,i);
        if(l.isDepthTexture)
        h=T(l.format===n.DepthStencilFormat,l.type),A&&(R?r.texStorage2D(e.TEXTURE_2D,1,h,i.width,i.height):r.texImage2D(e.TEXTURE_2D,0,h,i.width,i.height,0,m,_,null));
        else 
        if(l.isDataTexture)
        if(x.length>0){
          R&&A&&r.texStorage2D(e.TEXTURE_2D,b,h,x[0].width,x[0].height);
          for(
          let n=0,i=x.length
          ;n<i;n++)
          t=x[n],R?C&&r.texSubImage2D(e.TEXTURE_2D,n,0,0,t.width,t.height,m,_,t.data):r.texImage2D(e.TEXTURE_2D,n,h,t.width,t.height,0,m,_,t.data);
          l.generateMipmaps=!1
          }else 
        R?(A&&r.texStorage2D(e.TEXTURE_2D,b,h,i.width,i.height),C&&function(n,t,i,a){
          let o=n.updateRanges;
          if(0===o.length)
          r.texSubImage2D(e.TEXTURE_2D,0,0,0,t.width,t.height,i,a,t.data);
          else{
            o.sort((e,n)=>e.start-n.start);
            let l=0;
            for(
            let e=1
            ;e<o.length;e++){
              let n=o[l],r=o[e],i=n.start+n.count,a=N(r.start,t.width,4),s=N(n.start,t.width,4);
              r.start<=i+1&&a===s&&N(r.start+r.count-1,t.width,4)===a?n.count=Math.max(n.count,r.start+r.count-n.start):o[++l]=r
              }
            o.length=l+1;
            let s=r.getParameter(e.UNPACK_ROW_LENGTH),c=r.getParameter(e.UNPACK_SKIP_PIXELS),d=r.getParameter(e.UNPACK_SKIP_ROWS);
            r.pixelStorei(e.UNPACK_ROW_LENGTH,t.width);
            for(
            let n=0,l=o.length
            ;n<l;n++){
              let l=o[n],s=Math.floor(l.start/4),c=Math.ceil(l.count/4),d=s%t.width,u=Math.floor(s/t.width);
              r.pixelStorei(e.UNPACK_SKIP_PIXELS,d),r.pixelStorei(e.UNPACK_SKIP_ROWS,u),r.texSubImage2D(e.TEXTURE_2D,0,d,u,c,1,i,a,t.data)
              }
            n.clearUpdateRanges(),r.pixelStorei(e.UNPACK_ROW_LENGTH,s),r.pixelStorei(e.UNPACK_SKIP_PIXELS,c),r.pixelStorei(e.UNPACK_SKIP_ROWS,d)
            }
          }(l,i,m,_)):r.texImage2D(e.TEXTURE_2D,0,h,i.width,i.height,0,m,_,i.data);
        else 
        if(l.isCompressedTexture)
        if(l.isCompressedArrayTexture){
          R&&A&&r.texStorage3D(e.TEXTURE_2D_ARRAY,b,h,x[0].width,x[0].height,i.depth);
          for(
          let a=0,o=x.length
          ;a<o;a++)
          if(t=x[a],l.format!==n.RGBAFormat)
          if(null!==m)
          if(R){
            if(C)
            if(l.layerUpdates.size>0){
              let i=(0,n.getByteLength)(t.width,t.height,l.format,l.type);
              for(
              let n
               of l.layerUpdates){
                let o=t.data.subarray(n*i/t.data.BYTES_PER_ELEMENT,(n+1)*i/t.data.BYTES_PER_ELEMENT);
                r.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,a,0,0,n,t.width,t.height,1,m,o)
                }
              l.clearLayerUpdates()
              }else 
            r.compressedTexSubImage3D(e.TEXTURE_2D_ARRAY,a,0,0,0,t.width,t.height,i.depth,m,t.data)
            }else 
          r.compressedTexImage3D(e.TEXTURE_2D_ARRAY,a,h,t.width,t.height,i.depth,0,t.data,0,0);
          else
          (0,n.warn)("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()");
          else 
          R?C&&r.texSubImage3D(e.TEXTURE_2D_ARRAY,a,0,0,0,t.width,t.height,i.depth,m,_,t.data):r.texImage3D(e.TEXTURE_2D_ARRAY,a,h,t.width,t.height,i.depth,0,m,_,t.data)
          }else{
          R&&A&&r.texStorage2D(e.TEXTURE_2D,b,h,x[0].width,x[0].height);
          for(
          let i=0,a=x.length
          ;i<a;i++)
          t=x[i],l.format!==n.RGBAFormat?null!==m?R?C&&r.compressedTexSubImage2D(e.TEXTURE_2D,i,0,0,t.width,t.height,m,t.data):r.compressedTexImage2D(e.TEXTURE_2D,i,h,t.width,t.height,0,t.data):(0,n.warn)("WebGLRenderer: Attempt to load unsupported compressed texture format in .uploadTexture()"):R?C&&r.texSubImage2D(e.TEXTURE_2D,i,0,0,t.width,t.height,m,_,t.data):r.texImage2D(e.TEXTURE_2D,i,h,t.width,t.height,0,m,_,t.data)
          }
        else 
        if(l.isDataArrayTexture)
        if(R){
          if(A&&r.texStorage3D(e.TEXTURE_2D_ARRAY,b,h,i.width,i.height,i.depth),C)
          if(l.layerUpdates.size>0){
            let t=(0,n.getByteLength)(i.width,i.height,l.format,l.type);
            for(
            let n
             of l.layerUpdates){
              let a=i.data.subarray(n*t/i.data.BYTES_PER_ELEMENT,(n+1)*t/i.data.BYTES_PER_ELEMENT);
              r.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,n,i.width,i.height,1,m,_,a)
              }
            l.clearLayerUpdates()
            }else 
          r.texSubImage3D(e.TEXTURE_2D_ARRAY,0,0,0,0,i.width,i.height,i.depth,m,_,i.data)
          }else 
        r.texImage3D(e.TEXTURE_2D_ARRAY,0,h,i.width,i.height,i.depth,0,m,_,i.data);
        else 
        if(l.isData3DTexture)
        R?(A&&r.texStorage3D(e.TEXTURE_3D,b,h,i.width,i.height,i.depth),C&&r.texSubImage3D(e.TEXTURE_3D,0,0,0,0,i.width,i.height,i.depth,m,_,i.data)):r.texImage3D(e.TEXTURE_3D,0,h,i.width,i.height,i.depth,0,m,_,i.data);
        else 
        if(l.isFramebufferTexture){
          if(A)
          if(R)
          r.texStorage2D(e.TEXTURE_2D,b,h,i.width,i.height);
          else{
            let n=i.width,t=i.height;
            for(
            let i=0
            ;i<b;i++)
            r.texImage2D(e.TEXTURE_2D,i,h,n,t,0,m,_,null),n>>=1,t>>=1
            }
          }else 
        if(l.isHTMLTexture){
          if("texElementImage2D"in e){
            let n=e.canvas;
            if(n.hasAttribute("layoutsubtree")||n.setAttribute("layoutsubtree","true"),i.parentNode!==n){
              n.appendChild(i),p.add(l),n.onpaint=e=>{
                let n=e.changedElements;
                for(
                let e
                 of p)
                n.includes(e.image)&&(e.needsUpdate=!0)
                },n.requestPaint();
              return
              }
            let t=e.RGBA,r=e.RGBA,a=e.UNSIGNED_BYTE;
            e.texElementImage2D(e.TEXTURE_2D,0,t,r,a,i),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_MIN_FILTER,e.LINEAR),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_S,e.CLAMP_TO_EDGE),e.texParameteri(e.TEXTURE_2D,e.TEXTURE_WRAP_T,e.CLAMP_TO_EDGE)
            }
          }else 
        if(x.length>0){
          if(R&&A){
            let n=k(x[0]);
            r.texStorage2D(e.TEXTURE_2D,b,h,n.width,n.height)
            }
          for(
          let n=0,i=x.length
          ;n<i;n++)
          t=x[n],R?C&&r.texSubImage2D(e.TEXTURE_2D,n,0,0,m,_,t):r.texImage2D(e.TEXTURE_2D,n,h,m,_,t);
          l.generateMipmaps=!1
          }else 
        if(R){
          if(A){
            let n=k(i);
            r.texStorage2D(e.TEXTURE_2D,b,h,n.width,n.height)
            }
          C&&r.texSubImage2D(e.TEXTURE_2D,0,0,0,m,_,i)
          }else 
        r.texImage2D(e.TEXTURE_2D,0,h,m,_,i);
        v(l)&&S(c),f.__version=u.version,l.onUpdate&&l.onUpdate(l)
        }
      t.__version=l.version
      }
    function y(n,t,a,l,s,d){
      let u=o.convert(a.format,a.colorSpace),f=o.convert(a.type),p=E(a.internalFormat,u,f,a.normalized,a.colorSpace),m=i.get(t),_=i.get(a);
      if(_.__renderTarget=t,!m.__hasExternalTextures){
        let n=Math.max(1,t.width>>d),i=Math.max(1,t.height>>d);
        s===e.TEXTURE_3D||s===e.TEXTURE_2D_ARRAY?r.texImage3D(s,d,p,n,i,t.depth,0,u,f,null):r.texImage2D(s,d,p,n,i,0,u,f,null)
        }
      r.bindFramebuffer(e.FRAMEBUFFER,n),W(t)?c.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,l,s,_.__webglTexture,0,V(t)):(s===e.TEXTURE_2D||s>=e.TEXTURE_CUBE_MAP_POSITIVE_X&&s<=e.TEXTURE_CUBE_MAP_NEGATIVE_Z)&&e.framebufferTexture2D(e.FRAMEBUFFER,l,s,_.__webglTexture,d),r.bindFramebuffer(e.FRAMEBUFFER,null)
      }
    function F(n,t,r){
      if(e.bindRenderbuffer(e.RENDERBUFFER,n),t.depthBuffer){
        let i=t.depthTexture,a=i&&i.isDepthTexture?i.type:null,o=T(t.stencilBuffer,a),l=t.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;
        W(t)?c.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,V(t),o,t.width,t.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,V(t),o,t.width,t.height):e.renderbufferStorage(e.RENDERBUFFER,o,t.width,t.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,l,e.RENDERBUFFER,n)
        }else{
        let n=t.textures;
        for(
        let i=0
        ;i<n.length;i++){
          let a=n[i],l=o.convert(a.format,a.colorSpace),s=o.convert(a.type),d=E(a.internalFormat,l,s,a.normalized,a.colorSpace);
          W(t)?c.renderbufferStorageMultisampleEXT(e.RENDERBUFFER,V(t),d,t.width,t.height):r?e.renderbufferStorageMultisample(e.RENDERBUFFER,V(t),d,t.width,t.height):e.renderbufferStorage(e.RENDERBUFFER,d,t.width,t.height)
          }
        }
      e.bindRenderbuffer(e.RENDERBUFFER,null)
      }
    function O(t,a,l){
      let s=!0===a.isWebGLCubeRenderTarget;
      if(r.bindFramebuffer(e.FRAMEBUFFER,t),!(a.depthTexture&&a.depthTexture.isDepthTexture))
      throw Error("renderTarget.depthTexture must be an instance of THREE.DepthTexture");
      let d=i.get(a.depthTexture);
      if(d.__renderTarget=a,d.__webglTexture&&a.depthTexture.image.width===a.width&&a.depthTexture.image.height===a.height||(a.depthTexture.image.width=a.width,a.depthTexture.image.height=a.height,a.depthTexture.needsUpdate=!0),s){
        if(void 0===d.__webglInit&&(d.__webglInit=!0,a.depthTexture.addEventListener("dispose",x)),void 0===d.__webglTexture){
          let t;
          d.__webglTexture=e.createTexture(),r.bindTexture(e.TEXTURE_CUBE_MAP,d.__webglTexture),D(e.TEXTURE_CUBE_MAP,a.depthTexture);
          let i=o.convert(a.depthTexture.format),l=o.convert(a.depthTexture.type);
          a.depthTexture.format===n.DepthFormat?t=e.DEPTH_COMPONENT24:a.depthTexture.format===n.DepthStencilFormat&&(t=e.DEPTH24_STENCIL8);
          for(
          let n=0
          ;n<6;n++)
          e.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,t,a.width,a.height,0,i,l,null)
          }
        }else 
      b(a.depthTexture,0);
      let u=d.__webglTexture,f=V(a),p=s?e.TEXTURE_CUBE_MAP_POSITIVE_X+l:e.TEXTURE_2D,m=a.depthTexture.format===n.DepthStencilFormat?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;
      if(a.depthTexture.format===n.DepthFormat)
      W(a)?c.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,m,p,u,0,f):e.framebufferTexture2D(e.FRAMEBUFFER,m,p,u,0);
      else 
      if(a.depthTexture.format===n.DepthStencilFormat)
      W(a)?c.framebufferTexture2DMultisampleEXT(e.FRAMEBUFFER,m,p,u,0,f):e.framebufferTexture2D(e.FRAMEBUFFER,m,p,u,0);
      else 
      throw Error("Unknown depthTexture format")
      }
    function B(n){
      let t=i.get(n),a=!0===n.isWebGLCubeRenderTarget;
      if(t.__boundDepthTexture!==n.depthTexture){
        let e=n.depthTexture;
        if(t.__depthDisposeCallback&&t.__depthDisposeCallback(),e){
          let n=()=>{
            delete t.__boundDepthTexture,delete t.__depthDisposeCallback,e.removeEventListener("dispose",n)
            };
          e.addEventListener("dispose",n),t.__depthDisposeCallback=n
          }
        t.__boundDepthTexture=e
        }
      if(n.depthTexture&&!t.__autoAllocateDepthBuffer)
      if(a)
      for(
      let e=0
      ;e<6;e++)
      O(t.__webglFramebuffer[e],n,e);
      else{
        let e=n.texture.mipmaps;
        e&&e.length>0?O(t.__webglFramebuffer[0],n,0):O(t.__webglFramebuffer,n,0)
        }
      else 
      if(a){
        t.__webglDepthbuffer=[];
        for(
        let i=0
        ;i<6;i++)
        if(r.bindFramebuffer(e.FRAMEBUFFER,t.__webglFramebuffer[i]),void 0===t.__webglDepthbuffer[i])
        t.__webglDepthbuffer[i]=e.createRenderbuffer(),F(t.__webglDepthbuffer[i],n,!1);
        else{
          let r=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,a=t.__webglDepthbuffer[i];
          e.bindRenderbuffer(e.RENDERBUFFER,a),e.framebufferRenderbuffer(e.FRAMEBUFFER,r,e.RENDERBUFFER,a)
          }
        }else{
        let i=n.texture.mipmaps;
        if(i&&i.length>0?r.bindFramebuffer(e.FRAMEBUFFER,t.__webglFramebuffer[0]):r.bindFramebuffer(e.FRAMEBUFFER,t.__webglFramebuffer),void 0===t.__webglDepthbuffer)
        t.__webglDepthbuffer=e.createRenderbuffer(),F(t.__webglDepthbuffer,n,!1);
        else{
          let r=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,i=t.__webglDepthbuffer;
          e.bindRenderbuffer(e.RENDERBUFFER,i),e.framebufferRenderbuffer(e.FRAMEBUFFER,r,e.RENDERBUFFER,i)
          }
        }
      r.bindFramebuffer(e.FRAMEBUFFER,null)
      }
    let G=[],H=[];
    function V(e){
      return Math.min(a.maxSamples,e.samples)
      }
    function W(e){
      let n=i.get(e);
      return e.samples>0&&!0===t.has("WEBGL_multisampled_render_to_texture")&&!1!==n.__useRenderToTexture
      }
    function z(e,t){
      let r=e.colorSpace,i=e.format,a=e.type;
      return!0===e.isCompressedTexture||!0===e.isVideoTexture||r!==n.LinearSRGBColorSpace&&r!==n.NoColorSpace&&(n.ColorManagement.getTransfer(r)===n.SRGBTransfer?(i!==n.RGBAFormat||a!==n.UnsignedByteType)&&(0,n.warn)("WebGLTextures: sRGB encoded textures have to use RGBAFormat and UnsignedByteType."):(0,n.error)("WebGLTextures: Unsupported texture color space:",r)),t
      }
    function k(e){
      return"u">typeof HTMLImageElement&&e instanceof HTMLImageElement?(u.width=e.naturalWidth||e.width,u.height=e.naturalHeight||e.height):"u">typeof VideoFrame&&e instanceof VideoFrame?(u.width=e.displayWidth,u.height=e.displayHeight):(u.width=e.width,u.height=e.height),u
      }
    this.allocateTextureUnit=function(){
      let e=C;
      return e>=a.maxTextures&&(0,n.warn)("WebGLTextures: Trying to use "+e+" texture units while this GPU supports only "+a.maxTextures),C+=1,e
      },this.resetTextureUnits=function(){
      C=0
      },this.getTextureUnits=function(){
      return C
      },this.setTextureUnits=function(e){
      C=e
      },this.setTexture2D=b,this.setTexture2DArray=function(n,t){
      let a=i.get(n);
      !1===n.isRenderTargetTexture&&n.version>0&&a.__version!==n.version?I(a,n,t):(n.isExternalTexture&&(a.__webglTexture=n.sourceTexture?n.sourceTexture:null),r.bindTexture(e.TEXTURE_2D_ARRAY,a.__webglTexture,e.TEXTURE0+t))
      },this.setTexture3D=function(n,t){
      let a=i.get(n);
      !1===n.isRenderTargetTexture&&n.version>0&&a.__version!==n.version?I(a,n,t):r.bindTexture(e.TEXTURE_3D,a.__webglTexture,e.TEXTURE0+t)
      },this.setTextureCube=function(t,l){
      let s=i.get(t);
      !0!==t.isCubeDepthTexture&&t.version>0&&s.__version!==t.version?function(t,l,s){
        if(6!==l.image.length)
        return;
        let c=w(t,l),d=l.source;
        r.bindTexture(e.TEXTURE_CUBE_MAP,t.__webglTexture,e.TEXTURE0+s);
        let u=i.get(d);
        if(d.version!==u.__version||!0===c){
          let t;
          r.activeTexture(e.TEXTURE0+s);
          let i=n.ColorManagement.getPrimaries(n.ColorManagement.workingColorSpace),f=l.colorSpace===n.NoColorSpace?null:n.ColorManagement.getPrimaries(l.colorSpace),p=l.colorSpace===n.NoColorSpace||i===f?e.NONE:e.BROWSER_DEFAULT_WEBGL;
          r.pixelStorei(e.UNPACK_FLIP_Y_WEBGL,l.flipY),r.pixelStorei(e.UNPACK_PREMULTIPLY_ALPHA_WEBGL,l.premultiplyAlpha),r.pixelStorei(e.UNPACK_ALIGNMENT,l.unpackAlignment),r.pixelStorei(e.UNPACK_COLORSPACE_CONVERSION_WEBGL,p);
          let m=l.isCompressedTexture||l.image[0].isCompressedTexture,_=l.image[0]&&l.image[0].isDataTexture,h=[];
          for(
          let e=0
          ;e<6;e++)
          m||_?h[e]=_?l.image[e].image:l.image[e]:h[e]=g(l.image[e],!0,a.maxCubemapSize),h[e]=z(l,h[e]);
          let T=h[0],x=o.convert(l.format,l.colorSpace),R=o.convert(l.type),A=E(l.internalFormat,x,R,l.normalized,l.colorSpace),C=!0!==l.isVideoTexture,b=void 0===u.__version||!0===c,P=d.dataReady,L=M(l,T);
          if(D(e.TEXTURE_CUBE_MAP,l),m){
            C&&b&&r.texStorage2D(e.TEXTURE_CUBE_MAP,L,A,T.width,T.height);
            for(
            let i=0
            ;i<6;i++){
              t=h[i].mipmaps;
              for(
              let a=0
              ;a<t.length;a++){
                let o=t[a];
                l.format!==n.RGBAFormat?null!==x?C?P&&r.compressedTexSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+i,a,0,0,o.width,o.height,x,o.data):r.compressedTexImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+i,a,A,o.width,o.height,0,o.data):(0,n.warn)("WebGLRenderer: Attempt to load unsupported compressed texture format in .setTextureCube()"):C?P&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+i,a,0,0,o.width,o.height,x,R,o.data):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+i,a,A,o.width,o.height,0,x,R,o.data)
                }
              }
            }else{
            if(t=l.mipmaps,C&&b){
              t.length>0&&L++;
              let n=k(h[0]);
              r.texStorage2D(e.TEXTURE_CUBE_MAP,L,A,n.width,n.height)
              }
            for(
            let n=0
            ;n<6;n++)
            if(_){
              C?P&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,0,0,h[n].width,h[n].height,x,R,h[n].data):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,A,h[n].width,h[n].height,0,x,R,h[n].data);
              for(
              let i=0
              ;i<t.length;i++){
                let a=t[i].image[n].image;
                C?P&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,i+1,0,0,a.width,a.height,x,R,a.data):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,i+1,A,a.width,a.height,0,x,R,a.data)
                }
              }else{
              C?P&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,0,0,x,R,h[n]):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,0,A,x,R,h[n]);
              for(
              let i=0
              ;i<t.length;i++){
                let a=t[i];
                C?P&&r.texSubImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,i+1,0,0,x,R,a.image[n]):r.texImage2D(e.TEXTURE_CUBE_MAP_POSITIVE_X+n,i+1,A,x,R,a.image[n])
                }
              }
            }
          v(l)&&S(e.TEXTURE_CUBE_MAP),u.__version=d.version,l.onUpdate&&l.onUpdate(l)
          }
        t.__version=l.version
        }(s,t,l):r.bindTexture(e.TEXTURE_CUBE_MAP,s.__webglTexture,e.TEXTURE0+l)
      },this.rebindTextures=function(n,t,r){
      let a=i.get(n);
      void 0!==t&&y(a.__webglFramebuffer,n,n.texture,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,0),void 0!==r&&B(n)
      },this.setupRenderTarget=function(n){
      let t=n.texture,a=i.get(n),s=i.get(t);
      n.addEventListener("dispose",R);
      let c=n.textures,d=!0===n.isWebGLCubeRenderTarget,u=c.length>1;
      if(!u&&(void 0===s.__webglTexture&&(s.__webglTexture=e.createTexture()),s.__version=t.version,l.memory.textures++),d){
        a.__webglFramebuffer=[];
        for(
        let n=0
        ;n<6;n++)
        if(t.mipmaps&&t.mipmaps.length>0){
          a.__webglFramebuffer[n]=[];
          for(
          let r=0
          ;r<t.mipmaps.length;r++)
          a.__webglFramebuffer[n][r]=e.createFramebuffer()
          }else 
        a.__webglFramebuffer[n]=e.createFramebuffer()
        }else{
        if(t.mipmaps&&t.mipmaps.length>0){
          a.__webglFramebuffer=[];
          for(
          let n=0
          ;n<t.mipmaps.length;n++)
          a.__webglFramebuffer[n]=e.createFramebuffer()
          }else 
        a.__webglFramebuffer=e.createFramebuffer();
        if(u)
        for(
        let n=0,t=c.length
        ;n<t;n++){
          let t=i.get(c[n]);
          void 0===t.__webglTexture&&(t.__webglTexture=e.createTexture(),l.memory.textures++)
          }
        if(n.samples>0&&!1===W(n)){
          a.__webglMultisampledFramebuffer=e.createFramebuffer(),a.__webglColorRenderbuffer=[],r.bindFramebuffer(e.FRAMEBUFFER,a.__webglMultisampledFramebuffer);
          for(
          let t=0
          ;t<c.length;t++){
            let r=c[t];
            a.__webglColorRenderbuffer[t]=e.createRenderbuffer(),e.bindRenderbuffer(e.RENDERBUFFER,a.__webglColorRenderbuffer[t]);
            let i=o.convert(r.format,r.colorSpace),l=o.convert(r.type),s=E(r.internalFormat,i,l,r.normalized,r.colorSpace,!0===n.isXRRenderTarget),d=V(n);
            e.renderbufferStorageMultisample(e.RENDERBUFFER,d,s,n.width,n.height),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+t,e.RENDERBUFFER,a.__webglColorRenderbuffer[t])
            }
          e.bindRenderbuffer(e.RENDERBUFFER,null),n.depthBuffer&&(a.__webglDepthRenderbuffer=e.createRenderbuffer(),F(a.__webglDepthRenderbuffer,n,!0)),r.bindFramebuffer(e.FRAMEBUFFER,null)
          }
        }
      if(d){
        r.bindTexture(e.TEXTURE_CUBE_MAP,s.__webglTexture),D(e.TEXTURE_CUBE_MAP,t);
        for(
        let r=0
        ;r<6;r++)
        if(t.mipmaps&&t.mipmaps.length>0)
        for(
        let i=0
        ;i<t.mipmaps.length;i++)
        y(a.__webglFramebuffer[r][i],n,t,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+r,i);
        else 
        y(a.__webglFramebuffer[r],n,t,e.COLOR_ATTACHMENT0,e.TEXTURE_CUBE_MAP_POSITIVE_X+r,0);
        v(t)&&S(e.TEXTURE_CUBE_MAP),r.unbindTexture()
        }else 
      if(u){
        for(
        let t=0,o=c.length
        ;t<o;t++){
          let o=c[t],l=i.get(o),s=e.TEXTURE_2D;
          (n.isWebGL3DRenderTarget||n.isWebGLArrayRenderTarget)&&(s=n.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),r.bindTexture(s,l.__webglTexture),D(s,o),y(a.__webglFramebuffer,n,o,e.COLOR_ATTACHMENT0+t,s,0),v(o)&&S(s)
          }
        r.unbindTexture()
        }else{
        let i=e.TEXTURE_2D;
        if((n.isWebGL3DRenderTarget||n.isWebGLArrayRenderTarget)&&(i=n.isWebGL3DRenderTarget?e.TEXTURE_3D:e.TEXTURE_2D_ARRAY),r.bindTexture(i,s.__webglTexture),D(i,t),t.mipmaps&&t.mipmaps.length>0)
        for(
        let r=0
        ;r<t.mipmaps.length;r++)
        y(a.__webglFramebuffer[r],n,t,e.COLOR_ATTACHMENT0,i,r);
        else 
        y(a.__webglFramebuffer,n,t,e.COLOR_ATTACHMENT0,i,0);
        v(t)&&S(i),r.unbindTexture()
        }
      n.depthBuffer&&B(n)
      },this.updateRenderTargetMipmap=function(n){
      let t=n.textures;
      for(
      let a=0,o=t.length
      ;a<o;a++){
        let o=t[a];
        if(v(o)){
          let t=n.isWebGLCubeRenderTarget?e.TEXTURE_CUBE_MAP:n.isWebGL3DRenderTarget?e.TEXTURE_3D:n.isWebGLArrayRenderTarget||n.isCompressedArrayTexture?e.TEXTURE_2D_ARRAY:e.TEXTURE_2D,a=i.get(o).__webglTexture;
          r.bindTexture(t,a),S(t),r.unbindTexture()
          }
        }
      },this.updateMultisampleRenderTarget=function(n){
      if(n.samples>0){
        if(!1===W(n)){
          let t=n.textures,a=n.width,o=n.height,l=e.COLOR_BUFFER_BIT,s=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT,c=i.get(n),u=t.length>1;
          if(u)
          for(
          let n=0
          ;n<t.length;n++)
          r.bindFramebuffer(e.FRAMEBUFFER,c.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,null),r.bindFramebuffer(e.FRAMEBUFFER,c.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.TEXTURE_2D,null,0);
          r.bindFramebuffer(e.READ_FRAMEBUFFER,c.__webglMultisampledFramebuffer);
          let f=n.texture.mipmaps;
          f&&f.length>0?r.bindFramebuffer(e.DRAW_FRAMEBUFFER,c.__webglFramebuffer[0]):r.bindFramebuffer(e.DRAW_FRAMEBUFFER,c.__webglFramebuffer);
          for(
          let r=0
          ;r<t.length;r++){
            if(n.resolveDepthBuffer&&(n.depthBuffer&&(l|=e.DEPTH_BUFFER_BIT),n.stencilBuffer&&n.resolveStencilBuffer&&(l|=e.STENCIL_BUFFER_BIT)),u){
              e.framebufferRenderbuffer(e.READ_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.RENDERBUFFER,c.__webglColorRenderbuffer[r]);
              let n=i.get(t[r]).__webglTexture;
              e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0,e.TEXTURE_2D,n,0)
              }
            e.blitFramebuffer(0,0,a,o,0,0,a,o,l,e.NEAREST),!0===d&&(G.length=0,H.length=0,G.push(e.COLOR_ATTACHMENT0+r),n.depthBuffer&&!1===n.resolveDepthBuffer&&(G.push(s),H.push(s),e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,H)),e.invalidateFramebuffer(e.READ_FRAMEBUFFER,G))
            }
          if(r.bindFramebuffer(e.READ_FRAMEBUFFER,null),r.bindFramebuffer(e.DRAW_FRAMEBUFFER,null),u)
          for(
          let n=0
          ;n<t.length;n++){
            r.bindFramebuffer(e.FRAMEBUFFER,c.__webglMultisampledFramebuffer),e.framebufferRenderbuffer(e.FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.RENDERBUFFER,c.__webglColorRenderbuffer[n]);
            let a=i.get(t[n]).__webglTexture;
            r.bindFramebuffer(e.FRAMEBUFFER,c.__webglFramebuffer),e.framebufferTexture2D(e.DRAW_FRAMEBUFFER,e.COLOR_ATTACHMENT0+n,e.TEXTURE_2D,a,0)
            }
          r.bindFramebuffer(e.DRAW_FRAMEBUFFER,c.__webglMultisampledFramebuffer)
          }else 
        if(n.depthBuffer&&!1===n.resolveDepthBuffer&&d){
          let t=n.stencilBuffer?e.DEPTH_STENCIL_ATTACHMENT:e.DEPTH_ATTACHMENT;
          e.invalidateFramebuffer(e.DRAW_FRAMEBUFFER,[t])
          }
        }
      },this.setupDepthRenderbuffer=B,this.setupFrameBufferTexture=y,this.useMultisampledRTT=W,this.isReversedDepthBuffer=function(){
      return r.buffers.depth.getReversed()
      }
    }
  function nR(e,t){
    return{convert:function(r,i=n.NoColorSpace){
      let a,o=n.ColorManagement.getTransfer(i);
      if(r===n.UnsignedByteType)
      return e.UNSIGNED_BYTE;
      if(r===n.UnsignedShort4444Type)
      return e.UNSIGNED_SHORT_4_4_4_4;
      if(r===n.UnsignedShort5551Type)
      return e.UNSIGNED_SHORT_5_5_5_1;
      if(r===n.UnsignedInt5999Type)
      return e.UNSIGNED_INT_5_9_9_9_REV;
      if(r===n.UnsignedInt101111Type)
      return e.UNSIGNED_INT_10F_11F_11F_REV;
      if(r===n.ByteType)
      return e.BYTE;
      if(r===n.ShortType)
      return e.SHORT;
      if(r===n.UnsignedShortType)
      return e.UNSIGNED_SHORT;
      if(r===n.IntType)
      return e.INT;
      if(r===n.UnsignedIntType)
      return e.UNSIGNED_INT;
      if(r===n.FloatType)
      return e.FLOAT;
      if(r===n.HalfFloatType)
      return e.HALF_FLOAT;
      if(r===n.AlphaFormat)
      return e.ALPHA;
      if(r===n.RGBFormat)
      return e.RGB;
      if(r===n.RGBAFormat)
      return e.RGBA;
      if(r===n.DepthFormat)
      return e.DEPTH_COMPONENT;
      if(r===n.DepthStencilFormat)
      return e.DEPTH_STENCIL;
      if(r===n.RedFormat)
      return e.RED;
      if(r===n.RedIntegerFormat)
      return e.RED_INTEGER;
      if(r===n.RGFormat)
      return e.RG;
      if(r===n.RGIntegerFormat)
      return e.RG_INTEGER;
      if(r===n.RGBAIntegerFormat)
      return e.RGBA_INTEGER;
      if(r===n.RGB_S3TC_DXT1_Format||r===n.RGBA_S3TC_DXT1_Format||r===n.RGBA_S3TC_DXT3_Format||r===n.RGBA_S3TC_DXT5_Format)
      if(o===n.SRGBTransfer){
        if(null===(a=t.get("WEBGL_compressed_texture_s3tc_srgb")))
        return null;
        if(r===n.RGB_S3TC_DXT1_Format)
        return a.COMPRESSED_SRGB_S3TC_DXT1_EXT;
        if(r===n.RGBA_S3TC_DXT1_Format)
        return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT1_EXT;
        if(r===n.RGBA_S3TC_DXT3_Format)
        return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT3_EXT;
        if(r===n.RGBA_S3TC_DXT5_Format)
        return a.COMPRESSED_SRGB_ALPHA_S3TC_DXT5_EXT
        }else{
        if(null===(a=t.get("WEBGL_compressed_texture_s3tc")))
        return null;
        if(r===n.RGB_S3TC_DXT1_Format)
        return a.COMPRESSED_RGB_S3TC_DXT1_EXT;
        if(r===n.RGBA_S3TC_DXT1_Format)
        return a.COMPRESSED_RGBA_S3TC_DXT1_EXT;
        if(r===n.RGBA_S3TC_DXT3_Format)
        return a.COMPRESSED_RGBA_S3TC_DXT3_EXT;
        if(r===n.RGBA_S3TC_DXT5_Format)
        return a.COMPRESSED_RGBA_S3TC_DXT5_EXT
        }
      if(r===n.RGB_PVRTC_4BPPV1_Format||r===n.RGB_PVRTC_2BPPV1_Format||r===n.RGBA_PVRTC_4BPPV1_Format||r===n.RGBA_PVRTC_2BPPV1_Format){
        if(null===(a=t.get("WEBGL_compressed_texture_pvrtc")))
        return null;
        if(r===n.RGB_PVRTC_4BPPV1_Format)
        return a.COMPRESSED_RGB_PVRTC_4BPPV1_IMG;
        if(r===n.RGB_PVRTC_2BPPV1_Format)
        return a.COMPRESSED_RGB_PVRTC_2BPPV1_IMG;
        if(r===n.RGBA_PVRTC_4BPPV1_Format)
        return a.COMPRESSED_RGBA_PVRTC_4BPPV1_IMG;
        if(r===n.RGBA_PVRTC_2BPPV1_Format)
        return a.COMPRESSED_RGBA_PVRTC_2BPPV1_IMG
        }
      if(r===n.RGB_ETC1_Format||r===n.RGB_ETC2_Format||r===n.RGBA_ETC2_EAC_Format||r===n.R11_EAC_Format||r===n.SIGNED_R11_EAC_Format||r===n.RG11_EAC_Format||r===n.SIGNED_RG11_EAC_Format){
        if(null===(a=t.get("WEBGL_compressed_texture_etc")))
        return null;
        if(r===n.RGB_ETC1_Format||r===n.RGB_ETC2_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ETC2:a.COMPRESSED_RGB8_ETC2;
        if(r===n.RGBA_ETC2_EAC_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ETC2_EAC:a.COMPRESSED_RGBA8_ETC2_EAC;
        if(r===n.R11_EAC_Format)
        return a.COMPRESSED_R11_EAC;
        if(r===n.SIGNED_R11_EAC_Format)
        return a.COMPRESSED_SIGNED_R11_EAC;
        if(r===n.RG11_EAC_Format)
        return a.COMPRESSED_RG11_EAC;
        if(r===n.SIGNED_RG11_EAC_Format)
        return a.COMPRESSED_SIGNED_RG11_EAC
        }
      if(r===n.RGBA_ASTC_4x4_Format||r===n.RGBA_ASTC_5x4_Format||r===n.RGBA_ASTC_5x5_Format||r===n.RGBA_ASTC_6x5_Format||r===n.RGBA_ASTC_6x6_Format||r===n.RGBA_ASTC_8x5_Format||r===n.RGBA_ASTC_8x6_Format||r===n.RGBA_ASTC_8x8_Format||r===n.RGBA_ASTC_10x5_Format||r===n.RGBA_ASTC_10x6_Format||r===n.RGBA_ASTC_10x8_Format||r===n.RGBA_ASTC_10x10_Format||r===n.RGBA_ASTC_12x10_Format||r===n.RGBA_ASTC_12x12_Format){
        if(null===(a=t.get("WEBGL_compressed_texture_astc")))
        return null;
        if(r===n.RGBA_ASTC_4x4_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_4x4_KHR:a.COMPRESSED_RGBA_ASTC_4x4_KHR;
        if(r===n.RGBA_ASTC_5x4_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x4_KHR:a.COMPRESSED_RGBA_ASTC_5x4_KHR;
        if(r===n.RGBA_ASTC_5x5_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_5x5_KHR:a.COMPRESSED_RGBA_ASTC_5x5_KHR;
        if(r===n.RGBA_ASTC_6x5_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x5_KHR:a.COMPRESSED_RGBA_ASTC_6x5_KHR;
        if(r===n.RGBA_ASTC_6x6_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_6x6_KHR:a.COMPRESSED_RGBA_ASTC_6x6_KHR;
        if(r===n.RGBA_ASTC_8x5_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x5_KHR:a.COMPRESSED_RGBA_ASTC_8x5_KHR;
        if(r===n.RGBA_ASTC_8x6_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x6_KHR:a.COMPRESSED_RGBA_ASTC_8x6_KHR;
        if(r===n.RGBA_ASTC_8x8_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_8x8_KHR:a.COMPRESSED_RGBA_ASTC_8x8_KHR;
        if(r===n.RGBA_ASTC_10x5_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x5_KHR:a.COMPRESSED_RGBA_ASTC_10x5_KHR;
        if(r===n.RGBA_ASTC_10x6_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x6_KHR:a.COMPRESSED_RGBA_ASTC_10x6_KHR;
        if(r===n.RGBA_ASTC_10x8_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x8_KHR:a.COMPRESSED_RGBA_ASTC_10x8_KHR;
        if(r===n.RGBA_ASTC_10x10_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_10x10_KHR:a.COMPRESSED_RGBA_ASTC_10x10_KHR;
        if(r===n.RGBA_ASTC_12x10_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x10_KHR:a.COMPRESSED_RGBA_ASTC_12x10_KHR;
        if(r===n.RGBA_ASTC_12x12_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB8_ALPHA8_ASTC_12x12_KHR:a.COMPRESSED_RGBA_ASTC_12x12_KHR
        }
      if(r===n.RGBA_BPTC_Format||r===n.RGB_BPTC_SIGNED_Format||r===n.RGB_BPTC_UNSIGNED_Format){
        if(null===(a=t.get("EXT_texture_compression_bptc")))
        return null;
        if(r===n.RGBA_BPTC_Format)
        return o===n.SRGBTransfer?a.COMPRESSED_SRGB_ALPHA_BPTC_UNORM_EXT:a.COMPRESSED_RGBA_BPTC_UNORM_EXT;
        if(r===n.RGB_BPTC_SIGNED_Format)
        return a.COMPRESSED_RGB_BPTC_SIGNED_FLOAT_EXT;
        if(r===n.RGB_BPTC_UNSIGNED_Format)
        return a.COMPRESSED_RGB_BPTC_UNSIGNED_FLOAT_EXT
        }
      if(r===n.RED_RGTC1_Format||r===n.SIGNED_RED_RGTC1_Format||r===n.RED_GREEN_RGTC2_Format||r===n.SIGNED_RED_GREEN_RGTC2_Format){
        if(null===(a=t.get("EXT_texture_compression_rgtc")))
        return null;
        if(r===n.RED_RGTC1_Format)
        return a.COMPRESSED_RED_RGTC1_EXT;
        if(r===n.SIGNED_RED_RGTC1_Format)
        return a.COMPRESSED_SIGNED_RED_RGTC1_EXT;
        if(r===n.RED_GREEN_RGTC2_Format)
        return a.COMPRESSED_RED_GREEN_RGTC2_EXT;
        if(r===n.SIGNED_RED_GREEN_RGTC2_Format)
        return a.COMPRESSED_SIGNED_RED_GREEN_RGTC2_EXT
        }
      return r===n.UnsignedInt248Type?e.UNSIGNED_INT_24_8:void 0!==e[r]?e[r]:null
      }}
    }
  let nA=`
void main() {

	gl_Position = vec4( position, 1.0 );

}`,nC=`
uniform sampler2DArray depthColor;
uniform float depthWidth;
uniform float depthHeight;

void main() {

	vec2 coord = vec2( gl_FragCoord.x / depthWidth, gl_FragCoord.y / depthHeight );

	if ( coord.x >= 1.0 ) {

		gl_FragDepth = texture( depthColor, vec3( coord.x - 1.0, coord.y, 1 ) ).r;

	} else {

		gl_FragDepth = texture( depthColor, vec3( coord.x, coord.y, 0 ) ).r;

	}

}`;
  class nb{
    constructor(){
      this.texture=null,this.mesh=null,this.depthNear=0,this.depthFar=0
      }init(e,t){
      if(null===this.texture){
        let r=new n.ExternalTexture(e.texture);
        (e.depthNear!==t.depthNear||e.depthFar!==t.depthFar)&&(this.depthNear=e.depthNear,this.depthFar=e.depthFar),this.texture=r
        }
      }getMesh(e){
      if(null!==this.texture&&null===this.mesh){
        let t=e.cameras[0].viewport,r=new n.ShaderMaterial({vertexShader:nA,fragmentShader:nC,uniforms:{depthColor:{value:this.texture},depthWidth:{value:t.z},depthHeight:{value:t.w}}});
        this.mesh=new n.Mesh(new n.PlaneGeometry(20,20),r)
        }
      return this.mesh
      }reset(){
      this.texture=null,this.mesh=null
      }getDepthTexture(){
      return this.texture
      }
  }
  class nP extends n.EventDispatcher{
    constructor(e,r){
      super();
      const i=this;
      let a=null,o=1,l=null,s="local-floor",c=1,d=null,u=null,f=null,p=null,m=null,_=null;
      const h="u">typeof XRWebGLBinding,g=new nb,v={},S=r.getContextAttributes();
      let E=null,T=null;
      const M=[],x=[],R=new n.Vector2;
      let A=null;
      const C=new n.PerspectiveCamera;
      C.viewport=new n.Vector4;
      const b=new n.PerspectiveCamera;
      b.viewport=new n.Vector4;
      const P=[C,b],L=new n.ArrayCamera;
      let U=null,D=null;
      function w(e){
        let n=x.indexOf(e.inputSource);
        if(-1===n)
        return;
        let t=M[n];
        void 0!==t&&(t.update(e.inputSource,e.frame,d||l),t.dispatchEvent({type:e.type,data:e.inputSource}))
        }
      function N(){
        a.removeEventListener("select",w),a.removeEventListener("selectstart",w),a.removeEventListener("selectend",w),a.removeEventListener("squeeze",w),a.removeEventListener("squeezestart",w),a.removeEventListener("squeezeend",w),a.removeEventListener("end",N),a.removeEventListener("inputsourceschange",I);
        for(
        let e=0
        ;e<M.length;e++){
          let n=x[e];
          null!==n&&(x[e]=null,M[e].disconnect(n))
          }
        for(
        let e
         in U=null,D=null,g.reset(),v)
        delete v[e];
        e.setRenderTarget(E),m=null,p=null,f=null,a=null,T=null,G.stop(),i.isPresenting=!1,e.setPixelRatio(A),e.setSize(R.width,R.height,!1),i.dispatchEvent({type:"sessionend"})
        }
      function I(e){
        for(
        let n=0
        ;n<e.removed.length;n++){
          let t=e.removed[n],r=x.indexOf(t);
          r>=0&&(x[r]=null,M[r].disconnect(t))
          }
        for(
        let n=0
        ;n<e.added.length;n++){
          let t=e.added[n],r=x.indexOf(t);
          if(-1===r){
            for(
            let e=0
            ;e<M.length;e++)
            if(e>=x.length){
              x.push(t),r=e;
              break
              }else 
            if(null===x[e]){
              x[e]=t,r=e;
              break
              }
            if(-1===r)
            break
            }
          let i=M[r];
          i&&i.connect(t)
          }
        }
      this.cameraAutoUpdate=!0,this.enabled=!1,this.isPresenting=!1,this.getController=function(e){
        let t=M[e];
        return void 0===t&&(t=new n.WebXRController,M[e]=t),t.getTargetRaySpace()
        },this.getControllerGrip=function(e){
        let t=M[e];
        return void 0===t&&(t=new n.WebXRController,M[e]=t),t.getGripSpace()
        },this.getHand=function(e){
        let t=M[e];
        return void 0===t&&(t=new n.WebXRController,M[e]=t),t.getHandSpace()
        },this.setFramebufferScaleFactor=function(e){
        o=e,!0===i.isPresenting&&(0,n.warn)("WebXRManager: Cannot change framebuffer scale while presenting.")
        },this.setReferenceSpaceType=function(e){
        s=e,!0===i.isPresenting&&(0,n.warn)("WebXRManager: Cannot change reference space type while presenting.")
        },this.getReferenceSpace=function(){
        return d||l
        },this.setReferenceSpace=function(e){
        d=e
        },this.getBaseLayer=function(){
        return null!==p?p:m
        },this.getBinding=function(){
        return null===f&&h&&(f=new XRWebGLBinding(a,r)),f
        },this.getFrame=function(){
        return _
        },this.getSession=function(){
        return a
        },this.setSession=async function(t){
        if(null!==(a=t)){
          if(E=e.getRenderTarget(),a.addEventListener("select",w),a.addEventListener("selectstart",w),a.addEventListener("selectend",w),a.addEventListener("squeeze",w),a.addEventListener("squeezestart",w),a.addEventListener("squeezeend",w),a.addEventListener("end",N),a.addEventListener("inputsourceschange",I),!0!==S.xrCompatible&&await r.makeXRCompatible(),A=e.getPixelRatio(),e.getSize(R),h&&"createProjectionLayer"in XRWebGLBinding.prototype){
            let t=null,i=null,l=null;
            S.depth&&(l=S.stencil?r.DEPTH24_STENCIL8:r.DEPTH_COMPONENT24,t=S.stencil?n.DepthStencilFormat:n.DepthFormat,i=S.stencil?n.UnsignedInt248Type:n.UnsignedIntType);
            let s={colorFormat:r.RGBA8,depthFormat:l,scaleFactor:o};
            p=(f=this.getBinding()).createProjectionLayer(s),a.updateRenderState({layers:[p]}),e.setPixelRatio(1),e.setSize(p.textureWidth,p.textureHeight,!1),T=new n.WebGLRenderTarget(p.textureWidth,p.textureHeight,{format:n.RGBAFormat,type:n.UnsignedByteType,depthTexture:new n.DepthTexture(p.textureWidth,p.textureHeight,i,void 0,void 0,void 0,void 0,void 0,void 0,t),stencilBuffer:S.stencil,colorSpace:e.outputColorSpace,samples:4*!!S.antialias,resolveDepthBuffer:!1===p.ignoreDepthValues,resolveStencilBuffer:!1===p.ignoreDepthValues})
            }else{
            let t={antialias:S.antialias,alpha:!0,depth:S.depth,stencil:S.stencil,framebufferScaleFactor:o};
            m=new XRWebGLLayer(a,r,t),a.updateRenderState({baseLayer:m}),e.setPixelRatio(1),e.setSize(m.framebufferWidth,m.framebufferHeight,!1),T=new n.WebGLRenderTarget(m.framebufferWidth,m.framebufferHeight,{format:n.RGBAFormat,type:n.UnsignedByteType,colorSpace:e.outputColorSpace,stencilBuffer:S.stencil,resolveDepthBuffer:!1===m.ignoreDepthValues,resolveStencilBuffer:!1===m.ignoreDepthValues})
            }
          T.isXRRenderTarget=!0,this.setFoveation(c),d=null,l=await a.requestReferenceSpace(s),G.setContext(a),G.start(),i.isPresenting=!0,i.dispatchEvent({type:"sessionstart"})
          }
        },this.getEnvironmentBlendMode=function(){
        if(null!==a)
        return a.environmentBlendMode
        },this.getDepthTexture=function(){
        return g.getDepthTexture()
        };
      const y=new n.Vector3,F=new n.Vector3;
      function O(e,n){
        null===n?e.matrixWorld.copy(e.matrix):e.matrixWorld.multiplyMatrices(n.matrixWorld,e.matrix),e.matrixWorldInverse.copy(e.matrixWorld).invert()
        }
      this.updateCamera=function(e){
        var t,r,i;
        if(null===a)
        return;
        let o=e.near,l=e.far;
        null!==g.texture&&(g.depthNear>0&&(o=g.depthNear),g.depthFar>0&&(l=g.depthFar)),L.near=b.near=C.near=o,L.far=b.far=C.far=l,(U!==L.near||D!==L.far)&&(a.updateRenderState({depthNear:L.near,depthFar:L.far}),U=L.near,D=L.far),L.layers.mask=6|e.layers.mask,C.layers.mask=-5&L.layers.mask,b.layers.mask=-3&L.layers.mask;
        let s=e.parent,c=L.cameras;
        O(L,s);
        for(
        let e=0
        ;e<c.length;e++)
        O(c[e],s);
        2===c.length?function(e,n,t){
          y.setFromMatrixPosition(n.matrixWorld),F.setFromMatrixPosition(t.matrixWorld);
          let r=y.distanceTo(F),i=n.projectionMatrix.elements,a=t.projectionMatrix.elements,o=i[14]/(i[10]-1),l=i[14]/(i[10]+1),s=(i[9]+1)/i[5],c=(i[9]-1)/i[5],d=(i[8]-1)/i[0],u=(a[8]+1)/a[0],f=r/(-d+u),p=-(f*d);
          if(n.matrixWorld.decompose(e.position,e.quaternion,e.scale),e.translateX(p),e.translateZ(f),e.matrixWorld.compose(e.position,e.quaternion,e.scale),e.matrixWorldInverse.copy(e.matrixWorld).invert(),-1===i[10])
          e.projectionMatrix.copy(n.projectionMatrix),e.projectionMatrixInverse.copy(n.projectionMatrixInverse);
          else{
            let n=o+f,t=l+f;
            e.projectionMatrix.makePerspective(o*d-p,o*u+(r-p),s*l/t*n,c*l/t*n,n,t),e.projectionMatrixInverse.copy(e.projectionMatrix).invert()
            }
          }(L,C,b):L.projectionMatrix.copy(C.projectionMatrix),t=e,r=L,null===(i=s)?t.matrix.copy(r.matrixWorld):(t.matrix.copy(i.matrixWorld),t.matrix.invert(),t.matrix.multiply(r.matrixWorld)),t.matrix.decompose(t.position,t.quaternion,t.scale),t.updateMatrixWorld(!0),t.projectionMatrix.copy(r.projectionMatrix),t.projectionMatrixInverse.copy(r.projectionMatrixInverse),t.isPerspectiveCamera&&(t.fov=2*n.RAD2DEG*Math.atan(1/t.projectionMatrix.elements[5]),t.zoom=1)
        },this.getCamera=function(){
        return L
        },this.getFoveation=function(){
        if(null!==p||null!==m)
        return c
        },this.setFoveation=function(e){
        c=e,null!==p&&(p.fixedFoveation=e),null!==m&&void 0!==m.fixedFoveation&&(m.fixedFoveation=e)
        },this.hasDepthSensing=function(){
        return null!==g.texture
        },this.getDepthSensingMesh=function(){
        return g.getMesh(L)
        },this.getCameraTexture=function(e){
        return v[e]
        };
      let B=null;
      const G=new t;
      G.setAnimationLoop(function(t,r){
        if(u=r.getViewerPose(d||l),_=r,null!==u){
          let t=u.views;
          null!==m&&(e.setRenderTargetFramebuffer(T,m.framebuffer),e.setRenderTarget(T));
          let r=!1;
          t.length!==L.cameras.length&&(L.cameras.length=0,r=!0);
          for(
          let i=0
          ;i<t.length;i++){
            let a=t[i],o=null;
            if(null!==m)
            o=m.getViewport(a);
            else{
              let n=f.getViewSubImage(p,a);
              o=n.viewport,0===i&&(e.setRenderTargetTextures(T,n.colorTexture,n.depthStencilTexture),e.setRenderTarget(T))
              }
            let l=P[i];
            void 0===l&&((l=new n.PerspectiveCamera).layers.enable(i),l.viewport=new n.Vector4,P[i]=l),l.matrix.fromArray(a.transform.matrix),l.matrix.decompose(l.position,l.quaternion,l.scale),l.projectionMatrix.fromArray(a.projectionMatrix),l.projectionMatrixInverse.copy(l.projectionMatrix).invert(),l.viewport.set(o.x,o.y,o.width,o.height),0===i&&(L.matrix.copy(l.matrix),L.matrix.decompose(L.position,L.quaternion,L.scale)),!0===r&&L.cameras.push(l)
            }
          let o=a.enabledFeatures;
          if(o&&o.includes("depth-sensing")&&"gpu-optimized"==a.depthUsage&&h){
            let e=(f=i.getBinding()).getDepthInformation(t[0]);
            e&&e.isValid&&e.texture&&g.init(e,a.renderState)
            }
          if(o&&o.includes("camera-access")&&h){
            e.state.unbindTexture(),f=i.getBinding();
            for(
            let e=0
            ;e<t.length;e++){
              let r=t[e].camera;
              if(r){
                let e=v[r];
                e||(e=new n.ExternalTexture,v[r]=e);
                let t=f.getCameraImage(r);
                e.sourceTexture=t
                }
              }
            }
          }
        for(
        let e=0
        ;e<M.length;e++){
          let n=x[e],t=M[e];
          null!==n&&void 0!==t&&t.update(n,r,d||l)
          }
        B&&B(t,r),r.detectedPlanes&&i.dispatchEvent({type:"planesdetected",data:r}),_=null
        }),this.setAnimationLoop=function(e){
        B=e
        },this.dispose=function(){
        }
      }
  }
  let nL=new n.Matrix4,nU=new n.Matrix3;
  function nD(e,t){
    function r(e,n){
      !0===e.matrixAutoUpdate&&e.updateMatrix(),n.value.copy(e.matrix)
      }
    function i(e,i){
      e.opacity.value=i.opacity,i.color&&e.diffuse.value.copy(i.color),i.emissive&&e.emissive.value.copy(i.emissive).multiplyScalar(i.emissiveIntensity),i.map&&(e.map.value=i.map,r(i.map,e.mapTransform)),i.alphaMap&&(e.alphaMap.value=i.alphaMap,r(i.alphaMap,e.alphaMapTransform)),i.bumpMap&&(e.bumpMap.value=i.bumpMap,r(i.bumpMap,e.bumpMapTransform),e.bumpScale.value=i.bumpScale,i.side===n.BackSide&&(e.bumpScale.value*=-1)),i.normalMap&&(e.normalMap.value=i.normalMap,r(i.normalMap,e.normalMapTransform),e.normalScale.value.copy(i.normalScale),i.side===n.BackSide&&e.normalScale.value.negate()),i.displacementMap&&(e.displacementMap.value=i.displacementMap,r(i.displacementMap,e.displacementMapTransform),e.displacementScale.value=i.displacementScale,e.displacementBias.value=i.displacementBias),i.emissiveMap&&(e.emissiveMap.value=i.emissiveMap,r(i.emissiveMap,e.emissiveMapTransform)),i.specularMap&&(e.specularMap.value=i.specularMap,r(i.specularMap,e.specularMapTransform)),i.alphaTest>0&&(e.alphaTest.value=i.alphaTest);
      let a=t.get(i),o=a.envMap,l=a.envMapRotation;
      o&&(e.envMap.value=o,e.envMapRotation.value.setFromMatrix4(nL.makeRotationFromEuler(l)).transpose(),o.isCubeTexture&&!1===o.isRenderTargetTexture&&e.envMapRotation.value.premultiply(nU),e.reflectivity.value=i.reflectivity,e.ior.value=i.ior,e.refractionRatio.value=i.refractionRatio),i.lightMap&&(e.lightMap.value=i.lightMap,e.lightMapIntensity.value=i.lightMapIntensity,r(i.lightMap,e.lightMapTransform)),i.aoMap&&(e.aoMap.value=i.aoMap,e.aoMapIntensity.value=i.aoMapIntensity,r(i.aoMap,e.aoMapTransform))
      }
    return{refreshFogUniforms:function(t,r){
      r.color.getRGB(t.fogColor.value,(0,n.getUnlitUniformColorSpace)(e)),r.isFog?(t.fogNear.value=r.near,t.fogFar.value=r.far):r.isFogExp2&&(t.fogDensity.value=r.density)
      },refreshMaterialUniforms:function(e,a,o,l,s){
      var c,d,u,f,p,m,_,h,g,v,S,E,T,M,x,R,A,C,b,P,L,U,D;
      let w;
      a.isNodeMaterial?a.uniformsNeedUpdate=!1:a.isMeshBasicMaterial?i(e,a):a.isMeshLambertMaterial?(i(e,a),a.envMap&&(e.envMapIntensity.value=a.envMapIntensity)):a.isMeshToonMaterial?(i(e,a),c=e,(d=a).gradientMap&&(c.gradientMap.value=d.gradientMap)):a.isMeshPhongMaterial?(i(e,a),u=e,f=a,u.specular.value.copy(f.specular),u.shininess.value=Math.max(f.shininess,1e-4),a.envMap&&(e.envMapIntensity.value=a.envMapIntensity)):a.isMeshStandardMaterial?(i(e,a),p=e,m=a,p.metalness.value=m.metalness,m.metalnessMap&&(p.metalnessMap.value=m.metalnessMap,r(m.metalnessMap,p.metalnessMapTransform)),p.roughness.value=m.roughness,m.roughnessMap&&(p.roughnessMap.value=m.roughnessMap,r(m.roughnessMap,p.roughnessMapTransform)),m.envMap&&(p.envMapIntensity.value=m.envMapIntensity),a.isMeshPhysicalMaterial&&(_=e,h=a,g=s,_.ior.value=h.ior,h.sheen>0&&(_.sheenColor.value.copy(h.sheenColor).multiplyScalar(h.sheen),_.sheenRoughness.value=h.sheenRoughness,h.sheenColorMap&&(_.sheenColorMap.value=h.sheenColorMap,r(h.sheenColorMap,_.sheenColorMapTransform)),h.sheenRoughnessMap&&(_.sheenRoughnessMap.value=h.sheenRoughnessMap,r(h.sheenRoughnessMap,_.sheenRoughnessMapTransform))),h.clearcoat>0&&(_.clearcoat.value=h.clearcoat,_.clearcoatRoughness.value=h.clearcoatRoughness,h.clearcoatMap&&(_.clearcoatMap.value=h.clearcoatMap,r(h.clearcoatMap,_.clearcoatMapTransform)),h.clearcoatRoughnessMap&&(_.clearcoatRoughnessMap.value=h.clearcoatRoughnessMap,r(h.clearcoatRoughnessMap,_.clearcoatRoughnessMapTransform)),h.clearcoatNormalMap&&(_.clearcoatNormalMap.value=h.clearcoatNormalMap,r(h.clearcoatNormalMap,_.clearcoatNormalMapTransform),_.clearcoatNormalScale.value.copy(h.clearcoatNormalScale),h.side===n.BackSide&&_.clearcoatNormalScale.value.negate())),h.dispersion>0&&(_.dispersion.value=h.dispersion),h.iridescence>0&&(_.iridescence.value=h.iridescence,_.iridescenceIOR.value=h.iridescenceIOR,_.iridescenceThicknessMinimum.value=h.iridescenceThicknessRange[0],_.iridescenceThicknessMaximum.value=h.iridescenceThicknessRange[1],h.iridescenceMap&&(_.iridescenceMap.value=h.iridescenceMap,r(h.iridescenceMap,_.iridescenceMapTransform)),h.iridescenceThicknessMap&&(_.iridescenceThicknessMap.value=h.iridescenceThicknessMap,r(h.iridescenceThicknessMap,_.iridescenceThicknessMapTransform))),h.transmission>0&&(_.transmission.value=h.transmission,_.transmissionSamplerMap.value=g.texture,_.transmissionSamplerSize.value.set(g.width,g.height),h.transmissionMap&&(_.transmissionMap.value=h.transmissionMap,r(h.transmissionMap,_.transmissionMapTransform)),_.thickness.value=h.thickness,h.thicknessMap&&(_.thicknessMap.value=h.thicknessMap,r(h.thicknessMap,_.thicknessMapTransform)),_.attenuationDistance.value=h.attenuationDistance,_.attenuationColor.value.copy(h.attenuationColor)),h.anisotropy>0&&(_.anisotropyVector.value.set(h.anisotropy*Math.cos(h.anisotropyRotation),h.anisotropy*Math.sin(h.anisotropyRotation)),h.anisotropyMap&&(_.anisotropyMap.value=h.anisotropyMap,r(h.anisotropyMap,_.anisotropyMapTransform))),_.specularIntensity.value=h.specularIntensity,_.specularColor.value.copy(h.specularColor),h.specularColorMap&&(_.specularColorMap.value=h.specularColorMap,r(h.specularColorMap,_.specularColorMapTransform)),h.specularIntensityMap&&(_.specularIntensityMap.value=h.specularIntensityMap,r(h.specularIntensityMap,_.specularIntensityMapTransform)))):a.isMeshMatcapMaterial?(i(e,a),v=e,(S=a).matcap&&(v.matcap.value=S.matcap)):a.isMeshDepthMaterial?i(e,a):a.isMeshDistanceMaterial?(i(e,a),E=e,T=a,w=t.get(T).light,E.referencePosition.value.setFromMatrixPosition(w.matrixWorld),E.nearDistance.value=w.shadow.camera.near,E.farDistance.value=w.shadow.camera.far):a.isMeshNormalMaterial?i(e,a):a.isLineBasicMaterial?(M=e,x=a,M.diffuse.value.copy(x.color),M.opacity.value=x.opacity,x.map&&(M.map.value=x.map,r(x.map,M.mapTransform)),a.isLineDashedMaterial&&(R=e,A=a,R.dashSize.value=A.dashSize,R.totalSize.value=A.dashSize+A.gapSize,R.scale.value=A.scale)):a.isPointsMaterial?(C=e,b=a,P=o,L=l,C.diffuse.value.copy(b.color),C.opacity.value=b.opacity,C.size.value=b.size*P,C.scale.value=.5*L,b.map&&(C.map.value=b.map,r(b.map,C.uvTransform)),b.alphaMap&&(C.alphaMap.value=b.alphaMap,r(b.alphaMap,C.alphaMapTransform)),b.alphaTest>0&&(C.alphaTest.value=b.alphaTest)):a.isSpriteMaterial?(U=e,D=a,U.diffuse.value.copy(D.color),U.opacity.value=D.opacity,U.rotation.value=D.rotation,D.map&&(U.map.value=D.map,r(D.map,U.mapTransform)),D.alphaMap&&(U.alphaMap.value=D.alphaMap,r(D.alphaMap,U.alphaMapTransform)),D.alphaTest>0&&(U.alphaTest.value=D.alphaTest)):a.isShadowMaterial?(e.color.value.copy(a.color),e.opacity.value=a.opacity):a.isShaderMaterial&&(a.uniformsNeedUpdate=!1)
      }}
    }
  function nw(e,t,r,i){
    let a={},o={},l=[],s=e.getParameter(e.MAX_UNIFORM_BUFFER_BINDINGS);
    function c(e){
      let t={boundary:0,storage:0};
      return"number"==typeof e||"boolean"==typeof e?(t.boundary=4,t.storage=4):e.isVector2?(t.boundary=8,t.storage=8):e.isVector3||e.isColor?(t.boundary=16,t.storage=12):e.isVector4?(t.boundary=16,t.storage=16):e.isMatrix3?(t.boundary=48,t.storage=48):e.isMatrix4?(t.boundary=64,t.storage=64):e.isTexture?(0,n.warn)("WebGLRenderer: Texture samplers can not be part of an uniforms group."):ArrayBuffer.isView(e)?(t.boundary=16,t.storage=e.byteLength):(0,n.warn)("WebGLRenderer: Unsupported uniform value type.",e),t
      }
    function d(n){
      let t=n.target;
      t.removeEventListener("dispose",d);
      let r=l.indexOf(t.__bindingPointIndex);
      l.splice(r,1),e.deleteBuffer(a[t.id]),delete a[t.id],delete o[t.id]
      }
    return{bind:function(e,n){
      let t=n.program;
      i.uniformBlockBinding(e,t)
      },update:function(r,u){
      var f;
      let p,m,_,h,g=a[r.id];
      void 0===g&&(function(e){
        let n=e.uniforms,t=0;
        for(
        let e=0,r=n.length
        ;e<r;e++){
          let r=Array.isArray(n[e])?n[e]:[n[e]];
          for(
          let e=0,n=r.length
          ;e<n;e++){
            let n=r[e],i=Array.isArray(n.value)?n.value:[n.value];
            for(
            let e=0,r=i.length
            ;e<r;e++){
              let r=c(i[e]),a=t%16,o=a%r.boundary,l=a+o;
              t+=o,0!==l&&16-l<r.storage&&(t+=16-l),n.__data=new Float32Array(r.storage/Float32Array.BYTES_PER_ELEMENT),n.__offset=t,t+=r.storage
              }
            }
          }
        let r=t%16;
        r>0&&(t+=16-r),e.__size=t,e.__cache={}
        }(r),(f=r).__bindingPointIndex=p=function(){
        for(
        let e=0
        ;e<s;e++)
        if(-1===l.indexOf(e))
        return l.push(e),e;
        return(0,n.error)("WebGLRenderer: Maximum number of simultaneously usable uniforms groups reached."),0
        }(),m=e.createBuffer(),_=f.__size,h=f.usage,e.bindBuffer(e.UNIFORM_BUFFER,m),e.bufferData(e.UNIFORM_BUFFER,_,h),e.bindBuffer(e.UNIFORM_BUFFER,null),e.bindBufferBase(e.UNIFORM_BUFFER,p,m),g=m,a[r.id]=g,r.addEventListener("dispose",d));
      let v=u.program;
      i.updateUBOMapping(r,v);
      let S=t.render.frame;
      o[r.id]!==S&&(function(n){
        let t=a[n.id],r=n.uniforms,i=n.__cache;
        e.bindBuffer(e.UNIFORM_BUFFER,t);
        for(
        let n=0,t=r.length
        ;n<t;n++){
          let t=Array.isArray(r[n])?r[n]:[r[n]];
          for(
          let r=0,a=t.length
          ;r<a;r++){
            let a=t[r];
            if(!0===function(e,n,t,r){
              let i=e.value,a=n+"_"+t;
              if(void 0===r[a])
              return"number"==typeof i||"boolean"==typeof i?r[a]=i:ArrayBuffer.isView(i)?r[a]=i.slice():r[a]=i.clone(),!0;
              {
                let e=r[a];
                if("number"==typeof i||"boolean"==typeof i){
                  if(e!==i)
                  return r[a]=i,!0
                  }else 
                if(ArrayBuffer.isView(i))
                return!0;
                else 
                if(!1===e.equals(i))
                return e.copy(i),!0
                }
              return!1
              }(a,n,r,i)){
              let n=a.__offset,t=Array.isArray(a.value)?a.value:[a.value],r=0;
              for(
              let i=0
              ;i<t.length;i++){
                let o=t[i],l=c(o);
                "number"==typeof o||"boolean"==typeof o?(a.__data[0]=o,e.bufferSubData(e.UNIFORM_BUFFER,n+r,a.__data)):o.isMatrix3?(a.__data[0]=o.elements[0],a.__data[1]=o.elements[1],a.__data[2]=o.elements[2],a.__data[3]=0,a.__data[4]=o.elements[3],a.__data[5]=o.elements[4],a.__data[6]=o.elements[5],a.__data[7]=0,a.__data[8]=o.elements[6],a.__data[9]=o.elements[7],a.__data[10]=o.elements[8],a.__data[11]=0):ArrayBuffer.isView(o)?a.__data.set(new o.constructor(o.buffer,o.byteOffset,a.__data.length)):(o.toArray(a.__data,r),r+=l.storage/Float32Array.BYTES_PER_ELEMENT)
                }
              e.bufferSubData(e.UNIFORM_BUFFER,n,a.__data)
              }
            }
          }
        e.bindBuffer(e.UNIFORM_BUFFER,null)
        }(r),o[r.id]=S)
      },dispose:function(){
      for(
      let n
       in a)
      e.deleteBuffer(a[n]);
      l=[],a={},o={}
      }}
    }
  nU.set(-1,0,0,0,1,0,0,0,1);
  let nN=new Uint16Array([12469,15057,12620,14925,13266,14620,13807,14376,14323,13990,14545,13625,14713,13328,14840,12882,14931,12528,14996,12233,15039,11829,15066,11525,15080,11295,15085,10976,15082,10705,15073,10495,13880,14564,13898,14542,13977,14430,14158,14124,14393,13732,14556,13410,14702,12996,14814,12596,14891,12291,14937,11834,14957,11489,14958,11194,14943,10803,14921,10506,14893,10278,14858,9960,14484,14039,14487,14025,14499,13941,14524,13740,14574,13468,14654,13106,14743,12678,14818,12344,14867,11893,14889,11509,14893,11180,14881,10751,14852,10428,14812,10128,14765,9754,14712,9466,14764,13480,14764,13475,14766,13440,14766,13347,14769,13070,14786,12713,14816,12387,14844,11957,14860,11549,14868,11215,14855,10751,14825,10403,14782,10044,14729,9651,14666,9352,14599,9029,14967,12835,14966,12831,14963,12804,14954,12723,14936,12564,14917,12347,14900,11958,14886,11569,14878,11247,14859,10765,14828,10401,14784,10011,14727,9600,14660,9289,14586,8893,14508,8533,15111,12234,15110,12234,15104,12216,15092,12156,15067,12010,15028,11776,14981,11500,14942,11205,14902,10752,14861,10393,14812,9991,14752,9570,14682,9252,14603,8808,14519,8445,14431,8145,15209,11449,15208,11451,15202,11451,15190,11438,15163,11384,15117,11274,15055,10979,14994,10648,14932,10343,14871,9936,14803,9532,14729,9218,14645,8742,14556,8381,14461,8020,14365,7603,15273,10603,15272,10607,15267,10619,15256,10631,15231,10614,15182,10535,15118,10389,15042,10167,14963,9787,14883,9447,14800,9115,14710,8665,14615,8318,14514,7911,14411,7507,14279,7198,15314,9675,15313,9683,15309,9712,15298,9759,15277,9797,15229,9773,15166,9668,15084,9487,14995,9274,14898,8910,14800,8539,14697,8234,14590,7790,14479,7409,14367,7067,14178,6621,15337,8619,15337,8631,15333,8677,15325,8769,15305,8871,15264,8940,15202,8909,15119,8775,15022,8565,14916,8328,14804,8009,14688,7614,14569,7287,14448,6888,14321,6483,14088,6171,15350,7402,15350,7419,15347,7480,15340,7613,15322,7804,15287,7973,15229,8057,15148,8012,15046,7846,14933,7611,14810,7357,14682,7069,14552,6656,14421,6316,14251,5948,14007,5528,15356,5942,15356,5977,15353,6119,15348,6294,15332,6551,15302,6824,15249,7044,15171,7122,15070,7050,14949,6861,14818,6611,14679,6349,14538,6067,14398,5651,14189,5311,13935,4958,15359,4123,15359,4153,15356,4296,15353,4646,15338,5160,15311,5508,15263,5829,15188,6042,15088,6094,14966,6001,14826,5796,14678,5543,14527,5287,14377,4985,14133,4586,13869,4257,15360,1563,15360,1642,15358,2076,15354,2636,15341,3350,15317,4019,15273,4429,15203,4732,15105,4911,14981,4932,14836,4818,14679,4621,14517,4386,14359,4156,14083,3795,13808,3437,15360,122,15360,137,15358,285,15355,636,15344,1274,15322,2177,15281,2765,15215,3223,15120,3451,14995,3569,14846,3567,14681,3466,14511,3305,14344,3121,14037,2800,13753,2467,15360,0,15360,1,15359,21,15355,89,15346,253,15325,479,15287,796,15225,1148,15133,1492,15008,1749,14856,1882,14685,1886,14506,1783,14324,1608,13996,1398,13702,1183]),nI=null;
  e.s(["PMREMGenerator",0,x,"ShaderChunk",0,i,"ShaderLib",0,o,"UniformsLib",0,a,"WebGLCubeRenderTarget",0,L,"WebGLRenderer",0,class{
    constructor(e={}){
      let i,a,o,l,s,c,_,h,g,v,S,E,T,M,x,R,A,C,b,P,L,O,G,H;
      const{canvas:V=(0,n.createCanvasElement)(),context:W=null,depth:z=!0,stencil:k=!1,alpha:X=!1,antialias:q=!1,premultipliedAlpha:K=!0,preserveDrawingBuffer:Y=!1,powerPreference:j="default",failIfMajorPerformanceCaveat:Z=!1,reversedDepthBuffer:$=!1,outputBufferType:Q=n.UnsignedByteType}=e;
      if(this.isWebGLRenderer=!0,null!==W){
        if("u">typeof WebGLRenderingContext&&W instanceof WebGLRenderingContext)
        throw Error("THREE.WebGLRenderer: WebGL 1 is not supported since r163.");
        i=W.getContextAttributes().alpha
        }else 
      i=X;
      const J=new Set([n.RGBAIntegerFormat,n.RGIntegerFormat,n.RedIntegerFormat]),ee=new Set([n.UnsignedByteType,n.UnsignedIntType,n.UnsignedShortType,n.UnsignedInt248Type,n.UnsignedShort4444Type,n.UnsignedShort5551Type]),en=new Uint32Array(4),et=new Int32Array(4),er=new n.Vector3;
      let ei=null,ea=null;
      const eo=[],el=[];
      let es=null;
      this.domElement=V,this.debug={checkShaderErrors:!0,onShaderError:null},this.autoClear=!0,this.autoClearColor=!0,this.autoClearDepth=!0,this.autoClearStencil=!0,this.sortObjects=!0,this.clippingPlanes=[],this.localClippingEnabled=!1,this.toneMapping=n.NoToneMapping,this.toneMappingExposure=1,this.transmissionResolutionScale=1;
      const ec=this;
      let ed=!1,eu=null;
      this._outputColorSpace=n.SRGBColorSpace;
      let ef=0,ep=0,em=null,e_=-1,eh=null;
      const eg=new n.Vector4,ev=new n.Vector4;
      let eS=null;
      const eE=new n.Color(0);
      let eT=0,eM=V.width,ex=V.height,eR=1,eA=null,eC=null;
      const eb=new n.Vector4(0,0,eM,ex),eP=new n.Vector4(0,0,eM,ex);
      let eL=!1;
      const eU=new n.Frustum;
      let eD=!1,ew=!1;
      const eN=new n.Matrix4,eI=new n.Vector3,ey=new n.Vector4,eF={background:null,fog:null,environment:null,overrideMaterial:null,isScene:!0};
      let eO=!1;
      function eB(){
        return null===em?eR:1
        }
      let eG=W;
      function eH(e,n){
        return V.getContext(e,n)
        }
      try{
        if("setAttribute"in V&&V.setAttribute("data-engine",`three.js r${n.REVISION}`),V.addEventListener("webglcontextlost",ek,!1),V.addEventListener("webglcontextrestored",eX,!1),V.addEventListener("webglcontextcreationerror",eq,!1),null===eG){
          const e="webgl2";
          if(eG=eH(e,{alpha:!0,depth:z,stencil:k,antialias:q,premultipliedAlpha:K,preserveDrawingBuffer:Y,powerPreference:j,failIfMajorPerformanceCaveat:Z}),null===eG)
          if(eH(e))
          throw Error("Error creating WebGL context with your selected attributes.");
          else 
          throw Error("Error creating WebGL context.")
          }
        }catch(e){
        throw(0,n.error)("WebGLRenderer: "+e.message),e
        }
      function eV(){
        (a=new D(eG)).init(),O=new nR(eG,a),o=new p(eG,a,e,O),l=new nM(eG,a),o.reversedDepthBuffer&&$&&l.buffers.depth.setReversed(!0),s=new I(eG),c=new na,_=new nx(eG,a,l,c,o,O,s),h=new U(ec),g=new r(eG),G=new u(eG,g),v=new w(eG,g,s,G),S=new F(eG,v,g,G,s),b=new y(eG,o,_),R=new m(c),E=new ni(ec,h,a,o,G,R),T=new nD(ec,c),M=new nc,x=new n_(a),C=new d(ec,h,l,S,i,K),A=new nT(ec,S,o),H=new nw(eG,s,o,l),P=new f(eG,a,s),L=new N(eG,a,s),s.programs=E.programs,ec.capabilities=o,ec.extensions=a,ec.properties=c,ec.renderLists=M,ec.shadowMap=A,ec.state=l,ec.info=s
        }
      eV(),Q!==n.UnsignedByteType&&(es=new B(Q,V.width,V.height,z,k));
      const ez=new nP(ec,eG);
      function ek(e){
        e.preventDefault(),(0,n.log)("WebGLRenderer: Context Lost."),ed=!0
        }
      function eX(){
        (0,n.log)("WebGLRenderer: Context Restored."),ed=!1;
        let e=s.autoReset,t=A.enabled,r=A.autoUpdate,i=A.needsUpdate,a=A.type;
        eV(),s.autoReset=e,A.enabled=t,A.autoUpdate=r,A.needsUpdate=i,A.type=a
        }
      function eq(e){
        (0,n.error)("WebGLRenderer: A WebGL context could not be created. Reason: ",e.statusMessage)
        }
      function eK(e){
        var n,t;
        let r,i=e.target;
        i.removeEventListener("dispose",eK),t=n=i,void 0!==(r=c.get(t).programs)&&(r.forEach(function(e){
          E.releaseProgram(e)
          }),t.isShaderMaterial&&E.releaseShaderCache(t)),c.remove(n)
        }
      function eY(e,t,r){
        !0===e.transparent&&e.side===n.DoubleSide&&!1===e.forceSinglePass?(e.side=n.BackSide,e.needsUpdate=!0,e4(e,t,r),e.side=n.FrontSide,e.needsUpdate=!0,e4(e,t,r),e.side=n.DoubleSide):e4(e,t,r)
        }
      this.xr=ez,this.getContext=function(){
        return eG
        },this.getContextAttributes=function(){
        return eG.getContextAttributes()
        },this.forceContextLoss=function(){
        let e=a.get("WEBGL_lose_context");
        e&&e.loseContext()
        },this.forceContextRestore=function(){
        let e=a.get("WEBGL_lose_context");
        e&&e.restoreContext()
        },this.getPixelRatio=function(){
        return eR
        },this.setPixelRatio=function(e){
        void 0!==e&&(eR=e,this.setSize(eM,ex,!1))
        },this.getSize=function(e){
        return e.set(eM,ex)
        },this.setSize=function(e,t,r=!0){
        ez.isPresenting?(0,n.warn)("WebGLRenderer: Can't change size while VR device is presenting."):(eM=e,ex=t,V.width=Math.floor(e*eR),V.height=Math.floor(t*eR),!0===r&&(V.style.width=e+"px",V.style.height=t+"px"),null!==es&&es.setSize(V.width,V.height),this.setViewport(0,0,e,t))
        },this.getDrawingBufferSize=function(e){
        return e.set(eM*eR,ex*eR).floor()
        },this.setDrawingBufferSize=function(e,n,t){
        eM=e,ex=n,eR=t,V.width=Math.floor(e*t),V.height=Math.floor(n*t),this.setViewport(0,0,e,n)
        },this.setEffects=function(e){
        if(Q===n.UnsignedByteType)
        return void(0,n.error)("THREE.WebGLRenderer: setEffects() requires outputBufferType set to HalfFloatType or FloatType.");
        if(e){
          for(
          let t=0
          ;t<e.length;t++)
          if(!0===e[t].isOutputPass){
            (0,n.warn)("THREE.WebGLRenderer: OutputPass is not needed in setEffects(). Tone mapping and color space conversion are applied automatically.");
            break
            }
          }
        es.setEffects(e||[])
        },this.getCurrentViewport=function(e){
        return e.copy(eg)
        },this.getViewport=function(e){
        return e.copy(eb)
        },this.setViewport=function(e,n,t,r){
        e.isVector4?eb.set(e.x,e.y,e.z,e.w):eb.set(e,n,t,r),l.viewport(eg.copy(eb).multiplyScalar(eR).round())
        },this.getScissor=function(e){
        return e.copy(eP)
        },this.setScissor=function(e,n,t,r){
        e.isVector4?eP.set(e.x,e.y,e.z,e.w):eP.set(e,n,t,r),l.scissor(ev.copy(eP).multiplyScalar(eR).round())
        },this.getScissorTest=function(){
        return eL
        },this.setScissorTest=function(e){
        l.setScissorTest(eL=e)
        },this.setOpaqueSort=function(e){
        eA=e
        },this.setTransparentSort=function(e){
        eC=e
        },this.getClearColor=function(e){
        return e.copy(C.getClearColor())
        },this.setClearColor=function(){
        C.setClearColor(...arguments)
        },this.getClearAlpha=function(){
        return C.getClearAlpha()
        },this.setClearAlpha=function(){
        C.setClearAlpha(...arguments)
        },this.clear=function(e=!0,n=!0,t=!0){
        let r=0;
        if(e){
          let e=!1;
          if(null!==em){
            let n=em.texture.format;
            e=J.has(n)
            }
          if(e){
            let e=em.texture.type,n=ee.has(e),t=C.getClearColor(),r=C.getClearAlpha(),i=t.r,a=t.g,o=t.b;
            n?(en[0]=i,en[1]=a,en[2]=o,en[3]=r,eG.clearBufferuiv(eG.COLOR,0,en)):(et[0]=i,et[1]=a,et[2]=o,et[3]=r,eG.clearBufferiv(eG.COLOR,0,et))
            }else 
          r|=eG.COLOR_BUFFER_BIT
          }
        n&&(r|=eG.DEPTH_BUFFER_BIT,this.state.buffers.depth.setMask(!0)),t&&(r|=eG.STENCIL_BUFFER_BIT,this.state.buffers.stencil.setMask(0xffffffff)),0!==r&&eG.clear(r)
        },this.clearColor=function(){
        this.clear(!0,!1,!1)
        },this.clearDepth=function(){
        this.clear(!1,!0,!1)
        },this.clearStencil=function(){
        this.clear(!1,!1,!0)
        },this.setNodesHandler=function(e){
        e.setRenderer(this),eu=e
        },this.dispose=function(){
        V.removeEventListener("webglcontextlost",ek,!1),V.removeEventListener("webglcontextrestored",eX,!1),V.removeEventListener("webglcontextcreationerror",eq,!1),C.dispose(),M.dispose(),x.dispose(),c.dispose(),h.dispose(),S.dispose(),G.dispose(),H.dispose(),E.dispose(),ez.dispose(),ez.removeEventListener("sessionstart",eZ),ez.removeEventListener("sessionend",e$),eQ.stop()
        },this.renderBufferDirect=function(e,t,r,i,s,d){
        let u;
        null===t&&(t=eF);
        let f=s.isMesh&&0>s.matrixWorld.determinant(),p=function(e,t,r,i,a){
          !0!==t.isScene&&(t=eF),_.resetTextureUnits();
          let s=t.fog,d=i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial?t.environment:null,u=null===em?ec.outputColorSpace:!0===em.isXRRenderTarget?em.texture.colorSpace:n.ColorManagement.workingColorSpace,f=i.isMeshStandardMaterial||i.isMeshLambertMaterial&&!i.envMap||i.isMeshPhongMaterial&&!i.envMap,p=h.get(i.envMap||d,f),m=!0===i.vertexColors&&!!r.attributes.color&&4===r.attributes.color.itemSize,g=!!r.attributes.tangent&&(!!i.normalMap||i.anisotropy>0),v=!!r.morphAttributes.position,S=!!r.morphAttributes.normal,E=!!r.morphAttributes.color,M=n.NoToneMapping;
          i.toneMapped&&(null===em||!0===em.isXRRenderTarget)&&(M=ec.toneMapping);
          let x=r.morphAttributes.position||r.morphAttributes.normal||r.morphAttributes.color,A=void 0!==x?x.length:0,C=c.get(i),P=ea.state.lights;
          if(!0===eD&&(!0===ew||e!==eh)){
            let n=e===eh&&i.id===e_;
            R.setState(i,e,n)
            }
          let L=!1;
          i.version===C.__version?C.needsLights&&C.lightsStateVersion!==P.state.version||C.outputColorSpace!==u||a.isBatchedMesh&&!1===C.batching?L=!0:a.isBatchedMesh||!0!==C.batching?a.isBatchedMesh&&!0===C.batchingColor&&null===a.colorTexture||a.isBatchedMesh&&!1===C.batchingColor&&null!==a.colorTexture||a.isInstancedMesh&&!1===C.instancing?L=!0:a.isInstancedMesh||!0!==C.instancing?a.isSkinnedMesh&&!1===C.skinning?L=!0:a.isSkinnedMesh||!0!==C.skinning?a.isInstancedMesh&&!0===C.instancingColor&&null===a.instanceColor||a.isInstancedMesh&&!1===C.instancingColor&&null!==a.instanceColor||a.isInstancedMesh&&!0===C.instancingMorph&&null===a.morphTexture||a.isInstancedMesh&&!1===C.instancingMorph&&null!==a.morphTexture||C.envMap!==p||!0===i.fog&&C.fog!==s||void 0!==C.numClippingPlanes&&(C.numClippingPlanes!==R.numPlanes||C.numIntersection!==R.numIntersection)||C.vertexAlphas!==m||C.vertexTangents!==g||C.morphTargets!==v||C.morphNormals!==S||C.morphColors!==E||C.toneMapping!==M||C.morphTargetsCount!==A?L=!0:!!C.lightProbeGrid!=ea.state.lightProbeGridArray.length>0&&(L=!0):L=!0:L=!0:L=!0:(L=!0,C.__version=i.version);
          let U=C.currentProgram;
          !0===L&&(U=e4(i,t,a),eu&&i.isNodeMaterial&&eu.onUpdateProgram(i,U,C));
          let D=!1,w=!1,N=!1,I=U.getUniforms(),y=C.uniforms;
          if(l.useProgram(U.program)&&(D=!0,w=!0,N=!0),i.id!==e_&&(e_=i.id,w=!0),C.needsLights){
            let e=function(e,n){
              if(0===e.length)
              return null;
              if(1===e.length)
              return null!==e[0].texture?e[0]:null;
              er.setFromMatrixPosition(n.matrixWorld);
              for(
              let n=0,t=e.length
              ;n<t;n++){
                let t=e[n];
                if(null!==t.texture&&t.boundingBox.containsPoint(er))
                return t
                }
              return null
              }(ea.state.lightProbeGridArray,a);
            C.lightProbeGrid!==e&&(C.lightProbeGrid=e,w=!0)
            }
          if(D||eh!==e){
            l.buffers.depth.getReversed()&&!0!==e.reversedDepth&&(e._reversedDepth=!0,e.updateProjectionMatrix()),I.setValue(eG,"projectionMatrix",e.projectionMatrix),I.setValue(eG,"viewMatrix",e.matrixWorldInverse);
            let n=I.map.cameraPosition;
            void 0!==n&&n.setValue(eG,eI.setFromMatrixPosition(e.matrixWorld)),o.logarithmicDepthBuffer&&I.setValue(eG,"logDepthBufFC",2/(Math.log(e.far+1)/Math.LN2)),(i.isMeshPhongMaterial||i.isMeshToonMaterial||i.isMeshLambertMaterial||i.isMeshBasicMaterial||i.isMeshStandardMaterial||i.isShaderMaterial)&&I.setValue(eG,"isOrthographic",!0===e.isOrthographicCamera),eh!==e&&(eh=e,w=!0,N=!0)
            }
          if(C.needsLights&&(P.state.directionalShadowMap.length>0&&I.setValue(eG,"directionalShadowMap",P.state.directionalShadowMap,_),P.state.spotShadowMap.length>0&&I.setValue(eG,"spotShadowMap",P.state.spotShadowMap,_),P.state.pointShadowMap.length>0&&I.setValue(eG,"pointShadowMap",P.state.pointShadowMap,_)),a.isSkinnedMesh){
            I.setOptional(eG,a,"bindMatrix"),I.setOptional(eG,a,"bindMatrixInverse");
            let e=a.skeleton;
            e&&(null===e.boneTexture&&e.computeBoneTexture(),I.setValue(eG,"boneTexture",e.boneTexture,_))
            }
          a.isBatchedMesh&&(I.setOptional(eG,a,"batchingTexture"),I.setValue(eG,"batchingTexture",a._matricesTexture,_),I.setOptional(eG,a,"batchingIdTexture"),I.setValue(eG,"batchingIdTexture",a._indirectTexture,_),I.setOptional(eG,a,"batchingColorTexture"),null!==a._colorsTexture&&I.setValue(eG,"batchingColorTexture",a._colorsTexture,_));
          let F=r.morphAttributes;
          if((void 0!==F.position||void 0!==F.normal||void 0!==F.color)&&b.update(a,r,U),(w||C.receiveShadow!==a.receiveShadow)&&(C.receiveShadow=a.receiveShadow,I.setValue(eG,"receiveShadow",a.receiveShadow)),(i.isMeshStandardMaterial||i.isMeshLambertMaterial||i.isMeshPhongMaterial)&&null===i.envMap&&null!==t.environment&&(y.envMapIntensity.value=t.environmentIntensity),void 0!==y.dfgLUT&&(y.dfgLUT.value=(null===nI&&((nI=new n.DataTexture(nN,16,16,n.RGFormat,n.HalfFloatType)).name="DFG_LUT",nI.minFilter=n.LinearFilter,nI.magFilter=n.LinearFilter,nI.wrapS=n.ClampToEdgeWrapping,nI.wrapT=n.ClampToEdgeWrapping,nI.generateMipmaps=!1,nI.needsUpdate=!0),nI)),w){
            var O,B;
            if(I.setValue(eG,"toneMappingExposure",ec.toneMappingExposure),C.needsLights&&(O=y,B=N,O.ambientLightColor.needsUpdate=B,O.lightProbe.needsUpdate=B,O.directionalLights.needsUpdate=B,O.directionalLightShadows.needsUpdate=B,O.pointLights.needsUpdate=B,O.pointLightShadows.needsUpdate=B,O.spotLights.needsUpdate=B,O.spotLightShadows.needsUpdate=B,O.rectAreaLights.needsUpdate=B,O.hemisphereLights.needsUpdate=B),s&&!0===i.fog&&T.refreshFogUniforms(y,s),T.refreshMaterialUniforms(y,i,eR,ex,ea.state.transmissionRenderTarget[e.id]),C.needsLights&&C.lightProbeGrid){
              let e=C.lightProbeGrid;
              y.probesSH.value=e.texture,y.probesMin.value.copy(e.boundingBox.min),y.probesMax.value.copy(e.boundingBox.max),y.probesResolution.value.copy(e.resolution)
              }
            eW.upload(eG,e5(C),y,_)
            }
          if(i.isShaderMaterial&&!0===i.uniformsNeedUpdate&&(eW.upload(eG,e5(C),y,_),i.uniformsNeedUpdate=!1),i.isSpriteMaterial&&I.setValue(eG,"center",a.center),I.setValue(eG,"modelViewMatrix",a.modelViewMatrix),I.setValue(eG,"normalMatrix",a.normalMatrix),I.setValue(eG,"modelMatrix",a.matrixWorld),void 0!==i.uniformsGroups){
            let e=i.uniformsGroups;
            for(
            let n=0,t=e.length
            ;n<t;n++){
              let t=e[n];
              H.update(t,U),H.bind(t,U)
              }
            }
          return U
          }(e,t,r,i,s);
        l.setMaterial(i,f);
        let m=r.index,S=1;
        if(!0===i.wireframe){
          if(void 0===(m=v.getWireframeAttribute(r)))
          return;
          S=2
          }
        let E=r.drawRange,M=r.attributes.position,x=E.start*S,A=(E.start+E.count)*S;
        null!==d&&(x=Math.max(x,d.start*S),A=Math.min(A,(d.start+d.count)*S)),null!==m?(x=Math.max(x,0),A=Math.min(A,m.count)):null!=M&&(x=Math.max(x,0),A=Math.min(A,M.count));
        let C=A-x;
        if(C<0||C===1/0)
        return;
        G.setup(s,i,p,r,m);
        let U=P;
        if(null!==m&&(u=g.get(m),(U=L).setIndex(u)),s.isMesh)
        !0===i.wireframe?(l.setLineWidth(i.wireframeLinewidth*eB()),U.setMode(eG.LINES)):U.setMode(eG.TRIANGLES);
        else 
        if(s.isLine){
          let e=i.linewidth;
          void 0===e&&(e=1),l.setLineWidth(e*eB()),s.isLineSegments?U.setMode(eG.LINES):s.isLineLoop?U.setMode(eG.LINE_LOOP):U.setMode(eG.LINE_STRIP)
          }else 
        s.isPoints?U.setMode(eG.POINTS):s.isSprite&&U.setMode(eG.TRIANGLES);
        if(s.isBatchedMesh)
        if(a.get("WEBGL_multi_draw"))
        U.renderMultiDraw(s._multiDrawStarts,s._multiDrawCounts,s._multiDrawCount);
        else{
          let e=s._multiDrawStarts,n=s._multiDrawCounts,t=s._multiDrawCount,r=m?g.get(m).bytesPerElement:1,a=c.get(i).currentProgram.getUniforms();
          for(
          let i=0
          ;i<t;i++)
          a.setValue(eG,"_gl_DrawID",i),U.render(e[i]/r,n[i])
          }
        else 
        if(s.isInstancedMesh)
        U.renderInstances(x,C,s.count);
        else 
        if(r.isInstancedBufferGeometry){
          let e=void 0!==r._maxInstanceCount?r._maxInstanceCount:1/0,n=Math.min(r.instanceCount,e);
          U.renderInstances(x,C,n)
          }else 
        U.render(x,C)
        },this.compile=function(e,n,t=null){
        null===t&&(t=e),(ea=x.get(t)).init(n),el.push(ea),t.traverseVisible(function(e){
          e.isLight&&e.layers.test(n.layers)&&(ea.pushLight(e),e.castShadow&&ea.pushShadow(e))
          }),e!==t&&e.traverseVisible(function(e){
          e.isLight&&e.layers.test(n.layers)&&(ea.pushLight(e),e.castShadow&&ea.pushShadow(e))
          }),ea.setupLights();
        let r=new Set;
        return e.traverse(function(e){
          if(!(e.isMesh||e.isPoints||e.isLine||e.isSprite))
          return;
          let n=e.material;
          if(n)
          if(Array.isArray(n))
          for(
          let i=0
          ;i<n.length;i++){
            let a=n[i];
            eY(a,t,e),r.add(a)
            }
          else 
          eY(n,t,e),r.add(n)
          }),ea=el.pop(),r
        },this.compileAsync=function(e,n,t=null){
        let r=this.compile(e,n,t);
        return new Promise(n=>{
          function t(){
            (r.forEach(function(e){
              c.get(e).currentProgram.isReady()&&r.delete(e)
              }),0===r.size)?n(e):setTimeout(t,10)
            }
          null!==a.get("KHR_parallel_shader_compile")?t():setTimeout(t,10)
          })
        };
      let ej=null;
      function eZ(){
        eQ.stop()
        }
      function e$(){
        eQ.start()
        }
      const eQ=new t;
      function eJ(e,n,t,r){
        if(!1===e.visible)
        return;
        if(e.layers.test(n.layers)){
          if(e.isGroup)
          t=e.renderOrder;
          else 
          if(e.isLOD)
          !0===e.autoUpdate&&e.update(n);
          else 
          if(e.isLightProbeGrid)
          ea.pushLightProbeGrid(e);
          else 
          if(e.isLight)
          ea.pushLight(e),e.castShadow&&ea.pushShadow(e);
          else 
          if(e.isSprite){
            if(!e.frustumCulled||eU.intersectsSprite(e)){
              r&&ey.setFromMatrixPosition(e.matrixWorld).applyMatrix4(eN);
              let n=S.update(e),i=e.material;
              i.visible&&ei.push(e,n,i,t,ey.z,null)
              }
            }else 
          if((e.isMesh||e.isLine||e.isPoints)&&(!e.frustumCulled||eU.intersectsObject(e))){
            let n=S.update(e),i=e.material;
            if(r&&(void 0!==e.boundingSphere?(null===e.boundingSphere&&e.computeBoundingSphere(),ey.copy(e.boundingSphere.center)):(null===n.boundingSphere&&n.computeBoundingSphere(),ey.copy(n.boundingSphere.center)),ey.applyMatrix4(e.matrixWorld).applyMatrix4(eN)),Array.isArray(i)){
              let r=n.groups;
              for(
              let a=0,o=r.length
              ;a<o;a++){
                let o=r[a],l=i[o.materialIndex];
                l&&l.visible&&ei.push(e,n,l,t,ey.z,o)
                }
              }else 
            i.visible&&ei.push(e,n,i,t,ey.z,null)
            }
          }
        let i=e.children;
        for(
        let e=0,a=i.length
        ;e<a;e++)
        eJ(i[e],n,t,r)
        }
      function e0(e,n,t,r){
        let{opaque:i,transmissive:a,transparent:o}=e;
        ea.setupLightsView(t),!0===eD&&R.setGlobalState(ec.clippingPlanes,t),r&&l.viewport(eg.copy(r)),i.length>0&&e3(i,n,t),a.length>0&&e3(a,n,t),o.length>0&&e3(o,n,t),l.buffers.depth.setTest(!0),l.buffers.depth.setMask(!0),l.buffers.color.setMask(!0),l.setPolygonOffset(!1)
        }
      function e1(e,t,r,i){
        if(null!==(!0===r.isScene?r.overrideMaterial:null))
        return;
        if(void 0===ea.state.transmissionRenderTarget[i.id]){
          let e=a.has("EXT_color_buffer_half_float")||a.has("EXT_color_buffer_float");
          ea.state.transmissionRenderTarget[i.id]=new n.WebGLRenderTarget(1,1,{generateMipmaps:!0,type:e?n.HalfFloatType:n.UnsignedByteType,minFilter:n.LinearMipmapLinearFilter,samples:Math.max(4,o.samples),stencilBuffer:k,resolveDepthBuffer:!1,resolveStencilBuffer:!1,colorSpace:n.ColorManagement.workingColorSpace})
          }
        let l=ea.state.transmissionRenderTarget[i.id],s=i.viewport||eg;
        l.setSize(s.z*ec.transmissionResolutionScale,s.w*ec.transmissionResolutionScale);
        let c=ec.getRenderTarget(),d=ec.getActiveCubeFace(),u=ec.getActiveMipmapLevel();
        ec.setRenderTarget(l),ec.getClearColor(eE),(eT=ec.getClearAlpha())<1&&ec.setClearColor(0xffffff,.5),ec.clear(),eO&&C.render(r);
        let f=ec.toneMapping;
        ec.toneMapping=n.NoToneMapping;
        let p=i.viewport;
        if(void 0!==i.viewport&&(i.viewport=void 0),ea.setupLightsView(i),!0===eD&&R.setGlobalState(ec.clippingPlanes,i),e3(e,r,i),_.updateMultisampleRenderTarget(l),_.updateRenderTargetMipmap(l),!1===a.has("WEBGL_multisampled_render_to_texture")){
          let e=!1;
          for(
          let a=0,o=t.length
          ;a<o;a++){
            let{object:o,geometry:l,material:s,group:c}=t[a];
            if(s.side===n.DoubleSide&&o.layers.test(i.layers)){
              let t=s.side;
              s.side=n.BackSide,s.needsUpdate=!0,e2(o,r,i,l,s,c),s.side=t,s.needsUpdate=!0,e=!0
              }
            }
          !0===e&&(_.updateMultisampleRenderTarget(l),_.updateRenderTargetMipmap(l))
          }
        ec.setRenderTarget(c,d,u),ec.setClearColor(eE,eT),void 0!==p&&(i.viewport=p),ec.toneMapping=f
        }
      function e3(e,n,t){
        let r=!0===n.isScene?n.overrideMaterial:null;
        for(
        let i=0,a=e.length
        ;i<a;i++){
          let a=e[i],{object:o,geometry:l,group:s}=a,c=a.material;
          !0===c.allowOverride&&null!==r&&(c=r),o.layers.test(t.layers)&&e2(o,n,t,l,c,s)
          }
        }
      function e2(e,t,r,i,a,o){
        e.onBeforeRender(ec,t,r,i,a,o),e.modelViewMatrix.multiplyMatrices(r.matrixWorldInverse,e.matrixWorld),e.normalMatrix.getNormalMatrix(e.modelViewMatrix),a.onBeforeRender(ec,t,r,i,e,o),!0===a.transparent&&a.side===n.DoubleSide&&!1===a.forceSinglePass?(a.side=n.BackSide,a.needsUpdate=!0,ec.renderBufferDirect(r,t,i,a,e,o),a.side=n.FrontSide,a.needsUpdate=!0,ec.renderBufferDirect(r,t,i,a,e,o),a.side=n.DoubleSide):ec.renderBufferDirect(r,t,i,a,e,o),e.onAfterRender(ec,t,r,i,a,o)
        }
      function e4(e,n,t){
        var r;
        !0!==n.isScene&&(n=eF);
        let i=c.get(e),a=ea.state.lights,o=ea.state.shadowsArray,l=a.state.version,s=E.getParameters(e,a.state,o,n,t,ea.state.lightProbeGridArray),d=E.getProgramCacheKey(s),u=i.programs;
        i.environment=e.isMeshStandardMaterial||e.isMeshLambertMaterial||e.isMeshPhongMaterial?n.environment:null,i.fog=n.fog;
        let f=e.isMeshStandardMaterial||e.isMeshLambertMaterial&&!e.envMap||e.isMeshPhongMaterial&&!e.envMap;
        i.envMap=h.get(e.envMap||i.environment,f),i.envMapRotation=null!==i.environment&&null===e.envMap?n.environmentRotation:e.envMapRotation,void 0===u&&(e.addEventListener("dispose",eK),i.programs=u=new Map);
        let p=u.get(d);
        if(void 0!==p){
          if(i.currentProgram===p&&i.lightsStateVersion===l)
          return e6(e,s),p
          }else 
        s.uniforms=E.getUniforms(e),null!==eu&&e.isNodeMaterial&&eu.build(e,t,s),e.onBeforeCompile(s,ec),p=E.acquireProgram(s,d),u.set(d,p),i.uniforms=s.uniforms;
        let m=i.uniforms;
        return(e.isShaderMaterial||e.isRawShaderMaterial)&&!0!==e.clipping||(m.clippingPlanes=R.uniform),e6(e,s),i.needsLights=(r=e).isMeshLambertMaterial||r.isMeshToonMaterial||r.isMeshPhongMaterial||r.isMeshStandardMaterial||r.isShadowMaterial||r.isShaderMaterial&&!0===r.lights,i.lightsStateVersion=l,i.needsLights&&(m.ambientLightColor.value=a.state.ambient,m.lightProbe.value=a.state.probe,m.directionalLights.value=a.state.directional,m.directionalLightShadows.value=a.state.directionalShadow,m.spotLights.value=a.state.spot,m.spotLightShadows.value=a.state.spotShadow,m.rectAreaLights.value=a.state.rectArea,m.ltc_1.value=a.state.rectAreaLTC1,m.ltc_2.value=a.state.rectAreaLTC2,m.pointLights.value=a.state.point,m.pointLightShadows.value=a.state.pointShadow,m.hemisphereLights.value=a.state.hemi,m.directionalShadowMatrix.value=a.state.directionalShadowMatrix,m.spotLightMatrix.value=a.state.spotLightMatrix,m.spotLightMap.value=a.state.spotLightMap,m.pointShadowMatrix.value=a.state.pointShadowMatrix),i.lightProbeGrid=ea.state.lightProbeGridArray.length>0,i.currentProgram=p,i.uniformsList=null,p
        }
      function e5(e){
        if(null===e.uniformsList){
          let n=e.currentProgram.getUniforms();
          e.uniformsList=eW.seqWithValue(n.seq,e.uniforms)
          }
        return e.uniformsList
        }
      function e6(e,n){
        let t=c.get(e);
        t.outputColorSpace=n.outputColorSpace,t.batching=n.batching,t.batchingColor=n.batchingColor,t.instancing=n.instancing,t.instancingColor=n.instancingColor,t.instancingMorph=n.instancingMorph,t.skinning=n.skinning,t.morphTargets=n.morphTargets,t.morphNormals=n.morphNormals,t.morphColors=n.morphColors,t.morphTargetsCount=n.morphTargetsCount,t.numClippingPlanes=n.numClippingPlanes,t.numIntersection=n.numClipIntersection,t.vertexAlphas=n.vertexAlphas,t.vertexTangents=n.vertexTangents,t.toneMapping=n.toneMapping
        }
      eQ.setAnimationLoop(function(e){
        ej&&ej(e)
        }),"u">typeof self&&eQ.setContext(self),this.setAnimationLoop=function(e){
        ej=e,ez.setAnimationLoop(e),null===e?eQ.stop():eQ.start()
        },ez.addEventListener("sessionstart",eZ),ez.addEventListener("sessionend",e$),this.render=function(e,t){
        if(void 0!==t&&!0!==t.isCamera)
        return void(0,n.error)("WebGLRenderer.render: camera is not an instance of THREE.Camera.");
        if(!0===ed)
        return;
        null!==eu&&eu.renderStart(e,t);
        let r=!0===ez.enabled&&!0===ez.isPresenting,i=null!==es&&(null===em||r)&&es.begin(ec,em);
        if(!0===e.matrixWorldAutoUpdate&&e.updateMatrixWorld(),null===t.parent&&!0===t.matrixWorldAutoUpdate&&t.updateMatrixWorld(),!0===ez.enabled&&!0===ez.isPresenting&&(null===es||!1===es.isCompositing())&&(!0===ez.cameraAutoUpdate&&ez.updateCamera(t),t=ez.getCamera()),!0===e.isScene&&e.onBeforeRender(ec,e,t,em),(ea=x.get(e,el.length)).init(t),ea.state.textureUnits=_.getTextureUnits(),el.push(ea),eN.multiplyMatrices(t.projectionMatrix,t.matrixWorldInverse),eU.setFromProjectionMatrix(eN,n.WebGLCoordinateSystem,t.reversedDepth),ew=this.localClippingEnabled,eD=R.init(this.clippingPlanes,ew),(ei=M.get(e,eo.length)).init(),eo.push(ei),!0===ez.enabled&&!0===ez.isPresenting){
          let e=ec.xr.getDepthSensingMesh();
          null!==e&&eJ(e,t,-1/0,ec.sortObjects)
          }
        eJ(e,t,0,ec.sortObjects),ei.finish(),!0===ec.sortObjects&&ei.sort(eA,eC),(eO=!1===ez.enabled||!1===ez.isPresenting||!1===ez.hasDepthSensing())&&C.addToRenderList(ei,e),this.info.render.frame++,!0===eD&&R.beginShadows();
        let a=ea.state.shadowsArray;
        if(A.render(a,e,t),!0===eD&&R.endShadows(),!0===this.info.autoReset&&this.info.reset(),!1===(i&&es.hasRenderPass())){
          let n=ei.opaque,r=ei.transmissive;
          if(ea.setupLights(),t.isArrayCamera){
            let i=t.cameras;
            if(r.length>0)
            for(
            let t=0,a=i.length
            ;t<a;t++)
            e1(n,r,e,i[t]);
            eO&&C.render(e);
            for(
            let n=0,t=i.length
            ;n<t;n++){
              let t=i[n];
              e0(ei,e,t,t.viewport)
              }
            }else 
          r.length>0&&e1(n,r,e,t),eO&&C.render(e),e0(ei,e,t)
          }
        null!==em&&0===ep&&(_.updateMultisampleRenderTarget(em),_.updateRenderTargetMipmap(em)),i&&es.end(ec),!0===e.isScene&&e.onAfterRender(ec,e,t),G.resetDefaultState(),e_=-1,eh=null,el.pop(),el.length>0?(ea=el[el.length-1],_.setTextureUnits(ea.state.textureUnits),!0===eD&&R.setGlobalState(ec.clippingPlanes,ea.state.camera)):ea=null,eo.pop(),ei=eo.length>0?eo[eo.length-1]:null,null!==eu&&eu.renderEnd()
        },this.getActiveCubeFace=function(){
        return ef
        },this.getActiveMipmapLevel=function(){
        return ep
        },this.getRenderTarget=function(){
        return em
        },this.setRenderTargetTextures=function(e,n,t){
        let r=c.get(e);
        r.__autoAllocateDepthBuffer=!1===e.resolveDepthBuffer,!1===r.__autoAllocateDepthBuffer&&(r.__useRenderToTexture=!1),c.get(e.texture).__webglTexture=n,c.get(e.depthTexture).__webglTexture=r.__autoAllocateDepthBuffer?void 0:t,r.__hasExternalTextures=!0
        },this.setRenderTargetFramebuffer=function(e,n){
        let t=c.get(e);
        t.__webglFramebuffer=n,t.__useDefaultFramebuffer=void 0===n
        };
      const e8=eG.createFramebuffer();
      this.setRenderTarget=function(e,n=0,t=0){
        em=e,ef=n,ep=t;
        let r=null,i=!1,a=!1;
        if(e){
          let o=c.get(e);
          if(void 0!==o.__useDefaultFramebuffer){
            l.bindFramebuffer(eG.FRAMEBUFFER,o.__webglFramebuffer),eg.copy(e.viewport),ev.copy(e.scissor),eS=e.scissorTest,l.viewport(eg),l.scissor(ev),l.setScissorTest(eS),e_=-1;
            return
            }
          if(void 0===o.__webglFramebuffer)
          _.setupRenderTarget(e);
          else 
          if(o.__hasExternalTextures)
          _.rebindTextures(e,c.get(e.texture).__webglTexture,c.get(e.depthTexture).__webglTexture);
          else 
          if(e.depthBuffer){
            let n=e.depthTexture;
            if(o.__boundDepthTexture!==n){
              if(null!==n&&c.has(n)&&(e.width!==n.image.width||e.height!==n.image.height))
              throw Error("WebGLRenderTarget: Attached DepthTexture is initialized to the incorrect size.");
              _.setupDepthRenderbuffer(e)
              }
            }
          let s=e.texture;
          (s.isData3DTexture||s.isDataArrayTexture||s.isCompressedArrayTexture)&&(a=!0);
          let d=c.get(e).__webglFramebuffer;
          e.isWebGLCubeRenderTarget?(r=Array.isArray(d[n])?d[n][t]:d[n],i=!0):r=e.samples>0&&!1===_.useMultisampledRTT(e)?c.get(e).__webglMultisampledFramebuffer:Array.isArray(d)?d[t]:d,eg.copy(e.viewport),ev.copy(e.scissor),eS=e.scissorTest
          }else 
        eg.copy(eb).multiplyScalar(eR).floor(),ev.copy(eP).multiplyScalar(eR).floor(),eS=eL;
        if(0!==t&&(r=e8),l.bindFramebuffer(eG.FRAMEBUFFER,r)&&l.drawBuffers(e,r),l.viewport(eg),l.scissor(ev),l.setScissorTest(eS),i){
          let r=c.get(e.texture);
          eG.framebufferTexture2D(eG.FRAMEBUFFER,eG.COLOR_ATTACHMENT0,eG.TEXTURE_CUBE_MAP_POSITIVE_X+n,r.__webglTexture,t)
          }else 
        if(a)
        for(
        let r=0
        ;r<e.textures.length;r++){
          let i=c.get(e.textures[r]);
          eG.framebufferTextureLayer(eG.FRAMEBUFFER,eG.COLOR_ATTACHMENT0+r,i.__webglTexture,t,n)
          }
        else 
        if(null!==e&&0!==t){
          let n=c.get(e.texture);
          eG.framebufferTexture2D(eG.FRAMEBUFFER,eG.COLOR_ATTACHMENT0,eG.TEXTURE_2D,n.__webglTexture,t)
          }
        e_=-1
        },this.readRenderTargetPixels=function(e,t,r,i,a,s,d,u=0){
        if(!(e&&e.isWebGLRenderTarget))
        return void(0,n.error)("WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
        let f=c.get(e).__webglFramebuffer;
        if(e.isWebGLCubeRenderTarget&&void 0!==d&&(f=f[d]),f){
          l.bindFramebuffer(eG.FRAMEBUFFER,f);
          try{
            let l=e.textures[u],c=l.format,d=l.type;
            if(e.textures.length>1&&eG.readBuffer(eG.COLOR_ATTACHMENT0+u),!o.textureFormatReadable(c))
            return void(0,n.error)("WebGLRenderer.readRenderTargetPixels: renderTarget is not in RGBA or implementation defined format.");
            if(!o.textureTypeReadable(d))
            return void(0,n.error)("WebGLRenderer.readRenderTargetPixels: renderTarget is not in UnsignedByteType or implementation defined type.");
            t>=0&&t<=e.width-i&&r>=0&&r<=e.height-a&&eG.readPixels(t,r,i,a,O.convert(c),O.convert(d),s)
            }finally{
            let e=null!==em?c.get(em).__webglFramebuffer:null;
            l.bindFramebuffer(eG.FRAMEBUFFER,e)
            }
          }
        },this.readRenderTargetPixelsAsync=async function(e,t,r,i,a,s,d,u=0){
        if(!(e&&e.isWebGLRenderTarget))
        throw Error("THREE.WebGLRenderer.readRenderTargetPixels: renderTarget is not THREE.WebGLRenderTarget.");
        let f=c.get(e).__webglFramebuffer;
        if(e.isWebGLCubeRenderTarget&&void 0!==d&&(f=f[d]),f)
        if(t>=0&&t<=e.width-i&&r>=0&&r<=e.height-a){
          l.bindFramebuffer(eG.FRAMEBUFFER,f);
          let d=e.textures[u],p=d.format,m=d.type;
          if(e.textures.length>1&&eG.readBuffer(eG.COLOR_ATTACHMENT0+u),!o.textureFormatReadable(p))
          throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in RGBA or implementation defined format.");
          if(!o.textureTypeReadable(m))
          throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: renderTarget is not in UnsignedByteType or implementation defined type.");
          let _=eG.createBuffer();
          eG.bindBuffer(eG.PIXEL_PACK_BUFFER,_),eG.bufferData(eG.PIXEL_PACK_BUFFER,s.byteLength,eG.STREAM_READ),eG.readPixels(t,r,i,a,O.convert(p),O.convert(m),0);
          let h=null!==em?c.get(em).__webglFramebuffer:null;
          l.bindFramebuffer(eG.FRAMEBUFFER,h);
          let g=eG.fenceSync(eG.SYNC_GPU_COMMANDS_COMPLETE,0);
          return eG.flush(),await (0,n.probeAsync)(eG,g,4),eG.bindBuffer(eG.PIXEL_PACK_BUFFER,_),eG.getBufferSubData(eG.PIXEL_PACK_BUFFER,0,s),eG.deleteBuffer(_),eG.deleteSync(g),s
          }else 
        throw Error("THREE.WebGLRenderer.readRenderTargetPixelsAsync: requested read bounds are out of range.")
        },this.copyFramebufferToTexture=function(e,n=null,t=0){
        let r=Math.pow(2,-t),i=Math.floor(e.image.width*r),a=Math.floor(e.image.height*r),o=null!==n?n.x:0,s=null!==n?n.y:0;
        _.setTexture2D(e,0),eG.copyTexSubImage2D(eG.TEXTURE_2D,t,0,0,o,s,i,a),l.unbindTexture()
        };
      const e9=eG.createFramebuffer(),e7=eG.createFramebuffer();
      this.copyTextureToTexture=function(e,n,t=null,r=null,i=0,a=0){
        let o,s,d,u,f,p,m,h,g,v,S=e.isCompressedTexture?e.mipmaps[a]:e.image;
        if(null!==t)
        o=t.max.x-t.min.x,s=t.max.y-t.min.y,d=t.isBox3?t.max.z-t.min.z:1,u=t.min.x,f=t.min.y,p=t.isBox3?t.min.z:0;
        else{
          let n=Math.pow(2,-i);
          o=Math.floor(S.width*n),s=Math.floor(S.height*n),d=e.isDataArrayTexture?S.depth:e.isData3DTexture?Math.floor(S.depth*n):1,u=0,f=0,p=0
          }
        null!==r?(m=r.x,h=r.y,g=r.z):(m=0,h=0,g=0);
        let E=O.convert(n.format),T=O.convert(n.type);
        n.isData3DTexture?(_.setTexture3D(n,0),v=eG.TEXTURE_3D):n.isDataArrayTexture||n.isCompressedArrayTexture?(_.setTexture2DArray(n,0),v=eG.TEXTURE_2D_ARRAY):(_.setTexture2D(n,0),v=eG.TEXTURE_2D),l.activeTexture(eG.TEXTURE0),l.pixelStorei(eG.UNPACK_FLIP_Y_WEBGL,n.flipY),l.pixelStorei(eG.UNPACK_PREMULTIPLY_ALPHA_WEBGL,n.premultiplyAlpha),l.pixelStorei(eG.UNPACK_ALIGNMENT,n.unpackAlignment);
        let M=l.getParameter(eG.UNPACK_ROW_LENGTH),x=l.getParameter(eG.UNPACK_IMAGE_HEIGHT),R=l.getParameter(eG.UNPACK_SKIP_PIXELS),A=l.getParameter(eG.UNPACK_SKIP_ROWS),C=l.getParameter(eG.UNPACK_SKIP_IMAGES);
        l.pixelStorei(eG.UNPACK_ROW_LENGTH,S.width),l.pixelStorei(eG.UNPACK_IMAGE_HEIGHT,S.height),l.pixelStorei(eG.UNPACK_SKIP_PIXELS,u),l.pixelStorei(eG.UNPACK_SKIP_ROWS,f),l.pixelStorei(eG.UNPACK_SKIP_IMAGES,p);
        let b=e.isDataArrayTexture||e.isData3DTexture,P=n.isDataArrayTexture||n.isData3DTexture;
        if(e.isDepthTexture){
          let t=c.get(e),r=c.get(n),_=c.get(t.__renderTarget),v=c.get(r.__renderTarget);
          l.bindFramebuffer(eG.READ_FRAMEBUFFER,_.__webglFramebuffer),l.bindFramebuffer(eG.DRAW_FRAMEBUFFER,v.__webglFramebuffer);
          for(
          let t=0
          ;t<d;t++)
          b&&(eG.framebufferTextureLayer(eG.READ_FRAMEBUFFER,eG.COLOR_ATTACHMENT0,c.get(e).__webglTexture,i,p+t),eG.framebufferTextureLayer(eG.DRAW_FRAMEBUFFER,eG.COLOR_ATTACHMENT0,c.get(n).__webglTexture,a,g+t)),eG.blitFramebuffer(u,f,o,s,m,h,o,s,eG.DEPTH_BUFFER_BIT,eG.NEAREST);
          l.bindFramebuffer(eG.READ_FRAMEBUFFER,null),l.bindFramebuffer(eG.DRAW_FRAMEBUFFER,null)
          }else 
        if(0!==i||e.isRenderTargetTexture||c.has(e)){
          let t=c.get(e),r=c.get(n);
          l.bindFramebuffer(eG.READ_FRAMEBUFFER,e9),l.bindFramebuffer(eG.DRAW_FRAMEBUFFER,e7);
          for(
          let e=0
          ;e<d;e++)
          b?eG.framebufferTextureLayer(eG.READ_FRAMEBUFFER,eG.COLOR_ATTACHMENT0,t.__webglTexture,i,p+e):eG.framebufferTexture2D(eG.READ_FRAMEBUFFER,eG.COLOR_ATTACHMENT0,eG.TEXTURE_2D,t.__webglTexture,i),P?eG.framebufferTextureLayer(eG.DRAW_FRAMEBUFFER,eG.COLOR_ATTACHMENT0,r.__webglTexture,a,g+e):eG.framebufferTexture2D(eG.DRAW_FRAMEBUFFER,eG.COLOR_ATTACHMENT0,eG.TEXTURE_2D,r.__webglTexture,a),0!==i?eG.blitFramebuffer(u,f,o,s,m,h,o,s,eG.COLOR_BUFFER_BIT,eG.NEAREST):P?eG.copyTexSubImage3D(v,a,m,h,g+e,u,f,o,s):eG.copyTexSubImage2D(v,a,m,h,u,f,o,s);
          l.bindFramebuffer(eG.READ_FRAMEBUFFER,null),l.bindFramebuffer(eG.DRAW_FRAMEBUFFER,null)
          }else 
        P?e.isDataTexture||e.isData3DTexture?eG.texSubImage3D(v,a,m,h,g,o,s,d,E,T,S.data):n.isCompressedArrayTexture?eG.compressedTexSubImage3D(v,a,m,h,g,o,s,d,E,S.data):eG.texSubImage3D(v,a,m,h,g,o,s,d,E,T,S):e.isDataTexture?eG.texSubImage2D(eG.TEXTURE_2D,a,m,h,o,s,E,T,S.data):e.isCompressedTexture?eG.compressedTexSubImage2D(eG.TEXTURE_2D,a,m,h,S.width,S.height,E,S.data):eG.texSubImage2D(eG.TEXTURE_2D,a,m,h,o,s,E,T,S);
        l.pixelStorei(eG.UNPACK_ROW_LENGTH,M),l.pixelStorei(eG.UNPACK_IMAGE_HEIGHT,x),l.pixelStorei(eG.UNPACK_SKIP_PIXELS,R),l.pixelStorei(eG.UNPACK_SKIP_ROWS,A),l.pixelStorei(eG.UNPACK_SKIP_IMAGES,C),0===a&&n.generateMipmaps&&eG.generateMipmap(v),l.unbindTexture()
        },this.initRenderTarget=function(e){
        void 0===c.get(e).__webglFramebuffer&&_.setupRenderTarget(e)
        },this.initTexture=function(e){
        e.isCubeTexture?_.setTextureCube(e,0):e.isData3DTexture?_.setTexture3D(e,0):e.isDataArrayTexture||e.isCompressedArrayTexture?_.setTexture2DArray(e,0):_.setTexture2D(e,0),l.unbindTexture()
        },this.resetState=function(){
        ef=0,ep=0,em=null,l.reset(),G.reset()
        },"u">typeof __THREE_DEVTOOLS__&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))
      }get coordinateSystem(){
      return n.WebGLCoordinateSystem
      }get outputColorSpace(){
      return this._outputColorSpace
      }set outputColorSpace(e){
      this._outputColorSpace=e;
      let t=this.getContext();
      t.drawingBufferColorSpace=n.ColorManagement._getDrawingBufferColorSpace(e),t.unpackColorSpace=n.ColorManagement._getUnpackColorSpace()
      }
  },"WebGLUtils",0,nR])
  }]);
