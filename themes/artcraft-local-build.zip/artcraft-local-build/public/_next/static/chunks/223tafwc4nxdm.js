(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,33209,e=>{
  "use strict";
  var t=e.i(43476),a=e.i(71645),r=e.i(89970),l=e.i(74268),i=e.i(91672),o=e.i(21853),n=e.i(79655);
  let s="ARTCRAFT",u=116.34/97.5;
  function c({cap:e,lift:a}){
    return(0,t.jsx)("svg",{viewBox:"0 0 116.34 97.5",fill:"currentColor","aria-hidden":!0,style:{display:"inline-block",width:`${e*u}em`,height:`${e}em`,verticalAlign:`${a}em`,filter:"drop-shadow(0 0 0.3vw color-mix(in srgb, var(--bg) 85%, transparent)) drop-shadow(0 0.2vw 1.6vw color-mix(in srgb, var(--bg) 60%, transparent))"},children:(0,t.jsx)("path",{d:"M104.28,49.49L81.55,0h-31.23l-3.17,4.76L14.75,53.63,0,75.85l21.55,21.55,63.79-36.94,16.99,37.04,14.01-21.74-12.06-26.27ZM32.89,65.66l32.42-48.87,10.91,23.77-43.32,25.09Z"})})
    }
  e.s(["HeroScrim",0,function(){
    let[e,l]=(0,a.useState)(-1),s=(0,a.useRef)(null);
    (0,a.useEffect)(()=>{
      let e,t=()=>l(o.useTunerStore.getState().version);
      t();
      let a=o.useTunerStore.subscribe(()=>{
        clearTimeout(e),e=setTimeout(t,150)
        });
      return()=>{
        clearTimeout(e),a()
        }
      },[]),(0,a.useEffect)(()=>{
      if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
      let e=()=>{
        let e=i.introTuner.read(),t=Math.max(0,Math.min(1,(i.introClock.t-e.cardsAt)/.9));
        s.current&&(s.current.style.opacity=String(t))
        };
      return r.default.ticker.add(e),()=>{
        r.default.ticker.remove(e),s.current&&(s.current.style.opacity="")
        }
      },[]);
    let u=e<0?(0,n.wordmarkDefaults)():n.wordmarkTuner.read();
    return(0,t.jsx)("div",{ref:s,"aria-hidden":!0,className:"absolute",style:{inset:`-${u.scrimPadY}px -${u.scrimPadX}px`,background:`radial-gradient(closest-side, color-mix(in srgb, var(--bg) ${u.scrimBg}%, transparent), transparent)`}})
    },"default",0,function(){
    let e=(0,a.useRef)(null),d=(0,a.useRef)([]),[h,f]=(0,a.useState)(0),[m,p]=(0,a.useState)(-1);
    (0,a.useEffect)(()=>{
      let e,t=()=>p(o.useTunerStore.getState().version);
      t();
      let a=o.useTunerStore.subscribe(()=>{
        clearTimeout(e),e=setTimeout(t,150)
        });
      return()=>{
        clearTimeout(e),a()
        }
      },[]);
    let g=m<0?(0,n.wordmarkDefaults)():n.wordmarkTuner.read(),b=(0,a.useRef)(g);
    return b.current=g,(0,a.useEffect)(()=>{
      let t=e.current;
      if(!t)
      return;
      let a=!1,r=()=>{
        if(a)
        return;
        let e=document.createElement("span");
        e.style.cssText="position:absolute;left:-9999px;top:0;visibility:hidden;white-space:pre;font-size:100px;line-height:1;",e.style.fontFamily=n.WORDMARK_FONT,e.style.fontWeight=String(g.weight),e.style.fontStretch=`${n.WORDMARK_STRETCH}%`,e.textContent=s.slice(1),document.body.appendChild(e);
        let r=e.getBoundingClientRect().width;
        e.remove();
        let l=t.clientWidth;
        r>0&&l>0&&f(Math.round(l/(r/100+g.logoCap*u+g.logoPad)*10)/10)
        },l=document.fonts?.ready;
      l?l.then(r).catch(r):r();
      let i=new ResizeObserver(r);
      return i.observe(t),()=>{
        a=!0,i.disconnect()
        }
      },[m]),(0,a.useEffect)(()=>{
      if(!h)
      return;
      let e=d.current.filter(e=>!!e);
      if(e.length!==s.length)
      return;
      let t=()=>{
        for(
        let t
         of e)
        t.style.transform="",t.style.fontWeight="",t.style.fontStretch="",t.style.width="";
        let t=e.map(e=>e.getBoundingClientRect());
        e.forEach((e,a)=>{
          e.style.width=`${t[a].width}px`
          }),l.heroWordmark.els=e,l.heroWordmark.baseX=t.map(e=>e.left+e.width/2),l.heroWordmark.baseDocY=t.map(e=>e.top+e.height/2+window.scrollY);
        let a=t.map(e=>e.width/h),r=[],i=0;
        for(
        let e
         of a)
        r.push(i),i+=e;
        l.heroWordmark.metrics={adv:a,cum:r,total:i},l.heroWordmark.fontPx=h,l.heroWordmark.ready=!0
        };
      return t(),window.addEventListener("resize",t),()=>{
        window.removeEventListener("resize",t),l.heroWordmark.ready=!1,l.heroWordmark.els=[]
        }
      },[h]),(0,a.useEffect)(()=>{
      if(!h||window.matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
      let e=d.current.filter(e=>!!e);
      if(e.length!==s.length)
      return;
      let t=e=>Math.max(0,Math.min(1,e)),a=()=>{
        let o;
        if(!l.heroWordmark.ready)
        return;
        let n=i.introTuner.read(),s=i.introClock.t,u=l.heroWordmark.baseX,c=l.heroWordmark.metrics.adv,d=l.heroWordmark.fontPx,h=e.length,f=u[0]-c[0]*d/2,m=u[h-1]+c[h-1]*d/2,p=(o=t((s-n.wordAt)/Math.max(.1,n.wordDur)))<.5?4*o*o*o:1-Math.pow(-2*o+2,3)/2,g=u[0]+((f+m)/2-u[0])*(1-p);
        e[0].style.transform=`translate3d(${(g-u[0]).toFixed(1)}px, 0, 0)`,e[0].style.opacity=String(t(s/.3));
        let v=g+c[0]*d/2,x=-(u[h-1]+c[h-1]*d/2-(u[0]+c[0]*d/2))-b.current.bladeTuck*d,w=t((s-n.wordAt)/Math.max(.1,n.wordDur)),y=x*(1-(1-Math.pow(1-w,3)));
        for(
        let t=1
        ;t<h;t++){
          let a=u[t]+y;
          e[t].style.transform=`translate3d(${y.toFixed(1)}px, 0, 0)`,e[t].style.opacity="1";
          let r=v-(a-c[t]*d/2);
          e[t].style.clipPath=r>.5?`inset(-20% 0 -20% ${r.toFixed(1)}px)`:""
          }
        if(p>=1&&w>=1&&s>.35){
          for(
          let t
           of e)
          t.style.transform="",t.style.opacity="1",t.style.clipPath="";
          l.heroWordmark.forming=!1,r.default.ticker.remove(a)
          }
        },o=()=>{
        let t=i.introTuner.read(),o=t.wordAt+t.wordDur+.5;
        if(i.introClock.t>o){
          for(
          let t
           of e)
          t.style.opacity="1";
          return
          }
        for(
        let t
         of(r.default.ticker.remove(a),l.heroWordmark.forming=!0,e))
        t.style.opacity="0";
        r.default.ticker.add(a)
        };
      o();
      let n=(0,i.onIntroReplay)(o);
      return()=>{
        for(
        let e
         of(n(),r.default.ticker.remove(a),l.heroWordmark.forming=!1,d.current))
        e&&(e.style.transform="",e.style.opacity="",e.style.clipPath="")
        }
      },[h]),(0,t.jsxs)("div",{ref:e,className:"pointer-events-none relative z-40 w-full",style:{containerType:"inline-size"},children:[(0,t.jsx)("div",{"aria-hidden":!0,className:"absolute -inset-x-[6%] -inset-y-[34%]",style:{backdropFilter:"blur(12px)",WebkitBackdropFilter:"blur(12px)",maskImage:"radial-gradient(closest-side, black 45%, transparent 100%)",WebkitMaskImage:"radial-gradient(closest-side, black 45%, transparent 100%)"}}),(0,t.jsx)("div",{role:"img","aria-label":s,className:"relative whitespace-pre text-ink-strong",style:{fontFamily:n.WORDMARK_FONT,fontWeight:g.weight,fontStretch:`${n.WORDMARK_STRETCH}%`,fontSize:h||"17.8cqw",lineHeight:1},children:s.split("").map((e,a)=>(0,t.jsx)("span",{"aria-hidden":!0,ref:e=>{
      d.current[a]=e
      },className:"wm-letter inline-block text-center",style:{...0===a?{paddingRight:`${g.logoPad}em`}:null,willChange:"transform, opacity",textShadow:"0 0 0.6vw color-mix(in srgb, var(--bg) 92%, transparent), 0 0.25vw 2.4vw color-mix(in srgb, var(--bg) 78%, transparent), 0 0.4vw 5vw color-mix(in srgb, var(--bg) 55%, transparent)"},children:0===a?(0,t.jsx)(c,{cap:g.logoCap,lift:g.logoLift}):e},a))})]})
    }])
  },17031,e=>{
  "use strict";
  var t=e.i(43476),a=e.i(71645),r=e.i(75056),l=e.i(25234),i=e.i(1950),i=i,o=e.i(90072),n=e.i(25215),s=e.i(69529),u=e.i(91672),c=e.i(82040),d=e.i(21853);
  let h=(0,d.defineTunables)("galaxyLayout","Galaxy layout",{arms:{label:"Arms",min:2,max:6,step:1,default:6,info:"How many spiral arms emanate from the center; cards are dealt across them round-robin."},turns:{label:"Turns per arm",min:.4,max:2.5,step:.05,default:1.05,info:"How many revolutions each arm makes from origin to outer end — lower is straighter rays, higher is a tighter swirl."},rMaxFrac:{label:"Track pitch",min:.4,max:1.2,step:.02,default:.7,info:"Sets the spiral's tightness: the radius the drawn windings span, as a fraction of the viewport half-diagonal. Larger = wider winding gaps = bigger cards. Cards travel past it until fully offscreen."},birthFrac:{label:"Birth radius",min:.02,max:.4,step:.01,default:.08,info:"Where cards are born, as a fraction of the outer radius — the nebula pocket around the wordmark."},cardN:{label:"Card count",min:8,max:96,step:1,default:64,info:"Cards riding the arms at the reference viewport size; smaller viewports scale this down proportionally (see Tuned @ Mpx)."},tunedMpx:{label:"Tuned @ Mpx",min:.5,max:12,step:.1,default:1.65,info:"Viewport area (CSS megapixels) the card count was tuned at. Smaller viewports get proportionally fewer cards — never more than the count knob."},cardHFrac:{label:"Card h cap",min:.08,max:.35,step:.005,default:.25,info:"Absolute card height ceiling as a fraction of the viewport height — the track-gap math sizes cards below this so they never collide."},armJitter:{label:"Arm desync",min:0,max:1,step:.01,default:.76,info:"Per-arm conveyor stagger in slot gaps — 0 births all arms in lockstep rings; ~0.38 (golden) scatters them evenly at any card count."},ticksPerArm:{label:"Ticks / arm",min:0,max:40,step:1,default:16,info:"Tick marks straddling each arm's outer half in the line underlay (0 = none)."},circFrac:{label:"Constr circle",min:.2,max:1,step:.02,default:.56,info:"Radius of the dashed construction circle in the underlay, as a fraction of the outer radius."},guideX:{label:"Guide lines ×",min:1,max:4,step:1,default:1,info:"Underlay line density: guide curves per card arm (2 draws a phantom guide midway between arms). Mobile profile always keeps 1×."},dedupPx:{label:"Dedup px",min:0,max:800,step:10,default:300,info:"Two visible cards sharing a clip closer than this on screen trigger a reassignment of the blurrier one (the swap hides inside its birth blur). 0 disables."}}),f=(0,d.defineTunables)("galaxyMobile","Galaxy mobile",{mobMpx:{label:"Mobile < Mpx",min:0,max:1.2,step:.05,default:.6,info:"Viewports smaller than this megapixel area use the mobile profile below instead of the Galaxy-layout values. 0 disables the profile."},mobArms:{label:"Arms",min:1,max:6,step:1,default:3,info:"Arm count on mobile — fewer arms means less angular crowding on a narrow stage."},mobTurns:{label:"Turns",min:.3,max:2,step:.05,default:.7,info:"Spiral windings on mobile — straighter arms space consecutive cards further apart radially, so they can run larger."},mobCardN:{label:"Card count",min:4,max:40,step:1,default:14,info:"Cards riding the arms on mobile — a fixed count, not scaled from the desktop knob."},mobRMax:{label:"Outer radius",min:.3,max:1.2,step:.02,default:.8,info:"Spiral reach on mobile as a fraction of the half-diagonal — how far the arms extend past the small stage."},mobCardH:{label:"Card h cap",min:.08,max:.5,step:.005,default:.3,info:"Card height ceiling on mobile as a fraction of the viewport height."},mobBirth:{label:"Birth radius",min:.02,max:.3,step:.005,default:.08,info:"Where cards are born on mobile, as a fraction of the outer radius."},mobDensityX:{label:"Density ×",min:1,max:1.6,step:.02,default:1.15,info:"Density multiplier on mobile — lets cards claim more of their (larger) neighbor gaps."}}),m=(0,d.defineTunables)("galaxyMotion","Galaxy motion",{idleSpeed:{label:"Idle cyc/min",min:0,max:.8,step:.01,default:.57,info:"Unattended conveyor speed — full journeys (birth to edge) per minute."},scrub:{label:"Scrub /1kpx",min:0,max:1,step:.01,default:.2,info:"Conveyor journeys advanced per 1000px of scroll — scroll-linked and reversible."},spinDeg:{label:"Spin °/min",min:-60,max:60,step:.5,default:-50,info:"Slow global rotation of the whole system (arms, ticks, and card paths together); cards themselves stay upright."},wobbleAmp:{label:"Wobble px",min:0,max:40,step:1,default:6,info:"How far cards drift off their exact arm position — the floating-in-space noise. Collision-safe: sizing measures the real wobbled positions."},wobbleFreq:{label:"Wobble Hz",min:0,max:2,step:.05,default:.25,info:"Speed of the floating drift."},introDur:{label:"Wave dur s",min:.4,max:4,step:.05,default:4,info:"Duration of the intro reveal wave sweeping from the logo past the outer edge. Starts at the master Intro group's Cards beat."},rollChunk:{label:"Roll chunk",min:0,max:.5,step:.01,default:.12,info:"Fraction of the journey cards drift outward during the reveal — they start slightly short of their spread positions and slide the last chunk in as the wave uncovers them. 0 = reveal in place."},burstX:{label:"Burst ×",min:1,max:8,step:.1,default:3,info:"Conveyor speed multiplier at the start of the intro, easing down to normal — the field arrives moving and settles into its drift."},burstDur:{label:"Burst ease s",min:.5,max:6,step:.1,default:2.5,info:"How long the speed burst takes to ease back to normal conveyor speed."},waveBand:{label:"Wave band px",min:40,max:600,step:10,default:220,info:"Thickness of the reveal wave's front — the zone where a card fades in and racks from blur to focus."},waveAber:{label:"Wave flare",min:0,max:.3,step:.002,default:.2,info:"Dispersion flare of the chromatic ring trailing the reveal wave — cards flash as it crosses them."},waveLag:{label:"Flare lag s",min:0,max:1,step:.05,default:.4,info:"How far behind the reveal front the dispersion ring launches — it sweeps the already-revealed field as a second pass."},perfFloor:{label:"FPS floor",min:0,max:60,step:5,default:30,info:"When sustained frame rate drops below this, the galaxy sheds cards (and their decoders) until smooth, then slowly regrows. 0 disables the governor."}}),p=(0,d.defineTunables)("galaxyPointer","Galaxy pointer",{fieldPx:{label:"Field px",min:80,max:800,step:10,default:320,info:"Radius of the cursor's influence — cards inside it tilt toward the pointer and pick up dispersion flare."},tiltDeg:{label:"Tilt °",min:0,max:25,step:.5,default:0,info:"Maximum lean of a card toward the cursor at the field's center — the pulled-at feel. The targeted card straightens to zero."},tugPx:{label:"Tug px",min:0,max:40,step:1,default:8,info:"How far cards inside the field are actually displaced toward the cursor — the translation pull. Collision-safe: sizing measures the tugged positions."},mouseWarp:{label:"Mouse warp px",min:0,max:400,step:1,default:200,info:"The cursor's weight on nearby card surfaces: a local bulge toward the camera at the point of the card nearest the mouse, on top of the base curve warp."},flareAdd:{label:"Flare add",min:0,max:.08,step:.002,default:.032,info:"Extra chromatic dispersion picked up by cards the cursor sweeps near, on top of the base aberration."},flareDecay:{label:"Flare decay /s",min:.5,max:8,step:.1,default:3,info:"How fast the sweep flare fades behind the cursor — lower leaves a longer lens trail."},holdTau:{label:"Hold tau s",min:.05,max:1,step:.05,default:.15,info:"How quickly the targeted card's conveyor motion brakes to a stop under the cursor."},restTau:{label:"Rest tau s",min:.1,max:4,step:.05,default:1,info:"How quickly the rest of the spiral follows the target to a stop — deliberately slower, so the hold reads as spreading outward from the hand."},holdWobble:{label:"Hold wobble ×",min:1,max:3,step:.1,default:1.2,info:"Wobble multiplier on the rest of the spiral while a card is held — the flow strains gently against the freeze."},targetTau:{label:"Target tau s",min:.05,max:12,step:.05,default:.25,info:"Behavioral ease of the target lock (sizing pin, paint order, decode priority, wobble kill). The optical clear — dispersion, blur, warp, wash — always runs at a fixed fast pace regardless."},rippleSpeed:{label:"Ripple px/s",min:200,max:3e3,step:50,default:900,info:"Expansion speed of a click's dispersion ring."},rippleWidth:{label:"Ripple width",min:40,max:400,step:10,default:140,info:"Thickness of the ripple's dispersion band."},rippleAmp:{label:"Ripple amp",min:0,max:.1,step:.002,default:.016,info:"Peak dispersion the ripple adds to cards it crosses. Multiple clicks stack."},rippleWarp:{label:"Ripple warp px",min:0,max:80,step:1,default:22,info:"How far a card's surface pops toward the camera as the ripple ring passes through it — the physical half of the click feedback."},rippleLife:{label:"Ripple life s",min:.4,max:4,step:.1,default:1.8,info:"How long a ripple keeps its strength as it travels before fading out."},clickAmp:{label:"Punch amp px",min:0,max:30,step:1,default:20,info:"Peak texture displacement of the local click punch — the circular wave that grows from the click point across the clicked card only. Clicks stack."},clickDur:{label:"Punch dur s",min:.2,max:1.5,step:.05,default:.75,info:"Time for the punch ring to travel from the click point to the card edges and die."},clickWidth:{label:"Punch width",min:.04,max:.4,step:.01,default:.14,info:"Thickness of the punch ring as a fraction of the card size — the softness of the blurred circle driving the displacement."},boostScale:{label:"Boost scale ×",min:1.2,max:4,step:.1,default:3,info:"Scale multiplier a click toggles onto the held card. Allowed to overlap neighbors; scales back down on leaving the card, and the next hold needs a fresh click."},boostTau:{label:"Boost tau s",min:.05,max:.6,step:.01,default:.18,info:"Ease time of the click-boost scale, up and down."}}),g=(0,d.defineTunables)("galaxyLook","Galaxy look",{density:{label:"Density",min:.3,max:1,step:.02,default:.82,info:"Fraction of the gap to its nearest neighbor each card may fill — higher packs the screen tighter, lower gives more air. Collision-free across the whole range (at 1.0 cards may kiss edges)."},cornerPx:{label:"Corner px",min:0,max:24,step:1,default:10,info:"Corner radius of each card (and its hairline frame), in px — the one deliberate exception to the site's zero-radius rule."},innerCap:{label:"Inner cap",min:.2,max:1,step:.02,default:.45,info:"Size ceiling for newborn cards as a fraction of the full cap, ramping up over the journey — keeps inner cards smaller than outer ones even when space would allow more."},aspectEnd:{label:"Square until",min:.05,max:.8,step:.01,default:.3,info:"Journey fraction over which a newborn card morphs from a rounded square into its full 16:9 aspect."},blurMax:{label:"Blur max",min:0,max:.25,step:.005,default:.12,info:"Blur radius (in card-UV units) at birth — the nebula softness at the center; also the blur a still-loading card holds."},blurEnd:{label:"Blur end",min:.05,max:.9,step:.01,default:.18,info:"Journey fraction where the blur fully resolves to sharp."},playFrac:{label:"Play from",min:0,max:1,step:.02,default:.14,info:"Journey fraction past which a card's clip earns a live decoder — inner blurred cards hold a frozen frame."},fadeBand:{label:"Birth fade",min:.02,max:.3,step:.01,default:.15,info:"Fraction of the journey over which a newborn card fades in at the center. There is no exit fade — cards die fully offscreen."},aberration:{label:"Dispersion",min:0,max:.06,step:.001,default:.019,info:"Chromatic aberration strength toward each card's edges — the cheap lens-dispersion detail."},curvePx:{label:"Curve px",min:0,max:160,step:1,default:32,info:"How far each card's center bows toward the camera — the slight lens-warp of the plane."},frameAlpha:{label:"Frame alpha",min:0,max:1,step:.02,default:.22,info:"Strength of the hairline frame drawn along each card's (rounded) edge."},lineAlpha:{label:"Line alpha",min:0,max:1,step:.02,default:.15,info:"Opacity of the arm guide curves and construction circle in the underlay — 0 kills the geometric layer entirely."},tickAlpha:{label:"Tick alpha",min:0,max:1,step:.02,default:.3,info:"Opacity of the tick marks along the arms."},lineW:{label:"Line px",min:.5,max:3,step:.1,default:2,info:"Base thickness of the arm guide ribbons — the resting hairline weight."},pulseAlpha:{label:"Pulse alpha",min:0,max:1,step:.02,default:.72,info:"Peak extra opacity of the color pulses traveling along the arm lines (0 = no pulses)."},pulseSpeed:{label:"Pulse speed",min:0,max:.8,step:.01,default:.19,info:"Pulse travel speed — band cycles per second along each arm, moving outward faster than the conveyor."},pulseWidth:{label:"Pulse length",min:.01,max:.25,step:.005,default:.05,info:"Length of each comet as a fraction of its band — sharp head, longer tail behind."},pulseW:{label:"Pulse thick px",min:0,max:8,step:.25,default:3.5,info:"Extra ribbon thickness at a pulse's peak — the colored part swells above the hairline."},pulseCount:{label:"Pulses / arm",min:1,max:6,step:1,default:3,info:"Simultaneous pulses riding each arm."},pulseHue:{label:"Pulse hue spread",min:0,max:1,step:.02,default:.4,info:"Dark theme only: per-arm hue rotation of the pulse color away from the accent — 0 keeps every arm brand blue, 1 spreads across the wheel. Light theme is always colorless."},pulseDark:{label:"Pulse gray (light)",min:0,max:1,step:.02,default:.62,info:"Light theme only: darkness of the plain gray pulses (ink mixed over the paper; 1 = ink-black). Light mode carries the pulse with thickness, not color."}}),b=`
  uniform float uCurve;
  uniform float uWarp;
  uniform vec2 uMouse;
  uniform vec2 uSize;
  out vec2 vUv;
  void main() {
    vUv = uv;
    vec4 world = modelMatrix * vec4(position, 1.0);
    // Bow the plane toward the camera: strongest at the card center,
    // flat at the edges. Applied in world space so it reads in px.
    float d2 = dot(position.xy, position.xy);
    world.z += uCurve * (0.25 - d2) * 2.0;
    // The cursor's weight: a local bulge toward the camera at the point of
    // the card nearest the mouse (uMouse in card-local units, may lie
    // outside the card) — the surface leans into the hand.
    vec2 dpx = (position.xy - uMouse) * uSize;
    float rr = max(uSize.x, uSize.y) * 0.6;
    world.z += uWarp * exp(-dot(dpx, dpx) / (rr * rr));
    gl_Position = projectionMatrix * viewMatrix * world;
  }
`,v=`
  uniform sampler2D uMap;
  uniform vec2 uRepeat;
  uniform vec2 uOffset;
  uniform vec3 uBg;
  uniform float uBlur;
  uniform float uTexA;
  uniform float uAlpha;
  uniform float uAber;
  uniform vec2 uSize;
  uniform float uRadius;
  uniform vec3 uFrameCol;
  uniform float uFrameA;
  // Local click punches: xy = ring center (card UV), z = ring radius px,
  // w = displacement amplitude px (0 = slot unused). uClickW is the ring
  // thickness in px — the "blur" of the circle driving the displacement.
  uniform vec4 uClick[4];
  uniform float uClickW;
  in vec2 vUv;
  out vec4 outColor;

  const vec2 TAPS[12] = vec2[12](
    vec2(-0.326, -0.406), vec2(-0.840, -0.074), vec2(-0.696, 0.457),
    vec2(-0.203, 0.621), vec2(0.962, -0.195), vec2(0.473, -0.480),
    vec2(0.519, 0.767), vec2(0.185, -0.893), vec2(0.507, 0.064),
    vec2(0.896, 0.412), vec2(-0.322, -0.933), vec2(-0.792, -0.598)
  );

  void main() {
    // Local click punches: a soft gaussian ring pushes the texture
    // radially outward from the click point — the classic blurred-circle
    // displacement, evaluated inline. Stackable across the four slots.
    vec2 uvL = vUv;
    for (int k = 0; k < 4; k++) {
      if (uClick[k].w > 0.001) {
        vec2 q = (vUv - uClick[k].xy) * uSize;
        float dq = length(q);
        float ring = (dq - uClick[k].z) / max(1.0, uClickW);
        uvL += (q / max(1.0, dq)) *
          (uClick[k].w * exp(-ring * ring)) / uSize;
      }
    }
    // Cover-fit crop window; samples clamp inside it so blur taps never
    // bleed past the crop.
    vec2 uv = uvL * uRepeat + uOffset;
    vec2 lo = uOffset;
    vec2 hi = uOffset + uRepeat;
    vec3 col;
    if (uBlur > 0.0008) {
      // Poisson disk with a per-pixel rotation — a cheap wide gaussian
      // stand-in that hides its tap count at nebula sizes.
      float a = fract(sin(dot(gl_FragCoord.xy, vec2(12.9898, 78.233))) * 43758.545) * 6.2832;
      mat2 rot = mat2(cos(a), -sin(a), sin(a), cos(a));
      vec3 acc = texture(uMap, clamp(uv, lo, hi)).rgb;
      for (int i = 0; i < 12; i++) {
        acc += texture(uMap, clamp(uv + rot * TAPS[i] * uBlur, lo, hi)).rgb;
      }
      col = acc / 13.0;
    } else {
      // Sharp path: chromatic dispersion growing toward the card edges.
      vec2 d = vUv - 0.5;
      vec2 shift = d * dot(d, d) * 4.0 * uAber;
      col = vec3(
        texture(uMap, clamp(uv + shift, lo, hi)).r,
        texture(uMap, clamp(uv, lo, hi)).g,
        texture(uMap, clamp(uv - shift, lo, hi)).b
      );
    }
    col = mix(uBg, col, uTexA);

    // Rounded-rect SDF in card px: antialiased corner cut, plus the
    // hairline frame drawn as a ~1px band riding the same edge (so it
    // follows the radius exactly).
    vec2 q = abs((vUv - 0.5) * uSize) - (0.5 * uSize - vec2(uRadius));
    float dEdge = length(max(q, vec2(0.0))) + min(max(q.x, q.y), 0.0) - uRadius;
    float frameBand = 1.0 - smoothstep(0.5, 1.5, abs(dEdge + 1.0));
    col = mix(col, uFrameCol, frameBand * uFrameA);
    float aa = 1.0 - smoothstep(-0.75, 0.75, dEdge);
    outColor = vec4(col, uAlpha * aa);
  }
`;
  function x({colors:e,onScreen:r,pointer:s,ripples:c}){
    let w=(0,i.C)(e=>e.size),y=(0,a.useRef)(null),T=(0,a.useRef)([]),E=(0,a.useRef)({time:0,idleP:0,spin:0,cullTimer:0,frameEma:1/60,perfScale:1,lastP:0,holdTarget:0,holdRest:0,fieldK:1,targetI:-1,useCounter:1e4,lastClicks:0,boostOn:!1,boostK:0,boostCard:-1}),W=(0,a.useMemo)(()=>n.SEEDANCE_SHOWCASE.map(e=>{
      let t=document.createElement("video");
      return t.src=e.src,t.muted=!0,t.loop=!0,t.playsInline=!0,t.crossOrigin="anonymous",t.disableRemotePlayback=!0,t.preload="metadata",t
      }),[]),P=(0,a.useMemo)(()=>{
      let e=new Float32Array(n.SEEDANCE_SHOWCASE.length);
      return e.fill(16/9),e
      },[]),F=(0,a.useMemo)(()=>W.map((e,t)=>{
      let a=new o.VideoTexture(e),r=()=>{
        P[t]=e.videoWidth/e.videoHeight||16/9
        };
      return e.readyState>=1?r():e.addEventListener("loadedmetadata",r,{once:!0}),a
      }),[W,P]);
    (0,a.useEffect)(()=>{
      W.forEach((e,t)=>{
        e.getAttribute("src")||(e.src=n.SEEDANCE_SHOWCASE[t].src,e.load())
        });
      let e=W.map((e,t)=>setTimeout(()=>{
        let a=()=>{
          if(!e.paused||0!==e.currentTime)
          return;
          let a=Math.max(.2,(e.duration||8)-.5);
          e.currentTime=.1+2.618*t%a
          };
        e.readyState>=1?a():e.addEventListener("loadedmetadata",a,{once:!0})
        },400+250*t));
      return()=>{
        e.forEach(clearTimeout),F.forEach(e=>e.dispose()),W.forEach(e=>{
          e.pause(),e.removeAttribute("src"),e.load()
          })
        }
      },[W,F]),(0,a.useEffect)(()=>{
      if(r)
      return;
      let e=setTimeout(()=>W.forEach(e=>e.pause()),2500);
      return()=>clearTimeout(e)
      },[r,W]);
    let[B,R]=(0,a.useState)(0);
    (0,a.useEffect)(()=>{
      let e,t=()=>JSON.stringify([h.read(),f.read()]),a=t(),r=d.useTunerStore.subscribe(()=>{
        let r=t();
        r!==a&&(a=r,clearTimeout(e),e=setTimeout(()=>R(e=>e+1),250))
        });
      return()=>{
        clearTimeout(e),r()
        }
      },[]);
    let D=(0,a.useMemo)(()=>{
      let e=h.read(),t=f.read(),a=w.width*w.height/1e6,r=t.mobMpx>0&&a<t.mobMpx,l=Math.max(1,Math.round(r?t.mobArms:e.arms)),i=r?Math.max(4,Math.round(t.mobCardN)):Math.max(6,Math.min(Math.round(e.cardN),Math.round(e.cardN*a/e.tunedMpx))),n=Math.hypot(w.width,w.height)/2,s=(r?t.mobRMax:e.rMaxFrac)*n,u=(r?t.mobTurns:e.turns)*Math.PI*2,c=s/u,d=Math.min(340,Math.max(70,w.height*(r?t.mobCardH:e.cardHFrac))),m=Math.max(1,Math.ceil(i/l)),p=(r?t.mobBirth:e.birthFrac)*u,g=(n+1.5*d)/c,b=l*(r?1:Math.max(1,Math.round(e.guideX))),v=[];
      for(
      let e=0
      ;e<b;e++){
        let t=e*Math.PI*2/b,a=[],r=[],l=[],i=[],n=[],s=[];
        for(
        let o=0
        ;o<=200;o++){
          let u=.3*p+o/200*(g-.3*p),d=c*u,h=u+t,f=d*Math.cos(h),m=d*Math.sin(h),b=c*Math.cos(h)-d*Math.sin(h),v=c*Math.sin(h)+d*Math.cos(h),x=Math.hypot(b,v)||1,w=-v/x,y=b/x;
          for(
          let t
           of[-1,1])
          a.push(f,m,-2),r.push(w,y),l.push(t),i.push(o/200),n.push(e);
          if(o<200){
            let e=2*o;
            s.push(e,e+1,e+2,e+1,e+3,e+2)
            }
          }
        let u=new o.BufferGeometry;
        u.setAttribute("position",new o.Float32BufferAttribute(a,3)),u.setAttribute("aN",new o.Float32BufferAttribute(r,2)),u.setAttribute("aSide",new o.Float32BufferAttribute(l,1)),u.setAttribute("aT",new o.Float32BufferAttribute(i,1)),u.setAttribute("aArm",new o.Float32BufferAttribute(n,1)),u.setIndex(s),v.push(u)
        }
      let x=[],y=Math.round(e.ticksPerArm);
      for(
      let e=0
      ;e<l;e++){
        let t=e*Math.PI*2/l;
        for(
        let e=0
        ;e<y;e++){
          let a=u*(.45+.55*(e+.5)/y),r=c*a,l=a+t,i=Math.cos(l),o=Math.sin(l);
          x.push((r-6)*i,(r-6)*o,-2,(r+6)*i,(r+6)*o,-2)
          }
        }
      let M=new o.BufferGeometry;
      M.setAttribute("position",new o.Float32BufferAttribute(x,3));
      let k=[],A=e.circFrac*s,C=Math.max(8,Math.round(Math.PI*A/14));
      for(
      let e=0
      ;e<C;e++){
        let t=e/C*Math.PI*2,a=t+Math.PI/C;
        k.push(A*Math.cos(t),A*Math.sin(t),-2,A*Math.cos(a),A*Math.sin(a),-2)
        }
      let S=new o.BufferGeometry;
      return S.setAttribute("position",new o.Float32BufferAttribute(k,3)),{arms:l,cardN:i,rMax:s,thetaMax:u,thetaBirth:p,thetaExit:g,b:c,cardHCap:d,armJitter:e.armJitter,slotsPerArm:m,mobile:r,mobDensityX:t.mobDensityX,armGeoms:v,tickGeom:M,circGeom:S}
      },[w.width,w.height,B]);
    (0,a.useEffect)(()=>()=>{
      D.armGeoms.forEach(e=>e.dispose()),D.tickGeom.dispose(),D.circGeom.dispose()
      },[D]);
    let L=(0,a.useMemo)(()=>Array.from({length:D.cardN},(e,t)=>({clip:t%n.SEEDANCE_SHOWCASE.length,arm:t%D.arms,slot:Math.floor(t/D.arms)})),[D]),z=(0,a.useMemo)(()=>{
      let e=L.map((e,t)=>t);
      return e.sort((e,t)=>.618034*e%1-.618034*t%1),e
      },[L]),I=(0,a.useMemo)(()=>{
      let e=new Int32Array(L.length);
      return z.forEach((t,a)=>{
        e[t]=a
        }),e
      },[L,z]),H=(0,a.useMemo)(()=>L.map(e=>new o.ShaderMaterial({glslVersion:o.GLSL3,vertexShader:b,fragmentShader:v,transparent:!0,depthTest:!1,depthWrite:!1,uniforms:{uMap:{value:F[e.clip]},uRepeat:{value:new o.Vector2(1,1)},uOffset:{value:new o.Vector2(0,0)},uBg:{value:new o.Vector3(.9,.9,.9)},uBlur:{value:0},uTexA:{value:0},uAlpha:{value:0},uAber:{value:0},uCurve:{value:0},uSize:{value:new o.Vector2(160,90)},uMouse:{value:new o.Vector2(0,0)},uWarp:{value:0},uClick:{value:[new o.Vector4,new o.Vector4,new o.Vector4,new o.Vector4]},uClickW:{value:20},uRadius:{value:0},uFrameCol:{value:new o.Vector3(.5,.5,.5)},uFrameA:{value:0}}})),[L,F]);
    (0,a.useEffect)(()=>()=>H.forEach(e=>e.dispose()),[H]);
    let O=(0,a.useMemo)(()=>new o.LineBasicMaterial({transparent:!0,depthTest:!1,depthWrite:!1}),[]),N=(0,a.useMemo)(()=>new o.ShaderMaterial({transparent:!0,depthTest:!1,depthWrite:!1,side:o.DoubleSide,uniforms:{uTime:{value:0},uColor:{value:new o.Color("#888888")},uAlpha:{value:0},uPulseColor:{value:new o.Color("#2d81ff")},uPulseAlpha:{value:0},uSpeed:{value:.22},uWidth:{value:.035},uCount:{value:2},uHue:{value:.35},uBaseW:{value:1.2},uPulseW:{value:3.5},uWaveR:{value:1e6},uWaveBand:{value:220}},vertexShader:`
          attribute vec2 aN;
          attribute float aSide;
          attribute float aT;
          attribute float aArm;
          uniform float uTime;
          uniform float uSpeed;
          uniform float uWidth;
          uniform float uCount;
          uniform float uBaseW;
          uniform float uPulseW;
          uniform float uWaveR;
          uniform float uWaveBand;
          varying float vG;
          varying float vSide;
          varying float vArm;
          void main() {
            // Band coordinate: comets travel outward (increasing aT),
            // arms dephased by the golden conjugate so they never flash
            // in lockstep. Asymmetric falloff: sharp head, longer tail
            // trailing behind the direction of travel.
            float d = fract(aT * uCount - uTime * uSpeed + aArm * 0.618);
            float s = d - 0.5;
            float sig = uWidth * (s < 0.0 ? 1.7 : 0.55);
            float g = exp(-0.5 * (s / sig) * (s / sig));
            // Fade pulses out over the blurred birth zone.
            g *= smoothstep(0.04, 0.14, aT);
            // Intro choreography: pulses are uncovered by the same radial
            // reveal wave that uncovers the cards (trailing band), so they
            // appear rolling outward with the field. Post-intro the wave
            // radius saturates past every arm; a tuner replay rewinds it.
            g *= clamp((uWaveR - length(position.xy)) / uWaveBand, 0.0, 1.0);
            vG = g;
            vSide = aSide;
            vArm = aArm;
            // Ribbon width: resting hairline plus the pulse swell.
            float w = uBaseW + uPulseW * g;
            vec3 p = position;
            p.xy += aN * aSide * w * 0.5;
            gl_Position = projectionMatrix * modelViewMatrix * vec4(p, 1.0);
          }
        `,fragmentShader:`
          precision highp float;
          uniform vec3 uColor;
          uniform float uAlpha;
          uniform vec3 uPulseColor;
          uniform float uPulseAlpha;
          uniform float uHue;
          varying float vG;
          varying float vSide;
          varying float vArm;

          // Hue rotation in YIQ — cheap and good enough for glow accents.
          vec3 hueRotate(vec3 color, float a) {
            const mat3 toYIQ = mat3(
              0.299, 0.587, 0.114,
              0.596, -0.274, -0.322,
              0.211, -0.523, 0.312);
            const mat3 toRGB = mat3(
              1.0, 0.956, 0.621,
              1.0, -0.272, -0.647,
              1.0, -1.106, 1.703);
            vec3 yiq = color * toYIQ;
            float h = atan(yiq.z, yiq.y) + a;
            float c = length(yiq.yz);
            return clamp(vec3(yiq.x, c * cos(h), c * sin(h)) * toRGB, 0.0, 1.0);
          }

          void main() {
            // Soft ribbon edges — the cross-fade doubles as antialiasing.
            float edge = 1.0 - smoothstep(0.45, 1.0, abs(vSide));
            float g = clamp(vG, 0.0, 1.0);
            vec3 pulseCol = hueRotate(uPulseColor, vArm * uHue * 6.28318);
            vec3 col = mix(uColor, pulseCol, g);
            gl_FragColor = vec4(col, (uAlpha + uPulseAlpha * vG) * edge);
          }
        `}),[]),j=(0,a.useMemo)(()=>new o.LineBasicMaterial({transparent:!0,depthTest:!1,depthWrite:!1}),[]);
    (0,a.useEffect)(()=>()=>{
      O.dispose(),j.dispose(),N.dispose()
      },[O,j,N]);
    let q=(0,a.useRef)({init:!1,bg:new o.Vector3(.9,.9,.9),frame:new o.Vector3(.5,.5,.5),line:new o.Color("#888888"),accent:new o.Color("#2d81ff"),ink:new o.Color("#101014"),light:0,pulse:new o.Color("#2d81ff"),tBg:new o.Vector3(.9,.9,.9),tFrame:new o.Vector3(.5,.5,.5),tLine:new o.Color("#888888"),tAccent:new o.Color("#2d81ff"),tInk:new o.Color("#101014"),tLight:0});
    (0,a.useEffect)(()=>{
      let t=q.current;
      t.tBg.copy(S(e.bg)),t.tFrame.copy(S(e.lineStrong)),t.tLine.set(e.lineStrong),t.tAccent.set(e.accent),t.tInk.set(e.ink),t.tLight=+(.2126*t.tBg.x+.7152*t.tBg.y+.0722*t.tBg.z>.5),t.init||(t.init=!0,t.bg.copy(t.tBg),t.frame.copy(t.tFrame),t.line.copy(t.tLine),t.accent.copy(t.tAccent),t.ink.copy(t.tInk),t.light=t.tLight)
      },[e]);
    let G=(0,a.useMemo)(()=>new o.PlaneGeometry(1,1,12,12),[]);
    (0,a.useEffect)(()=>()=>G.dispose(),[G]);
    let V=(0,a.useMemo)(()=>[...D.armGeoms.map(e=>new o.Mesh(e,N)),new o.LineSegments(D.circGeom,O),new o.LineSegments(D.tickGeom,j)],[D,O,j,N]),K=(0,a.useMemo)(()=>new Float32Array(2*L.length),[L]),_=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),U=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),$=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),X=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),J=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),Y=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),Q=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),Z=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),ee=(0,a.useMemo)(()=>{
      let e=new Float32Array(L.length);
      return e.fill(NaN),e
      },[L]),et=(0,a.useRef)([]),ea=(0,a.useMemo)(()=>{
      let e=new Float32Array(n.SEEDANCE_SHOWCASE.length);
      for(
      let t=0
      ;t<e.length;t++)
      e[t]=t;
      return e
      },[]),er=(0,a.useMemo)(()=>new Float32Array(L.length),[L]),el=(0,a.useMemo)(()=>new Float32Array(n.SEEDANCE_SHOWCASE.length),[]),ei=(0,a.useMemo)(()=>new Float32Array(n.SEEDANCE_SHOWCASE.length),[]),eo=(0,a.useMemo)(()=>n.SEEDANCE_SHOWCASE.map((e,t)=>t),[]);
    return(0,l.useFrame)((e,t)=>{
      let a=Math.min(t,.05),r=E.current;
      r.time+=a;
      let l=m.read(),i=g.read(),n=p.read(),d=u.introTuner.read(),f=r.time,b=M((u.introClock.t-d.cardsAt)/Math.max(.1,l.introDur)),v=A(b),x=M((u.introClock.t-d.cardsAt-l.waveLag)/Math.max(.1,l.introDur)),w=A(x),S=M((u.introClock.t-d.cardsAt)/Math.max(.1,l.burstDur)),B=1+(l.burstX-1)*(1-A(S));
      r.idleP+=a*l.idleSpeed*B/60,r.spin+=a*o.MathUtils.degToRad(l.spinDeg)/60*(1-r.holdRest);
      let R=r.idleP+window.scrollY*l.scrub/1e3;
      y.current&&(y.current.rotation.z=r.spin);
      let G=R-r.lastP;
      r.lastP=R;
      let V=r.targetI>=0;
      r.holdTarget+=(!!V-r.holdTarget)*(1-Math.exp(-a/Math.max(.01,n.holdTau))),r.holdRest+=(!!V-r.holdRest)*(1-Math.exp(-a/Math.max(.01,n.restTau))),r.fieldK+=(!V-r.fieldK)*(1-Math.exp(-a/.12)),el.fill(-1);
      let en=q.current,es=1-Math.exp(-a/.13);
      if(en.bg.lerp(en.tBg,es),en.frame.lerp(en.tFrame,es),en.line.lerp(en.tLine,es),en.accent.lerp(en.tAccent,es),en.ink.lerp(en.tInk,es),en.light+=(en.tLight-en.light)*es,O.color.copy(en.line),j.color.copy(en.line),N.uniforms.uColor.value.copy(en.line),en.pulse.setRGB(en.bg.x+(en.ink.r-en.bg.x)*i.pulseDark,en.bg.y+(en.ink.g-en.bg.y)*i.pulseDark,en.bg.z+(en.ink.b-en.bg.z)*i.pulseDark),N.uniforms.uPulseColor.value.copy(en.accent).lerp(en.pulse,en.light),N.uniforms.uHue.value=i.pulseHue*(1-en.light),r.frameEma+=(Math.min(t,.25)-r.frameEma)*.05,l.perfFloor>0&&f>4){
        let e=1/l.perfFloor;
        r.frameEma>e?r.perfScale=Math.max(.35,r.perfScale-.3*a):r.frameEma<.7*e&&(r.perfScale=Math.min(1,r.perfScale+.05*a))
        }else 
      0===l.perfFloor&&(r.perfScale=1);
      let eu=Math.max(6,Math.round(L.length*r.perfScale)),ec=Math.cos(r.spin),ed=Math.sin(r.spin),eh=s.current,ef=-l.rollChunk*(1-v);
      for(
      let e=0
      ;e<eu;e++){
        let t=z[e],a=L[t];
        Y[t]-=G*(t===r.targetI?Math.max(r.holdTarget,r.holdRest):r.holdRest);
        let i=Math.max(0,k((a.slot+.5+a.arm*D.armJitter)/D.slotsPerArm+R+Y[t])+ef);
        if(_[t]=i,b>=1&&!Number.isNaN(ee[t])&&Math.abs(i-ee[t])>.5){
          let e=0;
          for(
          let t=1
          ;t<ea.length;t++)
          ea[t]<ea[e]&&(e=t);
          a.clip=e,ea[e]=++r.useCounter,H[t].uniforms.uMap.value=F[e]
          }
        ee[t]=i;
        let o=D.thetaBirth+i*(D.thetaExit-D.thetaBirth),s=D.b*o,u=o+a.arm*Math.PI*2/D.arms,c=Math.cos(u),d=Math.sin(u),h=l.wobbleAmp*(1+(n.holdWobble-1)*r.holdRest)*(1-X[t]),m=Math.sin(f*l.wobbleFreq*Math.PI*2+2.399*t),p=Math.cos(f*l.wobbleFreq*Math.PI*1.4+1.713*t);
        if(K[2*t]=s*c+h*(-(m*d)+.6*p*c),K[2*t+1]=s*d+h*(m*c+.6*p*d),eh.active&&n.tugPx>0&&r.fieldK>.001){
          let e=ec*K[2*t]-ed*K[2*t+1],a=ed*K[2*t]+ec*K[2*t+1],l=eh.x-e,i=eh.y-a,o=l*l+i*i,s=n.tugPx*Math.exp(-o/(n.fieldPx*n.fieldPx))*r.fieldK*(1-X[t])/Math.max(1,Math.sqrt(o));
          K[2*t]+=(ec*l+ed*i)*s,K[2*t+1]+=(-ed*l+ec*i)*s
          }
        }
      let em=-1,ep=-1,eg=1+(n.boostScale-1)*r.boostK;
      if(eh.active){
        let e=r.targetI,t=n.tugPx+8,a=!1,l=!1;
        if(e>=0&&I[e]<eu&&U[e]>=8){
          let i=ec*K[2*e]-ed*K[2*e+1],o=ed*K[2*e]+ec*K[2*e+1],n=Math.abs(eh.x-i),s=Math.abs(eh.y-o),u=U[e];
          a=n<=8*u/9+t&&s<=u/2+t;
          let c=u*(e===r.boostCard?eg:1);
          l=n<=8*c/9+t&&s<=c/2+t
          }
        if(a)
        em=e;
        else{
          for(
          let t=0
          ;t<eu;t++){
            let a=z[t];
            if(a===e)
            continue;
            let r=_[a];
            if(r<.04||r<=ep)
            continue;
            let l=U[a];
            if(l<8)
            continue;
            let i=ec*K[2*a]-ed*K[2*a+1],o=ed*K[2*a]+ec*K[2*a+1];
            Math.abs(eh.x-i)<=8*l/9&&Math.abs(eh.y-o)<=l/2&&(ep=r,em=a)
            }
          em<0&&l&&(em=e)
          }
        }
      if(r.targetI=em,eh.clicks!==r.lastClicks&&(r.lastClicks=eh.clicks,r.targetI>=0)){
        let e=r.targetI,t=ec*K[2*e]-ed*K[2*e+1],a=ed*K[2*e]+ec*K[2*e+1],l=Math.max(1,U[e]*(e===r.boostCard?eg:1)),o=1+(16/9-1)*C(0,i.aspectEnd,_[e]);
        et.current.push({card:e,u:.5+(eh.x-t)/(l*o),v:.5+(eh.y-a)/l,start:f}),et.current.length>8&&et.current.shift(),r.boostCard===r.targetI?r.boostOn=!r.boostOn:(r.boostCard=r.targetI,r.boostOn=!0)
        }
      r.boostOn&&r.targetI!==r.boostCard&&(r.boostOn=!1),r.boostK+=(!!r.boostOn-r.boostK)*(1-Math.exp(-a/Math.max(.01,n.boostTau))),!r.boostOn&&r.boostK<.001&&(r.boostCard=-1);
      let eb=c.current;
      for(
      let e=eb.length-1
      ;e>=0;e--)
      eb[e].start<0&&(eb[e].start=f),f-eb[e].start>n.rippleLife&&eb.splice(e,1);
      let ev=et.current;
      for(
      let e=ev.length-1
      ;e>=0;e--)
      f-ev[e].start>n.clickDur&&ev.splice(e,1);
      let ex=n.tiltDeg*Math.PI/180;
      for(
      let e=0
      ;e<L.length;e++){
        let t=T.current[e];
        if(!t)
        continue;
        if(I[e]>=eu){
          t.visible=!1;
          continue
          }
        t.visible||(U[e]=0,t.visible=!0);
        let o=L[e],s=_[e],u=K[2*e],c=K[2*e+1],d=X[e]+=((e===r.targetI)-X[e])*(1-Math.exp(-a/Math.max(.01,n.targetTau))),h=J[e]+=((e===r.targetI)-J[e])*(1-Math.exp(-a/.12)),m=1/0,p=1/0;
        for(
        let t=0
        ;t<eu;t++){
          let a=z[t];
          if(a===e)
          continue;
          let l=Math.max(9*Math.abs(K[2*a]-u)/16,Math.abs(K[2*a+1]-c));
          if(a===r.targetI&&X[a]>.3){
            let e=.98*Math.max(0,2*l-U[a]);
            e<p&&(p=e)
            }else 
          l<m&&(m=l)
          }
        let g=Math.min(D.cardHCap*(i.innerCap+(1-i.innerCap)*s),i.density*(D.mobile?D.mobDensityX:1)*m,p);
        d>.3?U[e]+=(g-U[e])*(1-Math.exp(-6*a)):U[e]=g<U[e]?g:U[e]+(g-U[e])*(1-Math.exp(-3*a));
        let y=Math.max(.001,U[e])*(e===r.boostCard?eg:1),k=1+(16/9-1)*C(0,i.aspectEnd,s),A=y*k,S=ec*u-ed*c,E=ed*u+ec*c,F=0,B=0,R=0;
        if(eh.active&&r.fieldK>.001){
          let e=eh.x-S,t=eh.y-E,a=e*e+t*t;
          F=Math.exp(-a/(n.fieldPx*n.fieldPx))*r.fieldK;
          let l=1/Math.max(1,Math.sqrt(a));
          R=ex*e*l*F,B=ex*t*l*F
          }
        let O=1-Math.exp(-10*a);
        Q[e]+=(B*(1-h)-Q[e])*O,Z[e]+=(R*(1-h)-Z[e])*O,$[e]=Math.max($[e]*Math.exp(-n.flareDecay*a),n.flareAdd*F);
        let N=0;
        for(
        let e=0
        ;e<eb.length;e++){
          let t=f-eb[e].start,a=(Math.hypot(S-eb[e].x,E-eb[e].y)-t*n.rippleSpeed)/n.rippleWidth;
          N+=n.rippleAmp*Math.exp(-a*a)*(1-t/n.rippleLife)
          }
        t.position.set(u,c,0),t.rotation.set(Q[e],Z[e],-r.spin),t.scale.set(A,y,1),t.renderOrder=10+Math.round(100*s)+Math.round(500*d);
        let j=M(s/i.fadeBand),q=1,G=0;
        if(b<1||x>0&&x<1){
          let e=D.b*(D.thetaBirth+s*(D.thetaExit-D.thetaBirth)),t=Math.max(1,l.waveBand);
          if(b<1&&(q=M((v*D.b*D.thetaExit-e)/t)),x>0&&x<1){
            let a=(e-w*D.b*D.thetaExit)/t;
            G=Math.exp(-a*a)
            }
          }
        let V=+(W[o.clip].readyState>=2);
        er[e]+=(V-er[e])*(1-Math.exp(-3*a));
        let Y=er[e],ee=H[e].uniforms;
        ee.uBg.value.copy(en.bg),ee.uFrameCol.value.copy(en.frame);
        let et=P[o.clip],ea=ee.uRepeat.value,ei=ee.uOffset.value;
        et>k?(ea.set(k/et,1),ei.set((1-k/et)/2,0)):(ea.set(1,et/k),ei.set(0,(1-et/k)/2)),ee.uBlur.value=Math.max(i.blurMax*(1-C(0,i.blurEnd,s))*(1-h),(1-Y)*i.blurMax,(1-q)*i.blurMax),ee.uTexA.value=Y,ee.uAber.value=(i.aberration+$[e]+N+l.waveAber*G)*(1-h);
        let eo=Math.min(2,N/Math.max(.002,n.rippleAmp));
        ee.uCurve.value=(i.curvePx+n.rippleWarp*eo)*(1-h),ee.uMouse.value.set((eh.x-S)/Math.max(1,A),(eh.y-E)/Math.max(1,y)),ee.uWarp.value=n.mouseWarp*F*(1-h),ee.uSize.value.set(A,y);
        let es=ee.uClick.value,ef=0;
        for(
        let t=0
        ;t<ev.length&&ef<4;t++){
          let a=ev[t];
          if(a.card!==e)
          continue;
          let r=(f-a.start)/Math.max(.05,n.clickDur);
          r>=1||es[ef++].set(a.u,a.v,.85*r*Math.max(A,y),n.clickAmp*(1-r))
          }
        for(;ef<4;ef++)
        es[ef].w=0;
        ee.uClickW.value=n.clickWidth*Math.max(A,y),ee.uRadius.value=Math.min(i.cornerPx,.49*y),ee.uFrameA.value=i.frameAlpha,ee.uAlpha.value=j*q;
        let em=d>.05?2:s;
        (ee.uAlpha.value>.04||d>.05)&&em>el[o.clip]&&(el[o.clip]=em)
        }
      let ew=C(0,1,M((u.introClock.t-d.instrAt)/1.2));
      if(O.opacity=i.lineAlpha*ew,j.opacity=i.tickAlpha*ew,N.uniforms.uTime.value=r.time,N.uniforms.uAlpha.value=i.lineAlpha*ew,N.uniforms.uPulseAlpha.value=i.pulseAlpha*ew,N.uniforms.uSpeed.value=i.pulseSpeed,N.uniforms.uWidth.value=i.pulseWidth,N.uniforms.uCount.value=Math.round(i.pulseCount),N.uniforms.uBaseW.value=i.lineW,N.uniforms.uPulseW.value=i.pulseW,N.uniforms.uWaveR.value=v*D.b*D.thetaExit,N.uniforms.uWaveBand.value=Math.max(1,l.waveBand),r.cullTimer-=a,r.cullTimer<=0){
        r.cullTimer=.25,function(e,t,a,r,l){
          r.sort((e,a)=>t[a]-t[e]);
          let i=0;
          for(
          let o=0
          ;o<r.length;o++){
            let n=r[o],s=e[n];
            if(o<8&&t[n]>=l){
              a[n]=0,s.paused&&i<3&&(i++,s.play().catch(()=>{
                }));
              continue
              }
            a[n]+=.25,a[n]>=1.2&&!s.paused&&s.pause()
            }
          }(W,el,ei,eo,i.playFrac);
        let e=h.read().dedupPx;
        if(e>0&&b>=1){
          let t=e*e;
          for(
          let e=0
          ;e<eu;e++){
            let a=z[e];
            if(!(H[a].uniforms.uAlpha.value<.3))
            for(
            let l=e+1
            ;l<eu;l++){
              let e=z[l];
              if(L[a].clip!==L[e].clip||H[e].uniforms.uAlpha.value<.3)
              continue;
              let i=K[2*a]-K[2*e],o=K[2*a+1]-K[2*e+1];
              if(i*i+o*o>t)
              continue;
              let n=_[a]<_[e]?a:e,s=K[2*n],u=K[2*n+1],c=-1,d=-1/0;
              for(
              let e=0
              ;e<ea.length;e++){
                if(e===L[n].clip)
                continue;
                let a=1/0;
                for(
                let t=0
                ;t<eu;t++){
                  let r=z[t];
                  if(r===n||L[r].clip!==e||H[r].uniforms.uAlpha.value<.15)
                  continue;
                  let l=K[2*r]-s,i=K[2*r+1]-u,o=l*l+i*i;
                  o<a&&(a=o)
                  }
                let r=Math.min(a,4*t)-1e-4*ea[e];
                r>d&&(d=r,c=e)
                }
              c>=0&&(L[n].clip=c,ea[c]=++r.useCounter,H[n].uniforms.uMap.value=F[c])
              }
            }
          }
        }
      }),(0,t.jsxs)("group",{ref:y,children:[V.map((e,a)=>(0,t.jsx)("primitive",{object:e},a)),L.map((e,a)=>(0,t.jsx)("mesh",{ref:e=>{
      T.current[a]=e
      },geometry:G,material:H[a],scale:[1,1,1]},a))]})
    }
  function w(){
    let e=(0,i.C)(e=>e.camera),t=(0,i.C)(e=>e.size);
    return(0,a.useEffect)(()=>{
      let a=t.height/2/Math.tan(o.MathUtils.degToRad(15));
      e.fov=30,e.position.set(0,0,a),e.near=Math.max(1,a-1200),e.far=a+1200,e.updateProjectionMatrix()
      },[e,t.height]),null
    }
  class y extends a.Component{
    state={failed:!1};static getDerivedStateFromError(){
      return{failed:!0}
      }render(){
      return this.state.failed?null:this.props.children
      }
  }
  let M=e=>Math.max(0,Math.min(1,e)),k=e=>(e%1+1)%1,A=e=>1-Math.pow(1-e,3);
  function C(e,t,a){
    let r=M((a-e)/(t-e));
    return r*r*(3-2*r)
    }
  function S(e){
    let t=parseInt(e.replace("#",""),16);
    return new o.Vector3((t>>16&255)/255,(t>>8&255)/255,(255&t)/255)
    }
  e.s(["default",0,function(){
    let[e,l]=(0,a.useState)(!1),[i,o]=(0,a.useState)(null),[n,u]=(0,a.useState)(!0),d=(0,a.useRef)(null),h=(0,a.useRef)({x:0,y:0,active:!1,clicks:0}),f=(0,a.useRef)([]);
    (0,a.useEffect)(()=>{
      let e=d.current;
      if(!e)
      return;
      let t=t=>{
        let a=e.getBoundingClientRect();
        h.current.x=t.clientX-a.left-a.width/2,h.current.y=-(t.clientY-a.top-a.height/2)
        },a=e=>{
        t(e),h.current.active=!0
        },r=()=>{
        h.current.active=!1
        },l=e=>{
        t(e),h.current.clicks++;
        let a=f.current;
        a.push({x:h.current.x,y:h.current.y,start:-1}),a.length>8&&a.shift()
        };
      return e.addEventListener("pointermove",a),e.addEventListener("pointerleave",r),e.addEventListener("pointercancel",r),e.addEventListener("pointerdown",l),()=>{
        e.removeEventListener("pointermove",a),e.removeEventListener("pointerleave",r),e.removeEventListener("pointercancel",r),e.removeEventListener("pointerdown",l)
        }
      },[]),(0,a.useEffect)(()=>{
      if(!(0,s.webglAvailable)()||window.matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
      let e=0,t=()=>{
        document.hidden?e=requestAnimationFrame(t):l(!0)
        };
      return e=requestAnimationFrame(t),()=>cancelAnimationFrame(e)
      },[]),(0,a.useEffect)(()=>{
      if(e)
      return(0,c.watchThemeColors)(o)
      },[e]),(0,a.useEffect)(()=>{
      let e=d.current;
      if(!e)
      return;
      let t=!0,a=()=>u(t&&!document.hidden),r=new IntersectionObserver(([e])=>{
        t=e.isIntersecting,a()
        },{rootMargin:"600px 0px"});
      return r.observe(e),document.addEventListener("visibilitychange",a),()=>{
        r.disconnect(),document.removeEventListener("visibilitychange",a)
        }
      },[]);
    let m=e&&null!==i;
    return(0,t.jsx)("div",{ref:d,"aria-hidden":!0,className:"absolute inset-0",children:m&&(0,t.jsx)(y,{children:(0,t.jsxs)(r.Canvas,{tabIndex:-1,dpr:[1,1.5],frameloop:n?"always":"never",gl:{antialias:!0,alpha:!0,powerPreference:"high-performance"},style:{position:"absolute",inset:0,pointerEvents:"none"},children:[(0,t.jsx)(w,{}),(0,t.jsx)(x,{colors:i,onScreen:n,pointer:h,ripples:f})]})})})
    }],17031)
  }]);
