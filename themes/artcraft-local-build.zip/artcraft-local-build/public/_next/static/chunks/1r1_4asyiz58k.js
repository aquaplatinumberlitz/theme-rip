(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,90072,t=>{
  "use strict";
  let e,i,s,r,n,a,o,h,l,u="attached",c="detached",p="srgb",d="srgb-linear",m="linear",y="srgb",f={Int8Array:Int8Array,Uint8Array:Uint8Array,Uint8ClampedArray:Uint8ClampedArray,Int16Array:Int16Array,Uint16Array:Uint16Array,Int32Array:Int32Array,Uint32Array:Uint32Array,Float32Array:Float32Array,Float64Array:Float64Array};
  function g(t,e){
    return new f[t](e)
    }
  function x(t){
    return ArrayBuffer.isView(t)&&!(t instanceof DataView)
    }
  function b(t){
    return document.createElementNS("http://www.w3.org/1999/xhtml",t)
    }
  let v={},M=null;
  function w(...t){
    let e="THREE."+t.shift();
    M?M("log",e,...t):console.log(e,...t)
    }
  function S(t){
    let e=t[0];
    if("string"==typeof e&&e.startsWith("TSL:")){
      let e=t[1];
      e&&e.isStackTrace?t[0]+=" "+e.getLocation():t[1]='Stack trace not available. Enable "THREE.Node.captureStackTrace" to capture stack traces.'
      }
    return t
    }
  function _(...t){
    let e="THREE."+(t=S(t)).shift();
    if(M)
    M("warn",e,...t);
    else{
      let i=t[0];
      i&&i.isStackTrace?console.warn(i.getError(e)):console.warn(e,...t)
      }
    }
  function A(...t){
    let e="THREE."+(t=S(t)).shift();
    if(M)
    M("error",e,...t);
    else{
      let i=t[0];
      i&&i.isStackTrace?console.error(i.getError(e)):console.error(e,...t)
      }
    }
  function T(...t){
    let e=t.join(" ");
    e in v||(v[e]=!0,_(...t))
    }
  class C{
    addEventListener(t,e){
      void 0===this._listeners&&(this._listeners={});
      let i=this._listeners;
      void 0===i[t]&&(i[t]=[]),-1===i[t].indexOf(e)&&i[t].push(e)
      }hasEventListener(t,e){
      let i=this._listeners;
      return void 0!==i&&void 0!==i[t]&&-1!==i[t].indexOf(e)
      }removeEventListener(t,e){
      let i=this._listeners;
      if(void 0===i)
      return;
      let s=i[t];
      if(void 0!==s){
        let t=s.indexOf(e);
        -1!==t&&s.splice(t,1)
        }
      }dispatchEvent(t){
      let e=this._listeners;
      if(void 0===e)
      return;
      let i=e[t.type];
      if(void 0!==i){
        t.target=this;
        let e=i.slice(0);
        for(
        let i=0,s=e.length
        ;i<s;i++)
        e[i].call(this,t);
        t.target=null
        }
      }
  }
  let I=["00","01","02","03","04","05","06","07","08","09","0a","0b","0c","0d","0e","0f","10","11","12","13","14","15","16","17","18","19","1a","1b","1c","1d","1e","1f","20","21","22","23","24","25","26","27","28","29","2a","2b","2c","2d","2e","2f","30","31","32","33","34","35","36","37","38","39","3a","3b","3c","3d","3e","3f","40","41","42","43","44","45","46","47","48","49","4a","4b","4c","4d","4e","4f","50","51","52","53","54","55","56","57","58","59","5a","5b","5c","5d","5e","5f","60","61","62","63","64","65","66","67","68","69","6a","6b","6c","6d","6e","6f","70","71","72","73","74","75","76","77","78","79","7a","7b","7c","7d","7e","7f","80","81","82","83","84","85","86","87","88","89","8a","8b","8c","8d","8e","8f","90","91","92","93","94","95","96","97","98","99","9a","9b","9c","9d","9e","9f","a0","a1","a2","a3","a4","a5","a6","a7","a8","a9","aa","ab","ac","ad","ae","af","b0","b1","b2","b3","b4","b5","b6","b7","b8","b9","ba","bb","bc","bd","be","bf","c0","c1","c2","c3","c4","c5","c6","c7","c8","c9","ca","cb","cc","cd","ce","cf","d0","d1","d2","d3","d4","d5","d6","d7","d8","d9","da","db","dc","dd","de","df","e0","e1","e2","e3","e4","e5","e6","e7","e8","e9","ea","eb","ec","ed","ee","ef","f0","f1","f2","f3","f4","f5","f6","f7","f8","f9","fa","fb","fc","fd","fe","ff"],z=1234567,B=Math.PI/180,k=180/Math.PI;
  function O(){
    let t=0xffffffff*Math.random()|0,e=0xffffffff*Math.random()|0,i=0xffffffff*Math.random()|0,s=0xffffffff*Math.random()|0;
    return(I[255&t]+I[t>>8&255]+I[t>>16&255]+I[t>>24&255]+"-"+I[255&e]+I[e>>8&255]+"-"+I[e>>16&15|64]+I[e>>24&255]+"-"+I[63&i|128]+I[i>>8&255]+"-"+I[i>>16&255]+I[i>>24&255]+I[255&s]+I[s>>8&255]+I[s>>16&255]+I[s>>24&255]).toLowerCase()
    }
  function R(t,e,i){
    return Math.max(e,Math.min(i,t))
    }
  function P(t,e){
    return(t%e+e)%e
    }
  function F(t,e,i){
    return(1-i)*t+i*e
    }
  function L(t,e){
    switch(e.constructor){case Float32Array:
    return t;
    case Uint32Array:
    return t/0xffffffff;
    case Uint16Array:
    return t/65535;
    case Uint8Array:
    return t/255;
    case Int32Array:
    return Math.max(t/0x7fffffff,-1);
    case Int16Array:
    return Math.max(t/32767,-1);
    case Int8Array:
    return Math.max(t/127,-1);
    default:
    throw Error("Invalid component type.")
    }
    }
  function N(t,e){
    switch(e.constructor){case Float32Array:
    return t;
    case Uint32Array:
    return Math.round(0xffffffff*t);
    case Uint16Array:
    return Math.round(65535*t);
    case Uint8Array:
    return Math.round(255*t);
    case Int32Array:
    return Math.round(0x7fffffff*t);
    case Int16Array:
    return Math.round(32767*t);
    case Int8Array:
    return Math.round(127*t);
    default:
    throw Error("Invalid component type.")
    }
    }
  class E{
    static{
    E.prototype.isVector2=!0
    }constructor(t=0,e=0){
      this.x=t,this.y=e
      }get width(){
      return this.x
      }set width(t){
      this.x=t
      }get height(){
      return this.y
      }set height(t){
      this.y=t
      }set(t,e){
      return this.x=t,this.y=e,this
      }setScalar(t){
      return this.x=t,this.y=t,this
      }setX(t){
      return this.x=t,this
      }setY(t){
      return this.y=t,this
      }setComponent(t,e){
      switch(t){case 0:
      this.x=e;
      break;
      case 1:
      this.y=e;
      break;
      default:
      throw Error("index is out of range: "+t)
      }
      return this
      }getComponent(t){
      switch(t){case 0:
      return this.x;
      case 1:
      return this.y;
      default:
      throw Error("index is out of range: "+t)
      }
      }clone(){
      return new this.constructor(this.x,this.y)
      }copy(t){
      return this.x=t.x,this.y=t.y,this
      }add(t){
      return this.x+=t.x,this.y+=t.y,this
      }addScalar(t){
      return this.x+=t,this.y+=t,this
      }addVectors(t,e){
      return this.x=t.x+e.x,this.y=t.y+e.y,this
      }addScaledVector(t,e){
      return this.x+=t.x*e,this.y+=t.y*e,this
      }sub(t){
      return this.x-=t.x,this.y-=t.y,this
      }subScalar(t){
      return this.x-=t,this.y-=t,this
      }subVectors(t,e){
      return this.x=t.x-e.x,this.y=t.y-e.y,this
      }multiply(t){
      return this.x*=t.x,this.y*=t.y,this
      }multiplyScalar(t){
      return this.x*=t,this.y*=t,this
      }divide(t){
      return this.x/=t.x,this.y/=t.y,this
      }divideScalar(t){
      return this.multiplyScalar(1/t)
      }applyMatrix3(t){
      let e=this.x,i=this.y,s=t.elements;
      return this.x=s[0]*e+s[3]*i+s[6],this.y=s[1]*e+s[4]*i+s[7],this
      }min(t){
      return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this
      }max(t){
      return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this
      }clamp(t,e){
      return this.x=R(this.x,t.x,e.x),this.y=R(this.y,t.y,e.y),this
      }clampScalar(t,e){
      return this.x=R(this.x,t,e),this.y=R(this.y,t,e),this
      }clampLength(t,e){
      let i=this.length();
      return this.divideScalar(i||1).multiplyScalar(R(i,t,e))
      }floor(){
      return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this
      }ceil(){
      return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this
      }round(){
      return this.x=Math.round(this.x),this.y=Math.round(this.y),this
      }roundToZero(){
      return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this
      }negate(){
      return this.x=-this.x,this.y=-this.y,this
      }dot(t){
      return this.x*t.x+this.y*t.y
      }cross(t){
      return this.x*t.y-this.y*t.x
      }lengthSq(){
      return this.x*this.x+this.y*this.y
      }length(){
      return Math.sqrt(this.x*this.x+this.y*this.y)
      }manhattanLength(){
      return Math.abs(this.x)+Math.abs(this.y)
      }normalize(){
      return this.divideScalar(this.length()||1)
      }angle(){
      return Math.atan2(-this.y,-this.x)+Math.PI
      }angleTo(t){
      let e=Math.sqrt(this.lengthSq()*t.lengthSq());
      return 0===e?Math.PI/2:Math.acos(R(this.dot(t)/e,-1,1))
      }distanceTo(t){
      return Math.sqrt(this.distanceToSquared(t))
      }distanceToSquared(t){
      let e=this.x-t.x,i=this.y-t.y;
      return e*e+i*i
      }manhattanDistanceTo(t){
      return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)
      }setLength(t){
      return this.normalize().multiplyScalar(t)
      }lerp(t,e){
      return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this
      }lerpVectors(t,e,i){
      return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this
      }equals(t){
      return t.x===this.x&&t.y===this.y
      }fromArray(t,e=0){
      return this.x=t[e],this.y=t[e+1],this
      }toArray(t=[],e=0){
      return t[e]=this.x,t[e+1]=this.y,t
      }fromBufferAttribute(t,e){
      return this.x=t.getX(e),this.y=t.getY(e),this
      }rotateAround(t,e){
      let i=Math.cos(e),s=Math.sin(e),r=this.x-t.x,n=this.y-t.y;
      return this.x=r*i-n*s+t.x,this.y=r*s+n*i+t.y,this
      }random(){
      return this.x=Math.random(),this.y=Math.random(),this
      }*[Symbol.iterator](){
      yield this.x,yield this.y
      }
  }
  class V{
    constructor(t=0,e=0,i=0,s=1){
      this.isQuaternion=!0,this._x=t,this._y=e,this._z=i,this._w=s
      }static slerpFlat(t,e,i,s,r,n,a){
      let o=i[s+0],h=i[s+1],l=i[s+2],u=i[s+3],c=r[n+0],p=r[n+1],d=r[n+2],m=r[n+3];
      if(u!==m||o!==c||h!==p||l!==d){
        let t=o*c+h*p+l*d+u*m;
        t<0&&(c=-c,p=-p,d=-d,m=-m,t=-t);
        let e=1-a;
        if(t<.9995){
          let i=Math.acos(t),s=Math.sin(i);
          o=o*(e=Math.sin(e*i)/s)+c*(a=Math.sin(a*i)/s),h=h*e+p*a,l=l*e+d*a,u=u*e+m*a
          }else{
          let t=1/Math.sqrt((o=o*e+c*a)*o+(h=h*e+p*a)*h+(l=l*e+d*a)*l+(u=u*e+m*a)*u);
          o*=t,h*=t,l*=t,u*=t
          }
        }
      t[e]=o,t[e+1]=h,t[e+2]=l,t[e+3]=u
      }static multiplyQuaternionsFlat(t,e,i,s,r,n){
      let a=i[s],o=i[s+1],h=i[s+2],l=i[s+3],u=r[n],c=r[n+1],p=r[n+2],d=r[n+3];
      return t[e]=a*d+l*u+o*p-h*c,t[e+1]=o*d+l*c+h*u-a*p,t[e+2]=h*d+l*p+a*c-o*u,t[e+3]=l*d-a*u-o*c-h*p,t
      }get x(){
      return this._x
      }set x(t){
      this._x=t,this._onChangeCallback()
      }get y(){
      return this._y
      }set y(t){
      this._y=t,this._onChangeCallback()
      }get z(){
      return this._z
      }set z(t){
      this._z=t,this._onChangeCallback()
      }get w(){
      return this._w
      }set w(t){
      this._w=t,this._onChangeCallback()
      }set(t,e,i,s){
      return this._x=t,this._y=e,this._z=i,this._w=s,this._onChangeCallback(),this
      }clone(){
      return new this.constructor(this._x,this._y,this._z,this._w)
      }copy(t){
      return this._x=t.x,this._y=t.y,this._z=t.z,this._w=t.w,this._onChangeCallback(),this
      }setFromEuler(t,e=!0){
      let i=t._x,s=t._y,r=t._z,n=t._order,a=Math.cos,o=Math.sin,h=a(i/2),l=a(s/2),u=a(r/2),c=o(i/2),p=o(s/2),d=o(r/2);
      switch(n){case"XYZ":
      this._x=c*l*u+h*p*d,this._y=h*p*u-c*l*d,this._z=h*l*d+c*p*u,this._w=h*l*u-c*p*d;
      break;
      case"YXZ":
      this._x=c*l*u+h*p*d,this._y=h*p*u-c*l*d,this._z=h*l*d-c*p*u,this._w=h*l*u+c*p*d;
      break;
      case"ZXY":
      this._x=c*l*u-h*p*d,this._y=h*p*u+c*l*d,this._z=h*l*d+c*p*u,this._w=h*l*u-c*p*d;
      break;
      case"ZYX":
      this._x=c*l*u-h*p*d,this._y=h*p*u+c*l*d,this._z=h*l*d-c*p*u,this._w=h*l*u+c*p*d;
      break;
      case"YZX":
      this._x=c*l*u+h*p*d,this._y=h*p*u+c*l*d,this._z=h*l*d-c*p*u,this._w=h*l*u-c*p*d;
      break;
      case"XZY":
      this._x=c*l*u-h*p*d,this._y=h*p*u-c*l*d,this._z=h*l*d+c*p*u,this._w=h*l*u+c*p*d;
      break;
      default:
      _("Quaternion: .setFromEuler() encountered an unknown order: "+n)
      }
      return!0===e&&this._onChangeCallback(),this
      }setFromAxisAngle(t,e){
      let i=e/2,s=Math.sin(i);
      return this._x=t.x*s,this._y=t.y*s,this._z=t.z*s,this._w=Math.cos(i),this._onChangeCallback(),this
      }setFromRotationMatrix(t){
      let e=t.elements,i=e[0],s=e[4],r=e[8],n=e[1],a=e[5],o=e[9],h=e[2],l=e[6],u=e[10],c=i+a+u;
      if(c>0){
        let t=.5/Math.sqrt(c+1);
        this._w=.25/t,this._x=(l-o)*t,this._y=(r-h)*t,this._z=(n-s)*t
        }else 
      if(i>a&&i>u){
        let t=2*Math.sqrt(1+i-a-u);
        this._w=(l-o)/t,this._x=.25*t,this._y=(s+n)/t,this._z=(r+h)/t
        }else 
      if(a>u){
        let t=2*Math.sqrt(1+a-i-u);
        this._w=(r-h)/t,this._x=(s+n)/t,this._y=.25*t,this._z=(o+l)/t
        }else{
        let t=2*Math.sqrt(1+u-i-a);
        this._w=(n-s)/t,this._x=(r+h)/t,this._y=(o+l)/t,this._z=.25*t
        }
      return this._onChangeCallback(),this
      }setFromUnitVectors(t,e){
      let i=t.dot(e)+1;
      return i<1e-8?(i=0,Math.abs(t.x)>Math.abs(t.z)?(this._x=-t.y,this._y=t.x,this._z=0):(this._x=0,this._y=-t.z,this._z=t.y)):(this._x=t.y*e.z-t.z*e.y,this._y=t.z*e.x-t.x*e.z,this._z=t.x*e.y-t.y*e.x),this._w=i,this.normalize()
      }angleTo(t){
      return 2*Math.acos(Math.abs(R(this.dot(t),-1,1)))
      }rotateTowards(t,e){
      let i=this.angleTo(t);
      if(0===i)
      return this;
      let s=Math.min(1,e/i);
      return this.slerp(t,s),this
      }identity(){
      return this.set(0,0,0,1)
      }invert(){
      return this.conjugate()
      }conjugate(){
      return this._x*=-1,this._y*=-1,this._z*=-1,this._onChangeCallback(),this
      }dot(t){
      return this._x*t._x+this._y*t._y+this._z*t._z+this._w*t._w
      }lengthSq(){
      return this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w
      }length(){
      return Math.sqrt(this._x*this._x+this._y*this._y+this._z*this._z+this._w*this._w)
      }normalize(){
      let t=this.length();
      return 0===t?(this._x=0,this._y=0,this._z=0,this._w=1):(t=1/t,this._x=this._x*t,this._y=this._y*t,this._z=this._z*t,this._w=this._w*t),this._onChangeCallback(),this
      }multiply(t){
      return this.multiplyQuaternions(this,t)
      }premultiply(t){
      return this.multiplyQuaternions(t,this)
      }multiplyQuaternions(t,e){
      let i=t._x,s=t._y,r=t._z,n=t._w,a=e._x,o=e._y,h=e._z,l=e._w;
      return this._x=i*l+n*a+s*h-r*o,this._y=s*l+n*o+r*a-i*h,this._z=r*l+n*h+i*o-s*a,this._w=n*l-i*a-s*o-r*h,this._onChangeCallback(),this
      }slerp(t,e){
      let i=t._x,s=t._y,r=t._z,n=t._w,a=this.dot(t);
      a<0&&(i=-i,s=-s,r=-r,n=-n,a=-a);
      let o=1-e;
      if(a<.9995){
        let t=Math.acos(a),h=Math.sin(t);
        o=Math.sin(o*t)/h,e=Math.sin(e*t)/h,this._x=this._x*o+i*e,this._y=this._y*o+s*e,this._z=this._z*o+r*e,this._w=this._w*o+n*e,this._onChangeCallback()
        }else 
      this._x=this._x*o+i*e,this._y=this._y*o+s*e,this._z=this._z*o+r*e,this._w=this._w*o+n*e,this.normalize();
      return this
      }slerpQuaternions(t,e,i){
      return this.copy(t).slerp(e,i)
      }random(){
      let t=2*Math.PI*Math.random(),e=2*Math.PI*Math.random(),i=Math.random(),s=Math.sqrt(1-i),r=Math.sqrt(i);
      return this.set(s*Math.sin(t),s*Math.cos(t),r*Math.sin(e),r*Math.cos(e))
      }equals(t){
      return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._w===this._w
      }fromArray(t,e=0){
      return this._x=t[e],this._y=t[e+1],this._z=t[e+2],this._w=t[e+3],this._onChangeCallback(),this
      }toArray(t=[],e=0){
      return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._w,t
      }fromBufferAttribute(t,e){
      return this._x=t.getX(e),this._y=t.getY(e),this._z=t.getZ(e),this._w=t.getW(e),this._onChangeCallback(),this
      }toJSON(){
      return this.toArray()
      }_onChange(t){
      return this._onChangeCallback=t,this
      }_onChangeCallback(){
      }*[Symbol.iterator](){
      yield this._x,yield this._y,yield this._z,yield this._w
      }
  }
  class D{
    static{
    D.prototype.isVector3=!0
    }constructor(t=0,e=0,i=0){
      this.x=t,this.y=e,this.z=i
      }set(t,e,i){
      return void 0===i&&(i=this.z),this.x=t,this.y=e,this.z=i,this
      }setScalar(t){
      return this.x=t,this.y=t,this.z=t,this
      }setX(t){
      return this.x=t,this
      }setY(t){
      return this.y=t,this
      }setZ(t){
      return this.z=t,this
      }setComponent(t,e){
      switch(t){case 0:
      this.x=e;
      break;
      case 1:
      this.y=e;
      break;
      case 2:
      this.z=e;
      break;
      default:
      throw Error("index is out of range: "+t)
      }
      return this
      }getComponent(t){
      switch(t){case 0:
      return this.x;
      case 1:
      return this.y;
      case 2:
      return this.z;
      default:
      throw Error("index is out of range: "+t)
      }
      }clone(){
      return new this.constructor(this.x,this.y,this.z)
      }copy(t){
      return this.x=t.x,this.y=t.y,this.z=t.z,this
      }add(t){
      return this.x+=t.x,this.y+=t.y,this.z+=t.z,this
      }addScalar(t){
      return this.x+=t,this.y+=t,this.z+=t,this
      }addVectors(t,e){
      return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this
      }addScaledVector(t,e){
      return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this
      }sub(t){
      return this.x-=t.x,this.y-=t.y,this.z-=t.z,this
      }subScalar(t){
      return this.x-=t,this.y-=t,this.z-=t,this
      }subVectors(t,e){
      return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this
      }multiply(t){
      return this.x*=t.x,this.y*=t.y,this.z*=t.z,this
      }multiplyScalar(t){
      return this.x*=t,this.y*=t,this.z*=t,this
      }multiplyVectors(t,e){
      return this.x=t.x*e.x,this.y=t.y*e.y,this.z=t.z*e.z,this
      }applyEuler(t){
      return this.applyQuaternion(j.setFromEuler(t))
      }applyAxisAngle(t,e){
      return this.applyQuaternion(j.setFromAxisAngle(t,e))
      }applyMatrix3(t){
      let e=this.x,i=this.y,s=this.z,r=t.elements;
      return this.x=r[0]*e+r[3]*i+r[6]*s,this.y=r[1]*e+r[4]*i+r[7]*s,this.z=r[2]*e+r[5]*i+r[8]*s,this
      }applyNormalMatrix(t){
      return this.applyMatrix3(t).normalize()
      }applyMatrix4(t){
      let e=this.x,i=this.y,s=this.z,r=t.elements,n=1/(r[3]*e+r[7]*i+r[11]*s+r[15]);
      return this.x=(r[0]*e+r[4]*i+r[8]*s+r[12])*n,this.y=(r[1]*e+r[5]*i+r[9]*s+r[13])*n,this.z=(r[2]*e+r[6]*i+r[10]*s+r[14])*n,this
      }applyQuaternion(t){
      let e=this.x,i=this.y,s=this.z,r=t.x,n=t.y,a=t.z,o=t.w,h=2*(n*s-a*i),l=2*(a*e-r*s),u=2*(r*i-n*e);
      return this.x=e+o*h+n*u-a*l,this.y=i+o*l+a*h-r*u,this.z=s+o*u+r*l-n*h,this
      }project(t){
      return this.applyMatrix4(t.matrixWorldInverse).applyMatrix4(t.projectionMatrix)
      }unproject(t){
      return this.applyMatrix4(t.projectionMatrixInverse).applyMatrix4(t.matrixWorld)
      }transformDirection(t){
      let e=this.x,i=this.y,s=this.z,r=t.elements;
      return this.x=r[0]*e+r[4]*i+r[8]*s,this.y=r[1]*e+r[5]*i+r[9]*s,this.z=r[2]*e+r[6]*i+r[10]*s,this.normalize()
      }divide(t){
      return this.x/=t.x,this.y/=t.y,this.z/=t.z,this
      }divideScalar(t){
      return this.multiplyScalar(1/t)
      }min(t){
      return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this
      }max(t){
      return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this
      }clamp(t,e){
      return this.x=R(this.x,t.x,e.x),this.y=R(this.y,t.y,e.y),this.z=R(this.z,t.z,e.z),this
      }clampScalar(t,e){
      return this.x=R(this.x,t,e),this.y=R(this.y,t,e),this.z=R(this.z,t,e),this
      }clampLength(t,e){
      let i=this.length();
      return this.divideScalar(i||1).multiplyScalar(R(i,t,e))
      }floor(){
      return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this
      }ceil(){
      return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this
      }round(){
      return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this
      }roundToZero(){
      return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this
      }negate(){
      return this.x=-this.x,this.y=-this.y,this.z=-this.z,this
      }dot(t){
      return this.x*t.x+this.y*t.y+this.z*t.z
      }lengthSq(){
      return this.x*this.x+this.y*this.y+this.z*this.z
      }length(){
      return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z)
      }manhattanLength(){
      return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)
      }normalize(){
      return this.divideScalar(this.length()||1)
      }setLength(t){
      return this.normalize().multiplyScalar(t)
      }lerp(t,e){
      return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this
      }lerpVectors(t,e,i){
      return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this
      }cross(t){
      return this.crossVectors(this,t)
      }crossVectors(t,e){
      let i=t.x,s=t.y,r=t.z,n=e.x,a=e.y,o=e.z;
      return this.x=s*o-r*a,this.y=r*n-i*o,this.z=i*a-s*n,this
      }projectOnVector(t){
      let e=t.lengthSq();
      if(0===e)
      return this.set(0,0,0);
      let i=t.dot(this)/e;
      return this.copy(t).multiplyScalar(i)
      }projectOnPlane(t){
      return U.copy(this).projectOnVector(t),this.sub(U)
      }reflect(t){
      return this.sub(U.copy(t).multiplyScalar(2*this.dot(t)))
      }angleTo(t){
      let e=Math.sqrt(this.lengthSq()*t.lengthSq());
      return 0===e?Math.PI/2:Math.acos(R(this.dot(t)/e,-1,1))
      }distanceTo(t){
      return Math.sqrt(this.distanceToSquared(t))
      }distanceToSquared(t){
      let e=this.x-t.x,i=this.y-t.y,s=this.z-t.z;
      return e*e+i*i+s*s
      }manhattanDistanceTo(t){
      return Math.abs(this.x-t.x)+Math.abs(this.y-t.y)+Math.abs(this.z-t.z)
      }setFromSpherical(t){
      return this.setFromSphericalCoords(t.radius,t.phi,t.theta)
      }setFromSphericalCoords(t,e,i){
      let s=Math.sin(e)*t;
      return this.x=s*Math.sin(i),this.y=Math.cos(e)*t,this.z=s*Math.cos(i),this
      }setFromCylindrical(t){
      return this.setFromCylindricalCoords(t.radius,t.theta,t.y)
      }setFromCylindricalCoords(t,e,i){
      return this.x=t*Math.sin(e),this.y=i,this.z=t*Math.cos(e),this
      }setFromMatrixPosition(t){
      let e=t.elements;
      return this.x=e[12],this.y=e[13],this.z=e[14],this
      }setFromMatrixScale(t){
      let e=this.setFromMatrixColumn(t,0).length(),i=this.setFromMatrixColumn(t,1).length(),s=this.setFromMatrixColumn(t,2).length();
      return this.x=e,this.y=i,this.z=s,this
      }setFromMatrixColumn(t,e){
      return this.fromArray(t.elements,4*e)
      }setFromMatrix3Column(t,e){
      return this.fromArray(t.elements,3*e)
      }setFromEuler(t){
      return this.x=t._x,this.y=t._y,this.z=t._z,this
      }setFromColor(t){
      return this.x=t.r,this.y=t.g,this.z=t.b,this
      }equals(t){
      return t.x===this.x&&t.y===this.y&&t.z===this.z
      }fromArray(t,e=0){
      return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this
      }toArray(t=[],e=0){
      return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t
      }fromBufferAttribute(t,e){
      return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this
      }random(){
      return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this
      }randomDirection(){
      let t=Math.random()*Math.PI*2,e=2*Math.random()-1,i=Math.sqrt(1-e*e);
      return this.x=i*Math.cos(t),this.y=e,this.z=i*Math.sin(t),this
      }*[Symbol.iterator](){
      yield this.x,yield this.y,yield this.z
      }
  }
  let U=new D,j=new V;
  class W{
    static{
    W.prototype.isMatrix3=!0
    }constructor(t,e,i,s,r,n,a,o,h){
      this.elements=[1,0,0,0,1,0,0,0,1],void 0!==t&&this.set(t,e,i,s,r,n,a,o,h)
      }set(t,e,i,s,r,n,a,o,h){
      let l=this.elements;
      return l[0]=t,l[1]=s,l[2]=a,l[3]=e,l[4]=r,l[5]=o,l[6]=i,l[7]=n,l[8]=h,this
      }identity(){
      return this.set(1,0,0,0,1,0,0,0,1),this
      }copy(t){
      let e=this.elements,i=t.elements;
      return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],this
      }extractBasis(t,e,i){
      return t.setFromMatrix3Column(this,0),e.setFromMatrix3Column(this,1),i.setFromMatrix3Column(this,2),this
      }setFromMatrix4(t){
      let e=t.elements;
      return this.set(e[0],e[4],e[8],e[1],e[5],e[9],e[2],e[6],e[10]),this
      }multiply(t){
      return this.multiplyMatrices(this,t)
      }premultiply(t){
      return this.multiplyMatrices(t,this)
      }multiplyMatrices(t,e){
      let i=t.elements,s=e.elements,r=this.elements,n=i[0],a=i[3],o=i[6],h=i[1],l=i[4],u=i[7],c=i[2],p=i[5],d=i[8],m=s[0],y=s[3],f=s[6],g=s[1],x=s[4],b=s[7],v=s[2],M=s[5],w=s[8];
      return r[0]=n*m+a*g+o*v,r[3]=n*y+a*x+o*M,r[6]=n*f+a*b+o*w,r[1]=h*m+l*g+u*v,r[4]=h*y+l*x+u*M,r[7]=h*f+l*b+u*w,r[2]=c*m+p*g+d*v,r[5]=c*y+p*x+d*M,r[8]=c*f+p*b+d*w,this
      }multiplyScalar(t){
      let e=this.elements;
      return e[0]*=t,e[3]*=t,e[6]*=t,e[1]*=t,e[4]*=t,e[7]*=t,e[2]*=t,e[5]*=t,e[8]*=t,this
      }determinant(){
      let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],n=t[4],a=t[5],o=t[6],h=t[7],l=t[8];
      return e*n*l-e*a*h-i*r*l+i*a*o+s*r*h-s*n*o
      }invert(){
      let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],n=t[4],a=t[5],o=t[6],h=t[7],l=t[8],u=l*n-a*h,c=a*o-l*r,p=h*r-n*o,d=e*u+i*c+s*p;
      if(0===d)
      return this.set(0,0,0,0,0,0,0,0,0);
      let m=1/d;
      return t[0]=u*m,t[1]=(s*h-l*i)*m,t[2]=(a*i-s*n)*m,t[3]=c*m,t[4]=(l*e-s*o)*m,t[5]=(s*r-a*e)*m,t[6]=p*m,t[7]=(i*o-h*e)*m,t[8]=(n*e-i*r)*m,this
      }transpose(){
      let t,e=this.elements;
      return t=e[1],e[1]=e[3],e[3]=t,t=e[2],e[2]=e[6],e[6]=t,t=e[5],e[5]=e[7],e[7]=t,this
      }getNormalMatrix(t){
      return this.setFromMatrix4(t).invert().transpose()
      }transposeIntoArray(t){
      let e=this.elements;
      return t[0]=e[0],t[1]=e[3],t[2]=e[6],t[3]=e[1],t[4]=e[4],t[5]=e[7],t[6]=e[2],t[7]=e[5],t[8]=e[8],this
      }setUvTransform(t,e,i,s,r,n,a){
      let o=Math.cos(r),h=Math.sin(r);
      return this.set(i*o,i*h,-i*(o*n+h*a)+n+t,-s*h,s*o,-s*(-h*n+o*a)+a+e,0,0,1),this
      }scale(t,e){
      return this.premultiply(G.makeScale(t,e)),this
      }rotate(t){
      return this.premultiply(G.makeRotation(-t)),this
      }translate(t,e){
      return this.premultiply(G.makeTranslation(t,e)),this
      }makeTranslation(t,e){
      return t.isVector2?this.set(1,0,t.x,0,1,t.y,0,0,1):this.set(1,0,t,0,1,e,0,0,1),this
      }makeRotation(t){
      let e=Math.cos(t),i=Math.sin(t);
      return this.set(e,-i,0,i,e,0,0,0,1),this
      }makeScale(t,e){
      return this.set(t,0,0,0,e,0,0,0,1),this
      }equals(t){
      let e=this.elements,i=t.elements;
      for(
      let t=0
      ;t<9;t++)
      if(e[t]!==i[t])
      return!1;
      return!0
      }fromArray(t,e=0){
      for(
      let i=0
      ;i<9;i++)
      this.elements[i]=t[i+e];
      return this
      }toArray(t=[],e=0){
      let i=this.elements;
      return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t
      }clone(){
      return new this.constructor().fromArray(this.elements)
      }
  }
  let G=new W,q=new W().set(.4123908,.3575843,.1804808,.212639,.7151687,.0721923,.0193308,.1191948,.9505322),J=new W().set(3.2409699,-1.5373832,-.4986108,-.9692436,1.8759675,.0415551,.0556301,-.203977,1.0569715),H=(o=[.64,.33,.3,.6,.15,.06],h=[.2126,.7152,.0722],l=[.3127,.329],(a={enabled:!0,workingColorSpace:d,spaces:{},convert:function(t,e,i){
    return!1!==this.enabled&&e!==i&&e&&i&&(this.spaces[e].transfer===y&&(t.r=X(t.r),t.g=X(t.g),t.b=X(t.b)),this.spaces[e].primaries!==this.spaces[i].primaries&&(t.applyMatrix3(this.spaces[e].toXYZ),t.applyMatrix3(this.spaces[i].fromXYZ)),this.spaces[i].transfer===y&&(t.r=Y(t.r),t.g=Y(t.g),t.b=Y(t.b))),t
    },workingToColorSpace:function(t,e){
    return this.convert(t,this.workingColorSpace,e)
    },colorSpaceToWorking:function(t,e){
    return this.convert(t,e,this.workingColorSpace)
    },getPrimaries:function(t){
    return this.spaces[t].primaries
    },getTransfer:function(t){
    return""===t?m:this.spaces[t].transfer
    },getToneMappingMode:function(t){
    return this.spaces[t].outputColorSpaceConfig.toneMappingMode||"standard"
    },getLuminanceCoefficients:function(t,e=this.workingColorSpace){
    return t.fromArray(this.spaces[e].luminanceCoefficients)
    },define:function(t){
    Object.assign(this.spaces,t)
    },_getMatrix:function(t,e,i){
    return t.copy(this.spaces[e].toXYZ).multiply(this.spaces[i].fromXYZ)
    },_getDrawingBufferColorSpace:function(t){
    return this.spaces[t].outputColorSpaceConfig.drawingBufferColorSpace
    },_getUnpackColorSpace:function(t=this.workingColorSpace){
    return this.spaces[t].workingColorSpaceConfig.unpackColorSpace
    },fromWorkingColorSpace:function(t,e){
    return T("ColorManagement: .fromWorkingColorSpace() has been renamed to .workingToColorSpace()."),a.workingToColorSpace(t,e)
    },toWorkingColorSpace:function(t,e){
    return T("ColorManagement: .toWorkingColorSpace() has been renamed to .colorSpaceToWorking()."),a.colorSpaceToWorking(t,e)
    }}).define({[d]:{primaries:o,whitePoint:l,transfer:m,toXYZ:q,fromXYZ:J,luminanceCoefficients:h,workingColorSpaceConfig:{unpackColorSpace:p},outputColorSpaceConfig:{drawingBufferColorSpace:p}},[p]:{primaries:o,whitePoint:l,transfer:y,toXYZ:q,fromXYZ:J,luminanceCoefficients:h,outputColorSpaceConfig:{drawingBufferColorSpace:p}}}),a);
  function X(t){
    return t<.04045?.0773993808*t:Math.pow(.9478672986*t+.0521327014,2.4)
    }
  function Y(t){
    return t<.0031308?12.92*t:1.055*Math.pow(t,.41666)-.055
    }
  class Z{
    static getDataURL(t,i="image/png"){
      let s;
      if(/^data:/i.test(t.src)||"u"<typeof HTMLCanvasElement)
      return t.src;
      if(t instanceof HTMLCanvasElement)
      s=t;
      else{
        void 0===e&&(e=b("canvas")),e.width=t.width,e.height=t.height;
        let i=e.getContext("2d");
        t instanceof ImageData?i.putImageData(t,0,0):i.drawImage(t,0,0,t.width,t.height),s=e
        }
      return s.toDataURL(i)
      }static sRGBToLinear(t){
      if("u">typeof HTMLImageElement&&t instanceof HTMLImageElement||"u">typeof HTMLCanvasElement&&t instanceof HTMLCanvasElement||"u">typeof ImageBitmap&&t instanceof ImageBitmap){
        let e=b("canvas");
        e.width=t.width,e.height=t.height;
        let i=e.getContext("2d");
        i.drawImage(t,0,0,t.width,t.height);
        let s=i.getImageData(0,0,t.width,t.height),r=s.data;
        for(
        let t=0
        ;t<r.length;t++)
        r[t]=255*X(r[t]/255);
        return i.putImageData(s,0,0),e
        }
      if(!t.data)
      return _("ImageUtils.sRGBToLinear(): Unsupported image type. No color space conversion applied."),t;
      {
        let e=t.data.slice(0);
        for(
        let t=0
        ;t<e.length;t++)
        e instanceof Uint8Array||e instanceof Uint8ClampedArray?e[t]=Math.floor(255*X(e[t]/255)):e[t]=X(e[t]);
        return{data:e,width:t.width,height:t.height}
        }
    }
  }
  let $=0;
  class Q{
    constructor(t=null){
      this.isSource=!0,Object.defineProperty(this,"id",{value:$++}),this.uuid=O(),this.data=t,this.dataReady=!0,this.version=0
      }getSize(t){
      let e=this.data;
      return"u">typeof HTMLVideoElement&&e instanceof HTMLVideoElement?t.set(e.videoWidth,e.videoHeight,0):"u">typeof VideoFrame&&e instanceof VideoFrame?t.set(e.displayWidth,e.displayHeight,0):null!==e?t.set(e.width,e.height,e.depth||0):t.set(0,0,0),t
      }set needsUpdate(t){
      !0===t&&this.version++
      }toJSON(t){
      let e=void 0===t||"string"==typeof t;
      if(!e&&void 0!==t.images[this.uuid])
      return t.images[this.uuid];
      let i={uuid:this.uuid,url:""},s=this.data;
      if(null!==s){
        let t;
        if(Array.isArray(s)){
          t=[];
          for(
          let e=0,i=s.length
          ;e<i;e++)
          s[e].isDataTexture?t.push(K(s[e].image)):t.push(K(s[e]))
          }else 
        t=K(s);
        i.url=t
        }
      return e||(t.images[this.uuid]=i),i
      }
  }
  function K(t){
    return"u">typeof HTMLImageElement&&t instanceof HTMLImageElement||"u">typeof HTMLCanvasElement&&t instanceof HTMLCanvasElement||"u">typeof ImageBitmap&&t instanceof ImageBitmap?Z.getDataURL(t):t.data?{data:Array.from(t.data),width:t.width,height:t.height,type:t.data.constructor.name}:(_("Texture: Unable to serialize Texture."),{})
    }
  let tt=0,te=new D;
  class ti extends C{
    constructor(t=ti.DEFAULT_IMAGE,e=ti.DEFAULT_MAPPING,i=1001,s=1001,r=1006,n=1008,a=1023,o=1009,h=ti.DEFAULT_ANISOTROPY,l=""){
      super(),this.isTexture=!0,Object.defineProperty(this,"id",{value:tt++}),this.uuid=O(),this.name="",this.source=new Q(t),this.mipmaps=[],this.mapping=e,this.channel=0,this.wrapS=i,this.wrapT=s,this.magFilter=r,this.minFilter=n,this.anisotropy=h,this.format=a,this.internalFormat=null,this.type=o,this.offset=new E(0,0),this.repeat=new E(1,1),this.center=new E(0,0),this.rotation=0,this.matrixAutoUpdate=!0,this.matrix=new W,this.generateMipmaps=!0,this.premultiplyAlpha=!1,this.flipY=!0,this.unpackAlignment=4,this.colorSpace=l,this.userData={},this.updateRanges=[],this.version=0,this.onUpdate=null,this.renderTarget=null,this.isRenderTargetTexture=!1,this.isArrayTexture=!!t&&!!t.depth&&t.depth>1,this.pmremVersion=0,this.normalized=!1
      }get width(){
      return this.source.getSize(te).x
      }get height(){
      return this.source.getSize(te).y
      }get depth(){
      return this.source.getSize(te).z
      }get image(){
      return this.source.data
      }set image(t){
      this.source.data=t
      }updateMatrix(){
      this.matrix.setUvTransform(this.offset.x,this.offset.y,this.repeat.x,this.repeat.y,this.rotation,this.center.x,this.center.y)
      }addUpdateRange(t,e){
      this.updateRanges.push({start:t,count:e})
      }clearUpdateRanges(){
      this.updateRanges.length=0
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      return this.name=t.name,this.source=t.source,this.mipmaps=t.mipmaps.slice(0),this.mapping=t.mapping,this.channel=t.channel,this.wrapS=t.wrapS,this.wrapT=t.wrapT,this.magFilter=t.magFilter,this.minFilter=t.minFilter,this.anisotropy=t.anisotropy,this.format=t.format,this.internalFormat=t.internalFormat,this.type=t.type,this.normalized=t.normalized,this.offset.copy(t.offset),this.repeat.copy(t.repeat),this.center.copy(t.center),this.rotation=t.rotation,this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrix.copy(t.matrix),this.generateMipmaps=t.generateMipmaps,this.premultiplyAlpha=t.premultiplyAlpha,this.flipY=t.flipY,this.unpackAlignment=t.unpackAlignment,this.colorSpace=t.colorSpace,this.renderTarget=t.renderTarget,this.isRenderTargetTexture=t.isRenderTargetTexture,this.isArrayTexture=t.isArrayTexture,this.userData=JSON.parse(JSON.stringify(t.userData)),this.needsUpdate=!0,this
      }setValues(t){
      for(
      let e
       in t){
        let i=t[e];
        if(void 0===i){
          _(`Texture.setValues(): parameter '${e}' has value of undefined.`);
          continue
          }
        let s=this[e];
        if(void 0===s){
          _(`Texture.setValues(): property '${e}' does not exist.`);
          continue
          }
        s&&i&&s.isVector2&&i.isVector2||s&&i&&s.isVector3&&i.isVector3||s&&i&&s.isMatrix3&&i.isMatrix3?s.copy(i):this[e]=i
        }
      }toJSON(t){
      let e=void 0===t||"string"==typeof t;
      if(!e&&void 0!==t.textures[this.uuid])
      return t.textures[this.uuid];
      let i={metadata:{version:4.7,type:"Texture",generator:"Texture.toJSON"},uuid:this.uuid,name:this.name,image:this.source.toJSON(t).uuid,mapping:this.mapping,channel:this.channel,repeat:[this.repeat.x,this.repeat.y],offset:[this.offset.x,this.offset.y],center:[this.center.x,this.center.y],rotation:this.rotation,wrap:[this.wrapS,this.wrapT],format:this.format,internalFormat:this.internalFormat,type:this.type,normalized:this.normalized,colorSpace:this.colorSpace,minFilter:this.minFilter,magFilter:this.magFilter,anisotropy:this.anisotropy,flipY:this.flipY,generateMipmaps:this.generateMipmaps,premultiplyAlpha:this.premultiplyAlpha,unpackAlignment:this.unpackAlignment};
      return Object.keys(this.userData).length>0&&(i.userData=this.userData),e||(t.textures[this.uuid]=i),i
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }transformUv(t){
      if(300!==this.mapping)
      return t;
      if(t.applyMatrix3(this.matrix),t.x<0||t.x>1)
      switch(this.wrapS){case 1e3:
      t.x=t.x-Math.floor(t.x);
      break;
      case 1001:
      t.x=t.x<0?0:1;
      break;
      case 1002:
      1===Math.abs(Math.floor(t.x)%2)?t.x=Math.ceil(t.x)-t.x:t.x=t.x-Math.floor(t.x)
      }
      if(t.y<0||t.y>1)
      switch(this.wrapT){case 1e3:
      t.y=t.y-Math.floor(t.y);
      break;
      case 1001:
      t.y=t.y<0?0:1;
      break;
      case 1002:
      1===Math.abs(Math.floor(t.y)%2)?t.y=Math.ceil(t.y)-t.y:t.y=t.y-Math.floor(t.y)
      }
      return this.flipY&&(t.y=1-t.y),t
      }set needsUpdate(t){
      !0===t&&(this.version++,this.source.needsUpdate=!0)
      }set needsPMREMUpdate(t){
      !0===t&&this.pmremVersion++
      }
  }
  ti.DEFAULT_IMAGE=null,ti.DEFAULT_MAPPING=300,ti.DEFAULT_ANISOTROPY=1;
  class ts{
    static{
    ts.prototype.isVector4=!0
    }constructor(t=0,e=0,i=0,s=1){
      this.x=t,this.y=e,this.z=i,this.w=s
      }get width(){
      return this.z
      }set width(t){
      this.z=t
      }get height(){
      return this.w
      }set height(t){
      this.w=t
      }set(t,e,i,s){
      return this.x=t,this.y=e,this.z=i,this.w=s,this
      }setScalar(t){
      return this.x=t,this.y=t,this.z=t,this.w=t,this
      }setX(t){
      return this.x=t,this
      }setY(t){
      return this.y=t,this
      }setZ(t){
      return this.z=t,this
      }setW(t){
      return this.w=t,this
      }setComponent(t,e){
      switch(t){case 0:
      this.x=e;
      break;
      case 1:
      this.y=e;
      break;
      case 2:
      this.z=e;
      break;
      case 3:
      this.w=e;
      break;
      default:
      throw Error("index is out of range: "+t)
      }
      return this
      }getComponent(t){
      switch(t){case 0:
      return this.x;
      case 1:
      return this.y;
      case 2:
      return this.z;
      case 3:
      return this.w;
      default:
      throw Error("index is out of range: "+t)
      }
      }clone(){
      return new this.constructor(this.x,this.y,this.z,this.w)
      }copy(t){
      return this.x=t.x,this.y=t.y,this.z=t.z,this.w=void 0!==t.w?t.w:1,this
      }add(t){
      return this.x+=t.x,this.y+=t.y,this.z+=t.z,this.w+=t.w,this
      }addScalar(t){
      return this.x+=t,this.y+=t,this.z+=t,this.w+=t,this
      }addVectors(t,e){
      return this.x=t.x+e.x,this.y=t.y+e.y,this.z=t.z+e.z,this.w=t.w+e.w,this
      }addScaledVector(t,e){
      return this.x+=t.x*e,this.y+=t.y*e,this.z+=t.z*e,this.w+=t.w*e,this
      }sub(t){
      return this.x-=t.x,this.y-=t.y,this.z-=t.z,this.w-=t.w,this
      }subScalar(t){
      return this.x-=t,this.y-=t,this.z-=t,this.w-=t,this
      }subVectors(t,e){
      return this.x=t.x-e.x,this.y=t.y-e.y,this.z=t.z-e.z,this.w=t.w-e.w,this
      }multiply(t){
      return this.x*=t.x,this.y*=t.y,this.z*=t.z,this.w*=t.w,this
      }multiplyScalar(t){
      return this.x*=t,this.y*=t,this.z*=t,this.w*=t,this
      }applyMatrix4(t){
      let e=this.x,i=this.y,s=this.z,r=this.w,n=t.elements;
      return this.x=n[0]*e+n[4]*i+n[8]*s+n[12]*r,this.y=n[1]*e+n[5]*i+n[9]*s+n[13]*r,this.z=n[2]*e+n[6]*i+n[10]*s+n[14]*r,this.w=n[3]*e+n[7]*i+n[11]*s+n[15]*r,this
      }divide(t){
      return this.x/=t.x,this.y/=t.y,this.z/=t.z,this.w/=t.w,this
      }divideScalar(t){
      return this.multiplyScalar(1/t)
      }setAxisAngleFromQuaternion(t){
      this.w=2*Math.acos(t.w);
      let e=Math.sqrt(1-t.w*t.w);
      return e<1e-4?(this.x=1,this.y=0,this.z=0):(this.x=t.x/e,this.y=t.y/e,this.z=t.z/e),this
      }setAxisAngleFromRotationMatrix(t){
      let e,i,s,r,n=t.elements,a=n[0],o=n[4],h=n[8],l=n[1],u=n[5],c=n[9],p=n[2],d=n[6],m=n[10];
      if(.01>Math.abs(o-l)&&.01>Math.abs(h-p)&&.01>Math.abs(c-d)){
        if(.1>Math.abs(o+l)&&.1>Math.abs(h+p)&&.1>Math.abs(c+d)&&.1>Math.abs(a+u+m-3))
        return this.set(1,0,0,0),this;
        e=Math.PI;
        let t=(a+1)/2,n=(u+1)/2,y=(m+1)/2,f=(o+l)/4,g=(h+p)/4,x=(c+d)/4;
        return t>n&&t>y?t<.01?(i=0,s=.707106781,r=.707106781):(s=f/(i=Math.sqrt(t)),r=g/i):n>y?n<.01?(i=.707106781,s=0,r=.707106781):(i=f/(s=Math.sqrt(n)),r=x/s):y<.01?(i=.707106781,s=.707106781,r=0):(i=g/(r=Math.sqrt(y)),s=x/r),this.set(i,s,r,e),this
        }
      let y=Math.sqrt((d-c)*(d-c)+(h-p)*(h-p)+(l-o)*(l-o));
      return .001>Math.abs(y)&&(y=1),this.x=(d-c)/y,this.y=(h-p)/y,this.z=(l-o)/y,this.w=Math.acos((a+u+m-1)/2),this
      }setFromMatrixPosition(t){
      let e=t.elements;
      return this.x=e[12],this.y=e[13],this.z=e[14],this.w=e[15],this
      }min(t){
      return this.x=Math.min(this.x,t.x),this.y=Math.min(this.y,t.y),this.z=Math.min(this.z,t.z),this.w=Math.min(this.w,t.w),this
      }max(t){
      return this.x=Math.max(this.x,t.x),this.y=Math.max(this.y,t.y),this.z=Math.max(this.z,t.z),this.w=Math.max(this.w,t.w),this
      }clamp(t,e){
      return this.x=R(this.x,t.x,e.x),this.y=R(this.y,t.y,e.y),this.z=R(this.z,t.z,e.z),this.w=R(this.w,t.w,e.w),this
      }clampScalar(t,e){
      return this.x=R(this.x,t,e),this.y=R(this.y,t,e),this.z=R(this.z,t,e),this.w=R(this.w,t,e),this
      }clampLength(t,e){
      let i=this.length();
      return this.divideScalar(i||1).multiplyScalar(R(i,t,e))
      }floor(){
      return this.x=Math.floor(this.x),this.y=Math.floor(this.y),this.z=Math.floor(this.z),this.w=Math.floor(this.w),this
      }ceil(){
      return this.x=Math.ceil(this.x),this.y=Math.ceil(this.y),this.z=Math.ceil(this.z),this.w=Math.ceil(this.w),this
      }round(){
      return this.x=Math.round(this.x),this.y=Math.round(this.y),this.z=Math.round(this.z),this.w=Math.round(this.w),this
      }roundToZero(){
      return this.x=Math.trunc(this.x),this.y=Math.trunc(this.y),this.z=Math.trunc(this.z),this.w=Math.trunc(this.w),this
      }negate(){
      return this.x=-this.x,this.y=-this.y,this.z=-this.z,this.w=-this.w,this
      }dot(t){
      return this.x*t.x+this.y*t.y+this.z*t.z+this.w*t.w
      }lengthSq(){
      return this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w
      }length(){
      return Math.sqrt(this.x*this.x+this.y*this.y+this.z*this.z+this.w*this.w)
      }manhattanLength(){
      return Math.abs(this.x)+Math.abs(this.y)+Math.abs(this.z)+Math.abs(this.w)
      }normalize(){
      return this.divideScalar(this.length()||1)
      }setLength(t){
      return this.normalize().multiplyScalar(t)
      }lerp(t,e){
      return this.x+=(t.x-this.x)*e,this.y+=(t.y-this.y)*e,this.z+=(t.z-this.z)*e,this.w+=(t.w-this.w)*e,this
      }lerpVectors(t,e,i){
      return this.x=t.x+(e.x-t.x)*i,this.y=t.y+(e.y-t.y)*i,this.z=t.z+(e.z-t.z)*i,this.w=t.w+(e.w-t.w)*i,this
      }equals(t){
      return t.x===this.x&&t.y===this.y&&t.z===this.z&&t.w===this.w
      }fromArray(t,e=0){
      return this.x=t[e],this.y=t[e+1],this.z=t[e+2],this.w=t[e+3],this
      }toArray(t=[],e=0){
      return t[e]=this.x,t[e+1]=this.y,t[e+2]=this.z,t[e+3]=this.w,t
      }fromBufferAttribute(t,e){
      return this.x=t.getX(e),this.y=t.getY(e),this.z=t.getZ(e),this.w=t.getW(e),this
      }random(){
      return this.x=Math.random(),this.y=Math.random(),this.z=Math.random(),this.w=Math.random(),this
      }*[Symbol.iterator](){
      yield this.x,yield this.y,yield this.z,yield this.w
      }
  }
  class tr extends C{
    constructor(t=1,e=1,i={}){
      super(),i=Object.assign({generateMipmaps:!1,internalFormat:null,minFilter:1006,depthBuffer:!0,stencilBuffer:!1,resolveDepthBuffer:!0,resolveStencilBuffer:!0,depthTexture:null,samples:0,count:1,depth:1,multiview:!1},i),this.isRenderTarget=!0,this.width=t,this.height=e,this.depth=i.depth,this.scissor=new ts(0,0,t,e),this.scissorTest=!1,this.viewport=new ts(0,0,t,e),this.textures=[];
      const s=new ti({width:t,height:e,depth:i.depth}),r=i.count;
      for(
      let t=0
      ;t<r;t++)
      this.textures[t]=s.clone(),this.textures[t].isRenderTargetTexture=!0,this.textures[t].renderTarget=this;
      this._setTextureOptions(i),this.depthBuffer=i.depthBuffer,this.stencilBuffer=i.stencilBuffer,this.resolveDepthBuffer=i.resolveDepthBuffer,this.resolveStencilBuffer=i.resolveStencilBuffer,this._depthTexture=null,this.depthTexture=i.depthTexture,this.samples=i.samples,this.multiview=i.multiview
      }_setTextureOptions(t={}){
      let e={minFilter:1006,generateMipmaps:!1,flipY:!1,internalFormat:null};
      void 0!==t.mapping&&(e.mapping=t.mapping),void 0!==t.wrapS&&(e.wrapS=t.wrapS),void 0!==t.wrapT&&(e.wrapT=t.wrapT),void 0!==t.wrapR&&(e.wrapR=t.wrapR),void 0!==t.magFilter&&(e.magFilter=t.magFilter),void 0!==t.minFilter&&(e.minFilter=t.minFilter),void 0!==t.format&&(e.format=t.format),void 0!==t.type&&(e.type=t.type),void 0!==t.anisotropy&&(e.anisotropy=t.anisotropy),void 0!==t.colorSpace&&(e.colorSpace=t.colorSpace),void 0!==t.flipY&&(e.flipY=t.flipY),void 0!==t.generateMipmaps&&(e.generateMipmaps=t.generateMipmaps),void 0!==t.internalFormat&&(e.internalFormat=t.internalFormat);
      for(
      let t=0
      ;t<this.textures.length;t++)
      this.textures[t].setValues(e)
      }get texture(){
      return this.textures[0]
      }set texture(t){
      this.textures[0]=t
      }set depthTexture(t){
      null!==this._depthTexture&&(this._depthTexture.renderTarget=null),null!==t&&(t.renderTarget=this),this._depthTexture=t
      }get depthTexture(){
      return this._depthTexture
      }setSize(t,e,i=1){
      if(this.width!==t||this.height!==e||this.depth!==i){
        this.width=t,this.height=e,this.depth=i;
        for(
        let s=0,r=this.textures.length
        ;s<r;s++)
        this.textures[s].image.width=t,this.textures[s].image.height=e,this.textures[s].image.depth=i,!0!==this.textures[s].isData3DTexture&&(this.textures[s].isArrayTexture=this.textures[s].image.depth>1);
        this.dispose()
        }
      this.viewport.set(0,0,t,e),this.scissor.set(0,0,t,e)
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      this.width=t.width,this.height=t.height,this.depth=t.depth,this.scissor.copy(t.scissor),this.scissorTest=t.scissorTest,this.viewport.copy(t.viewport),this.textures.length=0;
      for(
      let e=0,i=t.textures.length
      ;e<i;e++){
        this.textures[e]=t.textures[e].clone(),this.textures[e].isRenderTargetTexture=!0,this.textures[e].renderTarget=this;
        let i=Object.assign({},t.textures[e].image);
        this.textures[e].source=new Q(i)
        }
      return this.depthBuffer=t.depthBuffer,this.stencilBuffer=t.stencilBuffer,this.resolveDepthBuffer=t.resolveDepthBuffer,this.resolveStencilBuffer=t.resolveStencilBuffer,null!==t.depthTexture&&(this.depthTexture=t.depthTexture.clone()),this.samples=t.samples,this.multiview=t.multiview,this
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }
  }
  class tn extends tr{
    constructor(t=1,e=1,i={}){
      super(t,e,i),this.isWebGLRenderTarget=!0
      }
  }
  class ta extends ti{
    constructor(t=null,e=1,i=1,s=1){
      super(null),this.isDataArrayTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=1003,this.minFilter=1003,this.wrapR=1001,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1,this.layerUpdates=new Set
      }addLayerUpdate(t){
      this.layerUpdates.add(t)
      }clearLayerUpdates(){
      this.layerUpdates.clear()
      }
  }
  class to extends ti{
    constructor(t=null,e=1,i=1,s=1){
      super(null),this.isData3DTexture=!0,this.image={data:t,width:e,height:i,depth:s},this.magFilter=1003,this.minFilter=1003,this.wrapR=1001,this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1
      }
  }
  class th{
    static{
    th.prototype.isMatrix4=!0
    }constructor(t,e,i,s,r,n,a,o,h,l,u,c,p,d,m,y){
      this.elements=[1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1],void 0!==t&&this.set(t,e,i,s,r,n,a,o,h,l,u,c,p,d,m,y)
      }set(t,e,i,s,r,n,a,o,h,l,u,c,p,d,m,y){
      let f=this.elements;
      return f[0]=t,f[4]=e,f[8]=i,f[12]=s,f[1]=r,f[5]=n,f[9]=a,f[13]=o,f[2]=h,f[6]=l,f[10]=u,f[14]=c,f[3]=p,f[7]=d,f[11]=m,f[15]=y,this
      }identity(){
      return this.set(1,0,0,0,0,1,0,0,0,0,1,0,0,0,0,1),this
      }clone(){
      return new th().fromArray(this.elements)
      }copy(t){
      let e=this.elements,i=t.elements;
      return e[0]=i[0],e[1]=i[1],e[2]=i[2],e[3]=i[3],e[4]=i[4],e[5]=i[5],e[6]=i[6],e[7]=i[7],e[8]=i[8],e[9]=i[9],e[10]=i[10],e[11]=i[11],e[12]=i[12],e[13]=i[13],e[14]=i[14],e[15]=i[15],this
      }copyPosition(t){
      let e=this.elements,i=t.elements;
      return e[12]=i[12],e[13]=i[13],e[14]=i[14],this
      }setFromMatrix3(t){
      let e=t.elements;
      return this.set(e[0],e[3],e[6],0,e[1],e[4],e[7],0,e[2],e[5],e[8],0,0,0,0,1),this
      }extractBasis(t,e,i){
      return 0===this.determinant()?(t.set(1,0,0),e.set(0,1,0),i.set(0,0,1)):(t.setFromMatrixColumn(this,0),e.setFromMatrixColumn(this,1),i.setFromMatrixColumn(this,2)),this
      }makeBasis(t,e,i){
      return this.set(t.x,e.x,i.x,0,t.y,e.y,i.y,0,t.z,e.z,i.z,0,0,0,0,1),this
      }extractRotation(t){
      if(0===t.determinant())
      return this.identity();
      let e=this.elements,i=t.elements,s=1/tl.setFromMatrixColumn(t,0).length(),r=1/tl.setFromMatrixColumn(t,1).length(),n=1/tl.setFromMatrixColumn(t,2).length();
      return e[0]=i[0]*s,e[1]=i[1]*s,e[2]=i[2]*s,e[3]=0,e[4]=i[4]*r,e[5]=i[5]*r,e[6]=i[6]*r,e[7]=0,e[8]=i[8]*n,e[9]=i[9]*n,e[10]=i[10]*n,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this
      }makeRotationFromEuler(t){
      let e=this.elements,i=t.x,s=t.y,r=t.z,n=Math.cos(i),a=Math.sin(i),o=Math.cos(s),h=Math.sin(s),l=Math.cos(r),u=Math.sin(r);
      if("XYZ"===t.order){
        let t=n*l,i=n*u,s=a*l,r=a*u;
        e[0]=o*l,e[4]=-o*u,e[8]=h,e[1]=i+s*h,e[5]=t-r*h,e[9]=-a*o,e[2]=r-t*h,e[6]=s+i*h,e[10]=n*o
        }else 
      if("YXZ"===t.order){
        let t=o*l,i=o*u,s=h*l,r=h*u;
        e[0]=t+r*a,e[4]=s*a-i,e[8]=n*h,e[1]=n*u,e[5]=n*l,e[9]=-a,e[2]=i*a-s,e[6]=r+t*a,e[10]=n*o
        }else 
      if("ZXY"===t.order){
        let t=o*l,i=o*u,s=h*l,r=h*u;
        e[0]=t-r*a,e[4]=-n*u,e[8]=s+i*a,e[1]=i+s*a,e[5]=n*l,e[9]=r-t*a,e[2]=-n*h,e[6]=a,e[10]=n*o
        }else 
      if("ZYX"===t.order){
        let t=n*l,i=n*u,s=a*l,r=a*u;
        e[0]=o*l,e[4]=s*h-i,e[8]=t*h+r,e[1]=o*u,e[5]=r*h+t,e[9]=i*h-s,e[2]=-h,e[6]=a*o,e[10]=n*o
        }else 
      if("YZX"===t.order){
        let t=n*o,i=n*h,s=a*o,r=a*h;
        e[0]=o*l,e[4]=r-t*u,e[8]=s*u+i,e[1]=u,e[5]=n*l,e[9]=-a*l,e[2]=-h*l,e[6]=i*u+s,e[10]=t-r*u
        }else 
      if("XZY"===t.order){
        let t=n*o,i=n*h,s=a*o,r=a*h;
        e[0]=o*l,e[4]=-u,e[8]=h*l,e[1]=t*u+r,e[5]=n*l,e[9]=i*u-s,e[2]=s*u-i,e[6]=a*l,e[10]=r*u+t
        }
      return e[3]=0,e[7]=0,e[11]=0,e[12]=0,e[13]=0,e[14]=0,e[15]=1,this
      }makeRotationFromQuaternion(t){
      return this.compose(tc,t,tp)
      }lookAt(t,e,i){
      let s=this.elements;
      return ty.subVectors(t,e),0===ty.lengthSq()&&(ty.z=1),ty.normalize(),td.crossVectors(i,ty),0===td.lengthSq()&&(1===Math.abs(i.z)?ty.x+=1e-4:ty.z+=1e-4,ty.normalize(),td.crossVectors(i,ty)),td.normalize(),tm.crossVectors(ty,td),s[0]=td.x,s[4]=tm.x,s[8]=ty.x,s[1]=td.y,s[5]=tm.y,s[9]=ty.y,s[2]=td.z,s[6]=tm.z,s[10]=ty.z,this
      }multiply(t){
      return this.multiplyMatrices(this,t)
      }premultiply(t){
      return this.multiplyMatrices(t,this)
      }multiplyMatrices(t,e){
      let i=t.elements,s=e.elements,r=this.elements,n=i[0],a=i[4],o=i[8],h=i[12],l=i[1],u=i[5],c=i[9],p=i[13],d=i[2],m=i[6],y=i[10],f=i[14],g=i[3],x=i[7],b=i[11],v=i[15],M=s[0],w=s[4],S=s[8],_=s[12],A=s[1],T=s[5],C=s[9],I=s[13],z=s[2],B=s[6],k=s[10],O=s[14],R=s[3],P=s[7],F=s[11],L=s[15];
      return r[0]=n*M+a*A+o*z+h*R,r[4]=n*w+a*T+o*B+h*P,r[8]=n*S+a*C+o*k+h*F,r[12]=n*_+a*I+o*O+h*L,r[1]=l*M+u*A+c*z+p*R,r[5]=l*w+u*T+c*B+p*P,r[9]=l*S+u*C+c*k+p*F,r[13]=l*_+u*I+c*O+p*L,r[2]=d*M+m*A+y*z+f*R,r[6]=d*w+m*T+y*B+f*P,r[10]=d*S+m*C+y*k+f*F,r[14]=d*_+m*I+y*O+f*L,r[3]=g*M+x*A+b*z+v*R,r[7]=g*w+x*T+b*B+v*P,r[11]=g*S+x*C+b*k+v*F,r[15]=g*_+x*I+b*O+v*L,this
      }multiplyScalar(t){
      let e=this.elements;
      return e[0]*=t,e[4]*=t,e[8]*=t,e[12]*=t,e[1]*=t,e[5]*=t,e[9]*=t,e[13]*=t,e[2]*=t,e[6]*=t,e[10]*=t,e[14]*=t,e[3]*=t,e[7]*=t,e[11]*=t,e[15]*=t,this
      }determinant(){
      let t=this.elements,e=t[0],i=t[4],s=t[8],r=t[12],n=t[1],a=t[5],o=t[9],h=t[13],l=t[2],u=t[6],c=t[10],p=t[14],d=t[3],m=t[7],y=t[11],f=t[15],g=o*p-h*c,x=a*p-h*u,b=a*c-o*u,v=n*p-h*l,M=n*c-o*l,w=n*u-a*l;
      return e*(m*g-y*x+f*b)-i*(d*g-y*v+f*M)+s*(d*x-m*v+f*w)-r*(d*b-m*M+y*w)
      }transpose(){
      let t,e=this.elements;
      return t=e[1],e[1]=e[4],e[4]=t,t=e[2],e[2]=e[8],e[8]=t,t=e[6],e[6]=e[9],e[9]=t,t=e[3],e[3]=e[12],e[12]=t,t=e[7],e[7]=e[13],e[13]=t,t=e[11],e[11]=e[14],e[14]=t,this
      }setPosition(t,e,i){
      let s=this.elements;
      return t.isVector3?(s[12]=t.x,s[13]=t.y,s[14]=t.z):(s[12]=t,s[13]=e,s[14]=i),this
      }invert(){
      let t=this.elements,e=t[0],i=t[1],s=t[2],r=t[3],n=t[4],a=t[5],o=t[6],h=t[7],l=t[8],u=t[9],c=t[10],p=t[11],d=t[12],m=t[13],y=t[14],f=t[15],g=e*a-i*n,x=e*o-s*n,b=e*h-r*n,v=i*o-s*a,M=i*h-r*a,w=s*h-r*o,S=l*m-u*d,_=l*y-c*d,A=l*f-p*d,T=u*y-c*m,C=u*f-p*m,I=c*f-p*y,z=g*I-x*C+b*T+v*A-M*_+w*S;
      if(0===z)
      return this.set(0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
      let B=1/z;
      return t[0]=(a*I-o*C+h*T)*B,t[1]=(s*C-i*I-r*T)*B,t[2]=(m*w-y*M+f*v)*B,t[3]=(c*M-u*w-p*v)*B,t[4]=(o*A-n*I-h*_)*B,t[5]=(e*I-s*A+r*_)*B,t[6]=(y*b-d*w-f*x)*B,t[7]=(l*w-c*b+p*x)*B,t[8]=(n*C-a*A+h*S)*B,t[9]=(i*A-e*C-r*S)*B,t[10]=(d*M-m*b+f*g)*B,t[11]=(u*b-l*M-p*g)*B,t[12]=(a*_-n*T-o*S)*B,t[13]=(e*T-i*_+s*S)*B,t[14]=(m*x-d*v-y*g)*B,t[15]=(l*v-u*x+c*g)*B,this
      }scale(t){
      let e=this.elements,i=t.x,s=t.y,r=t.z;
      return e[0]*=i,e[4]*=s,e[8]*=r,e[1]*=i,e[5]*=s,e[9]*=r,e[2]*=i,e[6]*=s,e[10]*=r,e[3]*=i,e[7]*=s,e[11]*=r,this
      }getMaxScaleOnAxis(){
      let t=this.elements;
      return Math.sqrt(Math.max(t[0]*t[0]+t[1]*t[1]+t[2]*t[2],t[4]*t[4]+t[5]*t[5]+t[6]*t[6],t[8]*t[8]+t[9]*t[9]+t[10]*t[10]))
      }makeTranslation(t,e,i){
      return t.isVector3?this.set(1,0,0,t.x,0,1,0,t.y,0,0,1,t.z,0,0,0,1):this.set(1,0,0,t,0,1,0,e,0,0,1,i,0,0,0,1),this
      }makeRotationX(t){
      let e=Math.cos(t),i=Math.sin(t);
      return this.set(1,0,0,0,0,e,-i,0,0,i,e,0,0,0,0,1),this
      }makeRotationY(t){
      let e=Math.cos(t),i=Math.sin(t);
      return this.set(e,0,i,0,0,1,0,0,-i,0,e,0,0,0,0,1),this
      }makeRotationZ(t){
      let e=Math.cos(t),i=Math.sin(t);
      return this.set(e,-i,0,0,i,e,0,0,0,0,1,0,0,0,0,1),this
      }makeRotationAxis(t,e){
      let i=Math.cos(e),s=Math.sin(e),r=1-i,n=t.x,a=t.y,o=t.z,h=r*n,l=r*a;
      return this.set(h*n+i,h*a-s*o,h*o+s*a,0,h*a+s*o,l*a+i,l*o-s*n,0,h*o-s*a,l*o+s*n,r*o*o+i,0,0,0,0,1),this
      }makeScale(t,e,i){
      return this.set(t,0,0,0,0,e,0,0,0,0,i,0,0,0,0,1),this
      }makeShear(t,e,i,s,r,n){
      return this.set(1,i,r,0,t,1,n,0,e,s,1,0,0,0,0,1),this
      }compose(t,e,i){
      let s=this.elements,r=e._x,n=e._y,a=e._z,o=e._w,h=r+r,l=n+n,u=a+a,c=r*h,p=r*l,d=r*u,m=n*l,y=n*u,f=a*u,g=o*h,x=o*l,b=o*u,v=i.x,M=i.y,w=i.z;
      return s[0]=(1-(m+f))*v,s[1]=(p+b)*v,s[2]=(d-x)*v,s[3]=0,s[4]=(p-b)*M,s[5]=(1-(c+f))*M,s[6]=(y+g)*M,s[7]=0,s[8]=(d+x)*w,s[9]=(y-g)*w,s[10]=(1-(c+m))*w,s[11]=0,s[12]=t.x,s[13]=t.y,s[14]=t.z,s[15]=1,this
      }decompose(t,e,i){
      let s=this.elements;
      t.x=s[12],t.y=s[13],t.z=s[14];
      let r=this.determinant();
      if(0===r)
      return i.set(1,1,1),e.identity(),this;
      let n=tl.set(s[0],s[1],s[2]).length(),a=tl.set(s[4],s[5],s[6]).length(),o=tl.set(s[8],s[9],s[10]).length();
      r<0&&(n=-n),tu.copy(this);
      let h=1/n,l=1/a,u=1/o;
      return tu.elements[0]*=h,tu.elements[1]*=h,tu.elements[2]*=h,tu.elements[4]*=l,tu.elements[5]*=l,tu.elements[6]*=l,tu.elements[8]*=u,tu.elements[9]*=u,tu.elements[10]*=u,e.setFromRotationMatrix(tu),i.x=n,i.y=a,i.z=o,this
      }makePerspective(t,e,i,s,r,n,a=2e3,o=!1){
      let h,l,u=this.elements;
      if(o)
      h=r/(n-r),l=n*r/(n-r);
      else 
      if(2e3===a)
      h=-(n+r)/(n-r),l=-2*n*r/(n-r);
      else 
      if(2001===a)
      h=-n/(n-r),l=-n*r/(n-r);
      else 
      throw Error("THREE.Matrix4.makePerspective(): Invalid coordinate system: "+a);
      return u[0]=2*r/(e-t),u[4]=0,u[8]=(e+t)/(e-t),u[12]=0,u[1]=0,u[5]=2*r/(i-s),u[9]=(i+s)/(i-s),u[13]=0,u[2]=0,u[6]=0,u[10]=h,u[14]=l,u[3]=0,u[7]=0,u[11]=-1,u[15]=0,this
      }makeOrthographic(t,e,i,s,r,n,a=2e3,o=!1){
      let h,l,u=this.elements;
      if(o)
      h=1/(n-r),l=n/(n-r);
      else 
      if(2e3===a)
      h=-2/(n-r),l=-(n+r)/(n-r);
      else 
      if(2001===a)
      h=-1/(n-r),l=-r/(n-r);
      else 
      throw Error("THREE.Matrix4.makeOrthographic(): Invalid coordinate system: "+a);
      return u[0]=2/(e-t),u[4]=0,u[8]=0,u[12]=-(e+t)/(e-t),u[1]=0,u[5]=2/(i-s),u[9]=0,u[13]=-(i+s)/(i-s),u[2]=0,u[6]=0,u[10]=h,u[14]=l,u[3]=0,u[7]=0,u[11]=0,u[15]=1,this
      }equals(t){
      let e=this.elements,i=t.elements;
      for(
      let t=0
      ;t<16;t++)
      if(e[t]!==i[t])
      return!1;
      return!0
      }fromArray(t,e=0){
      for(
      let i=0
      ;i<16;i++)
      this.elements[i]=t[i+e];
      return this
      }toArray(t=[],e=0){
      let i=this.elements;
      return t[e]=i[0],t[e+1]=i[1],t[e+2]=i[2],t[e+3]=i[3],t[e+4]=i[4],t[e+5]=i[5],t[e+6]=i[6],t[e+7]=i[7],t[e+8]=i[8],t[e+9]=i[9],t[e+10]=i[10],t[e+11]=i[11],t[e+12]=i[12],t[e+13]=i[13],t[e+14]=i[14],t[e+15]=i[15],t
      }
  }
  let tl=new D,tu=new th,tc=new D(0,0,0),tp=new D(1,1,1),td=new D,tm=new D,ty=new D,tf=new th,tg=new V;
  class tx{
    constructor(t=0,e=0,i=0,s=tx.DEFAULT_ORDER){
      this.isEuler=!0,this._x=t,this._y=e,this._z=i,this._order=s
      }get x(){
      return this._x
      }set x(t){
      this._x=t,this._onChangeCallback()
      }get y(){
      return this._y
      }set y(t){
      this._y=t,this._onChangeCallback()
      }get z(){
      return this._z
      }set z(t){
      this._z=t,this._onChangeCallback()
      }get order(){
      return this._order
      }set order(t){
      this._order=t,this._onChangeCallback()
      }set(t,e,i,s=this._order){
      return this._x=t,this._y=e,this._z=i,this._order=s,this._onChangeCallback(),this
      }clone(){
      return new this.constructor(this._x,this._y,this._z,this._order)
      }copy(t){
      return this._x=t._x,this._y=t._y,this._z=t._z,this._order=t._order,this._onChangeCallback(),this
      }setFromRotationMatrix(t,e=this._order,i=!0){
      let s=t.elements,r=s[0],n=s[4],a=s[8],o=s[1],h=s[5],l=s[9],u=s[2],c=s[6],p=s[10];
      switch(e){case"XYZ":
      this._y=Math.asin(R(a,-1,1)),.9999999>Math.abs(a)?(this._x=Math.atan2(-l,p),this._z=Math.atan2(-n,r)):(this._x=Math.atan2(c,h),this._z=0);
      break;
      case"YXZ":
      this._x=Math.asin(-R(l,-1,1)),.9999999>Math.abs(l)?(this._y=Math.atan2(a,p),this._z=Math.atan2(o,h)):(this._y=Math.atan2(-u,r),this._z=0);
      break;
      case"ZXY":
      this._x=Math.asin(R(c,-1,1)),.9999999>Math.abs(c)?(this._y=Math.atan2(-u,p),this._z=Math.atan2(-n,h)):(this._y=0,this._z=Math.atan2(o,r));
      break;
      case"ZYX":
      this._y=Math.asin(-R(u,-1,1)),.9999999>Math.abs(u)?(this._x=Math.atan2(c,p),this._z=Math.atan2(o,r)):(this._x=0,this._z=Math.atan2(-n,h));
      break;
      case"YZX":
      this._z=Math.asin(R(o,-1,1)),.9999999>Math.abs(o)?(this._x=Math.atan2(-l,h),this._y=Math.atan2(-u,r)):(this._x=0,this._y=Math.atan2(a,p));
      break;
      case"XZY":
      this._z=Math.asin(-R(n,-1,1)),.9999999>Math.abs(n)?(this._x=Math.atan2(c,h),this._y=Math.atan2(a,r)):(this._x=Math.atan2(-l,p),this._y=0);
      break;
      default:
      _("Euler: .setFromRotationMatrix() encountered an unknown order: "+e)
      }
      return this._order=e,!0===i&&this._onChangeCallback(),this
      }setFromQuaternion(t,e,i){
      return tf.makeRotationFromQuaternion(t),this.setFromRotationMatrix(tf,e,i)
      }setFromVector3(t,e=this._order){
      return this.set(t.x,t.y,t.z,e)
      }reorder(t){
      return tg.setFromEuler(this),this.setFromQuaternion(tg,t)
      }equals(t){
      return t._x===this._x&&t._y===this._y&&t._z===this._z&&t._order===this._order
      }fromArray(t){
      return this._x=t[0],this._y=t[1],this._z=t[2],void 0!==t[3]&&(this._order=t[3]),this._onChangeCallback(),this
      }toArray(t=[],e=0){
      return t[e]=this._x,t[e+1]=this._y,t[e+2]=this._z,t[e+3]=this._order,t
      }_onChange(t){
      return this._onChangeCallback=t,this
      }_onChangeCallback(){
      }*[Symbol.iterator](){
      yield this._x,yield this._y,yield this._z,yield this._order
      }
  }
  tx.DEFAULT_ORDER="XYZ";
  class tb{
    constructor(){
      this.mask=1
      }set(t){
      this.mask=1<<t>>>0
      }enable(t){
      this.mask|=1<<t
      }enableAll(){
      this.mask=-1
      }toggle(t){
      this.mask^=1<<t
      }disable(t){
      this.mask&=~(1<<t)
      }disableAll(){
      this.mask=0
      }test(t){
      return(this.mask&t.mask)!=0
      }isEnabled(t){
      return(this.mask&1<<t)!=0
      }
  }
  let tv=0,tM=new D,tw=new V,tS=new th,t_=new D,tA=new D,tT=new D,tC=new V,tI=new D(1,0,0),tz=new D(0,1,0),tB=new D(0,0,1),tk={type:"added"},tO={type:"removed"},tR={type:"childadded",child:null},tP={type:"childremoved",child:null};
  class tF extends C{
    constructor(){
      super(),this.isObject3D=!0,Object.defineProperty(this,"id",{value:tv++}),this.uuid=O(),this.name="",this.type="Object3D",this.parent=null,this.children=[],this.up=tF.DEFAULT_UP.clone();
      const t=new D,e=new tx,i=new V,s=new D(1,1,1);
      e._onChange(function(){
        i.setFromEuler(e,!1)
        }),i._onChange(function(){
        e.setFromQuaternion(i,void 0,!1)
        }),Object.defineProperties(this,{position:{configurable:!0,enumerable:!0,value:t},rotation:{configurable:!0,enumerable:!0,value:e},quaternion:{configurable:!0,enumerable:!0,value:i},scale:{configurable:!0,enumerable:!0,value:s},modelViewMatrix:{value:new th},normalMatrix:{value:new W}}),this.matrix=new th,this.matrixWorld=new th,this.matrixAutoUpdate=tF.DEFAULT_MATRIX_AUTO_UPDATE,this.matrixWorldAutoUpdate=tF.DEFAULT_MATRIX_WORLD_AUTO_UPDATE,this.matrixWorldNeedsUpdate=!1,this.layers=new tb,this.visible=!0,this.castShadow=!1,this.receiveShadow=!1,this.frustumCulled=!0,this.renderOrder=0,this.animations=[],this.customDepthMaterial=void 0,this.customDistanceMaterial=void 0,this.static=!1,this.userData={},this.pivot=null
      }onBeforeShadow(){
      }onAfterShadow(){
      }onBeforeRender(){
      }onAfterRender(){
      }applyMatrix4(t){
      this.matrixAutoUpdate&&this.updateMatrix(),this.matrix.premultiply(t),this.matrix.decompose(this.position,this.quaternion,this.scale)
      }applyQuaternion(t){
      return this.quaternion.premultiply(t),this
      }setRotationFromAxisAngle(t,e){
      this.quaternion.setFromAxisAngle(t,e)
      }setRotationFromEuler(t){
      this.quaternion.setFromEuler(t,!0)
      }setRotationFromMatrix(t){
      this.quaternion.setFromRotationMatrix(t)
      }setRotationFromQuaternion(t){
      this.quaternion.copy(t)
      }rotateOnAxis(t,e){
      return tw.setFromAxisAngle(t,e),this.quaternion.multiply(tw),this
      }rotateOnWorldAxis(t,e){
      return tw.setFromAxisAngle(t,e),this.quaternion.premultiply(tw),this
      }rotateX(t){
      return this.rotateOnAxis(tI,t)
      }rotateY(t){
      return this.rotateOnAxis(tz,t)
      }rotateZ(t){
      return this.rotateOnAxis(tB,t)
      }translateOnAxis(t,e){
      return tM.copy(t).applyQuaternion(this.quaternion),this.position.add(tM.multiplyScalar(e)),this
      }translateX(t){
      return this.translateOnAxis(tI,t)
      }translateY(t){
      return this.translateOnAxis(tz,t)
      }translateZ(t){
      return this.translateOnAxis(tB,t)
      }localToWorld(t){
      return this.updateWorldMatrix(!0,!1),t.applyMatrix4(this.matrixWorld)
      }worldToLocal(t){
      return this.updateWorldMatrix(!0,!1),t.applyMatrix4(tS.copy(this.matrixWorld).invert())
      }lookAt(t,e,i){
      t.isVector3?t_.copy(t):t_.set(t,e,i);
      let s=this.parent;
      this.updateWorldMatrix(!0,!1),tA.setFromMatrixPosition(this.matrixWorld),this.isCamera||this.isLight?tS.lookAt(tA,t_,this.up):tS.lookAt(t_,tA,this.up),this.quaternion.setFromRotationMatrix(tS),s&&(tS.extractRotation(s.matrixWorld),tw.setFromRotationMatrix(tS),this.quaternion.premultiply(tw.invert()))
      }add(t){
      if(arguments.length>1){
        for(
        let t=0
        ;t<arguments.length;t++)
        this.add(arguments[t]);
        return this
        }
      return t===this?A("Object3D.add: object can't be added as a child of itself.",t):t&&t.isObject3D?(t.removeFromParent(),t.parent=this,this.children.push(t),t.dispatchEvent(tk),tR.child=t,this.dispatchEvent(tR),tR.child=null):A("Object3D.add: object not an instance of THREE.Object3D.",t),this
      }remove(t){
      if(arguments.length>1){
        for(
        let t=0
        ;t<arguments.length;t++)
        this.remove(arguments[t]);
        return this
        }
      let e=this.children.indexOf(t);
      return -1!==e&&(t.parent=null,this.children.splice(e,1),t.dispatchEvent(tO),tP.child=t,this.dispatchEvent(tP),tP.child=null),this
      }removeFromParent(){
      let t=this.parent;
      return null!==t&&t.remove(this),this
      }clear(){
      return this.remove(...this.children)
      }attach(t){
      return this.updateWorldMatrix(!0,!1),tS.copy(this.matrixWorld).invert(),null!==t.parent&&(t.parent.updateWorldMatrix(!0,!1),tS.multiply(t.parent.matrixWorld)),t.applyMatrix4(tS),t.removeFromParent(),t.parent=this,this.children.push(t),t.updateWorldMatrix(!1,!0),t.dispatchEvent(tk),tR.child=t,this.dispatchEvent(tR),tR.child=null,this
      }getObjectById(t){
      return this.getObjectByProperty("id",t)
      }getObjectByName(t){
      return this.getObjectByProperty("name",t)
      }getObjectByProperty(t,e){
      if(this[t]===e)
      return this;
      for(
      let i=0,s=this.children.length
      ;i<s;i++){
        let s=this.children[i].getObjectByProperty(t,e);
        if(void 0!==s)
        return s
        }
      }getObjectsByProperty(t,e,i=[]){
      this[t]===e&&i.push(this);
      let s=this.children;
      for(
      let r=0,n=s.length
      ;r<n;r++)
      s[r].getObjectsByProperty(t,e,i);
      return i
      }getWorldPosition(t){
      return this.updateWorldMatrix(!0,!1),t.setFromMatrixPosition(this.matrixWorld)
      }getWorldQuaternion(t){
      return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(tA,t,tT),t
      }getWorldScale(t){
      return this.updateWorldMatrix(!0,!1),this.matrixWorld.decompose(tA,tC,t),t
      }getWorldDirection(t){
      this.updateWorldMatrix(!0,!1);
      let e=this.matrixWorld.elements;
      return t.set(e[8],e[9],e[10]).normalize()
      }raycast(){
      }traverse(t){
      t(this);
      let e=this.children;
      for(
      let i=0,s=e.length
      ;i<s;i++)
      e[i].traverse(t)
      }traverseVisible(t){
      if(!1===this.visible)
      return;
      t(this);
      let e=this.children;
      for(
      let i=0,s=e.length
      ;i<s;i++)
      e[i].traverseVisible(t)
      }traverseAncestors(t){
      let e=this.parent;
      null!==e&&(t(e),e.traverseAncestors(t))
      }updateMatrix(){
      this.matrix.compose(this.position,this.quaternion,this.scale);
      let t=this.pivot;
      if(null!==t){
        let e=t.x,i=t.y,s=t.z,r=this.matrix.elements;
        r[12]+=e-r[0]*e-r[4]*i-r[8]*s,r[13]+=i-r[1]*e-r[5]*i-r[9]*s,r[14]+=s-r[2]*e-r[6]*i-r[10]*s
        }
      this.matrixWorldNeedsUpdate=!0
      }updateMatrixWorld(t){
      this.matrixAutoUpdate&&this.updateMatrix(),(this.matrixWorldNeedsUpdate||t)&&(!0===this.matrixWorldAutoUpdate&&(null===this.parent?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),this.matrixWorldNeedsUpdate=!1,t=!0);
      let e=this.children;
      for(
      let i=0,s=e.length
      ;i<s;i++)
      e[i].updateMatrixWorld(t)
      }updateWorldMatrix(t,e){
      let i=this.parent;
      if(!0===t&&null!==i&&i.updateWorldMatrix(!0,!1),this.matrixAutoUpdate&&this.updateMatrix(),!0===this.matrixWorldAutoUpdate&&(null===this.parent?this.matrixWorld.copy(this.matrix):this.matrixWorld.multiplyMatrices(this.parent.matrixWorld,this.matrix)),!0===e){
        let t=this.children;
        for(
        let e=0,i=t.length
        ;e<i;e++)
        t[e].updateWorldMatrix(!1,!0)
        }
      }toJSON(t){
      let e=void 0===t||"string"==typeof t,i={};
      e&&(t={geometries:{},materials:{},textures:{},images:{},shapes:{},skeletons:{},animations:{},nodes:{}},i.metadata={version:4.7,type:"Object",generator:"Object3D.toJSON"});
      let s={};
      function r(e,i){
        return void 0===e[i.uuid]&&(e[i.uuid]=i.toJSON(t)),i.uuid
        }
      if(s.uuid=this.uuid,s.type=this.type,""!==this.name&&(s.name=this.name),!0===this.castShadow&&(s.castShadow=!0),!0===this.receiveShadow&&(s.receiveShadow=!0),!1===this.visible&&(s.visible=!1),!1===this.frustumCulled&&(s.frustumCulled=!1),0!==this.renderOrder&&(s.renderOrder=this.renderOrder),!1!==this.static&&(s.static=this.static),Object.keys(this.userData).length>0&&(s.userData=this.userData),s.layers=this.layers.mask,s.matrix=this.matrix.toArray(),s.up=this.up.toArray(),null!==this.pivot&&(s.pivot=this.pivot.toArray()),!1===this.matrixAutoUpdate&&(s.matrixAutoUpdate=!1),void 0!==this.morphTargetDictionary&&(s.morphTargetDictionary=Object.assign({},this.morphTargetDictionary)),void 0!==this.morphTargetInfluences&&(s.morphTargetInfluences=this.morphTargetInfluences.slice()),this.isInstancedMesh&&(s.type="InstancedMesh",s.count=this.count,s.instanceMatrix=this.instanceMatrix.toJSON(),null!==this.instanceColor&&(s.instanceColor=this.instanceColor.toJSON())),this.isBatchedMesh&&(s.type="BatchedMesh",s.perObjectFrustumCulled=this.perObjectFrustumCulled,s.sortObjects=this.sortObjects,s.drawRanges=this._drawRanges,s.reservedRanges=this._reservedRanges,s.geometryInfo=this._geometryInfo.map(t=>({...t,boundingBox:t.boundingBox?t.boundingBox.toJSON():void 0,boundingSphere:t.boundingSphere?t.boundingSphere.toJSON():void 0})),s.instanceInfo=this._instanceInfo.map(t=>({...t})),s.availableInstanceIds=this._availableInstanceIds.slice(),s.availableGeometryIds=this._availableGeometryIds.slice(),s.nextIndexStart=this._nextIndexStart,s.nextVertexStart=this._nextVertexStart,s.geometryCount=this._geometryCount,s.maxInstanceCount=this._maxInstanceCount,s.maxVertexCount=this._maxVertexCount,s.maxIndexCount=this._maxIndexCount,s.geometryInitialized=this._geometryInitialized,s.matricesTexture=this._matricesTexture.toJSON(t),s.indirectTexture=this._indirectTexture.toJSON(t),null!==this._colorsTexture&&(s.colorsTexture=this._colorsTexture.toJSON(t)),null!==this.boundingSphere&&(s.boundingSphere=this.boundingSphere.toJSON()),null!==this.boundingBox&&(s.boundingBox=this.boundingBox.toJSON())),this.isScene)
      this.background&&(this.background.isColor?s.background=this.background.toJSON():this.background.isTexture&&(s.background=this.background.toJSON(t).uuid)),this.environment&&this.environment.isTexture&&!0!==this.environment.isRenderTargetTexture&&(s.environment=this.environment.toJSON(t).uuid);
      else 
      if(this.isMesh||this.isLine||this.isPoints){
        s.geometry=r(t.geometries,this.geometry);
        let e=this.geometry.parameters;
        if(void 0!==e&&void 0!==e.shapes){
          let i=e.shapes;
          if(Array.isArray(i))
          for(
          let e=0,s=i.length
          ;e<s;e++){
            let s=i[e];
            r(t.shapes,s)
            }
          else 
          r(t.shapes,i)
          }
        }
      if(this.isSkinnedMesh&&(s.bindMode=this.bindMode,s.bindMatrix=this.bindMatrix.toArray(),void 0!==this.skeleton&&(r(t.skeletons,this.skeleton),s.skeleton=this.skeleton.uuid)),void 0!==this.material)
      if(Array.isArray(this.material)){
        let e=[];
        for(
        let i=0,s=this.material.length
        ;i<s;i++)
        e.push(r(t.materials,this.material[i]));
        s.material=e
        }else 
      s.material=r(t.materials,this.material);
      if(this.children.length>0){
        s.children=[];
        for(
        let e=0
        ;e<this.children.length;e++)
        s.children.push(this.children[e].toJSON(t).object)
        }
      if(this.animations.length>0){
        s.animations=[];
        for(
        let e=0
        ;e<this.animations.length;e++){
          let i=this.animations[e];
          s.animations.push(r(t.animations,i))
          }
        }
      if(e){
        let e=n(t.geometries),s=n(t.materials),r=n(t.textures),a=n(t.images),o=n(t.shapes),h=n(t.skeletons),l=n(t.animations),u=n(t.nodes);
        e.length>0&&(i.geometries=e),s.length>0&&(i.materials=s),r.length>0&&(i.textures=r),a.length>0&&(i.images=a),o.length>0&&(i.shapes=o),h.length>0&&(i.skeletons=h),l.length>0&&(i.animations=l),u.length>0&&(i.nodes=u)
        }
      return i.object=s,i;
      function n(t){
        let e=[];
        for(
        let i
         in t){
          let s=t[i];
          delete s.metadata,e.push(s)
          }
        return e
        }
      }clone(t){
      return new this.constructor().copy(this,t)
      }copy(t,e=!0){
      if(this.name=t.name,this.up.copy(t.up),this.position.copy(t.position),this.rotation.order=t.rotation.order,this.quaternion.copy(t.quaternion),this.scale.copy(t.scale),this.pivot=null!==t.pivot?t.pivot.clone():null,this.matrix.copy(t.matrix),this.matrixWorld.copy(t.matrixWorld),this.matrixAutoUpdate=t.matrixAutoUpdate,this.matrixWorldAutoUpdate=t.matrixWorldAutoUpdate,this.matrixWorldNeedsUpdate=t.matrixWorldNeedsUpdate,this.layers.mask=t.layers.mask,this.visible=t.visible,this.castShadow=t.castShadow,this.receiveShadow=t.receiveShadow,this.frustumCulled=t.frustumCulled,this.renderOrder=t.renderOrder,this.static=t.static,this.animations=t.animations.slice(),this.userData=JSON.parse(JSON.stringify(t.userData)),!0===e)
      for(
      let e=0
      ;e<t.children.length;e++){
        let i=t.children[e];
        this.add(i.clone())
        }
      return this
      }
  }
  tF.DEFAULT_UP=new D(0,1,0),tF.DEFAULT_MATRIX_AUTO_UPDATE=!0,tF.DEFAULT_MATRIX_WORLD_AUTO_UPDATE=!0;
  class tL extends tF{
    constructor(){
      super(),this.isGroup=!0,this.type="Group"
      }
  }
  let tN={type:"move"},tE={aliceblue:0xf0f8ff,antiquewhite:0xfaebd7,aqua:65535,aquamarine:8388564,azure:0xf0ffff,beige:0xf5f5dc,bisque:0xffe4c4,black:0,blanchedalmond:0xffebcd,blue:255,blueviolet:9055202,brown:0xa52a2a,burlywood:0xdeb887,cadetblue:6266528,chartreuse:8388352,chocolate:0xd2691e,coral:0xff7f50,cornflowerblue:6591981,cornsilk:0xfff8dc,crimson:0xdc143c,cyan:65535,darkblue:139,darkcyan:35723,darkgoldenrod:0xb8860b,darkgray:0xa9a9a9,darkgreen:25600,darkgrey:0xa9a9a9,darkkhaki:0xbdb76b,darkmagenta:9109643,darkolivegreen:5597999,darkorange:0xff8c00,darkorchid:0x9932cc,darkred:9109504,darksalmon:0xe9967a,darkseagreen:9419919,darkslateblue:4734347,darkslategray:3100495,darkslategrey:3100495,darkturquoise:52945,darkviolet:9699539,deeppink:0xff1493,deepskyblue:49151,dimgray:6908265,dimgrey:6908265,dodgerblue:2003199,firebrick:0xb22222,floralwhite:0xfffaf0,forestgreen:2263842,fuchsia:0xff00ff,gainsboro:0xdcdcdc,ghostwhite:0xf8f8ff,gold:0xffd700,goldenrod:0xdaa520,gray:8421504,green:32768,greenyellow:0xadff2f,grey:8421504,honeydew:0xf0fff0,hotpink:0xff69b4,indianred:0xcd5c5c,indigo:4915330,ivory:0xfffff0,khaki:0xf0e68c,lavender:0xe6e6fa,lavenderblush:0xfff0f5,lawngreen:8190976,lemonchiffon:0xfffacd,lightblue:0xadd8e6,lightcoral:0xf08080,lightcyan:0xe0ffff,lightgoldenrodyellow:0xfafad2,lightgray:0xd3d3d3,lightgreen:9498256,lightgrey:0xd3d3d3,lightpink:0xffb6c1,lightsalmon:0xffa07a,lightseagreen:2142890,lightskyblue:8900346,lightslategray:7833753,lightslategrey:7833753,lightsteelblue:0xb0c4de,lightyellow:0xffffe0,lime:65280,limegreen:3329330,linen:0xfaf0e6,magenta:0xff00ff,maroon:8388608,mediumaquamarine:6737322,mediumblue:205,mediumorchid:0xba55d3,mediumpurple:9662683,mediumseagreen:3978097,mediumslateblue:8087790,mediumspringgreen:64154,mediumturquoise:4772300,mediumvioletred:0xc71585,midnightblue:1644912,mintcream:0xf5fffa,mistyrose:0xffe4e1,moccasin:0xffe4b5,navajowhite:0xffdead,navy:128,oldlace:0xfdf5e6,olive:8421376,olivedrab:7048739,orange:0xffa500,orangered:0xff4500,orchid:0xda70d6,palegoldenrod:0xeee8aa,palegreen:0x98fb98,paleturquoise:0xafeeee,palevioletred:0xdb7093,papayawhip:0xffefd5,peachpuff:0xffdab9,peru:0xcd853f,pink:0xffc0cb,plum:0xdda0dd,powderblue:0xb0e0e6,purple:8388736,rebeccapurple:6697881,red:0xff0000,rosybrown:0xbc8f8f,royalblue:4286945,saddlebrown:9127187,salmon:0xfa8072,sandybrown:0xf4a460,seagreen:3050327,seashell:0xfff5ee,sienna:0xa0522d,silver:0xc0c0c0,skyblue:8900331,slateblue:6970061,slategray:7372944,slategrey:7372944,snow:0xfffafa,springgreen:65407,steelblue:4620980,tan:0xd2b48c,teal:32896,thistle:0xd8bfd8,tomato:0xff6347,turquoise:4251856,violet:0xee82ee,wheat:0xf5deb3,white:0xffffff,whitesmoke:0xf5f5f5,yellow:0xffff00,yellowgreen:0x9acd32},tV={h:0,s:0,l:0},tD={h:0,s:0,l:0};
  function tU(t,e,i){
    return(i<0&&(i+=1),i>1&&(i-=1),i<1/6)?t+(e-t)*6*i:i<.5?e:i<2/3?t+(e-t)*6*(2/3-i):t
    }
  class tj{
    constructor(t,e,i){
      return this.isColor=!0,this.r=1,this.g=1,this.b=1,this.set(t,e,i)
      }set(t,e,i){
      return void 0===e&&void 0===i?t&&t.isColor?this.copy(t):"number"==typeof t?this.setHex(t):"string"==typeof t&&this.setStyle(t):this.setRGB(t,e,i),this
      }setScalar(t){
      return this.r=t,this.g=t,this.b=t,this
      }setHex(t,e=p){
      return t=Math.floor(t),this.r=(t>>16&255)/255,this.g=(t>>8&255)/255,this.b=(255&t)/255,H.colorSpaceToWorking(this,e),this
      }setRGB(t,e,i,s=H.workingColorSpace){
      return this.r=t,this.g=e,this.b=i,H.colorSpaceToWorking(this,s),this
      }setHSL(t,e,i,s=H.workingColorSpace){
      if(t=P(t,1),e=R(e,0,1),i=R(i,0,1),0===e)
      this.r=this.g=this.b=i;
      else{
        let s=i<=.5?i*(1+e):i+e-i*e,r=2*i-s;
        this.r=tU(r,s,t+1/3),this.g=tU(r,s,t),this.b=tU(r,s,t-1/3)
        }
      return H.colorSpaceToWorking(this,s),this
      }setStyle(t,e=p){
      let i;
      function s(e){
        void 0!==e&&1>parseFloat(e)&&_("Color: Alpha component of "+t+" will be ignored.")
        }
      if(i=/^(\w+)\(([^\)]*)\)/.exec(t)){
        let r,n=i[1],a=i[2];
        switch(n){case"rgb":case"rgba":
        if(r=/^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))
        return s(r[4]),this.setRGB(Math.min(255,parseInt(r[1],10))/255,Math.min(255,parseInt(r[2],10))/255,Math.min(255,parseInt(r[3],10))/255,e);
        if(r=/^\s*(\d+)\%\s*,\s*(\d+)\%\s*,\s*(\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))
        return s(r[4]),this.setRGB(Math.min(100,parseInt(r[1],10))/100,Math.min(100,parseInt(r[2],10))/100,Math.min(100,parseInt(r[3],10))/100,e);
        break;
        case"hsl":case"hsla":
        if(r=/^\s*(\d*\.?\d+)\s*,\s*(\d*\.?\d+)\%\s*,\s*(\d*\.?\d+)\%\s*(?:,\s*(\d*\.?\d+)\s*)?$/.exec(a))
        return s(r[4]),this.setHSL(parseFloat(r[1])/360,parseFloat(r[2])/100,parseFloat(r[3])/100,e);
        break;
        default:
        _("Color: Unknown color model "+t)
        }
        }else 
      if(i=/^\#([A-Fa-f\d]+)$/.exec(t)){
        let s=i[1],r=s.length;
        if(3===r)
        return this.setRGB(parseInt(s.charAt(0),16)/15,parseInt(s.charAt(1),16)/15,parseInt(s.charAt(2),16)/15,e);
        if(6===r)
        return this.setHex(parseInt(s,16),e);
        _("Color: Invalid hex color "+t)
        }else 
      if(t&&t.length>0)
      return this.setColorName(t,e);
      return this
      }setColorName(t,e=p){
      let i=tE[t.toLowerCase()];
      return void 0!==i?this.setHex(i,e):_("Color: Unknown color "+t),this
      }clone(){
      return new this.constructor(this.r,this.g,this.b)
      }copy(t){
      return this.r=t.r,this.g=t.g,this.b=t.b,this
      }copySRGBToLinear(t){
      return this.r=X(t.r),this.g=X(t.g),this.b=X(t.b),this
      }copyLinearToSRGB(t){
      return this.r=Y(t.r),this.g=Y(t.g),this.b=Y(t.b),this
      }convertSRGBToLinear(){
      return this.copySRGBToLinear(this),this
      }convertLinearToSRGB(){
      return this.copyLinearToSRGB(this),this
      }getHex(t=p){
      return H.workingToColorSpace(tW.copy(this),t),65536*Math.round(R(255*tW.r,0,255))+256*Math.round(R(255*tW.g,0,255))+Math.round(R(255*tW.b,0,255))
      }getHexString(t=p){
      return("000000"+this.getHex(t).toString(16)).slice(-6)
      }getHSL(t,e=H.workingColorSpace){
      let i,s;
      H.workingToColorSpace(tW.copy(this),e);
      let r=tW.r,n=tW.g,a=tW.b,o=Math.max(r,n,a),h=Math.min(r,n,a),l=(h+o)/2;
      if(h===o)
      i=0,s=0;
      else{
        let t=o-h;
        switch(s=l<=.5?t/(o+h):t/(2-o-h),o){case r:
        i=(n-a)/t+6*(n<a);
        break;
        case n:
        i=(a-r)/t+2;
        break;
        case a:
        i=(r-n)/t+4
        }
        i/=6
        }
      return t.h=i,t.s=s,t.l=l,t
      }getRGB(t,e=H.workingColorSpace){
      return H.workingToColorSpace(tW.copy(this),e),t.r=tW.r,t.g=tW.g,t.b=tW.b,t
      }getStyle(t=p){
      H.workingToColorSpace(tW.copy(this),t);
      let e=tW.r,i=tW.g,s=tW.b;
      return t!==p?`color(${t} ${e.toFixed(3)} ${i.toFixed(3)} ${s.toFixed(3)})`:`rgb(${Math.round(255*e)},${Math.round(255*i)},${Math.round(255*s)})`
      }offsetHSL(t,e,i){
      return this.getHSL(tV),this.setHSL(tV.h+t,tV.s+e,tV.l+i)
      }add(t){
      return this.r+=t.r,this.g+=t.g,this.b+=t.b,this
      }addColors(t,e){
      return this.r=t.r+e.r,this.g=t.g+e.g,this.b=t.b+e.b,this
      }addScalar(t){
      return this.r+=t,this.g+=t,this.b+=t,this
      }sub(t){
      return this.r=Math.max(0,this.r-t.r),this.g=Math.max(0,this.g-t.g),this.b=Math.max(0,this.b-t.b),this
      }multiply(t){
      return this.r*=t.r,this.g*=t.g,this.b*=t.b,this
      }multiplyScalar(t){
      return this.r*=t,this.g*=t,this.b*=t,this
      }lerp(t,e){
      return this.r+=(t.r-this.r)*e,this.g+=(t.g-this.g)*e,this.b+=(t.b-this.b)*e,this
      }lerpColors(t,e,i){
      return this.r=t.r+(e.r-t.r)*i,this.g=t.g+(e.g-t.g)*i,this.b=t.b+(e.b-t.b)*i,this
      }lerpHSL(t,e){
      this.getHSL(tV),t.getHSL(tD);
      let i=F(tV.h,tD.h,e),s=F(tV.s,tD.s,e),r=F(tV.l,tD.l,e);
      return this.setHSL(i,s,r),this
      }setFromVector3(t){
      return this.r=t.x,this.g=t.y,this.b=t.z,this
      }applyMatrix3(t){
      let e=this.r,i=this.g,s=this.b,r=t.elements;
      return this.r=r[0]*e+r[3]*i+r[6]*s,this.g=r[1]*e+r[4]*i+r[7]*s,this.b=r[2]*e+r[5]*i+r[8]*s,this
      }equals(t){
      return t.r===this.r&&t.g===this.g&&t.b===this.b
      }fromArray(t,e=0){
      return this.r=t[e],this.g=t[e+1],this.b=t[e+2],this
      }toArray(t=[],e=0){
      return t[e]=this.r,t[e+1]=this.g,t[e+2]=this.b,t
      }fromBufferAttribute(t,e){
      return this.r=t.getX(e),this.g=t.getY(e),this.b=t.getZ(e),this
      }toJSON(){
      return this.getHex()
      }*[Symbol.iterator](){
      yield this.r,yield this.g,yield this.b
      }
  }
  let tW=new tj;
  tj.NAMES=tE;
  class tG{
    constructor(t,e=25e-5){
      this.isFogExp2=!0,this.name="",this.color=new tj(t),this.density=e
      }clone(){
      return new tG(this.color,this.density)
      }toJSON(){
      return{type:"FogExp2",name:this.name,color:this.color.getHex(),density:this.density}
      }
  }
  class tq{
    constructor(t,e=1,i=1e3){
      this.isFog=!0,this.name="",this.color=new tj(t),this.near=e,this.far=i
      }clone(){
      return new tq(this.color,this.near,this.far)
      }toJSON(){
      return{type:"Fog",name:this.name,color:this.color.getHex(),near:this.near,far:this.far}
      }
  }
  class tJ extends tF{
    constructor(){
      super(),this.isScene=!0,this.type="Scene",this.background=null,this.environment=null,this.fog=null,this.backgroundBlurriness=0,this.backgroundIntensity=1,this.backgroundRotation=new tx,this.environmentIntensity=1,this.environmentRotation=new tx,this.overrideMaterial=null,"u">typeof __THREE_DEVTOOLS__&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))
      }copy(t,e){
      return super.copy(t,e),null!==t.background&&(this.background=t.background.clone()),null!==t.environment&&(this.environment=t.environment.clone()),null!==t.fog&&(this.fog=t.fog.clone()),this.backgroundBlurriness=t.backgroundBlurriness,this.backgroundIntensity=t.backgroundIntensity,this.backgroundRotation.copy(t.backgroundRotation),this.environmentIntensity=t.environmentIntensity,this.environmentRotation.copy(t.environmentRotation),null!==t.overrideMaterial&&(this.overrideMaterial=t.overrideMaterial.clone()),this.matrixAutoUpdate=t.matrixAutoUpdate,this
      }toJSON(t){
      let e=super.toJSON(t);
      return null!==this.fog&&(e.object.fog=this.fog.toJSON()),this.backgroundBlurriness>0&&(e.object.backgroundBlurriness=this.backgroundBlurriness),1!==this.backgroundIntensity&&(e.object.backgroundIntensity=this.backgroundIntensity),e.object.backgroundRotation=this.backgroundRotation.toArray(),1!==this.environmentIntensity&&(e.object.environmentIntensity=this.environmentIntensity),e.object.environmentRotation=this.environmentRotation.toArray(),e
      }
  }
  let tH=new D,tX=new D,tY=new D,tZ=new D,t$=new D,tQ=new D,tK=new D,t0=new D,t1=new D,t2=new D,t3=new ts,t5=new ts,t4=new ts;
  class t6{
    constructor(t=new D,e=new D,i=new D){
      this.a=t,this.b=e,this.c=i
      }static getNormal(t,e,i,s){
      s.subVectors(i,e),tH.subVectors(t,e),s.cross(tH);
      let r=s.lengthSq();
      return r>0?s.multiplyScalar(1/Math.sqrt(r)):s.set(0,0,0)
      }static getBarycoord(t,e,i,s,r){
      tH.subVectors(s,e),tX.subVectors(i,e),tY.subVectors(t,e);
      let n=tH.dot(tH),a=tH.dot(tX),o=tH.dot(tY),h=tX.dot(tX),l=tX.dot(tY),u=n*h-a*a;
      if(0===u)
      return r.set(0,0,0),null;
      let c=1/u,p=(h*o-a*l)*c,d=(n*l-a*o)*c;
      return r.set(1-p-d,d,p)
      }static containsPoint(t,e,i,s){
      return null!==this.getBarycoord(t,e,i,s,tZ)&&tZ.x>=0&&tZ.y>=0&&tZ.x+tZ.y<=1
      }static getInterpolation(t,e,i,s,r,n,a,o){
      return null===this.getBarycoord(t,e,i,s,tZ)?(o.x=0,o.y=0,"z"in o&&(o.z=0),"w"in o&&(o.w=0),null):(o.setScalar(0),o.addScaledVector(r,tZ.x),o.addScaledVector(n,tZ.y),o.addScaledVector(a,tZ.z),o)
      }static getInterpolatedAttribute(t,e,i,s,r,n){
      return t3.setScalar(0),t5.setScalar(0),t4.setScalar(0),t3.fromBufferAttribute(t,e),t5.fromBufferAttribute(t,i),t4.fromBufferAttribute(t,s),n.setScalar(0),n.addScaledVector(t3,r.x),n.addScaledVector(t5,r.y),n.addScaledVector(t4,r.z),n
      }static isFrontFacing(t,e,i,s){
      return tH.subVectors(i,e),tX.subVectors(t,e),0>tH.cross(tX).dot(s)
      }set(t,e,i){
      return this.a.copy(t),this.b.copy(e),this.c.copy(i),this
      }setFromPointsAndIndices(t,e,i,s){
      return this.a.copy(t[e]),this.b.copy(t[i]),this.c.copy(t[s]),this
      }setFromAttributeAndIndices(t,e,i,s){
      return this.a.fromBufferAttribute(t,e),this.b.fromBufferAttribute(t,i),this.c.fromBufferAttribute(t,s),this
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      return this.a.copy(t.a),this.b.copy(t.b),this.c.copy(t.c),this
      }getArea(){
      return tH.subVectors(this.c,this.b),tX.subVectors(this.a,this.b),.5*tH.cross(tX).length()
      }getMidpoint(t){
      return t.addVectors(this.a,this.b).add(this.c).multiplyScalar(1/3)
      }getNormal(t){
      return t6.getNormal(this.a,this.b,this.c,t)
      }getPlane(t){
      return t.setFromCoplanarPoints(this.a,this.b,this.c)
      }getBarycoord(t,e){
      return t6.getBarycoord(t,this.a,this.b,this.c,e)
      }getInterpolation(t,e,i,s,r){
      return t6.getInterpolation(t,this.a,this.b,this.c,e,i,s,r)
      }containsPoint(t){
      return t6.containsPoint(t,this.a,this.b,this.c)
      }isFrontFacing(t){
      return t6.isFrontFacing(this.a,this.b,this.c,t)
      }intersectsBox(t){
      return t.intersectsTriangle(this)
      }closestPointToPoint(t,e){
      let i,s,r=this.a,n=this.b,a=this.c;
      t$.subVectors(n,r),tQ.subVectors(a,r),t0.subVectors(t,r);
      let o=t$.dot(t0),h=tQ.dot(t0);
      if(o<=0&&h<=0)
      return e.copy(r);
      t1.subVectors(t,n);
      let l=t$.dot(t1),u=tQ.dot(t1);
      if(l>=0&&u<=l)
      return e.copy(n);
      let c=o*u-l*h;
      if(c<=0&&o>=0&&l<=0)
      return i=o/(o-l),e.copy(r).addScaledVector(t$,i);
      t2.subVectors(t,a);
      let p=t$.dot(t2),d=tQ.dot(t2);
      if(d>=0&&p<=d)
      return e.copy(a);
      let m=p*h-o*d;
      if(m<=0&&h>=0&&d<=0)
      return s=h/(h-d),e.copy(r).addScaledVector(tQ,s);
      let y=l*d-p*u;
      if(y<=0&&u-l>=0&&p-d>=0)
      return tK.subVectors(a,n),s=(u-l)/(u-l+(p-d)),e.copy(n).addScaledVector(tK,s);
      let f=1/(y+m+c);
      return i=m*f,s=c*f,e.copy(r).addScaledVector(t$,i).addScaledVector(tQ,s)
      }equals(t){
      return t.a.equals(this.a)&&t.b.equals(this.b)&&t.c.equals(this.c)
      }
  }
  class t8{
    constructor(t=new D(Infinity,Infinity,Infinity),e=new D(-1/0,-1/0,-1/0)){
      this.isBox3=!0,this.min=t,this.max=e
      }set(t,e){
      return this.min.copy(t),this.max.copy(e),this
      }setFromArray(t){
      this.makeEmpty();
      for(
      let e=0,i=t.length
      ;e<i;e+=3)
      this.expandByPoint(t7.fromArray(t,e));
      return this
      }setFromBufferAttribute(t){
      this.makeEmpty();
      for(
      let e=0,i=t.count
      ;e<i;e++)
      this.expandByPoint(t7.fromBufferAttribute(t,e));
      return this
      }setFromPoints(t){
      this.makeEmpty();
      for(
      let e=0,i=t.length
      ;e<i;e++)
      this.expandByPoint(t[e]);
      return this
      }setFromCenterAndSize(t,e){
      let i=t7.copy(e).multiplyScalar(.5);
      return this.min.copy(t).sub(i),this.max.copy(t).add(i),this
      }setFromObject(t,e=!1){
      return this.makeEmpty(),this.expandByObject(t,e)
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      return this.min.copy(t.min),this.max.copy(t.max),this
      }makeEmpty(){
      return this.min.x=this.min.y=this.min.z=Infinity,this.max.x=this.max.y=this.max.z=-1/0,this
      }isEmpty(){
      return this.max.x<this.min.x||this.max.y<this.min.y||this.max.z<this.min.z
      }getCenter(t){
      return this.isEmpty()?t.set(0,0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)
      }getSize(t){
      return this.isEmpty()?t.set(0,0,0):t.subVectors(this.max,this.min)
      }expandByPoint(t){
      return this.min.min(t),this.max.max(t),this
      }expandByVector(t){
      return this.min.sub(t),this.max.add(t),this
      }expandByScalar(t){
      return this.min.addScalar(-t),this.max.addScalar(t),this
      }expandByObject(t,e=!1){
      t.updateWorldMatrix(!1,!1);
      let i=t.geometry;
      if(void 0!==i){
        let s=i.getAttribute("position");
        if(!0===e&&void 0!==s&&!0!==t.isInstancedMesh)
        for(
        let e=0,i=s.count
        ;e<i;e++)
        !0===t.isMesh?t.getVertexPosition(e,t7):t7.fromBufferAttribute(s,e),t7.applyMatrix4(t.matrixWorld),this.expandByPoint(t7);
        else 
        void 0!==t.boundingBox?(null===t.boundingBox&&t.computeBoundingBox(),et.copy(t.boundingBox)):(null===i.boundingBox&&i.computeBoundingBox(),et.copy(i.boundingBox)),et.applyMatrix4(t.matrixWorld),this.union(et)
        }
      let s=t.children;
      for(
      let t=0,i=s.length
      ;t<i;t++)
      this.expandByObject(s[t],e);
      return this
      }containsPoint(t){
      return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y&&t.z>=this.min.z&&t.z<=this.max.z
      }containsBox(t){
      return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y&&this.min.z<=t.min.z&&t.max.z<=this.max.z
      }getParameter(t,e){
      return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y),(t.z-this.min.z)/(this.max.z-this.min.z))
      }intersectsBox(t){
      return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y&&t.max.z>=this.min.z&&t.min.z<=this.max.z
      }intersectsSphere(t){
      return this.clampPoint(t.center,t7),t7.distanceToSquared(t.center)<=t.radius*t.radius
      }intersectsPlane(t){
      let e,i;
      return t.normal.x>0?(e=t.normal.x*this.min.x,i=t.normal.x*this.max.x):(e=t.normal.x*this.max.x,i=t.normal.x*this.min.x),t.normal.y>0?(e+=t.normal.y*this.min.y,i+=t.normal.y*this.max.y):(e+=t.normal.y*this.max.y,i+=t.normal.y*this.min.y),t.normal.z>0?(e+=t.normal.z*this.min.z,i+=t.normal.z*this.max.z):(e+=t.normal.z*this.max.z,i+=t.normal.z*this.min.z),e<=-t.constant&&i>=-t.constant
      }intersectsTriangle(t){
      if(this.isEmpty())
      return!1;
      this.getCenter(eo),eh.subVectors(this.max,eo),ee.subVectors(t.a,eo),ei.subVectors(t.b,eo),es.subVectors(t.c,eo),er.subVectors(ei,ee),en.subVectors(es,ei),ea.subVectors(ee,es);
      let e=[0,-er.z,er.y,0,-en.z,en.y,0,-ea.z,ea.y,er.z,0,-er.x,en.z,0,-en.x,ea.z,0,-ea.x,-er.y,er.x,0,-en.y,en.x,0,-ea.y,ea.x,0];
      return!!ec(e,ee,ei,es,eh)&&!!ec(e=[1,0,0,0,1,0,0,0,1],ee,ei,es,eh)&&(el.crossVectors(er,en),ec(e=[el.x,el.y,el.z],ee,ei,es,eh))
      }clampPoint(t,e){
      return e.copy(t).clamp(this.min,this.max)
      }distanceToPoint(t){
      return this.clampPoint(t,t7).distanceTo(t)
      }getBoundingSphere(t){
      return this.isEmpty()?t.makeEmpty():(this.getCenter(t.center),t.radius=.5*this.getSize(t7).length()),t
      }intersect(t){
      return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this
      }union(t){
      return this.min.min(t.min),this.max.max(t.max),this
      }applyMatrix4(t){
      return this.isEmpty()||(t9[0].set(this.min.x,this.min.y,this.min.z).applyMatrix4(t),t9[1].set(this.min.x,this.min.y,this.max.z).applyMatrix4(t),t9[2].set(this.min.x,this.max.y,this.min.z).applyMatrix4(t),t9[3].set(this.min.x,this.max.y,this.max.z).applyMatrix4(t),t9[4].set(this.max.x,this.min.y,this.min.z).applyMatrix4(t),t9[5].set(this.max.x,this.min.y,this.max.z).applyMatrix4(t),t9[6].set(this.max.x,this.max.y,this.min.z).applyMatrix4(t),t9[7].set(this.max.x,this.max.y,this.max.z).applyMatrix4(t),this.setFromPoints(t9)),this
      }translate(t){
      return this.min.add(t),this.max.add(t),this
      }equals(t){
      return t.min.equals(this.min)&&t.max.equals(this.max)
      }toJSON(){
      return{min:this.min.toArray(),max:this.max.toArray()}
      }fromJSON(t){
      return this.min.fromArray(t.min),this.max.fromArray(t.max),this
      }
  }
  let t9=[new D,new D,new D,new D,new D,new D,new D,new D],t7=new D,et=new t8,ee=new D,ei=new D,es=new D,er=new D,en=new D,ea=new D,eo=new D,eh=new D,el=new D,eu=new D;
  function ec(t,e,i,s,r){
    for(
    let n=0,a=t.length-3
    ;n<=a;n+=3){
      eu.fromArray(t,n);
      let a=r.x*Math.abs(eu.x)+r.y*Math.abs(eu.y)+r.z*Math.abs(eu.z),o=e.dot(eu),h=i.dot(eu),l=s.dot(eu);
      if(Math.max(-Math.max(o,h,l),Math.min(o,h,l))>a)
      return!1
      }
    return!0
    }
  let ep=function(){
    let t=new ArrayBuffer(4),e=new Float32Array(t),i=new Uint32Array(t),s=new Uint32Array(512),r=new Uint32Array(512);
    for(
    let t=0
    ;t<256;++t){
      let e=t-127;
      e<-27?(s[t]=0,s[256|t]=32768,r[t]=24,r[256|t]=24):e<-14?(s[t]=1024>>-e-14,s[256|t]=1024>>-e-14|32768,r[t]=-e-1,r[256|t]=-e-1):e<=15?(s[t]=e+15<<10,s[256|t]=e+15<<10|32768,r[t]=13,r[256|t]=13):e<128?(s[t]=31744,s[256|t]=64512,r[t]=24,r[256|t]=24):(s[t]=31744,s[256|t]=64512,r[t]=13,r[256|t]=13)
      }
    let n=new Uint32Array(2048),a=new Uint32Array(64),o=new Uint32Array(64);
    for(
    let t=1
    ;t<1024;++t){
      let e=t<<13,i=0;
      for(;(8388608&e)==0;)
      e<<=1,i-=8388608;
      e&=-8388609,i+=0x38800000,n[t]=e|i
      }
    for(
    let t=1024
    ;t<2048;++t)
    n[t]=0x38000000+(t-1024<<13);
    for(
    let t=1
    ;t<31;++t)
    a[t]=t<<23;
    a[31]=0x47800000,a[32]=0x80000000;
    for(
    let t=33
    ;t<63;++t)
    a[t]=0x80000000+(t-32<<23);
    a[63]=0xc7800000;
    for(
    let t=1
    ;t<64;++t)
    32!==t&&(o[t]=1024);
    return{floatView:e,uint32View:i,baseTable:s,shiftTable:r,mantissaTable:n,exponentTable:a,offsetTable:o}
    }();
  function ed(t){
    Math.abs(t)>65504&&_("DataUtils.toHalfFloat(): Value out of range."),t=R(t,-65504,65504),ep.floatView[0]=t;
    let e=ep.uint32View[0],i=e>>23&511;
    return ep.baseTable[i]+((8388607&e)>>ep.shiftTable[i])
    }
  function em(t){
    let e=t>>10;
    return ep.uint32View[0]=ep.mantissaTable[ep.offsetTable[e]+(1023&t)]+ep.exponentTable[e],ep.floatView[0]
    }
  let ey=new D,ef=new E,eg=0;
  class ex extends C{
    constructor(t,e,i=!1){
      if(super(),Array.isArray(t))
      throw TypeError("THREE.BufferAttribute: array should be a Typed Array.");
      this.isBufferAttribute=!0,Object.defineProperty(this,"id",{value:eg++}),this.name="",this.array=t,this.itemSize=e,this.count=void 0!==t?t.length/e:0,this.normalized=i,this.usage=35044,this.updateRanges=[],this.gpuType=1015,this.version=0
      }onUploadCallback(){
      }set needsUpdate(t){
      !0===t&&this.version++
      }setUsage(t){
      return this.usage=t,this
      }addUpdateRange(t,e){
      this.updateRanges.push({start:t,count:e})
      }clearUpdateRanges(){
      this.updateRanges.length=0
      }copy(t){
      return this.name=t.name,this.array=new t.array.constructor(t.array),this.itemSize=t.itemSize,this.count=t.count,this.normalized=t.normalized,this.usage=t.usage,this.gpuType=t.gpuType,this
      }copyAt(t,e,i){
      t*=this.itemSize,i*=e.itemSize;
      for(
      let s=0,r=this.itemSize
      ;s<r;s++)
      this.array[t+s]=e.array[i+s];
      return this
      }copyArray(t){
      return this.array.set(t),this
      }applyMatrix3(t){
      if(2===this.itemSize)
      for(
      let e=0,i=this.count
      ;e<i;e++)
      ef.fromBufferAttribute(this,e),ef.applyMatrix3(t),this.setXY(e,ef.x,ef.y);
      else 
      if(3===this.itemSize)
      for(
      let e=0,i=this.count
      ;e<i;e++)
      ey.fromBufferAttribute(this,e),ey.applyMatrix3(t),this.setXYZ(e,ey.x,ey.y,ey.z);
      return this
      }applyMatrix4(t){
      for(
      let e=0,i=this.count
      ;e<i;e++)
      ey.fromBufferAttribute(this,e),ey.applyMatrix4(t),this.setXYZ(e,ey.x,ey.y,ey.z);
      return this
      }applyNormalMatrix(t){
      for(
      let e=0,i=this.count
      ;e<i;e++)
      ey.fromBufferAttribute(this,e),ey.applyNormalMatrix(t),this.setXYZ(e,ey.x,ey.y,ey.z);
      return this
      }transformDirection(t){
      for(
      let e=0,i=this.count
      ;e<i;e++)
      ey.fromBufferAttribute(this,e),ey.transformDirection(t),this.setXYZ(e,ey.x,ey.y,ey.z);
      return this
      }set(t,e=0){
      return this.array.set(t,e),this
      }getComponent(t,e){
      let i=this.array[t*this.itemSize+e];
      return this.normalized&&(i=L(i,this.array)),i
      }setComponent(t,e,i){
      return this.normalized&&(i=N(i,this.array)),this.array[t*this.itemSize+e]=i,this
      }getX(t){
      let e=this.array[t*this.itemSize];
      return this.normalized&&(e=L(e,this.array)),e
      }setX(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize]=e,this
      }getY(t){
      let e=this.array[t*this.itemSize+1];
      return this.normalized&&(e=L(e,this.array)),e
      }setY(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize+1]=e,this
      }getZ(t){
      let e=this.array[t*this.itemSize+2];
      return this.normalized&&(e=L(e,this.array)),e
      }setZ(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize+2]=e,this
      }getW(t){
      let e=this.array[t*this.itemSize+3];
      return this.normalized&&(e=L(e,this.array)),e
      }setW(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize+3]=e,this
      }setXY(t,e,i){
      return t*=this.itemSize,this.normalized&&(e=N(e,this.array),i=N(i,this.array)),this.array[t+0]=e,this.array[t+1]=i,this
      }setXYZ(t,e,i,s){
      return t*=this.itemSize,this.normalized&&(e=N(e,this.array),i=N(i,this.array),s=N(s,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this
      }setXYZW(t,e,i,s,r){
      return t*=this.itemSize,this.normalized&&(e=N(e,this.array),i=N(i,this.array),s=N(s,this.array),r=N(r,this.array)),this.array[t+0]=e,this.array[t+1]=i,this.array[t+2]=s,this.array[t+3]=r,this
      }onUpload(t){
      return this.onUploadCallback=t,this
      }clone(){
      return new this.constructor(this.array,this.itemSize).copy(this)
      }toJSON(){
      let t={itemSize:this.itemSize,type:this.array.constructor.name,array:Array.from(this.array),normalized:this.normalized};
      return""!==this.name&&(t.name=this.name),35044!==this.usage&&(t.usage=this.usage),t
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }
  }
  class eb extends ex{
    constructor(t,e,i){
      super(new Uint16Array(t),e,i)
      }
  }
  class ev extends ex{
    constructor(t,e,i){
      super(new Uint32Array(t),e,i)
      }
  }
  class eM extends ex{
    constructor(t,e,i){
      super(new Float32Array(t),e,i)
      }
  }
  let ew=new t8,eS=new D,e_=new D;
  class eA{
    constructor(t=new D,e=-1){
      this.isSphere=!0,this.center=t,this.radius=e
      }set(t,e){
      return this.center.copy(t),this.radius=e,this
      }setFromPoints(t,e){
      let i=this.center;
      void 0!==e?i.copy(e):ew.setFromPoints(t).getCenter(i);
      let s=0;
      for(
      let e=0,r=t.length
      ;e<r;e++)
      s=Math.max(s,i.distanceToSquared(t[e]));
      return this.radius=Math.sqrt(s),this
      }copy(t){
      return this.center.copy(t.center),this.radius=t.radius,this
      }isEmpty(){
      return this.radius<0
      }makeEmpty(){
      return this.center.set(0,0,0),this.radius=-1,this
      }containsPoint(t){
      return t.distanceToSquared(this.center)<=this.radius*this.radius
      }distanceToPoint(t){
      return t.distanceTo(this.center)-this.radius
      }intersectsSphere(t){
      let e=this.radius+t.radius;
      return t.center.distanceToSquared(this.center)<=e*e
      }intersectsBox(t){
      return t.intersectsSphere(this)
      }intersectsPlane(t){
      return Math.abs(t.distanceToPoint(this.center))<=this.radius
      }clampPoint(t,e){
      let i=this.center.distanceToSquared(t);
      return e.copy(t),i>this.radius*this.radius&&(e.sub(this.center).normalize(),e.multiplyScalar(this.radius).add(this.center)),e
      }getBoundingBox(t){
      return this.isEmpty()?t.makeEmpty():(t.set(this.center,this.center),t.expandByScalar(this.radius)),t
      }applyMatrix4(t){
      return this.center.applyMatrix4(t),this.radius=this.radius*t.getMaxScaleOnAxis(),this
      }translate(t){
      return this.center.add(t),this
      }expandByPoint(t){
      if(this.isEmpty())
      return this.center.copy(t),this.radius=0,this;
      eS.subVectors(t,this.center);
      let e=eS.lengthSq();
      if(e>this.radius*this.radius){
        let t=Math.sqrt(e),i=(t-this.radius)*.5;
        this.center.addScaledVector(eS,i/t),this.radius+=i
        }
      return this
      }union(t){
      return t.isEmpty()||(this.isEmpty()?this.copy(t):!0===this.center.equals(t.center)?this.radius=Math.max(this.radius,t.radius):(e_.subVectors(t.center,this.center).setLength(t.radius),this.expandByPoint(eS.copy(t.center).add(e_)),this.expandByPoint(eS.copy(t.center).sub(e_)))),this
      }equals(t){
      return t.center.equals(this.center)&&t.radius===this.radius
      }clone(){
      return new this.constructor().copy(this)
      }toJSON(){
      return{radius:this.radius,center:this.center.toArray()}
      }fromJSON(t){
      return this.radius=t.radius,this.center.fromArray(t.center),this
      }
  }
  let eT=0,eC=new th,eI=new tF,ez=new D,eB=new t8,ek=new t8,eO=new D;
  class eR extends C{
    constructor(){
      super(),this.isBufferGeometry=!0,Object.defineProperty(this,"id",{value:eT++}),this.uuid=O(),this.name="",this.type="BufferGeometry",this.index=null,this.indirect=null,this.indirectOffset=0,this.attributes={},this.morphAttributes={},this.morphTargetsRelative=!1,this.groups=[],this.boundingBox=null,this.boundingSphere=null,this.drawRange={start:0,count:1/0},this.userData={}
      }getIndex(){
      return this.index
      }setIndex(t){
      return Array.isArray(t)?this.index=new(!function(t){
        for(
        let e=t.length-1
        ;e>=0;--e)
        if(t[e]>=65535)
        return!0;
        return!1
        }(t)?eb:ev)(t,1):this.index=t,this
      }setIndirect(t,e=0){
      return this.indirect=t,this.indirectOffset=e,this
      }getIndirect(){
      return this.indirect
      }getAttribute(t){
      return this.attributes[t]
      }setAttribute(t,e){
      return this.attributes[t]=e,this
      }deleteAttribute(t){
      return delete this.attributes[t],this
      }hasAttribute(t){
      return void 0!==this.attributes[t]
      }addGroup(t,e,i=0){
      this.groups.push({start:t,count:e,materialIndex:i})
      }clearGroups(){
      this.groups=[]
      }setDrawRange(t,e){
      this.drawRange.start=t,this.drawRange.count=e
      }applyMatrix4(t){
      let e=this.attributes.position;
      void 0!==e&&(e.applyMatrix4(t),e.needsUpdate=!0);
      let i=this.attributes.normal;
      if(void 0!==i){
        let e=new W().getNormalMatrix(t);
        i.applyNormalMatrix(e),i.needsUpdate=!0
        }
      let s=this.attributes.tangent;
      return void 0!==s&&(s.transformDirection(t),s.needsUpdate=!0),null!==this.boundingBox&&this.computeBoundingBox(),null!==this.boundingSphere&&this.computeBoundingSphere(),this
      }applyQuaternion(t){
      return eC.makeRotationFromQuaternion(t),this.applyMatrix4(eC),this
      }rotateX(t){
      return eC.makeRotationX(t),this.applyMatrix4(eC),this
      }rotateY(t){
      return eC.makeRotationY(t),this.applyMatrix4(eC),this
      }rotateZ(t){
      return eC.makeRotationZ(t),this.applyMatrix4(eC),this
      }translate(t,e,i){
      return eC.makeTranslation(t,e,i),this.applyMatrix4(eC),this
      }scale(t,e,i){
      return eC.makeScale(t,e,i),this.applyMatrix4(eC),this
      }lookAt(t){
      return eI.lookAt(t),eI.updateMatrix(),this.applyMatrix4(eI.matrix),this
      }center(){
      return this.computeBoundingBox(),this.boundingBox.getCenter(ez).negate(),this.translate(ez.x,ez.y,ez.z),this
      }setFromPoints(t){
      let e=this.getAttribute("position");
      if(void 0===e){
        let e=[];
        for(
        let i=0,s=t.length
        ;i<s;i++){
          let s=t[i];
          e.push(s.x,s.y,s.z||0)
          }
        this.setAttribute("position",new eM(e,3))
        }else{
        let i=Math.min(t.length,e.count);
        for(
        let s=0
        ;s<i;s++){
          let i=t[s];
          e.setXYZ(s,i.x,i.y,i.z||0)
          }
        t.length>e.count&&_("BufferGeometry: Buffer size too small for points data. Use .dispose() and create a new geometry."),e.needsUpdate=!0
        }
      return this
      }computeBoundingBox(){
      null===this.boundingBox&&(this.boundingBox=new t8);
      let t=this.attributes.position,e=this.morphAttributes.position;
      if(t&&t.isGLBufferAttribute){
        A("BufferGeometry.computeBoundingBox(): GLBufferAttribute requires a manual bounding box.",this),this.boundingBox.set(new D(-1/0,-1/0,-1/0),new D(Infinity,Infinity,Infinity));
        return
        }
      if(void 0!==t){
        if(this.boundingBox.setFromBufferAttribute(t),e)
        for(
        let t=0,i=e.length
        ;t<i;t++){
          let i=e[t];
          eB.setFromBufferAttribute(i),this.morphTargetsRelative?(eO.addVectors(this.boundingBox.min,eB.min),this.boundingBox.expandByPoint(eO),eO.addVectors(this.boundingBox.max,eB.max),this.boundingBox.expandByPoint(eO)):(this.boundingBox.expandByPoint(eB.min),this.boundingBox.expandByPoint(eB.max))
          }
        }else 
      this.boundingBox.makeEmpty();
      (isNaN(this.boundingBox.min.x)||isNaN(this.boundingBox.min.y)||isNaN(this.boundingBox.min.z))&&A('BufferGeometry.computeBoundingBox(): Computed min/max have NaN values. The "position" attribute is likely to have NaN values.',this)
      }computeBoundingSphere(){
      null===this.boundingSphere&&(this.boundingSphere=new eA);
      let t=this.attributes.position,e=this.morphAttributes.position;
      if(t&&t.isGLBufferAttribute){
        A("BufferGeometry.computeBoundingSphere(): GLBufferAttribute requires a manual bounding sphere.",this),this.boundingSphere.set(new D,1/0);
        return
        }
      if(t){
        let i=this.boundingSphere.center;
        if(eB.setFromBufferAttribute(t),e)
        for(
        let t=0,i=e.length
        ;t<i;t++){
          let i=e[t];
          ek.setFromBufferAttribute(i),this.morphTargetsRelative?(eO.addVectors(eB.min,ek.min),eB.expandByPoint(eO),eO.addVectors(eB.max,ek.max),eB.expandByPoint(eO)):(eB.expandByPoint(ek.min),eB.expandByPoint(ek.max))
          }
        eB.getCenter(i);
        let s=0;
        for(
        let e=0,r=t.count
        ;e<r;e++)
        eO.fromBufferAttribute(t,e),s=Math.max(s,i.distanceToSquared(eO));
        if(e)
        for(
        let r=0,n=e.length
        ;r<n;r++){
          let n=e[r],a=this.morphTargetsRelative;
          for(
          let e=0,r=n.count
          ;e<r;e++)
          eO.fromBufferAttribute(n,e),a&&(ez.fromBufferAttribute(t,e),eO.add(ez)),s=Math.max(s,i.distanceToSquared(eO))
          }
        this.boundingSphere.radius=Math.sqrt(s),isNaN(this.boundingSphere.radius)&&A('BufferGeometry.computeBoundingSphere(): Computed radius is NaN. The "position" attribute is likely to have NaN values.',this)
        }
      }computeTangents(){
      let t=this.index,e=this.attributes;
      if(null===t||void 0===e.position||void 0===e.normal||void 0===e.uv)
      return void A("BufferGeometry: .computeTangents() failed. Missing required attributes (index, position, normal or uv)");
      let i=e.position,s=e.normal,r=e.uv;
      !1===this.hasAttribute("tangent")&&this.setAttribute("tangent",new ex(new Float32Array(4*i.count),4));
      let n=this.getAttribute("tangent"),a=[],o=[];
      for(
      let t=0
      ;t<i.count;t++)
      a[t]=new D,o[t]=new D;
      let h=new D,l=new D,u=new D,c=new E,p=new E,d=new E,m=new D,y=new D,f=this.groups;
      0===f.length&&(f=[{start:0,count:t.count}]);
      for(
      let e=0,s=f.length
      ;e<s;++e){
        let s=f[e],n=s.start,g=s.count;
        for(
        let e=n,s=n+g
        ;e<s;e+=3)
        !function(t,e,s){
          h.fromBufferAttribute(i,t),l.fromBufferAttribute(i,e),u.fromBufferAttribute(i,s),c.fromBufferAttribute(r,t),p.fromBufferAttribute(r,e),d.fromBufferAttribute(r,s),l.sub(h),u.sub(h),p.sub(c),d.sub(c);
          let n=1/(p.x*d.y-d.x*p.y);
          isFinite(n)&&(m.copy(l).multiplyScalar(d.y).addScaledVector(u,-p.y).multiplyScalar(n),y.copy(u).multiplyScalar(p.x).addScaledVector(l,-d.x).multiplyScalar(n),a[t].add(m),a[e].add(m),a[s].add(m),o[t].add(y),o[e].add(y),o[s].add(y))
          }(t.getX(e+0),t.getX(e+1),t.getX(e+2))
        }
      let g=new D,x=new D,b=new D,v=new D;
      function M(t){
        b.fromBufferAttribute(s,t),v.copy(b);
        let e=a[t];
        g.copy(e),g.sub(b.multiplyScalar(b.dot(e))).normalize(),x.crossVectors(v,e);
        let i=x.dot(o[t]);
        n.setXYZW(t,g.x,g.y,g.z,i<0?-1:1)
        }
      for(
      let e=0,i=f.length
      ;e<i;++e){
        let i=f[e],s=i.start,r=i.count;
        for(
        let e=s,i=s+r
        ;e<i;e+=3)
        M(t.getX(e+0)),M(t.getX(e+1)),M(t.getX(e+2))
        }
      }computeVertexNormals(){
      let t=this.index,e=this.getAttribute("position");
      if(void 0!==e){
        let i=this.getAttribute("normal");
        if(void 0===i)
        i=new ex(new Float32Array(3*e.count),3),this.setAttribute("normal",i);
        else 
        for(
        let t=0,e=i.count
        ;t<e;t++)
        i.setXYZ(t,0,0,0);
        let s=new D,r=new D,n=new D,a=new D,o=new D,h=new D,l=new D,u=new D;
        if(t)
        for(
        let c=0,p=t.count
        ;c<p;c+=3){
          let p=t.getX(c+0),d=t.getX(c+1),m=t.getX(c+2);
          s.fromBufferAttribute(e,p),r.fromBufferAttribute(e,d),n.fromBufferAttribute(e,m),l.subVectors(n,r),u.subVectors(s,r),l.cross(u),a.fromBufferAttribute(i,p),o.fromBufferAttribute(i,d),h.fromBufferAttribute(i,m),a.add(l),o.add(l),h.add(l),i.setXYZ(p,a.x,a.y,a.z),i.setXYZ(d,o.x,o.y,o.z),i.setXYZ(m,h.x,h.y,h.z)
          }
        else 
        for(
        let t=0,a=e.count
        ;t<a;t+=3)
        s.fromBufferAttribute(e,t+0),r.fromBufferAttribute(e,t+1),n.fromBufferAttribute(e,t+2),l.subVectors(n,r),u.subVectors(s,r),l.cross(u),i.setXYZ(t+0,l.x,l.y,l.z),i.setXYZ(t+1,l.x,l.y,l.z),i.setXYZ(t+2,l.x,l.y,l.z);
        this.normalizeNormals(),i.needsUpdate=!0
        }
      }normalizeNormals(){
      let t=this.attributes.normal;
      for(
      let e=0,i=t.count
      ;e<i;e++)
      eO.fromBufferAttribute(t,e),eO.normalize(),t.setXYZ(e,eO.x,eO.y,eO.z)
      }toNonIndexed(){
      function t(t,e){
        let i=t.array,s=t.itemSize,r=t.normalized,n=new i.constructor(e.length*s),a=0,o=0;
        for(
        let r=0,h=e.length
        ;r<h;r++){
          a=t.isInterleavedBufferAttribute?e[r]*t.data.stride+t.offset:e[r]*s;
          for(
          let t=0
          ;t<s;t++)
          n[o++]=i[a++]
          }
        return new ex(n,s,r)
        }
      if(null===this.index)
      return _("BufferGeometry.toNonIndexed(): BufferGeometry is already non-indexed."),this;
      let e=new eR,i=this.index.array,s=this.attributes;
      for(
      let r
       in s){
        let n=t(s[r],i);
        e.setAttribute(r,n)
        }
      let r=this.morphAttributes;
      for(
      let s
       in r){
        let n=[],a=r[s];
        for(
        let e=0,s=a.length
        ;e<s;e++){
          let s=t(a[e],i);
          n.push(s)
          }
        e.morphAttributes[s]=n
        }
      e.morphTargetsRelative=this.morphTargetsRelative;
      let n=this.groups;
      for(
      let t=0,i=n.length
      ;t<i;t++){
        let i=n[t];
        e.addGroup(i.start,i.count,i.materialIndex)
        }
      return e
      }toJSON(){
      let t={metadata:{version:4.7,type:"BufferGeometry",generator:"BufferGeometry.toJSON"}};
      if(t.uuid=this.uuid,t.type=this.type,""!==this.name&&(t.name=this.name),Object.keys(this.userData).length>0&&(t.userData=this.userData),void 0!==this.parameters){
        let e=this.parameters;
        for(
        let i
         in e)
        void 0!==e[i]&&(t[i]=e[i]);
        return t
        }
      t.data={attributes:{}};
      let e=this.index;
      null!==e&&(t.data.index={type:e.array.constructor.name,array:Array.prototype.slice.call(e.array)});
      let i=this.attributes;
      for(
      let e
       in i){
        let s=i[e];
        t.data.attributes[e]=s.toJSON(t.data)
        }
      let s={},r=!1;
      for(
      let e
       in this.morphAttributes){
        let i=this.morphAttributes[e],n=[];
        for(
        let e=0,s=i.length
        ;e<s;e++){
          let s=i[e];
          n.push(s.toJSON(t.data))
          }
        n.length>0&&(s[e]=n,r=!0)
        }
      r&&(t.data.morphAttributes=s,t.data.morphTargetsRelative=this.morphTargetsRelative);
      let n=this.groups;
      n.length>0&&(t.data.groups=JSON.parse(JSON.stringify(n)));
      let a=this.boundingSphere;
      return null!==a&&(t.data.boundingSphere=a.toJSON()),t
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      this.index=null,this.attributes={},this.morphAttributes={},this.groups=[],this.boundingBox=null,this.boundingSphere=null;
      let e={};
      this.name=t.name;
      let i=t.index;
      null!==i&&this.setIndex(i.clone());
      let s=t.attributes;
      for(
      let t
       in s){
        let i=s[t];
        this.setAttribute(t,i.clone(e))
        }
      let r=t.morphAttributes;
      for(
      let t
       in r){
        let i=[],s=r[t];
        for(
        let t=0,r=s.length
        ;t<r;t++)
        i.push(s[t].clone(e));
        this.morphAttributes[t]=i
        }
      this.morphTargetsRelative=t.morphTargetsRelative;
      let n=t.groups;
      for(
      let t=0,e=n.length
      ;t<e;t++){
        let e=n[t];
        this.addGroup(e.start,e.count,e.materialIndex)
        }
      let a=t.boundingBox;
      null!==a&&(this.boundingBox=a.clone());
      let o=t.boundingSphere;
      return null!==o&&(this.boundingSphere=o.clone()),this.drawRange.start=t.drawRange.start,this.drawRange.count=t.drawRange.count,this.userData=t.userData,this
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }
  }
  class eP{
    constructor(t,e){
      this.isInterleavedBuffer=!0,this.array=t,this.stride=e,this.count=void 0!==t?t.length/e:0,this.usage=35044,this.updateRanges=[],this.version=0,this.uuid=O()
      }onUploadCallback(){
      }set needsUpdate(t){
      !0===t&&this.version++
      }setUsage(t){
      return this.usage=t,this
      }addUpdateRange(t,e){
      this.updateRanges.push({start:t,count:e})
      }clearUpdateRanges(){
      this.updateRanges.length=0
      }copy(t){
      return this.array=new t.array.constructor(t.array),this.count=t.count,this.stride=t.stride,this.usage=t.usage,this
      }copyAt(t,e,i){
      t*=this.stride,i*=e.stride;
      for(
      let s=0,r=this.stride
      ;s<r;s++)
      this.array[t+s]=e.array[i+s];
      return this
      }set(t,e=0){
      return this.array.set(t,e),this
      }clone(t){
      void 0===t.arrayBuffers&&(t.arrayBuffers={}),void 0===this.array.buffer._uuid&&(this.array.buffer._uuid=O()),void 0===t.arrayBuffers[this.array.buffer._uuid]&&(t.arrayBuffers[this.array.buffer._uuid]=this.array.slice(0).buffer);
      let e=new this.array.constructor(t.arrayBuffers[this.array.buffer._uuid]),i=new this.constructor(e,this.stride);
      return i.setUsage(this.usage),i
      }onUpload(t){
      return this.onUploadCallback=t,this
      }toJSON(t){
      return void 0===t.arrayBuffers&&(t.arrayBuffers={}),void 0===this.array.buffer._uuid&&(this.array.buffer._uuid=O()),void 0===t.arrayBuffers[this.array.buffer._uuid]&&(t.arrayBuffers[this.array.buffer._uuid]=Array.from(new Uint32Array(this.array.buffer))),{uuid:this.uuid,buffer:this.array.buffer._uuid,type:this.array.constructor.name,stride:this.stride}
      }
  }
  let eF=new D;
  class eL{
    constructor(t,e,i,s=!1){
      this.isInterleavedBufferAttribute=!0,this.name="",this.data=t,this.itemSize=e,this.offset=i,this.normalized=s
      }get count(){
      return this.data.count
      }get array(){
      return this.data.array
      }set needsUpdate(t){
      this.data.needsUpdate=t
      }applyMatrix4(t){
      for(
      let e=0,i=this.data.count
      ;e<i;e++)
      eF.fromBufferAttribute(this,e),eF.applyMatrix4(t),this.setXYZ(e,eF.x,eF.y,eF.z);
      return this
      }applyNormalMatrix(t){
      for(
      let e=0,i=this.count
      ;e<i;e++)
      eF.fromBufferAttribute(this,e),eF.applyNormalMatrix(t),this.setXYZ(e,eF.x,eF.y,eF.z);
      return this
      }transformDirection(t){
      for(
      let e=0,i=this.count
      ;e<i;e++)
      eF.fromBufferAttribute(this,e),eF.transformDirection(t),this.setXYZ(e,eF.x,eF.y,eF.z);
      return this
      }getComponent(t,e){
      let i=this.array[t*this.data.stride+this.offset+e];
      return this.normalized&&(i=L(i,this.array)),i
      }setComponent(t,e,i){
      return this.normalized&&(i=N(i,this.array)),this.data.array[t*this.data.stride+this.offset+e]=i,this
      }setX(t,e){
      return this.normalized&&(e=N(e,this.array)),this.data.array[t*this.data.stride+this.offset]=e,this
      }setY(t,e){
      return this.normalized&&(e=N(e,this.array)),this.data.array[t*this.data.stride+this.offset+1]=e,this
      }setZ(t,e){
      return this.normalized&&(e=N(e,this.array)),this.data.array[t*this.data.stride+this.offset+2]=e,this
      }setW(t,e){
      return this.normalized&&(e=N(e,this.array)),this.data.array[t*this.data.stride+this.offset+3]=e,this
      }getX(t){
      let e=this.data.array[t*this.data.stride+this.offset];
      return this.normalized&&(e=L(e,this.array)),e
      }getY(t){
      let e=this.data.array[t*this.data.stride+this.offset+1];
      return this.normalized&&(e=L(e,this.array)),e
      }getZ(t){
      let e=this.data.array[t*this.data.stride+this.offset+2];
      return this.normalized&&(e=L(e,this.array)),e
      }getW(t){
      let e=this.data.array[t*this.data.stride+this.offset+3];
      return this.normalized&&(e=L(e,this.array)),e
      }setXY(t,e,i){
      return t=t*this.data.stride+this.offset,this.normalized&&(e=N(e,this.array),i=N(i,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this
      }setXYZ(t,e,i,s){
      return t=t*this.data.stride+this.offset,this.normalized&&(e=N(e,this.array),i=N(i,this.array),s=N(s,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this
      }setXYZW(t,e,i,s,r){
      return t=t*this.data.stride+this.offset,this.normalized&&(e=N(e,this.array),i=N(i,this.array),s=N(s,this.array),r=N(r,this.array)),this.data.array[t+0]=e,this.data.array[t+1]=i,this.data.array[t+2]=s,this.data.array[t+3]=r,this
      }clone(t){
      if(void 0!==t)
      return void 0===t.interleavedBuffers&&(t.interleavedBuffers={}),void 0===t.interleavedBuffers[this.data.uuid]&&(t.interleavedBuffers[this.data.uuid]=this.data.clone(t)),new eL(t.interleavedBuffers[this.data.uuid],this.itemSize,this.offset,this.normalized);
      {
        w("InterleavedBufferAttribute.clone(): Cloning an interleaved buffer attribute will de-interleave buffer data.");
        let t=[];
        for(
        let e=0
        ;e<this.count;e++){
          let i=e*this.data.stride+this.offset;
          for(
          let e=0
          ;e<this.itemSize;e++)
          t.push(this.data.array[i+e])
          }
        return new ex(new this.array.constructor(t),this.itemSize,this.normalized)
        }
    }toJSON(t){
      if(void 0!==t)
      return void 0===t.interleavedBuffers&&(t.interleavedBuffers={}),void 0===t.interleavedBuffers[this.data.uuid]&&(t.interleavedBuffers[this.data.uuid]=this.data.toJSON(t)),{isInterleavedBufferAttribute:!0,itemSize:this.itemSize,data:this.data.uuid,offset:this.offset,normalized:this.normalized};
      {
        w("InterleavedBufferAttribute.toJSON(): Serializing an interleaved buffer attribute will de-interleave buffer data.");
        let t=[];
        for(
        let e=0
        ;e<this.count;e++){
          let i=e*this.data.stride+this.offset;
          for(
          let e=0
          ;e<this.itemSize;e++)
          t.push(this.data.array[i+e])
          }
        return{itemSize:this.itemSize,type:this.array.constructor.name,array:t,normalized:this.normalized}
        }
    }
  }
  let eN=0;
  class eE extends C{
    constructor(){
      super(),this.isMaterial=!0,Object.defineProperty(this,"id",{value:eN++}),this.uuid=O(),this.name="",this.type="Material",this.blending=1,this.side=0,this.vertexColors=!1,this.opacity=1,this.transparent=!1,this.alphaHash=!1,this.blendSrc=204,this.blendDst=205,this.blendEquation=100,this.blendSrcAlpha=null,this.blendDstAlpha=null,this.blendEquationAlpha=null,this.blendColor=new tj(0,0,0),this.blendAlpha=0,this.depthFunc=3,this.depthTest=!0,this.depthWrite=!0,this.stencilWriteMask=255,this.stencilFunc=519,this.stencilRef=0,this.stencilFuncMask=255,this.stencilFail=7680,this.stencilZFail=7680,this.stencilZPass=7680,this.stencilWrite=!1,this.clippingPlanes=null,this.clipIntersection=!1,this.clipShadows=!1,this.shadowSide=null,this.colorWrite=!0,this.precision=null,this.polygonOffset=!1,this.polygonOffsetFactor=0,this.polygonOffsetUnits=0,this.dithering=!1,this.alphaToCoverage=!1,this.premultipliedAlpha=!1,this.forceSinglePass=!1,this.allowOverride=!0,this.visible=!0,this.toneMapped=!0,this.userData={},this.version=0,this._alphaTest=0
      }get alphaTest(){
      return this._alphaTest
      }set alphaTest(t){
      this._alphaTest>0!=t>0&&this.version++,this._alphaTest=t
      }onBeforeRender(){
      }onBeforeCompile(){
      }customProgramCacheKey(){
      return this.onBeforeCompile.toString()
      }setValues(t){
      if(void 0!==t)
      for(
      let e
       in t){
        let i=t[e];
        if(void 0===i){
          _(`Material: parameter '${e}' has value of undefined.`);
          continue
          }
        let s=this[e];
        if(void 0===s){
          _(`Material: '${e}' is not a property of THREE.${this.type}.`);
          continue
          }
        s&&s.isColor?s.set(i):s&&s.isVector3&&i&&i.isVector3?s.copy(i):this[e]=i
        }
      }toJSON(t){
      let e=void 0===t||"string"==typeof t;
      e&&(t={textures:{},images:{}});
      let i={metadata:{version:4.7,type:"Material",generator:"Material.toJSON"}};
      function s(t){
        let e=[];
        for(
        let i
         in t){
          let s=t[i];
          delete s.metadata,e.push(s)
          }
        return e
        }
      if(i.uuid=this.uuid,i.type=this.type,""!==this.name&&(i.name=this.name),this.color&&this.color.isColor&&(i.color=this.color.getHex()),void 0!==this.roughness&&(i.roughness=this.roughness),void 0!==this.metalness&&(i.metalness=this.metalness),void 0!==this.sheen&&(i.sheen=this.sheen),this.sheenColor&&this.sheenColor.isColor&&(i.sheenColor=this.sheenColor.getHex()),void 0!==this.sheenRoughness&&(i.sheenRoughness=this.sheenRoughness),this.emissive&&this.emissive.isColor&&(i.emissive=this.emissive.getHex()),void 0!==this.emissiveIntensity&&1!==this.emissiveIntensity&&(i.emissiveIntensity=this.emissiveIntensity),this.specular&&this.specular.isColor&&(i.specular=this.specular.getHex()),void 0!==this.specularIntensity&&(i.specularIntensity=this.specularIntensity),this.specularColor&&this.specularColor.isColor&&(i.specularColor=this.specularColor.getHex()),void 0!==this.shininess&&(i.shininess=this.shininess),void 0!==this.clearcoat&&(i.clearcoat=this.clearcoat),void 0!==this.clearcoatRoughness&&(i.clearcoatRoughness=this.clearcoatRoughness),this.clearcoatMap&&this.clearcoatMap.isTexture&&(i.clearcoatMap=this.clearcoatMap.toJSON(t).uuid),this.clearcoatRoughnessMap&&this.clearcoatRoughnessMap.isTexture&&(i.clearcoatRoughnessMap=this.clearcoatRoughnessMap.toJSON(t).uuid),this.clearcoatNormalMap&&this.clearcoatNormalMap.isTexture&&(i.clearcoatNormalMap=this.clearcoatNormalMap.toJSON(t).uuid,i.clearcoatNormalScale=this.clearcoatNormalScale.toArray()),this.sheenColorMap&&this.sheenColorMap.isTexture&&(i.sheenColorMap=this.sheenColorMap.toJSON(t).uuid),this.sheenRoughnessMap&&this.sheenRoughnessMap.isTexture&&(i.sheenRoughnessMap=this.sheenRoughnessMap.toJSON(t).uuid),void 0!==this.dispersion&&(i.dispersion=this.dispersion),void 0!==this.iridescence&&(i.iridescence=this.iridescence),void 0!==this.iridescenceIOR&&(i.iridescenceIOR=this.iridescenceIOR),void 0!==this.iridescenceThicknessRange&&(i.iridescenceThicknessRange=this.iridescenceThicknessRange),this.iridescenceMap&&this.iridescenceMap.isTexture&&(i.iridescenceMap=this.iridescenceMap.toJSON(t).uuid),this.iridescenceThicknessMap&&this.iridescenceThicknessMap.isTexture&&(i.iridescenceThicknessMap=this.iridescenceThicknessMap.toJSON(t).uuid),void 0!==this.anisotropy&&(i.anisotropy=this.anisotropy),void 0!==this.anisotropyRotation&&(i.anisotropyRotation=this.anisotropyRotation),this.anisotropyMap&&this.anisotropyMap.isTexture&&(i.anisotropyMap=this.anisotropyMap.toJSON(t).uuid),this.map&&this.map.isTexture&&(i.map=this.map.toJSON(t).uuid),this.matcap&&this.matcap.isTexture&&(i.matcap=this.matcap.toJSON(t).uuid),this.alphaMap&&this.alphaMap.isTexture&&(i.alphaMap=this.alphaMap.toJSON(t).uuid),this.lightMap&&this.lightMap.isTexture&&(i.lightMap=this.lightMap.toJSON(t).uuid,i.lightMapIntensity=this.lightMapIntensity),this.aoMap&&this.aoMap.isTexture&&(i.aoMap=this.aoMap.toJSON(t).uuid,i.aoMapIntensity=this.aoMapIntensity),this.bumpMap&&this.bumpMap.isTexture&&(i.bumpMap=this.bumpMap.toJSON(t).uuid,i.bumpScale=this.bumpScale),this.normalMap&&this.normalMap.isTexture&&(i.normalMap=this.normalMap.toJSON(t).uuid,i.normalMapType=this.normalMapType,i.normalScale=this.normalScale.toArray()),this.displacementMap&&this.displacementMap.isTexture&&(i.displacementMap=this.displacementMap.toJSON(t).uuid,i.displacementScale=this.displacementScale,i.displacementBias=this.displacementBias),this.roughnessMap&&this.roughnessMap.isTexture&&(i.roughnessMap=this.roughnessMap.toJSON(t).uuid),this.metalnessMap&&this.metalnessMap.isTexture&&(i.metalnessMap=this.metalnessMap.toJSON(t).uuid),this.emissiveMap&&this.emissiveMap.isTexture&&(i.emissiveMap=this.emissiveMap.toJSON(t).uuid),this.specularMap&&this.specularMap.isTexture&&(i.specularMap=this.specularMap.toJSON(t).uuid),this.specularIntensityMap&&this.specularIntensityMap.isTexture&&(i.specularIntensityMap=this.specularIntensityMap.toJSON(t).uuid),this.specularColorMap&&this.specularColorMap.isTexture&&(i.specularColorMap=this.specularColorMap.toJSON(t).uuid),this.envMap&&this.envMap.isTexture&&(i.envMap=this.envMap.toJSON(t).uuid,void 0!==this.combine&&(i.combine=this.combine)),void 0!==this.envMapRotation&&(i.envMapRotation=this.envMapRotation.toArray()),void 0!==this.envMapIntensity&&(i.envMapIntensity=this.envMapIntensity),void 0!==this.reflectivity&&(i.reflectivity=this.reflectivity),void 0!==this.refractionRatio&&(i.refractionRatio=this.refractionRatio),this.gradientMap&&this.gradientMap.isTexture&&(i.gradientMap=this.gradientMap.toJSON(t).uuid),void 0!==this.transmission&&(i.transmission=this.transmission),this.transmissionMap&&this.transmissionMap.isTexture&&(i.transmissionMap=this.transmissionMap.toJSON(t).uuid),void 0!==this.thickness&&(i.thickness=this.thickness),this.thicknessMap&&this.thicknessMap.isTexture&&(i.thicknessMap=this.thicknessMap.toJSON(t).uuid),void 0!==this.attenuationDistance&&this.attenuationDistance!==1/0&&(i.attenuationDistance=this.attenuationDistance),void 0!==this.attenuationColor&&(i.attenuationColor=this.attenuationColor.getHex()),void 0!==this.size&&(i.size=this.size),null!==this.shadowSide&&(i.shadowSide=this.shadowSide),void 0!==this.sizeAttenuation&&(i.sizeAttenuation=this.sizeAttenuation),1!==this.blending&&(i.blending=this.blending),0!==this.side&&(i.side=this.side),!0===this.vertexColors&&(i.vertexColors=!0),this.opacity<1&&(i.opacity=this.opacity),!0===this.transparent&&(i.transparent=!0),204!==this.blendSrc&&(i.blendSrc=this.blendSrc),205!==this.blendDst&&(i.blendDst=this.blendDst),100!==this.blendEquation&&(i.blendEquation=this.blendEquation),null!==this.blendSrcAlpha&&(i.blendSrcAlpha=this.blendSrcAlpha),null!==this.blendDstAlpha&&(i.blendDstAlpha=this.blendDstAlpha),null!==this.blendEquationAlpha&&(i.blendEquationAlpha=this.blendEquationAlpha),this.blendColor&&this.blendColor.isColor&&(i.blendColor=this.blendColor.getHex()),0!==this.blendAlpha&&(i.blendAlpha=this.blendAlpha),3!==this.depthFunc&&(i.depthFunc=this.depthFunc),!1===this.depthTest&&(i.depthTest=this.depthTest),!1===this.depthWrite&&(i.depthWrite=this.depthWrite),!1===this.colorWrite&&(i.colorWrite=this.colorWrite),255!==this.stencilWriteMask&&(i.stencilWriteMask=this.stencilWriteMask),519!==this.stencilFunc&&(i.stencilFunc=this.stencilFunc),0!==this.stencilRef&&(i.stencilRef=this.stencilRef),255!==this.stencilFuncMask&&(i.stencilFuncMask=this.stencilFuncMask),7680!==this.stencilFail&&(i.stencilFail=this.stencilFail),7680!==this.stencilZFail&&(i.stencilZFail=this.stencilZFail),7680!==this.stencilZPass&&(i.stencilZPass=this.stencilZPass),!0===this.stencilWrite&&(i.stencilWrite=this.stencilWrite),void 0!==this.rotation&&0!==this.rotation&&(i.rotation=this.rotation),!0===this.polygonOffset&&(i.polygonOffset=!0),0!==this.polygonOffsetFactor&&(i.polygonOffsetFactor=this.polygonOffsetFactor),0!==this.polygonOffsetUnits&&(i.polygonOffsetUnits=this.polygonOffsetUnits),void 0!==this.linewidth&&1!==this.linewidth&&(i.linewidth=this.linewidth),void 0!==this.dashSize&&(i.dashSize=this.dashSize),void 0!==this.gapSize&&(i.gapSize=this.gapSize),void 0!==this.scale&&(i.scale=this.scale),!0===this.dithering&&(i.dithering=!0),this.alphaTest>0&&(i.alphaTest=this.alphaTest),!0===this.alphaHash&&(i.alphaHash=!0),!0===this.alphaToCoverage&&(i.alphaToCoverage=!0),!0===this.premultipliedAlpha&&(i.premultipliedAlpha=!0),!0===this.forceSinglePass&&(i.forceSinglePass=!0),!1===this.allowOverride&&(i.allowOverride=!1),!0===this.wireframe&&(i.wireframe=!0),this.wireframeLinewidth>1&&(i.wireframeLinewidth=this.wireframeLinewidth),"round"!==this.wireframeLinecap&&(i.wireframeLinecap=this.wireframeLinecap),"round"!==this.wireframeLinejoin&&(i.wireframeLinejoin=this.wireframeLinejoin),!0===this.flatShading&&(i.flatShading=!0),!1===this.visible&&(i.visible=!1),!1===this.toneMapped&&(i.toneMapped=!1),!1===this.fog&&(i.fog=!1),Object.keys(this.userData).length>0&&(i.userData=this.userData),e){
        let e=s(t.textures),r=s(t.images);
        e.length>0&&(i.textures=e),r.length>0&&(i.images=r)
        }
      return i
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      this.name=t.name,this.blending=t.blending,this.side=t.side,this.vertexColors=t.vertexColors,this.opacity=t.opacity,this.transparent=t.transparent,this.blendSrc=t.blendSrc,this.blendDst=t.blendDst,this.blendEquation=t.blendEquation,this.blendSrcAlpha=t.blendSrcAlpha,this.blendDstAlpha=t.blendDstAlpha,this.blendEquationAlpha=t.blendEquationAlpha,this.blendColor.copy(t.blendColor),this.blendAlpha=t.blendAlpha,this.depthFunc=t.depthFunc,this.depthTest=t.depthTest,this.depthWrite=t.depthWrite,this.stencilWriteMask=t.stencilWriteMask,this.stencilFunc=t.stencilFunc,this.stencilRef=t.stencilRef,this.stencilFuncMask=t.stencilFuncMask,this.stencilFail=t.stencilFail,this.stencilZFail=t.stencilZFail,this.stencilZPass=t.stencilZPass,this.stencilWrite=t.stencilWrite;
      let e=t.clippingPlanes,i=null;
      if(null!==e){
        let t=e.length;
        i=Array(t);
        for(
        let s=0
        ;s!==t;++s)
        i[s]=e[s].clone()
        }
      return this.clippingPlanes=i,this.clipIntersection=t.clipIntersection,this.clipShadows=t.clipShadows,this.shadowSide=t.shadowSide,this.colorWrite=t.colorWrite,this.precision=t.precision,this.polygonOffset=t.polygonOffset,this.polygonOffsetFactor=t.polygonOffsetFactor,this.polygonOffsetUnits=t.polygonOffsetUnits,this.dithering=t.dithering,this.alphaTest=t.alphaTest,this.alphaHash=t.alphaHash,this.alphaToCoverage=t.alphaToCoverage,this.premultipliedAlpha=t.premultipliedAlpha,this.forceSinglePass=t.forceSinglePass,this.allowOverride=t.allowOverride,this.visible=t.visible,this.toneMapped=t.toneMapped,this.userData=JSON.parse(JSON.stringify(t.userData)),this
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }set needsUpdate(t){
      !0===t&&this.version++
      }
  }
  class eV extends eE{
    constructor(t){
      super(),this.isSpriteMaterial=!0,this.type="SpriteMaterial",this.color=new tj(0xffffff),this.map=null,this.alphaMap=null,this.rotation=0,this.sizeAttenuation=!0,this.transparent=!0,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.rotation=t.rotation,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this
      }
  }
  let eD=new D,eU=new D,ej=new D,eW=new E,eG=new E,eq=new th,eJ=new D,eH=new D,eX=new D,eY=new E,eZ=new E,e$=new E;
  class eQ extends tF{
    constructor(t=new eV){
      if(super(),this.isSprite=!0,this.type="Sprite",void 0===i){
        i=new eR;
        const t=new eP(new Float32Array([-.5,-.5,0,0,0,.5,-.5,0,1,0,.5,.5,0,1,1,-.5,.5,0,0,1]),5);
        i.setIndex([0,1,2,0,2,3]),i.setAttribute("position",new eL(t,3,0,!1)),i.setAttribute("uv",new eL(t,2,3,!1))
        }
      this.geometry=i,this.material=t,this.center=new E(.5,.5),this.count=1
      }raycast(t,e){
      let i,s;
      null===t.camera&&A('Sprite: "Raycaster.camera" needs to be set in order to raycast against sprites.'),eU.setFromMatrixScale(this.matrixWorld),eq.copy(t.camera.matrixWorld),this.modelViewMatrix.multiplyMatrices(t.camera.matrixWorldInverse,this.matrixWorld),ej.setFromMatrixPosition(this.modelViewMatrix),t.camera.isPerspectiveCamera&&!1===this.material.sizeAttenuation&&eU.multiplyScalar(-ej.z);
      let r=this.material.rotation;
      0!==r&&(s=Math.cos(r),i=Math.sin(r));
      let n=this.center;
      eK(eJ.set(-.5,-.5,0),ej,n,eU,i,s),eK(eH.set(.5,-.5,0),ej,n,eU,i,s),eK(eX.set(.5,.5,0),ej,n,eU,i,s),eY.set(0,0),eZ.set(1,0),e$.set(1,1);
      let a=t.ray.intersectTriangle(eJ,eH,eX,!1,eD);
      if(null===a&&(eK(eH.set(-.5,.5,0),ej,n,eU,i,s),eZ.set(0,1),null===(a=t.ray.intersectTriangle(eJ,eX,eH,!1,eD))))
      return;
      let o=t.ray.origin.distanceTo(eD);
      o<t.near||o>t.far||e.push({distance:o,point:eD.clone(),uv:t6.getInterpolation(eD,eJ,eH,eX,eY,eZ,e$,new E),face:null,object:this})
      }copy(t,e){
      return super.copy(t,e),void 0!==t.center&&this.center.copy(t.center),this.material=t.material,this
      }
  }
  function eK(t,e,i,s,r,n){
    eW.subVectors(t,i).addScalar(.5).multiply(s),void 0!==r?(eG.x=n*eW.x-r*eW.y,eG.y=r*eW.x+n*eW.y):eG.copy(eW),t.copy(e),t.x+=eG.x,t.y+=eG.y,t.applyMatrix4(eq)
    }
  let e0=new D,e1=new D;
  class e2 extends tF{
    constructor(){
      super(),this.isLOD=!0,this._currentLevel=0,this.type="LOD",Object.defineProperties(this,{levels:{enumerable:!0,value:[]}}),this.autoUpdate=!0
      }copy(t){
      super.copy(t,!1);
      let e=t.levels;
      for(
      let t=0,i=e.length
      ;t<i;t++){
        let i=e[t];
        this.addLevel(i.object.clone(),i.distance,i.hysteresis)
        }
      return this.autoUpdate=t.autoUpdate,this
      }addLevel(t,e=0,i=0){
      let s;
      e=Math.abs(e);
      let r=this.levels;
      for(s=0;s<r.length&&!(e<r[s].distance);s++);
      return r.splice(s,0,{distance:e,hysteresis:i,object:t}),this.add(t),this
      }removeLevel(t){
      let e=this.levels;
      for(
      let i=0
      ;i<e.length;i++)
      if(e[i].distance===t){
        let t=e.splice(i,1);
        return this.remove(t[0].object),!0
        }
      return!1
      }getCurrentLevel(){
      return this._currentLevel
      }getObjectForDistance(t){
      let e=this.levels;
      if(e.length>0){
        let i,s;
        for(i=1,s=e.length;i<s;i++){
          let s=e[i].distance;
          if(e[i].object.visible&&(s-=s*e[i].hysteresis),t<s)
          break
          }
        return e[i-1].object
        }
      return null
      }raycast(t,e){
      if(this.levels.length>0){
        e0.setFromMatrixPosition(this.matrixWorld);
        let i=t.ray.origin.distanceTo(e0);
        this.getObjectForDistance(i).raycast(t,e)
        }
      }update(t){
      let e=this.levels;
      if(e.length>1){
        let i,s;
        e0.setFromMatrixPosition(t.matrixWorld),e1.setFromMatrixPosition(this.matrixWorld);
        let r=e0.distanceTo(e1)/t.zoom;
        for(i=1,e[0].object.visible=!0,s=e.length;i<s;i++){
          let t=e[i].distance;
          if(e[i].object.visible&&(t-=t*e[i].hysteresis),r>=t)
          e[i-1].object.visible=!1,e[i].object.visible=!0;
          else 
          break
          }
        for(this._currentLevel=i-1;i<s;i++)
        e[i].object.visible=!1
        }
      }toJSON(t){
      let e=super.toJSON(t);
      !1===this.autoUpdate&&(e.object.autoUpdate=!1),e.object.levels=[];
      let i=this.levels;
      for(
      let t=0,s=i.length
      ;t<s;t++){
        let s=i[t];
        e.object.levels.push({object:s.object.uuid,distance:s.distance,hysteresis:s.hysteresis})
        }
      return e
      }
  }
  let e3=new D,e5=new D,e4=new D,e6=new D,e8=new D,e9=new D,e7=new D;
  class it{
    constructor(t=new D,e=new D(0,0,-1)){
      this.origin=t,this.direction=e
      }set(t,e){
      return this.origin.copy(t),this.direction.copy(e),this
      }copy(t){
      return this.origin.copy(t.origin),this.direction.copy(t.direction),this
      }at(t,e){
      return e.copy(this.origin).addScaledVector(this.direction,t)
      }lookAt(t){
      return this.direction.copy(t).sub(this.origin).normalize(),this
      }recast(t){
      return this.origin.copy(this.at(t,e3)),this
      }closestPointToPoint(t,e){
      e.subVectors(t,this.origin);
      let i=e.dot(this.direction);
      return i<0?e.copy(this.origin):e.copy(this.origin).addScaledVector(this.direction,i)
      }distanceToPoint(t){
      return Math.sqrt(this.distanceSqToPoint(t))
      }distanceSqToPoint(t){
      let e=e3.subVectors(t,this.origin).dot(this.direction);
      return e<0?this.origin.distanceToSquared(t):(e3.copy(this.origin).addScaledVector(this.direction,e),e3.distanceToSquared(t))
      }distanceSqToSegment(t,e,i,s){
      let r,n,a,o;
      e5.copy(t).add(e).multiplyScalar(.5),e4.copy(e).sub(t).normalize(),e6.copy(this.origin).sub(e5);
      let h=.5*t.distanceTo(e),l=-this.direction.dot(e4),u=e6.dot(this.direction),c=-e6.dot(e4),p=e6.lengthSq(),d=Math.abs(1-l*l);
      if(d>0)
      if(r=l*c-u,n=l*u-c,o=h*d,r>=0)
      if(n>=-o)
      if(n<=o){
        let t=1/d;
        r*=t,n*=t,a=r*(r+l*n+2*u)+n*(l*r+n+2*c)+p
        }else 
      a=-(r=Math.max(0,-(l*(n=h)+u)))*r+n*(n+2*c)+p;
      else 
      a=-(r=Math.max(0,-(l*(n=-h)+u)))*r+n*(n+2*c)+p;
      else 
      n<=-o?(n=(r=Math.max(0,-(-l*h+u)))>0?-h:Math.min(Math.max(-h,-c),h),a=-r*r+n*(n+2*c)+p):n<=o?(r=0,a=(n=Math.min(Math.max(-h,-c),h))*(n+2*c)+p):(n=(r=Math.max(0,-(l*h+u)))>0?h:Math.min(Math.max(-h,-c),h),a=-r*r+n*(n+2*c)+p);
      else 
      n=l>0?-h:h,a=-(r=Math.max(0,-(l*n+u)))*r+n*(n+2*c)+p;
      return i&&i.copy(this.origin).addScaledVector(this.direction,r),s&&s.copy(e5).addScaledVector(e4,n),a
      }intersectSphere(t,e){
      e3.subVectors(t.center,this.origin);
      let i=e3.dot(this.direction),s=e3.dot(e3)-i*i,r=t.radius*t.radius;
      if(s>r)
      return null;
      let n=Math.sqrt(r-s),a=i-n,o=i+n;
      return o<0?null:a<0?this.at(o,e):this.at(a,e)
      }intersectsSphere(t){
      return!(t.radius<0)&&this.distanceSqToPoint(t.center)<=t.radius*t.radius
      }distanceToPlane(t){
      let e=t.normal.dot(this.direction);
      if(0===e)
      return 0===t.distanceToPoint(this.origin)?0:null;
      let i=-(this.origin.dot(t.normal)+t.constant)/e;
      return i>=0?i:null
      }intersectPlane(t,e){
      let i=this.distanceToPlane(t);
      return null===i?null:this.at(i,e)
      }intersectsPlane(t){
      let e=t.distanceToPoint(this.origin);
      return!!(0===e||t.normal.dot(this.direction)*e<0)
      }intersectBox(t,e){
      let i,s,r,n,a,o,h=1/this.direction.x,l=1/this.direction.y,u=1/this.direction.z,c=this.origin;
      return(h>=0?(i=(t.min.x-c.x)*h,s=(t.max.x-c.x)*h):(i=(t.max.x-c.x)*h,s=(t.min.x-c.x)*h),l>=0?(r=(t.min.y-c.y)*l,n=(t.max.y-c.y)*l):(r=(t.max.y-c.y)*l,n=(t.min.y-c.y)*l),i>n||r>s||((r>i||isNaN(i))&&(i=r),(n<s||isNaN(s))&&(s=n),u>=0?(a=(t.min.z-c.z)*u,o=(t.max.z-c.z)*u):(a=(t.max.z-c.z)*u,o=(t.min.z-c.z)*u),i>o||a>s||((a>i||i!=i)&&(i=a),(o<s||s!=s)&&(s=o),s<0)))?null:this.at(i>=0?i:s,e)
      }intersectsBox(t){
      return null!==this.intersectBox(t,e3)
      }intersectTriangle(t,e,i,s,r){
      let n;
      e8.subVectors(e,t),e9.subVectors(i,t),e7.crossVectors(e8,e9);
      let a=this.direction.dot(e7);
      if(a>0){
        if(s)
        return null;
        n=1
        }else{
        if(!(a<0))
        return null;
        n=-1,a=-a
        }
      e6.subVectors(this.origin,t);
      let o=n*this.direction.dot(e9.crossVectors(e6,e9));
      if(o<0)
      return null;
      let h=n*this.direction.dot(e8.cross(e6));
      if(h<0||o+h>a)
      return null;
      let l=-n*e6.dot(e7);
      return l<0?null:this.at(l/a,r)
      }applyMatrix4(t){
      return this.origin.applyMatrix4(t),this.direction.transformDirection(t),this
      }equals(t){
      return t.origin.equals(this.origin)&&t.direction.equals(this.direction)
      }clone(){
      return new this.constructor().copy(this)
      }
  }
  class ie extends eE{
    constructor(t){
      super(),this.isMeshBasicMaterial=!0,this.type="MeshBasicMaterial",this.color=new tj(0xffffff),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new tx,this.combine=0,this.reflectivity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this
      }
  }
  let ii=new th,is=new it,ir=new eA,ia=new D,io=new D,ih=new D,il=new D,iu=new D,ic=new D,ip=new D,id=new D;
  class im extends tF{
    constructor(t=new eR,e=new ie){
      super(),this.isMesh=!0,this.type="Mesh",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.count=1,this.updateMorphTargets()
      }copy(t,e){
      return super.copy(t,e),void 0!==t.morphTargetInfluences&&(this.morphTargetInfluences=t.morphTargetInfluences.slice()),void 0!==t.morphTargetDictionary&&(this.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this
      }updateMorphTargets(){
      let t=this.geometry.morphAttributes,e=Object.keys(t);
      if(e.length>0){
        let i=t[e[0]];
        if(void 0!==i){
          this.morphTargetInfluences=[],this.morphTargetDictionary={};
          for(
          let t=0,e=i.length
          ;t<e;t++){
            let e=i[t].name||String(t);
            this.morphTargetInfluences.push(0),this.morphTargetDictionary[e]=t
            }
          }
        }
      }getVertexPosition(t,e){
      let i=this.geometry,s=i.attributes.position,r=i.morphAttributes.position,n=i.morphTargetsRelative;
      e.fromBufferAttribute(s,t);
      let a=this.morphTargetInfluences;
      if(r&&a){
        ic.set(0,0,0);
        for(
        let i=0,s=r.length
        ;i<s;i++){
          let s=a[i],o=r[i];
          0!==s&&(iu.fromBufferAttribute(o,t),n?ic.addScaledVector(iu,s):ic.addScaledVector(iu.sub(e),s))
          }
        e.add(ic)
        }
      return e
      }raycast(t,e){
      let i=this.geometry,s=this.material,r=this.matrixWorld;
      void 0===s||(null===i.boundingSphere&&i.computeBoundingSphere(),ir.copy(i.boundingSphere),ir.applyMatrix4(r),is.copy(t.ray).recast(t.near),!1===ir.containsPoint(is.origin)&&(null===is.intersectSphere(ir,ia)||is.origin.distanceToSquared(ia)>(t.far-t.near)**2)||(ii.copy(r).invert(),is.copy(t.ray).applyMatrix4(ii),(null===i.boundingBox||!1!==is.intersectsBox(i.boundingBox))&&this._computeIntersections(t,e,is)))
      }_computeIntersections(t,e,i){
      let s,r=this.geometry,n=this.material,a=r.index,o=r.attributes.position,h=r.attributes.uv,l=r.attributes.uv1,u=r.attributes.normal,c=r.groups,p=r.drawRange;
      if(null!==a)
      if(Array.isArray(n))
      for(
      let r=0,o=c.length
      ;r<o;r++){
        let o=c[r],d=n[o.materialIndex],m=Math.max(o.start,p.start),y=Math.min(a.count,Math.min(o.start+o.count,p.start+p.count));
        for(
        let r=m
        ;r<y;r+=3)
        (s=iy(this,d,t,i,h,l,u,a.getX(r),a.getX(r+1),a.getX(r+2)))&&(s.faceIndex=Math.floor(r/3),s.face.materialIndex=o.materialIndex,e.push(s))
        }
      else{
        let r=Math.max(0,p.start),o=Math.min(a.count,p.start+p.count);
        for(
        let c=r
        ;c<o;c+=3)
        (s=iy(this,n,t,i,h,l,u,a.getX(c),a.getX(c+1),a.getX(c+2)))&&(s.faceIndex=Math.floor(c/3),e.push(s))
        }
      else 
      if(void 0!==o)
      if(Array.isArray(n))
      for(
      let r=0,a=c.length
      ;r<a;r++){
        let a=c[r],d=n[a.materialIndex],m=Math.max(a.start,p.start),y=Math.min(o.count,Math.min(a.start+a.count,p.start+p.count));
        for(
        let r=m
        ;r<y;r+=3)
        (s=iy(this,d,t,i,h,l,u,r,r+1,r+2))&&(s.faceIndex=Math.floor(r/3),s.face.materialIndex=a.materialIndex,e.push(s))
        }
      else{
        let r=Math.max(0,p.start),a=Math.min(o.count,p.start+p.count);
        for(
        let o=r
        ;o<a;o+=3)
        (s=iy(this,n,t,i,h,l,u,o,o+1,o+2))&&(s.faceIndex=Math.floor(o/3),e.push(s))
        }
      }
  }
  function iy(t,e,i,s,r,n,a,o,h,l){
    t.getVertexPosition(o,io),t.getVertexPosition(h,ih),t.getVertexPosition(l,il);
    let u=function(t,e,i,s,r,n,a,o){
      if(null===(1===e.side?s.intersectTriangle(a,n,r,!0,o):s.intersectTriangle(r,n,a,0===e.side,o)))
      return null;
      id.copy(o),id.applyMatrix4(t.matrixWorld);
      let h=i.ray.origin.distanceTo(id);
      return h<i.near||h>i.far?null:{distance:h,point:id.clone(),object:t}
      }(t,e,i,s,io,ih,il,ip);
    if(u){
      let t=new D;
      t6.getBarycoord(ip,io,ih,il,t),r&&(u.uv=t6.getInterpolatedAttribute(r,o,h,l,t,new E)),n&&(u.uv1=t6.getInterpolatedAttribute(n,o,h,l,t,new E)),a&&(u.normal=t6.getInterpolatedAttribute(a,o,h,l,t,new D),u.normal.dot(s.direction)>0&&u.normal.multiplyScalar(-1));
      let e={a:o,b:h,c:l,normal:new D,materialIndex:0};
      t6.getNormal(io,ih,il,e.normal),u.face=e,u.barycoord=t
      }
    return u
    }
  let ig=new ts,ix=new ts,ib=new ts,iv=new ts,iM=new th,iw=new D,iS=new eA,i_=new th,iA=new it;
  class iT extends im{
    constructor(t,e){
      super(t,e),this.isSkinnedMesh=!0,this.type="SkinnedMesh",this.bindMode=u,this.bindMatrix=new th,this.bindMatrixInverse=new th,this.boundingBox=null,this.boundingSphere=null
      }computeBoundingBox(){
      let t=this.geometry;
      null===this.boundingBox&&(this.boundingBox=new t8),this.boundingBox.makeEmpty();
      let e=t.getAttribute("position");
      for(
      let t=0
      ;t<e.count;t++)
      this.getVertexPosition(t,iw),this.boundingBox.expandByPoint(iw)
      }computeBoundingSphere(){
      let t=this.geometry;
      null===this.boundingSphere&&(this.boundingSphere=new eA),this.boundingSphere.makeEmpty();
      let e=t.getAttribute("position");
      for(
      let t=0
      ;t<e.count;t++)
      this.getVertexPosition(t,iw),this.boundingSphere.expandByPoint(iw)
      }copy(t,e){
      return super.copy(t,e),this.bindMode=t.bindMode,this.bindMatrix.copy(t.bindMatrix),this.bindMatrixInverse.copy(t.bindMatrixInverse),this.skeleton=t.skeleton,null!==t.boundingBox&&(this.boundingBox=t.boundingBox.clone()),null!==t.boundingSphere&&(this.boundingSphere=t.boundingSphere.clone()),this
      }raycast(t,e){
      let i=this.material,s=this.matrixWorld;
      void 0===i||(null===this.boundingSphere&&this.computeBoundingSphere(),iS.copy(this.boundingSphere),iS.applyMatrix4(s),!1===t.ray.intersectsSphere(iS)||(i_.copy(s).invert(),iA.copy(t.ray).applyMatrix4(i_),(null===this.boundingBox||!1!==iA.intersectsBox(this.boundingBox))&&this._computeIntersections(t,e,iA)))
      }getVertexPosition(t,e){
      return super.getVertexPosition(t,e),this.applyBoneTransform(t,e),e
      }bind(t,e){
      this.skeleton=t,void 0===e&&(this.updateMatrixWorld(!0),this.skeleton.calculateInverses(),e=this.matrixWorld),this.bindMatrix.copy(e),this.bindMatrixInverse.copy(e).invert()
      }pose(){
      this.skeleton.pose()
      }normalizeSkinWeights(){
      let t=new ts,e=this.geometry.attributes.skinWeight;
      for(
      let i=0,s=e.count
      ;i<s;i++){
        t.fromBufferAttribute(e,i);
        let s=1/t.manhattanLength();
        s!==1/0?t.multiplyScalar(s):t.set(1,0,0,0),e.setXYZW(i,t.x,t.y,t.z,t.w)
        }
      }updateMatrixWorld(t){
      super.updateMatrixWorld(t),this.bindMode===u?this.bindMatrixInverse.copy(this.matrixWorld).invert():this.bindMode===c?this.bindMatrixInverse.copy(this.bindMatrix).invert():_("SkinnedMesh: Unrecognized bindMode: "+this.bindMode)
      }applyBoneTransform(t,e){
      let i=this.skeleton,s=this.geometry;
      ix.fromBufferAttribute(s.attributes.skinIndex,t),ib.fromBufferAttribute(s.attributes.skinWeight,t),e.isVector4?(ig.copy(e),e.set(0,0,0,0)):(ig.set(...e,1),e.set(0,0,0)),ig.applyMatrix4(this.bindMatrix);
      for(
      let t=0
      ;t<4;t++){
        let s=ib.getComponent(t);
        if(0!==s){
          let r=ix.getComponent(t);
          iM.multiplyMatrices(i.bones[r].matrixWorld,i.boneInverses[r]),e.addScaledVector(iv.copy(ig).applyMatrix4(iM),s)
          }
        }
      return e.isVector4&&(e.w=ig.w),e.applyMatrix4(this.bindMatrixInverse)
      }
  }
  class iC extends tF{
    constructor(){
      super(),this.isBone=!0,this.type="Bone"
      }
  }
  class iI extends ti{
    constructor(t=null,e=1,i=1,s,r,n,a,o,h=1003,l=1003,u,c){
      super(null,n,a,o,h,l,s,r,u,c),this.isDataTexture=!0,this.image={data:t,width:e,height:i},this.generateMipmaps=!1,this.flipY=!1,this.unpackAlignment=1
      }
  }
  let iz=new th,iB=new th;
  class ik{
    constructor(t=[],e=[]){
      this.uuid=O(),this.bones=t.slice(0),this.boneInverses=e,this.boneMatrices=null,this.previousBoneMatrices=null,this.boneTexture=null,this.init()
      }init(){
      let t=this.bones,e=this.boneInverses;
      if(this.boneMatrices=new Float32Array(16*t.length),0===e.length)
      this.calculateInverses();
      else 
      if(t.length!==e.length){
        _("Skeleton: Number of inverse bone matrices does not match amount of bones."),this.boneInverses=[];
        for(
        let t=0,e=this.bones.length
        ;t<e;t++)
        this.boneInverses.push(new th)
        }
      }calculateInverses(){
      this.boneInverses.length=0;
      for(
      let t=0,e=this.bones.length
      ;t<e;t++){
        let e=new th;
        this.bones[t]&&e.copy(this.bones[t].matrixWorld).invert(),this.boneInverses.push(e)
        }
      }pose(){
      for(
      let t=0,e=this.bones.length
      ;t<e;t++){
        let e=this.bones[t];
        e&&e.matrixWorld.copy(this.boneInverses[t]).invert()
        }
      for(
      let t=0,e=this.bones.length
      ;t<e;t++){
        let e=this.bones[t];
        e&&(e.parent&&e.parent.isBone?(e.matrix.copy(e.parent.matrixWorld).invert(),e.matrix.multiply(e.matrixWorld)):e.matrix.copy(e.matrixWorld),e.matrix.decompose(e.position,e.quaternion,e.scale))
        }
      }update(){
      let t=this.bones,e=this.boneInverses,i=this.boneMatrices,s=this.boneTexture;
      for(
      let s=0,r=t.length
      ;s<r;s++){
        let r=t[s]?t[s].matrixWorld:iB;
        iz.multiplyMatrices(r,e[s]),iz.toArray(i,16*s)
        }
      null!==s&&(s.needsUpdate=!0)
      }clone(){
      return new ik(this.bones,this.boneInverses)
      }computeBoneTexture(){
      let t=Math.sqrt(4*this.bones.length),e=new Float32Array((t=Math.max(t=4*Math.ceil(t/4),4))*t*4);
      e.set(this.boneMatrices);
      let i=new iI(e,t,t,1023,1015);
      return i.needsUpdate=!0,this.boneMatrices=e,this.boneTexture=i,this
      }getBoneByName(t){
      for(
      let e=0,i=this.bones.length
      ;e<i;e++){
        let i=this.bones[e];
        if(i.name===t)
        return i
        }
      }dispose(){
      null!==this.boneTexture&&(this.boneTexture.dispose(),this.boneTexture=null)
      }fromJSON(t,e){
      this.uuid=t.uuid;
      for(
      let i=0,s=t.bones.length
      ;i<s;i++){
        let s=t.bones[i],r=e[s];
        void 0===r&&(_("Skeleton: No bone found with UUID:",s),r=new iC),this.bones.push(r),this.boneInverses.push(new th().fromArray(t.boneInverses[i]))
        }
      return this.init(),this
      }toJSON(){
      let t={metadata:{version:4.7,type:"Skeleton",generator:"Skeleton.toJSON"},bones:[],boneInverses:[]};
      t.uuid=this.uuid;
      let e=this.bones,i=this.boneInverses;
      for(
      let s=0,r=e.length
      ;s<r;s++){
        let r=e[s];
        t.bones.push(r.uuid);
        let n=i[s];
        t.boneInverses.push(n.toArray())
        }
      return t
      }
  }
  class iO extends ex{
    constructor(t,e,i,s=1){
      super(t,e,i),this.isInstancedBufferAttribute=!0,this.meshPerAttribute=s
      }copy(t){
      return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this
      }toJSON(){
      let t=super.toJSON();
      return t.meshPerAttribute=this.meshPerAttribute,t.isInstancedBufferAttribute=!0,t
      }
  }
  let iR=new th,iP=new th,iF=[],iL=new t8,iN=new th,iE=new im,iV=new eA;
  class iD extends im{
    constructor(t,e,i){
      super(t,e),this.isInstancedMesh=!0,this.instanceMatrix=new iO(new Float32Array(16*i),16),this.previousInstanceMatrix=null,this.instanceColor=null,this.morphTexture=null,this.count=i,this.boundingBox=null,this.boundingSphere=null;
      for(
      let t=0
      ;t<i;t++)
      this.setMatrixAt(t,iN)
      }computeBoundingBox(){
      let t=this.geometry,e=this.count;
      null===this.boundingBox&&(this.boundingBox=new t8),null===t.boundingBox&&t.computeBoundingBox(),this.boundingBox.makeEmpty();
      for(
      let i=0
      ;i<e;i++)
      this.getMatrixAt(i,iR),iL.copy(t.boundingBox).applyMatrix4(iR),this.boundingBox.union(iL)
      }computeBoundingSphere(){
      let t=this.geometry,e=this.count;
      null===this.boundingSphere&&(this.boundingSphere=new eA),null===t.boundingSphere&&t.computeBoundingSphere(),this.boundingSphere.makeEmpty();
      for(
      let i=0
      ;i<e;i++)
      this.getMatrixAt(i,iR),iV.copy(t.boundingSphere).applyMatrix4(iR),this.boundingSphere.union(iV)
      }copy(t,e){
      return super.copy(t,e),this.instanceMatrix.copy(t.instanceMatrix),null!==t.previousInstanceMatrix&&(this.previousInstanceMatrix=t.previousInstanceMatrix.clone()),null!==t.morphTexture&&(this.morphTexture=t.morphTexture.clone()),null!==t.instanceColor&&(this.instanceColor=t.instanceColor.clone()),this.count=t.count,null!==t.boundingBox&&(this.boundingBox=t.boundingBox.clone()),null!==t.boundingSphere&&(this.boundingSphere=t.boundingSphere.clone()),this
      }getColorAt(t,e){
      return null===this.instanceColor?e.setRGB(1,1,1):e.fromArray(this.instanceColor.array,3*t)
      }getMatrixAt(t,e){
      return e.fromArray(this.instanceMatrix.array,16*t)
      }getMorphAt(t,e){
      let i=e.morphTargetInfluences,s=this.morphTexture.source.data.data,r=t*(i.length+1)+1;
      for(
      let t=0
      ;t<i.length;t++)
      i[t]=s[r+t]
      }raycast(t,e){
      let i=this.matrixWorld,s=this.count;
      if((iE.geometry=this.geometry,iE.material=this.material,void 0!==iE.material)&&(null===this.boundingSphere&&this.computeBoundingSphere(),iV.copy(this.boundingSphere),iV.applyMatrix4(i),!1!==t.ray.intersectsSphere(iV)))
      for(
      let r=0
      ;r<s;r++){
        this.getMatrixAt(r,iR),iP.multiplyMatrices(i,iR),iE.matrixWorld=iP,iE.raycast(t,iF);
        for(
        let t=0,i=iF.length
        ;t<i;t++){
          let i=iF[t];
          i.instanceId=r,i.object=this,e.push(i)
          }
        iF.length=0
        }
      }setColorAt(t,e){
      return null===this.instanceColor&&(this.instanceColor=new iO(new Float32Array(3*this.instanceMatrix.count).fill(1),3)),e.toArray(this.instanceColor.array,3*t),this
      }setMatrixAt(t,e){
      return e.toArray(this.instanceMatrix.array,16*t),this
      }setMorphAt(t,e){
      let i=e.morphTargetInfluences,s=i.length+1;
      null===this.morphTexture&&(this.morphTexture=new iI(new Float32Array(s*this.count),s,this.count,1028,1015));
      let r=this.morphTexture.source.data.data,n=0;
      for(
      let t=0
      ;t<i.length;t++)
      n+=i[t];
      let a=this.geometry.morphTargetsRelative?1:1-n,o=s*t;
      return r[o]=a,r.set(i,o+1),this
      }updateMorphTargets(){
      }dispose(){
      this.dispatchEvent({type:"dispose"}),null!==this.morphTexture&&(this.morphTexture.dispose(),this.morphTexture=null)
      }
  }
  let iU=new D,ij=new D,iW=new W;
  class iG{
    constructor(t=new D(1,0,0),e=0){
      this.isPlane=!0,this.normal=t,this.constant=e
      }set(t,e){
      return this.normal.copy(t),this.constant=e,this
      }setComponents(t,e,i,s){
      return this.normal.set(t,e,i),this.constant=s,this
      }setFromNormalAndCoplanarPoint(t,e){
      return this.normal.copy(t),this.constant=-e.dot(this.normal),this
      }setFromCoplanarPoints(t,e,i){
      let s=iU.subVectors(i,e).cross(ij.subVectors(t,e)).normalize();
      return this.setFromNormalAndCoplanarPoint(s,t),this
      }copy(t){
      return this.normal.copy(t.normal),this.constant=t.constant,this
      }normalize(){
      let t=1/this.normal.length();
      return this.normal.multiplyScalar(t),this.constant*=t,this
      }negate(){
      return this.constant*=-1,this.normal.negate(),this
      }distanceToPoint(t){
      return this.normal.dot(t)+this.constant
      }distanceToSphere(t){
      return this.distanceToPoint(t.center)-t.radius
      }projectPoint(t,e){
      return e.copy(t).addScaledVector(this.normal,-this.distanceToPoint(t))
      }intersectLine(t,e,i=!0){
      let s=t.delta(iU),r=this.normal.dot(s);
      if(0===r)
      return 0===this.distanceToPoint(t.start)?e.copy(t.start):null;
      let n=-(t.start.dot(this.normal)+this.constant)/r;
      return!0===i&&(n<0||n>1)?null:e.copy(t.start).addScaledVector(s,n)
      }intersectsLine(t){
      let e=this.distanceToPoint(t.start),i=this.distanceToPoint(t.end);
      return e<0&&i>0||i<0&&e>0
      }intersectsBox(t){
      return t.intersectsPlane(this)
      }intersectsSphere(t){
      return t.intersectsPlane(this)
      }coplanarPoint(t){
      return t.copy(this.normal).multiplyScalar(-this.constant)
      }applyMatrix4(t,e){
      let i=e||iW.getNormalMatrix(t),s=this.coplanarPoint(iU).applyMatrix4(t),r=this.normal.applyMatrix3(i).normalize();
      return this.constant=-s.dot(r),this
      }translate(t){
      return this.constant-=t.dot(this.normal),this
      }equals(t){
      return t.normal.equals(this.normal)&&t.constant===this.constant
      }clone(){
      return new this.constructor().copy(this)
      }
  }
  let iq=new eA,iJ=new E(.5,.5),iH=new D;
  class iX{
    constructor(t=new iG,e=new iG,i=new iG,s=new iG,r=new iG,n=new iG){
      this.planes=[t,e,i,s,r,n]
      }set(t,e,i,s,r,n){
      let a=this.planes;
      return a[0].copy(t),a[1].copy(e),a[2].copy(i),a[3].copy(s),a[4].copy(r),a[5].copy(n),this
      }copy(t){
      let e=this.planes;
      for(
      let i=0
      ;i<6;i++)
      e[i].copy(t.planes[i]);
      return this
      }setFromProjectionMatrix(t,e=2e3,i=!1){
      let s=this.planes,r=t.elements,n=r[0],a=r[1],o=r[2],h=r[3],l=r[4],u=r[5],c=r[6],p=r[7],d=r[8],m=r[9],y=r[10],f=r[11],g=r[12],x=r[13],b=r[14],v=r[15];
      if(s[0].setComponents(h-n,p-l,f-d,v-g).normalize(),s[1].setComponents(h+n,p+l,f+d,v+g).normalize(),s[2].setComponents(h+a,p+u,f+m,v+x).normalize(),s[3].setComponents(h-a,p-u,f-m,v-x).normalize(),i)
      s[4].setComponents(o,c,y,b).normalize(),s[5].setComponents(h-o,p-c,f-y,v-b).normalize();
      else 
      if(s[4].setComponents(h-o,p-c,f-y,v-b).normalize(),2e3===e)
      s[5].setComponents(h+o,p+c,f+y,v+b).normalize();
      else 
      if(2001===e)
      s[5].setComponents(o,c,y,b).normalize();
      else 
      throw Error("THREE.Frustum.setFromProjectionMatrix(): Invalid coordinate system: "+e);
      return this
      }intersectsObject(t){
      if(void 0!==t.boundingSphere)
      null===t.boundingSphere&&t.computeBoundingSphere(),iq.copy(t.boundingSphere).applyMatrix4(t.matrixWorld);
      else{
        let e=t.geometry;
        null===e.boundingSphere&&e.computeBoundingSphere(),iq.copy(e.boundingSphere).applyMatrix4(t.matrixWorld)
        }
      return this.intersectsSphere(iq)
      }intersectsSprite(t){
      return iq.center.set(0,0,0),iq.radius=.7071067811865476+iJ.distanceTo(t.center),iq.applyMatrix4(t.matrixWorld),this.intersectsSphere(iq)
      }intersectsSphere(t){
      let e=this.planes,i=t.center,s=-t.radius;
      for(
      let t=0
      ;t<6;t++)
      if(e[t].distanceToPoint(i)<s)
      return!1;
      return!0
      }intersectsBox(t){
      let e=this.planes;
      for(
      let i=0
      ;i<6;i++){
        let s=e[i];
        if(iH.x=s.normal.x>0?t.max.x:t.min.x,iH.y=s.normal.y>0?t.max.y:t.min.y,iH.z=s.normal.z>0?t.max.z:t.min.z,0>s.distanceToPoint(iH))
        return!1
        }
      return!0
      }containsPoint(t){
      let e=this.planes;
      for(
      let i=0
      ;i<6;i++)
      if(0>e[i].distanceToPoint(t))
      return!1;
      return!0
      }clone(){
      return new this.constructor().copy(this)
      }
  }
  let iY=new th,iZ=new iX;
  class i${
    constructor(){
      this.coordinateSystem=2e3
      }intersectsObject(t,e){
      if(!e.isArrayCamera||0===e.cameras.length)
      return!1;
      for(
      let i=0
      ;i<e.cameras.length;i++){
        let s=e.cameras[i];
        if(iY.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),iZ.setFromProjectionMatrix(iY,s.coordinateSystem,s.reversedDepth),iZ.intersectsObject(t))
        return!0
        }
      return!1
      }intersectsSprite(t,e){
      if(!e||!e.cameras||0===e.cameras.length)
      return!1;
      for(
      let i=0
      ;i<e.cameras.length;i++){
        let s=e.cameras[i];
        if(iY.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),iZ.setFromProjectionMatrix(iY,s.coordinateSystem,s.reversedDepth),iZ.intersectsSprite(t))
        return!0
        }
      return!1
      }intersectsSphere(t,e){
      if(!e||!e.cameras||0===e.cameras.length)
      return!1;
      for(
      let i=0
      ;i<e.cameras.length;i++){
        let s=e.cameras[i];
        if(iY.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),iZ.setFromProjectionMatrix(iY,s.coordinateSystem,s.reversedDepth),iZ.intersectsSphere(t))
        return!0
        }
      return!1
      }intersectsBox(t,e){
      if(!e||!e.cameras||0===e.cameras.length)
      return!1;
      for(
      let i=0
      ;i<e.cameras.length;i++){
        let s=e.cameras[i];
        if(iY.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),iZ.setFromProjectionMatrix(iY,s.coordinateSystem,s.reversedDepth),iZ.intersectsBox(t))
        return!0
        }
      return!1
      }containsPoint(t,e){
      if(!e||!e.cameras||0===e.cameras.length)
      return!1;
      for(
      let i=0
      ;i<e.cameras.length;i++){
        let s=e.cameras[i];
        if(iY.multiplyMatrices(s.projectionMatrix,s.matrixWorldInverse),iZ.setFromProjectionMatrix(iY,s.coordinateSystem,s.reversedDepth),iZ.containsPoint(t))
        return!0
        }
      return!1
      }clone(){
      return new i$
      }
  }
  function iQ(t,e){
    return t-e
    }
  function iK(t,e){
    return t.z-e.z
    }
  function i0(t,e){
    return e.z-t.z
    }
  let i1=new th,i2=new tj(1,1,1),i3=new iX,i5=new i$,i4=new t8,i6=new eA,i8=new D,i9=new D,i7=new D,st=new class{
    constructor(){
      this.index=0,this.pool=[],this.list=[]
      }push(t,e,i,s){
      let r=this.pool,n=this.list;
      this.index>=r.length&&r.push({start:-1,count:-1,z:-1,index:-1});
      let a=r[this.index];
      n.push(a),this.index++,a.start=t,a.count=e,a.z=i,a.index=s
      }reset(){
      this.list.length=0,this.index=0
      }
  },se=new im,si=[];
  function ss(t,e){
    if(t.constructor!==e.constructor){
      let i=Math.min(t.length,e.length);
      for(
      let s=0
      ;s<i;s++)
      e[s]=t[s]
      }else{
      let i=Math.min(t.length,e.length);
      e.set(new t.constructor(t.buffer,0,i))
      }
    }
  class sr extends im{
    constructor(t,e,i=2*e,s){
      super(new eR,s),this.isBatchedMesh=!0,this.perObjectFrustumCulled=!0,this.sortObjects=!0,this.boundingBox=null,this.boundingSphere=null,this.customSort=null,this._instanceInfo=[],this._geometryInfo=[],this._availableInstanceIds=[],this._availableGeometryIds=[],this._nextIndexStart=0,this._nextVertexStart=0,this._geometryCount=0,this._visibilityChanged=!0,this._geometryInitialized=!1,this._maxInstanceCount=t,this._maxVertexCount=e,this._maxIndexCount=i,this._multiDrawCounts=new Int32Array(t),this._multiDrawStarts=new Int32Array(t),this._multiDrawCount=0,this._matricesTexture=null,this._indirectTexture=null,this._colorsTexture=null,this._initMatricesTexture(),this._initIndirectTexture()
      }get maxInstanceCount(){
      return this._maxInstanceCount
      }get instanceCount(){
      return this._instanceInfo.length-this._availableInstanceIds.length
      }get unusedVertexCount(){
      return this._maxVertexCount-this._nextVertexStart
      }get unusedIndexCount(){
      return this._maxIndexCount-this._nextIndexStart
      }_initMatricesTexture(){
      let t=Math.sqrt(4*this._maxInstanceCount),e=new iI(new Float32Array((t=Math.max(t=4*Math.ceil(t/4),4))*t*4),t,t,1023,1015);
      this._matricesTexture=e
      }_initIndirectTexture(){
      let t=Math.sqrt(this._maxInstanceCount),e=new iI(new Uint32Array((t=Math.ceil(t))*t),t,t,1029,1014);
      this._indirectTexture=e
      }_initColorsTexture(){
      let t=Math.sqrt(this._maxInstanceCount),e=new iI(new Float32Array((t=Math.ceil(t))*t*4).fill(1),t,t,1023,1015);
      e.colorSpace=H.workingColorSpace,this._colorsTexture=e
      }_initializeGeometry(t){
      let e=this.geometry,i=this._maxVertexCount,s=this._maxIndexCount;
      if(!1===this._geometryInitialized){
        for(
        let s
         in t.attributes){
          let{array:r,itemSize:n,normalized:a}=t.getAttribute(s),o=new ex(new r.constructor(i*n),n,a);
          e.setAttribute(s,o)
          }
        if(null!==t.getIndex()){
          let t=i>65535?new Uint32Array(s):new Uint16Array(s);
          e.setIndex(new ex(t,1))
          }
        this._geometryInitialized=!0
        }
      }_validateGeometry(t){
      let e=this.geometry;
      if(!!t.getIndex()!=!!e.getIndex())
      throw Error('THREE.BatchedMesh: All geometries must consistently have "index".');
      for(
      let i
       in e.attributes){
        if(!t.hasAttribute(i))
        throw Error(`THREE.BatchedMesh: Added geometry missing "${i}". All geometries must have consistent attributes.`);
        let s=t.getAttribute(i),r=e.getAttribute(i);
        if(s.itemSize!==r.itemSize||s.normalized!==r.normalized)
        throw Error("THREE.BatchedMesh: All attributes must have a consistent itemSize and normalized value.")
        }
      }validateInstanceId(t){
      let e=this._instanceInfo;
      if(t<0||t>=e.length||!1===e[t].active)
      throw Error(`THREE.BatchedMesh: Invalid instanceId ${t}. Instance is either out of range or has been deleted.`)
      }validateGeometryId(t){
      let e=this._geometryInfo;
      if(t<0||t>=e.length||!1===e[t].active)
      throw Error(`THREE.BatchedMesh: Invalid geometryId ${t}. Geometry is either out of range or has been deleted.`)
      }setCustomSort(t){
      return this.customSort=t,this
      }computeBoundingBox(){
      null===this.boundingBox&&(this.boundingBox=new t8);
      let t=this.boundingBox,e=this._instanceInfo;
      t.makeEmpty();
      for(
      let i=0,s=e.length
      ;i<s;i++){
        if(!1===e[i].active)
        continue;
        let s=e[i].geometryIndex;
        this.getMatrixAt(i,i1),this.getBoundingBoxAt(s,i4).applyMatrix4(i1),t.union(i4)
        }
      }computeBoundingSphere(){
      null===this.boundingSphere&&(this.boundingSphere=new eA);
      let t=this.boundingSphere,e=this._instanceInfo;
      t.makeEmpty();
      for(
      let i=0,s=e.length
      ;i<s;i++){
        if(!1===e[i].active)
        continue;
        let s=e[i].geometryIndex;
        this.getMatrixAt(i,i1),this.getBoundingSphereAt(s,i6).applyMatrix4(i1),t.union(i6)
        }
      }addInstance(t){
      if(this._instanceInfo.length>=this.maxInstanceCount&&0===this._availableInstanceIds.length)
      throw Error("THREE.BatchedMesh: Maximum item count reached.");
      let e={visible:!0,active:!0,geometryIndex:t},i=null;
      this._availableInstanceIds.length>0?(this._availableInstanceIds.sort(iQ),i=this._availableInstanceIds.shift(),this._instanceInfo[i]=e):(i=this._instanceInfo.length,this._instanceInfo.push(e));
      let s=this._matricesTexture;
      i1.identity().toArray(s.image.data,16*i),s.needsUpdate=!0;
      let r=this._colorsTexture;
      return r&&(i2.toArray(r.image.data,4*i),r.needsUpdate=!0),this._visibilityChanged=!0,i
      }addGeometry(t,e=-1,i=-1){
      let s;
      this._initializeGeometry(t),this._validateGeometry(t);
      let r={vertexStart:-1,vertexCount:-1,reservedVertexCount:-1,indexStart:-1,indexCount:-1,reservedIndexCount:-1,start:-1,count:-1,boundingBox:null,boundingSphere:null,active:!0},n=this._geometryInfo;
      r.vertexStart=this._nextVertexStart,r.reservedVertexCount=-1===e?t.getAttribute("position").count:e;
      let a=t.getIndex();
      if(null!==a&&(r.indexStart=this._nextIndexStart,r.reservedIndexCount=-1===i?a.count:i),-1!==r.indexStart&&r.indexStart+r.reservedIndexCount>this._maxIndexCount||r.vertexStart+r.reservedVertexCount>this._maxVertexCount)
      throw Error("THREE.BatchedMesh: Reserved space request exceeds the maximum buffer size.");
      return this._availableGeometryIds.length>0?(this._availableGeometryIds.sort(iQ),n[s=this._availableGeometryIds.shift()]=r):(s=this._geometryCount,this._geometryCount++,n.push(r)),this.setGeometryAt(s,t),this._nextIndexStart=r.indexStart+r.reservedIndexCount,this._nextVertexStart=r.vertexStart+r.reservedVertexCount,s
      }setGeometryAt(t,e){
      if(t>=this._geometryCount)
      throw Error("THREE.BatchedMesh: Maximum geometry count reached.");
      this._validateGeometry(e);
      let i=this.geometry,s=null!==i.getIndex(),r=i.getIndex(),n=e.getIndex(),a=this._geometryInfo[t];
      if(s&&n.count>a.reservedIndexCount||e.attributes.position.count>a.reservedVertexCount)
      throw Error("THREE.BatchedMesh: Reserved space not large enough for provided geometry.");
      let o=a.vertexStart,h=a.reservedVertexCount;
      for(
      let t
       in a.vertexCount=e.getAttribute("position").count,i.attributes){
        let s=e.getAttribute(t),r=i.getAttribute(t);
        !function(t,e,i=0){
          let s=e.itemSize;
          if(t.isInterleavedBufferAttribute||t.array.constructor!==e.array.constructor){
            let r=t.count;
            for(
            let n=0
            ;n<r;n++)
            for(
            let r=0
            ;r<s;r++)
            e.setComponent(n+i,r,t.getComponent(n,r))
            }else 
          e.array.set(t.array,i*s);
          e.needsUpdate=!0
          }(s,r,o);
        let n=s.itemSize;
        for(
        let t=s.count
        ;t<h;t++){
          let e=o+t;
          for(
          let t=0
          ;t<n;t++)
          r.setComponent(e,t,0)
          }
        r.needsUpdate=!0,r.addUpdateRange(o*n,h*n)
        }
      if(s){
        let t=a.indexStart,i=a.reservedIndexCount;
        a.indexCount=e.getIndex().count;
        for(
        let e=0
        ;e<n.count;e++)
        r.setX(t+e,o+n.getX(e));
        for(
        let e=n.count
        ;e<i;e++)
        r.setX(t+e,o);
        r.needsUpdate=!0,r.addUpdateRange(t,a.reservedIndexCount)
        }
      return a.start=s?a.indexStart:a.vertexStart,a.count=s?a.indexCount:a.vertexCount,a.boundingBox=null,null!==e.boundingBox&&(a.boundingBox=e.boundingBox.clone()),a.boundingSphere=null,null!==e.boundingSphere&&(a.boundingSphere=e.boundingSphere.clone()),this._visibilityChanged=!0,t
      }deleteGeometry(t){
      let e=this._geometryInfo;
      if(t>=e.length||!1===e[t].active)
      return this;
      let i=this._instanceInfo;
      for(
      let e=0,s=i.length
      ;e<s;e++)
      i[e].active&&i[e].geometryIndex===t&&this.deleteInstance(e);
      return e[t].active=!1,this._availableGeometryIds.push(t),this._visibilityChanged=!0,this
      }deleteInstance(t){
      return this.validateInstanceId(t),this._instanceInfo[t].active=!1,this._availableInstanceIds.push(t),this._visibilityChanged=!0,this
      }optimize(){
      let t=0,e=0,i=this._geometryInfo,s=i.map((t,e)=>e).sort((t,e)=>i[t].vertexStart-i[e].vertexStart),r=this.geometry;
      for(
      let n=0,a=i.length
      ;n<a;n++){
        let a=i[s[n]];
        if(!1!==a.active){
          if(null!==r.index){
            if(a.indexStart!==e){
              let{indexStart:i,vertexStart:s,reservedIndexCount:n}=a,o=r.index,h=o.array,l=t-s;
              for(
              let t=i
              ;t<i+n;t++)
              h[t]=h[t]+l;
              o.array.copyWithin(e,i,i+n),o.addUpdateRange(e,n),o.needsUpdate=!0,a.indexStart=e
              }
            e+=a.reservedIndexCount
            }
          if(a.vertexStart!==t){
            let{vertexStart:e,reservedVertexCount:i}=a,s=r.attributes;
            for(
            let r
             in s){
              let n=s[r],{array:a,itemSize:o}=n;
              a.copyWithin(t*o,e*o,(e+i)*o),n.addUpdateRange(t*o,i*o),n.needsUpdate=!0
              }
            a.vertexStart=t
            }
          t+=a.reservedVertexCount,a.start=r.index?a.indexStart:a.vertexStart
          }
        }
      return this._nextIndexStart=e,this._nextVertexStart=t,this._visibilityChanged=!0,this
      }getBoundingBoxAt(t,e){
      if(t>=this._geometryCount)
      return null;
      let i=this.geometry,s=this._geometryInfo[t];
      if(null===s.boundingBox){
        let t=new t8,e=i.index,r=i.attributes.position;
        for(
        let i=s.start,n=s.start+s.count
        ;i<n;i++){
          let s=i;
          e&&(s=e.getX(s)),t.expandByPoint(i8.fromBufferAttribute(r,s))
          }
        s.boundingBox=t
        }
      return e.copy(s.boundingBox),e
      }getBoundingSphereAt(t,e){
      if(t>=this._geometryCount)
      return null;
      let i=this.geometry,s=this._geometryInfo[t];
      if(null===s.boundingSphere){
        let e=new eA;
        this.getBoundingBoxAt(t,i4),i4.getCenter(e.center);
        let r=i.index,n=i.attributes.position,a=0;
        for(
        let t=s.start,i=s.start+s.count
        ;t<i;t++){
          let i=t;
          r&&(i=r.getX(i)),i8.fromBufferAttribute(n,i),a=Math.max(a,e.center.distanceToSquared(i8))
          }
        e.radius=Math.sqrt(a),s.boundingSphere=e
        }
      return e.copy(s.boundingSphere),e
      }setMatrixAt(t,e){
      this.validateInstanceId(t);
      let i=this._matricesTexture,s=this._matricesTexture.image.data;
      return e.toArray(s,16*t),i.needsUpdate=!0,this
      }getMatrixAt(t,e){
      return this.validateInstanceId(t),e.fromArray(this._matricesTexture.image.data,16*t)
      }setColorAt(t,e){
      return this.validateInstanceId(t),null===this._colorsTexture&&this._initColorsTexture(),e.toArray(this._colorsTexture.image.data,4*t),this._colorsTexture.needsUpdate=!0,this
      }getColorAt(t,e){
      return(this.validateInstanceId(t),null!==this._colorsTexture)?e.fromArray(this._colorsTexture.image.data,4*t):e.isVector4?e.set(1,1,1,1):e.setRGB(1,1,1)
      }setVisibleAt(t,e){
      return this.validateInstanceId(t),this._instanceInfo[t].visible===e||(this._instanceInfo[t].visible=e,this._visibilityChanged=!0),this
      }getVisibleAt(t){
      return this.validateInstanceId(t),this._instanceInfo[t].visible
      }setGeometryIdAt(t,e){
      return this.validateInstanceId(t),this.validateGeometryId(e),this._instanceInfo[t].geometryIndex=e,this
      }getGeometryIdAt(t){
      return this.validateInstanceId(t),this._instanceInfo[t].geometryIndex
      }getGeometryRangeAt(t,e={}){
      this.validateGeometryId(t);
      let i=this._geometryInfo[t];
      return e.vertexStart=i.vertexStart,e.vertexCount=i.vertexCount,e.reservedVertexCount=i.reservedVertexCount,e.indexStart=i.indexStart,e.indexCount=i.indexCount,e.reservedIndexCount=i.reservedIndexCount,e.start=i.start,e.count=i.count,e
      }setInstanceCount(t){
      let e=this._availableInstanceIds,i=this._instanceInfo;
      for(e.sort(iQ);e[e.length-1]===i.length-1;)
      i.pop(),e.pop();
      if(t<i.length)
      throw Error(`BatchedMesh: Instance ids outside the range ${t} are being used. Cannot shrink instance count.`);
      let s=new Int32Array(t),r=new Int32Array(t);
      ss(this._multiDrawCounts,s),ss(this._multiDrawStarts,r),this._multiDrawCounts=s,this._multiDrawStarts=r,this._maxInstanceCount=t;
      let n=this._indirectTexture,a=this._matricesTexture,o=this._colorsTexture;
      n.dispose(),this._initIndirectTexture(),ss(n.image.data,this._indirectTexture.image.data),a.dispose(),this._initMatricesTexture(),ss(a.image.data,this._matricesTexture.image.data),o&&(o.dispose(),this._initColorsTexture(),ss(o.image.data,this._colorsTexture.image.data))
      }setGeometrySize(t,e){
      let i=[...this._geometryInfo].filter(t=>t.active);
      if(Math.max(...i.map(t=>t.vertexStart+t.reservedVertexCount))>t)
      throw Error(`BatchedMesh: Geometry vertex values are being used outside the range ${e}. Cannot shrink further.`);
      if(this.geometry.index&&Math.max(...i.map(t=>t.indexStart+t.reservedIndexCount))>e)
      throw Error(`BatchedMesh: Geometry index values are being used outside the range ${e}. Cannot shrink further.`);
      let s=this.geometry;
      s.dispose(),this._maxVertexCount=t,this._maxIndexCount=e,this._geometryInitialized&&(this._geometryInitialized=!1,this.geometry=new eR,this._initializeGeometry(s));
      let r=this.geometry;
      for(
      let t
       in s.index&&ss(s.index.array,r.index.array),s.attributes)
      ss(s.attributes[t].array,r.attributes[t].array)
      }raycast(t,e){
      let i=this._instanceInfo,s=this._geometryInfo,r=this.matrixWorld,n=this.geometry;
      se.material=this.material,se.geometry.index=n.index,se.geometry.attributes=n.attributes,null===se.geometry.boundingBox&&(se.geometry.boundingBox=new t8),null===se.geometry.boundingSphere&&(se.geometry.boundingSphere=new eA);
      for(
      let n=0,a=i.length
      ;n<a;n++){
        if(!i[n].visible||!i[n].active)
        continue;
        let a=i[n].geometryIndex,o=s[a];
        se.geometry.setDrawRange(o.start,o.count),this.getMatrixAt(n,se.matrixWorld).premultiply(r),this.getBoundingBoxAt(a,se.geometry.boundingBox),this.getBoundingSphereAt(a,se.geometry.boundingSphere),se.raycast(t,si);
        for(
        let t=0,i=si.length
        ;t<i;t++){
          let i=si[t];
          i.object=this,i.batchId=n,e.push(i)
          }
        si.length=0
        }
      se.material=null,se.geometry.index=null,se.geometry.attributes={},se.geometry.setDrawRange(0,1/0)
      }copy(t){
      return super.copy(t),this.geometry=t.geometry.clone(),this.perObjectFrustumCulled=t.perObjectFrustumCulled,this.sortObjects=t.sortObjects,this.boundingBox=null!==t.boundingBox?t.boundingBox.clone():null,this.boundingSphere=null!==t.boundingSphere?t.boundingSphere.clone():null,this._geometryInfo=t._geometryInfo.map(t=>({...t,boundingBox:null!==t.boundingBox?t.boundingBox.clone():null,boundingSphere:null!==t.boundingSphere?t.boundingSphere.clone():null})),this._instanceInfo=t._instanceInfo.map(t=>({...t})),this._availableInstanceIds=t._availableInstanceIds.slice(),this._availableGeometryIds=t._availableGeometryIds.slice(),this._nextIndexStart=t._nextIndexStart,this._nextVertexStart=t._nextVertexStart,this._geometryCount=t._geometryCount,this._maxInstanceCount=t._maxInstanceCount,this._maxVertexCount=t._maxVertexCount,this._maxIndexCount=t._maxIndexCount,this._geometryInitialized=t._geometryInitialized,this._multiDrawCounts=t._multiDrawCounts.slice(),this._multiDrawStarts=t._multiDrawStarts.slice(),this._indirectTexture=t._indirectTexture.clone(),this._indirectTexture.image.data=this._indirectTexture.image.data.slice(),this._matricesTexture=t._matricesTexture.clone(),this._matricesTexture.image.data=this._matricesTexture.image.data.slice(),null!==this._colorsTexture&&(this._colorsTexture=t._colorsTexture.clone(),this._colorsTexture.image.data=this._colorsTexture.image.data.slice()),this
      }dispose(){
      this.geometry.dispose(),this._matricesTexture.dispose(),this._matricesTexture=null,this._indirectTexture.dispose(),this._indirectTexture=null,null!==this._colorsTexture&&(this._colorsTexture.dispose(),this._colorsTexture=null)
      }onBeforeRender(t,e,i,s,r){
      if(!this._visibilityChanged&&!this.perObjectFrustumCulled&&!this.sortObjects)
      return;
      let n=s.getIndex(),a=null===n?1:n.array.BYTES_PER_ELEMENT,o=1;
      r.wireframe&&(o=2,a=s.attributes.position.count>65535?4:2);
      let h=this._instanceInfo,l=this._multiDrawStarts,u=this._multiDrawCounts,c=this._geometryInfo,p=this.perObjectFrustumCulled,d=this._indirectTexture,m=d.image.data,y=i.isArrayCamera?i5:i3;
      p&&!i.isArrayCamera&&(i1.multiplyMatrices(i.projectionMatrix,i.matrixWorldInverse).multiply(this.matrixWorld),i3.setFromProjectionMatrix(i1,i.coordinateSystem,i.reversedDepth));
      let f=0;
      if(this.sortObjects){
        i1.copy(this.matrixWorld).invert(),i8.setFromMatrixPosition(i.matrixWorld).applyMatrix4(i1),i9.set(0,0,-1).transformDirection(i.matrixWorld).transformDirection(i1);
        for(
        let t=0,e=h.length
        ;t<e;t++)
        if(h[t].visible&&h[t].active){
          let e=h[t].geometryIndex;
          this.getMatrixAt(t,i1),this.getBoundingSphereAt(e,i6).applyMatrix4(i1);
          let s=!1;
          if(p&&(s=!y.intersectsSphere(i6,i)),!s){
            let i=c[e],s=i7.subVectors(i6.center,i8).dot(i9);
            st.push(i.start,i.count,s,t)
            }
          }
        let t=st.list,e=this.customSort;
        null===e?t.sort(r.transparent?i0:iK):e.call(this,t,i);
        for(
        let e=0,i=t.length
        ;e<i;e++){
          let i=t[e];
          l[f]=i.start*a*o,u[f]=i.count*o,m[f]=i.index,f++
          }
        st.reset()
        }else 
      for(
      let t=0,e=h.length
      ;t<e;t++)
      if(h[t].visible&&h[t].active){
        let e=h[t].geometryIndex,s=!1;
        if(p&&(this.getMatrixAt(t,i1),this.getBoundingSphereAt(e,i6).applyMatrix4(i1),s=!y.intersectsSphere(i6,i)),!s){
          let i=c[e];
          l[f]=i.start*a*o,u[f]=i.count*o,m[f]=t,f++
          }
        }
      d.needsUpdate=!0,this._multiDrawCount=f,this._visibilityChanged=!1
      }onBeforeShadow(t,e,i,s,r,n){
      this.onBeforeRender(t,null,s,r,n)
      }
  }
  class sn extends eE{
    constructor(t){
      super(),this.isLineBasicMaterial=!0,this.type="LineBasicMaterial",this.color=new tj(0xffffff),this.map=null,this.linewidth=1,this.linecap="round",this.linejoin="round",this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.map=t.map,this.linewidth=t.linewidth,this.linecap=t.linecap,this.linejoin=t.linejoin,this.fog=t.fog,this
      }
  }
  let sa=new D,so=new D,sh=new th,sl=new it,su=new eA,sc=new D,sp=new D;
  class sd extends tF{
    constructor(t=new eR,e=new sn){
      super(),this.isLine=!0,this.type="Line",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()
      }copy(t,e){
      return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this
      }computeLineDistances(){
      let t=this.geometry;
      if(null===t.index){
        let e=t.attributes.position,i=[0];
        for(
        let t=1,s=e.count
        ;t<s;t++)
        sa.fromBufferAttribute(e,t-1),so.fromBufferAttribute(e,t),i[t]=i[t-1],i[t]+=sa.distanceTo(so);
        t.setAttribute("lineDistance",new eM(i,1))
        }else 
      _("Line.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
      return this
      }raycast(t,e){
      let i=this.geometry,s=this.matrixWorld,r=t.params.Line.threshold,n=i.drawRange;
      if(null===i.boundingSphere&&i.computeBoundingSphere(),su.copy(i.boundingSphere),su.applyMatrix4(s),su.radius+=r,!1===t.ray.intersectsSphere(su))
      return;
      sh.copy(s).invert(),sl.copy(t.ray).applyMatrix4(sh);
      let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),o=a*a,h=this.isLineSegments?2:1,l=i.index,u=i.attributes.position;
      if(null!==l){
        let i=Math.max(0,n.start),s=Math.min(l.count,n.start+n.count);
        for(
        let r=i,n=s-1
        ;r<n;r+=h){
          let i=sm(this,t,sl,o,l.getX(r),l.getX(r+1),r);
          i&&e.push(i)
          }
        if(this.isLineLoop){
          let r=sm(this,t,sl,o,l.getX(s-1),l.getX(i),s-1);
          r&&e.push(r)
          }
        }else{
        let i=Math.max(0,n.start),s=Math.min(u.count,n.start+n.count);
        for(
        let r=i,n=s-1
        ;r<n;r+=h){
          let i=sm(this,t,sl,o,r,r+1,r);
          i&&e.push(i)
          }
        if(this.isLineLoop){
          let r=sm(this,t,sl,o,s-1,i,s-1);
          r&&e.push(r)
          }
        }
      }updateMorphTargets(){
      let t=this.geometry.morphAttributes,e=Object.keys(t);
      if(e.length>0){
        let i=t[e[0]];
        if(void 0!==i){
          this.morphTargetInfluences=[],this.morphTargetDictionary={};
          for(
          let t=0,e=i.length
          ;t<e;t++){
            let e=i[t].name||String(t);
            this.morphTargetInfluences.push(0),this.morphTargetDictionary[e]=t
            }
          }
        }
      }
  }
  function sm(t,e,i,s,r,n,a){
    let o=t.geometry.attributes.position;
    if(sa.fromBufferAttribute(o,r),so.fromBufferAttribute(o,n),i.distanceSqToSegment(sa,so,sc,sp)>s)
    return;
    sc.applyMatrix4(t.matrixWorld);
    let h=e.ray.origin.distanceTo(sc);
    if(!(h<e.near)&&!(h>e.far))
    return{distance:h,point:sp.clone().applyMatrix4(t.matrixWorld),index:a,face:null,faceIndex:null,barycoord:null,object:t}
    }
  let sy=new D,sf=new D;
  class sg extends sd{
    constructor(t,e){
      super(t,e),this.isLineSegments=!0,this.type="LineSegments"
      }computeLineDistances(){
      let t=this.geometry;
      if(null===t.index){
        let e=t.attributes.position,i=[];
        for(
        let t=0,s=e.count
        ;t<s;t+=2)
        sy.fromBufferAttribute(e,t),sf.fromBufferAttribute(e,t+1),i[t]=0===t?0:i[t-1],i[t+1]=i[t]+sy.distanceTo(sf);
        t.setAttribute("lineDistance",new eM(i,1))
        }else 
      _("LineSegments.computeLineDistances(): Computation only possible with non-indexed BufferGeometry.");
      return this
      }
  }
  class sx extends sd{
    constructor(t,e){
      super(t,e),this.isLineLoop=!0,this.type="LineLoop"
      }
  }
  class sb extends eE{
    constructor(t){
      super(),this.isPointsMaterial=!0,this.type="PointsMaterial",this.color=new tj(0xffffff),this.map=null,this.alphaMap=null,this.size=1,this.sizeAttenuation=!0,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.map=t.map,this.alphaMap=t.alphaMap,this.size=t.size,this.sizeAttenuation=t.sizeAttenuation,this.fog=t.fog,this
      }
  }
  let sv=new th,sM=new it,sw=new eA,sS=new D;
  class s_ extends tF{
    constructor(t=new eR,e=new sb){
      super(),this.isPoints=!0,this.type="Points",this.geometry=t,this.material=e,this.morphTargetDictionary=void 0,this.morphTargetInfluences=void 0,this.updateMorphTargets()
      }copy(t,e){
      return super.copy(t,e),this.material=Array.isArray(t.material)?t.material.slice():t.material,this.geometry=t.geometry,this
      }raycast(t,e){
      let i=this.geometry,s=this.matrixWorld,r=t.params.Points.threshold,n=i.drawRange;
      if(null===i.boundingSphere&&i.computeBoundingSphere(),sw.copy(i.boundingSphere),sw.applyMatrix4(s),sw.radius+=r,!1===t.ray.intersectsSphere(sw))
      return;
      sv.copy(s).invert(),sM.copy(t.ray).applyMatrix4(sv);
      let a=r/((this.scale.x+this.scale.y+this.scale.z)/3),o=a*a,h=i.index,l=i.attributes.position;
      if(null!==h){
        let i=Math.max(0,n.start),r=Math.min(h.count,n.start+n.count);
        for(
        let n=i
        ;n<r;n++){
          let i=h.getX(n);
          sS.fromBufferAttribute(l,i),sA(sS,i,o,s,t,e,this)
          }
        }else{
        let i=Math.max(0,n.start),r=Math.min(l.count,n.start+n.count);
        for(
        let n=i
        ;n<r;n++)
        sS.fromBufferAttribute(l,n),sA(sS,n,o,s,t,e,this)
        }
      }updateMorphTargets(){
      let t=this.geometry.morphAttributes,e=Object.keys(t);
      if(e.length>0){
        let i=t[e[0]];
        if(void 0!==i){
          this.morphTargetInfluences=[],this.morphTargetDictionary={};
          for(
          let t=0,e=i.length
          ;t<e;t++){
            let e=i[t].name||String(t);
            this.morphTargetInfluences.push(0),this.morphTargetDictionary[e]=t
            }
          }
        }
      }
  }
  function sA(t,e,i,s,r,n,a){
    let o=sM.distanceSqToPoint(t);
    if(o<i){
      let i=new D;
      sM.closestPointToPoint(t,i),i.applyMatrix4(s);
      let h=r.ray.origin.distanceTo(i);
      if(h<r.near||h>r.far)
      return;
      n.push({distance:h,distanceToRay:Math.sqrt(o),point:i,index:e,face:null,faceIndex:null,barycoord:null,object:a})
      }
    }
  class sT extends ti{
    constructor(t,e,i,s,r=1006,n=1006,a,o,h){
      super(t,e,i,s,r,n,a,o,h),this.isVideoTexture=!0,this.generateMipmaps=!1,this._requestVideoFrameCallbackId=0;
      const l=this;
      "requestVideoFrameCallback"in t&&(this._requestVideoFrameCallbackId=t.requestVideoFrameCallback(function e(){
        l.needsUpdate=!0,l._requestVideoFrameCallbackId=t.requestVideoFrameCallback(e)
        }))
      }clone(){
      return new this.constructor(this.image).copy(this)
      }update(){
      let t=this.image;
      !1=="requestVideoFrameCallback"in t&&t.readyState>=t.HAVE_CURRENT_DATA&&(this.needsUpdate=!0)
      }dispose(){
      0!==this._requestVideoFrameCallbackId&&(this.source.data.cancelVideoFrameCallback(this._requestVideoFrameCallbackId),this._requestVideoFrameCallbackId=0),super.dispose()
      }
  }
  class sC extends ti{
    constructor(t,e,i,s,r,n,a,o,h,l,u,c){
      super(null,n,a,o,h,l,s,r,u,c),this.isCompressedTexture=!0,this.image={width:e,height:i},this.mipmaps=t,this.flipY=!1,this.generateMipmaps=!1
      }
  }
  class sI extends ti{
    constructor(t=[],e=301,i,s,r,n,a,o,h,l){
      super(t,e,i,s,r,n,a,o,h,l),this.isCubeTexture=!0,this.flipY=!1
      }get images(){
      return this.image
      }set images(t){
      this.image=t
      }
  }
  class sz extends ti{
    constructor(t,e,i=1014,s,r,n,a=1003,o=1003,h,l=1026,u=1){
      if(1026!==l&&1027!==l)
      throw Error("DepthTexture format must be either THREE.DepthFormat or THREE.DepthStencilFormat");
      super({width:t,height:e,depth:u},s,r,n,a,o,l,i,h),this.isDepthTexture=!0,this.flipY=!1,this.generateMipmaps=!1,this.compareFunction=null
      }copy(t){
      return super.copy(t),this.source=new Q(Object.assign({},t.image)),this.compareFunction=t.compareFunction,this
      }toJSON(t){
      let e=super.toJSON(t);
      return null!==this.compareFunction&&(e.compareFunction=this.compareFunction),e
      }
  }
  class sB extends eR{
    constructor(t=1,e=1,i=1,s=1,r=1,n=1){
      super(),this.type="BoxGeometry",this.parameters={width:t,height:e,depth:i,widthSegments:s,heightSegments:r,depthSegments:n};
      const a=this;
      s=Math.floor(s),r=Math.floor(r);
      const o=[],h=[],l=[],u=[];
      let c=0,p=0;
      function d(t,e,i,s,r,n,d,m,y,f,g){
        let x=n/y,b=d/f,v=n/2,M=d/2,w=m/2,S=y+1,_=f+1,A=0,T=0,C=new D;
        for(
        let n=0
        ;n<_;n++){
          let a=n*b-M;
          for(
          let o=0
          ;o<S;o++){
            let c=o*x-v;
            C[t]=c*s,C[e]=a*r,C[i]=w,h.push(C.x,C.y,C.z),C[t]=0,C[e]=0,C[i]=m>0?1:-1,l.push(C.x,C.y,C.z),u.push(o/y),u.push(1-n/f),A+=1
            }
          }
        for(
        let t=0
        ;t<f;t++)
        for(
        let e=0
        ;e<y;e++){
          let i=c+e+S*t,s=c+e+S*(t+1),r=c+(e+1)+S*(t+1),n=c+(e+1)+S*t;
          o.push(i,s,n),o.push(s,r,n),T+=6
          }
        a.addGroup(p,T,g),p+=T,c+=A
        }
      d("z","y","x",-1,-1,i,e,t,n=Math.floor(n),r,0),d("z","y","x",1,-1,i,e,-t,n,r,1),d("x","z","y",1,1,t,i,e,s,n,2),d("x","z","y",1,-1,t,i,-e,s,n,3),d("x","y","z",1,-1,t,e,i,s,r,4),d("x","y","z",-1,-1,t,e,-i,s,r,5),this.setIndex(o),this.setAttribute("position",new eM(h,3)),this.setAttribute("normal",new eM(l,3)),this.setAttribute("uv",new eM(u,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new sB(t.width,t.height,t.depth,t.widthSegments,t.heightSegments,t.depthSegments)
      }
  }
  class sk extends eR{
    constructor(t=1,e=1,i=4,s=8,r=1){
      super(),this.type="CapsuleGeometry",this.parameters={radius:t,height:e,capSegments:i,radialSegments:s,heightSegments:r},e=Math.max(0,e),i=Math.max(1,Math.floor(i)),s=Math.max(3,Math.floor(s));
      const n=[],a=[],o=[],h=[],l=e/2,u=Math.PI/2*t,c=e,p=2*u+c,d=2*i+(r=Math.max(1,Math.floor(r))),m=s+1,y=new D,f=new D;
      for(
      let g=0
      ;g<=d;g++){
        let x=0,b=0,v=0,M=0;
        if(g<=i){
          const e=g/i,s=e*Math.PI/2;
          b=-l-t*Math.cos(s),v=t*Math.sin(s),M=-t*Math.cos(s),x=e*u
          }else 
        if(g<=i+r){
          const s=(g-i)/r;
          b=-l+s*e,v=t,M=0,x=u+s*c
          }else{
          const e=(g-i-r)/i,s=e*Math.PI/2;
          b=l+t*Math.sin(s),v=t*Math.cos(s),M=t*Math.sin(s),x=u+c+e*u
          }
        const w=Math.max(0,Math.min(1,x/p));
        let S=0;
        0===g?S=.5/s:g===d&&(S=-.5/s);
        for(
        let t=0
        ;t<=s;t++){
          const e=t/s,i=e*Math.PI*2,r=Math.sin(i),n=Math.cos(i);
          f.x=-v*n,f.y=b,f.z=v*r,a.push(f.x,f.y,f.z),y.set(-v*n,M,v*r),y.normalize(),o.push(y.x,y.y,y.z),h.push(e+S,w)
          }
        if(g>0){
          const t=(g-1)*m;
          for(
          let e=0
          ;e<s;e++){
            const i=t+e,s=t+e+1,r=g*m+e,a=g*m+e+1;
            n.push(i,s,r),n.push(s,a,r)
            }
          }
        }
      this.setIndex(n),this.setAttribute("position",new eM(a,3)),this.setAttribute("normal",new eM(o,3)),this.setAttribute("uv",new eM(h,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new sk(t.radius,t.height,t.capSegments,t.radialSegments,t.heightSegments)
      }
  }
  class sO extends eR{
    constructor(t=1,e=32,i=0,s=2*Math.PI){
      super(),this.type="CircleGeometry",this.parameters={radius:t,segments:e,thetaStart:i,thetaLength:s},e=Math.max(3,e);
      const r=[],n=[],a=[],o=[],h=new D,l=new E;
      n.push(0,0,0),a.push(0,0,1),o.push(.5,.5);
      for(
      let r=0,u=3
      ;r<=e;r++,u+=3){
        const c=i+r/e*s;
        h.x=t*Math.cos(c),h.y=t*Math.sin(c),n.push(h.x,h.y,h.z),a.push(0,0,1),l.x=(n[u]/t+1)/2,l.y=(n[u+1]/t+1)/2,o.push(l.x,l.y)
        }
      for(
      let t=1
      ;t<=e;t++)
      r.push(t,t+1,0);
      this.setIndex(r),this.setAttribute("position",new eM(n,3)),this.setAttribute("normal",new eM(a,3)),this.setAttribute("uv",new eM(o,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new sO(t.radius,t.segments,t.thetaStart,t.thetaLength)
      }
  }
  class sR extends eR{
    constructor(t=1,e=1,i=1,s=32,r=1,n=!1,a=0,o=2*Math.PI){
      super(),this.type="CylinderGeometry",this.parameters={radiusTop:t,radiusBottom:e,height:i,radialSegments:s,heightSegments:r,openEnded:n,thetaStart:a,thetaLength:o};
      const h=this;
      s=Math.floor(s),r=Math.floor(r);
      const l=[],u=[],c=[],p=[];
      let d=0;
      const m=[],y=i/2;
      let f=0;
      function g(i){
        let r=d,n=new E,m=new D,g=0,x=!0===i?t:e,b=!0===i?1:-1;
        for(
        let t=1
        ;t<=s;t++)
        u.push(0,y*b,0),c.push(0,b,0),p.push(.5,.5),d++;
        let v=d;
        for(
        let t=0
        ;t<=s;t++){
          let e=t/s*o+a,i=Math.cos(e),r=Math.sin(e);
          m.x=x*r,m.y=y*b,m.z=x*i,u.push(m.x,m.y,m.z),c.push(0,b,0),n.x=.5*i+.5,n.y=.5*r*b+.5,p.push(n.x,n.y),d++
          }
        for(
        let t=0
        ;t<s;t++){
          let e=r+t,s=v+t;
          !0===i?l.push(s,s+1,e):l.push(s+1,s,e),g+=3
          }
        h.addGroup(f,g,!0===i?1:2),f+=g
        }
      (function(){
        let n=new D,g=new D,x=0,b=(e-t)/i;
        for(
        let h=0
        ;h<=r;h++){
          let l=[],f=h/r,x=f*(e-t)+t;
          for(
          let t=0
          ;t<=s;t++){
            let e=t/s,r=e*o+a,h=Math.sin(r),m=Math.cos(r);
            g.x=x*h,g.y=-f*i+y,g.z=x*m,u.push(g.x,g.y,g.z),n.set(h,b,m).normalize(),c.push(n.x,n.y,n.z),p.push(e,1-f),l.push(d++)
            }
          m.push(l)
          }
        for(
        let i=0
        ;i<s;i++)
        for(
        let s=0
        ;s<r;s++){
          let n=m[s][i],a=m[s+1][i],o=m[s+1][i+1],h=m[s][i+1];
          (t>0||0!==s)&&(l.push(n,a,h),x+=3),(e>0||s!==r-1)&&(l.push(a,o,h),x+=3)
          }
        h.addGroup(f,x,0),f+=x
        })(),!1===n&&(t>0&&g(!0),e>0&&g(!1)),this.setIndex(l),this.setAttribute("position",new eM(u,3)),this.setAttribute("normal",new eM(c,3)),this.setAttribute("uv",new eM(p,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new sR(t.radiusTop,t.radiusBottom,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)
      }
  }
  class sP extends sR{
    constructor(t=1,e=1,i=32,s=1,r=!1,n=0,a=2*Math.PI){
      super(0,t,e,i,s,r,n,a),this.type="ConeGeometry",this.parameters={radius:t,height:e,radialSegments:i,heightSegments:s,openEnded:r,thetaStart:n,thetaLength:a}
      }static fromJSON(t){
      return new sP(t.radius,t.height,t.radialSegments,t.heightSegments,t.openEnded,t.thetaStart,t.thetaLength)
      }
  }
  class sF extends eR{
    constructor(t=[],e=[],i=1,s=0){
      super(),this.type="PolyhedronGeometry",this.parameters={vertices:t,indices:e,radius:i,detail:s};
      const r=[],n=[];
      function a(t){
        r.push(t.x,t.y,t.z)
        }
      function o(e,i){
        let s=3*e;
        i.x=t[s+0],i.y=t[s+1],i.z=t[s+2]
        }
      function h(t,e,i,s){
        s<0&&1===t.x&&(n[e]=t.x-1),0===i.x&&0===i.z&&(n[e]=s/2/Math.PI+.5)
        }
      function l(t){
        return Math.atan2(t.z,-t.x)
        }
      (function(t){
        let i=new D,s=new D,r=new D;
        for(
        let n=0
        ;n<e.length;n+=3)
        o(e[n+0],i),o(e[n+1],s),o(e[n+2],r),function(t,e,i,s){
          let r=s+1,n=[];
          for(
          let s=0
          ;s<=r;s++){
            n[s]=[];
            let a=t.clone().lerp(i,s/r),o=e.clone().lerp(i,s/r),h=r-s;
            for(
            let t=0
            ;t<=h;t++)
            0===t&&s===r?n[s][t]=a:n[s][t]=a.clone().lerp(o,t/h)
            }
          for(
          let t=0
          ;t<r;t++)
          for(
          let e=0
          ;e<2*(r-t)-1;e++){
            let i=Math.floor(e/2);
            e%2==0?(a(n[t][i+1]),a(n[t+1][i]),a(n[t][i])):(a(n[t][i+1]),a(n[t+1][i+1]),a(n[t+1][i]))
            }
          }(i,s,r,t)
        })(s),function(t){
        let e=new D;
        for(
        let i=0
        ;i<r.length;i+=3)
        e.x=r[i+0],e.y=r[i+1],e.z=r[i+2],e.normalize().multiplyScalar(t),r[i+0]=e.x,r[i+1]=e.y,r[i+2]=e.z
        }(i),function(){
        let t=new D;
        for(
        let i=0
        ;i<r.length;i+=3){
          var e;
          t.x=r[i+0],t.y=r[i+1],t.z=r[i+2];
          let s=l(t)/2/Math.PI+.5,a=Math.atan2(-(e=t).y,Math.sqrt(e.x*e.x+e.z*e.z))/Math.PI+.5;
          n.push(s,1-a)
          }
        (function(){
          let t=new D,e=new D,i=new D,s=new D,a=new E,o=new E,u=new E;
          for(
          let c=0,p=0
          ;c<r.length;c+=9,p+=6){
            t.set(r[c+0],r[c+1],r[c+2]),e.set(r[c+3],r[c+4],r[c+5]),i.set(r[c+6],r[c+7],r[c+8]),a.set(n[p+0],n[p+1]),o.set(n[p+2],n[p+3]),u.set(n[p+4],n[p+5]),s.copy(t).add(e).add(i).divideScalar(3);
            let d=l(s);
            h(a,p+0,t,d),h(o,p+2,e,d),h(u,p+4,i,d)
            }
          })(),function(){
          for(
          let t=0
          ;t<n.length;t+=6){
            let e=n[t+0],i=n[t+2],s=n[t+4],r=Math.max(e,i,s),a=Math.min(e,i,s);
            r>.9&&a<.1&&(e<.2&&(n[t+0]+=1),i<.2&&(n[t+2]+=1),s<.2&&(n[t+4]+=1))
            }
          }()
        }(),this.setAttribute("position",new eM(r,3)),this.setAttribute("normal",new eM(r.slice(),3)),this.setAttribute("uv",new eM(n,2)),0===s?this.computeVertexNormals():this.normalizeNormals()
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new sF(t.vertices,t.indices,t.radius,t.detail)
      }
  }
  class sL extends sF{
    constructor(t=1,e=0){
      const i=(1+Math.sqrt(5))/2,s=1/i;
      super([-1,-1,-1,-1,-1,1,-1,1,-1,-1,1,1,1,-1,-1,1,-1,1,1,1,-1,1,1,1,0,-s,-i,0,-s,i,0,s,-i,0,s,i,-s,-i,0,-s,i,0,s,-i,0,s,i,0,-i,0,-s,i,0,-s,-i,0,s,i,0,s],[3,11,7,3,7,15,3,15,13,7,19,17,7,17,6,7,6,15,17,4,8,17,8,10,17,10,6,8,0,16,8,16,2,8,2,10,0,12,1,0,1,18,0,18,16,6,10,2,6,2,13,6,13,15,2,16,18,2,18,3,2,3,13,18,1,9,18,9,11,18,11,3,4,14,12,4,12,0,4,0,8,11,9,5,11,5,19,11,19,7,19,5,14,19,14,4,19,4,17,1,12,14,1,14,5,1,5,9],t,e),this.type="DodecahedronGeometry",this.parameters={radius:t,detail:e}
      }static fromJSON(t){
      return new sL(t.radius,t.detail)
      }
  }
  let sN=new D,sE=new D,sV=new D,sD=new t6;
  class sU extends eR{
    constructor(t=null,e=1){
      if(super(),this.type="EdgesGeometry",this.parameters={geometry:t,thresholdAngle:e},null!==t){
        const i=Math.cos(B*e),s=t.getIndex(),r=t.getAttribute("position"),n=s?s.count:r.count,a=[0,0,0],o=["a","b","c"],h=[,,,],l={},u=[];
        for(
        let t=0
        ;t<n;t+=3){
          s?(a[0]=s.getX(t),a[1]=s.getX(t+1),a[2]=s.getX(t+2)):(a[0]=t,a[1]=t+1,a[2]=t+2);
          const{a:e,b:n,c}=sD;
          if(e.fromBufferAttribute(r,a[0]),n.fromBufferAttribute(r,a[1]),c.fromBufferAttribute(r,a[2]),sD.getNormal(sV),h[0]=`${Math.round(1e4*e.x)},${Math.round(1e4*e.y)},${Math.round(1e4*e.z)}`,h[1]=`${Math.round(1e4*n.x)},${Math.round(1e4*n.y)},${Math.round(1e4*n.z)}`,h[2]=`${Math.round(1e4*c.x)},${Math.round(1e4*c.y)},${Math.round(1e4*c.z)}`,h[0]!==h[1]&&h[1]!==h[2]&&h[2]!==h[0])
          for(
          let t=0
          ;t<3;t++){
            const e=(t+1)%3,s=h[t],r=h[e],n=sD[o[t]],c=sD[o[e]],p=`${s}_${r}`,d=`${r}_${s}`;
            d in l&&l[d]?(sV.dot(l[d].normal)<=i&&(u.push(n.x,n.y,n.z),u.push(c.x,c.y,c.z)),l[d]=null):p in l||(l[p]={index0:a[t],index1:a[e],normal:sV.clone()})
            }
          }
        for(
        const t
         in l)
        if(l[t]){
          const{index0:e,index1:i}=l[t];
          sN.fromBufferAttribute(r,e),sE.fromBufferAttribute(r,i),u.push(sN.x,sN.y,sN.z),u.push(sE.x,sE.y,sE.z)
          }
        this.setAttribute("position",new eM(u,3))
        }
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }
  }
  class sj{
    constructor(){
      this.type="Curve",this.arcLengthDivisions=200,this.needsUpdate=!1,this.cacheArcLengths=null
      }getPoint(){
      _("Curve: .getPoint() not implemented.")
      }getPointAt(t,e){
      let i=this.getUtoTmapping(t);
      return this.getPoint(i,e)
      }getPoints(t=5){
      let e=[];
      for(
      let i=0
      ;i<=t;i++)
      e.push(this.getPoint(i/t));
      return e
      }getSpacedPoints(t=5){
      let e=[];
      for(
      let i=0
      ;i<=t;i++)
      e.push(this.getPointAt(i/t));
      return e
      }getLength(){
      let t=this.getLengths();
      return t[t.length-1]
      }getLengths(t=this.arcLengthDivisions){
      if(this.cacheArcLengths&&this.cacheArcLengths.length===t+1&&!this.needsUpdate)
      return this.cacheArcLengths;
      this.needsUpdate=!1;
      let e=[],i,s=this.getPoint(0),r=0;
      e.push(0);
      for(
      let n=1
      ;n<=t;n++)
      e.push(r+=(i=this.getPoint(n/t)).distanceTo(s)),s=i;
      return this.cacheArcLengths=e,e
      }updateArcLengths(){
      this.needsUpdate=!0,this.getLengths()
      }getUtoTmapping(t,e=null){
      let i,s=this.getLengths(),r=0,n=s.length;
      i=e||t*s[n-1];
      let a=0,o=n-1,h;
      for(;a<=o;)
      if((h=s[r=Math.floor(a+(o-a)/2)]-i)<0)
      a=r+1;
      else 
      if(h>0)
      o=r-1;
      else{
        o=r;
        break
        }
      if(s[r=o]===i)
      return r/(n-1);
      let l=s[r],u=s[r+1];
      return(r+(i-l)/(u-l))/(n-1)
      }getTangent(t,e){
      let i=t-1e-4,s=t+1e-4;
      i<0&&(i=0),s>1&&(s=1);
      let r=this.getPoint(i),n=this.getPoint(s),a=e||(r.isVector2?new E:new D);
      return a.copy(n).sub(r).normalize(),a
      }getTangentAt(t,e){
      let i=this.getUtoTmapping(t);
      return this.getTangent(i,e)
      }computeFrenetFrames(t,e=!1){
      let i=new D,s=[],r=[],n=[],a=new D,o=new th;
      for(
      let e=0
      ;e<=t;e++){
        let i=e/t;
        s[e]=this.getTangentAt(i,new D)
        }
      r[0]=new D,n[0]=new D;
      let h=Number.MAX_VALUE,l=Math.abs(s[0].x),u=Math.abs(s[0].y),c=Math.abs(s[0].z);
      l<=h&&(h=l,i.set(1,0,0)),u<=h&&(h=u,i.set(0,1,0)),c<=h&&i.set(0,0,1),a.crossVectors(s[0],i).normalize(),r[0].crossVectors(s[0],a),n[0].crossVectors(s[0],r[0]);
      for(
      let e=1
      ;e<=t;e++){
        if(r[e]=r[e-1].clone(),n[e]=n[e-1].clone(),a.crossVectors(s[e-1],s[e]),a.length()>Number.EPSILON){
          a.normalize();
          let t=Math.acos(R(s[e-1].dot(s[e]),-1,1));
          r[e].applyMatrix4(o.makeRotationAxis(a,t))
          }
        n[e].crossVectors(s[e],r[e])
        }
      if(!0===e){
        let e=Math.acos(R(r[0].dot(r[t]),-1,1));
        e/=t,s[0].dot(a.crossVectors(r[0],r[t]))>0&&(e=-e);
        for(
        let i=1
        ;i<=t;i++)
        r[i].applyMatrix4(o.makeRotationAxis(s[i],e*i)),n[i].crossVectors(s[i],r[i])
        }
      return{tangents:s,normals:r,binormals:n}
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      return this.arcLengthDivisions=t.arcLengthDivisions,this
      }toJSON(){
      let t={metadata:{version:4.7,type:"Curve",generator:"Curve.toJSON"}};
      return t.arcLengthDivisions=this.arcLengthDivisions,t.type=this.type,t
      }fromJSON(t){
      return this.arcLengthDivisions=t.arcLengthDivisions,this
      }
  }
  class sW extends sj{
    constructor(t=0,e=0,i=1,s=1,r=0,n=2*Math.PI,a=!1,o=0){
      super(),this.isEllipseCurve=!0,this.type="EllipseCurve",this.aX=t,this.aY=e,this.xRadius=i,this.yRadius=s,this.aStartAngle=r,this.aEndAngle=n,this.aClockwise=a,this.aRotation=o
      }getPoint(t,e=new E){
      let i=2*Math.PI,s=this.aEndAngle-this.aStartAngle,r=Math.abs(s)<Number.EPSILON;
      for(;s<0;)
      s+=i;
      for(;s>i;)
      s-=i;
      s<Number.EPSILON&&(s=r?0:i),!0!==this.aClockwise||r||(s===i?s=-i:s-=i);
      let n=this.aStartAngle+t*s,a=this.aX+this.xRadius*Math.cos(n),o=this.aY+this.yRadius*Math.sin(n);
      if(0!==this.aRotation){
        let t=Math.cos(this.aRotation),e=Math.sin(this.aRotation),i=a-this.aX,s=o-this.aY;
        a=i*t-s*e+this.aX,o=i*e+s*t+this.aY
        }
      return e.set(a,o)
      }copy(t){
      return super.copy(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this
      }toJSON(){
      let t=super.toJSON();
      return t.aX=this.aX,t.aY=this.aY,t.xRadius=this.xRadius,t.yRadius=this.yRadius,t.aStartAngle=this.aStartAngle,t.aEndAngle=this.aEndAngle,t.aClockwise=this.aClockwise,t.aRotation=this.aRotation,t
      }fromJSON(t){
      return super.fromJSON(t),this.aX=t.aX,this.aY=t.aY,this.xRadius=t.xRadius,this.yRadius=t.yRadius,this.aStartAngle=t.aStartAngle,this.aEndAngle=t.aEndAngle,this.aClockwise=t.aClockwise,this.aRotation=t.aRotation,this
      }
  }
  class sG extends sW{
    constructor(t,e,i,s,r,n){
      super(t,e,i,i,s,r,n),this.isArcCurve=!0,this.type="ArcCurve"
      }
  }
  function sq(){
    let t=0,e=0,i=0,s=0;
    function r(r,n,a,o){
      t=r,e=a,i=-3*r+3*n-2*a-o,s=2*r-2*n+a+o
      }
    return{initCatmullRom:function(t,e,i,s,n){
      r(e,i,n*(i-t),n*(s-e))
      },initNonuniformCatmullRom:function(t,e,i,s,n,a,o){
      let h=(e-t)/n-(i-t)/(n+a)+(i-e)/a,l=(i-e)/a-(s-e)/(a+o)+(s-i)/o;
      r(e,i,h*=a,l*=a)
      },calc:function(r){
      let n=r*r;
      return t+e*r+i*n+n*r*s
      }}
    }
  let sJ=new D,sH=new D,sX=new sq,sY=new sq,sZ=new sq;
  class s$ extends sj{
    constructor(t=[],e=!1,i="centripetal",s=.5){
      super(),this.isCatmullRomCurve3=!0,this.type="CatmullRomCurve3",this.points=t,this.closed=e,this.curveType=i,this.tension=s
      }getPoint(t,e=new D){
      let i,s,r=this.points,n=r.length,a=(n-!this.closed)*t,o=Math.floor(a),h=a-o;
      this.closed?o+=o>0?0:(Math.floor(Math.abs(o)/n)+1)*n:0===h&&o===n-1&&(o=n-2,h=1),this.closed||o>0?i=r[(o-1)%n]:(sH.subVectors(r[0],r[1]).add(r[0]),i=sH);
      let l=r[o%n],u=r[(o+1)%n];
      if(this.closed||o+2<n?s=r[(o+2)%n]:(sJ.subVectors(r[n-1],r[n-2]).add(r[n-1]),s=sJ),"centripetal"===this.curveType||"chordal"===this.curveType){
        let t="chordal"===this.curveType?.5:.25,e=Math.pow(i.distanceToSquared(l),t),r=Math.pow(l.distanceToSquared(u),t),n=Math.pow(u.distanceToSquared(s),t);
        r<1e-4&&(r=1),e<1e-4&&(e=r),n<1e-4&&(n=r),sX.initNonuniformCatmullRom(i.x,l.x,u.x,s.x,e,r,n),sY.initNonuniformCatmullRom(i.y,l.y,u.y,s.y,e,r,n),sZ.initNonuniformCatmullRom(i.z,l.z,u.z,s.z,e,r,n)
        }else
      "catmullrom"===this.curveType&&(sX.initCatmullRom(i.x,l.x,u.x,s.x,this.tension),sY.initCatmullRom(i.y,l.y,u.y,s.y,this.tension),sZ.initCatmullRom(i.z,l.z,u.z,s.z,this.tension));
      return e.set(sX.calc(h),sY.calc(h),sZ.calc(h)),e
      }copy(t){
      super.copy(t),this.points=[];
      for(
      let e=0,i=t.points.length
      ;e<i;e++){
        let i=t.points[e];
        this.points.push(i.clone())
        }
      return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this
      }toJSON(){
      let t=super.toJSON();
      t.points=[];
      for(
      let e=0,i=this.points.length
      ;e<i;e++){
        let i=this.points[e];
        t.points.push(i.toArray())
        }
      return t.closed=this.closed,t.curveType=this.curveType,t.tension=this.tension,t
      }fromJSON(t){
      super.fromJSON(t),this.points=[];
      for(
      let e=0,i=t.points.length
      ;e<i;e++){
        let i=t.points[e];
        this.points.push(new D().fromArray(i))
        }
      return this.closed=t.closed,this.curveType=t.curveType,this.tension=t.tension,this
      }
  }
  function sQ(t,e,i,s,r){
    let n=(s-e)*.5,a=(r-i)*.5,o=t*t;
    return t*o*(2*i-2*s+n+a)+(-3*i+3*s-2*n-a)*o+n*t+i
    }
  function sK(t,e,i,s){
    let r;
    return(r=1-t)*r*e+2*(1-t)*t*i+t*t*s
    }
  function s0(t,e,i,s,r){
    let n,a;
    return(n=1-t)*n*n*e+3*(a=1-t)*a*t*i+3*(1-t)*t*t*s+t*t*t*r
    }
  class s1 extends sj{
    constructor(t=new E,e=new E,i=new E,s=new E){
      super(),this.isCubicBezierCurve=!0,this.type="CubicBezierCurve",this.v0=t,this.v1=e,this.v2=i,this.v3=s
      }getPoint(t,e=new E){
      let i=this.v0,s=this.v1,r=this.v2,n=this.v3;
      return e.set(s0(t,i.x,s.x,r.x,n.x),s0(t,i.y,s.y,r.y,n.y)),e
      }copy(t){
      return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this
      }toJSON(){
      let t=super.toJSON();
      return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this
      }
  }
  class s2 extends sj{
    constructor(t=new D,e=new D,i=new D,s=new D){
      super(),this.isCubicBezierCurve3=!0,this.type="CubicBezierCurve3",this.v0=t,this.v1=e,this.v2=i,this.v3=s
      }getPoint(t,e=new D){
      let i=this.v0,s=this.v1,r=this.v2,n=this.v3;
      return e.set(s0(t,i.x,s.x,r.x,n.x),s0(t,i.y,s.y,r.y,n.y),s0(t,i.z,s.z,r.z,n.z)),e
      }copy(t){
      return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this.v3.copy(t.v3),this
      }toJSON(){
      let t=super.toJSON();
      return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t.v3=this.v3.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this.v3.fromArray(t.v3),this
      }
  }
  class s3 extends sj{
    constructor(t=new E,e=new E){
      super(),this.isLineCurve=!0,this.type="LineCurve",this.v1=t,this.v2=e
      }getPoint(t,e=new E){
      return 1===t?e.copy(this.v2):(e.copy(this.v2).sub(this.v1),e.multiplyScalar(t).add(this.v1)),e
      }getPointAt(t,e){
      return this.getPoint(t,e)
      }getTangent(t,e=new E){
      return e.subVectors(this.v2,this.v1).normalize()
      }getTangentAt(t,e){
      return this.getTangent(t,e)
      }copy(t){
      return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this
      }toJSON(){
      let t=super.toJSON();
      return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this
      }
  }
  class s5 extends sj{
    constructor(t=new D,e=new D){
      super(),this.isLineCurve3=!0,this.type="LineCurve3",this.v1=t,this.v2=e
      }getPoint(t,e=new D){
      return 1===t?e.copy(this.v2):(e.copy(this.v2).sub(this.v1),e.multiplyScalar(t).add(this.v1)),e
      }getPointAt(t,e){
      return this.getPoint(t,e)
      }getTangent(t,e=new D){
      return e.subVectors(this.v2,this.v1).normalize()
      }getTangentAt(t,e){
      return this.getTangent(t,e)
      }copy(t){
      return super.copy(t),this.v1.copy(t.v1),this.v2.copy(t.v2),this
      }toJSON(){
      let t=super.toJSON();
      return t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this
      }
  }
  class s4 extends sj{
    constructor(t=new E,e=new E,i=new E){
      super(),this.isQuadraticBezierCurve=!0,this.type="QuadraticBezierCurve",this.v0=t,this.v1=e,this.v2=i
      }getPoint(t,e=new E){
      let i=this.v0,s=this.v1,r=this.v2;
      return e.set(sK(t,i.x,s.x,r.x),sK(t,i.y,s.y,r.y)),e
      }copy(t){
      return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this
      }toJSON(){
      let t=super.toJSON();
      return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this
      }
  }
  class s6 extends sj{
    constructor(t=new D,e=new D,i=new D){
      super(),this.isQuadraticBezierCurve3=!0,this.type="QuadraticBezierCurve3",this.v0=t,this.v1=e,this.v2=i
      }getPoint(t,e=new D){
      let i=this.v0,s=this.v1,r=this.v2;
      return e.set(sK(t,i.x,s.x,r.x),sK(t,i.y,s.y,r.y),sK(t,i.z,s.z,r.z)),e
      }copy(t){
      return super.copy(t),this.v0.copy(t.v0),this.v1.copy(t.v1),this.v2.copy(t.v2),this
      }toJSON(){
      let t=super.toJSON();
      return t.v0=this.v0.toArray(),t.v1=this.v1.toArray(),t.v2=this.v2.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.v0.fromArray(t.v0),this.v1.fromArray(t.v1),this.v2.fromArray(t.v2),this
      }
  }
  class s8 extends sj{
    constructor(t=[]){
      super(),this.isSplineCurve=!0,this.type="SplineCurve",this.points=t
      }getPoint(t,e=new E){
      let i=this.points,s=(i.length-1)*t,r=Math.floor(s),n=s-r,a=i[0===r?r:r-1],o=i[r],h=i[r>i.length-2?i.length-1:r+1],l=i[r>i.length-3?i.length-1:r+2];
      return e.set(sQ(n,a.x,o.x,h.x,l.x),sQ(n,a.y,o.y,h.y,l.y)),e
      }copy(t){
      super.copy(t),this.points=[];
      for(
      let e=0,i=t.points.length
      ;e<i;e++){
        let i=t.points[e];
        this.points.push(i.clone())
        }
      return this
      }toJSON(){
      let t=super.toJSON();
      t.points=[];
      for(
      let e=0,i=this.points.length
      ;e<i;e++){
        let i=this.points[e];
        t.points.push(i.toArray())
        }
      return t
      }fromJSON(t){
      super.fromJSON(t),this.points=[];
      for(
      let e=0,i=t.points.length
      ;e<i;e++){
        let i=t.points[e];
        this.points.push(new E().fromArray(i))
        }
      return this
      }
  }
  var s9=Object.freeze({__proto__:null,ArcCurve:sG,CatmullRomCurve3:s$,CubicBezierCurve:s1,CubicBezierCurve3:s2,EllipseCurve:sW,LineCurve:s3,LineCurve3:s5,QuadraticBezierCurve:s4,QuadraticBezierCurve3:s6,SplineCurve:s8});
  class s7 extends sj{
    constructor(){
      super(),this.type="CurvePath",this.curves=[],this.autoClose=!1
      }add(t){
      this.curves.push(t)
      }closePath(){
      let t=this.curves[0].getPoint(0),e=this.curves[this.curves.length-1].getPoint(1);
      if(!t.equals(e)){
        let i=!0===t.isVector2?"LineCurve":"LineCurve3";
        this.curves.push(new s9[i](e,t))
        }
      return this
      }getPoint(t,e){
      let i=t*this.getLength(),s=this.getCurveLengths(),r=0;
      for(;r<s.length;){
        if(s[r]>=i){
          let t=s[r]-i,n=this.curves[r],a=n.getLength(),o=0===a?0:1-t/a;
          return n.getPointAt(o,e)
          }
        r++
        }
      return null
      }getLength(){
      let t=this.getCurveLengths();
      return t[t.length-1]
      }updateArcLengths(){
      this.needsUpdate=!0,this.cacheLengths=null,this.getCurveLengths()
      }getCurveLengths(){
      if(this.cacheLengths&&this.cacheLengths.length===this.curves.length)
      return this.cacheLengths;
      let t=[],e=0;
      for(
      let i=0,s=this.curves.length
      ;i<s;i++)
      t.push(e+=this.curves[i].getLength());
      return this.cacheLengths=t,t
      }getSpacedPoints(t=40){
      let e=[];
      for(
      let i=0
      ;i<=t;i++)
      e.push(this.getPoint(i/t));
      return this.autoClose&&e.push(e[0]),e
      }getPoints(t=12){
      let e,i=[];
      for(
      let s=0,r=this.curves
      ;s<r.length;s++){
        let n=r[s],a=n.isEllipseCurve?2*t:n.isLineCurve||n.isLineCurve3?1:n.isSplineCurve?t*n.points.length:t,o=n.getPoints(a);
        for(
        let t=0
        ;t<o.length;t++){
          let s=o[t];
          e&&e.equals(s)||(i.push(s),e=s)
          }
        }
      return this.autoClose&&i.length>1&&!i[i.length-1].equals(i[0])&&i.push(i[0]),i
      }copy(t){
      super.copy(t),this.curves=[];
      for(
      let e=0,i=t.curves.length
      ;e<i;e++){
        let i=t.curves[e];
        this.curves.push(i.clone())
        }
      return this.autoClose=t.autoClose,this
      }toJSON(){
      let t=super.toJSON();
      t.autoClose=this.autoClose,t.curves=[];
      for(
      let e=0,i=this.curves.length
      ;e<i;e++){
        let i=this.curves[e];
        t.curves.push(i.toJSON())
        }
      return t
      }fromJSON(t){
      super.fromJSON(t),this.autoClose=t.autoClose,this.curves=[];
      for(
      let e=0,i=t.curves.length
      ;e<i;e++){
        let i=t.curves[e];
        this.curves.push(new s9[i.type]().fromJSON(i))
        }
      return this
      }
  }
  class rt extends s7{
    constructor(t){
      super(),this.type="Path",this.currentPoint=new E,t&&this.setFromPoints(t)
      }setFromPoints(t){
      this.moveTo(t[0].x,t[0].y);
      for(
      let e=1,i=t.length
      ;e<i;e++)
      this.lineTo(t[e].x,t[e].y);
      return this
      }moveTo(t,e){
      return this.currentPoint.set(t,e),this
      }lineTo(t,e){
      let i=new s3(this.currentPoint.clone(),new E(t,e));
      return this.curves.push(i),this.currentPoint.set(t,e),this
      }quadraticCurveTo(t,e,i,s){
      let r=new s4(this.currentPoint.clone(),new E(t,e),new E(i,s));
      return this.curves.push(r),this.currentPoint.set(i,s),this
      }bezierCurveTo(t,e,i,s,r,n){
      let a=new s1(this.currentPoint.clone(),new E(t,e),new E(i,s),new E(r,n));
      return this.curves.push(a),this.currentPoint.set(r,n),this
      }splineThru(t){
      let e=new s8([this.currentPoint.clone()].concat(t));
      return this.curves.push(e),this.currentPoint.copy(t[t.length-1]),this
      }arc(t,e,i,s,r,n){
      let a=this.currentPoint.x,o=this.currentPoint.y;
      return this.absarc(t+a,e+o,i,s,r,n),this
      }absarc(t,e,i,s,r,n){
      return this.absellipse(t,e,i,i,s,r,n),this
      }ellipse(t,e,i,s,r,n,a,o){
      let h=this.currentPoint.x,l=this.currentPoint.y;
      return this.absellipse(t+h,e+l,i,s,r,n,a,o),this
      }absellipse(t,e,i,s,r,n,a,o){
      let h=new sW(t,e,i,s,r,n,a,o);
      if(this.curves.length>0){
        let t=h.getPoint(0);
        t.equals(this.currentPoint)||this.lineTo(t.x,t.y)
        }
      this.curves.push(h);
      let l=h.getPoint(1);
      return this.currentPoint.copy(l),this
      }copy(t){
      return super.copy(t),this.currentPoint.copy(t.currentPoint),this
      }toJSON(){
      let t=super.toJSON();
      return t.currentPoint=this.currentPoint.toArray(),t
      }fromJSON(t){
      return super.fromJSON(t),this.currentPoint.fromArray(t.currentPoint),this
      }
  }
  class re extends rt{
    constructor(t){
      super(t),this.uuid=O(),this.type="Shape",this.holes=[]
      }getPointsHoles(t){
      let e=[];
      for(
      let i=0,s=this.holes.length
      ;i<s;i++)
      e[i]=this.holes[i].getPoints(t);
      return e
      }extractPoints(t){
      return{shape:this.getPoints(t),holes:this.getPointsHoles(t)}
      }copy(t){
      super.copy(t),this.holes=[];
      for(
      let e=0,i=t.holes.length
      ;e<i;e++){
        let i=t.holes[e];
        this.holes.push(i.clone())
        }
      return this
      }toJSON(){
      let t=super.toJSON();
      t.uuid=this.uuid,t.holes=[];
      for(
      let e=0,i=this.holes.length
      ;e<i;e++){
        let i=this.holes[e];
        t.holes.push(i.toJSON())
        }
      return t
      }fromJSON(t){
      super.fromJSON(t),this.uuid=t.uuid,this.holes=[];
      for(
      let e=0,i=t.holes.length
      ;e<i;e++){
        let i=t.holes[e];
        this.holes.push(new rt().fromJSON(i))
        }
      return this
      }
  }
  function ri(t,e,i,s,r){
    let n;
    if(r===function(t,e,i,s){
      let r=0;
      for(
      let n=e,a=i-s
      ;n<i;n+=s)
      r+=(t[a]-t[n])*(t[n+1]+t[a+1]),a=n;
      return r
      }(t,e,i,s)>0)
    for(
    let r=e
    ;r<i;r+=s)
    n=ry(r/s|0,t[r],t[r+1],n);
    else 
    for(
    let r=i-s
    ;r>=e;r-=s)
    n=ry(r/s|0,t[r],t[r+1],n);
    return n&&rl(n,n.next)&&(rf(n),n=n.next),n
    }
  function rs(t,e){
    if(!t)
    return t;
    e||(e=t);
    let i=t,s;
    do 
    if(s=!1,!i.steiner&&(rl(i,i.next)||0===rh(i.prev,i,i.next))){
      if(rf(i),(i=e=i.prev)===i.next)
      break;
      s=!0
      }else 
    i=i.next;
    while(s||i!==e)
    return e
    }
  function rr(t,e){
    let i=t.x-e.x;
    return 0===i&&0==(i=t.y-e.y)&&(i=(t.next.y-t.y)/(t.next.x-t.x)-(e.next.y-e.y)/(e.next.x-e.x)),i
    }
  function rn(t,e,i,s,r){
    return(t=((t=((t=((t=((t=(t-i)*r|0)|t<<8)&0xff00ff)|t<<4)&0xf0f0f0f)|t<<2)&0x33333333)|t<<1)&0x55555555)|(e=((e=((e=((e=((e=(e-s)*r|0)|e<<8)&0xff00ff)|e<<4)&0xf0f0f0f)|e<<2)&0x33333333)|e<<1)&0x55555555)<<1
    }
  function ra(t,e,i,s,r,n,a,o){
    return(r-a)*(e-o)>=(t-a)*(n-o)&&(t-a)*(s-o)>=(i-a)*(e-o)&&(i-a)*(n-o)>=(r-a)*(s-o)
    }
  function ro(t,e,i,s,r,n,a,o){
    return(t!==a||e!==o)&&ra(t,e,i,s,r,n,a,o)
    }
  function rh(t,e,i){
    return(e.y-t.y)*(i.x-e.x)-(e.x-t.x)*(i.y-e.y)
    }
  function rl(t,e){
    return t.x===e.x&&t.y===e.y
    }
  function ru(t,e,i,s){
    let r=rp(rh(t,e,i)),n=rp(rh(t,e,s)),a=rp(rh(i,s,t)),o=rp(rh(i,s,e));
    return!!(r!==n&&a!==o||0===r&&rc(t,i,e)||0===n&&rc(t,s,e)||0===a&&rc(i,t,s)||0===o&&rc(i,e,s))
    }
  function rc(t,e,i){
    return e.x<=Math.max(t.x,i.x)&&e.x>=Math.min(t.x,i.x)&&e.y<=Math.max(t.y,i.y)&&e.y>=Math.min(t.y,i.y)
    }
  function rp(t){
    return t>0?1:t<0?-1:0
    }
  function rd(t,e){
    return 0>rh(t.prev,t,t.next)?rh(t,e,t.next)>=0&&rh(t,t.prev,e)>=0:0>rh(t,e,t.prev)||0>rh(t,t.next,e)
    }
  function rm(t,e){
    let i=rg(t.i,t.x,t.y),s=rg(e.i,e.x,e.y),r=t.next,n=e.prev;
    return t.next=e,e.prev=t,i.next=r,r.prev=i,s.next=i,i.prev=s,n.next=s,s.prev=n,s
    }
  function ry(t,e,i,s){
    let r=rg(t,e,i);
    return s?(r.next=s.next,r.prev=s,s.next.prev=r,s.next=r):(r.prev=r,r.next=r),r
    }
  function rf(t){
    t.next.prev=t.prev,t.prev.next=t.next,t.prevZ&&(t.prevZ.nextZ=t.nextZ),t.nextZ&&(t.nextZ.prevZ=t.prevZ)
    }
  function rg(t,e,i){
    return{i:t,x:e,y:i,prev:null,next:null,z:0,prevZ:null,nextZ:null,steiner:!1}
    }
  class rx{
    static triangulate(t,e,i=2){
      return function(t,e,i=2){
        let s,r,n,a=e&&e.length,o=a?e[0]*i:t.length,h=ri(t,0,o,i,!0),l=[];
        if(!h||h.next===h.prev)
        return l;
        if(a&&(h=function(t,e,i,s){
          let r=[];
          for(
          let i=0,n=e.length
          ;i<n;i++){
            let a=e[i]*s,o=i<n-1?e[i+1]*s:t.length,h=ri(t,a,o,s,!1);
            h===h.next&&(h.steiner=!0),r.push(function(t){
              let e=t,i=t;
              do
              (e.x<i.x||e.x===i.x&&e.y<i.y)&&(i=e),e=e.next;
              while(e!==t)
              return i
              }(h))
            }
          r.sort(rr);
          for(
          let t=0
          ;t<r.length;t++)
          i=function(t,e){
            let i=function(t,e){
              let i,s=e,r=t.x,n=t.y,a=-1/0;
              if(rl(t,s))
              return s;
              do{
                if(rl(t,s.next))
                return s.next;
                if(n<=s.y&&n>=s.next.y&&s.next.y!==s.y){
                  let t=s.x+(n-s.y)*(s.next.x-s.x)/(s.next.y-s.y);
                  if(t<=r&&t>a&&(a=t,i=s.x<s.next.x?s:s.next,t===r))
                  return i
                  }
                s=s.next
                }while(s!==e)
              if(!i)
              return null;
              let o=i,h=i.x,l=i.y,u=1/0;
              s=i;
              do{
                if(r>=s.x&&s.x>=h&&r!==s.x&&ra(n<l?r:a,n,h,l,n<l?a:r,n,s.x,s.y)){
                  var c,p;
                  let e=Math.abs(n-s.y)/(r-s.x);
                  rd(s,t)&&(e<u||e===u&&(s.x>i.x||s.x===i.x&&(c=i,p=s,0>rh(c.prev,c,p.prev)&&0>rh(p.next,c,c.next))))&&(i=s,u=e)
                  }
                s=s.next
                }while(s!==o)
              return i
              }(t,e);
            if(!i)
            return e;
            let s=rm(i,t);
            return rs(s,s.next),rs(i,i.next)
            }(r[t],i);
          return i
          }(t,e,h,i)),t.length>80*i){
          s=t[0],r=t[1];
          let e=s,a=r;
          for(
          let n=i
          ;n<o;n+=i){
            let i=t[n],o=t[n+1];
            i<s&&(s=i),o<r&&(r=o),i>e&&(e=i),o>a&&(a=o)
            }
          n=0!==(n=Math.max(e-s,a-r))?32767/n:0
          }
        return function t(e,i,s,r,n,a,o){
          if(!e)
          return;
          !o&&a&&function(t,e,i,s){
            let r=t;
            do 
            0===r.z&&(r.z=rn(r.x,r.y,e,i,s)),r.prevZ=r.prev,r.nextZ=r.next,r=r.next;
            while(r!==t)
            r.prevZ.nextZ=null,r.prevZ=null,function(t){
              let e,i=1;
              do{
                let s,r=t;
                t=null;
                let n=null;
                for(e=0;r;){
                  e++;
                  let a=r,o=0;
                  for(
                  let t=0
                  ;t<i&&(o++,a=a.nextZ);t++);
                  let h=i;
                  for(;o>0||h>0&&a;)
                  0!==o&&(0===h||!a||r.z<=a.z)?(s=r,r=r.nextZ,o--):(s=a,a=a.nextZ,h--),n?n.nextZ=s:t=s,s.prevZ=n,n=s;
                  r=a
                  }
                n.nextZ=null,i*=2
                }while(e>1)
              }(r)
            }(e,r,n,a);
          let h=e;
          for(;e.prev!==e.next;){
            let l=e.prev,u=e.next;
            if(a?function(t,e,i,s){
              let r=t.prev,n=t.next;
              if(rh(r,t,n)>=0)
              return!1;
              let a=r.x,o=t.x,h=n.x,l=r.y,u=t.y,c=n.y,p=Math.min(a,o,h),d=Math.min(l,u,c),m=Math.max(a,o,h),y=Math.max(l,u,c),f=rn(p,d,e,i,s),g=rn(m,y,e,i,s),x=t.prevZ,b=t.nextZ;
              for(;x&&x.z>=f&&b&&b.z<=g;){
                if(x.x>=p&&x.x<=m&&x.y>=d&&x.y<=y&&x!==r&&x!==n&&ro(a,l,o,u,h,c,x.x,x.y)&&rh(x.prev,x,x.next)>=0||(x=x.prevZ,b.x>=p&&b.x<=m&&b.y>=d&&b.y<=y&&b!==r&&b!==n&&ro(a,l,o,u,h,c,b.x,b.y)&&rh(b.prev,b,b.next)>=0))
                return!1;
                b=b.nextZ
                }
              for(;x&&x.z>=f;){
                if(x.x>=p&&x.x<=m&&x.y>=d&&x.y<=y&&x!==r&&x!==n&&ro(a,l,o,u,h,c,x.x,x.y)&&rh(x.prev,x,x.next)>=0)
                return!1;
                x=x.prevZ
                }
              for(;b&&b.z<=g;){
                if(b.x>=p&&b.x<=m&&b.y>=d&&b.y<=y&&b!==r&&b!==n&&ro(a,l,o,u,h,c,b.x,b.y)&&rh(b.prev,b,b.next)>=0)
                return!1;
                b=b.nextZ
                }
              return!0
              }(e,r,n,a):function(t){
              let e=t.prev,i=t.next;
              if(rh(e,t,i)>=0)
              return!1;
              let s=e.x,r=t.x,n=i.x,a=e.y,o=t.y,h=i.y,l=Math.min(s,r,n),u=Math.min(a,o,h),c=Math.max(s,r,n),p=Math.max(a,o,h),d=i.next;
              for(;d!==e;){
                if(d.x>=l&&d.x<=c&&d.y>=u&&d.y<=p&&ro(s,a,r,o,n,h,d.x,d.y)&&rh(d.prev,d,d.next)>=0)
                return!1;
                d=d.next
                }
              return!0
              }(e)){
              i.push(l.i,e.i,u.i),rf(e),e=u.next,h=u.next;
              continue
              }
            if((e=u)===h){
              o?1===o?t(e=function(t,e){
                let i=t;
                do{
                  let s=i.prev,r=i.next.next;
                  !rl(s,r)&&ru(s,i,i.next,r)&&rd(s,r)&&rd(r,s)&&(e.push(s.i,i.i,r.i),rf(i),rf(i.next),i=t=r),i=i.next
                  }while(i!==t)
                return rs(i)
                }(rs(e),i),i,s,r,n,a,2):2===o&&function(e,i,s,r,n,a){
                let o=e;
                do{
                  let e=o.next.next;
                  for(;e!==o.prev;){
                    var h,l;
                    if(o.i!==e.i&&(h=o,l=e,h.next.i!==l.i&&h.prev.i!==l.i&&!function(t,e){
                      let i=t;
                      do{
                        if(i.i!==t.i&&i.next.i!==t.i&&i.i!==e.i&&i.next.i!==e.i&&ru(i,i.next,t,e))
                        return!0;
                        i=i.next
                        }while(i!==t)
                      return!1
                      }(h,l)&&(rd(h,l)&&rd(l,h)&&function(t,e){
                      let i=t,s=!1,r=(t.x+e.x)/2,n=(t.y+e.y)/2;
                      do 
                      i.y>n!=i.next.y>n&&i.next.y!==i.y&&r<(i.next.x-i.x)*(n-i.y)/(i.next.y-i.y)+i.x&&(s=!s),i=i.next;
                      while(i!==t)
                      return s
                      }(h,l)&&(rh(h.prev,h,l.prev)||rh(h,l.prev,l))||rl(h,l)&&rh(h.prev,h,h.next)>0&&rh(l.prev,l,l.next)>0))){
                      let h=rm(o,e);
                      o=rs(o,o.next),h=rs(h,h.next),t(o,i,s,r,n,a,0),t(h,i,s,r,n,a,0);
                      return
                      }
                    e=e.next
                    }
                  o=o.next
                  }while(o!==e)
                }(e,i,s,r,n,a):t(rs(e),i,s,r,n,a,1);
              break
              }
            }
          }(h,l,i,s,r,n,0),l
        }(t,e,i)
      }
  }
  class rb{
    static area(t){
      let e=t.length,i=0;
      for(
      let s=e-1,r=0
      ;r<e;s=r++)
      i+=t[s].x*t[r].y-t[r].x*t[s].y;
      return .5*i
      }static isClockWise(t){
      return 0>rb.area(t)
      }static triangulateShape(t,e){
      let i=[],s=[],r=[];
      rv(t),rM(i,t);
      let n=t.length;
      e.forEach(rv);
      for(
      let t=0
      ;t<e.length;t++)
      s.push(n),n+=e[t].length,rM(i,e[t]);
      let a=rx.triangulate(i,s);
      for(
      let t=0
      ;t<a.length;t+=3)
      r.push(a.slice(t,t+3));
      return r
      }
  }
  function rv(t){
    let e=t.length;
    e>2&&t[e-1].equals(t[0])&&t.pop()
    }
  function rM(t,e){
    for(
    let i=0
    ;i<e.length;i++)
    t.push(e[i].x),t.push(e[i].y)
    }
  class rw extends eR{
    constructor(t=new re([new E(.5,.5),new E(-.5,.5),new E(-.5,-.5),new E(.5,-.5)]),e={}){
      super(),this.type="ExtrudeGeometry",this.parameters={shapes:t,options:e},t=Array.isArray(t)?t:[t];
      const i=this,s=[],r=[];
      for(
      let n=0,a=t.length
      ;n<a;n++)
      !function(t){
        let n,a,o,h,l,u=[],c=void 0!==e.curveSegments?e.curveSegments:12,p=void 0!==e.steps?e.steps:1,d=void 0!==e.depth?e.depth:1,m=void 0===e.bevelEnabled||e.bevelEnabled,y=void 0!==e.bevelThickness?e.bevelThickness:.2,f=void 0!==e.bevelSize?e.bevelSize:y-.1,g=void 0!==e.bevelOffset?e.bevelOffset:0,x=void 0!==e.bevelSegments?e.bevelSegments:3,b=e.extrudePath,v=void 0!==e.UVGenerator?e.UVGenerator:rS,M,w=!1;
        if(b){
          M=b.getSpacedPoints(p),w=!0,m=!1;
          let t=!!b.isCatmullRomCurve3&&b.closed;
          n=b.computeFrenetFrames(p,t),a=new D,o=new D,h=new D
          }
        m||(x=0,y=0,f=0,g=0);
        let S=t.extractPoints(c),_=S.shape,T=S.holes;
        if(!rb.isClockWise(_)){
          _=_.reverse();
          for(
          let t=0,e=T.length
          ;t<e;t++){
            let e=T[t];
            rb.isClockWise(e)&&(T[t]=e.reverse())
            }
          }
        function C(t){
          let e=1e-10*1e-10,i=t[0];
          for(
          let s=1
          ;s<=t.length;s++){
            let r=s%t.length,n=t[r],a=n.x-i.x,o=n.y-i.y,h=a*a+o*o,l=Math.max(Math.abs(n.x),Math.abs(n.y),Math.abs(i.x),Math.abs(i.y));
            if(h<=e*l*l){
              t.splice(r,1),s--;
              continue
              }
            i=n
            }
          }
        C(_),T.forEach(C);
        let I=T.length,z=_;
        for(
        let t=0
        ;t<I;t++){
          let e=T[t];
          _=_.concat(e)
          }
        function B(t,e,i){
          return e||A("ExtrudeGeometry: vec does not exist"),t.clone().addScaledVector(e,i)
          }
        let k=_.length;
        function O(t,e,i){
          let s,r,n,a=t.x-e.x,o=t.y-e.y,h=i.x-t.x,l=i.y-t.y,u=a*a+o*o;
          if(Math.abs(a*l-o*h)>Number.EPSILON){
            let c=Math.sqrt(u),p=Math.sqrt(h*h+l*l),d=e.x-o/c,m=e.y+a/c,y=((i.x-l/p-d)*l-(i.y+h/p-m)*h)/(a*l-o*h),f=(s=d+a*y-t.x)*s+(r=m+o*y-t.y)*r;
            if(f<=2)
            return new E(s,r);
            n=Math.sqrt(f/2)
            }else{
            let t=!1;
            a>Number.EPSILON?h>Number.EPSILON&&(t=!0):a<-Number.EPSILON?h<-Number.EPSILON&&(t=!0):Math.sign(o)===Math.sign(l)&&(t=!0),t?(s=-o,r=a,n=Math.sqrt(u)):(s=a,r=o,n=Math.sqrt(u/2))
            }
          return new E(s/n,r/n)
          }
        let R=[];
        for(
        let t=0,e=z.length,i=e-1,s=t+1
        ;t<e;t++,i++,s++)
        i===e&&(i=0),s===e&&(s=0),R[t]=O(z[t],z[i],z[s]);
        let P=[],F,L=R.concat();
        for(
        let t=0
        ;t<I;t++){
          let e=T[t];
          F=[];
          for(
          let t=0,i=e.length,s=i-1,r=t+1
          ;t<i;t++,s++,r++)
          s===i&&(s=0),r===i&&(r=0),F[t]=O(e[t],e[s],e[r]);
          P.push(F),L=L.concat(F)
          }
        if(0===x)
        l=rb.triangulateShape(z,T);
        else{
          let t=[],e=[];
          for(
          let i=0
          ;i<x;i++){
            let s=i/x,r=y*Math.cos(s*Math.PI/2),n=f*Math.sin(s*Math.PI/2)+g;
            for(
            let e=0,i=z.length
            ;e<i;e++){
              let i=B(z[e],R[e],n);
              j(i.x,i.y,-r),0===s&&t.push(i)
              }
            for(
            let t=0
            ;t<I;t++){
              let i=T[t];
              F=P[t];
              let a=[];
              for(
              let t=0,e=i.length
              ;t<e;t++){
                let e=B(i[t],F[t],n);
                j(e.x,e.y,-r),0===s&&a.push(e)
                }
              0===s&&e.push(a)
              }
            }
          l=rb.triangulateShape(t,e)
          }
        let N=l.length,V=f+g;
        for(
        let t=0
        ;t<k;t++){
          let e=m?B(_[t],L[t],V):_[t];
          w?(o.copy(n.normals[0]).multiplyScalar(e.x),a.copy(n.binormals[0]).multiplyScalar(e.y),h.copy(M[0]).add(o).add(a),j(h.x,h.y,h.z)):j(e.x,e.y,0)
          }
        for(
        let t=1
        ;t<=p;t++)
        for(
        let e=0
        ;e<k;e++){
          let i=m?B(_[e],L[e],V):_[e];
          w?(o.copy(n.normals[t]).multiplyScalar(i.x),a.copy(n.binormals[t]).multiplyScalar(i.y),h.copy(M[t]).add(o).add(a),j(h.x,h.y,h.z)):j(i.x,i.y,d/p*t)
          }
        for(
        let t=x-1
        ;t>=0;t--){
          let e=t/x,i=y*Math.cos(e*Math.PI/2),s=f*Math.sin(e*Math.PI/2)+g;
          for(
          let t=0,e=z.length
          ;t<e;t++){
            let e=B(z[t],R[t],s);
            j(e.x,e.y,d+i)
            }
          for(
          let t=0,e=T.length
          ;t<e;t++){
            let e=T[t];
            F=P[t];
            for(
            let t=0,r=e.length
            ;t<r;t++){
              let r=B(e[t],F[t],s);
              w?j(r.x,r.y+M[p-1].y,M[p-1].x+i):j(r.x,r.y,d+i)
              }
            }
          }
        function U(t,e){
          let r=t.length;
          for(;--r>=0;){
            let n=r,a=r-1;
            a<0&&(a=t.length-1);
            for(
            let t=0,r=p+2*x
            ;t<r;t++){
              let r=k*t,o=k*(t+1);
              !function(t,e,r,n){
                G(t),G(e),G(n),G(e),G(r),G(n);
                let a=s.length/3,o=v.generateSideWallUV(i,s,a-6,a-3,a-2,a-1);
                q(o[0]),q(o[1]),q(o[3]),q(o[1]),q(o[2]),q(o[3])
                }(e+n+r,e+a+r,e+a+o,e+n+o)
              }
            }
          }
        function j(t,e,i){
          u.push(t),u.push(e),u.push(i)
          }
        function W(t,e,r){
          G(t),G(e),G(r);
          let n=s.length/3,a=v.generateTopUV(i,s,n-3,n-2,n-1);
          q(a[0]),q(a[1]),q(a[2])
          }
        function G(t){
          s.push(u[3*t+0]),s.push(u[3*t+1]),s.push(u[3*t+2])
          }
        function q(t){
          r.push(t.x),r.push(t.y)
          }
        (function(){
          let t=s.length/3;
          if(m){
            let t=0*k;
            for(
            let e=0
            ;e<N;e++){
              let i=l[e];
              W(i[2]+t,i[1]+t,i[0]+t)
              }
            t=k*(p+2*x);
            for(
            let e=0
            ;e<N;e++){
              let i=l[e];
              W(i[0]+t,i[1]+t,i[2]+t)
              }
            }else{
            for(
            let t=0
            ;t<N;t++){
              let e=l[t];
              W(e[2],e[1],e[0])
              }
            for(
            let t=0
            ;t<N;t++){
              let e=l[t];
              W(e[0]+k*p,e[1]+k*p,e[2]+k*p)
              }
            }
          i.addGroup(t,s.length/3-t,0)
          })(),function(){
          let t=s.length/3,e=0;
          U(z,0),e+=z.length;
          for(
          let t=0,i=T.length
          ;t<i;t++){
            let i=T[t];
            U(i,e),e+=i.length
            }
          i.addGroup(t,s.length/3-t,1)
          }()
        }(t[n]);
      this.setAttribute("position",new eM(s,3)),this.setAttribute("uv",new eM(r,2)),this.computeVertexNormals()
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }toJSON(){
      let t=super.toJSON();
      return function(t,e,i){
        if(i.shapes=[],Array.isArray(t))
        for(
        let e=0,s=t.length
        ;e<s;e++){
          let s=t[e];
          i.shapes.push(s.uuid)
          }
        else 
        i.shapes.push(t.uuid);
        return i.options=Object.assign({},e),void 0!==e.extrudePath&&(i.options.extrudePath=e.extrudePath.toJSON()),i
        }(this.parameters.shapes,this.parameters.options,t)
      }static fromJSON(t,e){
      let i=[];
      for(
      let s=0,r=t.shapes.length
      ;s<r;s++){
        let r=e[t.shapes[s]];
        i.push(r)
        }
      let s=t.options.extrudePath;
      return void 0!==s&&(t.options.extrudePath=new s9[s.type]().fromJSON(s)),new rw(i,t.options)
      }
  }
  let rS={generateTopUV:function(t,e,i,s,r){
    let n=e[3*i],a=e[3*i+1],o=e[3*s],h=e[3*s+1],l=e[3*r],u=e[3*r+1];
    return[new E(n,a),new E(o,h),new E(l,u)]
    },generateSideWallUV:function(t,e,i,s,r,n){
    let a=e[3*i],o=e[3*i+1],h=e[3*i+2],l=e[3*s],u=e[3*s+1],c=e[3*s+2],p=e[3*r],d=e[3*r+1],m=e[3*r+2],y=e[3*n],f=e[3*n+1],g=e[3*n+2];
    return Math.abs(o-u)<Math.abs(a-l)?[new E(a,1-h),new E(l,1-c),new E(p,1-m),new E(y,1-g)]:[new E(o,1-h),new E(u,1-c),new E(d,1-m),new E(f,1-g)]
    }};
  class r_ extends sF{
    constructor(t=1,e=0){
      const i=(1+Math.sqrt(5))/2;
      super([-1,i,0,1,i,0,-1,-i,0,1,-i,0,0,-1,i,0,1,i,0,-1,-i,0,1,-i,i,0,-1,i,0,1,-i,0,-1,-i,0,1],[0,11,5,0,5,1,0,1,7,0,7,10,0,10,11,1,5,9,5,11,4,11,10,2,10,7,6,7,1,8,3,9,4,3,4,2,3,2,6,3,6,8,3,8,9,4,9,5,2,4,11,6,2,10,8,6,7,9,8,1],t,e),this.type="IcosahedronGeometry",this.parameters={radius:t,detail:e}
      }static fromJSON(t){
      return new r_(t.radius,t.detail)
      }
  }
  class rA extends eR{
    constructor(t=[new E(0,-.5),new E(.5,0),new E(0,.5)],e=12,i=0,s=2*Math.PI){
      super(),this.type="LatheGeometry",this.parameters={points:t,segments:e,phiStart:i,phiLength:s},e=Math.floor(e),s=R(s,0,2*Math.PI);
      const r=[],n=[],a=[],o=[],h=[],l=1/e,u=new D,c=new E,p=new D,d=new D,m=new D;
      let y=0,f=0;
      for(
      let e=0
      ;e<=t.length-1;e++)
      switch(e){case 0:
      y=t[e+1].x-t[e].x,p.x=+(f=t[e+1].y-t[e].y),p.y=-y,p.z=0*f,m.copy(p),p.normalize(),o.push(p.x,p.y,p.z);
      break;
      case t.length-1:
      o.push(m.x,m.y,m.z);
      break;
      default:
      y=t[e+1].x-t[e].x,p.x=+(f=t[e+1].y-t[e].y),p.y=-y,p.z=0*f,d.copy(p),p.x+=m.x,p.y+=m.y,p.z+=m.z,p.normalize(),o.push(p.x,p.y,p.z),m.copy(d)
      }
      for(
      let r=0
      ;r<=e;r++){
        const p=i+r*l*s,d=Math.sin(p),m=Math.cos(p);
        for(
        let i=0
        ;i<=t.length-1;i++){
          u.x=t[i].x*d,u.y=t[i].y,u.z=t[i].x*m,n.push(u.x,u.y,u.z),c.x=r/e,c.y=i/(t.length-1),a.push(c.x,c.y);
          const s=o[3*i+0]*d,l=o[3*i+1],p=o[3*i+0]*m;
          h.push(s,l,p)
          }
        }
      for(
      let i=0
      ;i<e;i++)
      for(
      let e=0
      ;e<t.length-1;e++){
        const s=e+i*t.length,n=s+t.length,a=s+t.length+1,o=s+1;
        r.push(s,n,o),r.push(a,o,n)
        }
      this.setIndex(r),this.setAttribute("position",new eM(n,3)),this.setAttribute("uv",new eM(a,2)),this.setAttribute("normal",new eM(h,3))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new rA(t.points,t.segments,t.phiStart,t.phiLength)
      }
  }
  class rT extends sF{
    constructor(t=1,e=0){
      super([1,0,0,-1,0,0,0,1,0,0,-1,0,0,0,1,0,0,-1],[0,2,4,0,4,3,0,3,5,0,5,2,1,2,5,1,5,3,1,3,4,1,4,2],t,e),this.type="OctahedronGeometry",this.parameters={radius:t,detail:e}
      }static fromJSON(t){
      return new rT(t.radius,t.detail)
      }
  }
  class rC extends eR{
    constructor(t=1,e=1,i=1,s=1){
      super(),this.type="PlaneGeometry",this.parameters={width:t,height:e,widthSegments:i,heightSegments:s};
      const r=t/2,n=e/2,a=Math.floor(i),o=Math.floor(s),h=a+1,l=o+1,u=t/a,c=e/o,p=[],d=[],m=[],y=[];
      for(
      let t=0
      ;t<l;t++){
        const e=t*c-n;
        for(
        let i=0
        ;i<h;i++){
          const s=i*u-r;
          d.push(s,-e,0),m.push(0,0,1),y.push(i/a),y.push(1-t/o)
          }
        }
      for(
      let t=0
      ;t<o;t++)
      for(
      let e=0
      ;e<a;e++){
        const i=e+h*t,s=e+h*(t+1),r=e+1+h*(t+1),n=e+1+h*t;
        p.push(i,s,n),p.push(s,r,n)
        }
      this.setIndex(p),this.setAttribute("position",new eM(d,3)),this.setAttribute("normal",new eM(m,3)),this.setAttribute("uv",new eM(y,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new rC(t.width,t.height,t.widthSegments,t.heightSegments)
      }
  }
  class rI extends eR{
    constructor(t=.5,e=1,i=32,s=1,r=0,n=2*Math.PI){
      super(),this.type="RingGeometry",this.parameters={innerRadius:t,outerRadius:e,thetaSegments:i,phiSegments:s,thetaStart:r,thetaLength:n},i=Math.max(3,i);
      const a=[],o=[],h=[],l=[];
      let u=t;
      const c=(e-t)/(s=Math.max(1,s)),p=new D,d=new E;
      for(
      let t=0
      ;t<=s;t++){
        for(
        let t=0
        ;t<=i;t++){
          const s=r+t/i*n;
          p.x=u*Math.cos(s),p.y=u*Math.sin(s),o.push(p.x,p.y,p.z),h.push(0,0,1),d.x=(p.x/e+1)/2,d.y=(p.y/e+1)/2,l.push(d.x,d.y)
          }
        u+=c
        }
      for(
      let t=0
      ;t<s;t++){
        const e=t*(i+1);
        for(
        let t=0
        ;t<i;t++){
          const s=t+e,r=s+i+1,n=s+i+2,o=s+1;
          a.push(s,r,o),a.push(r,n,o)
          }
        }
      this.setIndex(a),this.setAttribute("position",new eM(o,3)),this.setAttribute("normal",new eM(h,3)),this.setAttribute("uv",new eM(l,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new rI(t.innerRadius,t.outerRadius,t.thetaSegments,t.phiSegments,t.thetaStart,t.thetaLength)
      }
  }
  class rz extends eR{
    constructor(t=new re([new E(0,.5),new E(-.5,-.5),new E(.5,-.5)]),e=12){
      super(),this.type="ShapeGeometry",this.parameters={shapes:t,curveSegments:e};
      const i=[],s=[],r=[],n=[];
      let a=0,o=0;
      if(!1===Array.isArray(t))
      h(t);
      else 
      for(
      let e=0
      ;e<t.length;e++)
      h(t[e]),this.addGroup(a,o,e),a+=o,o=0;
      function h(t){
        let a=s.length/3,h=t.extractPoints(e),l=h.shape,u=h.holes;
        !1===rb.isClockWise(l)&&(l=l.reverse());
        for(
        let t=0,e=u.length
        ;t<e;t++){
          let e=u[t];
          !0===rb.isClockWise(e)&&(u[t]=e.reverse())
          }
        let c=rb.triangulateShape(l,u);
        for(
        let t=0,e=u.length
        ;t<e;t++){
          let e=u[t];
          l=l.concat(e)
          }
        for(
        let t=0,e=l.length
        ;t<e;t++){
          let e=l[t];
          s.push(e.x,e.y,0),r.push(0,0,1),n.push(e.x,e.y)
          }
        for(
        let t=0,e=c.length
        ;t<e;t++){
          let e=c[t],s=e[0]+a,r=e[1]+a,n=e[2]+a;
          i.push(s,r,n),o+=3
          }
        }
      this.setIndex(i),this.setAttribute("position",new eM(s,3)),this.setAttribute("normal",new eM(r,3)),this.setAttribute("uv",new eM(n,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }toJSON(){
      let t=super.toJSON();
      return function(t,e){
        if(e.shapes=[],Array.isArray(t))
        for(
        let i=0,s=t.length
        ;i<s;i++){
          let s=t[i];
          e.shapes.push(s.uuid)
          }
        else 
        e.shapes.push(t.uuid);
        return e
        }(this.parameters.shapes,t)
      }static fromJSON(t,e){
      let i=[];
      for(
      let s=0,r=t.shapes.length
      ;s<r;s++){
        let r=e[t.shapes[s]];
        i.push(r)
        }
      return new rz(i,t.curveSegments)
      }
  }
  class rB extends eR{
    constructor(t=1,e=32,i=16,s=0,r=2*Math.PI,n=0,a=Math.PI){
      super(),this.type="SphereGeometry",this.parameters={radius:t,widthSegments:e,heightSegments:i,phiStart:s,phiLength:r,thetaStart:n,thetaLength:a},e=Math.max(3,Math.floor(e)),i=Math.max(2,Math.floor(i));
      const o=Math.min(n+a,Math.PI);
      let h=0;
      const l=[],u=new D,c=new D,p=[],d=[],m=[],y=[];
      for(
      let p=0
      ;p<=i;p++){
        const f=[],g=p/i;
        let x=0;
        0===p&&0===n?x=.5/e:p===i&&o===Math.PI&&(x=-.5/e);
        for(
        let i=0
        ;i<=e;i++){
          const o=i/e;
          u.x=-t*Math.cos(s+o*r)*Math.sin(n+g*a),u.y=t*Math.cos(n+g*a),u.z=t*Math.sin(s+o*r)*Math.sin(n+g*a),d.push(u.x,u.y,u.z),c.copy(u).normalize(),m.push(c.x,c.y,c.z),y.push(o+x,1-g),f.push(h++)
          }
        l.push(f)
        }
      for(
      let t=0
      ;t<i;t++)
      for(
      let s=0
      ;s<e;s++){
        const e=l[t][s+1],r=l[t][s],a=l[t+1][s],h=l[t+1][s+1];
        (0!==t||n>0)&&p.push(e,r,h),(t!==i-1||o<Math.PI)&&p.push(r,a,h)
        }
      this.setIndex(p),this.setAttribute("position",new eM(d,3)),this.setAttribute("normal",new eM(m,3)),this.setAttribute("uv",new eM(y,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new rB(t.radius,t.widthSegments,t.heightSegments,t.phiStart,t.phiLength,t.thetaStart,t.thetaLength)
      }
  }
  class rk extends sF{
    constructor(t=1,e=0){
      super([1,1,1,-1,-1,1,-1,1,-1,1,-1,-1],[2,1,0,0,3,2,1,3,0,2,3,1],t,e),this.type="TetrahedronGeometry",this.parameters={radius:t,detail:e}
      }static fromJSON(t){
      return new rk(t.radius,t.detail)
      }
  }
  class rO extends eR{
    constructor(t=1,e=.4,i=12,s=48,r=2*Math.PI,n=0,a=2*Math.PI){
      super(),this.type="TorusGeometry",this.parameters={radius:t,tube:e,radialSegments:i,tubularSegments:s,arc:r,thetaStart:n,thetaLength:a},i=Math.floor(i),s=Math.floor(s);
      const o=[],h=[],l=[],u=[],c=new D,p=new D,d=new D;
      for(
      let o=0
      ;o<=i;o++){
        const m=n+o/i*a;
        for(
        let n=0
        ;n<=s;n++){
          const a=n/s*r;
          p.x=(t+e*Math.cos(m))*Math.cos(a),p.y=(t+e*Math.cos(m))*Math.sin(a),p.z=e*Math.sin(m),h.push(p.x,p.y,p.z),c.x=t*Math.cos(a),c.y=t*Math.sin(a),d.subVectors(p,c).normalize(),l.push(d.x,d.y,d.z),u.push(n/s),u.push(o/i)
          }
        }
      for(
      let t=1
      ;t<=i;t++)
      for(
      let e=1
      ;e<=s;e++){
        const i=(s+1)*t+e-1,r=(s+1)*(t-1)+e-1,n=(s+1)*(t-1)+e,a=(s+1)*t+e;
        o.push(i,r,a),o.push(r,n,a)
        }
      this.setIndex(o),this.setAttribute("position",new eM(h,3)),this.setAttribute("normal",new eM(l,3)),this.setAttribute("uv",new eM(u,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new rO(t.radius,t.tube,t.radialSegments,t.tubularSegments,t.arc)
      }
  }
  class rR extends eR{
    constructor(t=1,e=.4,i=64,s=8,r=2,n=3){
      super(),this.type="TorusKnotGeometry",this.parameters={radius:t,tube:e,tubularSegments:i,radialSegments:s,p:r,q:n},i=Math.floor(i),s=Math.floor(s);
      const a=[],o=[],h=[],l=[],u=new D,c=new D,p=new D,d=new D,m=new D,y=new D,f=new D;
      for(
      let a=0
      ;a<=i;++a){
        const x=a/i*r*Math.PI*2;
        g(x,r,n,t,p),g(x+.01,r,n,t,d),y.subVectors(d,p),f.addVectors(d,p),m.crossVectors(y,f),f.crossVectors(m,y),m.normalize(),f.normalize();
        for(
        let t=0
        ;t<=s;++t){
          const r=t/s*Math.PI*2,n=-e*Math.cos(r),d=e*Math.sin(r);
          u.x=p.x+(n*f.x+d*m.x),u.y=p.y+(n*f.y+d*m.y),u.z=p.z+(n*f.z+d*m.z),o.push(u.x,u.y,u.z),c.subVectors(u,p).normalize(),h.push(c.x,c.y,c.z),l.push(a/i),l.push(t/s)
          }
        }
      for(
      let t=1
      ;t<=i;t++)
      for(
      let e=1
      ;e<=s;e++){
        const i=(s+1)*(t-1)+(e-1),r=(s+1)*t+(e-1),n=(s+1)*t+e,o=(s+1)*(t-1)+e;
        a.push(i,r,o),a.push(r,n,o)
        }
      function g(t,e,i,s,r){
        let n=Math.cos(t),a=Math.sin(t),o=i/e*t,h=Math.cos(o);
        r.x=s*(2+h)*.5*n,r.y=s*(2+h)*a*.5,r.z=s*Math.sin(o)*.5
        }
      this.setIndex(a),this.setAttribute("position",new eM(o,3)),this.setAttribute("normal",new eM(h,3)),this.setAttribute("uv",new eM(l,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }static fromJSON(t){
      return new rR(t.radius,t.tube,t.tubularSegments,t.radialSegments,t.p,t.q)
      }
  }
  class rP extends eR{
    constructor(t=new s6(new D(-1,-1,0),new D(-1,1,0),new D(1,1,0)),e=64,i=1,s=8,r=!1){
      super(),this.type="TubeGeometry",this.parameters={path:t,tubularSegments:e,radius:i,radialSegments:s,closed:r};
      const n=t.computeFrenetFrames(e,r);
      this.tangents=n.tangents,this.normals=n.normals,this.binormals=n.binormals;
      const a=new D,o=new D,h=new E;
      let l=new D;
      const u=[],c=[],p=[],d=[];
      function m(r){
        l=t.getPointAt(r/e,l);
        let h=n.normals[r],p=n.binormals[r];
        for(
        let t=0
        ;t<=s;t++){
          let e=t/s*Math.PI*2,r=Math.sin(e),n=-Math.cos(e);
          o.x=n*h.x+r*p.x,o.y=n*h.y+r*p.y,o.z=n*h.z+r*p.z,o.normalize(),c.push(o.x,o.y,o.z),a.x=l.x+i*o.x,a.y=l.y+i*o.y,a.z=l.z+i*o.z,u.push(a.x,a.y,a.z)
          }
        }
      (function(){
        for(
        let t=0
        ;t<e;t++)
        m(t);
        m(!1===r?e:0),function(){
          for(
          let t=0
          ;t<=e;t++)
          for(
          let i=0
          ;i<=s;i++)
          h.x=t/e,h.y=i/s,p.push(h.x,h.y)
          }(),function(){
          for(
          let t=1
          ;t<=e;t++)
          for(
          let e=1
          ;e<=s;e++){
            let i=(s+1)*(t-1)+(e-1),r=(s+1)*t+(e-1),n=(s+1)*t+e,a=(s+1)*(t-1)+e;
            d.push(i,r,a),d.push(r,n,a)
            }
          }()
        })(),this.setIndex(d),this.setAttribute("position",new eM(u,3)),this.setAttribute("normal",new eM(c,3)),this.setAttribute("uv",new eM(p,2))
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }toJSON(){
      let t=super.toJSON();
      return t.path=this.parameters.path.toJSON(),t
      }static fromJSON(t){
      return new rP(new s9[t.path.type]().fromJSON(t.path),t.tubularSegments,t.radius,t.radialSegments,t.closed)
      }
  }
  class rF extends eR{
    constructor(t=null){
      if(super(),this.type="WireframeGeometry",this.parameters={geometry:t},null!==t){
        const e=[],i=new Set,s=new D,r=new D;
        if(null!==t.index){
          const n=t.attributes.position,a=t.index;
          let o=t.groups;
          0===o.length&&(o=[{start:0,count:a.count,materialIndex:0}]);
          for(
          let t=0,h=o.length
          ;t<h;++t){
            const h=o[t],l=h.start,u=h.count;
            for(
            let t=l,o=l+u
            ;t<o;t+=3)
            for(
            let o=0
            ;o<3;o++){
              const h=a.getX(t+o),l=a.getX(t+(o+1)%3);
              s.fromBufferAttribute(n,h),r.fromBufferAttribute(n,l),!0===rL(s,r,i)&&(e.push(s.x,s.y,s.z),e.push(r.x,r.y,r.z))
              }
            }
          }else{
          const n=t.attributes.position;
          for(
          let t=0,a=n.count/3
          ;t<a;t++)
          for(
          let a=0
          ;a<3;a++){
            const o=3*t+a,h=3*t+(a+1)%3;
            s.fromBufferAttribute(n,o),r.fromBufferAttribute(n,h),!0===rL(s,r,i)&&(e.push(s.x,s.y,s.z),e.push(r.x,r.y,r.z))
            }
          }
        this.setAttribute("position",new eM(e,3))
        }
      }copy(t){
      return super.copy(t),this.parameters=Object.assign({},t.parameters),this
      }
  }
  function rL(t,e,i){
    let s=`${t.x},${t.y},${t.z}-${e.x},${e.y},${e.z}`,r=`${e.x},${e.y},${e.z}-${t.x},${t.y},${t.z}`;
    return!0!==i.has(s)&&!0!==i.has(r)&&(i.add(s),i.add(r),!0)
    }
  var rN=Object.freeze({__proto__:null,BoxGeometry:sB,CapsuleGeometry:sk,CircleGeometry:sO,ConeGeometry:sP,CylinderGeometry:sR,DodecahedronGeometry:sL,EdgesGeometry:sU,ExtrudeGeometry:rw,IcosahedronGeometry:r_,LatheGeometry:rA,OctahedronGeometry:rT,PlaneGeometry:rC,PolyhedronGeometry:sF,RingGeometry:rI,ShapeGeometry:rz,SphereGeometry:rB,TetrahedronGeometry:rk,TorusGeometry:rO,TorusKnotGeometry:rR,TubeGeometry:rP,WireframeGeometry:rF});
  class rE extends eE{
    constructor(t){
      super(),this.isShadowMaterial=!0,this.type="ShadowMaterial",this.color=new tj(0),this.transparent=!0,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.fog=t.fog,this
      }
  }
  function rV(t){
    let e={};
    for(
    let i
     in t)
    for(
    let s
     in e[i]={},t[i]){
      let r=t[i][s];
      if(rU(r))
      r.isRenderTargetTexture?(_("UniformsUtils: Textures of render targets cannot be cloned via cloneUniforms() or mergeUniforms()."),e[i][s]=null):e[i][s]=r.clone();
      else 
      if(Array.isArray(r))
      if(rU(r[0])){
        let t=[];
        for(
        let e=0,i=r.length
        ;e<i;e++)
        t[e]=r[e].clone();
        e[i][s]=t
        }else 
      e[i][s]=r.slice();
      else 
      e[i][s]=r
      }
    return e
    }
  function rD(t){
    let e={};
    for(
    let i=0
    ;i<t.length;i++){
      let s=rV(t[i]);
      for(
      let t
       in s)
      e[t]=s[t]
      }
    return e
    }
  function rU(t){
    return t&&(t.isColor||t.isMatrix3||t.isMatrix4||t.isVector2||t.isVector3||t.isVector4||t.isTexture||t.isQuaternion)
    }
  class rj extends eE{
    constructor(t){
      super(),this.isShaderMaterial=!0,this.type="ShaderMaterial",this.defines={},this.uniforms={},this.uniformsGroups=[],this.vertexShader="void main() {\n	gl_Position = projectionMatrix * modelViewMatrix * vec4( position, 1.0 );\n}",this.fragmentShader="void main() {\n	gl_FragColor = vec4( 1.0, 0.0, 0.0, 1.0 );\n}",this.linewidth=1,this.wireframe=!1,this.wireframeLinewidth=1,this.fog=!1,this.lights=!1,this.clipping=!1,this.forceSinglePass=!0,this.extensions={clipCullDistance:!1,multiDraw:!1},this.defaultAttributeValues={color:[1,1,1],uv:[0,0],uv1:[0,0]},this.index0AttributeName=void 0,this.uniformsNeedUpdate=!1,this.glslVersion=null,void 0!==t&&this.setValues(t)
      }copy(t){
      return super.copy(t),this.fragmentShader=t.fragmentShader,this.vertexShader=t.vertexShader,this.uniforms=rV(t.uniforms),this.uniformsGroups=function(t){
        let e=[];
        for(
        let i=0
        ;i<t.length;i++)
        e.push(t[i].clone());
        return e
        }(t.uniformsGroups),this.defines=Object.assign({},t.defines),this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.fog=t.fog,this.lights=t.lights,this.clipping=t.clipping,this.extensions=Object.assign({},t.extensions),this.glslVersion=t.glslVersion,this.defaultAttributeValues=Object.assign({},t.defaultAttributeValues),this.index0AttributeName=t.index0AttributeName,this.uniformsNeedUpdate=t.uniformsNeedUpdate,this
      }toJSON(t){
      let e=super.toJSON(t);
      for(
      let i
       in e.glslVersion=this.glslVersion,e.uniforms={},this.uniforms){
        let s=this.uniforms[i].value;
        s&&s.isTexture?e.uniforms[i]={type:"t",value:s.toJSON(t).uuid}:s&&s.isColor?e.uniforms[i]={type:"c",value:s.getHex()}:s&&s.isVector2?e.uniforms[i]={type:"v2",value:s.toArray()}:s&&s.isVector3?e.uniforms[i]={type:"v3",value:s.toArray()}:s&&s.isVector4?e.uniforms[i]={type:"v4",value:s.toArray()}:s&&s.isMatrix3?e.uniforms[i]={type:"m3",value:s.toArray()}:s&&s.isMatrix4?e.uniforms[i]={type:"m4",value:s.toArray()}:e.uniforms[i]={value:s}
        }
      Object.keys(this.defines).length>0&&(e.defines=this.defines),e.vertexShader=this.vertexShader,e.fragmentShader=this.fragmentShader,e.lights=this.lights,e.clipping=this.clipping;
      let i={};
      for(
      let t
       in this.extensions)
      !0===this.extensions[t]&&(i[t]=!0);
      return Object.keys(i).length>0&&(e.extensions=i),e
      }
  }
  class rW extends rj{
    constructor(t){
      super(t),this.isRawShaderMaterial=!0,this.type="RawShaderMaterial"
      }
  }
  class rG extends eE{
    constructor(t){
      super(),this.isMeshStandardMaterial=!0,this.type="MeshStandardMaterial",this.defines={STANDARD:""},this.color=new tj(0xffffff),this.roughness=1,this.metalness=0,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new tj(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new E(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.roughnessMap=null,this.metalnessMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new tx,this.envMapIntensity=1,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.defines={STANDARD:""},this.color.copy(t.color),this.roughness=t.roughness,this.metalness=t.metalness,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.roughnessMap=t.roughnessMap,this.metalnessMap=t.metalnessMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.envMapIntensity=t.envMapIntensity,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this
      }
  }
  class rq extends rG{
    constructor(t){
      super(),this.isMeshPhysicalMaterial=!0,this.defines={STANDARD:"",PHYSICAL:""},this.type="MeshPhysicalMaterial",this.anisotropyRotation=0,this.anisotropyMap=null,this.clearcoatMap=null,this.clearcoatRoughness=0,this.clearcoatRoughnessMap=null,this.clearcoatNormalScale=new E(1,1),this.clearcoatNormalMap=null,this.ior=1.5,Object.defineProperty(this,"reflectivity",{get:function(){
        return R(2.5*(this.ior-1)/(this.ior+1),0,1)
        },set:function(t){
        this.ior=(1+.4*t)/(1-.4*t)
        }}),this.iridescenceMap=null,this.iridescenceIOR=1.3,this.iridescenceThicknessRange=[100,400],this.iridescenceThicknessMap=null,this.sheenColor=new tj(0),this.sheenColorMap=null,this.sheenRoughness=1,this.sheenRoughnessMap=null,this.transmissionMap=null,this.thickness=0,this.thicknessMap=null,this.attenuationDistance=1/0,this.attenuationColor=new tj(1,1,1),this.specularIntensity=1,this.specularIntensityMap=null,this.specularColor=new tj(1,1,1),this.specularColorMap=null,this._anisotropy=0,this._clearcoat=0,this._dispersion=0,this._iridescence=0,this._sheen=0,this._transmission=0,this.setValues(t)
      }get anisotropy(){
      return this._anisotropy
      }set anisotropy(t){
      this._anisotropy>0!=t>0&&this.version++,this._anisotropy=t
      }get clearcoat(){
      return this._clearcoat
      }set clearcoat(t){
      this._clearcoat>0!=t>0&&this.version++,this._clearcoat=t
      }get iridescence(){
      return this._iridescence
      }set iridescence(t){
      this._iridescence>0!=t>0&&this.version++,this._iridescence=t
      }get dispersion(){
      return this._dispersion
      }set dispersion(t){
      this._dispersion>0!=t>0&&this.version++,this._dispersion=t
      }get sheen(){
      return this._sheen
      }set sheen(t){
      this._sheen>0!=t>0&&this.version++,this._sheen=t
      }get transmission(){
      return this._transmission
      }set transmission(t){
      this._transmission>0!=t>0&&this.version++,this._transmission=t
      }copy(t){
      return super.copy(t),this.defines={STANDARD:"",PHYSICAL:""},this.anisotropy=t.anisotropy,this.anisotropyRotation=t.anisotropyRotation,this.anisotropyMap=t.anisotropyMap,this.clearcoat=t.clearcoat,this.clearcoatMap=t.clearcoatMap,this.clearcoatRoughness=t.clearcoatRoughness,this.clearcoatRoughnessMap=t.clearcoatRoughnessMap,this.clearcoatNormalMap=t.clearcoatNormalMap,this.clearcoatNormalScale.copy(t.clearcoatNormalScale),this.dispersion=t.dispersion,this.ior=t.ior,this.iridescence=t.iridescence,this.iridescenceMap=t.iridescenceMap,this.iridescenceIOR=t.iridescenceIOR,this.iridescenceThicknessRange=[...t.iridescenceThicknessRange],this.iridescenceThicknessMap=t.iridescenceThicknessMap,this.sheen=t.sheen,this.sheenColor.copy(t.sheenColor),this.sheenColorMap=t.sheenColorMap,this.sheenRoughness=t.sheenRoughness,this.sheenRoughnessMap=t.sheenRoughnessMap,this.transmission=t.transmission,this.transmissionMap=t.transmissionMap,this.thickness=t.thickness,this.thicknessMap=t.thicknessMap,this.attenuationDistance=t.attenuationDistance,this.attenuationColor.copy(t.attenuationColor),this.specularIntensity=t.specularIntensity,this.specularIntensityMap=t.specularIntensityMap,this.specularColor.copy(t.specularColor),this.specularColorMap=t.specularColorMap,this
      }
  }
  class rJ extends eE{
    constructor(t){
      super(),this.isMeshPhongMaterial=!0,this.type="MeshPhongMaterial",this.color=new tj(0xffffff),this.specular=new tj(1118481),this.shininess=30,this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new tj(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new E(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new tx,this.combine=0,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.specular.copy(t.specular),this.shininess=t.shininess,this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.envMapIntensity=t.envMapIntensity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this
      }
  }
  class rH extends eE{
    constructor(t){
      super(),this.isMeshToonMaterial=!0,this.defines={TOON:""},this.type="MeshToonMaterial",this.color=new tj(0xffffff),this.map=null,this.gradientMap=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new tj(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new E(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.alphaMap=null,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.map=t.map,this.gradientMap=t.gradientMap,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.alphaMap=t.alphaMap,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.fog=t.fog,this
      }
  }
  class rX extends eE{
    constructor(t){
      super(),this.isMeshNormalMaterial=!0,this.type="MeshNormalMaterial",this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new E(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.flatShading=!1,this.setValues(t)
      }copy(t){
      return super.copy(t),this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.flatShading=t.flatShading,this
      }
  }
  class rY extends eE{
    constructor(t){
      super(),this.isMeshLambertMaterial=!0,this.type="MeshLambertMaterial",this.color=new tj(0xffffff),this.map=null,this.lightMap=null,this.lightMapIntensity=1,this.aoMap=null,this.aoMapIntensity=1,this.emissive=new tj(0),this.emissiveIntensity=1,this.emissiveMap=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new E(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.specularMap=null,this.alphaMap=null,this.envMap=null,this.envMapRotation=new tx,this.combine=0,this.reflectivity=1,this.envMapIntensity=1,this.refractionRatio=.98,this.wireframe=!1,this.wireframeLinewidth=1,this.wireframeLinecap="round",this.wireframeLinejoin="round",this.flatShading=!1,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.color.copy(t.color),this.map=t.map,this.lightMap=t.lightMap,this.lightMapIntensity=t.lightMapIntensity,this.aoMap=t.aoMap,this.aoMapIntensity=t.aoMapIntensity,this.emissive.copy(t.emissive),this.emissiveMap=t.emissiveMap,this.emissiveIntensity=t.emissiveIntensity,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.specularMap=t.specularMap,this.alphaMap=t.alphaMap,this.envMap=t.envMap,this.envMapRotation.copy(t.envMapRotation),this.combine=t.combine,this.reflectivity=t.reflectivity,this.envMapIntensity=t.envMapIntensity,this.refractionRatio=t.refractionRatio,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.wireframeLinecap=t.wireframeLinecap,this.wireframeLinejoin=t.wireframeLinejoin,this.flatShading=t.flatShading,this.fog=t.fog,this
      }
  }
  class rZ extends eE{
    constructor(t){
      super(),this.isMeshDepthMaterial=!0,this.type="MeshDepthMaterial",this.depthPacking=3200,this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.wireframe=!1,this.wireframeLinewidth=1,this.setValues(t)
      }copy(t){
      return super.copy(t),this.depthPacking=t.depthPacking,this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this
      }
  }
  class r$ extends eE{
    constructor(t){
      super(),this.isMeshDistanceMaterial=!0,this.type="MeshDistanceMaterial",this.map=null,this.alphaMap=null,this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.map=t.map,this.alphaMap=t.alphaMap,this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this
      }
  }
  class rQ extends eE{
    constructor(t){
      super(),this.isMeshMatcapMaterial=!0,this.defines={MATCAP:""},this.type="MeshMatcapMaterial",this.color=new tj(0xffffff),this.matcap=null,this.map=null,this.bumpMap=null,this.bumpScale=1,this.normalMap=null,this.normalMapType=0,this.normalScale=new E(1,1),this.displacementMap=null,this.displacementScale=1,this.displacementBias=0,this.alphaMap=null,this.wireframe=!1,this.wireframeLinewidth=1,this.flatShading=!1,this.fog=!0,this.setValues(t)
      }copy(t){
      return super.copy(t),this.defines={MATCAP:""},this.color.copy(t.color),this.matcap=t.matcap,this.map=t.map,this.bumpMap=t.bumpMap,this.bumpScale=t.bumpScale,this.normalMap=t.normalMap,this.normalMapType=t.normalMapType,this.normalScale.copy(t.normalScale),this.displacementMap=t.displacementMap,this.displacementScale=t.displacementScale,this.displacementBias=t.displacementBias,this.alphaMap=t.alphaMap,this.wireframe=t.wireframe,this.wireframeLinewidth=t.wireframeLinewidth,this.flatShading=t.flatShading,this.fog=t.fog,this
      }
  }
  class rK extends sn{
    constructor(t){
      super(),this.isLineDashedMaterial=!0,this.type="LineDashedMaterial",this.scale=1,this.dashSize=3,this.gapSize=1,this.setValues(t)
      }copy(t){
      return super.copy(t),this.scale=t.scale,this.dashSize=t.dashSize,this.gapSize=t.gapSize,this
      }
  }
  function r0(t,e){
    return t&&t.constructor!==e?"number"==typeof e.BYTES_PER_ELEMENT?new e(t):Array.prototype.slice.call(t):t
    }
  function r1(t){
    let e=t.length,i=Array(e);
    for(
    let t=0
    ;t!==e;++t)
    i[t]=t;
    return i.sort(function(e,i){
      return t[e]-t[i]
      }),i
    }
  function r2(t,e,i){
    let s=t.length,r=new t.constructor(s);
    for(
    let n=0,a=0
    ;a!==s;++n){
      let s=i[n]*e;
      for(
      let i=0
      ;i!==e;++i)
      r[a++]=t[s+i]
      }
    return r
    }
  function r3(t,e,i,s){
    let r=1,n=t[0];
    for(;void 0!==n&&void 0===n[s];)
    n=t[r++];
    if(void 0===n)
    return;
    let a=n[s];
    if(void 0!==a)
    if(Array.isArray(a))
    do 
    void 0!==(a=n[s])&&(e.push(n.time),i.push(...a)),n=t[r++];
    while(void 0!==n)
    else 
    if(void 0!==a.toArray)
    do 
    void 0!==(a=n[s])&&(e.push(n.time),a.toArray(i,i.length)),n=t[r++];
    while(void 0!==n)
    else 
    do 
    void 0!==(a=n[s])&&(e.push(n.time),i.push(a)),n=t[r++];
    while(void 0!==n)
    }
  class r5{
    constructor(t,e,i,s){
      this.parameterPositions=t,this._cachedIndex=0,this.resultBuffer=void 0!==s?s:new e.constructor(i),this.sampleValues=e,this.valueSize=i,this.settings=null,this.DefaultSettings_={}
      }evaluate(t){
      let e=this.parameterPositions,i=this._cachedIndex,s=e[i],r=e[i-1];
      t:{
        e:{
          let n;
          i:{
            s:
            if(!(t<s)){
              for(
              let n=i+2
              ;;){
                if(void 0===s){
                  if(t<r)
                  break s;
                  return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)
                  }
                if(i===n)
                break;
                if(r=s,t<(s=e[++i]))
                break e
                }
              n=e.length;
              break i
              }
            if(!(t>=r)){
              let a=e[1];
              t<a&&(i=2,r=a);
              for(
              let n=i-2
              ;;){
                if(void 0===r)
                return this._cachedIndex=0,this.copySampleValue_(0);
                if(i===n)
                break;
                if(s=r,t>=(r=e[--i-1]))
                break e
                }
              n=i,i=0;
              break i
              }
            break t
            }
          for(;i<n;){
            let s=i+n>>>1;
            t<e[s]?n=s:i=s+1
            }
          if(s=e[i],void 0===(r=e[i-1]))
          return this._cachedIndex=0,this.copySampleValue_(0);
          if(void 0===s)
          return i=e.length,this._cachedIndex=i,this.copySampleValue_(i-1)
          }
        this._cachedIndex=i,this.intervalChanged_(i,r,s)
        }
      return this.interpolate_(i,r,t,s)
      }getSettings_(){
      return this.settings||this.DefaultSettings_
      }copySampleValue_(t){
      let e=this.resultBuffer,i=this.sampleValues,s=this.valueSize,r=t*s;
      for(
      let t=0
      ;t!==s;++t)
      e[t]=i[r+t];
      return e
      }interpolate_(){
      throw Error("call to abstract method")
      }intervalChanged_(){
      }
  }
  class r4 extends r5{
    constructor(t,e,i,s){
      super(t,e,i,s),this._weightPrev=-0,this._offsetPrev=-0,this._weightNext=-0,this._offsetNext=-0,this.DefaultSettings_={endingStart:2400,endingEnd:2400}
      }intervalChanged_(t,e,i){
      let s=this.parameterPositions,r=t-2,n=t+1,a=s[r],o=s[n];
      if(void 0===a)
      switch(this.getSettings_().endingStart){case 2401:
      r=t,a=2*e-i;
      break;
      case 2402:
      r=s.length-2,a=e+s[r]-s[r+1];
      break;
      default:
      r=t,a=i
      }
      if(void 0===o)
      switch(this.getSettings_().endingEnd){case 2401:
      n=t,o=2*i-e;
      break;
      case 2402:
      n=1,o=i+s[1]-s[0];
      break;
      default:
      n=t-1,o=e
      }
      let h=(i-e)*.5,l=this.valueSize;
      this._weightPrev=h/(e-a),this._weightNext=h/(o-i),this._offsetPrev=r*l,this._offsetNext=n*l
      }interpolate_(t,e,i,s){
      let r=this.resultBuffer,n=this.sampleValues,a=this.valueSize,o=t*a,h=o-a,l=this._offsetPrev,u=this._offsetNext,c=this._weightPrev,p=this._weightNext,d=(i-e)/(s-e),m=d*d,y=m*d,f=-c*y+2*c*m-c*d,g=(1+c)*y+(-1.5-2*c)*m+(-.5+c)*d+1,x=(-1-p)*y+(1.5+p)*m+.5*d,b=p*y-p*m;
      for(
      let t=0
      ;t!==a;++t)
      r[t]=f*n[l+t]+g*n[h+t]+x*n[o+t]+b*n[u+t];
      return r
      }
  }
  class r6 extends r5{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }interpolate_(t,e,i,s){
      let r=this.resultBuffer,n=this.sampleValues,a=this.valueSize,o=t*a,h=o-a,l=(i-e)/(s-e),u=1-l;
      for(
      let t=0
      ;t!==a;++t)
      r[t]=n[h+t]*u+n[o+t]*l;
      return r
      }
  }
  class r8 extends r5{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }interpolate_(t){
      return this.copySampleValue_(t-1)
      }
  }
  class r9 extends r5{
    interpolate_(t,e,i,s){
      let r=this.resultBuffer,n=this.sampleValues,a=this.valueSize,o=t*a,h=o-a,l=this.settings||this.DefaultSettings_,u=l.inTangents,c=l.outTangents;
      if(!u||!c){
        let t=(i-e)/(s-e),l=1-t;
        for(
        let e=0
        ;e!==a;++e)
        r[e]=n[h+e]*l+n[o+e]*t;
        return r
        }
      let p=2*a,d=t-1;
      for(
      let l=0
      ;l!==a;++l){
        let a,m,y,f,g,x=n[h+l],b=n[o+l],v=d*p+2*l,M=c[v],w=c[v+1],S=t*p+2*l,_=u[S],A=u[S+1],T=(i-e)/(s-e);
        for(
        let t=0
        ;t<8;t++){
          m=(a=T*T)*T;
          let t=(g=(f=(y=1-T)*y)*y)*e+3*f*T*M+3*y*a*_+m*s-i;
          if(1e-10>Math.abs(t))
          break;
          let r=3*f*(M-e)+6*y*T*(_-M)+3*a*(s-_);
          if(1e-10>Math.abs(r))
          break;
          T-=t/r,T=Math.max(0,Math.min(1,T))
          }
        r[l]=g*x+3*f*T*w+3*y*a*A+m*b
        }
      return r
      }
  }
  class r7{
    constructor(t,e,i,s){
      if(void 0===t)
      throw Error("THREE.KeyframeTrack: track name is undefined");
      if(void 0===e||0===e.length)
      throw Error("THREE.KeyframeTrack: no keyframes in track named "+t);
      this.name=t,this.times=r0(e,this.TimeBufferType),this.values=r0(i,this.ValueBufferType),this.setInterpolation(s||this.DefaultInterpolation)
      }static toJSON(t){
      let e,i=t.constructor;
      if(i.toJSON!==this.toJSON)
      e=i.toJSON(t);
      else{
        e={name:t.name,times:r0(t.times,Array),values:r0(t.values,Array)};
        let i=t.getInterpolation();
        i!==t.DefaultInterpolation&&(e.interpolation=i)
        }
      return e.type=t.ValueTypeName,e
      }InterpolantFactoryMethodDiscrete(t){
      return new r8(this.times,this.values,this.getValueSize(),t)
      }InterpolantFactoryMethodLinear(t){
      return new r6(this.times,this.values,this.getValueSize(),t)
      }InterpolantFactoryMethodSmooth(t){
      return new r4(this.times,this.values,this.getValueSize(),t)
      }InterpolantFactoryMethodBezier(t){
      let e=new r9(this.times,this.values,this.getValueSize(),t);
      return this.settings&&(e.settings=this.settings),e
      }setInterpolation(t){
      let e;
      switch(t){case 2300:
      e=this.InterpolantFactoryMethodDiscrete;
      break;
      case 2301:
      e=this.InterpolantFactoryMethodLinear;
      break;
      case 2302:
      e=this.InterpolantFactoryMethodSmooth;
      break;
      case 2303:
      e=this.InterpolantFactoryMethodBezier
      }
      if(void 0===e){
        let e="unsupported interpolation for "+this.ValueTypeName+" keyframe track named "+this.name;
        if(void 0===this.createInterpolant)
        if(t!==this.DefaultInterpolation)
        this.setInterpolation(this.DefaultInterpolation);
        else 
        throw Error(e);
        return _("KeyframeTrack:",e),this
        }
      return this.createInterpolant=e,this
      }getInterpolation(){
      switch(this.createInterpolant){case this.InterpolantFactoryMethodDiscrete:
      return 2300;
      case this.InterpolantFactoryMethodLinear:
      return 2301;
      case this.InterpolantFactoryMethodSmooth:
      return 2302;
      case this.InterpolantFactoryMethodBezier:
      return 2303
      }
      }getValueSize(){
      return this.values.length/this.times.length
      }shift(t){
      if(0!==t){
        let e=this.times;
        for(
        let i=0,s=e.length
        ;i!==s;++i)
        e[i]+=t
        }
      return this
      }scale(t){
      if(1!==t){
        let e=this.times;
        for(
        let i=0,s=e.length
        ;i!==s;++i)
        e[i]*=t
        }
      return this
      }trim(t,e){
      let i=this.times,s=i.length,r=0,n=s-1;
      for(;r!==s&&i[r]<t;)
      ++r;
      for(;-1!==n&&i[n]>e;)
      --n;
      if(++n,0!==r||n!==s){
        r>=n&&(r=(n=Math.max(n,1))-1);
        let t=this.getValueSize();
        this.times=i.slice(r,n),this.values=this.values.slice(r*t,n*t)
        }
      return this
      }validate(){
      let t=!0,e=this.getValueSize();
      e-Math.floor(e)!=0&&(A("KeyframeTrack: Invalid value size in track.",this),t=!1);
      let i=this.times,s=this.values,r=i.length;
      0===r&&(A("KeyframeTrack: Track is empty.",this),t=!1);
      let n=null;
      for(
      let e=0
      ;e!==r;e++){
        let s=i[e];
        if("number"==typeof s&&isNaN(s)){
          A("KeyframeTrack: Time is not a valid number.",this,e,s),t=!1;
          break
          }
        if(null!==n&&n>s){
          A("KeyframeTrack: Out of order keys.",this,e,s,n),t=!1;
          break
          }
        n=s
        }
      if(void 0!==s&&x(s))
      for(
      let e=0,i=s.length
      ;e!==i;++e){
        let i=s[e];
        if(isNaN(i)){
          A("KeyframeTrack: Value is not a valid number.",this,e,i),t=!1;
          break
          }
        }
      return t
      }optimize(){
      let t=this.times.slice(),e=this.values.slice(),i=this.getValueSize(),s=2302===this.getInterpolation(),r=t.length-1,n=1;
      for(
      let a=1
      ;a<r;++a){
        let r=!1,o=t[a];
        if(o!==t[a+1]&&(1!==a||o!==t[0]))
        if(s)
        r=!0;
        else{
          let t=a*i,s=t-i,n=t+i;
          for(
          let a=0
          ;a!==i;++a){
            let i=e[t+a];
            if(i!==e[s+a]||i!==e[n+a]){
              r=!0;
              break
              }
            }
          }
        if(r){
          if(a!==n){
            t[n]=t[a];
            let s=a*i,r=n*i;
            for(
            let t=0
            ;t!==i;++t)
            e[r+t]=e[s+t]
            }
          ++n
          }
        }
      if(r>0){
        t[n]=t[r];
        for(
        let t=r*i,s=n*i,a=0
        ;a!==i;++a)
        e[s+a]=e[t+a];
        ++n
        }
      return n!==t.length?(this.times=t.slice(0,n),this.values=e.slice(0,n*i)):(this.times=t,this.values=e),this
      }clone(){
      let t=this.times.slice(),e=this.values.slice(),i=new this.constructor(this.name,t,e);
      return i.createInterpolant=this.createInterpolant,i
      }
  }
  r7.prototype.ValueTypeName="",r7.prototype.TimeBufferType=Float32Array,r7.prototype.ValueBufferType=Float32Array,r7.prototype.DefaultInterpolation=2301;
  class nt extends r7{
    constructor(t,e,i){
      super(t,e,i)
      }
  }
  nt.prototype.ValueTypeName="bool",nt.prototype.ValueBufferType=Array,nt.prototype.DefaultInterpolation=2300,nt.prototype.InterpolantFactoryMethodLinear=void 0,nt.prototype.InterpolantFactoryMethodSmooth=void 0;
  class ne extends r7{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }
  }
  ne.prototype.ValueTypeName="color";
  class ni extends r7{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }
  }
  ni.prototype.ValueTypeName="number";
  class ns extends r5{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }interpolate_(t,e,i,s){
      let r=this.resultBuffer,n=this.sampleValues,a=this.valueSize,o=(i-e)/(s-e),h=t*a;
      for(
      let t=h+a
      ;h!==t;h+=4)
      V.slerpFlat(r,0,n,h-a,n,h,o);
      return r
      }
  }
  class nr extends r7{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }InterpolantFactoryMethodLinear(t){
      return new ns(this.times,this.values,this.getValueSize(),t)
      }
  }
  nr.prototype.ValueTypeName="quaternion",nr.prototype.InterpolantFactoryMethodSmooth=void 0;
  class nn extends r7{
    constructor(t,e,i){
      super(t,e,i)
      }
  }
  nn.prototype.ValueTypeName="string",nn.prototype.ValueBufferType=Array,nn.prototype.DefaultInterpolation=2300,nn.prototype.InterpolantFactoryMethodLinear=void 0,nn.prototype.InterpolantFactoryMethodSmooth=void 0;
  class na extends r7{
    constructor(t,e,i,s){
      super(t,e,i,s)
      }
  }
  na.prototype.ValueTypeName="vector";
  class no{
    constructor(t="",e=-1,i=[],s=2500){
      this.name=t,this.tracks=i,this.duration=e,this.blendMode=s,this.uuid=O(),this.userData={},this.duration<0&&this.resetDuration()
      }static parse(t){
      let e=[],i=t.tracks,s=1/(t.fps||1);
      for(
      let t=0,r=i.length
      ;t!==r;++t)
      e.push((function(t){
        if(void 0===t.type)
        throw Error("THREE.KeyframeTrack: track type undefined, can not parse");
        let e=function(t){
          switch(t.toLowerCase()){case"scalar":case"double":case"float":case"number":case"integer":
          return ni;
          case"vector":case"vector2":case"vector3":case"vector4":
          return na;
          case"color":
          return ne;
          case"quaternion":
          return nr;
          case"bool":case"boolean":
          return nt;
          case"string":
          return nn
          }
          throw Error("THREE.KeyframeTrack: Unsupported typeName: "+t)
          }(t.type);
        if(void 0===t.times){
          let e=[],i=[];
          r3(t.keys,e,i,"value"),t.times=e,t.values=i
          }
        return void 0!==e.parse?e.parse(t):new e(t.name,t.times,t.values,t.interpolation)
        })(i[t]).scale(s));
      let r=new this(t.name,t.duration,e,t.blendMode);
      return r.uuid=t.uuid,r.userData=JSON.parse(t.userData||"{}"),r
      }static toJSON(t){
      let e=[],i=t.tracks,s={name:t.name,duration:t.duration,tracks:e,uuid:t.uuid,blendMode:t.blendMode,userData:JSON.stringify(t.userData)};
      for(
      let t=0,s=i.length
      ;t!==s;++t)
      e.push(r7.toJSON(i[t]));
      return s
      }static CreateFromMorphTargetSequence(t,e,i,s){
      let r=e.length,n=[];
      for(
      let t=0
      ;t<r;t++){
        let a=[],o=[];
        a.push((t+r-1)%r,t,(t+1)%r),o.push(0,1,0);
        let h=r1(a);
        a=r2(a,1,h),o=r2(o,1,h),s||0!==a[0]||(a.push(r),o.push(o[0])),n.push(new ni(".morphTargetInfluences["+e[t].name+"]",a,o).scale(1/i))
        }
      return new this(t,-1,n)
      }static findByName(t,e){
      let i=t;
      Array.isArray(t)||(i=t.geometry&&t.geometry.animations||t.animations);
      for(
      let t=0
      ;t<i.length;t++)
      if(i[t].name===e)
      return i[t];
      return null
      }static CreateClipsFromMorphTargetSequences(t,e,i){
      let s={},r=/^([\w-]*?)([\d]+)$/;
      for(
      let e=0,i=t.length
      ;e<i;e++){
        let i=t[e],n=i.name.match(r);
        if(n&&n.length>1){
          let t=n[1],e=s[t];
          e||(s[t]=e=[]),e.push(i)
          }
        }
      let n=[];
      for(
      let t
       in s)
      n.push(this.CreateFromMorphTargetSequence(t,s[t],e,i));
      return n
      }static parseAnimation(t,e){
      if(_("AnimationClip: parseAnimation() is deprecated and will be removed with r185"),!t)
      return A("AnimationClip: No animation in JSONLoader data."),null;
      let i=function(t,e,i,s,r){
        if(0!==i.length){
          let n=[],a=[];
          r3(i,n,a,s),0!==n.length&&r.push(new t(e,n,a))
          }
        },s=[],r=t.name||"default",n=t.fps||30,a=t.blendMode,o=t.length||-1,h=t.hierarchy||[];
      for(
      let t=0
      ;t<h.length;t++){
        let r=h[t].keys;
        if(r&&0!==r.length)
        if(r[0].morphTargets){
          let t,e={};
          for(t=0;t<r.length;t++)
          if(r[t].morphTargets)
          for(
          let i=0
          ;i<r[t].morphTargets.length;i++)
          e[r[t].morphTargets[i]]=-1;
          for(
          let i
           in e){
            let e=[],n=[];
            for(
            let s=0
            ;s!==r[t].morphTargets.length;++s){
              let s=r[t];
              e.push(s.time),n.push(+(s.morphTarget===i))
              }
            s.push(new ni(".morphTargetInfluence["+i+"]",e,n))
            }
          o=e.length*n
          }else{
          let n=".bones["+e[t].name+"]";
          i(na,n+".position",r,"pos",s),i(nr,n+".quaternion",r,"rot",s),i(na,n+".scale",r,"scl",s)
          }
        }
      return 0===s.length?null:new this(r,o,s,a)
      }resetDuration(){
      let t=this.tracks,e=0;
      for(
      let i=0,s=t.length
      ;i!==s;++i){
        let t=this.tracks[i];
        e=Math.max(e,t.times[t.times.length-1])
        }
      return this.duration=e,this
      }trim(){
      for(
      let t=0
      ;t<this.tracks.length;t++)
      this.tracks[t].trim(0,this.duration);
      return this
      }validate(){
      let t=!0;
      for(
      let e=0
      ;e<this.tracks.length;e++)
      t=t&&this.tracks[e].validate();
      return t
      }optimize(){
      for(
      let t=0
      ;t<this.tracks.length;t++)
      this.tracks[t].optimize();
      return this
      }clone(){
      let t=[];
      for(
      let e=0
      ;e<this.tracks.length;e++)
      t.push(this.tracks[e].clone());
      let e=new this.constructor(this.name,this.duration,t,this.blendMode);
      return e.userData=JSON.parse(JSON.stringify(this.userData)),e
      }toJSON(){
      return this.constructor.toJSON(this)
      }
  }
  let nh={enabled:!1,files:{},add:function(t,e){
    !1===this.enabled||nl(t)||(this.files[t]=e)
    },get:function(t){
    if(!1!==this.enabled&&!nl(t))
    return this.files[t]
    },remove:function(t){
    delete this.files[t]
    },clear:function(){
    this.files={}
    }};
  function nl(t){
    try{
      let e=t.slice(t.indexOf(":")+1),i=new URL(e);
      return"blob:"===i.protocol
      }catch(t){
      return!1
      }
    }
  class nu{
    constructor(t,e,i){
      let s;
      const r=this;
      let n=!1,a=0,o=0;
      const h=[];
      this.onStart=void 0,this.onLoad=t,this.onProgress=e,this.onError=i,this._abortController=null,this.itemStart=function(t){
        o++,!1===n&&void 0!==r.onStart&&r.onStart(t,a,o),n=!0
        },this.itemEnd=function(t){
        a++,void 0!==r.onProgress&&r.onProgress(t,a,o),a===o&&(n=!1,void 0!==r.onLoad&&r.onLoad())
        },this.itemError=function(t){
        void 0!==r.onError&&r.onError(t)
        },this.resolveURL=function(t){
        return s?s(t):t
        },this.setURLModifier=function(t){
        return s=t,this
        },this.addHandler=function(t,e){
        return h.push(t,e),this
        },this.removeHandler=function(t){
        let e=h.indexOf(t);
        return -1!==e&&h.splice(e,2),this
        },this.getHandler=function(t){
        for(
        let e=0,i=h.length
        ;e<i;e+=2){
          let i=h[e],s=h[e+1];
          if(i.global&&(i.lastIndex=0),i.test(t))
          return s
          }
        return null
        },this.abort=function(){
        return this.abortController.abort(),this._abortController=null,this
        }
      }get abortController(){
      return this._abortController||(this._abortController=new AbortController),this._abortController
      }
  }
  let nc=new nu;
  class np{
    constructor(t){
      this.manager=void 0!==t?t:nc,this.crossOrigin="anonymous",this.withCredentials=!1,this.path="",this.resourcePath="",this.requestHeader={},"u">typeof __THREE_DEVTOOLS__&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))
      }load(){
      }loadAsync(t,e){
      let i=this;
      return new Promise(function(s,r){
        i.load(t,s,e,r)
        })
      }parse(){
      }setCrossOrigin(t){
      return this.crossOrigin=t,this
      }setWithCredentials(t){
      return this.withCredentials=t,this
      }setPath(t){
      return this.path=t,this
      }setResourcePath(t){
      return this.resourcePath=t,this
      }setRequestHeader(t){
      return this.requestHeader=t,this
      }abort(){
      return this
      }
  }
  np.DEFAULT_MATERIAL_NAME="__DEFAULT";
  let nd={};
  class nm extends Error{
    constructor(t,e){
      super(t),this.response=e
      }
  }
  class ny extends np{
    constructor(t){
      super(t),this.mimeType="",this.responseType="",this._abortController=new AbortController
      }load(t,e,i,s){
      void 0===t&&(t=""),void 0!==this.path&&(t=this.path+t),t=this.manager.resolveURL(t);
      let r=nh.get(`file:${t}`);
      if(void 0!==r){
        this.manager.itemStart(t),setTimeout(()=>{
          e&&e(r),this.manager.itemEnd(t)
          },0);
        return
        }
      if(void 0!==nd[t])
      return void nd[t].push({onLoad:e,onProgress:i,onError:s});
      nd[t]=[],nd[t].push({onLoad:e,onProgress:i,onError:s});
      let n=new Request(t,{headers:new Headers(this.requestHeader),credentials:this.withCredentials?"include":"same-origin",signal:"function"==typeof AbortSignal.any?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal}),a=this.mimeType,o=this.responseType;
      fetch(n).then(e=>{
        if(200===e.status||0===e.status){
          if(0===e.status&&_("FileLoader: HTTP Status 0 received."),"u"<typeof ReadableStream||void 0===e.body||void 0===e.body.getReader)
          return e;
          let i=nd[t],s=e.body.getReader(),r=e.headers.get("X-File-Size")||e.headers.get("Content-Length"),n=r?parseInt(r):0,a=0!==n,o=0;
          return new Response(new ReadableStream({start(t){
            !function e(){
              s.read().then(({done:s,value:r})=>{
                if(s)
                t.close();
                else{
                  let s=new ProgressEvent("progress",{lengthComputable:a,loaded:o+=r.byteLength,total:n});
                  for(
                  let t=0,e=i.length
                  ;t<e;t++){
                    let e=i[t];
                    e.onProgress&&e.onProgress(s)
                    }
                  t.enqueue(r),e()
                  }
                },e=>{
                t.error(e)
                })
              }()
            }}))
          }
        throw new nm(`fetch for "${e.url}" responded with ${e.status}: ${e.statusText}`,e)
        }).then(t=>{
        switch(o){case"arraybuffer":
        return t.arrayBuffer();
        case"blob":
        return t.blob();
        case"document":
        return t.text().then(t=>new DOMParser().parseFromString(t,a));
        case"json":
        return t.json();
        default:
        if(""===a)
        return t.text();
        {
          let e=/charset="?([^;"\s]*)"?/i.exec(a),i=new TextDecoder(e&&e[1]?e[1].toLowerCase():void 0);
          return t.arrayBuffer().then(t=>i.decode(t))
          }}
        }).then(e=>{
        nh.add(`file:${t}`,e);
        let i=nd[t];
        delete nd[t];
        for(
        let t=0,s=i.length
        ;t<s;t++){
          let s=i[t];
          s.onLoad&&s.onLoad(e)
          }
        }).catch(e=>{
        let i=nd[t];
        if(void 0===i)
        throw this.manager.itemError(t),e;
        delete nd[t];
        for(
        let t=0,s=i.length
        ;t<s;t++){
          let s=i[t];
          s.onError&&s.onError(e)
          }
        this.manager.itemError(t)
        }).finally(()=>{
        this.manager.itemEnd(t)
        }),this.manager.itemStart(t)
      }setResponseType(t){
      return this.responseType=t,this
      }setMimeType(t){
      return this.mimeType=t,this
      }abort(){
      return this._abortController.abort(),this._abortController=new AbortController,this
      }
  }
  let nf=new WeakMap;
  class ng extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      void 0!==this.path&&(t=this.path+t),t=this.manager.resolveURL(t);
      let r=this,n=nh.get(`image:${t}`);
      if(void 0!==n){
        if(!0===n.complete)
        r.manager.itemStart(t),setTimeout(function(){
          e&&e(n),r.manager.itemEnd(t)
          },0);
        else{
          let t=nf.get(n);
          void 0===t&&(t=[],nf.set(n,t)),t.push({onLoad:e,onError:s})
          }
        return n
        }
      let a=b("img");
      function o(){
        l(),e&&e(this);
        let i=nf.get(this)||[];
        for(
        let t=0
        ;t<i.length;t++){
          let e=i[t];
          e.onLoad&&e.onLoad(this)
          }
        nf.delete(this),r.manager.itemEnd(t)
        }
      function h(e){
        l(),s&&s(e),nh.remove(`image:${t}`);
        let i=nf.get(this)||[];
        for(
        let t=0
        ;t<i.length;t++){
          let s=i[t];
          s.onError&&s.onError(e)
          }
        nf.delete(this),r.manager.itemError(t),r.manager.itemEnd(t)
        }
      function l(){
        a.removeEventListener("load",o,!1),a.removeEventListener("error",h,!1)
        }
      return a.addEventListener("load",o,!1),a.addEventListener("error",h,!1),"data:"!==t.slice(0,5)&&void 0!==this.crossOrigin&&(a.crossOrigin=this.crossOrigin),nh.add(`image:${t}`,a),r.manager.itemStart(t),a.src=t,a
      }
  }
  class nx extends tF{
    constructor(t,e=1){
      super(),this.isLight=!0,this.type="Light",this.color=new tj(t),this.intensity=e
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }copy(t,e){
      return super.copy(t,e),this.color.copy(t.color),this.intensity=t.intensity,this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.color=this.color.getHex(),e.object.intensity=this.intensity,e
      }
  }
  class nb extends nx{
    constructor(t,e,i){
      super(t,i),this.isHemisphereLight=!0,this.type="HemisphereLight",this.position.copy(tF.DEFAULT_UP),this.updateMatrix(),this.groundColor=new tj(e)
      }copy(t,e){
      return super.copy(t,e),this.groundColor.copy(t.groundColor),this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.groundColor=this.groundColor.getHex(),e
      }
  }
  let nv=new th,nM=new D,nw=new D;
  class nS{
    constructor(t){
      this.camera=t,this.intensity=1,this.bias=0,this.biasNode=null,this.normalBias=0,this.radius=1,this.blurSamples=8,this.mapSize=new E(512,512),this.mapType=1009,this.map=null,this.mapPass=null,this.matrix=new th,this.autoUpdate=!0,this.needsUpdate=!1,this._frustum=new iX,this._frameExtents=new E(1,1),this._viewportCount=1,this._viewports=[new ts(0,0,1,1)]
      }getViewportCount(){
      return this._viewportCount
      }getFrustum(){
      return this._frustum
      }updateMatrices(t){
      let e=this.camera,i=this.matrix;
      nM.setFromMatrixPosition(t.matrixWorld),e.position.copy(nM),nw.setFromMatrixPosition(t.target.matrixWorld),e.lookAt(nw),e.updateMatrixWorld(),nv.multiplyMatrices(e.projectionMatrix,e.matrixWorldInverse),this._frustum.setFromProjectionMatrix(nv,e.coordinateSystem,e.reversedDepth),2001===e.coordinateSystem||e.reversedDepth?i.set(.5,0,0,.5,0,.5,0,.5,0,0,1,0,0,0,0,1):i.set(.5,0,0,.5,0,.5,0,.5,0,0,.5,.5,0,0,0,1),i.multiply(nv)
      }getViewport(t){
      return this._viewports[t]
      }getFrameExtents(){
      return this._frameExtents
      }dispose(){
      this.map&&this.map.dispose(),this.mapPass&&this.mapPass.dispose()
      }copy(t){
      return this.camera=t.camera.clone(),this.intensity=t.intensity,this.bias=t.bias,this.radius=t.radius,this.autoUpdate=t.autoUpdate,this.needsUpdate=t.needsUpdate,this.normalBias=t.normalBias,this.blurSamples=t.blurSamples,this.mapSize.copy(t.mapSize),this.biasNode=t.biasNode,this
      }clone(){
      return new this.constructor().copy(this)
      }toJSON(){
      let t={};
      return 1!==this.intensity&&(t.intensity=this.intensity),0!==this.bias&&(t.bias=this.bias),0!==this.normalBias&&(t.normalBias=this.normalBias),1!==this.radius&&(t.radius=this.radius),(512!==this.mapSize.x||512!==this.mapSize.y)&&(t.mapSize=this.mapSize.toArray()),t.camera=this.camera.toJSON(!1).object,delete t.camera.matrix,t
      }
  }
  let n_=new D,nA=new V,nT=new D;
  class nC extends tF{
    constructor(){
      super(),this.isCamera=!0,this.type="Camera",this.matrixWorldInverse=new th,this.projectionMatrix=new th,this.projectionMatrixInverse=new th,this.coordinateSystem=2e3,this._reversedDepth=!1
      }get reversedDepth(){
      return this._reversedDepth
      }copy(t,e){
      return super.copy(t,e),this.matrixWorldInverse.copy(t.matrixWorldInverse),this.projectionMatrix.copy(t.projectionMatrix),this.projectionMatrixInverse.copy(t.projectionMatrixInverse),this.coordinateSystem=t.coordinateSystem,this
      }getWorldDirection(t){
      return super.getWorldDirection(t).negate()
      }updateMatrixWorld(t){
      super.updateMatrixWorld(t),this.matrixWorld.decompose(n_,nA,nT),1===nT.x&&1===nT.y&&1===nT.z?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(n_,nA,nT.set(1,1,1)).invert()
      }updateWorldMatrix(t,e){
      super.updateWorldMatrix(t,e),this.matrixWorld.decompose(n_,nA,nT),1===nT.x&&1===nT.y&&1===nT.z?this.matrixWorldInverse.copy(this.matrixWorld).invert():this.matrixWorldInverse.compose(n_,nA,nT.set(1,1,1)).invert()
      }clone(){
      return new this.constructor().copy(this)
      }
  }
  let nI=new D,nz=new E,nB=new E;
  class nk extends nC{
    constructor(t=50,e=1,i=.1,s=2e3){
      super(),this.isPerspectiveCamera=!0,this.type="PerspectiveCamera",this.fov=t,this.zoom=1,this.near=i,this.far=s,this.focus=10,this.aspect=e,this.view=null,this.filmGauge=35,this.filmOffset=0,this.updateProjectionMatrix()
      }copy(t,e){
      return super.copy(t,e),this.fov=t.fov,this.zoom=t.zoom,this.near=t.near,this.far=t.far,this.focus=t.focus,this.aspect=t.aspect,this.view=null===t.view?null:Object.assign({},t.view),this.filmGauge=t.filmGauge,this.filmOffset=t.filmOffset,this
      }setFocalLength(t){
      let e=.5*this.getFilmHeight()/t;
      this.fov=2*k*Math.atan(e),this.updateProjectionMatrix()
      }getFocalLength(){
      let t=Math.tan(.5*B*this.fov);
      return .5*this.getFilmHeight()/t
      }getEffectiveFOV(){
      return 2*k*Math.atan(Math.tan(.5*B*this.fov)/this.zoom)
      }getFilmWidth(){
      return this.filmGauge*Math.min(this.aspect,1)
      }getFilmHeight(){
      return this.filmGauge/Math.max(this.aspect,1)
      }getViewBounds(t,e,i){
      nI.set(-1,-1,.5).applyMatrix4(this.projectionMatrixInverse),e.set(nI.x,nI.y).multiplyScalar(-t/nI.z),nI.set(1,1,.5).applyMatrix4(this.projectionMatrixInverse),i.set(nI.x,nI.y).multiplyScalar(-t/nI.z)
      }getViewSize(t,e){
      return this.getViewBounds(t,nz,nB),e.subVectors(nB,nz)
      }setViewOffset(t,e,i,s,r,n){
      this.aspect=t/e,null===this.view&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=n,this.updateProjectionMatrix()
      }clearViewOffset(){
      null!==this.view&&(this.view.enabled=!1),this.updateProjectionMatrix()
      }updateProjectionMatrix(){
      let t=this.near,e=t*Math.tan(.5*B*this.fov)/this.zoom,i=2*e,s=this.aspect*i,r=-.5*s,n=this.view;
      if(null!==this.view&&this.view.enabled){
        let t=n.fullWidth,a=n.fullHeight;
        r+=n.offsetX*s/t,e-=n.offsetY*i/a,s*=n.width/t,i*=n.height/a
        }
      let a=this.filmOffset;
      0!==a&&(r+=t*a/this.getFilmWidth()),this.projectionMatrix.makePerspective(r,r+s,e,e-i,t,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.fov=this.fov,e.object.zoom=this.zoom,e.object.near=this.near,e.object.far=this.far,e.object.focus=this.focus,e.object.aspect=this.aspect,null!==this.view&&(e.object.view=Object.assign({},this.view)),e.object.filmGauge=this.filmGauge,e.object.filmOffset=this.filmOffset,e
      }
  }
  class nO extends nS{
    constructor(){
      super(new nk(50,1,.5,500)),this.isSpotLightShadow=!0,this.focus=1,this.aspect=1
      }updateMatrices(t){
      let e=this.camera,i=2*k*t.angle*this.focus,s=this.mapSize.width/this.mapSize.height*this.aspect,r=t.distance||e.far;
      (i!==e.fov||s!==e.aspect||r!==e.far)&&(e.fov=i,e.aspect=s,e.far=r,e.updateProjectionMatrix()),super.updateMatrices(t)
      }copy(t){
      return super.copy(t),this.focus=t.focus,this
      }
  }
  class nR extends nx{
    constructor(t,e,i=0,s=Math.PI/3,r=0,n=2){
      super(t,e),this.isSpotLight=!0,this.type="SpotLight",this.position.copy(tF.DEFAULT_UP),this.updateMatrix(),this.target=new tF,this.distance=i,this.angle=s,this.penumbra=r,this.decay=n,this.map=null,this.shadow=new nO
      }get power(){
      return this.intensity*Math.PI
      }set power(t){
      this.intensity=t/Math.PI
      }dispose(){
      super.dispose(),this.shadow.dispose()
      }copy(t,e){
      return super.copy(t,e),this.distance=t.distance,this.angle=t.angle,this.penumbra=t.penumbra,this.decay=t.decay,this.target=t.target.clone(),this.map=t.map,this.shadow=t.shadow.clone(),this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.distance=this.distance,e.object.angle=this.angle,e.object.decay=this.decay,e.object.penumbra=this.penumbra,e.object.target=this.target.uuid,this.map&&this.map.isTexture&&(e.object.map=this.map.toJSON(t).uuid),e.object.shadow=this.shadow.toJSON(),e
      }
  }
  class nP extends nS{
    constructor(){
      super(new nk(90,1,.5,500)),this.isPointLightShadow=!0
      }
  }
  class nF extends nx{
    constructor(t,e,i=0,s=2){
      super(t,e),this.isPointLight=!0,this.type="PointLight",this.distance=i,this.decay=s,this.shadow=new nP
      }get power(){
      return 4*this.intensity*Math.PI
      }set power(t){
      this.intensity=t/(4*Math.PI)
      }dispose(){
      super.dispose(),this.shadow.dispose()
      }copy(t,e){
      return super.copy(t,e),this.distance=t.distance,this.decay=t.decay,this.shadow=t.shadow.clone(),this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.distance=this.distance,e.object.decay=this.decay,e.object.shadow=this.shadow.toJSON(),e
      }
  }
  class nL extends nC{
    constructor(t=-1,e=1,i=1,s=-1,r=.1,n=2e3){
      super(),this.isOrthographicCamera=!0,this.type="OrthographicCamera",this.zoom=1,this.view=null,this.left=t,this.right=e,this.top=i,this.bottom=s,this.near=r,this.far=n,this.updateProjectionMatrix()
      }copy(t,e){
      return super.copy(t,e),this.left=t.left,this.right=t.right,this.top=t.top,this.bottom=t.bottom,this.near=t.near,this.far=t.far,this.zoom=t.zoom,this.view=null===t.view?null:Object.assign({},t.view),this
      }setViewOffset(t,e,i,s,r,n){
      null===this.view&&(this.view={enabled:!0,fullWidth:1,fullHeight:1,offsetX:0,offsetY:0,width:1,height:1}),this.view.enabled=!0,this.view.fullWidth=t,this.view.fullHeight=e,this.view.offsetX=i,this.view.offsetY=s,this.view.width=r,this.view.height=n,this.updateProjectionMatrix()
      }clearViewOffset(){
      null!==this.view&&(this.view.enabled=!1),this.updateProjectionMatrix()
      }updateProjectionMatrix(){
      let t=(this.right-this.left)/(2*this.zoom),e=(this.top-this.bottom)/(2*this.zoom),i=(this.right+this.left)/2,s=(this.top+this.bottom)/2,r=i-t,n=i+t,a=s+e,o=s-e;
      if(null!==this.view&&this.view.enabled){
        let t=(this.right-this.left)/this.view.fullWidth/this.zoom,e=(this.top-this.bottom)/this.view.fullHeight/this.zoom;
        r+=t*this.view.offsetX,n=r+t*this.view.width,a-=e*this.view.offsetY,o=a-e*this.view.height
        }
      this.projectionMatrix.makeOrthographic(r,n,a,o,this.near,this.far,this.coordinateSystem,this.reversedDepth),this.projectionMatrixInverse.copy(this.projectionMatrix).invert()
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.zoom=this.zoom,e.object.left=this.left,e.object.right=this.right,e.object.top=this.top,e.object.bottom=this.bottom,e.object.near=this.near,e.object.far=this.far,null!==this.view&&(e.object.view=Object.assign({},this.view)),e
      }
  }
  class nN extends nS{
    constructor(){
      super(new nL(-5,5,5,-5,.5,500)),this.isDirectionalLightShadow=!0
      }
  }
  class nE extends nx{
    constructor(t,e){
      super(t,e),this.isDirectionalLight=!0,this.type="DirectionalLight",this.position.copy(tF.DEFAULT_UP),this.updateMatrix(),this.target=new tF,this.shadow=new nN
      }dispose(){
      super.dispose(),this.shadow.dispose()
      }copy(t){
      return super.copy(t),this.target=t.target.clone(),this.shadow=t.shadow.clone(),this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.shadow=this.shadow.toJSON(),e.object.target=this.target.uuid,e
      }
  }
  class nV extends nx{
    constructor(t,e){
      super(t,e),this.isAmbientLight=!0,this.type="AmbientLight"
      }
  }
  class nD extends nx{
    constructor(t,e,i=10,s=10){
      super(t,e),this.isRectAreaLight=!0,this.type="RectAreaLight",this.width=i,this.height=s
      }get power(){
      return this.intensity*this.width*this.height*Math.PI
      }set power(t){
      this.intensity=t/(this.width*this.height*Math.PI)
      }copy(t){
      return super.copy(t),this.width=t.width,this.height=t.height,this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.width=this.width,e.object.height=this.height,e
      }
  }
  class nU{
    constructor(){
      this.isSphericalHarmonics3=!0,this.coefficients=[];
      for(
      let t=0
      ;t<9;t++)
      this.coefficients.push(new D)
      }set(t){
      for(
      let e=0
      ;e<9;e++)
      this.coefficients[e].copy(t[e]);
      return this
      }zero(){
      for(
      let t=0
      ;t<9;t++)
      this.coefficients[t].set(0,0,0);
      return this
      }getAt(t,e){
      let i=t.x,s=t.y,r=t.z,n=this.coefficients;
      return e.copy(n[0]).multiplyScalar(.282095),e.addScaledVector(n[1],.488603*s),e.addScaledVector(n[2],.488603*r),e.addScaledVector(n[3],.488603*i),e.addScaledVector(n[4],i*s*1.092548),e.addScaledVector(n[5],s*r*1.092548),e.addScaledVector(n[6],.315392*(3*r*r-1)),e.addScaledVector(n[7],i*r*1.092548),e.addScaledVector(n[8],.546274*(i*i-s*s)),e
      }getIrradianceAt(t,e){
      let i=t.x,s=t.y,r=t.z,n=this.coefficients;
      return e.copy(n[0]).multiplyScalar(.886227),e.addScaledVector(n[1],1.023328*s),e.addScaledVector(n[2],1.023328*r),e.addScaledVector(n[3],1.023328*i),e.addScaledVector(n[4],.858086*i*s),e.addScaledVector(n[5],.858086*s*r),e.addScaledVector(n[6],.743125*r*r-.247708),e.addScaledVector(n[7],.858086*i*r),e.addScaledVector(n[8],.429043*(i*i-s*s)),e
      }add(t){
      for(
      let e=0
      ;e<9;e++)
      this.coefficients[e].add(t.coefficients[e]);
      return this
      }addScaledSH(t,e){
      for(
      let i=0
      ;i<9;i++)
      this.coefficients[i].addScaledVector(t.coefficients[i],e);
      return this
      }scale(t){
      for(
      let e=0
      ;e<9;e++)
      this.coefficients[e].multiplyScalar(t);
      return this
      }lerp(t,e){
      for(
      let i=0
      ;i<9;i++)
      this.coefficients[i].lerp(t.coefficients[i],e);
      return this
      }equals(t){
      for(
      let e=0
      ;e<9;e++)
      if(!this.coefficients[e].equals(t.coefficients[e]))
      return!1;
      return!0
      }copy(t){
      return this.set(t.coefficients)
      }clone(){
      return new this.constructor().copy(this)
      }fromArray(t,e=0){
      let i=this.coefficients;
      for(
      let s=0
      ;s<9;s++)
      i[s].fromArray(t,e+3*s);
      return this
      }toArray(t=[],e=0){
      let i=this.coefficients;
      for(
      let s=0
      ;s<9;s++)
      i[s].toArray(t,e+3*s);
      return t
      }static getBasisAt(t,e){
      let i=t.x,s=t.y,r=t.z;
      e[0]=.282095,e[1]=.488603*s,e[2]=.488603*r,e[3]=.488603*i,e[4]=1.092548*i*s,e[5]=1.092548*s*r,e[6]=.315392*(3*r*r-1),e[7]=1.092548*i*r,e[8]=.546274*(i*i-s*s)
      }
  }
  class nj extends nx{
    constructor(t=new nU,e=1){
      super(void 0,e),this.isLightProbe=!0,this.sh=t
      }copy(t){
      return super.copy(t),this.sh.copy(t.sh),this
      }toJSON(t){
      let e=super.toJSON(t);
      return e.object.sh=this.sh.toArray(),e
      }
  }
  class nW extends np{
    constructor(t){
      super(t),this.textures={}
      }load(t,e,i,s){
      let r=this,n=new ny(r.manager);
      n.setPath(r.path),n.setRequestHeader(r.requestHeader),n.setWithCredentials(r.withCredentials),n.load(t,function(i){
        try{
          e(r.parse(JSON.parse(i)))
          }catch(e){
          s?s(e):A(e),r.manager.itemError(t)
          }
        },i,s)
      }parse(t){
      let e=this.textures;
      function i(t){
        return void 0===e[t]&&_("MaterialLoader: Undefined texture",t),e[t]
        }
      let s=this.createMaterialFromType(t.type);
      if(void 0!==t.uuid&&(s.uuid=t.uuid),void 0!==t.name&&(s.name=t.name),void 0!==t.color&&void 0!==s.color&&s.color.setHex(t.color),void 0!==t.roughness&&(s.roughness=t.roughness),void 0!==t.metalness&&(s.metalness=t.metalness),void 0!==t.sheen&&(s.sheen=t.sheen),void 0!==t.sheenColor&&(s.sheenColor=new tj().setHex(t.sheenColor)),void 0!==t.sheenRoughness&&(s.sheenRoughness=t.sheenRoughness),void 0!==t.emissive&&void 0!==s.emissive&&s.emissive.setHex(t.emissive),void 0!==t.specular&&void 0!==s.specular&&s.specular.setHex(t.specular),void 0!==t.specularIntensity&&(s.specularIntensity=t.specularIntensity),void 0!==t.specularColor&&void 0!==s.specularColor&&s.specularColor.setHex(t.specularColor),void 0!==t.shininess&&(s.shininess=t.shininess),void 0!==t.clearcoat&&(s.clearcoat=t.clearcoat),void 0!==t.clearcoatRoughness&&(s.clearcoatRoughness=t.clearcoatRoughness),void 0!==t.dispersion&&(s.dispersion=t.dispersion),void 0!==t.iridescence&&(s.iridescence=t.iridescence),void 0!==t.iridescenceIOR&&(s.iridescenceIOR=t.iridescenceIOR),void 0!==t.iridescenceThicknessRange&&(s.iridescenceThicknessRange=t.iridescenceThicknessRange),void 0!==t.transmission&&(s.transmission=t.transmission),void 0!==t.thickness&&(s.thickness=t.thickness),void 0!==t.attenuationDistance&&(s.attenuationDistance=t.attenuationDistance),void 0!==t.attenuationColor&&void 0!==s.attenuationColor&&s.attenuationColor.setHex(t.attenuationColor),void 0!==t.anisotropy&&(s.anisotropy=t.anisotropy),void 0!==t.anisotropyRotation&&(s.anisotropyRotation=t.anisotropyRotation),void 0!==t.fog&&(s.fog=t.fog),void 0!==t.flatShading&&(s.flatShading=t.flatShading),void 0!==t.blending&&(s.blending=t.blending),void 0!==t.combine&&(s.combine=t.combine),void 0!==t.side&&(s.side=t.side),void 0!==t.shadowSide&&(s.shadowSide=t.shadowSide),void 0!==t.opacity&&(s.opacity=t.opacity),void 0!==t.transparent&&(s.transparent=t.transparent),void 0!==t.alphaTest&&(s.alphaTest=t.alphaTest),void 0!==t.alphaHash&&(s.alphaHash=t.alphaHash),void 0!==t.depthFunc&&(s.depthFunc=t.depthFunc),void 0!==t.depthTest&&(s.depthTest=t.depthTest),void 0!==t.depthWrite&&(s.depthWrite=t.depthWrite),void 0!==t.colorWrite&&(s.colorWrite=t.colorWrite),void 0!==t.blendSrc&&(s.blendSrc=t.blendSrc),void 0!==t.blendDst&&(s.blendDst=t.blendDst),void 0!==t.blendEquation&&(s.blendEquation=t.blendEquation),void 0!==t.blendSrcAlpha&&(s.blendSrcAlpha=t.blendSrcAlpha),void 0!==t.blendDstAlpha&&(s.blendDstAlpha=t.blendDstAlpha),void 0!==t.blendEquationAlpha&&(s.blendEquationAlpha=t.blendEquationAlpha),void 0!==t.blendColor&&void 0!==s.blendColor&&s.blendColor.setHex(t.blendColor),void 0!==t.blendAlpha&&(s.blendAlpha=t.blendAlpha),void 0!==t.stencilWriteMask&&(s.stencilWriteMask=t.stencilWriteMask),void 0!==t.stencilFunc&&(s.stencilFunc=t.stencilFunc),void 0!==t.stencilRef&&(s.stencilRef=t.stencilRef),void 0!==t.stencilFuncMask&&(s.stencilFuncMask=t.stencilFuncMask),void 0!==t.stencilFail&&(s.stencilFail=t.stencilFail),void 0!==t.stencilZFail&&(s.stencilZFail=t.stencilZFail),void 0!==t.stencilZPass&&(s.stencilZPass=t.stencilZPass),void 0!==t.stencilWrite&&(s.stencilWrite=t.stencilWrite),void 0!==t.wireframe&&(s.wireframe=t.wireframe),void 0!==t.wireframeLinewidth&&(s.wireframeLinewidth=t.wireframeLinewidth),void 0!==t.wireframeLinecap&&(s.wireframeLinecap=t.wireframeLinecap),void 0!==t.wireframeLinejoin&&(s.wireframeLinejoin=t.wireframeLinejoin),void 0!==t.rotation&&(s.rotation=t.rotation),void 0!==t.linewidth&&(s.linewidth=t.linewidth),void 0!==t.dashSize&&(s.dashSize=t.dashSize),void 0!==t.gapSize&&(s.gapSize=t.gapSize),void 0!==t.scale&&(s.scale=t.scale),void 0!==t.polygonOffset&&(s.polygonOffset=t.polygonOffset),void 0!==t.polygonOffsetFactor&&(s.polygonOffsetFactor=t.polygonOffsetFactor),void 0!==t.polygonOffsetUnits&&(s.polygonOffsetUnits=t.polygonOffsetUnits),void 0!==t.dithering&&(s.dithering=t.dithering),void 0!==t.alphaToCoverage&&(s.alphaToCoverage=t.alphaToCoverage),void 0!==t.premultipliedAlpha&&(s.premultipliedAlpha=t.premultipliedAlpha),void 0!==t.forceSinglePass&&(s.forceSinglePass=t.forceSinglePass),void 0!==t.allowOverride&&(s.allowOverride=t.allowOverride),void 0!==t.visible&&(s.visible=t.visible),void 0!==t.toneMapped&&(s.toneMapped=t.toneMapped),void 0!==t.userData&&(s.userData=t.userData),void 0!==t.vertexColors&&("number"==typeof t.vertexColors?s.vertexColors=t.vertexColors>0:s.vertexColors=t.vertexColors),void 0!==t.uniforms)
      for(
      let e
       in t.uniforms){
        let r=t.uniforms[e];
        switch(s.uniforms[e]={},r.type){case"t":
        s.uniforms[e].value=i(r.value);
        break;
        case"c":
        s.uniforms[e].value=new tj().setHex(r.value);
        break;
        case"v2":
        s.uniforms[e].value=new E().fromArray(r.value);
        break;
        case"v3":
        s.uniforms[e].value=new D().fromArray(r.value);
        break;
        case"v4":
        s.uniforms[e].value=new ts().fromArray(r.value);
        break;
        case"m3":
        s.uniforms[e].value=new W().fromArray(r.value);
        break;
        case"m4":
        s.uniforms[e].value=new th().fromArray(r.value);
        break;
        default:
        s.uniforms[e].value=r.value
        }
        }
      if(void 0!==t.defines&&(s.defines=t.defines),void 0!==t.vertexShader&&(s.vertexShader=t.vertexShader),void 0!==t.fragmentShader&&(s.fragmentShader=t.fragmentShader),void 0!==t.glslVersion&&(s.glslVersion=t.glslVersion),void 0!==t.extensions)
      for(
      let e
       in t.extensions)
      s.extensions[e]=t.extensions[e];
      if(void 0!==t.lights&&(s.lights=t.lights),void 0!==t.clipping&&(s.clipping=t.clipping),void 0!==t.size&&(s.size=t.size),void 0!==t.sizeAttenuation&&(s.sizeAttenuation=t.sizeAttenuation),void 0!==t.map&&(s.map=i(t.map)),void 0!==t.matcap&&(s.matcap=i(t.matcap)),void 0!==t.alphaMap&&(s.alphaMap=i(t.alphaMap)),void 0!==t.bumpMap&&(s.bumpMap=i(t.bumpMap)),void 0!==t.bumpScale&&(s.bumpScale=t.bumpScale),void 0!==t.normalMap&&(s.normalMap=i(t.normalMap)),void 0!==t.normalMapType&&(s.normalMapType=t.normalMapType),void 0!==t.normalScale){
        let e=t.normalScale;
        !1===Array.isArray(e)&&(e=[e,e]),s.normalScale=new E().fromArray(e)
        }
      return void 0!==t.displacementMap&&(s.displacementMap=i(t.displacementMap)),void 0!==t.displacementScale&&(s.displacementScale=t.displacementScale),void 0!==t.displacementBias&&(s.displacementBias=t.displacementBias),void 0!==t.roughnessMap&&(s.roughnessMap=i(t.roughnessMap)),void 0!==t.metalnessMap&&(s.metalnessMap=i(t.metalnessMap)),void 0!==t.emissiveMap&&(s.emissiveMap=i(t.emissiveMap)),void 0!==t.emissiveIntensity&&(s.emissiveIntensity=t.emissiveIntensity),void 0!==t.specularMap&&(s.specularMap=i(t.specularMap)),void 0!==t.specularIntensityMap&&(s.specularIntensityMap=i(t.specularIntensityMap)),void 0!==t.specularColorMap&&(s.specularColorMap=i(t.specularColorMap)),void 0!==t.envMap&&(s.envMap=i(t.envMap)),void 0!==t.envMapRotation&&s.envMapRotation.fromArray(t.envMapRotation),void 0!==t.envMapIntensity&&(s.envMapIntensity=t.envMapIntensity),void 0!==t.reflectivity&&(s.reflectivity=t.reflectivity),void 0!==t.refractionRatio&&(s.refractionRatio=t.refractionRatio),void 0!==t.lightMap&&(s.lightMap=i(t.lightMap)),void 0!==t.lightMapIntensity&&(s.lightMapIntensity=t.lightMapIntensity),void 0!==t.aoMap&&(s.aoMap=i(t.aoMap)),void 0!==t.aoMapIntensity&&(s.aoMapIntensity=t.aoMapIntensity),void 0!==t.gradientMap&&(s.gradientMap=i(t.gradientMap)),void 0!==t.clearcoatMap&&(s.clearcoatMap=i(t.clearcoatMap)),void 0!==t.clearcoatRoughnessMap&&(s.clearcoatRoughnessMap=i(t.clearcoatRoughnessMap)),void 0!==t.clearcoatNormalMap&&(s.clearcoatNormalMap=i(t.clearcoatNormalMap)),void 0!==t.clearcoatNormalScale&&(s.clearcoatNormalScale=new E().fromArray(t.clearcoatNormalScale)),void 0!==t.iridescenceMap&&(s.iridescenceMap=i(t.iridescenceMap)),void 0!==t.iridescenceThicknessMap&&(s.iridescenceThicknessMap=i(t.iridescenceThicknessMap)),void 0!==t.transmissionMap&&(s.transmissionMap=i(t.transmissionMap)),void 0!==t.thicknessMap&&(s.thicknessMap=i(t.thicknessMap)),void 0!==t.anisotropyMap&&(s.anisotropyMap=i(t.anisotropyMap)),void 0!==t.sheenColorMap&&(s.sheenColorMap=i(t.sheenColorMap)),void 0!==t.sheenRoughnessMap&&(s.sheenRoughnessMap=i(t.sheenRoughnessMap)),s
      }setTextures(t){
      return this.textures=t,this
      }createMaterialFromType(t){
      return nW.createMaterialFromType(t)
      }static createMaterialFromType(t){
      return new({ShadowMaterial:rE,SpriteMaterial:eV,RawShaderMaterial:rW,ShaderMaterial:rj,PointsMaterial:sb,MeshPhysicalMaterial:rq,MeshStandardMaterial:rG,MeshPhongMaterial:rJ,MeshToonMaterial:rH,MeshNormalMaterial:rX,MeshLambertMaterial:rY,MeshDepthMaterial:rZ,MeshDistanceMaterial:r$,MeshBasicMaterial:ie,MeshMatcapMaterial:rQ,LineDashedMaterial:rK,LineBasicMaterial:sn,Material:eE})[t]
      }
  }
  class nG{
    static extractUrlBase(t){
      let e=t.lastIndexOf("/");
      return -1===e?"./":t.slice(0,e+1)
      }static resolveURL(t,e){
      return"string"!=typeof t||""===t?"":(/^https?:\/\//i.test(e)&&/^\//.test(t)&&(e=e.replace(/(^https?:\/\/[^\/]+).*/i,"$1")),/^(https?:)?\/\//i.test(t)||/^data:.*,.*$/i.test(t)||/^blob:.*$/i.test(t))?t:e+t
      }
  }
  class nq extends eR{
    constructor(){
      super(),this.isInstancedBufferGeometry=!0,this.type="InstancedBufferGeometry",this.instanceCount=1/0
      }copy(t){
      return super.copy(t),this.instanceCount=t.instanceCount,this
      }toJSON(){
      let t=super.toJSON();
      return t.instanceCount=this.instanceCount,t.isInstancedBufferGeometry=!0,t
      }
  }
  class nJ extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=this,n=new ny(r.manager);
      n.setPath(r.path),n.setRequestHeader(r.requestHeader),n.setWithCredentials(r.withCredentials),n.load(t,function(i){
        try{
          e(r.parse(JSON.parse(i)))
          }catch(e){
          s?s(e):A(e),r.manager.itemError(t)
          }
        },i,s)
      }parse(t){
      let e={},i={};
      function s(t,s){
        if(void 0!==e[s])
        return e[s];
        let r=t.interleavedBuffers[s],n=function(t,e){
          if(void 0!==i[e])
          return i[e];
          let s=new Uint32Array(t.arrayBuffers[e]).buffer;
          return i[e]=s,s
          }(t,r.buffer),a=new eP(g(r.type,n),r.stride);
        return a.uuid=r.uuid,e[s]=a,a
        }
      let r=t.isInstancedBufferGeometry?new nq:new eR,n=t.data.index;
      if(void 0!==n){
        let t=g(n.type,n.array);
        r.setIndex(new ex(t,1))
        }
      let a=t.data.attributes;
      for(
      let e
       in a){
        let i,n=a[e];
        if(n.isInterleavedBufferAttribute)
        i=new eL(s(t.data,n.data),n.itemSize,n.offset,n.normalized);
        else{
          let t=g(n.type,n.array);
          i=new(n.isInstancedBufferAttribute?iO:ex)(t,n.itemSize,n.normalized)
          }
        void 0!==n.name&&(i.name=n.name),void 0!==n.usage&&i.setUsage(n.usage),r.setAttribute(e,i)
        }
      let o=t.data.morphAttributes;
      if(o)
      for(
      let e
       in o){
        let i=o[e],n=[];
        for(
        let e=0,r=i.length
        ;e<r;e++){
          let r,a=i[e];
          r=a.isInterleavedBufferAttribute?new eL(s(t.data,a.data),a.itemSize,a.offset,a.normalized):new ex(g(a.type,a.array),a.itemSize,a.normalized),void 0!==a.name&&(r.name=a.name),n.push(r)
          }
        r.morphAttributes[e]=n
        }
      t.data.morphTargetsRelative&&(r.morphTargetsRelative=!0);
      let h=t.data.groups||t.data.drawcalls||t.data.offsets;
      if(void 0!==h)
      for(
      let t=0,e=h.length
      ;t!==e;++t){
        let e=h[t];
        r.addGroup(e.start,e.count,e.materialIndex)
        }
      let l=t.data.boundingSphere;
      return void 0!==l&&(r.boundingSphere=new eA().fromJSON(l)),t.name&&(r.name=t.name),t.userData&&(r.userData=t.userData),r
      }
  }
  let nH={},nX={UVMapping:300,CubeReflectionMapping:301,CubeRefractionMapping:302,EquirectangularReflectionMapping:303,EquirectangularRefractionMapping:304,CubeUVReflectionMapping:306},nY={RepeatWrapping:1e3,ClampToEdgeWrapping:1001,MirroredRepeatWrapping:1002},nZ={NearestFilter:1003,NearestMipmapNearestFilter:1004,NearestMipmapLinearFilter:1005,LinearFilter:1006,LinearMipmapNearestFilter:1007,LinearMipmapLinearFilter:1008},n$=new WeakMap;
  class nQ{
    static getContext(){
      return void 0===s&&(s=new(window.AudioContext||window.webkitAudioContext)),s
      }static setContext(t){
      s=t
      }
  }
  let nK=new th,n0=new th,n1=new th;
  class n2{
    constructor(){
      this._previousTime=0,this._currentTime=0,this._startTime=performance.now(),this._delta=0,this._elapsed=0,this._timescale=1,this._document=null,this._pageVisibilityHandler=null
      }connect(t){
      this._document=t,void 0!==t.hidden&&(this._pageVisibilityHandler=n3.bind(this),t.addEventListener("visibilitychange",this._pageVisibilityHandler,!1))
      }disconnect(){
      null!==this._pageVisibilityHandler&&(this._document.removeEventListener("visibilitychange",this._pageVisibilityHandler),this._pageVisibilityHandler=null),this._document=null
      }getDelta(){
      return this._delta/1e3
      }getElapsed(){
      return this._elapsed/1e3
      }getTimescale(){
      return this._timescale
      }setTimescale(t){
      return this._timescale=t,this
      }reset(){
      return this._currentTime=performance.now()-this._startTime,this
      }dispose(){
      this.disconnect()
      }update(t){
      return null!==this._pageVisibilityHandler&&!0===this._document.hidden?this._delta=0:(this._previousTime=this._currentTime,this._currentTime=(void 0!==t?t:performance.now())-this._startTime,this._delta=(this._currentTime-this._previousTime)*this._timescale,this._elapsed+=this._delta),this
      }
  }
  function n3(){
    !1===this._document.hidden&&this.reset()
    }
  let n5=new D,n4=new V,n6=new D,n8=new D,n9=new D;
  class n7 extends tF{
    constructor(t){
      super(),this.type="Audio",this.listener=t,this.context=t.context,this.gain=this.context.createGain(),this.gain.connect(t.getInput()),this.autoplay=!1,this.buffer=null,this.detune=0,this.loop=!1,this.loopStart=0,this.loopEnd=0,this.offset=0,this.duration=void 0,this.playbackRate=1,this.isPlaying=!1,this.hasPlaybackControl=!0,this.source=null,this.sourceType="empty",this._startedAt=0,this._progress=0,this._connected=!1,this.filters=[]
      }getOutput(){
      return this.gain
      }setNodeSource(t){
      return this.hasPlaybackControl=!1,this.sourceType="audioNode",this.source=t,this.connect(),this
      }setMediaElementSource(t){
      return this.hasPlaybackControl=!1,this.sourceType="mediaNode",this.source=this.context.createMediaElementSource(t),this.connect(),this
      }setMediaStreamSource(t){
      return this.hasPlaybackControl=!1,this.sourceType="mediaStreamNode",this.source=this.context.createMediaStreamSource(t),this.connect(),this
      }setBuffer(t){
      return this.buffer=t,this.sourceType="buffer",this.autoplay&&this.play(),this
      }play(t=0){
      if(!0===this.isPlaying)
      return void _("Audio: Audio is already playing.");
      if(!1===this.hasPlaybackControl)
      return void _("Audio: this Audio has no playback control.");
      this._startedAt=this.context.currentTime+t;
      let e=this.context.createBufferSource();
      return e.buffer=this.buffer,e.loop=this.loop,e.loopStart=this.loopStart,e.loopEnd=this.loopEnd,e.onended=this.onEnded.bind(this),e.start(this._startedAt,this._progress+this.offset,this.duration),this.isPlaying=!0,this.source=e,this.setDetune(this.detune),this.setPlaybackRate(this.playbackRate),this.connect()
      }pause(){
      return!1===this.hasPlaybackControl?void _("Audio: this Audio has no playback control."):(!0===this.isPlaying&&(this._progress+=Math.max(this.context.currentTime-this._startedAt,0)*this.playbackRate,!0===this.loop&&(this._progress=this._progress%(this.duration||this.buffer.duration)),this.source.stop(),this.source.onended=null,this.isPlaying=!1),this)
      }stop(t=0){
      return!1===this.hasPlaybackControl?void _("Audio: this Audio has no playback control."):(this._progress=0,null!==this.source&&(this.source.stop(this.context.currentTime+t),this.source.onended=null),this.isPlaying=!1,this)
      }connect(){
      if(this.filters.length>0){
        this.source.connect(this.filters[0]);
        for(
        let t=1,e=this.filters.length
        ;t<e;t++)
        this.filters[t-1].connect(this.filters[t]);
        this.filters[this.filters.length-1].connect(this.getOutput())
        }else 
      this.source.connect(this.getOutput());
      return this._connected=!0,this
      }disconnect(){
      if(!1!==this._connected){
        if(this.filters.length>0){
          this.source.disconnect(this.filters[0]);
          for(
          let t=1,e=this.filters.length
          ;t<e;t++)
          this.filters[t-1].disconnect(this.filters[t]);
          this.filters[this.filters.length-1].disconnect(this.getOutput())
          }else 
        this.source.disconnect(this.getOutput());
        return this._connected=!1,this
        }
      }getFilters(){
      return this.filters
      }setFilters(t){
      return t||(t=[]),!0===this._connected?(this.disconnect(),this.filters=t.slice(),this.connect()):this.filters=t.slice(),this
      }setDetune(t){
      return this.detune=t,!0===this.isPlaying&&void 0!==this.source.detune&&this.source.detune.setTargetAtTime(this.detune,this.context.currentTime,.01),this
      }getDetune(){
      return this.detune
      }getFilter(){
      return this.getFilters()[0]
      }setFilter(t){
      return this.setFilters(t?[t]:[])
      }setPlaybackRate(t){
      return!1===this.hasPlaybackControl?void _("Audio: this Audio has no playback control."):(this.playbackRate=t,!0===this.isPlaying&&this.source.playbackRate.setTargetAtTime(this.playbackRate,this.context.currentTime,.01),this)
      }getPlaybackRate(){
      return this.playbackRate
      }onEnded(){
      this.isPlaying=!1,this._progress=0
      }getLoop(){
      return!1===this.hasPlaybackControl?(_("Audio: this Audio has no playback control."),!1):this.loop
      }setLoop(t){
      return!1===this.hasPlaybackControl?void _("Audio: this Audio has no playback control."):(this.loop=t,!0===this.isPlaying&&(this.source.loop=this.loop),this)
      }setLoopStart(t){
      return this.loopStart=t,this
      }setLoopEnd(t){
      return this.loopEnd=t,this
      }getVolume(){
      return this.gain.gain.value
      }setVolume(t){
      return this.gain.gain.setTargetAtTime(t,this.context.currentTime,.01),this
      }copy(t,e){
      return(super.copy(t,e),"buffer"!==t.sourceType)?_("Audio: Audio source type cannot be copied."):(this.autoplay=t.autoplay,this.buffer=t.buffer,this.detune=t.detune,this.loop=t.loop,this.loopStart=t.loopStart,this.loopEnd=t.loopEnd,this.offset=t.offset,this.duration=t.duration,this.playbackRate=t.playbackRate,this.hasPlaybackControl=t.hasPlaybackControl,this.sourceType=t.sourceType,this.filters=t.filters.slice()),this
      }clone(t){
      return new this.constructor(this.listener).copy(this,t)
      }
  }
  let at=new D,ae=new V,ai=new D,as=new D;
  class ar{
    constructor(t,e,i){
      let s,r,n;
      switch(this.binding=t,this.valueSize=i,e){case"quaternion":
      s=this._slerp,r=this._slerpAdditive,n=this._setAdditiveIdentityQuaternion,this.buffer=new Float64Array(6*i),this._workIndex=5;
      break;
      case"string":case"bool":
      s=this._select,r=this._select,n=this._setAdditiveIdentityOther,this.buffer=Array(5*i);
      break;
      default:
      s=this._lerp,r=this._lerpAdditive,n=this._setAdditiveIdentityNumeric,this.buffer=new Float64Array(5*i)
      }
      this._mixBufferRegion=s,this._mixBufferRegionAdditive=r,this._setIdentity=n,this._origIndex=3,this._addIndex=4,this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,this.useCount=0,this.referenceCount=0
      }accumulate(t,e){
      let i=this.buffer,s=this.valueSize,r=t*s+s,n=this.cumulativeWeight;
      if(0===n){
        for(
        let t=0
        ;t!==s;++t)
        i[r+t]=i[t];
        n=e
        }else{
        n+=e;
        let t=e/n;
        this._mixBufferRegion(i,r,0,t,s)
        }
      this.cumulativeWeight=n
      }accumulateAdditive(t){
      let e=this.buffer,i=this.valueSize,s=i*this._addIndex;
      0===this.cumulativeWeightAdditive&&this._setIdentity(),this._mixBufferRegionAdditive(e,s,0,t,i),this.cumulativeWeightAdditive+=t
      }apply(t){
      let e=this.valueSize,i=this.buffer,s=t*e+e,r=this.cumulativeWeight,n=this.cumulativeWeightAdditive,a=this.binding;
      if(this.cumulativeWeight=0,this.cumulativeWeightAdditive=0,r<1){
        let t=e*this._origIndex;
        this._mixBufferRegion(i,s,t,1-r,e)
        }
      n>0&&this._mixBufferRegionAdditive(i,s,this._addIndex*e,1,e);
      for(
      let t=e,r=e+e
      ;t!==r;++t)
      if(i[t]!==i[t+e]){
        a.setValue(i,s);
        break
        }
      }saveOriginalState(){
      let t=this.binding,e=this.buffer,i=this.valueSize,s=i*this._origIndex;
      t.getValue(e,s);
      for(
      let t=i
      ;t!==s;++t)
      e[t]=e[s+t%i];
      this._setIdentity(),this.cumulativeWeight=0,this.cumulativeWeightAdditive=0
      }restoreOriginalState(){
      let t=3*this.valueSize;
      this.binding.setValue(this.buffer,t)
      }_setAdditiveIdentityNumeric(){
      let t=this._addIndex*this.valueSize,e=t+this.valueSize;
      for(
      let i=t
      ;i<e;i++)
      this.buffer[i]=0
      }_setAdditiveIdentityQuaternion(){
      this._setAdditiveIdentityNumeric(),this.buffer[this._addIndex*this.valueSize+3]=1
      }_setAdditiveIdentityOther(){
      let t=this._origIndex*this.valueSize,e=this._addIndex*this.valueSize;
      for(
      let i=0
      ;i<this.valueSize;i++)
      this.buffer[e+i]=this.buffer[t+i]
      }_select(t,e,i,s,r){
      if(s>=.5)
      for(
      let s=0
      ;s!==r;++s)
      t[e+s]=t[i+s]
      }_slerp(t,e,i,s){
      V.slerpFlat(t,e,t,e,t,i,s)
      }_slerpAdditive(t,e,i,s,r){
      let n=this._workIndex*r;
      V.multiplyQuaternionsFlat(t,n,t,e,t,i),V.slerpFlat(t,e,t,e,t,n,s)
      }_lerp(t,e,i,s,r){
      let n=1-s;
      for(
      let a=0
      ;a!==r;++a){
        let r=e+a;
        t[r]=t[r]*n+t[i+a]*s
        }
      }_lerpAdditive(t,e,i,s,r){
      for(
      let n=0
      ;n!==r;++n){
        let r=e+n;
        t[r]=t[r]+t[i+n]*s
        }
      }
  }
  let an="\\[\\]\\.:\\/",aa=RegExp("["+an+"]","g"),ao="[^"+an+"]",ah="[^"+an.replace("\\.","")+"]",al=RegExp("^"+/((?:WC+[\/:])*)/.source.replace("WC",ao)+/(WCOD+)?/.source.replace("WCOD",ah)+/(?:\.(WC+)(?:\[(.+)\])?)?/.source.replace("WC",ao)+/\.(WC+)(?:\[(.+)\])?/.source.replace("WC",ao)+"$"),au=["material","materials","bones","map"];
  class ac{
    constructor(t,e,i){
      this.path=e,this.parsedPath=i||ac.parseTrackName(e),this.node=ac.findNode(t,this.parsedPath.nodeName),this.rootNode=t,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound
      }static create(t,e,i){
      return t&&t.isAnimationObjectGroup?new ac.Composite(t,e,i):new ac(t,e,i)
      }static sanitizeNodeName(t){
      return t.replace(/\s/g,"_").replace(aa,"")
      }static parseTrackName(t){
      let e=al.exec(t);
      if(null===e)
      throw Error("PropertyBinding: Cannot parse trackName: "+t);
      let i={nodeName:e[2],objectName:e[3],objectIndex:e[4],propertyName:e[5],propertyIndex:e[6]},s=i.nodeName&&i.nodeName.lastIndexOf(".");
      if(void 0!==s&&-1!==s){
        let t=i.nodeName.substring(s+1);
        -1!==au.indexOf(t)&&(i.nodeName=i.nodeName.substring(0,s),i.objectName=t)
        }
      if(null===i.propertyName||0===i.propertyName.length)
      throw Error("PropertyBinding: can not parse propertyName from trackName: "+t);
      return i
      }static findNode(t,e){
      if(void 0===e||""===e||"."===e||-1===e||e===t.name||e===t.uuid)
      return t;
      if(t.skeleton){
        let i=t.skeleton.getBoneByName(e);
        if(void 0!==i)
        return i
        }
      if(t.children){
        let i=function(t){
          for(
          let s=0
          ;s<t.length;s++){
            let r=t[s];
            if(r.name===e||r.uuid===e)
            return r;
            let n=i(r.children);
            if(n)
            return n
            }
          return null
          },s=i(t.children);
        if(s)
        return s
        }
      return null
      }_getValue_unavailable(){
      }_setValue_unavailable(){
      }_getValue_direct(t,e){
      t[e]=this.targetObject[this.propertyName]
      }_getValue_array(t,e){
      let i=this.resolvedProperty;
      for(
      let s=0,r=i.length
      ;s!==r;++s)
      t[e++]=i[s]
      }_getValue_arrayElement(t,e){
      t[e]=this.resolvedProperty[this.propertyIndex]
      }_getValue_toArray(t,e){
      this.resolvedProperty.toArray(t,e)
      }_setValue_direct(t,e){
      this.targetObject[this.propertyName]=t[e]
      }_setValue_direct_setNeedsUpdate(t,e){
      this.targetObject[this.propertyName]=t[e],this.targetObject.needsUpdate=!0
      }_setValue_direct_setMatrixWorldNeedsUpdate(t,e){
      this.targetObject[this.propertyName]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0
      }_setValue_array(t,e){
      let i=this.resolvedProperty;
      for(
      let s=0,r=i.length
      ;s!==r;++s)
      i[s]=t[e++]
      }_setValue_array_setNeedsUpdate(t,e){
      let i=this.resolvedProperty;
      for(
      let s=0,r=i.length
      ;s!==r;++s)
      i[s]=t[e++];
      this.targetObject.needsUpdate=!0
      }_setValue_array_setMatrixWorldNeedsUpdate(t,e){
      let i=this.resolvedProperty;
      for(
      let s=0,r=i.length
      ;s!==r;++s)
      i[s]=t[e++];
      this.targetObject.matrixWorldNeedsUpdate=!0
      }_setValue_arrayElement(t,e){
      this.resolvedProperty[this.propertyIndex]=t[e]
      }_setValue_arrayElement_setNeedsUpdate(t,e){
      this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.needsUpdate=!0
      }_setValue_arrayElement_setMatrixWorldNeedsUpdate(t,e){
      this.resolvedProperty[this.propertyIndex]=t[e],this.targetObject.matrixWorldNeedsUpdate=!0
      }_setValue_fromArray(t,e){
      this.resolvedProperty.fromArray(t,e)
      }_setValue_fromArray_setNeedsUpdate(t,e){
      this.resolvedProperty.fromArray(t,e),this.targetObject.needsUpdate=!0
      }_setValue_fromArray_setMatrixWorldNeedsUpdate(t,e){
      this.resolvedProperty.fromArray(t,e),this.targetObject.matrixWorldNeedsUpdate=!0
      }_getValue_unbound(t,e){
      this.bind(),this.getValue(t,e)
      }_setValue_unbound(t,e){
      this.bind(),this.setValue(t,e)
      }bind(){
      let t=this.node,e=this.parsedPath,i=e.objectName,s=e.propertyName,r=e.propertyIndex;
      if(t||(t=ac.findNode(this.rootNode,e.nodeName),this.node=t),this.getValue=this._getValue_unavailable,this.setValue=this._setValue_unavailable,!t)
      return void _("PropertyBinding: No target node found for track: "+this.path+".");
      if(i){
        let s=e.objectIndex;
        switch(i){case"materials":
        if(!t.material)
        return void A("PropertyBinding: Can not bind to material as node does not have a material.",this);
        if(!t.material.materials)
        return void A("PropertyBinding: Can not bind to material.materials as node.material does not have a materials array.",this);
        t=t.material.materials;
        break;
        case"bones":
        if(!t.skeleton)
        return void A("PropertyBinding: Can not bind to bones as node does not have a skeleton.",this);
        t=t.skeleton.bones;
        for(
        let e=0
        ;e<t.length;e++)
        if(t[e].name===s){
          s=e;
          break
          }
        break;
        case"map":
        if("map"in t){
          t=t.map;
          break
          }
        if(!t.material)
        return void A("PropertyBinding: Can not bind to material as node does not have a material.",this);
        if(!t.material.map)
        return void A("PropertyBinding: Can not bind to material.map as node.material does not have a map.",this);
        t=t.material.map;
        break;
        default:
        if(void 0===t[i])
        return void A("PropertyBinding: Can not bind to objectName of node undefined.",this);
        t=t[i]
        }
        if(void 0!==s){
          if(void 0===t[s])
          return void A("PropertyBinding: Trying to bind to objectIndex of objectName, but is undefined.",this,t);
          t=t[s]
          }
        }
      let n=t[s];
      if(void 0===n)
      return void A("PropertyBinding: Trying to update property for track: "+e.nodeName+"."+s+" but it wasn't found.",t);
      let a=this.Versioning.None;
      this.targetObject=t,!0===t.isMaterial?a=this.Versioning.NeedsUpdate:!0===t.isObject3D&&(a=this.Versioning.MatrixWorldNeedsUpdate);
      let o=this.BindingType.Direct;
      if(void 0!==r){
        if("morphTargetInfluences"===s){
          if(!t.geometry)
          return void A("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.",this);
          if(!t.geometry.morphAttributes)
          return void A("PropertyBinding: Can not bind to morphTargetInfluences because node does not have a geometry.morphAttributes.",this);
          void 0!==t.morphTargetDictionary[r]&&(r=t.morphTargetDictionary[r])
          }
        o=this.BindingType.ArrayElement,this.resolvedProperty=n,this.propertyIndex=r
        }else 
      void 0!==n.fromArray&&void 0!==n.toArray?(o=this.BindingType.HasFromToArray,this.resolvedProperty=n):Array.isArray(n)?(o=this.BindingType.EntireArray,this.resolvedProperty=n):this.propertyName=s;
      this.getValue=this.GetterByBindingType[o],this.setValue=this.SetterByBindingTypeAndVersioning[o][a]
      }unbind(){
      this.node=null,this.getValue=this._getValue_unbound,this.setValue=this._setValue_unbound
      }
  }
  ac.Composite=class{
    constructor(t,e,i){
      const s=i||ac.parseTrackName(e);
      this._targetGroup=t,this._bindings=t.subscribe_(e,s)
      }getValue(t,e){
      this.bind();
      let i=this._targetGroup.nCachedObjects_,s=this._bindings[i];
      void 0!==s&&s.getValue(t,e)
      }setValue(t,e){
      let i=this._bindings;
      for(
      let s=this._targetGroup.nCachedObjects_,r=i.length
      ;s!==r;++s)
      i[s].setValue(t,e)
      }bind(){
      let t=this._bindings;
      for(
      let e=this._targetGroup.nCachedObjects_,i=t.length
      ;e!==i;++e)
      t[e].bind()
      }unbind(){
      let t=this._bindings;
      for(
      let e=this._targetGroup.nCachedObjects_,i=t.length
      ;e!==i;++e)
      t[e].unbind()
      }
  },ac.prototype.BindingType={Direct:0,EntireArray:1,ArrayElement:2,HasFromToArray:3},ac.prototype.Versioning={None:0,NeedsUpdate:1,MatrixWorldNeedsUpdate:2},ac.prototype.GetterByBindingType=[ac.prototype._getValue_direct,ac.prototype._getValue_array,ac.prototype._getValue_arrayElement,ac.prototype._getValue_toArray],ac.prototype.SetterByBindingTypeAndVersioning=[[ac.prototype._setValue_direct,ac.prototype._setValue_direct_setNeedsUpdate,ac.prototype._setValue_direct_setMatrixWorldNeedsUpdate],[ac.prototype._setValue_array,ac.prototype._setValue_array_setNeedsUpdate,ac.prototype._setValue_array_setMatrixWorldNeedsUpdate],[ac.prototype._setValue_arrayElement,ac.prototype._setValue_arrayElement_setNeedsUpdate,ac.prototype._setValue_arrayElement_setMatrixWorldNeedsUpdate],[ac.prototype._setValue_fromArray,ac.prototype._setValue_fromArray_setNeedsUpdate,ac.prototype._setValue_fromArray_setMatrixWorldNeedsUpdate]];
  class ap{
    constructor(t,e,i=null,s=e.blendMode){
      this._mixer=t,this._clip=e,this._localRoot=i,this.blendMode=s;
      const r=e.tracks,n=r.length,a=Array(n),o={endingStart:2400,endingEnd:2400};
      for(
      let t=0
      ;t!==n;++t){
        const e=r[t].createInterpolant(null);
        a[t]=e,e.settings&&Object.assign(o,e.settings),e.settings=o
        }
      this._interpolantSettings=o,this._interpolants=a,this._propertyBindings=Array(n),this._cacheIndex=null,this._byClipCacheIndex=null,this._timeScaleInterpolant=null,this._weightInterpolant=null,this.loop=2201,this._loopCount=-1,this._startTime=null,this.time=0,this.timeScale=1,this._effectiveTimeScale=1,this.weight=1,this._effectiveWeight=1,this.repetitions=1/0,this.paused=!1,this.enabled=!0,this.clampWhenFinished=!1,this.zeroSlopeAtStart=!0,this.zeroSlopeAtEnd=!0
      }play(){
      return this._mixer._activateAction(this),this
      }stop(){
      return this._mixer._deactivateAction(this),this.reset()
      }reset(){
      return this.paused=!1,this.enabled=!0,this.time=0,this._loopCount=-1,this._startTime=null,this.stopFading().stopWarping()
      }isRunning(){
      return this.enabled&&!this.paused&&0!==this.timeScale&&null===this._startTime&&this._mixer._isActiveAction(this)
      }isScheduled(){
      return this._mixer._isActiveAction(this)
      }startAt(t){
      return this._startTime=t,this
      }setLoop(t,e){
      return this.loop=t,this.repetitions=e,this
      }setEffectiveWeight(t){
      return this.weight=t,this._effectiveWeight=this.enabled?t:0,this.stopFading()
      }getEffectiveWeight(){
      return this._effectiveWeight
      }fadeIn(t){
      return this._scheduleFading(t,0,1)
      }fadeOut(t){
      return this._scheduleFading(t,1,0)
      }crossFadeFrom(t,e,i=!1){
      if(t.fadeOut(e),this.fadeIn(e),!0===i){
        let i=this._clip.duration,s=t._clip.duration;
        t.warp(1,s/i,e),this.warp(i/s,1,e)
        }
      return this
      }crossFadeTo(t,e,i=!1){
      return t.crossFadeFrom(this,e,i)
      }stopFading(){
      let t=this._weightInterpolant;
      return null!==t&&(this._weightInterpolant=null,this._mixer._takeBackControlInterpolant(t)),this
      }setEffectiveTimeScale(t){
      return this.timeScale=t,this._effectiveTimeScale=this.paused?0:t,this.stopWarping()
      }getEffectiveTimeScale(){
      return this._effectiveTimeScale
      }setDuration(t){
      return this.timeScale=this._clip.duration/t,this.stopWarping()
      }syncWith(t){
      return this.time=t.time,this.timeScale=t.timeScale,this.stopWarping()
      }halt(t){
      return this.warp(this._effectiveTimeScale,0,t)
      }warp(t,e,i){
      let s=this._mixer,r=s.time,n=this.timeScale,a=this._timeScaleInterpolant;
      null===a&&(a=s._lendControlInterpolant(),this._timeScaleInterpolant=a);
      let o=a.parameterPositions,h=a.sampleValues;
      return o[0]=r,o[1]=r+i,h[0]=t/n,h[1]=e/n,this
      }stopWarping(){
      let t=this._timeScaleInterpolant;
      return null!==t&&(this._timeScaleInterpolant=null,this._mixer._takeBackControlInterpolant(t)),this
      }getMixer(){
      return this._mixer
      }getClip(){
      return this._clip
      }getRoot(){
      return this._localRoot||this._mixer._root
      }_update(t,e,i,s){
      if(!this.enabled)
      return void this._updateWeight(t);
      let r=this._startTime;
      if(null!==r){
        let s=(t-r)*i;
        s<0||0===i?e=0:(this._startTime=null,e=i*s)
        }
      e*=this._updateTimeScale(t);
      let n=this._updateTime(e),a=this._updateWeight(t);
      if(a>0){
        let t=this._interpolants,e=this._propertyBindings;
        if(2501===this.blendMode)
        for(
        let i=0,s=t.length
        ;i!==s;++i)
        t[i].evaluate(n),e[i].accumulateAdditive(a);
        else 
        for(
        let i=0,r=t.length
        ;i!==r;++i)
        t[i].evaluate(n),e[i].accumulate(s,a)
        }
      }_updateWeight(t){
      let e=0;
      if(this.enabled){
        e=this.weight;
        let i=this._weightInterpolant;
        if(null!==i){
          let s=i.evaluate(t)[0];
          e*=s,t>i.parameterPositions[1]&&(this.stopFading(),0===s&&(this.enabled=!1))
          }
        }
      return this._effectiveWeight=e,e
      }_updateTimeScale(t){
      let e=0;
      if(!this.paused){
        e=this.timeScale;
        let i=this._timeScaleInterpolant;
        null!==i&&(e*=i.evaluate(t)[0],t>i.parameterPositions[1]&&(this.stopWarping(),0===e?this.paused=!0:this.timeScale=e))
        }
      return this._effectiveTimeScale=e,e
      }_updateTime(t){
      let e=this._clip.duration,i=this.loop,s=this.time+t,r=this._loopCount,n=2202===i;
      if(0===t)
      return -1===r?s:n&&(1&r)==1?e-s:s;
      if(2200===i){
        -1===r&&(this._loopCount=0,this._setEndings(!0,!0,!1));
        r:{
          if(s>=e)
          s=e;
          else 
          if(s<0)
          s=0;
          else{
            this.time=s;
            break r
            }
          this.clampWhenFinished?this.paused=!0:this.enabled=!1,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:t<0?-1:1})
          }
        }else{
        if(-1===r&&(t>=0?(r=0,this._setEndings(!0,0===this.repetitions,n)):this._setEndings(0===this.repetitions,!0,n)),s>=e||s<0){
          let i=Math.floor(s/e);
          s-=e*i,r+=Math.abs(i);
          let a=this.repetitions-r;
          if(a<=0)
          this.clampWhenFinished?this.paused=!0:this.enabled=!1,s=t>0?e:0,this.time=s,this._mixer.dispatchEvent({type:"finished",action:this,direction:t>0?1:-1});
          else{
            if(1===a){
              let e=t<0;
              this._setEndings(e,!e,n)
              }else 
            this._setEndings(!1,!1,n);
            this._loopCount=r,this.time=s,this._mixer.dispatchEvent({type:"loop",action:this,loopDelta:i})
            }
          }else 
        this._loopCount=r,this.time=s;
        if(n&&(1&r)==1)
        return e-s
        }
      return s
      }_setEndings(t,e,i){
      let s=this._interpolantSettings;
      i?(s.endingStart=2401,s.endingEnd=2401):(t?s.endingStart=this.zeroSlopeAtStart?2401:2400:s.endingStart=2402,e?s.endingEnd=this.zeroSlopeAtEnd?2401:2400:s.endingEnd=2402)
      }_scheduleFading(t,e,i){
      let s=this._mixer,r=s.time,n=this._weightInterpolant;
      null===n&&(n=s._lendControlInterpolant(),this._weightInterpolant=n);
      let a=n.parameterPositions,o=n.sampleValues;
      return a[0]=r,o[0]=e,a[1]=r+t,o[1]=i,this
      }
  }
  let ad=new Float32Array(1);
  class am{
    constructor(t){
      this.value=t
      }clone(){
      return new am(void 0===this.value.clone?this.value:this.value.clone())
      }
  }
  let ay=0,af=new th;
  function ag(t,e){
    return t.distance-e.distance
    }
  function ax(t,e,i,s){
    let r=!0;
    if(t.layers.test(e.layers)&&!1===t.raycast(e,i)&&(r=!1),!0===r&&!0===s){
      let s=t.children;
      for(
      let t=0,r=s.length
      ;t<r;t++)
      ax(s[t],e,i,!0)
      }
    }
  class ab{
    static{
    ab.prototype.isMatrix2=!0
    }constructor(t,e,i,s){
      this.elements=[1,0,0,1],void 0!==t&&this.set(t,e,i,s)
      }identity(){
      return this.set(1,0,0,1),this
      }fromArray(t,e=0){
      for(
      let i=0
      ;i<4;i++)
      this.elements[i]=t[i+e];
      return this
      }set(t,e,i,s){
      let r=this.elements;
      return r[0]=t,r[2]=e,r[1]=i,r[3]=s,this
      }
  }
  let av=new E,aM=new D,aw=new D,aS=new D,a_=new D,aA=new D,aT=new D,aC=new D,aI=new D,az=new D,aB=new th,ak=new th,aO=new D,aR=new tj,aP=new tj,aF=new D,aL=new D,aN=new D,aE=new D,aV=new nC;
  function aD(t,e,i,s,r,n,a){
    aE.set(r,n,a).unproject(s);
    let o=e[t];
    if(void 0!==o){
      let t=i.getAttribute("position");
      for(
      let e=0,i=o.length
      ;e<i;e++)
      t.setXYZ(o[e],aE.x,aE.y,aE.z)
      }
    }
  let aU=new t8,aj=new D;
  function aW(t,e,i,s){
    let r=function(t){
      switch(t){case 1009:case 1010:
      return{byteLength:1,components:1};
      case 1012:case 1011:case 1016:
      return{byteLength:2,components:1};
      case 1017:case 1018:
      return{byteLength:2,components:4};
      case 1014:case 1013:case 1015:
      return{byteLength:4,components:1};
      case 35902:case 35899:
      return{byteLength:4,components:3}
      }
      throw Error(`Unknown texture type ${t}.`)
      }(s);
    switch(i){case 1021:
    return t*e;
    case 1028:case 1029:
    return t*e/r.components*r.byteLength;
    case 1030:case 1031:
    return t*e*2/r.components*r.byteLength;
    case 1022:
    return t*e*3/r.components*r.byteLength;
    case 1023:case 1033:
    return t*e*4/r.components*r.byteLength;
    case 33776:case 33777:case 36196:case 37492:case 37488:case 37489:
    return Math.floor((t+3)/4)*Math.floor((e+3)/4)*8;
    case 33778:case 33779:case 37496:case 37490:case 37491:case 37808:
    return Math.floor((t+3)/4)*Math.floor((e+3)/4)*16;
    case 35841:case 35843:
    return Math.max(t,16)*Math.max(e,8)/4;
    case 35840:case 35842:
    return Math.max(t,8)*Math.max(e,8)/2;
    case 37809:
    return Math.floor((t+4)/5)*Math.floor((e+3)/4)*16;
    case 37810:
    return Math.floor((t+4)/5)*Math.floor((e+4)/5)*16;
    case 37811:
    return Math.floor((t+5)/6)*Math.floor((e+4)/5)*16;
    case 37812:
    return Math.floor((t+5)/6)*Math.floor((e+5)/6)*16;
    case 37813:
    return Math.floor((t+7)/8)*Math.floor((e+4)/5)*16;
    case 37814:
    return Math.floor((t+7)/8)*Math.floor((e+5)/6)*16;
    case 37815:
    return Math.floor((t+7)/8)*Math.floor((e+7)/8)*16;
    case 37816:
    return Math.floor((t+9)/10)*Math.floor((e+4)/5)*16;
    case 37817:
    return Math.floor((t+9)/10)*Math.floor((e+5)/6)*16;
    case 37818:
    return Math.floor((t+9)/10)*Math.floor((e+7)/8)*16;
    case 37819:
    return Math.floor((t+9)/10)*Math.floor((e+9)/10)*16;
    case 37820:
    return Math.floor((t+11)/12)*Math.floor((e+9)/10)*16;
    case 37821:
    return Math.floor((t+11)/12)*Math.floor((e+11)/12)*16;
    case 36492:case 36494:case 36495:case 36285:case 36286:
    return Math.ceil(t/4)*Math.ceil(e/4)*16;
    case 36283:case 36284:
    return Math.ceil(t/4)*Math.ceil(e/4)*8
    }
    throw Error(`Unable to determine texture byte length for ${i} format.`)
    }
  "u">typeof __THREE_DEVTOOLS__&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("register",{detail:{revision:"184"}})),"u">typeof window&&(window.__THREE__?_("WARNING: Multiple instances of Three.js being imported."):window.__THREE__="184"),t.s(["ACESFilmicToneMapping",0,4,"AddEquation",0,100,"AddOperation",0,2,"AdditiveAnimationBlendMode",0,2501,"AdditiveBlending",0,2,"AgXToneMapping",0,6,"AlphaFormat",0,1021,"AlwaysCompare",0,519,"AlwaysDepth",0,1,"AlwaysStencilFunc",0,519,"AmbientLight",0,nV,"AnimationAction",0,ap,"AnimationClip",0,no,"AnimationLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=this,n=new ny(this.manager);
      n.setPath(this.path),n.setRequestHeader(this.requestHeader),n.setWithCredentials(this.withCredentials),n.load(t,function(i){
        try{
          e(r.parse(JSON.parse(i)))
          }catch(e){
          s?s(e):A(e),r.manager.itemError(t)
          }
        },i,s)
      }parse(t){
      let e=[];
      for(
      let i=0
      ;i<t.length;i++){
        let s=no.parse(t[i]);
        e.push(s)
        }
      return e
      }
  },"AnimationMixer",0,class extends C{
    constructor(t){
      super(),this._root=t,this._initMemoryManager(),this._accuIndex=0,this.time=0,this.timeScale=1,"u">typeof __THREE_DEVTOOLS__&&__THREE_DEVTOOLS__.dispatchEvent(new CustomEvent("observe",{detail:this}))
      }_bindAction(t,e){
      let i=t._localRoot||this._root,s=t._clip.tracks,r=s.length,n=t._propertyBindings,a=t._interpolants,o=i.uuid,h=this._bindingsByRootAndName,l=h[o];
      void 0===l&&(l={},h[o]=l);
      for(
      let t=0
      ;t!==r;++t){
        let r=s[t],h=r.name,u=l[h];
        if(void 0!==u)
        ++u.referenceCount,n[t]=u;
        else{
          if(void 0!==(u=n[t])){
            null===u._cacheIndex&&(++u.referenceCount,this._addInactiveBinding(u,o,h));
            continue
            }
          let s=e&&e._propertyBindings[t].binding.parsedPath;
          u=new ar(ac.create(i,h,s),r.ValueTypeName,r.getValueSize()),++u.referenceCount,this._addInactiveBinding(u,o,h),n[t]=u
          }
        a[t].resultBuffer=u.buffer
        }
      }_activateAction(t){
      if(!this._isActiveAction(t)){
        if(null===t._cacheIndex){
          let e=(t._localRoot||this._root).uuid,i=t._clip.uuid,s=this._actionsByClip[i];
          this._bindAction(t,s&&s.knownActions[0]),this._addInactiveAction(t,i,e)
          }
        let e=t._propertyBindings;
        for(
        let t=0,i=e.length
        ;t!==i;++t){
          let i=e[t];
          0==i.useCount++&&(this._lendBinding(i),i.saveOriginalState())
          }
        this._lendAction(t)
        }
      }_deactivateAction(t){
      if(this._isActiveAction(t)){
        let e=t._propertyBindings;
        for(
        let t=0,i=e.length
        ;t!==i;++t){
          let i=e[t];
          0==--i.useCount&&(i.restoreOriginalState(),this._takeBackBinding(i))
          }
        this._takeBackAction(t)
        }
      }_initMemoryManager(){
      this._actions=[],this._nActiveActions=0,this._actionsByClip={},this._bindings=[],this._nActiveBindings=0,this._bindingsByRootAndName={},this._controlInterpolants=[],this._nActiveControlInterpolants=0;
      let t=this;
      this.stats={actions:{get total(){
        return t._actions.length
        },get inUse(){
        return t._nActiveActions
        }},bindings:{get total(){
        return t._bindings.length
        },get inUse(){
        return t._nActiveBindings
        }},controlInterpolants:{get total(){
        return t._controlInterpolants.length
        },get inUse(){
        return t._nActiveControlInterpolants
        }}}
      }_isActiveAction(t){
      let e=t._cacheIndex;
      return null!==e&&e<this._nActiveActions
      }_addInactiveAction(t,e,i){
      let s=this._actions,r=this._actionsByClip,n=r[e];
      if(void 0===n)
      n={knownActions:[t],actionByRoot:{}},t._byClipCacheIndex=0,r[e]=n;
      else{
        let e=n.knownActions;
        t._byClipCacheIndex=e.length,e.push(t)
        }
      t._cacheIndex=s.length,s.push(t),n.actionByRoot[i]=t
      }_removeInactiveAction(t){
      let e=this._actions,i=e[e.length-1],s=t._cacheIndex;
      i._cacheIndex=s,e[s]=i,e.pop(),t._cacheIndex=null;
      let r=t._clip.uuid,n=this._actionsByClip,a=n[r],o=a.knownActions,h=o[o.length-1],l=t._byClipCacheIndex;
      h._byClipCacheIndex=l,o[l]=h,o.pop(),t._byClipCacheIndex=null;
      let u=a.actionByRoot,c=(t._localRoot||this._root).uuid;
      delete u[c],0===o.length&&delete n[r],this._removeInactiveBindingsForAction(t)
      }_removeInactiveBindingsForAction(t){
      let e=t._propertyBindings;
      for(
      let t=0,i=e.length
      ;t!==i;++t){
        let i=e[t];
        0==--i.referenceCount&&this._removeInactiveBinding(i)
        }
      }_lendAction(t){
      let e=this._actions,i=t._cacheIndex,s=this._nActiveActions++,r=e[s];
      t._cacheIndex=s,e[s]=t,r._cacheIndex=i,e[i]=r
      }_takeBackAction(t){
      let e=this._actions,i=t._cacheIndex,s=--this._nActiveActions,r=e[s];
      t._cacheIndex=s,e[s]=t,r._cacheIndex=i,e[i]=r
      }_addInactiveBinding(t,e,i){
      let s=this._bindingsByRootAndName,r=this._bindings,n=s[e];
      void 0===n&&(n={},s[e]=n),n[i]=t,t._cacheIndex=r.length,r.push(t)
      }_removeInactiveBinding(t){
      let e=this._bindings,i=t.binding,s=i.rootNode.uuid,r=i.path,n=this._bindingsByRootAndName,a=n[s],o=e[e.length-1],h=t._cacheIndex;
      o._cacheIndex=h,e[h]=o,e.pop(),delete a[r],0===Object.keys(a).length&&delete n[s]
      }_lendBinding(t){
      let e=this._bindings,i=t._cacheIndex,s=this._nActiveBindings++,r=e[s];
      t._cacheIndex=s,e[s]=t,r._cacheIndex=i,e[i]=r
      }_takeBackBinding(t){
      let e=this._bindings,i=t._cacheIndex,s=--this._nActiveBindings,r=e[s];
      t._cacheIndex=s,e[s]=t,r._cacheIndex=i,e[i]=r
      }_lendControlInterpolant(){
      let t=this._controlInterpolants,e=this._nActiveControlInterpolants++,i=t[e];
      return void 0===i&&((i=new r6(new Float32Array(2),new Float32Array(2),1,ad)).__cacheIndex=e,t[e]=i),i
      }_takeBackControlInterpolant(t){
      let e=this._controlInterpolants,i=t.__cacheIndex,s=--this._nActiveControlInterpolants,r=e[s];
      t.__cacheIndex=s,e[s]=t,r.__cacheIndex=i,e[i]=r
      }clipAction(t,e,i){
      let s=e||this._root,r=s.uuid,n="string"==typeof t?no.findByName(s,t):t,a=null!==n?n.uuid:t,o=this._actionsByClip[a],h=null;
      if(void 0===i&&(i=null!==n?n.blendMode:2500),void 0!==o){
        let t=o.actionByRoot[r];
        if(void 0!==t&&t.blendMode===i)
        return t;
        h=o.knownActions[0],null===n&&(n=h._clip)
        }
      if(null===n)
      return null;
      let l=new ap(this,n,e,i);
      return this._bindAction(l,h),this._addInactiveAction(l,a,r),l
      }existingAction(t,e){
      let i=e||this._root,s=i.uuid,r="string"==typeof t?no.findByName(i,t):t,n=r?r.uuid:t,a=this._actionsByClip[n];
      return void 0!==a&&a.actionByRoot[s]||null
      }stopAllAction(){
      let t=this._actions,e=this._nActiveActions;
      for(
      let i=e-1
      ;i>=0;--i)
      t[i].stop();
      return this
      }update(t){
      t*=this.timeScale;
      let e=this._actions,i=this._nActiveActions,s=this.time+=t,r=Math.sign(t),n=this._accuIndex^=1;
      for(
      let a=0
      ;a!==i;++a)
      e[a]._update(s,t,r,n);
      let a=this._bindings,o=this._nActiveBindings;
      for(
      let t=0
      ;t!==o;++t)
      a[t].apply(n);
      return this
      }setTime(t){
      this.time=0;
      for(
      let t=0
      ;t<this._actions.length;t++)
      this._actions[t].time=0;
      return this.update(t)
      }getRoot(){
      return this._root
      }uncacheClip(t){
      let e=this._actions,i=t.uuid,s=this._actionsByClip,r=s[i];
      if(void 0!==r){
        let t=r.knownActions;
        for(
        let i=0,s=t.length
        ;i!==s;++i){
          let s=t[i];
          this._deactivateAction(s);
          let r=s._cacheIndex,n=e[e.length-1];
          s._cacheIndex=null,s._byClipCacheIndex=null,n._cacheIndex=r,e[r]=n,e.pop(),this._removeInactiveBindingsForAction(s)
          }
        delete s[i]
        }
      }uncacheRoot(t){
      let e=t.uuid,i=this._actionsByClip;
      for(
      let t
       in i){
        let s=i[t].actionByRoot[e];
        void 0!==s&&(this._deactivateAction(s),this._removeInactiveAction(s))
        }
      let s=this._bindingsByRootAndName[e];
      if(void 0!==s)
      for(
      let t
       in s){
        let e=s[t];
        e.restoreOriginalState(),this._removeInactiveBinding(e)
        }
      }uncacheAction(t,e){
      let i=this.existingAction(t,e);
      null!==i&&(this._deactivateAction(i),this._removeInactiveAction(i))
      }
  },"AnimationObjectGroup",0,class{
    constructor(){
      this.isAnimationObjectGroup=!0,this.uuid=O(),this._objects=Array.prototype.slice.call(arguments),this.nCachedObjects_=0;
      const t={};
      this._indicesByUUID=t;
      for(
      let e=0,i=arguments.length
      ;e!==i;++e)
      t[arguments[e].uuid]=e;
      this._paths=[],this._parsedPaths=[],this._bindings=[],this._bindingsIndicesByPath={};
      const e=this;
      this.stats={objects:{get total(){
        return e._objects.length
        },get inUse(){
        return this.total-e.nCachedObjects_
        }},get bindingsPerObject(){
        return e._bindings.length
        }}
      }add(){
      let t=this._objects,e=this._indicesByUUID,i=this._paths,s=this._parsedPaths,r=this._bindings,n=r.length,a,o=t.length,h=this.nCachedObjects_;
      for(
      let l=0,u=arguments.length
      ;l!==u;++l){
        let u=arguments[l],c=u.uuid,p=e[c];
        if(void 0===p){
          p=o++,e[c]=p,t.push(u);
          for(
          let t=0
          ;t!==n;++t)
          r[t].push(new ac(u,i[t],s[t]))
          }else 
        if(p<h){
          a=t[p];
          let o=--h,l=t[o];
          e[l.uuid]=p,t[p]=l,e[c]=o,t[o]=u;
          for(
          let t=0
          ;t!==n;++t){
            let e=r[t],n=e[o],a=e[p];
            e[p]=n,void 0===a&&(a=new ac(u,i[t],s[t])),e[o]=a
            }
          }else 
        t[p]!==a&&A("AnimationObjectGroup: Different objects with the same UUID detected. Clean the caches or recreate your infrastructure when reloading scenes.")
        }
      this.nCachedObjects_=h
      }remove(){
      let t=this._objects,e=this._indicesByUUID,i=this._bindings,s=i.length,r=this.nCachedObjects_;
      for(
      let n=0,a=arguments.length
      ;n!==a;++n){
        let a=arguments[n],o=a.uuid,h=e[o];
        if(void 0!==h&&h>=r){
          let n=r++,l=t[n];
          e[l.uuid]=h,t[h]=l,e[o]=n,t[n]=a;
          for(
          let t=0
          ;t!==s;++t){
            let e=i[t],s=e[n],r=e[h];
            e[h]=s,e[n]=r
            }
          }
        }
      this.nCachedObjects_=r
      }uncache(){
      let t=this._objects,e=this._indicesByUUID,i=this._bindings,s=i.length,r=this.nCachedObjects_,n=t.length;
      for(
      let a=0,o=arguments.length
      ;a!==o;++a){
        let o=arguments[a],h=o.uuid,l=e[h];
        if(void 0!==l)
        if(delete e[h],l<r){
          let a=--r,o=t[a],h=--n,u=t[h];
          e[o.uuid]=l,t[l]=o,e[u.uuid]=a,t[a]=u,t.pop();
          for(
          let t=0
          ;t!==s;++t){
            let e=i[t],s=e[a],r=e[h];
            e[l]=s,e[a]=r,e.pop()
            }
          }else{
          let r=--n,a=t[r];
          r>0&&(e[a.uuid]=l),t[l]=a,t.pop();
          for(
          let t=0
          ;t!==s;++t){
            let e=i[t];
            e[l]=e[r],e.pop()
            }
          }
        }
      this.nCachedObjects_=r
      }subscribe_(t,e){
      let i=this._bindingsIndicesByPath,s=i[t],r=this._bindings;
      if(void 0!==s)
      return r[s];
      let n=this._paths,a=this._parsedPaths,o=this._objects,h=o.length,l=this.nCachedObjects_,u=Array(h);
      s=r.length,i[t]=s,n.push(t),a.push(e),r.push(u);
      for(
      let i=l,s=o.length
      ;i!==s;++i){
        let s=o[i];
        u[i]=new ac(s,t,e)
        }
      return u
      }unsubscribe_(t){
      let e=this._bindingsIndicesByPath,i=e[t];
      if(void 0!==i){
        let s=this._paths,r=this._parsedPaths,n=this._bindings,a=n.length-1,o=n[a];
        e[t[a]]=i,n[i]=o,n.pop(),r[i]=r[a],r.pop(),s[i]=s[a],s.pop()
        }
      }
  },"AnimationUtils",0,class{
    static convertArray(t,e){
      return r0(t,e)
      }static isTypedArray(t){
      return x(t)
      }static getKeyframeOrder(t){
      return r1(t)
      }static sortedArray(t,e,i){
      return r2(t,e,i)
      }static flattenJSON(t,e,i,s){
      r3(t,e,i,s)
      }static subclip(t,e,i,s,r=30){
      return function(t,e,i,s,r=30){
        let n=t.clone();
        n.name=e;
        let a=[];
        for(
        let t=0
        ;t<n.tracks.length;++t){
          let e=n.tracks[t],o=e.getValueSize(),h=[],l=[];
          for(
          let t=0
          ;t<e.times.length;++t){
            let n=e.times[t]*r;
            if(!(n<i)&&!(n>=s)){
              h.push(e.times[t]);
              for(
              let i=0
              ;i<o;++i)
              l.push(e.values[t*o+i])
              }
            }
          0!==h.length&&(e.times=r0(h,e.times.constructor),e.values=r0(l,e.values.constructor),a.push(e))
          }
        n.tracks=a;
        let o=1/0;
        for(
        let t=0
        ;t<n.tracks.length;++t)
        o>n.tracks[t].times[0]&&(o=n.tracks[t].times[0]);
        for(
        let t=0
        ;t<n.tracks.length;++t)
        n.tracks[t].shift(-1*o);
        return n.resetDuration(),n
        }(t,e,i,s,r)
      }static makeClipAdditive(t,e=0,i=t,s=30){
      return function(t,e=0,i=t,s=30){
        s<=0&&(s=30);
        let r=i.tracks.length,n=e/s;
        for(
        let e=0
        ;e<r;++e){
          let s,r=i.tracks[e],a=r.ValueTypeName;
          if("bool"===a||"string"===a)
          continue;
          let o=t.tracks.find(function(t){
            return t.name===r.name&&t.ValueTypeName===a
            });
          if(void 0===o)
          continue;
          let h=0,l=r.getValueSize();
          r.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline&&(h=l/3);
          let u=0,c=o.getValueSize();
          o.createInterpolant.isInterpolantFactoryMethodGLTFCubicSpline&&(u=c/3);
          let p=r.times.length-1;
          if(n<=r.times[0]){
            let t=h,e=l-h;
            s=r.values.slice(t,e)
            }else 
          if(n>=r.times[p]){
            let t=p*l+h,e=t+l-h;
            s=r.values.slice(t,e)
            }else{
            let t=r.createInterpolant(),e=h,i=l-h;
            t.evaluate(n),s=t.resultBuffer.slice(e,i)
            }
          "quaternion"===a&&new V().fromArray(s).normalize().conjugate().toArray(s);
          let d=o.times.length;
          for(
          let t=0
          ;t<d;++t){
            let e=t*c+u;
            if("quaternion"===a)
            V.multiplyQuaternionsFlat(o.values,e,s,0,o.values,e);
            else{
              let t=c-2*u;
              for(
              let i=0
              ;i<t;++i)
              o.values[e+i]-=s[i]
              }
            }
          }
        return t.blendMode=2501,t
        }(t,e,i,s)
      }
  },"ArcCurve",0,sG,"ArrayCamera",0,class extends nk{
    constructor(t=[]){
      super(),this.isArrayCamera=!0,this.isMultiViewCamera=!1,this.cameras=t
      }
  },"ArrowHelper",0,class extends tF{
    constructor(t=new D(0,0,1),e=new D(0,0,0),i=1,s=0xffff00,a=.2*i,o=.2*a){
      super(),this.type="ArrowHelper",void 0===r&&((r=new eR).setAttribute("position",new eM([0,0,0,0,1,0],3)),(n=new sP(.5,1,5,1)).translate(0,-.5,0)),this.position.copy(e),this.line=new sd(r,new sn({color:s,toneMapped:!1})),this.line.matrixAutoUpdate=!1,this.add(this.line),this.cone=new im(n,new ie({color:s,toneMapped:!1})),this.cone.matrixAutoUpdate=!1,this.add(this.cone),this.setDirection(t),this.setLength(i,a,o)
      }setDirection(t){
      if(t.y>.99999)
      this.quaternion.set(0,0,0,1);
      else 
      if(t.y<-.99999)
      this.quaternion.set(1,0,0,0);
      else{
        aj.set(t.z,0,-t.x).normalize();
        let e=Math.acos(t.y);
        this.quaternion.setFromAxisAngle(aj,e)
        }
      }setLength(t,e=.2*t,i=.2*e){
      this.line.scale.set(1,Math.max(1e-4,t-e),1),this.line.updateMatrix(),this.cone.scale.set(i,e,i),this.cone.position.y=t,this.cone.updateMatrix()
      }setColor(t){
      this.line.material.color.set(t),this.cone.material.color.set(t)
      }copy(t){
      return super.copy(t,!1),this.line.copy(t.line),this.cone.copy(t.cone),this
      }dispose(){
      this.line.geometry.dispose(),this.line.material.dispose(),this.cone.geometry.dispose(),this.cone.material.dispose()
      }
  },"AttachedBindMode",0,u,"Audio",0,n7,"AudioAnalyser",0,class{
    constructor(t,e=2048){
      this.analyser=t.context.createAnalyser(),this.analyser.fftSize=e,this.data=new Uint8Array(this.analyser.frequencyBinCount),t.getOutput().connect(this.analyser)
      }getFrequencyData(){
      return this.analyser.getByteFrequencyData(this.data),this.data
      }getAverageFrequency(){
      let t=0,e=this.getFrequencyData();
      for(
      let i=0
      ;i<e.length;i++)
      t+=e[i];
      return t/e.length
      }
  },"AudioContext",0,nQ,"AudioListener",0,class extends tF{
    constructor(){
      super(),this.type="AudioListener",this.context=nQ.getContext(),this.gain=this.context.createGain(),this.gain.connect(this.context.destination),this.filter=null,this.timeDelta=0,this._timer=new n2
      }getInput(){
      return this.gain
      }removeFilter(){
      return null!==this.filter&&(this.gain.disconnect(this.filter),this.filter.disconnect(this.context.destination),this.gain.connect(this.context.destination),this.filter=null),this
      }getFilter(){
      return this.filter
      }setFilter(t){
      return null!==this.filter?(this.gain.disconnect(this.filter),this.filter.disconnect(this.context.destination)):this.gain.disconnect(this.context.destination),this.filter=t,this.gain.connect(this.filter),this.filter.connect(this.context.destination),this
      }getMasterVolume(){
      return this.gain.gain.value
      }setMasterVolume(t){
      return this.gain.gain.setTargetAtTime(t,this.context.currentTime,.01),this
      }updateMatrixWorld(t){
      super.updateMatrixWorld(t),this._timer.update();
      let e=this.context.listener;
      if(this.timeDelta=this._timer.getDelta(),this.matrixWorld.decompose(n5,n4,n6),n8.set(0,0,-1).applyQuaternion(n4),n9.set(0,1,0).applyQuaternion(n4),e.positionX){
        let t=this.context.currentTime+this.timeDelta;
        e.positionX.linearRampToValueAtTime(n5.x,t),e.positionY.linearRampToValueAtTime(n5.y,t),e.positionZ.linearRampToValueAtTime(n5.z,t),e.forwardX.linearRampToValueAtTime(n8.x,t),e.forwardY.linearRampToValueAtTime(n8.y,t),e.forwardZ.linearRampToValueAtTime(n8.z,t),e.upX.linearRampToValueAtTime(n9.x,t),e.upY.linearRampToValueAtTime(n9.y,t),e.upZ.linearRampToValueAtTime(n9.z,t)
        }else 
      e.setPosition(n5.x,n5.y,n5.z),e.setOrientation(n8.x,n8.y,n8.z,n9.x,n9.y,n9.z)
      }
  },"AudioLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=this,n=new ny(this.manager);
      function a(e){
        s?s(e):A(e),r.manager.itemError(t)
        }
      n.setResponseType("arraybuffer"),n.setPath(this.path),n.setRequestHeader(this.requestHeader),n.setWithCredentials(this.withCredentials),n.load(t,function(i){
        try{
          let s=i.slice(0),n=nQ.getContext(),o=t+"#decode";
          r.manager.itemStart(o),n.decodeAudioData(s,function(t){
            e(t),r.manager.itemEnd(o)
            }).catch(function(t){
            a(t),r.manager.itemEnd(o)
            })
          }catch(t){
          a(t)
          }
        },i,s)
      }
  },"AxesHelper",0,class extends sg{
    constructor(t=1){
      const e=new eR;
      e.setAttribute("position",new eM([0,0,0,t,0,0,0,0,0,0,t,0,0,0,0,0,0,t],3)),e.setAttribute("color",new eM([1,0,0,1,.6,0,0,1,0,.6,1,0,0,0,1,0,.6,1],3)),super(e,new sn({vertexColors:!0,toneMapped:!1})),this.type="AxesHelper"
      }setColors(t,e,i){
      let s=new tj,r=this.geometry.attributes.color.array;
      return s.set(t),s.toArray(r,0),s.toArray(r,3),s.set(e),s.toArray(r,6),s.toArray(r,9),s.set(i),s.toArray(r,12),s.toArray(r,15),this.geometry.attributes.color.needsUpdate=!0,this
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"BackSide",0,1,"BasicDepthPacking",0,3200,"BasicShadowMap",0,0,"BatchedMesh",0,sr,"BezierInterpolant",0,r9,"Bone",0,iC,"BooleanKeyframeTrack",0,nt,"Box2",0,class{
    constructor(t=new E(Infinity,Infinity),e=new E(-1/0,-1/0)){
      this.isBox2=!0,this.min=t,this.max=e
      }set(t,e){
      return this.min.copy(t),this.max.copy(e),this
      }setFromPoints(t){
      this.makeEmpty();
      for(
      let e=0,i=t.length
      ;e<i;e++)
      this.expandByPoint(t[e]);
      return this
      }setFromCenterAndSize(t,e){
      let i=av.copy(e).multiplyScalar(.5);
      return this.min.copy(t).sub(i),this.max.copy(t).add(i),this
      }clone(){
      return new this.constructor().copy(this)
      }copy(t){
      return this.min.copy(t.min),this.max.copy(t.max),this
      }makeEmpty(){
      return this.min.x=this.min.y=Infinity,this.max.x=this.max.y=-1/0,this
      }isEmpty(){
      return this.max.x<this.min.x||this.max.y<this.min.y
      }getCenter(t){
      return this.isEmpty()?t.set(0,0):t.addVectors(this.min,this.max).multiplyScalar(.5)
      }getSize(t){
      return this.isEmpty()?t.set(0,0):t.subVectors(this.max,this.min)
      }expandByPoint(t){
      return this.min.min(t),this.max.max(t),this
      }expandByVector(t){
      return this.min.sub(t),this.max.add(t),this
      }expandByScalar(t){
      return this.min.addScalar(-t),this.max.addScalar(t),this
      }containsPoint(t){
      return t.x>=this.min.x&&t.x<=this.max.x&&t.y>=this.min.y&&t.y<=this.max.y
      }containsBox(t){
      return this.min.x<=t.min.x&&t.max.x<=this.max.x&&this.min.y<=t.min.y&&t.max.y<=this.max.y
      }getParameter(t,e){
      return e.set((t.x-this.min.x)/(this.max.x-this.min.x),(t.y-this.min.y)/(this.max.y-this.min.y))
      }intersectsBox(t){
      return t.max.x>=this.min.x&&t.min.x<=this.max.x&&t.max.y>=this.min.y&&t.min.y<=this.max.y
      }clampPoint(t,e){
      return e.copy(t).clamp(this.min,this.max)
      }distanceToPoint(t){
      return this.clampPoint(t,av).distanceTo(t)
      }intersect(t){
      return this.min.max(t.min),this.max.min(t.max),this.isEmpty()&&this.makeEmpty(),this
      }union(t){
      return this.min.min(t.min),this.max.max(t.max),this
      }translate(t){
      return this.min.add(t),this.max.add(t),this
      }equals(t){
      return t.min.equals(this.min)&&t.max.equals(this.max)
      }
  },"Box3",0,t8,"Box3Helper",0,class extends sg{
    constructor(t,e=0xffff00){
      const i=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),s=new eR;
      s.setIndex(new ex(i,1)),s.setAttribute("position",new eM([1,1,1,-1,1,1,-1,-1,1,1,-1,1,1,1,-1,-1,1,-1,-1,-1,-1,1,-1,-1],3)),super(s,new sn({color:e,toneMapped:!1})),this.box=t,this.type="Box3Helper",this.geometry.computeBoundingSphere()
      }updateMatrixWorld(t){
      let e=this.box;
      e.isEmpty()||(e.getCenter(this.position),e.getSize(this.scale),this.scale.multiplyScalar(.5),super.updateMatrixWorld(t))
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"BoxGeometry",0,sB,"BoxHelper",0,class extends sg{
    constructor(t,e=0xffff00){
      const i=new Uint16Array([0,1,1,2,2,3,3,0,4,5,5,6,6,7,7,4,0,4,1,5,2,6,3,7]),s=new Float32Array(24),r=new eR;
      r.setIndex(new ex(i,1)),r.setAttribute("position",new ex(s,3)),super(r,new sn({color:e,toneMapped:!1})),this.object=t,this.type="BoxHelper",this.matrixAutoUpdate=!1,this.update()
      }update(){
      if(void 0!==this.object&&aU.setFromObject(this.object),aU.isEmpty())
      return;
      let t=aU.min,e=aU.max,i=this.geometry.attributes.position,s=i.array;
      s[0]=e.x,s[1]=e.y,s[2]=e.z,s[3]=t.x,s[4]=e.y,s[5]=e.z,s[6]=t.x,s[7]=t.y,s[8]=e.z,s[9]=e.x,s[10]=t.y,s[11]=e.z,s[12]=e.x,s[13]=e.y,s[14]=t.z,s[15]=t.x,s[16]=e.y,s[17]=t.z,s[18]=t.x,s[19]=t.y,s[20]=t.z,s[21]=e.x,s[22]=t.y,s[23]=t.z,i.needsUpdate=!0,this.geometry.computeBoundingSphere()
      }setFromObject(t){
      return this.object=t,this.update(),this
      }copy(t,e){
      return super.copy(t,e),this.object=t.object,this
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"BufferAttribute",0,ex,"BufferGeometry",0,eR,"BufferGeometryLoader",0,nJ,"ByteType",0,1010,"Cache",0,nh,"Camera",0,nC,"CameraHelper",0,class extends sg{
    constructor(t){
      const e=new eR,i=new sn({color:0xffffff,vertexColors:!0,toneMapped:!1}),s=[],r=[],n={};
      function a(t,e){
        o(t),o(e)
        }
      function o(t){
        s.push(0,0,0),r.push(0,0,0),void 0===n[t]&&(n[t]=[]),n[t].push(s.length/3-1)
        }
      a("n1","n2"),a("n2","n4"),a("n4","n3"),a("n3","n1"),a("f1","f2"),a("f2","f4"),a("f4","f3"),a("f3","f1"),a("n1","f1"),a("n2","f2"),a("n3","f3"),a("n4","f4"),a("p","n1"),a("p","n2"),a("p","n3"),a("p","n4"),a("u1","u2"),a("u2","u3"),a("u3","u1"),a("c","t"),a("p","c"),a("cn1","cn2"),a("cn3","cn4"),a("cf1","cf2"),a("cf3","cf4"),e.setAttribute("position",new eM(s,3)),e.setAttribute("color",new eM(r,3)),super(e,i),this.type="CameraHelper",this.camera=t,this.camera.updateProjectionMatrix&&this.camera.updateProjectionMatrix(),this.matrix=t.matrixWorld,this.matrixAutoUpdate=!1,this.pointMap=n,this.update();
      const h=new tj(0xffaa00),l=new tj(0xff0000),u=new tj(43775),c=new tj(0xffffff),p=new tj(3355443);
      this.setColors(h,l,u,c,p)
      }setColors(t,e,i,s,r){
      let n=this.geometry.getAttribute("color");
      return n.setXYZ(0,t.r,t.g,t.b),n.setXYZ(1,t.r,t.g,t.b),n.setXYZ(2,t.r,t.g,t.b),n.setXYZ(3,t.r,t.g,t.b),n.setXYZ(4,t.r,t.g,t.b),n.setXYZ(5,t.r,t.g,t.b),n.setXYZ(6,t.r,t.g,t.b),n.setXYZ(7,t.r,t.g,t.b),n.setXYZ(8,t.r,t.g,t.b),n.setXYZ(9,t.r,t.g,t.b),n.setXYZ(10,t.r,t.g,t.b),n.setXYZ(11,t.r,t.g,t.b),n.setXYZ(12,t.r,t.g,t.b),n.setXYZ(13,t.r,t.g,t.b),n.setXYZ(14,t.r,t.g,t.b),n.setXYZ(15,t.r,t.g,t.b),n.setXYZ(16,t.r,t.g,t.b),n.setXYZ(17,t.r,t.g,t.b),n.setXYZ(18,t.r,t.g,t.b),n.setXYZ(19,t.r,t.g,t.b),n.setXYZ(20,t.r,t.g,t.b),n.setXYZ(21,t.r,t.g,t.b),n.setXYZ(22,t.r,t.g,t.b),n.setXYZ(23,t.r,t.g,t.b),n.setXYZ(24,e.r,e.g,e.b),n.setXYZ(25,e.r,e.g,e.b),n.setXYZ(26,e.r,e.g,e.b),n.setXYZ(27,e.r,e.g,e.b),n.setXYZ(28,e.r,e.g,e.b),n.setXYZ(29,e.r,e.g,e.b),n.setXYZ(30,e.r,e.g,e.b),n.setXYZ(31,e.r,e.g,e.b),n.setXYZ(32,i.r,i.g,i.b),n.setXYZ(33,i.r,i.g,i.b),n.setXYZ(34,i.r,i.g,i.b),n.setXYZ(35,i.r,i.g,i.b),n.setXYZ(36,i.r,i.g,i.b),n.setXYZ(37,i.r,i.g,i.b),n.setXYZ(38,s.r,s.g,s.b),n.setXYZ(39,s.r,s.g,s.b),n.setXYZ(40,r.r,r.g,r.b),n.setXYZ(41,r.r,r.g,r.b),n.setXYZ(42,r.r,r.g,r.b),n.setXYZ(43,r.r,r.g,r.b),n.setXYZ(44,r.r,r.g,r.b),n.setXYZ(45,r.r,r.g,r.b),n.setXYZ(46,r.r,r.g,r.b),n.setXYZ(47,r.r,r.g,r.b),n.setXYZ(48,r.r,r.g,r.b),n.setXYZ(49,r.r,r.g,r.b),n.needsUpdate=!0,this
      }update(){
      let t,e,i=this.geometry,s=this.pointMap;
      if(aV.projectionMatrixInverse.copy(this.camera.projectionMatrixInverse),!0===this.camera.reversedDepth)
      t=1,e=0;
      else 
      if(2e3===this.camera.coordinateSystem)
      t=-1,e=1;
      else 
      if(2001===this.camera.coordinateSystem)
      t=0,e=1;
      else 
      throw Error("THREE.CameraHelper.update(): Invalid coordinate system: "+this.camera.coordinateSystem);
      aD("c",s,i,aV,0,0,t),aD("t",s,i,aV,0,0,e),aD("n1",s,i,aV,-1,-1,t),aD("n2",s,i,aV,1,-1,t),aD("n3",s,i,aV,-1,1,t),aD("n4",s,i,aV,1,1,t),aD("f1",s,i,aV,-1,-1,e),aD("f2",s,i,aV,1,-1,e),aD("f3",s,i,aV,-1,1,e),aD("f4",s,i,aV,1,1,e),aD("u1",s,i,aV,.7,1.1,t),aD("u2",s,i,aV,-.7,1.1,t),aD("u3",s,i,aV,0,2,t),aD("cf1",s,i,aV,-1,0,e),aD("cf2",s,i,aV,1,0,e),aD("cf3",s,i,aV,0,-1,e),aD("cf4",s,i,aV,0,1,e),aD("cn1",s,i,aV,-1,0,t),aD("cn2",s,i,aV,1,0,t),aD("cn3",s,i,aV,0,-1,t),aD("cn4",s,i,aV,0,1,t),i.getAttribute("position").needsUpdate=!0
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"CanvasTexture",0,class extends ti{
    constructor(t,e,i,s,r,n,a,o,h){
      super(t,e,i,s,r,n,a,o,h),this.isCanvasTexture=!0,this.needsUpdate=!0
      }
  },"CapsuleGeometry",0,sk,"CatmullRomCurve3",0,s$,"CineonToneMapping",0,3,"CircleGeometry",0,sO,"ClampToEdgeWrapping",0,1001,"Clock",0,class{
    constructor(t=!0){
      this.autoStart=t,this.startTime=0,this.oldTime=0,this.elapsedTime=0,this.running=!1,_("Clock: This module has been deprecated. Please use THREE.Timer instead.")
      }start(){
      this.startTime=performance.now(),this.oldTime=this.startTime,this.elapsedTime=0,this.running=!0
      }stop(){
      this.getElapsedTime(),this.running=!1,this.autoStart=!1
      }getElapsedTime(){
      return this.getDelta(),this.elapsedTime
      }getDelta(){
      let t=0;
      if(this.autoStart&&!this.running)
      return this.start(),0;
      if(this.running){
        let e=performance.now();
        t=(e-this.oldTime)/1e3,this.oldTime=e,this.elapsedTime+=t
        }
      return t
      }
  },"Color",0,tj,"ColorKeyframeTrack",0,ne,"ColorManagement",0,H,"Compatibility",0,{TEXTURE_COMPARE:"depthTextureCompare"},"CompressedArrayTexture",0,class extends sC{
    constructor(t,e,i,s,r,n){
      super(t,e,i,r,n),this.isCompressedArrayTexture=!0,this.image.depth=s,this.wrapR=1001,this.layerUpdates=new Set
      }addLayerUpdate(t){
      this.layerUpdates.add(t)
      }clearLayerUpdates(){
      this.layerUpdates.clear()
      }
  },"CompressedCubeTexture",0,class extends sC{
    constructor(t,e,i){
      super(void 0,t[0].width,t[0].height,e,i,301),this.isCompressedCubeTexture=!0,this.isCubeTexture=!0,this.image=t
      }
  },"CompressedTexture",0,sC,"CompressedTextureLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=this,n=[],a=new sC,o=new ny(this.manager);
      o.setPath(this.path),o.setResponseType("arraybuffer"),o.setRequestHeader(this.requestHeader),o.setWithCredentials(r.withCredentials);
      let h=0;
      if(Array.isArray(t))
      for(
      let l=0,u=t.length
      ;l<u;++l)
      !function(l){
        o.load(t[l],function(t){
          let i=r.parse(t,!0);
          n[l]={width:i.width,height:i.height,format:i.format,mipmaps:i.mipmaps},6===(h+=1)&&(1===i.mipmapCount&&(a.minFilter=1006),a.image=n,a.format=i.format,a.needsUpdate=!0,e&&e(a))
          },i,s)
        }(l);
      else 
      o.load(t,function(t){
        let i=r.parse(t,!0);
        if(i.isCubemap){
          let t=i.mipmaps.length/i.mipmapCount;
          for(
          let e=0
          ;e<t;e++){
            n[e]={mipmaps:[]};
            for(
            let t=0
            ;t<i.mipmapCount;t++)
            n[e].mipmaps.push(i.mipmaps[e*i.mipmapCount+t]),n[e].format=i.format,n[e].width=i.width,n[e].height=i.height
            }
          a.image=n
          }else 
        a.image.width=i.width,a.image.height=i.height,a.mipmaps=i.mipmaps;
        1===i.mipmapCount&&(a.minFilter=1006),a.format=i.format,a.needsUpdate=!0,e&&e(a)
        },i,s);
      return a
      }
  },"ConeGeometry",0,sP,"ConstantAlphaFactor",0,213,"ConstantColorFactor",0,211,"Controls",0,class extends C{
    constructor(t,e=null){
      super(),this.object=t,this.domElement=e,this.enabled=!0,this.state=-1,this.keys={},this.mouseButtons={LEFT:null,MIDDLE:null,RIGHT:null},this.touches={ONE:null,TWO:null}
      }connect(t){
      void 0===t?_("Controls: connect() now requires an element."):(null!==this.domElement&&this.disconnect(),this.domElement=t)
      }disconnect(){
      }dispose(){
      }update(){
      }
  },"CubeCamera",0,class extends tF{
    constructor(t,e,i){
      super(),this.type="CubeCamera",this.renderTarget=i,this.coordinateSystem=null,this.activeMipmapLevel=0;
      const s=new nk(-90,1,t,e);
      s.layers=this.layers,this.add(s);
      const r=new nk(-90,1,t,e);
      r.layers=this.layers,this.add(r);
      const n=new nk(-90,1,t,e);
      n.layers=this.layers,this.add(n);
      const a=new nk(-90,1,t,e);
      a.layers=this.layers,this.add(a);
      const o=new nk(-90,1,t,e);
      o.layers=this.layers,this.add(o);
      const h=new nk(-90,1,t,e);
      h.layers=this.layers,this.add(h)
      }updateCoordinateSystem(){
      let t=this.coordinateSystem,e=this.children.concat(),[i,s,r,n,a,o]=e;
      for(
      let t
       of e)
      this.remove(t);
      if(2e3===t)
      i.up.set(0,1,0),i.lookAt(1,0,0),s.up.set(0,1,0),s.lookAt(-1,0,0),r.up.set(0,0,-1),r.lookAt(0,1,0),n.up.set(0,0,1),n.lookAt(0,-1,0),a.up.set(0,1,0),a.lookAt(0,0,1),o.up.set(0,1,0),o.lookAt(0,0,-1);
      else 
      if(2001===t)
      i.up.set(0,-1,0),i.lookAt(-1,0,0),s.up.set(0,-1,0),s.lookAt(1,0,0),r.up.set(0,0,1),r.lookAt(0,1,0),n.up.set(0,0,-1),n.lookAt(0,-1,0),a.up.set(0,-1,0),a.lookAt(0,0,1),o.up.set(0,-1,0),o.lookAt(0,0,-1);
      else 
      throw Error("THREE.CubeCamera.updateCoordinateSystem(): Invalid coordinate system: "+t);
      for(
      let t
       of e)
      this.add(t),t.updateMatrixWorld()
      }update(t,e){
      null===this.parent&&this.updateMatrixWorld();
      let{renderTarget:i,activeMipmapLevel:s}=this;
      this.coordinateSystem!==t.coordinateSystem&&(this.coordinateSystem=t.coordinateSystem,this.updateCoordinateSystem());
      let[r,n,a,o,h,l]=this.children,u=t.getRenderTarget(),c=t.getActiveCubeFace(),p=t.getActiveMipmapLevel(),d=t.xr.enabled;
      t.xr.enabled=!1;
      let m=i.texture.generateMipmaps;
      i.texture.generateMipmaps=!1;
      let y=!1;
      y=!0===t.isWebGLRenderer?t.state.buffers.depth.getReversed():t.reversedDepthBuffer,t.setRenderTarget(i,0,s),y&&!1===t.autoClear&&t.clearDepth(),t.render(e,r),t.setRenderTarget(i,1,s),y&&!1===t.autoClear&&t.clearDepth(),t.render(e,n),t.setRenderTarget(i,2,s),y&&!1===t.autoClear&&t.clearDepth(),t.render(e,a),t.setRenderTarget(i,3,s),y&&!1===t.autoClear&&t.clearDepth(),t.render(e,o),t.setRenderTarget(i,4,s),y&&!1===t.autoClear&&t.clearDepth(),t.render(e,h),i.texture.generateMipmaps=m,t.setRenderTarget(i,5,s),y&&!1===t.autoClear&&t.clearDepth(),t.render(e,l),t.setRenderTarget(u,c,p),t.xr.enabled=d,i.texture.needsPMREMUpdate=!0
      }
  },"CubeDepthTexture",0,class extends sz{
    constructor(t,e=1014,i=301,s,r,n=1003,a=1003,o,h=1026){
      const l={width:t,height:t,depth:1};
      super(t,t,e,i,s,r,n,a,o,h),this.image=[l,l,l,l,l,l],this.isCubeDepthTexture=!0,this.isCubeTexture=!0
      }get images(){
      return this.image
      }set images(t){
      this.image=t
      }
  },"CubeReflectionMapping",0,301,"CubeRefractionMapping",0,302,"CubeTexture",0,sI,"CubeTextureLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=new sI;
      r.colorSpace=p;
      let n=new ng(this.manager);
      n.setCrossOrigin(this.crossOrigin),n.setPath(this.path);
      let a=0;
      for(
      let i=0
      ;i<t.length;++i)
      !function(i){
        n.load(t[i],function(t){
          r.images[i]=t,6==++a&&(r.needsUpdate=!0,e&&e(r))
          },void 0,s)
        }(i);
      return r
      }
  },"CubeUVReflectionMapping",0,306,"CubicBezierCurve",0,s1,"CubicBezierCurve3",0,s2,"CubicInterpolant",0,r4,"CullFaceBack",0,1,"CullFaceFront",0,2,"CullFaceFrontBack",0,3,"CullFaceNone",0,0,"Curve",0,sj,"CurvePath",0,s7,"CustomBlending",0,5,"CustomToneMapping",0,5,"CylinderGeometry",0,sR,"Cylindrical",0,class{
    constructor(t=1,e=0,i=0){
      this.radius=t,this.theta=e,this.y=i
      }set(t,e,i){
      return this.radius=t,this.theta=e,this.y=i,this
      }copy(t){
      return this.radius=t.radius,this.theta=t.theta,this.y=t.y,this
      }setFromVector3(t){
      return this.setFromCartesianCoords(t.x,t.y,t.z)
      }setFromCartesianCoords(t,e,i){
      return this.radius=Math.sqrt(t*t+i*i),this.theta=Math.atan2(t,i),this.y=e,this
      }clone(){
      return new this.constructor().copy(this)
      }
  },"Data3DTexture",0,to,"DataArrayTexture",0,ta,"DataTexture",0,iI,"DataTextureLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=this,n=new iI,a=new ny(this.manager);
      return a.setResponseType("arraybuffer"),a.setRequestHeader(this.requestHeader),a.setPath(this.path),a.setWithCredentials(r.withCredentials),a.load(t,function(t){
        let i;
        try{
          i=r.parse(t)
          }catch(t){
          void 0!==s?s(t):A(t);
          return
          }
        void 0!==i.image?n.image=i.image:void 0!==i.data&&(n.image.width=i.width,n.image.height=i.height,n.image.data=i.data),n.wrapS=void 0!==i.wrapS?i.wrapS:1001,n.wrapT=void 0!==i.wrapT?i.wrapT:1001,n.magFilter=void 0!==i.magFilter?i.magFilter:1006,n.minFilter=void 0!==i.minFilter?i.minFilter:1006,n.anisotropy=void 0!==i.anisotropy?i.anisotropy:1,void 0!==i.colorSpace&&(n.colorSpace=i.colorSpace),void 0!==i.flipY&&(n.flipY=i.flipY),void 0!==i.format&&(n.format=i.format),void 0!==i.type&&(n.type=i.type),void 0!==i.mipmaps&&(n.mipmaps=i.mipmaps,n.minFilter=1008),1===i.mipmapCount&&(n.minFilter=1006),void 0!==i.generateMipmaps&&(n.generateMipmaps=i.generateMipmaps),n.needsUpdate=!0,e&&e(n,i)
        },i,s),n
      }
  },"DataUtils",0,class{
    static toHalfFloat(t){
      return ed(t)
      }static fromHalfFloat(t){
      return em(t)
      }
  },"DecrementStencilOp",0,7683,"DecrementWrapStencilOp",0,34056,"DefaultLoadingManager",0,nc,"DepthFormat",0,1026,"DepthStencilFormat",0,1027,"DepthTexture",0,sz,"DetachedBindMode",0,c,"DirectionalLight",0,nE,"DirectionalLightHelper",0,class extends tF{
    constructor(t,e,i){
      super(),this.light=t,this.matrix=t.matrixWorld,this.matrixAutoUpdate=!1,this.color=i,this.type="DirectionalLightHelper",void 0===e&&(e=1);
      let s=new eR;
      s.setAttribute("position",new eM([-e,e,0,e,e,0,e,-e,0,-e,-e,0,-e,e,0],3));
      const r=new sn({fog:!1,toneMapped:!1});
      this.lightPlane=new sd(s,r),this.add(this.lightPlane),(s=new eR).setAttribute("position",new eM([0,0,0,0,0,1],3)),this.targetLine=new sd(s,r),this.add(this.targetLine),this.update()
      }dispose(){
      this.lightPlane.geometry.dispose(),this.lightPlane.material.dispose(),this.targetLine.geometry.dispose(),this.targetLine.material.dispose()
      }update(){
      this.light.updateWorldMatrix(!0,!1),this.light.target.updateWorldMatrix(!0,!1),aF.setFromMatrixPosition(this.light.matrixWorld),aL.setFromMatrixPosition(this.light.target.matrixWorld),aN.subVectors(aL,aF),this.lightPlane.lookAt(aL),void 0!==this.color?(this.lightPlane.material.color.set(this.color),this.targetLine.material.color.set(this.color)):(this.lightPlane.material.color.copy(this.light.color),this.targetLine.material.color.copy(this.light.color)),this.targetLine.lookAt(aL),this.targetLine.scale.z=aN.length()
      }
  },"DiscreteInterpolant",0,r8,"DodecahedronGeometry",0,sL,"DoubleSide",0,2,"DstAlphaFactor",0,206,"DstColorFactor",0,208,"DynamicCopyUsage",0,35050,"DynamicDrawUsage",0,35048,"DynamicReadUsage",0,35049,"EdgesGeometry",0,sU,"EllipseCurve",0,sW,"EqualCompare",0,514,"EqualDepth",0,4,"EqualStencilFunc",0,514,"EquirectangularReflectionMapping",0,303,"EquirectangularRefractionMapping",0,304,"Euler",0,tx,"EventDispatcher",0,C,"ExternalTexture",0,class extends ti{
    constructor(t=null){
      super(),this.sourceTexture=t,this.isExternalTexture=!0
      }copy(t){
      return super.copy(t),this.sourceTexture=t.sourceTexture,this
      }
  },"ExtrudeGeometry",0,rw,"FileLoader",0,ny,"Float16BufferAttribute",0,class extends ex{
    constructor(t,e,i){
      super(new Uint16Array(t),e,i),this.isFloat16BufferAttribute=!0
      }getX(t){
      let e=em(this.array[t*this.itemSize]);
      return this.normalized&&(e=L(e,this.array)),e
      }setX(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize]=ed(e),this
      }getY(t){
      let e=em(this.array[t*this.itemSize+1]);
      return this.normalized&&(e=L(e,this.array)),e
      }setY(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize+1]=ed(e),this
      }getZ(t){
      let e=em(this.array[t*this.itemSize+2]);
      return this.normalized&&(e=L(e,this.array)),e
      }setZ(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize+2]=ed(e),this
      }getW(t){
      let e=em(this.array[t*this.itemSize+3]);
      return this.normalized&&(e=L(e,this.array)),e
      }setW(t,e){
      return this.normalized&&(e=N(e,this.array)),this.array[t*this.itemSize+3]=ed(e),this
      }setXY(t,e,i){
      return t*=this.itemSize,this.normalized&&(e=N(e,this.array),i=N(i,this.array)),this.array[t+0]=ed(e),this.array[t+1]=ed(i),this
      }setXYZ(t,e,i,s){
      return t*=this.itemSize,this.normalized&&(e=N(e,this.array),i=N(i,this.array),s=N(s,this.array)),this.array[t+0]=ed(e),this.array[t+1]=ed(i),this.array[t+2]=ed(s),this
      }setXYZW(t,e,i,s,r){
      return t*=this.itemSize,this.normalized&&(e=N(e,this.array),i=N(i,this.array),s=N(s,this.array),r=N(r,this.array)),this.array[t+0]=ed(e),this.array[t+1]=ed(i),this.array[t+2]=ed(s),this.array[t+3]=ed(r),this
      }
  },"Float32BufferAttribute",0,eM,"FloatType",0,1015,"Fog",0,tq,"FogExp2",0,tG,"FramebufferTexture",0,class extends ti{
    constructor(t,e){
      super({width:t,height:e}),this.isFramebufferTexture=!0,this.magFilter=1003,this.minFilter=1003,this.generateMipmaps=!1,this.needsUpdate=!0
      }
  },"FrontSide",0,0,"Frustum",0,iX,"FrustumArray",0,i$,"GLBufferAttribute",0,class{
    constructor(t,e,i,s,r,n=!1){
      this.isGLBufferAttribute=!0,this.name="",this.buffer=t,this.type=e,this.itemSize=i,this.elementSize=s,this.count=r,this.normalized=n,this.version=0
      }set needsUpdate(t){
      !0===t&&this.version++
      }setBuffer(t){
      return this.buffer=t,this
      }setType(t,e){
      return this.type=t,this.elementSize=e,this
      }setItemSize(t){
      return this.itemSize=t,this
      }setCount(t){
      return this.count=t,this
      }
  },"GLSL1",0,"100","GLSL3",0,"300 es","GreaterCompare",0,516,"GreaterDepth",0,6,"GreaterEqualCompare",0,518,"GreaterEqualDepth",0,5,"GreaterEqualStencilFunc",0,518,"GreaterStencilFunc",0,516,"GridHelper",0,class extends sg{
    constructor(t=10,e=10,i=4473924,s=8947848){
      i=new tj(i),s=new tj(s);
      const r=e/2,n=t/e,a=t/2,o=[],h=[];
      for(
      let t=0,l=0,u=-a
      ;t<=e;t++,u+=n){
        o.push(-a,0,u,a,0,u),o.push(u,0,-a,u,0,a);
        const e=t===r?i:s;
        e.toArray(h,l),l+=3,e.toArray(h,l),l+=3,e.toArray(h,l),l+=3,e.toArray(h,l),l+=3
        }
      const l=new eR;
      l.setAttribute("position",new eM(o,3)),l.setAttribute("color",new eM(h,3)),super(l,new sn({vertexColors:!0,toneMapped:!1})),this.type="GridHelper"
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"Group",0,tL,"HTMLTexture",0,class extends ti{
    constructor(t,e,i,s,r,n,a,o,h){
      super(t,e,i,s,r,n,a,o,h),this.isHTMLTexture=!0,this.generateMipmaps=!1,this.needsUpdate=!0;
      const l=t?t.parentNode:null;
      null!==l&&"requestPaint"in l&&(l.onpaint=()=>{
        this.needsUpdate=!0
        },l.requestPaint())
      }dispose(){
      let t=this.image?this.image.parentNode:null;
      null!==t&&"onpaint"in t&&(t.onpaint=null),super.dispose()
      }
  },"HalfFloatType",0,1016,"HemisphereLight",0,nb,"HemisphereLightHelper",0,class extends tF{
    constructor(t,e,i){
      super(),this.light=t,this.matrix=t.matrixWorld,this.matrixAutoUpdate=!1,this.color=i,this.type="HemisphereLightHelper";
      const s=new rT(e);
      s.rotateY(.5*Math.PI),this.material=new ie({wireframe:!0,fog:!1,toneMapped:!1}),void 0===this.color&&(this.material.vertexColors=!0);
      const r=new Float32Array(3*s.getAttribute("position").count);
      s.setAttribute("color",new ex(r,3)),this.add(new im(s,this.material)),this.update()
      }dispose(){
      this.children[0].geometry.dispose(),this.children[0].material.dispose()
      }update(){
      let t=this.children[0];
      if(void 0!==this.color)
      this.material.color.set(this.color);
      else{
        let e=t.geometry.getAttribute("color");
        aR.copy(this.light.color),aP.copy(this.light.groundColor);
        for(
        let t=0,i=e.count
        ;t<i;t++){
          let s=t<i/2?aR:aP;
          e.setXYZ(t,s.r,s.g,s.b)
          }
        e.needsUpdate=!0
        }
      this.light.updateWorldMatrix(!0,!1),t.lookAt(aO.setFromMatrixPosition(this.light.matrixWorld).negate())
      }
  },"IcosahedronGeometry",0,r_,"ImageBitmapLoader",0,class extends np{
    constructor(t){
      super(t),this.isImageBitmapLoader=!0,"u"<typeof createImageBitmap&&_("ImageBitmapLoader: createImageBitmap() not supported."),"u"<typeof fetch&&_("ImageBitmapLoader: fetch() not supported."),this.options={premultiplyAlpha:"none"},this._abortController=new AbortController
      }setOptions(t){
      return this.options=t,this
      }load(t,e,i,s){
      void 0===t&&(t=""),void 0!==this.path&&(t=this.path+t),t=this.manager.resolveURL(t);
      let r=this,n=nh.get(`image-bitmap:${t}`);
      if(void 0!==n)
      return(r.manager.itemStart(t),n.then)?void n.then(i=>{
        !0===n$.has(n)?(s&&s(n$.get(n)),r.manager.itemError(t)):e&&e(i),r.manager.itemEnd(t)
        }):void setTimeout(function(){
        e&&e(n),r.manager.itemEnd(t)
        },0);
      let a={};
      a.credentials="anonymous"===this.crossOrigin?"same-origin":"include",a.headers=this.requestHeader,a.signal="function"==typeof AbortSignal.any?AbortSignal.any([this._abortController.signal,this.manager.abortController.signal]):this._abortController.signal;
      let o=fetch(t,a).then(function(t){
        return t.blob()
        }).then(function(t){
        return createImageBitmap(t,Object.assign(r.options,{colorSpaceConversion:"none"}))
        }).then(function(i){
        nh.add(`image-bitmap:${t}`,i),e&&e(i),r.manager.itemEnd(t)
        }).catch(function(e){
        s&&s(e),n$.set(o,e),nh.remove(`image-bitmap:${t}`),r.manager.itemError(t),r.manager.itemEnd(t)
        });
      nh.add(`image-bitmap:${t}`,o),r.manager.itemStart(t)
      }abort(){
      return this._abortController.abort(),this._abortController=new AbortController,this
      }
  },"ImageLoader",0,ng,"ImageUtils",0,Z,"IncrementStencilOp",0,7682,"IncrementWrapStencilOp",0,34055,"InstancedBufferAttribute",0,iO,"InstancedBufferGeometry",0,nq,"InstancedInterleavedBuffer",0,class extends eP{
    constructor(t,e,i=1){
      super(t,e),this.isInstancedInterleavedBuffer=!0,this.meshPerAttribute=i
      }copy(t){
      return super.copy(t),this.meshPerAttribute=t.meshPerAttribute,this
      }clone(t){
      let e=super.clone(t);
      return e.meshPerAttribute=this.meshPerAttribute,e
      }toJSON(t){
      let e=super.toJSON(t);
      return e.isInstancedInterleavedBuffer=!0,e.meshPerAttribute=this.meshPerAttribute,e
      }
  },"InstancedMesh",0,iD,"Int16BufferAttribute",0,class extends ex{
    constructor(t,e,i){
      super(new Int16Array(t),e,i)
      }
  },"Int32BufferAttribute",0,class extends ex{
    constructor(t,e,i){
      super(new Int32Array(t),e,i)
      }
  },"Int8BufferAttribute",0,class extends ex{
    constructor(t,e,i){
      super(new Int8Array(t),e,i)
      }
  },"IntType",0,1013,"InterleavedBuffer",0,eP,"InterleavedBufferAttribute",0,eL,"Interpolant",0,r5,"InterpolateBezier",0,2303,"InterpolateDiscrete",0,2300,"InterpolateLinear",0,2301,"InterpolateSmooth",0,2302,"InterpolationSamplingMode",0,{NORMAL:"normal",CENTROID:"centroid",SAMPLE:"sample",FIRST:"first",EITHER:"either"},"InterpolationSamplingType",0,{PERSPECTIVE:"perspective",LINEAR:"linear",FLAT:"flat"},"InvertStencilOp",0,5386,"KeepStencilOp",0,7680,"KeyframeTrack",0,r7,"LOD",0,e2,"LatheGeometry",0,rA,"Layers",0,tb,"LessCompare",0,513,"LessDepth",0,2,"LessEqualCompare",0,515,"LessEqualDepth",0,3,"LessEqualStencilFunc",0,515,"LessStencilFunc",0,513,"Light",0,nx,"LightProbe",0,nj,"Line",0,sd,"Line3",0,class{
    constructor(t=new D,e=new D){
      this.start=t,this.end=e
      }set(t,e){
      return this.start.copy(t),this.end.copy(e),this
      }copy(t){
      return this.start.copy(t.start),this.end.copy(t.end),this
      }getCenter(t){
      return t.addVectors(this.start,this.end).multiplyScalar(.5)
      }delta(t){
      return t.subVectors(this.end,this.start)
      }distanceSq(){
      return this.start.distanceToSquared(this.end)
      }distance(){
      return this.start.distanceTo(this.end)
      }at(t,e){
      return this.delta(e).multiplyScalar(t).add(this.start)
      }closestPointToPointParameter(t,e){
      aM.subVectors(t,this.start),aw.subVectors(this.end,this.start);
      let i=aw.dot(aw);
      if(0===i)
      return 0;
      let s=aw.dot(aM)/i;
      return e&&(s=R(s,0,1)),s
      }closestPointToPoint(t,e,i){
      let s=this.closestPointToPointParameter(t,e);
      return this.delta(i).multiplyScalar(s).add(this.start)
      }distanceSqToLine3(t,e=aT,i=aC){
      let s,r,n=1e-8*1e-8,a=this.start,o=t.start,h=this.end,l=t.end;
      aS.subVectors(h,a),a_.subVectors(l,o),aA.subVectors(a,o);
      let u=aS.dot(aS),c=a_.dot(a_),p=a_.dot(aA);
      if(u<=n&&c<=n)
      return e.copy(a),i.copy(o),e.sub(i),e.dot(e);
      if(u<=n)
      s=0,r=R(r=p/c,0,1);
      else{
        let t=aS.dot(aA);
        if(c<=n)
        r=0,s=R(-t/u,0,1);
        else{
          let e=aS.dot(a_),i=u*c-e*e;
          s=0!==i?R((e*p-t*c)/i,0,1):0,(r=(e*s+p)/c)<0?(r=0,s=R(-t/u,0,1)):r>1&&(r=1,s=R((e-t)/u,0,1))
          }
        }
      return e.copy(a).addScaledVector(aS,s),i.copy(o).addScaledVector(a_,r),e.distanceToSquared(i)
      }applyMatrix4(t){
      return this.start.applyMatrix4(t),this.end.applyMatrix4(t),this
      }equals(t){
      return t.start.equals(this.start)&&t.end.equals(this.end)
      }clone(){
      return new this.constructor().copy(this)
      }
  },"LineBasicMaterial",0,sn,"LineCurve",0,s3,"LineCurve3",0,s5,"LineDashedMaterial",0,rK,"LineLoop",0,sx,"LineSegments",0,sg,"LinearFilter",0,1006,"LinearInterpolant",0,r6,"LinearMipMapLinearFilter",0,1008,"LinearMipMapNearestFilter",0,1007,"LinearMipmapLinearFilter",0,1008,"LinearMipmapNearestFilter",0,1007,"LinearSRGBColorSpace",0,d,"LinearToneMapping",0,1,"LinearTransfer",0,m,"Loader",0,np,"LoaderUtils",0,nG,"LoadingManager",0,nu,"LoopOnce",0,2200,"LoopPingPong",0,2202,"LoopRepeat",0,2201,"MOUSE",0,{LEFT:0,MIDDLE:1,RIGHT:2,ROTATE:0,DOLLY:1,PAN:2},"Material",0,eE,"MaterialBlending",0,6,"MaterialLoader",0,nW,"MathUtils",0,{DEG2RAD:B,RAD2DEG:k,generateUUID:O,clamp:R,euclideanModulo:P,mapLinear:function(t,e,i,s,r){
    return s+(t-e)*(r-s)/(i-e)
    },inverseLerp:function(t,e,i){
    return t!==e?(i-t)/(e-t):0
    },lerp:F,damp:function(t,e,i,s){
    return F(t,e,1-Math.exp(-i*s))
    },pingpong:function(t,e=1){
    return e-Math.abs(P(t,2*e)-e)
    },smoothstep:function(t,e,i){
    return t<=e?0:t>=i?1:(t=(t-e)/(i-e))*t*(3-2*t)
    },smootherstep:function(t,e,i){
    return t<=e?0:t>=i?1:(t=(t-e)/(i-e))*t*t*(t*(6*t-15)+10)
    },randInt:function(t,e){
    return t+Math.floor(Math.random()*(e-t+1))
    },randFloat:function(t,e){
    return t+Math.random()*(e-t)
    },randFloatSpread:function(t){
    return t*(.5-Math.random())
    },seededRandom:function(t){
    void 0!==t&&(z=t);
    let e=z+=0x6d2b79f5;
    return e=Math.imul(e^e>>>15,1|e),(((e^=e+Math.imul(e^e>>>7,61|e))^e>>>14)>>>0)/0x100000000
    },degToRad:function(t){
    return t*B
    },radToDeg:function(t){
    return t*k
    },isPowerOfTwo:function(t){
    return(t&t-1)==0&&0!==t
    },ceilPowerOfTwo:function(t){
    return Math.pow(2,Math.ceil(Math.log(t)/Math.LN2))
    },floorPowerOfTwo:function(t){
    return Math.pow(2,Math.floor(Math.log(t)/Math.LN2))
    },setQuaternionFromProperEuler:function(t,e,i,s,r){
    let n=Math.cos,a=Math.sin,o=n(i/2),h=a(i/2),l=n((e+s)/2),u=a((e+s)/2),c=n((e-s)/2),p=a((e-s)/2),d=n((s-e)/2),m=a((s-e)/2);
    switch(r){case"XYX":
    t.set(o*u,h*c,h*p,o*l);
    break;
    case"YZY":
    t.set(h*p,o*u,h*c,o*l);
    break;
    case"ZXZ":
    t.set(h*c,h*p,o*u,o*l);
    break;
    case"XZX":
    t.set(o*u,h*m,h*d,o*l);
    break;
    case"YXY":
    t.set(h*d,o*u,h*m,o*l);
    break;
    case"ZYZ":
    t.set(h*m,h*d,o*u,o*l);
    break;
    default:
    _("MathUtils: .setQuaternionFromProperEuler() encountered an unknown order: "+r)
    }
    },normalize:N,denormalize:L},"Matrix2",0,ab,"Matrix3",0,W,"Matrix4",0,th,"MaxEquation",0,104,"Mesh",0,im,"MeshBasicMaterial",0,ie,"MeshDepthMaterial",0,rZ,"MeshDistanceMaterial",0,r$,"MeshLambertMaterial",0,rY,"MeshMatcapMaterial",0,rQ,"MeshNormalMaterial",0,rX,"MeshPhongMaterial",0,rJ,"MeshPhysicalMaterial",0,rq,"MeshStandardMaterial",0,rG,"MeshToonMaterial",0,rH,"MinEquation",0,103,"MirroredRepeatWrapping",0,1002,"MixOperation",0,1,"MultiplyBlending",0,4,"MultiplyOperation",0,0,"NearestFilter",0,1003,"NearestMipMapLinearFilter",0,1005,"NearestMipMapNearestFilter",0,1004,"NearestMipmapLinearFilter",0,1005,"NearestMipmapNearestFilter",0,1004,"NeutralToneMapping",0,7,"NeverCompare",0,512,"NeverDepth",0,0,"NeverStencilFunc",0,512,"NoBlending",0,0,"NoColorSpace",0,"","NoNormalPacking",0,"","NoToneMapping",0,0,"NormalAnimationBlendMode",0,2500,"NormalBlending",0,1,"NormalGAPacking",0,"ga","NormalRGPacking",0,"rg","NotEqualCompare",0,517,"NotEqualDepth",0,7,"NotEqualStencilFunc",0,517,"NumberKeyframeTrack",0,ni,"Object3D",0,tF,"ObjectLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=this,n=""===this.path?nG.extractUrlBase(t):this.path;
      this.resourcePath=this.resourcePath||n;
      let a=new ny(this.manager);
      a.setPath(this.path),a.setRequestHeader(this.requestHeader),a.setWithCredentials(this.withCredentials),a.load(t,function(i){
        let n=null;
        try{
          n=JSON.parse(i)
          }catch(e){
          void 0!==s&&s(e),A("ObjectLoader: Can't parse "+t+".",e.message);
          return
          }
        let a=n.metadata;
        if(void 0===a||void 0===a.type||"geometry"===a.type.toLowerCase()){
          void 0!==s&&s(Error("THREE.ObjectLoader: Can't load "+t)),A("ObjectLoader: Can't load "+t);
          return
          }
        r.parse(n,e)
        },i,s)
      }async loadAsync(t,e){
      let i,s=""===this.path?nG.extractUrlBase(t):this.path;
      this.resourcePath=this.resourcePath||s;
      let r=new ny(this.manager);
      r.setPath(this.path),r.setRequestHeader(this.requestHeader),r.setWithCredentials(this.withCredentials);
      let n=await r.loadAsync(t,e);
      try{
        i=JSON.parse(n)
        }catch(e){
        throw Error("ObjectLoader: Can't parse "+t+". "+e.message)
        }
      let a=i.metadata;
      if(void 0===a||void 0===a.type||"geometry"===a.type.toLowerCase())
      throw Error("THREE.ObjectLoader: Can't load "+t);
      return await this.parseAsync(i)
      }parse(t,e){
      let i=this.parseAnimations(t.animations),s=this.parseShapes(t.shapes),r=this.parseGeometries(t.geometries,s),n=this.parseImages(t.images,function(){
        void 0!==e&&e(h)
        }),a=this.parseTextures(t.textures,n),o=this.parseMaterials(t.materials,a),h=this.parseObject(t.object,r,o,a,i),l=this.parseSkeletons(t.skeletons,h);
      if(this.bindSkeletons(h,l),this.bindLightTargets(h),void 0!==e){
        let t=!1;
        for(
        let e
         in n)
        if(n[e].data instanceof HTMLImageElement){
          t=!0;
          break
          }
        !1===t&&e(h)
        }
      return h
      }async parseAsync(t){
      let e=this.parseAnimations(t.animations),i=this.parseShapes(t.shapes),s=this.parseGeometries(t.geometries,i),r=await this.parseImagesAsync(t.images),n=this.parseTextures(t.textures,r),a=this.parseMaterials(t.materials,n),o=this.parseObject(t.object,s,a,n,e),h=this.parseSkeletons(t.skeletons,o);
      return this.bindSkeletons(o,h),this.bindLightTargets(o),o
      }static registerGeometry(t,e){
      nH[t]=e
      }parseShapes(t){
      let e={};
      if(void 0!==t)
      for(
      let i=0,s=t.length
      ;i<s;i++){
        let s=new re().fromJSON(t[i]);
        e[s.uuid]=s
        }
      return e
      }parseSkeletons(t,e){
      let i={},s={};
      if(e.traverse(function(t){
        t.isBone&&(s[t.uuid]=t)
        }),void 0!==t)
      for(
      let e=0,r=t.length
      ;e<r;e++){
        let r=new ik().fromJSON(t[e],s);
        i[r.uuid]=r
        }
      return i
      }parseGeometries(t,e){
      let i={};
      if(void 0!==t){
        let s=new nJ;
        for(
        let r=0,n=t.length
        ;r<n;r++){
          let n,a=t[r];
          switch(a.type){case"BufferGeometry":case"InstancedBufferGeometry":
          n=s.parse(a);
          break;
          default:
          a.type in rN?n=rN[a.type].fromJSON(a,e):a.type in nH?n=nH[a.type].fromJSON(a,e):_(`ObjectLoader: Unknown geometry type "${a.type}". Use .registerGeometry() before starting the deserialization process.`)
          }
          n.uuid=a.uuid,void 0!==a.name&&(n.name=a.name),void 0!==a.userData&&(n.userData=a.userData),i[a.uuid]=n
          }
        }
      return i
      }parseMaterials(t,e){
      let i={},s={};
      if(void 0!==t){
        let r=new nW;
        r.setTextures(e);
        for(
        let e=0,n=t.length
        ;e<n;e++){
          let n=t[e];
          void 0===i[n.uuid]&&(i[n.uuid]=r.parse(n)),s[n.uuid]=i[n.uuid]
          }
        }
      return s
      }parseAnimations(t){
      let e={};
      if(void 0!==t)
      for(
      let i=0
      ;i<t.length;i++){
        let s=t[i],r=no.parse(s);
        e[r.uuid]=r
        }
      return e
      }parseImages(t,e){
      let i,s=this,r={};
      function n(t){
        if("string"==typeof t){
          var e;
          return e=/^(\/\/)|([a-z]+:(\/\/)?)/i.test(t)?t:s.resourcePath+t,s.manager.itemStart(e),i.load(e,function(){
            s.manager.itemEnd(e)
            },void 0,function(){
            s.manager.itemError(e),s.manager.itemEnd(e)
            })
          }
        return t.data?{data:g(t.type,t.data),width:t.width,height:t.height}:null
        }
      if(void 0!==t&&t.length>0){
        (i=new ng(new nu(e))).setCrossOrigin(this.crossOrigin);
        for(
        let e=0,i=t.length
        ;e<i;e++){
          let i=t[e],s=i.url;
          if(Array.isArray(s)){
            let t=[];
            for(
            let e=0,i=s.length
            ;e<i;e++){
              let i=n(s[e]);
              null!==i&&(i instanceof HTMLImageElement?t.push(i):t.push(new iI(i.data,i.width,i.height)))
              }
            r[i.uuid]=new Q(t)
            }else{
            let t=n(i.url);
            r[i.uuid]=new Q(t)
            }
          }
        }
      return r
      }async parseImagesAsync(t){
      let e,i=this,s={};
      async function r(t){
        if("string"==typeof t){
          let s=/^(\/\/)|([a-z]+:(\/\/)?)/i.test(t)?t:i.resourcePath+t;
          return await e.loadAsync(s)
          }
        return t.data?{data:g(t.type,t.data),width:t.width,height:t.height}:null
        }
      if(void 0!==t&&t.length>0){
        (e=new ng(this.manager)).setCrossOrigin(this.crossOrigin);
        for(
        let e=0,i=t.length
        ;e<i;e++){
          let i=t[e],n=i.url;
          if(Array.isArray(n)){
            let t=[];
            for(
            let e=0,i=n.length
            ;e<i;e++){
              let i=n[e],s=await r(i);
              null!==s&&(s instanceof HTMLImageElement?t.push(s):t.push(new iI(s.data,s.width,s.height)))
              }
            s[i.uuid]=new Q(t)
            }else{
            let t=await r(i.url);
            s[i.uuid]=new Q(t)
            }
          }
        }
      return s
      }parseTextures(t,e){
      function i(t,e){
        return"number"==typeof t?t:(_("ObjectLoader.parseTexture: Constant should be in numeric form.",t),e[t])
        }
      let s={};
      if(void 0!==t)
      for(
      let r=0,n=t.length
      ;r<n;r++){
        let n,a=t[r];
        void 0===a.image&&_('ObjectLoader: No "image" specified for',a.uuid),void 0===e[a.image]&&_("ObjectLoader: Undefined image",a.image);
        let o=e[a.image],h=o.data;
        Array.isArray(h)?(n=new sI,6===h.length&&(n.needsUpdate=!0)):(n=h&&h.data?new iI:new ti,h&&(n.needsUpdate=!0)),n.source=o,n.uuid=a.uuid,void 0!==a.name&&(n.name=a.name),void 0!==a.mapping&&(n.mapping=i(a.mapping,nX)),void 0!==a.channel&&(n.channel=a.channel),void 0!==a.offset&&n.offset.fromArray(a.offset),void 0!==a.repeat&&n.repeat.fromArray(a.repeat),void 0!==a.center&&n.center.fromArray(a.center),void 0!==a.rotation&&(n.rotation=a.rotation),void 0!==a.wrap&&(n.wrapS=i(a.wrap[0],nY),n.wrapT=i(a.wrap[1],nY)),void 0!==a.format&&(n.format=a.format),void 0!==a.internalFormat&&(n.internalFormat=a.internalFormat),void 0!==a.type&&(n.type=a.type),void 0!==a.colorSpace&&(n.colorSpace=a.colorSpace),void 0!==a.minFilter&&(n.minFilter=i(a.minFilter,nZ)),void 0!==a.magFilter&&(n.magFilter=i(a.magFilter,nZ)),void 0!==a.anisotropy&&(n.anisotropy=a.anisotropy),void 0!==a.flipY&&(n.flipY=a.flipY),void 0!==a.generateMipmaps&&(n.generateMipmaps=a.generateMipmaps),void 0!==a.premultiplyAlpha&&(n.premultiplyAlpha=a.premultiplyAlpha),void 0!==a.unpackAlignment&&(n.unpackAlignment=a.unpackAlignment),void 0!==a.compareFunction&&(n.compareFunction=a.compareFunction),void 0!==a.normalized&&(n.normalized=a.normalized),void 0!==a.userData&&(n.userData=a.userData),s[a.uuid]=n
        }
      return s
      }parseObject(t,e,i,s,r){
      let n,a,o;
      function h(t){
        return void 0===e[t]&&_("ObjectLoader: Undefined geometry",t),e[t]
        }
      function l(t){
        if(void 0!==t){
          if(Array.isArray(t)){
            let e=[];
            for(
            let s=0,r=t.length
            ;s<r;s++){
              let r=t[s];
              void 0===i[r]&&_("ObjectLoader: Undefined material",r),e.push(i[r])
              }
            return e
            }
          return void 0===i[t]&&_("ObjectLoader: Undefined material",t),i[t]
          }
        }
      function u(t){
        return void 0===s[t]&&_("ObjectLoader: Undefined texture",t),s[t]
        }
      switch(t.type){case"Scene":
      n=new tJ,void 0!==t.background&&(Number.isInteger(t.background)?n.background=new tj(t.background):n.background=u(t.background)),void 0!==t.environment&&(n.environment=u(t.environment)),void 0!==t.fog&&("Fog"===t.fog.type?n.fog=new tq(t.fog.color,t.fog.near,t.fog.far):"FogExp2"===t.fog.type&&(n.fog=new tG(t.fog.color,t.fog.density)),""!==t.fog.name&&(n.fog.name=t.fog.name)),void 0!==t.backgroundBlurriness&&(n.backgroundBlurriness=t.backgroundBlurriness),void 0!==t.backgroundIntensity&&(n.backgroundIntensity=t.backgroundIntensity),void 0!==t.backgroundRotation&&n.backgroundRotation.fromArray(t.backgroundRotation),void 0!==t.environmentIntensity&&(n.environmentIntensity=t.environmentIntensity),void 0!==t.environmentRotation&&n.environmentRotation.fromArray(t.environmentRotation);
      break;
      case"PerspectiveCamera":
      n=new nk(t.fov,t.aspect,t.near,t.far),void 0!==t.focus&&(n.focus=t.focus),void 0!==t.zoom&&(n.zoom=t.zoom),void 0!==t.filmGauge&&(n.filmGauge=t.filmGauge),void 0!==t.filmOffset&&(n.filmOffset=t.filmOffset),void 0!==t.view&&(n.view=Object.assign({},t.view));
      break;
      case"OrthographicCamera":
      n=new nL(t.left,t.right,t.top,t.bottom,t.near,t.far),void 0!==t.zoom&&(n.zoom=t.zoom),void 0!==t.view&&(n.view=Object.assign({},t.view));
      break;
      case"AmbientLight":
      n=new nV(t.color,t.intensity);
      break;
      case"DirectionalLight":
      (n=new nE(t.color,t.intensity)).target=t.target||"";
      break;
      case"PointLight":
      n=new nF(t.color,t.intensity,t.distance,t.decay);
      break;
      case"RectAreaLight":
      n=new nD(t.color,t.intensity,t.width,t.height);
      break;
      case"SpotLight":
      (n=new nR(t.color,t.intensity,t.distance,t.angle,t.penumbra,t.decay)).target=t.target||"";
      break;
      case"HemisphereLight":
      n=new nb(t.color,t.groundColor,t.intensity);
      break;
      case"LightProbe":
      n=new nj(new nU().fromArray(t.sh),t.intensity);
      break;
      case"SkinnedMesh":
      n=new iT(a=h(t.geometry),o=l(t.material)),void 0!==t.bindMode&&(n.bindMode=t.bindMode),void 0!==t.bindMatrix&&n.bindMatrix.fromArray(t.bindMatrix),void 0!==t.skeleton&&(n.skeleton=t.skeleton);
      break;
      case"Mesh":
      n=new im(a=h(t.geometry),o=l(t.material));
      break;
      case"InstancedMesh":
      a=h(t.geometry),o=l(t.material);
      let c=t.count,p=t.instanceMatrix,d=t.instanceColor;
      (n=new iD(a,o,c)).instanceMatrix=new iO(new Float32Array(p.array),16),void 0!==d&&(n.instanceColor=new iO(new Float32Array(d.array),d.itemSize));
      break;
      case"BatchedMesh":
      a=h(t.geometry),o=l(t.material),(n=new sr(t.maxInstanceCount,t.maxVertexCount,t.maxIndexCount,o)).geometry=a,n.perObjectFrustumCulled=t.perObjectFrustumCulled,n.sortObjects=t.sortObjects,n._drawRanges=t.drawRanges,n._reservedRanges=t.reservedRanges,n._geometryInfo=t.geometryInfo.map(t=>{
        let e=null,i=null;
        return void 0!==t.boundingBox&&(e=new t8().fromJSON(t.boundingBox)),void 0!==t.boundingSphere&&(i=new eA().fromJSON(t.boundingSphere)),{...t,boundingBox:e,boundingSphere:i}
        }),n._instanceInfo=t.instanceInfo,n._availableInstanceIds=t._availableInstanceIds,n._availableGeometryIds=t._availableGeometryIds,n._nextIndexStart=t.nextIndexStart,n._nextVertexStart=t.nextVertexStart,n._geometryCount=t.geometryCount,n._maxInstanceCount=t.maxInstanceCount,n._maxVertexCount=t.maxVertexCount,n._maxIndexCount=t.maxIndexCount,n._geometryInitialized=t.geometryInitialized,n._matricesTexture=u(t.matricesTexture.uuid),n._indirectTexture=u(t.indirectTexture.uuid),void 0!==t.colorsTexture&&(n._colorsTexture=u(t.colorsTexture.uuid)),void 0!==t.boundingSphere&&(n.boundingSphere=new eA().fromJSON(t.boundingSphere)),void 0!==t.boundingBox&&(n.boundingBox=new t8().fromJSON(t.boundingBox));
      break;
      case"LOD":
      n=new e2;
      break;
      case"Line":
      n=new sd(h(t.geometry),l(t.material));
      break;
      case"LineLoop":
      n=new sx(h(t.geometry),l(t.material));
      break;
      case"LineSegments":
      n=new sg(h(t.geometry),l(t.material));
      break;
      case"PointCloud":case"Points":
      n=new s_(h(t.geometry),l(t.material));
      break;
      case"Sprite":
      n=new eQ(l(t.material));
      break;
      case"Group":
      n=new tL;
      break;
      case"Bone":
      n=new iC;
      break;
      default:
      n=new tF
      }
      if(n.uuid=t.uuid,void 0!==t.name&&(n.name=t.name),void 0!==t.matrix?(n.matrix.fromArray(t.matrix),void 0!==t.matrixAutoUpdate&&(n.matrixAutoUpdate=t.matrixAutoUpdate),n.matrixAutoUpdate&&n.matrix.decompose(n.position,n.quaternion,n.scale)):(void 0!==t.position&&n.position.fromArray(t.position),void 0!==t.rotation&&n.rotation.fromArray(t.rotation),void 0!==t.quaternion&&n.quaternion.fromArray(t.quaternion),void 0!==t.scale&&n.scale.fromArray(t.scale)),void 0!==t.up&&n.up.fromArray(t.up),void 0!==t.pivot&&(n.pivot=new D().fromArray(t.pivot)),void 0!==t.morphTargetDictionary&&(n.morphTargetDictionary=Object.assign({},t.morphTargetDictionary)),void 0!==t.morphTargetInfluences&&(n.morphTargetInfluences=t.morphTargetInfluences.slice()),void 0!==t.castShadow&&(n.castShadow=t.castShadow),void 0!==t.receiveShadow&&(n.receiveShadow=t.receiveShadow),t.shadow&&(void 0!==t.shadow.intensity&&(n.shadow.intensity=t.shadow.intensity),void 0!==t.shadow.bias&&(n.shadow.bias=t.shadow.bias),void 0!==t.shadow.normalBias&&(n.shadow.normalBias=t.shadow.normalBias),void 0!==t.shadow.radius&&(n.shadow.radius=t.shadow.radius),void 0!==t.shadow.mapSize&&n.shadow.mapSize.fromArray(t.shadow.mapSize),void 0!==t.shadow.camera&&(n.shadow.camera=this.parseObject(t.shadow.camera))),void 0!==t.visible&&(n.visible=t.visible),void 0!==t.frustumCulled&&(n.frustumCulled=t.frustumCulled),void 0!==t.renderOrder&&(n.renderOrder=t.renderOrder),void 0!==t.static&&(n.static=t.static),void 0!==t.userData&&(n.userData=t.userData),void 0!==t.layers&&(n.layers.mask=t.layers),void 0!==t.children){
        let a=t.children;
        for(
        let t=0
        ;t<a.length;t++)
        n.add(this.parseObject(a[t],e,i,s,r))
        }
      if(void 0!==t.animations){
        let e=t.animations;
        for(
        let t=0
        ;t<e.length;t++){
          let i=e[t];
          n.animations.push(r[i])
          }
        }
      if("LOD"===t.type){
        void 0!==t.autoUpdate&&(n.autoUpdate=t.autoUpdate);
        let e=t.levels;
        for(
        let t=0
        ;t<e.length;t++){
          let i=e[t],s=n.getObjectByProperty("uuid",i.object);
          void 0!==s&&n.addLevel(s,i.distance,i.hysteresis)
          }
        }
      return n
      }bindSkeletons(t,e){
      0!==Object.keys(e).length&&t.traverse(function(t){
        if(!0===t.isSkinnedMesh&&void 0!==t.skeleton){
          let i=e[t.skeleton];
          void 0===i?_("ObjectLoader: No skeleton found with UUID:",t.skeleton):t.bind(i,t.bindMatrix)
          }
        })
      }bindLightTargets(t){
      t.traverse(function(e){
        if(e.isDirectionalLight||e.isSpotLight){
          let i=e.target,s=t.getObjectByProperty("uuid",i);
          void 0!==s?e.target=s:e.target=new tF
          }
        })
      }
  },"ObjectSpaceNormalMap",0,1,"OctahedronGeometry",0,rT,"OneFactor",0,201,"OneMinusConstantAlphaFactor",0,214,"OneMinusConstantColorFactor",0,212,"OneMinusDstAlphaFactor",0,207,"OneMinusDstColorFactor",0,209,"OneMinusSrcAlphaFactor",0,205,"OneMinusSrcColorFactor",0,203,"OrthographicCamera",0,nL,"PCFShadowMap",0,1,"PCFSoftShadowMap",0,2,"Path",0,rt,"PerspectiveCamera",0,nk,"Plane",0,iG,"PlaneGeometry",0,rC,"PlaneHelper",0,class extends sd{
    constructor(t,e=1,i=0xffff00){
      const s=new eR;
      s.setAttribute("position",new eM([1,-1,0,-1,1,0,-1,-1,0,1,1,0,-1,1,0,-1,-1,0,1,-1,0,1,1,0],3)),s.computeBoundingSphere(),super(s,new sn({color:i,toneMapped:!1})),this.type="PlaneHelper",this.plane=t,this.size=e;
      const r=new eR;
      r.setAttribute("position",new eM([1,1,0,-1,1,0,-1,-1,0,1,1,0,-1,-1,0,1,-1,0],3)),r.computeBoundingSphere(),this.add(new im(r,new ie({color:i,opacity:.2,transparent:!0,depthWrite:!1,toneMapped:!1})))
      }updateMatrixWorld(t){
      this.position.set(0,0,0),this.scale.set(.5*this.size,.5*this.size,1),this.lookAt(this.plane.normal),this.translateZ(-this.plane.constant),super.updateMatrixWorld(t)
      }dispose(){
      this.geometry.dispose(),this.material.dispose(),this.children[0].geometry.dispose(),this.children[0].material.dispose()
      }
  },"PointLight",0,nF,"PointLightHelper",0,class extends im{
    constructor(t,e,i){
      super(new rB(e,4,2),new ie({wireframe:!0,fog:!1,toneMapped:!1})),this.light=t,this.color=i,this.type="PointLightHelper",this.matrix=this.light.matrixWorld,this.matrixAutoUpdate=!1,this.update()
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }update(){
      this.light.updateWorldMatrix(!0,!1),void 0!==this.color?this.material.color.set(this.color):this.material.color.copy(this.light.color)
      }
  },"Points",0,s_,"PointsMaterial",0,sb,"PolarGridHelper",0,class extends sg{
    constructor(t=10,e=16,i=8,s=64,r=4473924,n=8947848){
      r=new tj(r),n=new tj(n);
      const a=[],o=[];
      if(e>1)
      for(
      let i=0
      ;i<e;i++){
        const s=i/e*(2*Math.PI),h=Math.sin(s)*t,l=Math.cos(s)*t;
        a.push(0,0,0),a.push(h,0,l);
        const u=1&i?r:n;
        o.push(u.r,u.g,u.b),o.push(u.r,u.g,u.b)
        }
      for(
      let e=0
      ;e<i;e++){
        const h=1&e?r:n,l=t-t/i*e;
        for(
        let t=0
        ;t<s;t++){
          let e=t/s*(2*Math.PI),i=Math.sin(e)*l,r=Math.cos(e)*l;
          a.push(i,0,r),o.push(h.r,h.g,h.b),i=Math.sin(e=(t+1)/s*(2*Math.PI))*l,r=Math.cos(e)*l,a.push(i,0,r),o.push(h.r,h.g,h.b)
          }
        }
      const h=new eR;
      h.setAttribute("position",new eM(a,3)),h.setAttribute("color",new eM(o,3)),super(h,new sn({vertexColors:!0,toneMapped:!1})),this.type="PolarGridHelper"
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"PolyhedronGeometry",0,sF,"PositionalAudio",0,class extends n7{
    constructor(t){
      super(t),this.panner=this.context.createPanner(),this.panner.panningModel="HRTF",this.panner.connect(this.gain)
      }connect(){
      return super.connect(),this.panner.connect(this.gain),this
      }disconnect(){
      return super.disconnect(),this.panner.disconnect(this.gain),this
      }getOutput(){
      return this.panner
      }getRefDistance(){
      return this.panner.refDistance
      }setRefDistance(t){
      return this.panner.refDistance=t,this
      }getRolloffFactor(){
      return this.panner.rolloffFactor
      }setRolloffFactor(t){
      return this.panner.rolloffFactor=t,this
      }getDistanceModel(){
      return this.panner.distanceModel
      }setDistanceModel(t){
      return this.panner.distanceModel=t,this
      }getMaxDistance(){
      return this.panner.maxDistance
      }setMaxDistance(t){
      return this.panner.maxDistance=t,this
      }setDirectionalCone(t,e,i){
      return this.panner.coneInnerAngle=t,this.panner.coneOuterAngle=e,this.panner.coneOuterGain=i,this
      }updateMatrixWorld(t){
      if(super.updateMatrixWorld(t),!0===this.hasPlaybackControl&&!1===this.isPlaying)
      return;
      this.matrixWorld.decompose(at,ae,ai),as.set(0,0,1).applyQuaternion(ae);
      let e=this.panner;
      if(e.positionX){
        let t=this.context.currentTime+this.listener.timeDelta;
        e.positionX.linearRampToValueAtTime(at.x,t),e.positionY.linearRampToValueAtTime(at.y,t),e.positionZ.linearRampToValueAtTime(at.z,t),e.orientationX.linearRampToValueAtTime(as.x,t),e.orientationY.linearRampToValueAtTime(as.y,t),e.orientationZ.linearRampToValueAtTime(as.z,t)
        }else 
      e.setPosition(at.x,at.y,at.z),e.setOrientation(as.x,as.y,as.z)
      }
  },"PropertyBinding",0,ac,"PropertyMixer",0,ar,"QuadraticBezierCurve",0,s4,"QuadraticBezierCurve3",0,s6,"Quaternion",0,V,"QuaternionKeyframeTrack",0,nr,"QuaternionLinearInterpolant",0,ns,"R11_EAC_Format",0,37488,"RAD2DEG",0,k,"RED_GREEN_RGTC2_Format",0,36285,"RED_RGTC1_Format",0,36283,"REVISION",0,"184","RG11_EAC_Format",0,37490,"RGBADepthPacking",0,3201,"RGBAFormat",0,1023,"RGBAIntegerFormat",0,1033,"RGBA_ASTC_10x10_Format",0,37819,"RGBA_ASTC_10x5_Format",0,37816,"RGBA_ASTC_10x6_Format",0,37817,"RGBA_ASTC_10x8_Format",0,37818,"RGBA_ASTC_12x10_Format",0,37820,"RGBA_ASTC_12x12_Format",0,37821,"RGBA_ASTC_4x4_Format",0,37808,"RGBA_ASTC_5x4_Format",0,37809,"RGBA_ASTC_5x5_Format",0,37810,"RGBA_ASTC_6x5_Format",0,37811,"RGBA_ASTC_6x6_Format",0,37812,"RGBA_ASTC_8x5_Format",0,37813,"RGBA_ASTC_8x6_Format",0,37814,"RGBA_ASTC_8x8_Format",0,37815,"RGBA_BPTC_Format",0,36492,"RGBA_ETC2_EAC_Format",0,37496,"RGBA_PVRTC_2BPPV1_Format",0,35843,"RGBA_PVRTC_4BPPV1_Format",0,35842,"RGBA_S3TC_DXT1_Format",0,33777,"RGBA_S3TC_DXT3_Format",0,33778,"RGBA_S3TC_DXT5_Format",0,33779,"RGBDepthPacking",0,3202,"RGBFormat",0,1022,"RGBIntegerFormat",0,1032,"RGB_BPTC_SIGNED_Format",0,36494,"RGB_BPTC_UNSIGNED_Format",0,36495,"RGB_ETC1_Format",0,36196,"RGB_ETC2_Format",0,37492,"RGB_PVRTC_2BPPV1_Format",0,35841,"RGB_PVRTC_4BPPV1_Format",0,35840,"RGB_S3TC_DXT1_Format",0,33776,"RGDepthPacking",0,3203,"RGFormat",0,1030,"RGIntegerFormat",0,1031,"RawShaderMaterial",0,rW,"Ray",0,it,"Raycaster",0,class{
    constructor(t,e,i=0,s=1/0){
      this.ray=new it(t,e),this.near=i,this.far=s,this.camera=null,this.layers=new tb,this.params={Mesh:{},Line:{threshold:1},LOD:{},Points:{threshold:1},Sprite:{}}
      }set(t,e){
      this.ray.set(t,e)
      }setFromCamera(t,e){
      e.isPerspectiveCamera?(this.ray.origin.setFromMatrixPosition(e.matrixWorld),this.ray.direction.set(t.x,t.y,.5).unproject(e).sub(this.ray.origin).normalize(),this.camera=e):e.isOrthographicCamera?(this.ray.origin.set(t.x,t.y,(e.near+e.far)/(e.near-e.far)).unproject(e),this.ray.direction.set(0,0,-1).transformDirection(e.matrixWorld),this.camera=e):A("Raycaster: Unsupported camera type: "+e.type)
      }setFromXRController(t){
      return af.identity().extractRotation(t.matrixWorld),this.ray.origin.setFromMatrixPosition(t.matrixWorld),this.ray.direction.set(0,0,-1).applyMatrix4(af),this
      }intersectObject(t,e=!0,i=[]){
      return ax(t,this,i,e),i.sort(ag),i
      }intersectObjects(t,e=!0,i=[]){
      for(
      let s=0,r=t.length
      ;s<r;s++)
      ax(t[s],this,i,e);
      return i.sort(ag),i
      }
  },"RectAreaLight",0,nD,"RedFormat",0,1028,"RedIntegerFormat",0,1029,"ReinhardToneMapping",0,2,"RenderTarget",0,tr,"RenderTarget3D",0,class extends tr{
    constructor(t=1,e=1,i=1,s={}){
      super(t,e,s),this.isRenderTarget3D=!0,this.depth=i,this.texture=new to(null,t,e,i),this._setTextureOptions(s),this.texture.isRenderTargetTexture=!0
      }
  },"RepeatWrapping",0,1e3,"ReplaceStencilOp",0,7681,"ReverseSubtractEquation",0,102,"ReversedDepthFuncs",0,{0:1,2:6,4:7,3:5,1:0,6:2,7:4,5:3},"RingGeometry",0,rI,"SIGNED_R11_EAC_Format",0,37489,"SIGNED_RED_GREEN_RGTC2_Format",0,36286,"SIGNED_RED_RGTC1_Format",0,36284,"SIGNED_RG11_EAC_Format",0,37491,"SRGBColorSpace",0,p,"SRGBTransfer",0,y,"Scene",0,tJ,"ShaderMaterial",0,rj,"ShadowMaterial",0,rE,"Shape",0,re,"ShapeGeometry",0,rz,"ShapePath",0,class{
    constructor(){
      this.type="ShapePath",this.color=new tj,this.subPaths=[],this.currentPath=null
      }moveTo(t,e){
      return this.currentPath=new rt,this.subPaths.push(this.currentPath),this.currentPath.moveTo(t,e),this
      }lineTo(t,e){
      return this.currentPath.lineTo(t,e),this
      }quadraticCurveTo(t,e,i,s){
      return this.currentPath.quadraticCurveTo(t,e,i,s),this
      }bezierCurveTo(t,e,i,s,r,n){
      return this.currentPath.bezierCurveTo(t,e,i,s,r,n),this
      }splineThru(t){
      return this.currentPath.splineThru(t),this
      }toShapes(t){
      let e,i,s,r,n,a=rb.isClockWise,o=this.subPaths;
      if(0===o.length)
      return[];
      let h=[];
      if(1===o.length)
      return i=o[0],(s=new re).curves=i.curves,h.push(s),h;
      let l=!a(o[0].getPoints());
      l=t?!l:l;
      let u=[],c=[],p=[],d=0;
      c[0]=void 0,p[d]=[];
      for(
      let s=0,n=o.length
      ;s<n;s++)
      e=a(r=(i=o[s]).getPoints()),(e=t?!e:e)?(!l&&c[d]&&d++,c[d]={s:new re,p:r},c[d].s.curves=i.curves,l&&d++,p[d]=[]):p[d].push({h:i,p:r[0]});
      if(!c[0])
      return function(t){
        let e=[];
        for(
        let i=0,s=t.length
        ;i<s;i++){
          let s=t[i],r=new re;
          r.curves=s.curves,e.push(r)
          }
        return e
        }(o);
      if(c.length>1){
        let t=!1,e=0;
        for(
        let t=0,e=c.length
        ;t<e;t++)
        u[t]=[];
        for(
        let i=0,s=c.length
        ;i<s;i++){
          let s=p[i];
          for(
          let r=0
          ;r<s.length;r++){
            let n=s[r],a=!0;
            for(
            let s=0
            ;s<c.length;s++)
            (function(t,e){
              let i=e.length,s=!1;
              for(
              let r=i-1,n=0
              ;n<i;r=n++){
                let i=e[r],a=e[n],o=a.x-i.x,h=a.y-i.y;
                if(Math.abs(h)>Number.EPSILON){
                  if(h<0&&(i=e[n],o=-o,a=e[r],h=-h),t.y<i.y||t.y>a.y)
                  continue;
                  if(t.y===i.y){
                    if(t.x===i.x)
                    return!0
                    }else{
                    let e=h*(t.x-i.x)-o*(t.y-i.y);
                    if(0===e)
                    return!0;
                    if(e<0)
                    continue;
                    s=!s
                    }
                  }else{
                  if(t.y!==i.y)
                  continue;
                  if(a.x<=t.x&&t.x<=i.x||i.x<=t.x&&t.x<=a.x)
                  return!0
                  }
                }
              return s
              })(n.p,c[s].p)&&(i!==s&&e++,a?(a=!1,u[s].push(n)):t=!0);
            a&&u[i].push(n)
            }
          }
        e>0&&!1===t&&(p=u)
        }
      for(
      let t=0,e=c.length
      ;t<e;t++){
        s=c[t].s,h.push(s),n=p[t];
        for(
        let t=0,e=n.length
        ;t<e;t++)
        s.holes.push(n[t].h)
        }
      return h
      }
  },"ShapeUtils",0,rb,"ShortType",0,1011,"Skeleton",0,ik,"SkeletonHelper",0,class extends sg{
    constructor(t){
      const e=function t(e){
        let i=[];
        !0===e.isBone&&i.push(e);
        for(
        let s=0
        ;s<e.children.length;s++)
        i.push(...t(e.children[s]));
        return i
        }(t),i=new eR,s=[],r=[];
      for(
      let t=0
      ;t<e.length;t++){
        const i=e[t];
        i.parent&&i.parent.isBone&&(s.push(0,0,0),s.push(0,0,0),r.push(0,0,0),r.push(0,0,0))
        }
      i.setAttribute("position",new eM(s,3)),i.setAttribute("color",new eM(r,3)),super(i,new sn({vertexColors:!0,depthTest:!1,depthWrite:!1,toneMapped:!1,transparent:!0})),this.isSkeletonHelper=!0,this.type="SkeletonHelper",this.root=t,this.bones=e,this.matrix=t.matrixWorld,this.matrixAutoUpdate=!1;
      const n=new tj(255),a=new tj(65280);
      this.setColors(n,a)
      }updateMatrixWorld(t){
      let e=this.bones,i=this.geometry,s=i.getAttribute("position");
      ak.copy(this.root.matrixWorld).invert();
      for(
      let t=0,i=0
      ;t<e.length;t++){
        let r=e[t];
        r.parent&&r.parent.isBone&&(aB.multiplyMatrices(ak,r.matrixWorld),az.setFromMatrixPosition(aB),s.setXYZ(i,az.x,az.y,az.z),aB.multiplyMatrices(ak,r.parent.matrixWorld),az.setFromMatrixPosition(aB),s.setXYZ(i+1,az.x,az.y,az.z),i+=2)
        }
      i.getAttribute("position").needsUpdate=!0,super.updateMatrixWorld(t)
      }setColors(t,e){
      let i=this.geometry.getAttribute("color");
      for(
      let s=0
      ;s<i.count;s+=2)
      i.setXYZ(s,t.r,t.g,t.b),i.setXYZ(s+1,e.r,e.g,e.b);
      return i.needsUpdate=!0,this
      }dispose(){
      this.geometry.dispose(),this.material.dispose()
      }
  },"SkinnedMesh",0,iT,"Source",0,Q,"Sphere",0,eA,"SphereGeometry",0,rB,"Spherical",0,class{
    constructor(t=1,e=0,i=0){
      this.radius=t,this.phi=e,this.theta=i
      }set(t,e,i){
      return this.radius=t,this.phi=e,this.theta=i,this
      }copy(t){
      return this.radius=t.radius,this.phi=t.phi,this.theta=t.theta,this
      }makeSafe(){
      return this.phi=R(this.phi,1e-6,Math.PI-1e-6),this
      }setFromVector3(t){
      return this.setFromCartesianCoords(t.x,t.y,t.z)
      }setFromCartesianCoords(t,e,i){
      return this.radius=Math.sqrt(t*t+e*e+i*i),0===this.radius?(this.theta=0,this.phi=0):(this.theta=Math.atan2(t,i),this.phi=Math.acos(R(e/this.radius,-1,1))),this
      }clone(){
      return new this.constructor().copy(this)
      }
  },"SphericalHarmonics3",0,nU,"SplineCurve",0,s8,"SpotLight",0,nR,"SpotLightHelper",0,class extends tF{
    constructor(t,e){
      super(),this.light=t,this.matrixAutoUpdate=!1,this.color=e,this.type="SpotLightHelper";
      const i=new eR,s=[0,0,0,0,0,1,0,0,0,1,0,1,0,0,0,-1,0,1,0,0,0,0,1,1,0,0,0,0,-1,1];
      for(
      let t=0,e=1
      ;t<32;t++,e++){
        const i=t/32*Math.PI*2,r=e/32*Math.PI*2;
        s.push(Math.cos(i),Math.sin(i),1,Math.cos(r),Math.sin(r),1)
        }
      i.setAttribute("position",new eM(s,3));
      const r=new sn({fog:!1,toneMapped:!1});
      this.cone=new sg(i,r),this.add(this.cone),this.update()
      }dispose(){
      this.cone.geometry.dispose(),this.cone.material.dispose()
      }update(){
      this.light.updateWorldMatrix(!0,!1),this.light.target.updateWorldMatrix(!0,!1),this.parent?(this.parent.updateWorldMatrix(!0),this.matrix.copy(this.parent.matrixWorld).invert().multiply(this.light.matrixWorld)):this.matrix.copy(this.light.matrixWorld),this.matrixWorld.copy(this.light.matrixWorld);
      let t=this.light.distance?this.light.distance:1e3,e=t*Math.tan(this.light.angle);
      this.cone.scale.set(e,e,t),aI.setFromMatrixPosition(this.light.target.matrixWorld),this.cone.lookAt(aI),void 0!==this.color?this.cone.material.color.set(this.color):this.cone.material.color.copy(this.light.color)
      }
  },"Sprite",0,eQ,"SpriteMaterial",0,eV,"SrcAlphaFactor",0,204,"SrcAlphaSaturateFactor",0,210,"SrcColorFactor",0,202,"StaticCopyUsage",0,35046,"StaticDrawUsage",0,35044,"StaticReadUsage",0,35045,"StereoCamera",0,class{
    constructor(){
      this.type="StereoCamera",this.aspect=1,this.eyeSep=.064,this.cameraL=new nk,this.cameraL.layers.enable(1),this.cameraL.matrixAutoUpdate=!1,this.cameraR=new nk,this.cameraR.layers.enable(2),this.cameraR.matrixAutoUpdate=!1,this._cache={focus:null,fov:null,aspect:null,near:null,far:null,zoom:null,eyeSep:null}
      }update(t){
      let e=this._cache;
      if(e.focus!==t.focus||e.fov!==t.fov||e.aspect!==t.aspect*this.aspect||e.near!==t.near||e.far!==t.far||e.zoom!==t.zoom||e.eyeSep!==this.eyeSep){
        let i,s;
        e.focus=t.focus,e.fov=t.fov,e.aspect=t.aspect*this.aspect,e.near=t.near,e.far=t.far,e.zoom=t.zoom,e.eyeSep=this.eyeSep,n1.copy(t.projectionMatrix);
        let r=e.eyeSep/2,n=r*e.near/e.focus,a=e.near*Math.tan(B*e.fov*.5)/e.zoom;
        n0.elements[12]=-r,nK.elements[12]=r,i=-a*e.aspect+n,s=a*e.aspect+n,n1.elements[0]=2*e.near/(s-i),n1.elements[8]=(s+i)/(s-i),this.cameraL.projectionMatrix.copy(n1),i=-a*e.aspect-n,s=a*e.aspect-n,n1.elements[0]=2*e.near/(s-i),n1.elements[8]=(s+i)/(s-i),this.cameraR.projectionMatrix.copy(n1)
        }
      this.cameraL.matrixWorld.copy(t.matrixWorld).multiply(n0),this.cameraR.matrixWorld.copy(t.matrixWorld).multiply(nK)
      }
  },"StreamCopyUsage",0,35042,"StreamDrawUsage",0,35040,"StreamReadUsage",0,35041,"StringKeyframeTrack",0,nn,"SubtractEquation",0,101,"SubtractiveBlending",0,3,"TOUCH",0,{ROTATE:0,PAN:1,DOLLY_PAN:2,DOLLY_ROTATE:3},"TangentSpaceNormalMap",0,0,"TetrahedronGeometry",0,rk,"Texture",0,ti,"TextureLoader",0,class extends np{
    constructor(t){
      super(t)
      }load(t,e,i,s){
      let r=new ti,n=new ng(this.manager);
      return n.setCrossOrigin(this.crossOrigin),n.setPath(this.path),n.load(t,function(t){
        r.image=t,r.needsUpdate=!0,void 0!==e&&e(r)
        },i,s),r
      }
  },"TextureUtils",0,class{
    static contain(t,e){
      let i;
      return(i=t.image&&t.image.width?t.image.width/t.image.height:1)>e?(t.repeat.x=1,t.repeat.y=i/e,t.offset.x=0,t.offset.y=(1-t.repeat.y)/2):(t.repeat.x=e/i,t.repeat.y=1,t.offset.x=(1-t.repeat.x)/2,t.offset.y=0),t
      }static cover(t,e){
      let i;
      return(i=t.image&&t.image.width?t.image.width/t.image.height:1)>e?(t.repeat.x=e/i,t.repeat.y=1,t.offset.x=(1-t.repeat.x)/2,t.offset.y=0):(t.repeat.x=1,t.repeat.y=i/e,t.offset.x=0,t.offset.y=(1-t.repeat.y)/2),t
      }static fill(t){
      return t.repeat.x=1,t.repeat.y=1,t.offset.x=0,t.offset.y=0,t
      }static getByteLength(t,e,i,s){
      return aW(t,e,i,s)
      }
  },"Timer",0,n2,"TimestampQuery",0,{COMPUTE:"compute",RENDER:"render"},"TorusGeometry",0,rO,"TorusKnotGeometry",0,rR,"Triangle",0,t6,"TriangleFanDrawMode",0,2,"TriangleStripDrawMode",0,1,"TrianglesDrawMode",0,0,"TubeGeometry",0,rP,"UVMapping",0,300,"Uint16BufferAttribute",0,eb,"Uint32BufferAttribute",0,ev,"Uint8BufferAttribute",0,class extends ex{
    constructor(t,e,i){
      super(new Uint8Array(t),e,i)
      }
  },"Uint8ClampedBufferAttribute",0,class extends ex{
    constructor(t,e,i){
      super(new Uint8ClampedArray(t),e,i)
      }
  },"Uniform",0,am,"UniformsGroup",0,class extends C{
    constructor(){
      super(),this.isUniformsGroup=!0,Object.defineProperty(this,"id",{value:ay++}),this.name="",this.usage=35044,this.uniforms=[]
      }add(t){
      return this.uniforms.push(t),this
      }remove(t){
      let e=this.uniforms.indexOf(t);
      return -1!==e&&this.uniforms.splice(e,1),this
      }setName(t){
      return this.name=t,this
      }setUsage(t){
      return this.usage=t,this
      }dispose(){
      this.dispatchEvent({type:"dispose"})
      }copy(t){
      this.name=t.name,this.usage=t.usage;
      let e=t.uniforms;
      this.uniforms.length=0;
      for(
      let t=0,i=e.length
      ;t<i;t++){
        let i=Array.isArray(e[t])?e[t]:[e[t]];
        for(
        let t=0
        ;t<i.length;t++)
        this.uniforms.push(i[t].clone())
        }
      return this
      }clone(){
      return new this.constructor().copy(this)
      }
  },"UniformsUtils",0,{clone:rV,merge:rD},"UnsignedByteType",0,1009,"UnsignedInt101111Type",0,35899,"UnsignedInt248Type",0,1020,"UnsignedInt5999Type",0,35902,"UnsignedIntType",0,1014,"UnsignedShort4444Type",0,1017,"UnsignedShort5551Type",0,1018,"UnsignedShortType",0,1012,"VSMShadowMap",0,3,"Vector2",0,E,"Vector3",0,D,"Vector4",0,ts,"VectorKeyframeTrack",0,na,"VideoFrameTexture",0,class extends sT{
    constructor(t,e,i,s,r,n,a,o){
      super({},t,e,i,s,r,n,a,o),this.isVideoFrameTexture=!0
      }update(){
      }clone(){
      return new this.constructor().copy(this)
      }setFrame(t){
      this.image=t,this.needsUpdate=!0
      }
  },"VideoTexture",0,sT,"WebGL3DRenderTarget",0,class extends tn{
    constructor(t=1,e=1,i=1,s={}){
      super(t,e,s),this.isWebGL3DRenderTarget=!0,this.depth=i,this.texture=new to(null,t,e,i),this._setTextureOptions(s),this.texture.isRenderTargetTexture=!0
      }
  },"WebGLArrayRenderTarget",0,class extends tn{
    constructor(t=1,e=1,i=1,s={}){
      super(t,e,s),this.isWebGLArrayRenderTarget=!0,this.depth=i,this.texture=new ta(null,t,e,i),this._setTextureOptions(s),this.texture.isRenderTargetTexture=!0
      }
  },"WebGLCoordinateSystem",0,2e3,"WebGLRenderTarget",0,tn,"WebGPUCoordinateSystem",0,2001,"WebXRController",0,class{
    constructor(){
      this._targetRay=null,this._grip=null,this._hand=null
      }getHandSpace(){
      return null===this._hand&&(this._hand=new tL,this._hand.matrixAutoUpdate=!1,this._hand.visible=!1,this._hand.joints={},this._hand.inputState={pinching:!1}),this._hand
      }getTargetRaySpace(){
      return null===this._targetRay&&(this._targetRay=new tL,this._targetRay.matrixAutoUpdate=!1,this._targetRay.visible=!1,this._targetRay.hasLinearVelocity=!1,this._targetRay.linearVelocity=new D,this._targetRay.hasAngularVelocity=!1,this._targetRay.angularVelocity=new D),this._targetRay
      }getGripSpace(){
      return null===this._grip&&(this._grip=new tL,this._grip.matrixAutoUpdate=!1,this._grip.visible=!1,this._grip.hasLinearVelocity=!1,this._grip.linearVelocity=new D,this._grip.hasAngularVelocity=!1,this._grip.angularVelocity=new D,this._grip.eventsEnabled=!1),this._grip
      }dispatchEvent(t){
      return null!==this._targetRay&&this._targetRay.dispatchEvent(t),null!==this._grip&&this._grip.dispatchEvent(t),null!==this._hand&&this._hand.dispatchEvent(t),this
      }connect(t){
      if(t&&t.hand){
        let e=this._hand;
        if(e)
        for(
        let i
         of t.hand.values())
        this._getHandJoint(e,i)
        }
      return this.dispatchEvent({type:"connected",data:t}),this
      }disconnect(t){
      return this.dispatchEvent({type:"disconnected",data:t}),null!==this._targetRay&&(this._targetRay.visible=!1),null!==this._grip&&(this._grip.visible=!1),null!==this._hand&&(this._hand.visible=!1),this
      }update(t,e,i){
      let s=null,r=null,n=null,a=this._targetRay,o=this._grip,h=this._hand;
      if(t&&"visible-blurred"!==e.session.visibilityState){
        if(h&&t.hand){
          for(
          let s
           of(n=!0,t.hand.values())){
            let t=e.getJointPose(s,i),r=this._getHandJoint(h,s);
            null!==t&&(r.matrix.fromArray(t.transform.matrix),r.matrix.decompose(r.position,r.rotation,r.scale),r.matrixWorldNeedsUpdate=!0,r.jointRadius=t.radius),r.visible=null!==t
            }
          let s=h.joints["index-finger-tip"],r=h.joints["thumb-tip"],a=s.position.distanceTo(r.position);
          h.inputState.pinching&&a>.025?(h.inputState.pinching=!1,this.dispatchEvent({type:"pinchend",handedness:t.handedness,target:this})):!h.inputState.pinching&&a<=.015&&(h.inputState.pinching=!0,this.dispatchEvent({type:"pinchstart",handedness:t.handedness,target:this}))
          }else 
        null!==o&&t.gripSpace&&null!==(r=e.getPose(t.gripSpace,i))&&(o.matrix.fromArray(r.transform.matrix),o.matrix.decompose(o.position,o.rotation,o.scale),o.matrixWorldNeedsUpdate=!0,r.linearVelocity?(o.hasLinearVelocity=!0,o.linearVelocity.copy(r.linearVelocity)):o.hasLinearVelocity=!1,r.angularVelocity?(o.hasAngularVelocity=!0,o.angularVelocity.copy(r.angularVelocity)):o.hasAngularVelocity=!1,o.eventsEnabled&&o.dispatchEvent({type:"gripUpdated",data:t,target:this}));
        null!==a&&(null===(s=e.getPose(t.targetRaySpace,i))&&null!==r&&(s=r),null!==s&&(a.matrix.fromArray(s.transform.matrix),a.matrix.decompose(a.position,a.rotation,a.scale),a.matrixWorldNeedsUpdate=!0,s.linearVelocity?(a.hasLinearVelocity=!0,a.linearVelocity.copy(s.linearVelocity)):a.hasLinearVelocity=!1,s.angularVelocity?(a.hasAngularVelocity=!0,a.angularVelocity.copy(s.angularVelocity)):a.hasAngularVelocity=!1,this.dispatchEvent(tN)))
        }
      return null!==a&&(a.visible=null!==s),null!==o&&(o.visible=null!==r),null!==h&&(h.visible=null!==n),this
      }_getHandJoint(t,e){
      if(void 0===t.joints[e.jointName]){
        let i=new tL;
        i.matrixAutoUpdate=!1,i.visible=!1,t.joints[e.jointName]=i,t.add(i)
        }
      return t.joints[e.jointName]
      }
  },"WireframeGeometry",0,rF,"WrapAroundEnding",0,2402,"ZeroCurvatureEnding",0,2400,"ZeroFactor",0,200,"ZeroSlopeEnding",0,2401,"ZeroStencilOp",0,0,"cloneUniforms",0,rV,"createCanvasElement",0,function(){
    let t=b("canvas");
    return t.style.display="block",t
    },"createElementNS",0,b,"error",0,A,"getByteLength",0,aW,"getConsoleFunction",0,function(){
    return M
    },"getUnlitUniformColorSpace",0,function(t){
    let e=t.getRenderTarget();
    return null===e?t.outputColorSpace:!0===e.isXRRenderTarget?e.texture.colorSpace:H.workingColorSpace
    },"log",0,w,"mergeUniforms",0,rD,"probeAsync",0,function(t,e,i){
    return new Promise(function(s,r){
      setTimeout(function n(){
        switch(t.clientWaitSync(e,t.SYNC_FLUSH_COMMANDS_BIT,0)){case t.WAIT_FAILED:
        r();
        break;
        case t.TIMEOUT_EXPIRED:
        setTimeout(n,i);
        break;
        default:
        s()
        }
        },i)
      })
    },"setConsoleFunction",0,function(t){
    M=t
    },"warn",0,_,"warnOnce",0,T])
  }]);
