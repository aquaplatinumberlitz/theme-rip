(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,18566,(e,t,r)=>{
  t.exports=e.r(76562)
  },55068,e=>{
  "use strict";
  var t,r=e.i(43476),n=e.i(71645),i=e.i(22016),o=e.i(18566),l=e.i(74080),s=Object.defineProperty,a=(e,t)=>s(e,"name",{value:t,configurable:!0});
  function c(e,t=[]){
    let i=[];
    function o(t,o){
      let l=n.createContext(o);
      l.displayName=t+"Context";
      let s=i.length;
      i=[...i,o];
      let c=a(t=>{
        let{scope:i,children:o,...a}=t,c=i?.[e]?.[s]||l,u=n.useMemo(()=>a,Object.values(a));
        return(0,r.jsx)(c.Provider,{value:u,children:o})
        },"Provider");
      function u(r,i,a={}){
        let{optional:c=!1}=a,d=i?.[e]?.[s]||l,h=n.useContext(d);
        if(h)
        return h;
        if(void 0!==o)
        return o;
        if(!c)
        throw Error(`\`${r}\` must be used within \`${t}\``)
        }
      return c.displayName=t+"Provider",a(u,"useContext"),[c,u]
      }
    a(o,"createContext");
    let l=a(()=>{
      let t=i.map(e=>n.createContext(e));
      return a(function(r){
        let i=r?.[e]||t;
        return n.useMemo(()=>({[`__scope${e}`]:{...r,[e]:i}}),[r,i])
        },"useScope")
      },"createScope");
    return l.scopeName=e,[o,u(l,...t)]
    }
  function u(...e){
    let t=e[0];
    if(1===e.length)
    return t;
    let r=a(()=>{
      let r=e.map(e=>({useScope:e(),scopeName:e.scopeName}));
      return a(function(e){
        let i=r.reduce((t,{useScope:r,scopeName:n})=>{
          let i=r(e)[`__scope${n}`];
          return{...t,...i}
          },{});
        return n.useMemo(()=>({[`__scope${t.scopeName}`]:i}),[i])
        },"useComposedScopes")
      },"createScope");
    return r.scopeName=t.scopeName,r
    }
  a(function(e,t){
    let i=n.createContext(t);
    i.displayName=e+"Context";
    let o=a(e=>{
      let{children:t,...o}=e,l=n.useMemo(()=>o,Object.values(o));
      return(0,r.jsx)(i.Provider,{value:l,children:t})
      },"Provider");
    function l(r,o={}){
      let{optional:s=!1}=o,a=n.useContext(i);
      if(a)
      return a;
      if(void 0!==t)
      return t;
      if(!s)
      throw Error(`\`${r}\` must be used within \`${e}\``)
      }
    return o.displayName=e+"Provider",a(l,"useContext"),[o,l]
    },"createContext"),a(c,"createContextScope"),a(u,"composeContextScopes");
  var d=Object.defineProperty,h=(e,t)=>d(e,"name",{value:t,configurable:!0}),f=!!("u">typeof window&&window.document&&window.document.createElement);
  function p(e,t,{checkForDefaultPrevented:r=!0}={}){
    return h(function(n){
      if(e?.(n),!1===r||!n||!n.defaultPrevented)
      return t?.(n)
      },"handleEvent")
    }
  function m(e){
    if(!f)
    throw Error("Cannot access document outside of the DOM");
    return e?.ownerDocument??document
    }
  function g(e){
    return"IFRAME"===e.tagName
    }
  h(p,"composeEventHandlers"),h(function(e){
    if(!f)
    throw Error("Cannot access window outside of the DOM");
    return e?.ownerDocument?.defaultView??window
    },"getOwnerWindow"),h(m,"getOwnerDocument"),h(function e(t,r=!1){
    let{activeElement:n}=m(t);
    if(!n?.nodeName)
    return null;
    if(g(n)&&n.contentDocument)
    return e(n.contentDocument.body,r);
    if(r){
      let e=n.getAttribute("aria-activedescendant");
      if(e){
        let t=m(n).getElementById(e);
        if(t)
        return t
        }
      }
    return n
    },"getActiveElement"),h(g,"isFrame");
  var v=Object.defineProperty,b=(e,t)=>v(e,"name",{value:t,configurable:!0});
  function x(e,t){
    if("function"==typeof e)
    return e(t);
    null!=e&&(e.current=t)
    }
  function w(...e){
    return t=>{
      let r=!1,n=e.map(e=>{
        let n=x(e,t);
        return r||"function"!=typeof n||(r=!0),n
        });
      if(r)
      return()=>{
        for(
        let t=0
        ;t<n.length;t++){
          let r=n[t];
          "function"==typeof r?r():x(e[t],null)
          }
        }
      }
    }
  function y(...e){
    return n.useCallback(w(...e),e)
    }
  b(x,"setRef"),b(w,"composeRefs"),b(y,"useComposedRefs");
  var S=Object.defineProperty,E=(e,t)=>S(e,"name",{value:t,configurable:!0});
  function k(e){
    let t=n.forwardRef((t,r)=>{
      let{children:i,...o}=t,l=null,s=!1,a=[];
      T(i)&&"function"==typeof I&&(i=I(i._payload)),n.Children.forEach(i,e=>{
        if(R(e)){
          s=!0;
          let t="child"in e.props?e.props.child:e.props.children;
          T(t)&&"function"==typeof I&&(t=I(t._payload)),l=j(e,t),a.push(l?.props?.children)
          }else 
        a.push(e)
        }),l?l=n.cloneElement(l,void 0,a):!s&&1===n.Children.count(i)&&n.isValidElement(i)&&(l=i);
      let c=l?M(l):void 0,u=y(r,c);
      if(!l){
        if(i||0===i)
        throw Error(s?A(e):L(e));
        return i
        }
      let d=C(o,l.props??{});
      return l.type!==n.Fragment&&(d.ref=r?u:c),n.cloneElement(l,d)
      });
    return t.displayName=`${e}.Slot`,t
    }
  E(k,"createSlot");
  var N=Symbol.for("radix.slottable");
  E(function(e){
    let t=E(e=>"child"in e?e.children(e.child):e.children,"Slottable");
    return t.displayName=`${e}.Slottable`,t.__radixId=N,t
    },"createSlottable");
  var j=E((e,t)=>{
    if("child"in e.props){
      let t=e.props.child;
      return n.isValidElement(t)?n.cloneElement(t,void 0,e.props.children(t.props.children)):null
      }
    return n.isValidElement(t)?t:null
    },"getSlottableElementFromSlottable");
  function C(e,t){
    let r={...t};
    for(
    let n
     in t){
      let i=e[n],o=t[n];
      /^on[A-Z]/.test(n)?i&&o?r[n]=(...e)=>{
        let t=o(...e);
        return i(...e),t
        }:i&&(r[n]=i):"style"===n?r[n]={...i,...o}:"className"===n&&(r[n]=[i,o].filter(Boolean).join(" "))
      }
    return{...e,...r}
    }
  function M(e){
    let t=Object.getOwnPropertyDescriptor(e.props,"ref")?.get,r=t&&"isReactWarning"in t&&t.isReactWarning;
    return r?e.ref:(r=(t=Object.getOwnPropertyDescriptor(e,"ref")?.get)&&"isReactWarning"in t&&t.isReactWarning)?e.props.ref:e.props.ref||e.ref
    }
  function R(e){
    return n.isValidElement(e)&&"function"==typeof e.type&&"__radixId"in e.type&&e.type.__radixId===N
    }
  E(C,"mergeProps"),E(M,"getElementRef"),E(R,"isSlottable");
  var P=Symbol.for("react.lazy");
  function T(e){
    return null!=e&&"object"==typeof e&&"$$typeof"in e&&e.$$typeof===P&&"_payload"in e&&O(e._payload)
    }
  function O(e){
    return"object"==typeof e&&null!==e&&"then"in e
    }
  E(T,"isLazyComponent"),E(O,"isPromiseLike");
  var L=E(e=>`${e} failed to slot onto its children. Expected a single React element child or \`Slottable\`.`,"createSlotError"),A=E(e=>`${e} failed to slot onto its \`Slottable\`. Expected \`Slottable\` to receive a single React element child.`,"createSlottableError"),I=n[" use ".trim().toString()],D=Object.defineProperty,_=["a","button","div","form","h2","h3","img","input","label","li","nav","ol","p","select","span","svg","ul"].reduce((e,t)=>{
    let i=k(`Primitive.${t}`),o=n.forwardRef((e,n)=>{
      let{asChild:o,...l}=e;
      return"u">typeof window&&(window[Symbol.for("radix-ui")]=!0),(0,r.jsx)(o?i:t,{...l,ref:n})
      });
    return o.displayName=`Primitive.${t}`,{...e,[t]:o}
    },{});
  function z(e,t){
    e&&l.flushSync(()=>e.dispatchEvent(t))
    }
  D(z,"name",{value:"dispatchDiscreteCustomEvent",configurable:!0});
  var F=globalThis?.document?n.useLayoutEffect:()=>{
    },W=Object.defineProperty,H=n[" useEffectEvent ".trim().toString()],$=n[" useInsertionEffect ".trim().toString()];
  function Y(e){
    if("function"==typeof H)
    return H(e);
    let t=n.useRef(()=>{
      throw Error("Cannot call an event handler while rendering.")
      });
    return"function"==typeof $?$(()=>{
      t.current=e
      }):F(()=>{
      t.current=e
      }),n.useMemo(()=>(...e)=>t.current?.(...e),[])
    }
  W(Y,"name",{value:"useEffectEvent",configurable:!0});
  var U=Object.defineProperty,q=(e,t)=>U(e,"name",{value:t,configurable:!0}),V=n[" useInsertionEffect ".trim().toString()]||F;
  function B({prop:e,defaultProp:t,onChange:r=q(()=>{
    },"onChange"),caller:i}){
    let[o,l,s]=Z({defaultProp:t,onChange:r}),a=void 0!==e,c=a?e:o;
    return[c,n.useCallback(t=>{
      if(a){
        let r=K(t)?t(e):t;
        r!==e&&s.current?.(r)
        }else 
      l(t)
      },[a,e,l,s])]
    }
  function Z({defaultProp:e,onChange:t}){
    let[r,i]=n.useState(e),o=n.useRef(r),l=n.useRef(t);
    return V(()=>{
      l.current=t
      },[t]),n.useEffect(()=>{
      o.current!==r&&(l.current?.(r),o.current=r)
      },[r,o]),[r,i,l]
    }
  function K(e){
    return"function"==typeof e
    }
  q(B,"useControllableState"),q(Z,"useUncontrolledState"),q(K,"isFunction");
  var G=Symbol("RADIX:SYNC_STATE");
  q(function(e,t,r,i){
    let{prop:o,defaultProp:l,onChange:s,caller:a}=t,c=void 0!==o,u=Y(s),d=[{...r,state:l}];
    i&&d.push(i);
    let[h,f]=n.useReducer((t,r)=>{
      if(r.type===G)
      return{...t,state:r.state};
      let n=e(t,r);
      return c&&!Object.is(n.state,t.state)&&u(n.state),n
      },...d),p=h.state,m=n.useRef(p);
    n.useEffect(()=>{
      m.current!==p&&(m.current=p,c||u(p))
      },[p,m,c]);
    let g=n.useMemo(()=>void 0!==o?{...h,state:o}:h,[h,o]);
    return n.useEffect(()=>{
      c&&!Object.is(o,h.state)&&f({type:G,state:o})
      },[o,h.state,c]),[g,f]
    },"useControllableStateReducer");
  var X=Object.defineProperty,J=n.createContext(void 0);
  function Q(e){
    let t=n.useContext(J);
    return e||t||"ltr"
    }
  X(Q,"name",{value:"useDirection",configurable:!0});
  var ee=Object.defineProperty,et=(e,t)=>ee(e,"name",{value:t,configurable:!0});
  function er(e,t){
    return n.useReducer((e,r)=>t[e][r]??e,e)
    }
  et(er,"useStateMachine");
  var en=et(e=>{
    let{present:t,children:r}=e,i=ei(t),o="function"==typeof r?r({present:i.isPresent}):n.Children.only(r),l=el(i.ref,ea(o));
    return"function"==typeof r||i.isPresent?n.cloneElement(o,{ref:l}):null
    },"Presence");
  function ei(e){
    let[t,r]=n.useState(),i=n.useRef(null),o=n.useRef(e),l=n.useRef("none"),s=n.useRef(void 0),[a,c]=er(e?"mounted":"unmounted",{mounted:{UNMOUNT:"unmounted",ANIMATION_OUT:"unmountSuspended"},unmountSuspended:{MOUNT:"mounted",ANIMATION_END:"unmounted"},unmounted:{MOUNT:"mounted"}});
    return n.useEffect(()=>{
      "mounted"===a?(l.current=s.current??es(i.current),s.current=void 0):l.current="none"
      },[a]),F(()=>{
      let t=i.current,r=o.current;
      if(r!==e){
        let n=l.current,i=es(t);
        e?(s.current=i,c("MOUNT")):"none"===i||t?.display==="none"?c("UNMOUNT"):r&&n!==i?c("ANIMATION_OUT"):c("UNMOUNT"),o.current=e
        }
      },[e,c]),F(()=>{
      if(t){
        let e,r=t.ownerDocument.defaultView??window,n=et(n=>{
          let l=es(i.current).includes(CSS.escape(n.animationName));
          if(n.target===t&&l&&(c("ANIMATION_END"),!o.current)){
            let n=t.style.animationFillMode;
            t.style.animationFillMode="forwards",e=r.setTimeout(()=>{
              "forwards"===t.style.animationFillMode&&(t.style.animationFillMode=n)
              })
            }
          },"handleAnimationEnd"),s=et(e=>{
          e.target===t&&(l.current=es(i.current))
          },"handleAnimationStart");
        return t.addEventListener("animationstart",s),t.addEventListener("animationcancel",n),t.addEventListener("animationend",n),()=>{
          r.clearTimeout(e),t.removeEventListener("animationstart",s),t.removeEventListener("animationcancel",n),t.removeEventListener("animationend",n)
          }
        }
      c("ANIMATION_END")
      },[t,c]),{isPresent:["mounted","unmountSuspended"].includes(a),ref:n.useCallback(e=>{
      if(e){
        let t=getComputedStyle(e);
        i.current=t,s.current=es(t)
        }else 
      i.current=null;
      r(e)
      },[])}
    }
  function eo(e,t){
    if("function"==typeof e)
    return e(t);
    null!=e&&(e.current=t)
    }
  function el(...e){
    let t=n.useRef(e);
    return t.current=e,n.useCallback(e=>{
      let r=t.current,n=!1,i=r.map(t=>{
        let r=eo(t,e);
        return n||"function"!=typeof r||(n=!0),r
        });
      if(n)
      return()=>{
        for(
        let e=0
        ;e<i.length;e++){
          let t=i[e];
          "function"==typeof t?t():eo(r[e],null)
          }
        }
      },[])
    }
  function es(e){
    return e?.animationName||"none"
    }
  function ea(e){
    let t=Object.getOwnPropertyDescriptor(e.props,"ref")?.get,r=t&&"isReactWarning"in t&&t.isReactWarning;
    return r?e.ref:(r=(t=Object.getOwnPropertyDescriptor(e,"ref")?.get)&&"isReactWarning"in t&&t.isReactWarning)?e.props.ref:e.props.ref||e.ref
    }
  et(ei,"usePresence"),et(eo,"setRef"),et(el,"useStableComposedRefs"),et(es,"getAnimationName"),et(ea,"getElementRef");
  var ec=Object.defineProperty,eu=n[" useId ".trim().toString()]||(()=>void 0),ed=0;
  function eh(e){
    let[t,r]=n.useState(eu());
    return F(()=>{
      e||r(e=>e??String(ed++))
      },[e]),e||(t?`radix-${t}`:"")
    }
  ec(eh,"name",{value:"useId",configurable:!0});
  var ef=Object.defineProperty,ep=(e,t)=>ef(e,"name",{value:t,configurable:!0});
  function em(e){
    let t=e+"CollectionProvider",[i,o]=c(t),[l,s]=i(t,{collectionRef:{current:null},itemMap:new Map}),a=ep(e=>{
      let{scope:t,children:i}=e,o=n.useRef(null),s=n.useRef(new Map).current;
      return(0,r.jsx)(l,{scope:t,itemMap:s,collectionRef:o,children:i})
      },"CollectionProvider");
    a.displayName=t;
    let u=e+"CollectionSlot",d=k(u),h=n.forwardRef((e,t)=>{
      let{scope:n,children:i}=e,o=y(t,s(u,n).collectionRef);
      return(0,r.jsx)(d,{ref:o,children:i})
      });
    h.displayName=u;
    let f=e+"CollectionItemSlot",p="data-radix-collection-item",m=k(f),g=n.forwardRef((e,t)=>{
      let{scope:i,children:o,...l}=e,a=n.useRef(null),c=y(t,a),u=s(f,i);
      return n.useEffect(()=>(u.itemMap.set(a,{ref:a,...l}),()=>void u.itemMap.delete(a))),(0,r.jsx)(m,{...{[p]:""},ref:c,children:o})
      });
    function v(t){
      let r=s(e+"CollectionConsumer",t);
      return n.useCallback(()=>{
        let e=r.collectionRef.current;
        if(!e)
        return[];
        let t=Array.from(e.querySelectorAll(`[${p}]`));
        return Array.from(r.itemMap.values()).sort((e,r)=>t.indexOf(e.ref.current)-t.indexOf(r.ref.current))
        },[r.collectionRef,r.itemMap])
      }
    return g.displayName=f,ep(v,"useCollection"),[{Provider:a,Slot:h,ItemSlot:g},v,o]
    }
  ep(em,"createCollection");
  var eg=new WeakMap,ev=class e extends Map{
    static{
    ep(this,"OrderedDict")
    }#e;constructor(e){
      super(e),this.#e=[...super.keys()],eg.set(this,!0)
      }set(e,t){
      return eg.get(this)&&(this.has(e)?this.#e[this.#e.indexOf(e)]=e:this.#e.push(e)),super.set(e,t),this
      }insert(e,t,r){
      let n,i=this.has(t),o=this.#e.length,l=ew(e),s=l>=0?l:o+l,a=s<0||s>=o?-1:s;
      if(a===this.size||i&&a===this.size-1||-1===a)
      return this.set(t,r),this;
      let c=this.size+ +!i;
      l<0&&s++;
      let u=[...this.#e],d=!1;
      for(
      let e=s
      ;e<c;e++)
      if(s===e){
        let o=u[e];
        u[e]===t&&(o=u[e+1]),i&&this.delete(t),n=this.get(o),this.set(t,r)
        }else{
        d||u[e-1]!==t||(d=!0);
        let r=u[d?e:e-1],i=n;
        n=this.get(r),this.delete(r),this.set(r,i)
        }
      return this
      }with(t,r,n){
      let i=new e(this);
      return i.insert(t,r,n),i
      }before(e){
      let t=this.#e.indexOf(e)-1;
      if(!(t<0))
      return this.entryAt(t)
      }setBefore(e,t,r){
      let n=this.#e.indexOf(e);
      return -1===n?this:this.insert(n,t,r)
      }after(e){
      let t=this.#e.indexOf(e);
      if(-1!==(t=-1===t||t===this.size-1?-1:t+1))
      return this.entryAt(t)
      }setAfter(e,t,r){
      let n=this.#e.indexOf(e);
      return -1===n?this:this.insert(n+1,t,r)
      }first(){
      return this.entryAt(0)
      }last(){
      return this.entryAt(-1)
      }clear(){
      return this.#e=[],super.clear()
      }delete(e){
      let t=super.delete(e);
      return t&&this.#e.splice(this.#e.indexOf(e),1),t
      }deleteAt(e){
      let t=this.keyAt(e);
      return void 0!==t&&this.delete(t)
      }at(e){
      let t=eb(this.#e,e);
      if(void 0!==t)
      return this.get(t)
      }entryAt(e){
      let t=eb(this.#e,e);
      if(void 0!==t)
      return[t,this.get(t)]
      }indexOf(e){
      return this.#e.indexOf(e)
      }keyAt(e){
      return eb(this.#e,e)
      }from(e,t){
      let r=this.indexOf(e);
      if(-1===r)
      return;
      let n=r+t;
      return n<0&&(n=0),n>=this.size&&(n=this.size-1),this.at(n)
      }keyFrom(e,t){
      let r=this.indexOf(e);
      if(-1===r)
      return;
      let n=r+t;
      return n<0&&(n=0),n>=this.size&&(n=this.size-1),this.keyAt(n)
      }find(e,t){
      let r=0;
      for(
      let n
       of this){
        if(Reflect.apply(e,t,[n,r,this]))
        return n;
        r++
        }
      }findIndex(e,t){
      let r=0;
      for(
      let n
       of this){
        if(Reflect.apply(e,t,[n,r,this]))
        return r;
        r++
        }
      return -1
      }filter(t,r){
      let n=[],i=0;
      for(
      let e
       of this)
      Reflect.apply(t,r,[e,i,this])&&n.push(e),i++;
      return new e(n)
      }map(t,r){
      let n=[],i=0;
      for(
      let e
       of this)
      n.push([e[0],Reflect.apply(t,r,[e,i,this])]),i++;
      return new e(n)
      }reduce(...e){
      let[t,r]=e,n=0,i=r??this.at(0);
      for(
      let r
       of this)
      i=0===n&&1===e.length?r:Reflect.apply(t,this,[i,r,n,this]),n++;
      return i
      }reduceRight(...e){
      let[t,r]=e,n=r??this.at(-1);
      for(
      let r=this.size-1
      ;r>=0;r--){
        let i=this.at(r);
        n=r===this.size-1&&1===e.length?i:Reflect.apply(t,this,[n,i,r,this])
        }
      return n
      }toSorted(t){
      return new e([...this.entries()].sort(t))
      }toReversed(){
      let t=new e;
      for(
      let e=this.size-1
      ;e>=0;e--){
        let r=this.keyAt(e),n=this.get(r);
        t.set(r,n)
        }
      return t
      }toSpliced(...t){
      let r=[...this.entries()];
      return r.splice(...t),new e(r)
      }slice(t,r){
      let n=new e,i=this.size-1;
      if(void 0===t)
      return n;
      t<0&&(t+=this.size),void 0!==r&&r>0&&(i=r-1);
      for(
      let e=t
      ;e<=i;e++){
        let t=this.keyAt(e),r=this.get(t);
        n.set(t,r)
        }
      return n
      }every(e,t){
      let r=0;
      for(
      let n
       of this){
        if(!Reflect.apply(e,t,[n,r,this]))
        return!1;
        r++
        }
      return!0
      }some(e,t){
      let r=0;
      for(
      let n
       of this){
        if(Reflect.apply(e,t,[n,r,this]))
        return!0;
        r++
        }
      return!1
      }
  };
  function eb(e,t){
    if("at"in Array.prototype)
    return Array.prototype.at.call(e,t);
    let r=ex(e,t);
    return -1===r?void 0:e[r]
    }
  function ex(e,t){
    let r=e.length,n=ew(t),i=n>=0?n:r+n;
    return i<0||i>=r?-1:i
    }
  function ew(e){
    return e!=e||0===e?0:Math.trunc(e)
    }
  function ey(e,t){
    if(e===t)
    return!0;
    if("object"!=typeof e||"object"!=typeof t||null==e||null==t)
    return!1;
    let r=Object.keys(e),n=Object.keys(t);
    if(r.length!==n.length)
    return!1;
    for(
    let n
     of r)
    if(!Object.prototype.hasOwnProperty.call(t,n)||e[n]!==t[n])
    return!1;
    return!0
    }
  function eS(e,t){
    return!!(t.compareDocumentPosition(e)&Node.DOCUMENT_POSITION_PRECEDING)
    }
  function eE(e,t){
    return e[1].element&&t[1].element?eS(e[1].element,t[1].element)?-1:1:0
    }
  function ek(e){
    return new MutationObserver(t=>{
      for(
      let r
       of t)
      if("childList"===r.type)
      return void e()
      })
    }
  function eN(e){
    let t=n.useRef(e);
    return n.useEffect(()=>{
      t.current=e
      }),n.useMemo(()=>(...e)=>t.current?.(...e),[])
    }
  ep(eb,"at"),ep(ex,"toSafeIndex"),ep(ew,"toSafeInteger"),ep(function(e){
    let t=e+"CollectionProvider",[i,o]=c(t),[l,s]=i(t,{collectionElement:null,collectionRef:{current:null},collectionRefObject:{current:null},itemMap:new ev,setItemMap:ep(()=>void 0,"setItemMap")}),a=ep(({state:e,...t})=>e?(0,r.jsx)(d,{...t,state:e}):(0,r.jsx)(u,{...t}),"CollectionProvider");
    a.displayName=t;
    let u=ep(e=>{
      let t=b();
      return(0,r.jsx)(d,{...e,state:t})
      },"CollectionInit");
    u.displayName=t+"Init";
    let d=ep(e=>{
      let{scope:t,children:i,state:o}=e,s=n.useRef(null),[a,c]=n.useState(null),u=y(s,c),[d,h]=o;
      return n.useEffect(()=>{
        if(!a)
        return;
        let e=ek(()=>{
          });
        return e.observe(a,{childList:!0,subtree:!0}),()=>{
          e.disconnect()
          }
        },[a]),(0,r.jsx)(l,{scope:t,itemMap:d,setItemMap:h,collectionRef:u,collectionRefObject:s,collectionElement:a,children:i})
      },"CollectionProviderImpl");
    d.displayName=t+"Impl";
    let h=e+"CollectionSlot",f=k(h),p=n.forwardRef((e,t)=>{
      let{scope:n,children:i}=e,o=y(t,s(h,n).collectionRef);
      return(0,r.jsx)(f,{ref:o,children:i})
      });
    p.displayName=h;
    let m=e+"CollectionItemSlot",g=k(m),v=n.forwardRef((e,t)=>{
      let{scope:i,children:o,...l}=e,a=n.useRef(null),[c,u]=n.useState(null),d=y(t,a,u),{setItemMap:h}=s(m,i),f=n.useRef(l);
      ey(f.current,l)||(f.current=l);
      let p=f.current;
      return n.useEffect(()=>(h(e=>c?e.has(c)?e.set(c,{...p,element:c}).toSorted(eE):(e.set(c,{...p,element:c}),e.toSorted(eE)):e),()=>{
        h(e=>c&&e.has(c)?(e.delete(c),new ev(e)):e)
        }),[c,p,h]),(0,r.jsx)(g,{"data-radix-collection-item":"",ref:d,children:o})
      });
    function b(){
      return n.useState(new ev)
      }
    function x(t){
      let{itemMap:r}=s(e+"CollectionConsumer",t);
      return r
      }
    return v.displayName=m,ep(b,"useInitCollection"),ep(x,"useCollection"),[{Provider:a,Slot:p,ItemSlot:v},{createCollectionScope:o,useCollection:x,useInitCollection:b}]
    },"createCollection"),ep(ey,"shallowEqual"),ep(eS,"isElementPreceding"),ep(eE,"sortByDocumentPosition"),ep(ek,"getChildListObserver"),(0,Object.defineProperty)(eN,"name",{value:"useCallbackRef",configurable:!0});
  var ej=Object.defineProperty,eC=(e,t)=>ej(e,"name",{value:t,configurable:!0}),eM="dismissableLayer.update",eR=n.createContext({layers:new Set,layersWithOutsidePointerEventsDisabled:new Set,branches:new Set,dismissableSurfaces:new Set}),eP=n.forwardRef(eC(function(e,i){
    let{disableOutsidePointerEvents:o=!1,deferPointerDownOutside:l=!1,onEscapeKeyDown:s,onPointerDownOutside:a,onFocusOutside:c,onInteractOutside:u,onDismiss:d,...h}=e,f=n.useContext(eR),[m,g]=n.useState(null),v=m?.ownerDocument??globalThis?.document,[,b]=n.useState({}),x=y(i,g),w=Array.from(f.layers),[S]=[...f.layersWithOutsidePointerEventsDisabled].slice(-1),E=S?w.indexOf(S):-1,k=m?w.indexOf(m):-1,N=f.layersWithOutsidePointerEventsDisabled.size>0,j=k>=E,C=n.useRef(!1),M=eO(e=>{
      a?.(e),u?.(e),e.defaultPrevented||d?.()
      },{ownerDocument:v,deferPointerDownOutside:l,isDeferredPointerDownOutsideRef:C,dismissableSurfaces:f.dismissableSurfaces,shouldHandlePointerDownOutside:n.useCallback(e=>{
      if(!(e instanceof Node))
      return!1;
      let t=[...f.branches].some(t=>t.contains(e));
      return j&&!t
      },[f.branches,j])}),R=eL(e=>{
      if(l&&C.current)
      return;
      let t=e.target;
      ![...f.branches].some(e=>e.contains(t))&&(c?.(e),u?.(e),e.defaultPrevented||d?.())
      },v),P=!!m&&k===w.length-1,T=eN(e=>{
      "Escape"===e.key&&(s?.(e),!e.defaultPrevented&&d&&(e.preventDefault(),d()))
      });
    return n.useEffect(()=>{
      if(P)
      return v.addEventListener("keydown",T,{capture:!0}),()=>v.removeEventListener("keydown",T,{capture:!0})
      },[v,P,T]),n.useEffect(()=>{
      if(m)
      return o&&(0===f.layersWithOutsidePointerEventsDisabled.size&&(t=v.body.style.pointerEvents,v.body.style.pointerEvents="none"),f.layersWithOutsidePointerEventsDisabled.add(m)),f.layers.add(m),eA(),()=>{
        o&&(f.layersWithOutsidePointerEventsDisabled.delete(m),0===f.layersWithOutsidePointerEventsDisabled.size&&(v.body.style.pointerEvents=t))
        }
      },[m,v,o,f]),n.useEffect(()=>()=>{
      m&&(f.layers.delete(m),f.layersWithOutsidePointerEventsDisabled.delete(m),eA())
      },[m,f]),n.useEffect(()=>{
      let e=eC(()=>b({}),"handleUpdate");
      return document.addEventListener(eM,e),()=>document.removeEventListener(eM,e)
      },[]),(0,r.jsx)(_.div,{...h,ref:x,style:{pointerEvents:N?j?"auto":"none":void 0,...e.style},onFocusCapture:p(e.onFocusCapture,R.onFocusCapture),onBlurCapture:p(e.onBlurCapture,R.onBlurCapture),onPointerDownCapture:p(e.onPointerDownCapture,M.onPointerDownCapture)})
    },"DismissableLayer"));
  eC(function(){
    let e=n.useContext(eR),[t,r]=n.useState(null);
    return n.useEffect(()=>{
      if(t)
      return e.dismissableSurfaces.add(t),()=>{
        e.dismissableSurfaces.delete(t)
        }
      },[t,e.dismissableSurfaces]),r
    },"useDismissableLayerSurface");
  var eT=eC(()=>!0,"IS_TRUE");
  function eO(e,t){
    let{ownerDocument:r=globalThis?.document,deferPointerDownOutside:i=!1,isDeferredPointerDownOutsideRef:o,dismissableSurfaces:l,shouldHandlePointerDownOutside:s=eT}=t,a=eN(e),c=n.useRef(!1),u=n.useRef(!1),d=n.useRef(new Map),h=n.useRef(()=>{
      });
    return n.useEffect(()=>{
      function e(){
        u.current=!1,o.current=!1,d.current.clear()
        }
      function t(){
        return Array.from(d.current.values()).some(Boolean)
        }
      function n(e){
        if(!u.current)
        return;
        let t=e.target;
        t instanceof Node&&[...l].some(e=>e.contains(t))||d.current.set(e.type,!0),"click"===e.type&&window.setTimeout(()=>{
          u.current&&h.current()
          },0)
        }
      function f(e){
        u.current&&d.current.set(e.type,!1)
        }
      eC(e,"resetOutsideInteraction"),eC(t,"isOutsideInteractionIntercepted"),eC(n,"handleInteractionCapture"),eC(f,"handleInteractionBubble");
      let p=eC(n=>{
        if(n.target&&!c.current){
          let l=function(){
            r.removeEventListener("click",h.current);
            let n=t();
            e(),n||eI("dismissableLayer.pointerDownOutside",a,f,{discrete:!0})
            };
          if(eC(l,"handleAndDispatchPointerDownOutsideEvent"),!s(n.target)){
            r.removeEventListener("click",h.current),e(),c.current=!1;
            return
            }
          let f={originalEvent:n};
          u.current=!0,o.current=i&&0===n.button,d.current.clear(),i&&0===n.button?(r.removeEventListener("click",h.current),h.current=l,r.addEventListener("click",h.current,{once:!0})):l()
          }else 
        r.removeEventListener("click",h.current),e();
        c.current=!1
        },"handlePointerDown"),m=["pointerup","mousedown","mouseup","touchstart","touchend","click"];
      for(
      let e
       of m)
      r.addEventListener(e,n,!0),r.addEventListener(e,f);
      let g=window.setTimeout(()=>{
        r.addEventListener("pointerdown",p)
        },0);
      return()=>{
        for(
        let e
         of(window.clearTimeout(g),r.removeEventListener("pointerdown",p),r.removeEventListener("click",h.current),m))
        r.removeEventListener(e,n,!0),r.removeEventListener(e,f)
        }
      },[r,a,i,o,l,s]),{onPointerDownCapture:eC(()=>c.current=!0,"onPointerDownCapture")}
    }
  function eL(e,t=globalThis?.document){
    let r=eN(e),i=n.useRef(!1);
    return n.useEffect(()=>{
      let e=eC(e=>{
        e.target&&!i.current&&eI("dismissableLayer.focusOutside",r,{originalEvent:e},{discrete:!1})
        },"handleFocus");
      return t.addEventListener("focusin",e),()=>t.removeEventListener("focusin",e)
      },[t,r]),{onFocusCapture:eC(()=>i.current=!0,"onFocusCapture"),onBlurCapture:eC(()=>i.current=!1,"onBlurCapture")}
    }
  function eA(){
    let e=new CustomEvent(eM);
    document.dispatchEvent(e)
    }
  function eI(e,t,r,{discrete:n}){
    let i=r.originalEvent.target,o=new CustomEvent(e,{bubbles:!1,cancelable:!0,detail:r});
    t&&i.addEventListener(e,t,{once:!0}),n?z(i,o):i.dispatchEvent(o)
    }
  function eD(e){
    let t=n.useRef({value:e,previous:e});
    return n.useMemo(()=>(t.current.value!==e&&(t.current.previous=t.current.value,t.current.value=e),t.current.previous),[e])
    }
  eC(eO,"usePointerDownOutside"),eC(eL,"useFocusOutside"),eC(eA,"dispatchUpdate"),eC(eI,"handleAndDispatchCustomEvent"),(0,Object.defineProperty)(eD,"name",{value:"usePrevious",configurable:!0});
  var e_=Object.defineProperty,ez=Object.freeze({position:"absolute",border:0,width:1,height:1,padding:0,margin:-1,overflow:"hidden",clip:"rect(0, 0, 0, 0)",whiteSpace:"nowrap",wordWrap:"normal"}),eF=n.forwardRef(e_(function(e,t){
    return(0,r.jsx)(_.span,{...e,ref:t,style:{...ez,...e.style}})
    },"name",{value:"VisuallyHidden",configurable:!0})),eW=Object.defineProperty,eH=(e,t)=>eW(e,"name",{value:t,configurable:!0}),e$="NavigationMenu",[eY,eU,eq]=em(e$),[eV,eB,eZ]=em(e$),[eK,eG]=c(e$,[eq,eZ]),[eX,eJ]=eK(e$),[eQ,e0]=eK(e$),e1=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:i,value:o,onValueChange:l,defaultValue:s,delayDuration:a=200,skipDelayDuration:c=300,orientation:u="horizontal",dir:d,...h}=e,[f,p]=n.useState(null),m=y(t,p),g=Q(d),v=n.useRef(0),b=n.useRef(0),x=n.useRef(0),[w,S]=n.useState(!0),[E,k]=B({prop:o,onChange:eH(e=>{
      let t=c>0;
      ""!==e?(window.clearTimeout(x.current),t&&S(!1)):(window.clearTimeout(x.current),x.current=window.setTimeout(()=>S(!0),c)),l?.(e)
      },"onChange"),defaultProp:s??"",caller:e$}),N=n.useCallback(()=>{
      window.clearTimeout(b.current),b.current=window.setTimeout(()=>k(""),150)
      },[k]),j=n.useCallback(e=>{
      window.clearTimeout(b.current),k(e)
      },[k]),C=n.useCallback(e=>{
      E===e?window.clearTimeout(b.current):v.current=window.setTimeout(()=>{
        window.clearTimeout(b.current),k(e)
        },a)
      },[E,k,a]);
    return n.useEffect(()=>()=>{
      window.clearTimeout(v.current),window.clearTimeout(b.current),window.clearTimeout(x.current)
      },[]),(0,r.jsx)(e2,{scope:i,isRootMenu:!0,value:E,dir:g,orientation:u,rootNavigationMenu:f,onTriggerEnter:e=>{
      window.clearTimeout(v.current),w?C(e):j(e)
      },onTriggerLeave:()=>{
      window.clearTimeout(v.current),N()
      },onContentEnter:()=>window.clearTimeout(b.current),onContentLeave:N,onItemSelect:e=>{
      k(t=>t===e?"":e)
      },onItemDismiss:()=>k(""),children:(0,r.jsx)(_.nav,{"aria-label":"Main","data-orientation":u,dir:g,...h,ref:m})})
    },"NavigationMenu")),e2=eH(e=>{
    let{scope:t,isRootMenu:i,rootNavigationMenu:o,dir:l,orientation:s,children:a,value:c,onItemSelect:u,onItemDismiss:d,onTriggerEnter:h,onTriggerLeave:f,onContentEnter:p,onContentLeave:m}=e,[g,v]=n.useState(null),[b,x]=n.useState(new Map),[w,y]=n.useState(null);
    return(0,r.jsx)(eX,{scope:t,isRootMenu:i,rootNavigationMenu:o,value:c,previousValue:eD(c),baseId:eh(),dir:l,orientation:s,viewport:g,onViewportChange:v,indicatorTrack:w,onIndicatorTrackChange:y,onTriggerEnter:eN(h),onTriggerLeave:eN(f),onContentEnter:eN(p),onContentLeave:eN(m),onItemSelect:eN(u),onItemDismiss:eN(d),onViewportContentChange:n.useCallback((e,t)=>{
      x(r=>(r.set(e,t),new Map(r)))
      },[]),onViewportContentRemove:n.useCallback(e=>{
      x(t=>t.has(e)?(t.delete(e),new Map(t)):t)
      },[]),children:(0,r.jsx)(eY.Provider,{scope:t,children:(0,r.jsx)(eQ,{scope:t,items:b,children:a})})})
    },"NavigationMenuProvider"),e5=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:n,...i}=e,o=eJ("NavigationMenuList",n),l=(0,r.jsx)(_.ul,{"data-orientation":o.orientation,...i,ref:t});
    return(0,r.jsx)(_.div,{style:{position:"relative"},ref:o.onIndicatorTrackChange,children:(0,r.jsx)(eY.Slot,{scope:n,children:o.isRootMenu?(0,r.jsx)(tl,{asChild:!0,children:l}):l})})
    },"NavigationMenuList")),[e4,e6]=eK("NavigationMenuItem"),e3=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:i,value:o,...l}=e,s=eh(),a=n.useRef(null),c=n.useRef(null),u=n.useRef(null),d=n.useRef(()=>{
      }),h=n.useRef(!1),f=n.useCallback((e="start")=>{
      if(a.current){
        d.current();
        let t=tc(a.current);
        t.length&&tu("start"===e?t:t.reverse())
        }
      },[]),p=n.useCallback(()=>{
      if(a.current){
        let e=tc(a.current);
        e.length&&(d.current=td(e))
        }
      },[]);
    return(0,r.jsx)(e4,{scope:i,value:o||s||"LEGACY_REACT_AUTO_VALUE",triggerRef:c,contentRef:a,focusProxyRef:u,wasEscapeCloseRef:h,onEntryKeyDown:f,onFocusProxyEnter:f,onRootContentClose:p,onContentFocusOutside:p,children:(0,r.jsx)(_.li,{...l,ref:t})})
    },"NavigationMenuItem")),e8="NavigationMenuTrigger",e9=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:i,disabled:o,...l}=e,s=eJ(e8,e.__scopeNavigationMenu),a=e6(e8,e.__scopeNavigationMenu),c=n.useRef(null),u=y(c,a.triggerRef,t),d=tf(s.baseId,a.value),h=tp(s.baseId,a.value),f=n.useRef(!1),m=n.useRef(!1),g=a.value===s.value;
    return(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(eY.ItemSlot,{scope:i,value:a.value,children:(0,r.jsx)(ta,{asChild:!0,children:(0,r.jsx)(_.button,{id:d,disabled:o,"data-disabled":o?"":void 0,"data-state":th(g),"aria-expanded":g,"aria-controls":g?h:void 0,...l,ref:u,onPointerEnter:p(e.onPointerEnter,()=>{
      m.current=!1,a.wasEscapeCloseRef.current=!1
      }),onPointerMove:p(e.onPointerMove,tm(()=>{
      o||m.current||a.wasEscapeCloseRef.current||f.current||(s.onTriggerEnter(a.value),f.current=!0)
      })),onPointerLeave:p(e.onPointerLeave,tm(()=>{
      o||(s.onTriggerLeave(),f.current=!1)
      })),onClick:p(e.onClick,()=>{
      s.onItemSelect(a.value),m.current=g
      }),onKeyDown:p(e.onKeyDown,e=>{
      let t={horizontal:"ArrowDown",vertical:"rtl"===s.dir?"ArrowLeft":"ArrowRight"}[s.orientation];
      g&&e.key===t&&(a.onEntryKeyDown(),e.preventDefault())
      })})})}),g&&(0,r.jsxs)(r.Fragment,{children:[(0,r.jsx)(eF,{"aria-hidden":!0,tabIndex:0,ref:a.focusProxyRef,onFocus:e=>{
      let t=a.contentRef.current,r=e.relatedTarget,n=r===c.current,i=t?.contains(r);
      (n||!i)&&a.onFocusProxyEnter(n?"start":"end")
      }}),s.viewport&&(0,r.jsx)("span",{"aria-owns":h})]})]})
    },"NavigationMenuTrigger")),e7="navigationMenu.linkSelect",te=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:n,active:i,onSelect:o,...l}=e;
    return(0,r.jsx)(ta,{asChild:!0,children:(0,r.jsx)(_.a,{"data-active":i?"":void 0,"aria-current":i?"page":void 0,...l,ref:t,onClick:p(e.onClick,e=>{
      let t=e.target,r=new CustomEvent(e7,{bubbles:!0,cancelable:!0});
      t.addEventListener(e7,e=>o?.(e),{once:!0}),z(t,r),r.defaultPrevented||e.metaKey||z(t,new CustomEvent(ti,{bubbles:!0,cancelable:!0}))
      },{checkForDefaultPrevented:!1})})})
    },"NavigationMenuLink")),tt="NavigationMenuContent",tr=n.forwardRef(eH(function(e,t){
    let{forceMount:n,...i}=e,o=eJ(tt,e.__scopeNavigationMenu),l=e6(tt,e.__scopeNavigationMenu),s=y(l.contentRef,t),a=l.value===o.value,c={value:l.value,triggerRef:l.triggerRef,focusProxyRef:l.focusProxyRef,wasEscapeCloseRef:l.wasEscapeCloseRef,onContentFocusOutside:l.onContentFocusOutside,onRootContentClose:l.onRootContentClose,...i};
    return o.viewport?(0,r.jsx)(tn,{forceMount:n,...c,ref:s}):(0,r.jsx)(en,{present:n||a,children:(0,r.jsx)(to,{"data-state":th(a),...c,ref:s,onPointerEnter:p(e.onPointerEnter,o.onContentEnter),onPointerLeave:p(e.onPointerLeave,tm(o.onContentLeave)),style:{pointerEvents:!a&&o.isRootMenu?"none":void 0,...c.style}})})
    },"NavigationMenuContent")),tn=n.forwardRef(eH(function(e,t){
    let{onViewportContentChange:r,onViewportContentRemove:n}=eJ(tt,e.__scopeNavigationMenu);
    return F(()=>{
      r(e.value,{ref:t,...e})
      },[e,t,r]),F(()=>()=>n(e.value),[e.value,n]),null
    },"ViewportContentMounter")),ti="navigationMenu.rootContentDismiss",to=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:i,value:o,triggerRef:l,focusProxyRef:s,wasEscapeCloseRef:a,onRootContentClose:c,onContentFocusOutside:u,...d}=e,h=eJ(tt,i),f=n.useRef(null),m=y(f,t),g=tf(h.baseId,o),v=tp(h.baseId,o),b=eU(i),x=n.useRef(null),{onItemDismiss:w}=h;
    n.useEffect(()=>{
      let e=f.current;
      if(h.isRootMenu&&e){
        let t=eH(()=>{
          w(),c(),e.contains(document.activeElement)&&l.current?.focus()
          },"handleClose");
        return e.addEventListener(ti,t),()=>e.removeEventListener(ti,t)
        }
      },[h.isRootMenu,e.value,l,w,c]);
    let S=n.useMemo(()=>{
      let e=b().map(e=>e.value);
      "rtl"===h.dir&&e.reverse();
      let t=e.indexOf(h.value),r=e.indexOf(h.previousValue),n=o===h.value,i=r===e.indexOf(o);
      if(!n&&!i)
      return x.current;
      let l=(()=>{
        if(t!==r){
          if(n&&-1!==r)
          return t>r?"from-end":"from-start";
          if(i&&-1!==t)
          return t>r?"to-start":"to-end"
          }
        return null
        })();
      return x.current=l,l
      },[h.previousValue,h.value,h.dir,b,o]);
    return(0,r.jsx)(tl,{asChild:!0,children:(0,r.jsx)(eP,{id:v,"aria-labelledby":g,"data-motion":S,"data-orientation":h.orientation,...d,ref:m,disableOutsidePointerEvents:!1,onDismiss:()=>{
      let e=new Event(ti,{bubbles:!0,cancelable:!0});
      f.current?.dispatchEvent(e)
      },onFocusOutside:p(e.onFocusOutside,e=>{
      u();
      let t=e.target;
      h.rootNavigationMenu?.contains(t)&&e.preventDefault()
      }),onPointerDownOutside:p(e.onPointerDownOutside,e=>{
      let t=e.target,r=b().some(e=>e.ref.current?.contains(t)),n=h.isRootMenu&&h.viewport?.contains(t);
      (r||n||!h.isRootMenu)&&e.preventDefault()
      }),onKeyDown:p(e.onKeyDown,e=>{
      let t=e.altKey||e.ctrlKey||e.metaKey;
      if("Tab"===e.key&&!t){
        let t=tc(e.currentTarget),r=document.activeElement,n=t.findIndex(e=>e===r);
        tu(e.shiftKey?t.slice(0,n).reverse():t.slice(n+1,t.length))?e.preventDefault():s.current?.focus()
        }
      }),onEscapeKeyDown:p(e.onEscapeKeyDown,e=>{
      a.current=!0
      })})})
    },"NavigationMenuContentImpl"));
  ({contentRef:e,isActive:t,onActiveContentChange:i,...o})=>{
    let l=y(e,n.useCallback(e=>{
      t&&e&&i(e)
      },[t,i]));
    return(0,r.jsx)(to,{...o,ref:l})
    };
  var tl=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:n,...i}=e,o=eJ("FocusGroup",n);
    return(0,r.jsx)(eV.Provider,{scope:n,children:(0,r.jsx)(eV.Slot,{scope:n,children:(0,r.jsx)(_.div,{dir:o.dir,...i,ref:t})})})
    },"FocusGroup")),ts=["ArrowRight","ArrowLeft","ArrowUp","ArrowDown"],ta=n.forwardRef(eH(function(e,t){
    let{__scopeNavigationMenu:n,...i}=e,o=eB(n),l=eJ("FocusGroupItem",n);
    return(0,r.jsx)(eV.ItemSlot,{scope:n,children:(0,r.jsx)(_.button,{...i,ref:t,onKeyDown:p(e.onKeyDown,e=>{
      if(["Home","End",...ts].includes(e.key)){
        let t=o().map(e=>e.ref.current);
        if(["rtl"===l.dir?"ArrowRight":"ArrowLeft","ArrowUp","End"].includes(e.key)&&t.reverse(),ts.includes(e.key)){
          let r=t.indexOf(e.currentTarget);
          t=t.slice(r+1)
          }
        setTimeout(()=>tu(t)),e.preventDefault()
        }
      })})})
    },"FocusGroupItem"));
  function tc(e){
    let t=[],r=document.createTreeWalker(e,NodeFilter.SHOW_ELEMENT,{acceptNode:eH(e=>{
      let t="INPUT"===e.tagName&&"hidden"===e.type;
      return e.disabled||e.hidden||t?NodeFilter.FILTER_SKIP:e.tabIndex>=0?NodeFilter.FILTER_ACCEPT:NodeFilter.FILTER_SKIP
      },"acceptNode")});
    for(;r.nextNode();)
    t.push(r.currentNode);
    return t
    }
  function tu(e){
    let t=document.activeElement;
    return e.some(e=>e===t||(e.focus(),document.activeElement!==t))
    }
  function td(e){
    return e.forEach(e=>{
      e.dataset.tabindex=e.getAttribute("tabindex")||"",e.setAttribute("tabindex","-1")
      }),()=>{
      e.forEach(e=>{
        let t=e.dataset.tabindex;
        e.setAttribute("tabindex",t)
        })
      }
    }
  function th(e){
    return e?"open":"closed"
    }
  function tf(e,t){
    return`${e}-trigger-${t}`
    }
  function tp(e,t){
    return`${e}-content-${t}`
    }
  function tm(e){
    return t=>"mouse"===t.pointerType?e(t):void 0
    }
  eH(tc,"getTabbableCandidates"),eH(tu,"focusFirst"),eH(td,"removeFromTabOrder"),eH(function(e,t){
    let r=eN(t);
    F(()=>{
      let t=0;
      if(e){
        let n=new ResizeObserver(()=>{
          cancelAnimationFrame(t),t=window.requestAnimationFrame(r)
          });
        return n.observe(e),()=>{
          window.cancelAnimationFrame(t),n.unobserve(e)
          }
        }
      },[e,r])
    },"useResizeObserver"),eH(th,"getOpenState"),eH(tf,"makeTriggerId"),eH(tp,"makeContentId"),eH(tm,"whenMouse");
  var tg=e.i(3636),tv=e.i(56420);
  let tb=(0,tv.default)("menu",[["path",{d:"M4 5h16",key:"1tepv9"}],["path",{d:"M4 12h16",key:"1lakjw"}],["path",{d:"M4 19h16",key:"1djgab"}]]);
  var tx=e.i(60964),tw=e.i(19056),ty=e.i(12637),tS=e.i(8164);
  e.i(16787);
  var tE=e.i(19455);
  let tk=(0,tv.default)("moon",[["path",{d:"M20.985 12.486a9 9 0 1 1-9.473-9.472c.405-.022.617.46.402.803a6 6 0 0 0 8.268 8.268c.344-.215.825-.004.803.401",key:"kfwtm"}]]),tN=(0,tv.default)("sun",[["circle",{cx:"12",cy:"12",r:"4",key:"4exip2"}],["path",{d:"M12 2v2",key:"tus03m"}],["path",{d:"M12 20v2",key:"1lh1kg"}],["path",{d:"m4.93 4.93 1.41 1.41",key:"149t6j"}],["path",{d:"m17.66 17.66 1.41 1.41",key:"ptbguv"}],["path",{d:"M2 12h2",key:"1t8f8n"}],["path",{d:"M20 12h2",key:"1q8mjw"}],["path",{d:"m6.34 17.66-1.41 1.41",key:"1m8zz5"}],["path",{d:"m19.07 4.93-1.41 1.41",key:"1shlcs"}]]),tj=0;
  function tC(){
    let e=document.documentElement.getAttribute("data-theme");
    return"light"===e||"dark"===e?e:window.matchMedia("(prefers-color-scheme: dark)").matches?"dark":"light"
    }
  function tM({className:e}){
    let[t,i]=(0,n.useState)(null);
    return(0,n.useEffect)(()=>{
      i(tC())
      },[]),(0,r.jsx)("button",{type:"button",onClick:()=>{
      let e="dark"===tC()?"light":"dark",t=document.documentElement;
      t.classList.add("theme-anim"),window.clearTimeout(tj),tj=window.setTimeout(()=>t.classList.remove("theme-anim"),450),t.offsetWidth,t.setAttribute("data-theme",e);
      try{
        localStorage.setItem("artcraft-theme",e)
        }catch{
        }
      i(e)
      },"aria-label":"dark"===t?"Switch to light theme":"Switch to dark theme",className:`invert-block flex items-center justify-center text-muted hover:text-invert-fg ${e??""}`,children:"dark"===t?(0,r.jsx)(tN,{"aria-hidden":!0,className:"h-4 w-4"}):(0,r.jsx)(tk,{"aria-hidden":!0,className:"h-4 w-4"})})
    }
  let tR=[{name:"Home",href:"/"},{name:"Image",href:(0,ty.webappUrl)("/create-image")},{name:"Video",href:(0,ty.webappUrl)("/create-video")},{name:"Resources",children:[{name:"Tutorials",href:"/tutorials"},{name:"News",href:"/news"},{name:"FAQ",href:"/faq"},{name:"Press Kit",href:"/press-kit"}]},{name:"Download",href:"/download"},{name:"Support",href:"/support"},{name:"Craft Apps",href:"/apps",dividerBefore:!0}],tP="group flex h-full items-center px-2.5 hud-label whitespace-nowrap",tT="flex items-center gap-1.5 px-1.5 py-0.5 group-hover:bg-invert-bg group-hover:text-invert-fg",tO="bg-invert-bg text-invert-fg",tL="group flex px-3 py-2.5 hud-label whitespace-nowrap";
  function tA(e){
    return"children"in e&&Array.isArray(e.children)
    }
  function tI(e,t){
    return!/^https?:\/\//.test(t)&&("/"===t?"/"===e:e===t||e.startsWith(t+"/"))
    }
  e.s(["default",0,function(){
    let e=(0,o.usePathname)(),[t,l]=(0,n.useState)(!1);
    return(0,r.jsxs)("nav",{id:"site-nav",className:"sticky top-0 left-0 z-50 w-full border-b border-line bg-bg/95 backdrop-blur-sm",children:[(0,r.jsxs)("div",{className:"flex h-12 items-stretch justify-between",children:[(0,r.jsxs)("div",{className:"flex min-w-0 items-stretch",children:[(0,r.jsx)(i.default,{href:"/",className:"flex items-center border-r border-line px-4 hover:opacity-70 sm:px-5",children:(0,r.jsx)("img",{alt:"ArtCraft",src:"/artcraft-icon.svg",className:"themed-logo h-6 w-auto"})}),(0,r.jsx)(e1,{delayDuration:120,className:"hidden min-w-0 items-stretch lg:flex",children:(0,r.jsx)(e5,{className:"flex h-full items-stretch",children:tR.map(t=>{
      var n,o;
      let l=(n=e,tA(o=t)?!!(o.href&&tI(n,o.href))||o.children.some(e=>tI(n,e.href)):tI(n,o.href)),s=(0,tw.twMerge)(tP,l?"text-ink":"text-muted hover:text-ink"),a=(0,tw.twMerge)(tT,l&&tO);
      if(!tA(t)){
        let e;
        return(0,r.jsx)(e3,{className:(0,tw.twMerge)("flex items-stretch",t.dividerBefore&&"ml-1.5 border-l border-line pl-1.5"),children:(0,r.jsx)(te,{asChild:!0,children:(e=t.href,/^https?:\/\//.test(e))?(0,r.jsx)("a",{href:t.href,className:s,children:(0,r.jsx)("span",{className:a,children:t.name})}):(0,r.jsx)(i.default,{href:t.href,"aria-current":l?"page":void 0,className:s,children:(0,r.jsx)("span",{className:a,children:t.name})})})},t.name)
        }
      return(0,r.jsxs)(e3,{className:"relative flex items-stretch",children:[(0,r.jsx)(e9,{className:(0,tw.twMerge)(s,"focus:outline-none"),children:(0,r.jsxs)("span",{className:a,children:[t.name,(0,r.jsx)(tg.ChevronDownIcon,{"aria-hidden":!0,className:"h-3 w-3 group-data-[state=open]:rotate-180"})]})}),(0,r.jsx)(tr,{className:"absolute top-full left-0 border border-t-0 border-line bg-bg",children:(0,r.jsx)("ul",{className:"flex min-w-[200px] flex-col",children:t.children.map(t=>{
        let n=tI(e,t.href);
        return(0,r.jsx)("li",{children:(0,r.jsx)(te,{asChild:!0,children:(0,r.jsx)(i.default,{href:t.href,"aria-current":n?"page":void 0,className:(0,tw.twMerge)(tL,n?"text-ink":"text-muted hover:text-ink"),children:(0,r.jsx)("span",{className:(0,tw.twMerge)(tT,n&&tO),children:t.name})})})},t.name)
        })})})]},t.name)
      })})})]}),(0,r.jsxs)("div",{className:"flex shrink-0 items-stretch",children:[(0,r.jsxs)("div",{className:"hidden items-stretch md:flex",children:[(0,r.jsx)(i.default,{href:"/pricing",className:(0,tw.twMerge)(tP,"text-muted hover:text-ink"),children:(0,r.jsx)("span",{className:tT,children:"Pricing"})}),(0,r.jsx)("a",{href:ty.SOCIAL_LINKS.DISCORD,target:"_blank",rel:"noopener noreferrer","aria-label":"Join the ArtCraft Discord",title:"Join the ArtCraft Discord",className:"flex w-12 items-center justify-center border-l border-line text-muted hover:bg-invert-bg hover:text-invert-fg",children:(0,r.jsx)(tS.DiscordIcon,{className:"h-4 w-4"})}),(0,r.jsx)(tM,{className:"w-12 border-l border-line"}),(0,r.jsx)(tE.Button,{href:ty.WEBAPP_URL,className:"h-full border-l border-line px-5",children:"Launch App"})]}),(0,r.jsx)("div",{className:"flex items-stretch md:hidden",children:(0,r.jsx)(tM,{className:"w-12 border-l border-line"})}),(0,r.jsx)("div",{className:"flex items-stretch lg:hidden",children:(0,r.jsxs)("button",{type:"button",onClick:()=>l(e=>!e),"aria-expanded":t,"aria-controls":"mobile-nav",className:"flex w-12 items-center justify-center border-l border-line text-muted hover:bg-invert-bg hover:text-invert-fg",children:[(0,r.jsx)("span",{className:"sr-only",children:t?"Close main menu":"Open main menu"}),t?(0,r.jsx)(tx.XIcon,{"aria-hidden":!0,className:"h-5 w-5"}):(0,r.jsx)(tb,{"aria-hidden":!0,className:"h-5 w-5"})]})})]})]}),t&&(0,r.jsxs)("div",{id:"mobile-nav",className:"border-t border-line lg:hidden",children:[(0,r.jsx)("div",{className:"flex flex-col",children:tR.map(t=>{
      if(!tA(t)){
        let n,o=tI(e,t.href),s=(0,tw.twMerge)(tL,"py-3",t.dividerBefore&&"border-t border-line",o?"text-ink":"text-muted active:text-ink"),a=(0,r.jsx)("span",{className:(0,tw.twMerge)("flex items-center px-1.5 py-0.5",o&&tO),children:t.name});
        return(n=t.href,/^https?:\/\//.test(n))?(0,r.jsx)("a",{href:t.href,className:s,children:a},t.name):(0,r.jsx)(i.default,{href:t.href,onClick:()=>l(!1),className:s,children:a},t.name)
        }
      return(0,r.jsxs)("div",{className:"flex flex-col",children:[(0,r.jsx)("div",{className:"hud-label px-4 pt-3 pb-1 text-[10px] font-semibold tracking-[0.25em] text-faint",children:t.name}),(0,r.jsx)("div",{className:"flex flex-col",children:t.children.map(t=>{
        let n=tI(e,t.href);
        return(0,r.jsx)(i.default,{href:t.href,onClick:()=>l(!1),className:(0,tw.twMerge)(tL,"py-3 pl-8",n?"text-ink":"text-muted active:text-ink"),children:(0,r.jsx)("span",{className:(0,tw.twMerge)("flex items-center px-1.5 py-0.5",n&&tO),children:t.name})},t.name)
        })})]},t.name)
      })}),(0,r.jsx)("div",{className:"border-t border-line"}),(0,r.jsx)(tE.Button,{href:ty.WEBAPP_URL,className:"h-11 w-full active:opacity-80",children:"Launch App"}),(0,r.jsxs)("div",{className:"flex items-stretch border-t border-line",children:[(0,r.jsx)(i.default,{href:"/pricing",onClick:()=>l(!1),className:"hud-label flex h-10 flex-1 items-center justify-center gap-1.5 border-r border-line text-[11px] text-muted active:bg-invert-bg active:text-invert-fg",children:"Pricing"}),(0,r.jsx)("a",{href:ty.SOCIAL_LINKS.DISCORD,target:"_blank",rel:"noopener noreferrer",className:"hud-label flex h-10 flex-1 items-center justify-center gap-1.5 text-[11px] text-muted active:bg-invert-bg active:text-invert-fg",children:"Discord"})]})]})]})
    }],55068)
  },48185,e=>{
  "use strict";
  var t=e.i(71645),r=e.i(89970),n=e.i(91672);
  e.s(["default",0,function(){
    return(0,t.useEffect)(()=>{
      if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){
        n.introClock.t=999,n.introClock.done=!0;
        return
        }
      let e=n.introTuner.read(),t=!1;
      try{
        t="1"===localStorage.getItem(n.INTRO_SEEN_KEY)
        }catch{
        }
      n.introClock.t=0,n.introClock.done=!1,n.introClock.scale=t?e.returnScale:1;
      let i=r.default.utils.toArray("#site-nav > div > *"),o=null,l=()=>{
        i.length&&(o?.kill(),r.default.set(i,{autoAlpha:0,y:-6}),(o=r.default.timeline()).to({},{duration:n.introTuner.read().instrAt}),o.to(i,{autoAlpha:1,y:0,duration:.5,stagger:.08,ease:"power2.out",clearProps:"all"}),o.timeScale(n.introClock.scale))
        };
      l();
      let s=()=>{
        (0,n.introFastForward)(),o?.timeScale(n.introTuner.read().ffScale)
        },a=()=>{
        window.addEventListener("wheel",s,{passive:!0}),window.addEventListener("pointerdown",s,{passive:!0}),window.addEventListener("keydown",s),window.addEventListener("touchstart",s,{passive:!0})
        },c=()=>{
        window.removeEventListener("wheel",s),window.removeEventListener("pointerdown",s),window.removeEventListener("keydown",s),window.removeEventListener("touchstart",s)
        };
      a();
      let u=(0,n.onIntroReplay)(()=>{
        c(),a(),l()
        }),d=(e,t)=>{
        if(n.introClock.t+=Math.min(t,100)/1e3*n.introClock.scale,!n.introClock.done&&n.introClock.t>n.introTuner.read().cardsAt+3){
          n.introClock.done=!0,document.documentElement.removeAttribute("data-intro");
          try{
            localStorage.setItem(n.INTRO_SEEN_KEY,"1")
            }catch{
            }
          c()
          }
        };
      return r.default.ticker.add(d),()=>{
        r.default.ticker.remove(d),u(),c(),o?.kill(),i.length&&r.default.set(i,{clearProps:"all"}),n.introClock.t=999
        }
      },[]),null
    }])
  },47311,e=>{
  "use strict";
  e.s(["default",0,function(){
    return null
    }])
  },8341,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0});
  var n={cancelIdleCallback:function(){
    return l
    },requestIdleCallback:function(){
    return o
    }};
  for(
  var i
   in n)
  Object.defineProperty(r,i,{enumerable:!0,get:n[i]});
  let o="u">typeof self&&self.requestIdleCallback&&self.requestIdleCallback.bind(window)||function(e){
    let t=Date.now();
    return self.setTimeout(function(){
      e({didTimeout:!1,timeRemaining:function(){
        return Math.max(0,50-(Date.now()-t))
        }})
      },1)
    },l="u">typeof self&&self.cancelIdleCallback&&self.cancelIdleCallback.bind(window)||function(e){
    return clearTimeout(e)
    };
  ("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)
  },19083,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0});
  var n={ESCAPE_REGEX:function(){
    return l
    },htmlEscapeAttributeString:function(){
    return u
    },htmlEscapeJsonString:function(){
    return c
    }};
  for(
  var i
   in n)
  Object.defineProperty(r,i,{enumerable:!0,get:n[i]});
  let o={"&":"\\u0026",">":"\\u003e","<":"\\u003c","\u2028":"\\u2028","\u2029":"\\u2029"},l=/[&><\u2028\u2029]/g,s={"&":"&amp;",'"':"&quot;","'":"&#39;","<":"&lt;",">":"&gt;"},a=/[&"'<>]/g;
  function c(e){
    return e.replace(l,e=>o[e])
    }
  function u(e){
    return e.replace(a,e=>s[e])
    }
  },79520,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0});
  var n={default:function(){
    return w
    },handleClientScriptLoad:function(){
    return v
    },initScriptLoader:function(){
    return b
    }};
  for(
  var i
   in n)
  Object.defineProperty(r,i,{enumerable:!0,get:n[i]});
  let o=e.r(55682),l=e.r(90809),s=e.r(43476),a=o._(e.r(74080)),c=l._(e.r(71645)),u=e.r(42732),d=e.r(22737),h=e.r(8341),f=e.r(19083),p=new Map,m=new Set,g=e=>{
    let{src:t,id:r,onLoad:n=()=>{
      },onReady:i=null,dangerouslySetInnerHTML:o,children:l="",strategy:s="afterInteractive",onError:c,stylesheets:u}=e,h=r||t;
    if(h&&m.has(h))
    return;
    if(p.has(t)){
      m.add(h),p.get(t).then(n,c);
      return
      }
    let f=()=>{
      i&&i(),m.add(h)
      },g=document.createElement("script"),v=new Promise((e,t)=>{
      g.addEventListener("load",function(t){
        e(),n&&n.call(this,t),f()
        }),g.addEventListener("error",function(e){
        t(e)
        })
      }).catch(function(e){
      c&&c(e)
      });
    o?(g.innerHTML=o.__html||"",f()):l?(g.textContent="string"==typeof l?l:Array.isArray(l)?l.join(""):"",f()):t&&(g.src=t,p.set(t,v)),(0,d.setAttributesFromProps)(g,e),"worker"===s&&g.setAttribute("type","text/partytown"),g.setAttribute("data-nscript",s),u&&(e=>{
      if(a.default.preinit)
      return e.forEach(e=>{
        a.default.preinit(e,{as:"style"})
        });
      if("u">typeof window){
        let t=document.head;
        e.forEach(e=>{
          let r=document.createElement("link");
          r.type="text/css",r.rel="stylesheet",r.href=e,t.appendChild(r)
          })
        }
      })(u),document.body.appendChild(g)
    };
  function v(e){
    let{strategy:t="afterInteractive"}=e;
    "lazyOnload"===t?window.addEventListener("load",()=>{
      (0,h.requestIdleCallback)(()=>g(e))
      }):g(e)
    }
  function b(e){
    e.forEach(v),[...document.querySelectorAll('[data-nscript="beforeInteractive"]'),...document.querySelectorAll('[data-nscript="beforePageRender"]')].forEach(e=>{
      let t=e.id||e.getAttribute("src");
      m.add(t)
      })
    }
  function x(e){
    let{id:t,src:r="",onLoad:n=()=>{
      },onReady:i=null,strategy:o="afterInteractive",onError:l,stylesheets:d,...p}=e,{updateScripts:v,scripts:b,getIsSsr:x,appDir:w,nonce:y}=(0,c.useContext)(u.HeadManagerContext);
    y=p.nonce||y;
    let S=(0,c.useRef)(!1);
    (0,c.useEffect)(()=>{
      let e=t||r;
      S.current||(i&&e&&m.has(e)&&i(),S.current=!0)
      },[i,t,r]);
    let E=(0,c.useRef)(!1);
    if((0,c.useEffect)(()=>{
      if(!E.current){
        if("afterInteractive"===o)
        g(e);
        else
        "lazyOnload"===o&&("complete"===document.readyState?(0,h.requestIdleCallback)(()=>g(e)):window.addEventListener("load",()=>{
          (0,h.requestIdleCallback)(()=>g(e))
          }));
        E.current=!0
        }
      },[e,o]),("beforeInteractive"===o||"worker"===o)&&(v?(b[o]=(b[o]||[]).concat([{id:t,src:r,onLoad:n,onReady:i,onError:l,...p,nonce:y}]),v(b)):x&&x()?m.add(t||r):x&&!x()&&g({...e,nonce:y})),w){
      if(d&&d.forEach(e=>{
        a.default.preinit(e,{as:"style"})
        }),"beforeInteractive"===o)
      if(!r)
      return p.dangerouslySetInnerHTML&&(p.children=p.dangerouslySetInnerHTML.__html,delete p.dangerouslySetInnerHTML),(0,s.jsx)("script",{nonce:y,dangerouslySetInnerHTML:{__html:`(self.__next_s=self.__next_s||[]).push(${(0,f.htmlEscapeJsonString)(JSON.stringify([0,{...p,id:t}]))})`}});
      else 
      return a.default.preload(r,p.integrity?{as:"script",integrity:p.integrity,nonce:y,crossOrigin:p.crossOrigin}:{as:"script",nonce:y,crossOrigin:p.crossOrigin}),(0,s.jsx)("script",{nonce:y,dangerouslySetInnerHTML:{__html:`(self.__next_s=self.__next_s||[]).push(${(0,f.htmlEscapeJsonString)(JSON.stringify([r,{...p,id:t}]))})`}});
      "afterInteractive"===o&&r&&a.default.preload(r,p.integrity?{as:"script",integrity:p.integrity,nonce:y,crossOrigin:p.crossOrigin}:{as:"script",nonce:y,crossOrigin:p.crossOrigin})
      }
    return null
    }
  Object.defineProperty(x,"__nextScript",{value:!0});
  let w=x;
  ("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)
  },3303,(e,t,r)=>{
  t.exports=e.r(79520)
  },97287,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645),n=e.i(3303),i=e.i(75679);
  e.s(["default",0,function(){
    return((0,r.useEffect)(()=>{
      if(!i.GA_MEASUREMENT_ID)
      return;
      let e=e=>{
        ("auxclick"!==e.type||1===e.button)&&(0,i.trackClick)(e.target)
        };
      return document.addEventListener("click",e,!0),document.addEventListener("auxclick",e,!0),()=>{
        document.removeEventListener("click",e,!0),document.removeEventListener("auxclick",e,!0)
        }
      },[]),i.GA_MEASUREMENT_ID)?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsx)(n.default,{src:`https://www.googletagmanager.com/gtag/js?id=${i.GA_MEASUREMENT_ID}`,strategy:"afterInteractive"}),(0,t.jsx)(n.default,{id:"ga-init",strategy:"afterInteractive",children:`window.dataLayer=window.dataLayer||[];window.gtag=function(){dataLayer.push(arguments);};gtag("js",new Date());gtag("config",${JSON.stringify(i.GA_MEASUREMENT_ID)});`})]}):null
    }])
  },41253,e=>{
  "use strict";
  e.s(["lenisRef",0,{current:null}])
  },38685,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645),n=e.i(18566),i="1.3.23";
  function o(e,t,r){
    return Math.max(e,Math.min(t,r))
    }
  var l=class{
    isRunning=!1;value=0;from=0;to=0;currentTime=0;lerp;duration;easing;onUpdate;advance(e){
      if(!this.isRunning)
      return;
      let t=!1;
      if(this.duration&&this.easing){
        this.currentTime+=e;
        let r=o(0,this.currentTime/this.duration,1),n=(t=r>=1)?1:this.easing(r);
        this.value=this.from+(this.to-this.from)*n
        }else 
      if(this.lerp){
        var r,n,i,l;
        this.value=(r=this.value,n=this.to,i=60*this.lerp,(1-(l=1-Math.exp(-i*e)))*r+l*n),Math.round(this.value)===Math.round(this.to)&&(this.value=this.to,t=!0)
        }else 
      this.value=this.to,t=!0;
      t&&this.stop(),this.onUpdate?.(this.value,t)
      }stop(){
      this.isRunning=!1
      }fromTo(e,t,{lerp:r,duration:n,easing:i,onStart:o,onUpdate:l}){
      this.from=this.value=e,this.to=t,this.lerp=r,this.duration=n,this.easing=i,this.currentTime=0,this.isRunning=!0,o?.(),this.onUpdate=l
      }
  },s=class{
    width=0;height=0;scrollHeight=0;scrollWidth=0;debouncedResize;wrapperResizeObserver;contentResizeObserver;constructor(e,t,{autoResize:r=!0,debounce:n=250}={}){
      this.wrapper=e,this.content=t,r&&(this.debouncedResize=function(e,t){
        let r;
        return function(...n){
          clearTimeout(r),r=setTimeout(()=>{
            r=void 0,e.apply(this,n)
            },t)
          }
        }(this.resize,n),this.wrapper instanceof Window?window.addEventListener("resize",this.debouncedResize):(this.wrapperResizeObserver=new ResizeObserver(this.debouncedResize),this.wrapperResizeObserver.observe(this.wrapper)),this.contentResizeObserver=new ResizeObserver(this.debouncedResize),this.contentResizeObserver.observe(this.content)),this.resize()
      }destroy(){
      this.wrapperResizeObserver?.disconnect(),this.contentResizeObserver?.disconnect(),this.wrapper===window&&this.debouncedResize&&window.removeEventListener("resize",this.debouncedResize)
      }resize=()=>{
      this.onWrapperResize(),this.onContentResize()
      };onWrapperResize=()=>{
      this.wrapper instanceof Window?(this.width=window.innerWidth,this.height=window.innerHeight):(this.width=this.wrapper.clientWidth,this.height=this.wrapper.clientHeight)
      };onContentResize=()=>{
      this.wrapper instanceof Window?(this.scrollHeight=this.content.scrollHeight,this.scrollWidth=this.content.scrollWidth):(this.scrollHeight=this.wrapper.scrollHeight,this.scrollWidth=this.wrapper.scrollWidth)
      };get limit(){
      return{x:this.scrollWidth-this.width,y:this.scrollHeight-this.height}
      }
  },a=class{
    events={};emit(e,...t){
      let r=this.events[e]||[];
      for(
      let e=0,n=r.length
      ;e<n;e++)
      r[e]?.(...t)
      }on(e,t){
      return this.events[e]?this.events[e].push(t):this.events[e]=[t],()=>{
        this.events[e]=this.events[e]?.filter(e=>t!==e)
        }
      }off(e,t){
      this.events[e]=this.events[e]?.filter(e=>t!==e)
      }destroy(){
      this.events={}
      }
  };
  let c=100/6,u={passive:!1};
  function d(e,t){
    return 1===e?c:2===e?t:1
    }
  var h=class{
    touchStart={x:0,y:0};lastDelta={x:0,y:0};window={width:0,height:0};emitter=new a;constructor(e,t={wheelMultiplier:1,touchMultiplier:1}){
      this.element=e,this.options=t,window.addEventListener("resize",this.onWindowResize),this.onWindowResize(),this.element.addEventListener("wheel",this.onWheel,u),this.element.addEventListener("touchstart",this.onTouchStart,u),this.element.addEventListener("touchmove",this.onTouchMove,u),this.element.addEventListener("touchend",this.onTouchEnd,u)
      }on(e,t){
      return this.emitter.on(e,t)
      }destroy(){
      this.emitter.destroy(),window.removeEventListener("resize",this.onWindowResize),this.element.removeEventListener("wheel",this.onWheel,u),this.element.removeEventListener("touchstart",this.onTouchStart,u),this.element.removeEventListener("touchmove",this.onTouchMove,u),this.element.removeEventListener("touchend",this.onTouchEnd,u)
      }onTouchStart=e=>{
      let{clientX:t,clientY:r}=e.targetTouches?e.targetTouches[0]:e;
      this.touchStart.x=t,this.touchStart.y=r,this.lastDelta={x:0,y:0},this.emitter.emit("scroll",{deltaX:0,deltaY:0,event:e})
      };onTouchMove=e=>{
      let{clientX:t,clientY:r}=e.targetTouches?e.targetTouches[0]:e,n=-(t-this.touchStart.x)*this.options.touchMultiplier,i=-(r-this.touchStart.y)*this.options.touchMultiplier;
      this.touchStart.x=t,this.touchStart.y=r,this.lastDelta={x:n,y:i},this.emitter.emit("scroll",{deltaX:n,deltaY:i,event:e})
      };onTouchEnd=e=>{
      this.emitter.emit("scroll",{deltaX:this.lastDelta.x,deltaY:this.lastDelta.y,event:e})
      };onWheel=e=>{
      let{deltaX:t,deltaY:r,deltaMode:n}=e,i=d(n,this.window.width),o=d(n,this.window.height);
      t*=i,r*=o,t*=this.options.wheelMultiplier,r*=this.options.wheelMultiplier,this.emitter.emit("scroll",{deltaX:t,deltaY:r,event:e})
      };onWindowResize=()=>{
      this.window={width:window.innerWidth,height:window.innerHeight}
      }
  };
  let f=e=>Math.min(1,1.001-2**(-10*e));
  var p=class{
    _isScrolling=!1;_isStopped=!1;_isLocked=!1;_preventNextNativeScrollEvent=!1;_resetVelocityTimeout=null;_rafId=null;isTouching;time=0;userData={};lastVelocity=0;velocity=0;direction=0;options;targetScroll;animatedScroll;animate=new l;emitter=new a;dimensions;virtualScroll;constructor({wrapper:e=window,content:t=document.documentElement,eventsTarget:r=e,smoothWheel:n=!0,syncTouch:o=!1,syncTouchLerp:l=.075,touchInertiaExponent:a=1.7,duration:c,easing:u,lerp:d=.1,infinite:p=!1,orientation:m="vertical",gestureOrientation:g="horizontal"===m?"both":"vertical",touchMultiplier:v=1,wheelMultiplier:b=1,autoResize:x=!0,prevent:w,virtualScroll:y,overscroll:S=!0,autoRaf:E=!1,anchors:k=!1,autoToggle:N=!1,allowNestedScroll:j=!1,__experimental__naiveDimensions:C=!1,naiveDimensions:M=C,stopInertiaOnNavigate:R=!1}={}){
      window.lenisVersion=i,window.lenis||(window.lenis={}),window.lenis.version=i,"horizontal"===m&&(window.lenis.horizontal=!0),!0===o&&(window.lenis.touch=!0),e&&e!==document.documentElement||(e=window),"number"==typeof c&&"function"!=typeof u?u=f:"function"==typeof u&&"number"!=typeof c&&(c=1),this.options={wrapper:e,content:t,eventsTarget:r,smoothWheel:n,syncTouch:o,syncTouchLerp:l,touchInertiaExponent:a,duration:c,easing:u,lerp:d,infinite:p,gestureOrientation:g,orientation:m,touchMultiplier:v,wheelMultiplier:b,autoResize:x,prevent:w,virtualScroll:y,overscroll:S,autoRaf:E,anchors:k,autoToggle:N,allowNestedScroll:j,naiveDimensions:M,stopInertiaOnNavigate:R},this.dimensions=new s(e,t,{autoResize:x}),this.updateClassName(),this.targetScroll=this.animatedScroll=this.actualScroll,this.options.wrapper.addEventListener("scroll",this.onNativeScroll),this.options.wrapper.addEventListener("scrollend",this.onScrollEnd,{capture:!0}),(this.options.anchors||this.options.stopInertiaOnNavigate)&&this.options.wrapper.addEventListener("click",this.onClick),this.options.wrapper.addEventListener("pointerdown",this.onPointerDown),this.virtualScroll=new h(r,{touchMultiplier:v,wheelMultiplier:b}),this.virtualScroll.on("scroll",this.onVirtualScroll),this.options.autoToggle&&(this.checkOverflow(),this.rootElement.addEventListener("transitionend",this.onTransitionEnd)),this.options.autoRaf&&(this._rafId=requestAnimationFrame(this.raf))
      }destroy(){
      this.emitter.destroy(),this.options.wrapper.removeEventListener("scroll",this.onNativeScroll),this.options.wrapper.removeEventListener("scrollend",this.onScrollEnd,{capture:!0}),this.options.wrapper.removeEventListener("pointerdown",this.onPointerDown),(this.options.anchors||this.options.stopInertiaOnNavigate)&&this.options.wrapper.removeEventListener("click",this.onClick),this.virtualScroll.destroy(),this.dimensions.destroy(),this.cleanUpClassName(),this._rafId&&cancelAnimationFrame(this._rafId)
      }on(e,t){
      return this.emitter.on(e,t)
      }off(e,t){
      return this.emitter.off(e,t)
      }onScrollEnd=e=>{
      e instanceof CustomEvent||"smooth"!==this.isScrolling&&!1!==this.isScrolling||e.stopPropagation()
      };dispatchScrollendEvent=()=>{
      this.options.wrapper.dispatchEvent(new CustomEvent("scrollend",{bubbles:this.options.wrapper===window,detail:{lenisScrollEnd:!0}}))
      };get overflow(){
      let e=this.isHorizontal?"overflow-x":"overflow-y";
      return getComputedStyle(this.rootElement)[e]
      }checkOverflow(){
      ["hidden","clip"].includes(this.overflow)?this.internalStop():this.internalStart()
      }onTransitionEnd=e=>{
      e.propertyName?.includes("overflow")&&e.target===this.rootElement&&this.checkOverflow()
      };setScroll(e){
      this.isHorizontal?this.options.wrapper.scrollTo({left:e,behavior:"instant"}):this.options.wrapper.scrollTo({top:e,behavior:"instant"})
      }onClick=e=>{
      let t=e.composedPath().filter(e=>e instanceof HTMLAnchorElement&&e.href).map(e=>new URL(e.href)),r=new URL(window.location.href);
      if(this.options.anchors){
        let e=t.find(e=>r.host===e.host&&r.pathname===e.pathname&&e.hash);
        if(e){
          let t="object"==typeof this.options.anchors&&this.options.anchors?this.options.anchors:void 0,r=`#${e.hash.split("#")[1]}`;
          this.scrollTo(r,t);
          return
          }
        }
      if(this.options.stopInertiaOnNavigate&&t.some(e=>r.host===e.host&&r.pathname!==e.pathname))
      return void this.reset()
      };onPointerDown=e=>{
      1===e.button&&this.reset()
      };onVirtualScroll=e=>{
      if("function"==typeof this.options.virtualScroll&&!1===this.options.virtualScroll(e))
      return;
      let{deltaX:t,deltaY:r,event:n}=e;
      if(this.emitter.emit("virtual-scroll",{deltaX:t,deltaY:r,event:n}),n.ctrlKey||n.lenisStopPropagation)
      return;
      let i=n.type.includes("touch"),o=n.type.includes("wheel");
      this.isTouching="touchstart"===n.type||"touchmove"===n.type;
      let l=0===t&&0===r;
      if(this.options.syncTouch&&i&&"touchstart"===n.type&&l&&!this.isStopped&&!this.isLocked)
      return void this.reset();
      let s="vertical"===this.options.gestureOrientation&&0===r||"horizontal"===this.options.gestureOrientation&&0===t;
      if(l||s)
      return;
      let a=n.composedPath();
      a=a.slice(0,a.indexOf(this.rootElement));
      let c=this.options.prevent,u=Math.abs(t)>=Math.abs(r)?"horizontal":"vertical";
      if(a.find(e=>e instanceof HTMLElement&&("function"==typeof c&&c?.(e)||e.hasAttribute?.("data-lenis-prevent")||"vertical"===u&&e.hasAttribute?.("data-lenis-prevent-vertical")||"horizontal"===u&&e.hasAttribute?.("data-lenis-prevent-horizontal")||i&&e.hasAttribute?.("data-lenis-prevent-touch")||o&&e.hasAttribute?.("data-lenis-prevent-wheel")||this.options.allowNestedScroll&&this.hasNestedScroll(e,{deltaX:t,deltaY:r}))))
      return;
      if(this.isStopped||this.isLocked){
        n.cancelable&&n.preventDefault();
        return
        }
      if(!(this.options.syncTouch&&i||this.options.smoothWheel&&o)){
        this.isScrolling="native",this.animate.stop(),n.lenisStopPropagation=!0;
        return
        }
      let d=r;
      "both"===this.options.gestureOrientation?d=Math.abs(r)>Math.abs(t)?r:t:"horizontal"===this.options.gestureOrientation&&(d=t),(!this.options.overscroll||this.options.infinite||this.options.wrapper!==window&&this.limit>0&&(this.animatedScroll>0&&this.animatedScroll<this.limit||0===this.animatedScroll&&r>0||this.animatedScroll===this.limit&&r<0))&&(n.lenisStopPropagation=!0),n.cancelable&&n.preventDefault();
      let h=i&&this.options.syncTouch,f=i&&"touchend"===n.type;
      f&&(d=Math.sign(d)*Math.abs(this.velocity)**this.options.touchInertiaExponent),this.scrollTo(this.targetScroll+d,{programmatic:!1,...h?{lerp:f?this.options.syncTouchLerp:1}:{lerp:this.options.lerp,duration:this.options.duration,easing:this.options.easing}})
      };resize(){
      this.dimensions.resize(),this.animatedScroll=this.targetScroll=this.actualScroll,this.emit()
      }emit(){
      this.emitter.emit("scroll",this)
      }onNativeScroll=()=>{
      if(null!==this._resetVelocityTimeout&&(clearTimeout(this._resetVelocityTimeout),this._resetVelocityTimeout=null),this._preventNextNativeScrollEvent){
        this._preventNextNativeScrollEvent=!1;
        return
        }
      if(!1===this.isScrolling||"native"===this.isScrolling){
        let e=this.animatedScroll;
        this.animatedScroll=this.targetScroll=this.actualScroll,this.lastVelocity=this.velocity,this.velocity=this.animatedScroll-e,this.direction=Math.sign(this.animatedScroll-e),this.isStopped||(this.isScrolling="native"),this.emit(),0!==this.velocity&&(this._resetVelocityTimeout=setTimeout(()=>{
          this.lastVelocity=this.velocity,this.velocity=0,this.isScrolling=!1,this.emit()
          },400))
        }
      };reset(){
      this.isLocked=!1,this.isScrolling=!1,this.animatedScroll=this.targetScroll=this.actualScroll,this.lastVelocity=this.velocity=0,this.animate.stop()
      }start(){
      if(this.isStopped){
        if(this.options.autoToggle)
        return void this.rootElement.style.removeProperty("overflow");
        this.internalStart()
        }
      }internalStart(){
      this.isStopped&&(this.reset(),this.isStopped=!1,this.emit())
      }stop(){
      if(!this.isStopped){
        if(this.options.autoToggle)
        return void this.rootElement.style.setProperty("overflow","clip");
        this.internalStop()
        }
      }internalStop(){
      this.isStopped||(this.reset(),this.isStopped=!0,this.emit())
      }raf=e=>{
      let t=e-(this.time||e);
      this.time=e,this.animate.advance(.001*t),this.options.autoRaf&&(this._rafId=requestAnimationFrame(this.raf))
      };scrollTo(e,{offset:t=0,immediate:r=!1,lock:n=!1,programmatic:i=!0,lerp:l=i?this.options.lerp:void 0,duration:s=i?this.options.duration:void 0,easing:a=i?this.options.easing:void 0,onStart:c,onComplete:u,force:d=!1,userData:h}={}){
      if((this.isStopped||this.isLocked)&&!d)
      return;
      let p=e,m=t;
      if("string"==typeof p&&["top","left","start","#"].includes(p))
      p=0;
      else 
      if("string"==typeof p&&["bottom","right","end"].includes(p))
      p=this.limit;
      else{
        let e=null;
        if("string"==typeof p?(e=document.querySelector(p))||("#top"===p?p=0:console.warn("Lenis: Target not found",p)):p instanceof HTMLElement&&p?.nodeType&&(e=p),e){
          if(this.options.wrapper!==window){
            let e=this.rootElement.getBoundingClientRect();
            m-=this.isHorizontal?e.left:e.top
            }
          let t=e.getBoundingClientRect(),r=getComputedStyle(e),n=this.isHorizontal?Number.parseFloat(r.scrollMarginLeft):Number.parseFloat(r.scrollMarginTop),i=getComputedStyle(this.rootElement),o=this.isHorizontal?Number.parseFloat(i.scrollPaddingLeft):Number.parseFloat(i.scrollPaddingTop);
          p=(this.isHorizontal?t.left:t.top)+this.animatedScroll-(Number.isNaN(n)?0:n)-(Number.isNaN(o)?0:o)
          }
        }
      if("number"==typeof p){
        if(p+=m,this.options.infinite){
          if(i){
            this.targetScroll=this.animatedScroll=this.scroll;
            let e=p-this.animatedScroll;
            e>this.limit/2?p-=this.limit:e<-this.limit/2&&(p+=this.limit)
            }
          }else 
        p=o(0,p,this.limit);
        if(p===this.targetScroll){
          c?.(this),u?.(this);
          return
          }
        if(this.userData=h??{},r){
          this.animatedScroll=this.targetScroll=p,this.setScroll(this.scroll),this.reset(),this.preventNextNativeScrollEvent(),this.emit(),u?.(this),this.userData={},requestAnimationFrame(()=>{
            this.dispatchScrollendEvent()
            });
          return
          }
        i||(this.targetScroll=p),"number"==typeof s&&"function"!=typeof a?a=f:"function"==typeof a&&"number"!=typeof s&&(s=1),this.animate.fromTo(this.animatedScroll,p,{duration:s,easing:a,lerp:l,onStart:()=>{
          n&&(this.isLocked=!0),this.isScrolling="smooth",c?.(this)
          },onUpdate:(e,t)=>{
          this.isScrolling="smooth",this.lastVelocity=this.velocity,this.velocity=e-this.animatedScroll,this.direction=Math.sign(this.velocity),this.animatedScroll=e,this.setScroll(this.scroll),i&&(this.targetScroll=e),t||this.emit(),t&&(this.reset(),this.emit(),u?.(this),this.userData={},requestAnimationFrame(()=>{
            this.dispatchScrollendEvent()
            }),this.preventNextNativeScrollEvent())
          }})
        }
      }preventNextNativeScrollEvent(){
      this._preventNextNativeScrollEvent=!0,requestAnimationFrame(()=>{
        this._preventNextNativeScrollEvent=!1
        })
      }hasNestedScroll(e,{deltaX:t,deltaY:r}){
      let n,i,o,l,s,a,c,u,d,h,f,p,m,g,v,b,x=Date.now();
      e._lenis||(e._lenis={});
      let w=e._lenis;
      if(x-(w.time??0)>2e3){
        w.time=Date.now();
        let t=window.getComputedStyle(e);
        if(w.computedStyle=t,n=["auto","overlay","scroll"].includes(t.overflowX),i=["auto","overlay","scroll"].includes(t.overflowY),s=["auto"].includes(t.overscrollBehaviorX),a=["auto"].includes(t.overscrollBehaviorY),w.hasOverflowX=n,w.hasOverflowY=i,!(n||i))
        return!1;
        c=e.scrollWidth,u=e.scrollHeight,d=e.clientWidth,h=e.clientHeight,o=c>d,l=u>h,w.isScrollableX=o,w.isScrollableY=l,w.scrollWidth=c,w.scrollHeight=u,w.clientWidth=d,w.clientHeight=h,w.hasOverscrollBehaviorX=s,w.hasOverscrollBehaviorY=a
        }else 
      o=w.isScrollableX,l=w.isScrollableY,n=w.hasOverflowX,i=w.hasOverflowY,c=w.scrollWidth,u=w.scrollHeight,d=w.clientWidth,h=w.clientHeight,s=w.hasOverscrollBehaviorX,a=w.hasOverscrollBehaviorY;
      if(!(n&&o||i&&l))
      return!1;
      let y=Math.abs(t)>=Math.abs(r)?"horizontal":"vertical";
      if("horizontal"===y)
      f=Math.round(e.scrollLeft),p=c-d,m=t,g=n,v=o,b=s;
      else{
        if("vertical"!==y)
        return!1;
        f=Math.round(e.scrollTop),p=u-h,m=r,g=i,v=l,b=a
        }
      return!b&&(f>=p||f<=0)||(m>0?f<p:f>0)&&g&&v
      }get rootElement(){
      return this.options.wrapper===window?document.documentElement:this.options.wrapper
      }get limit(){
      return this.options.naiveDimensions?this.isHorizontal?this.rootElement.scrollWidth-this.rootElement.clientWidth:this.rootElement.scrollHeight-this.rootElement.clientHeight:this.dimensions.limit[this.isHorizontal?"x":"y"]
      }get isHorizontal(){
      return"horizontal"===this.options.orientation
      }get actualScroll(){
      let e=this.options.wrapper;
      return this.isHorizontal?e.scrollX??e.scrollLeft:e.scrollY??e.scrollTop
      }get scroll(){
      var e;
      return this.options.infinite?(this.animatedScroll%(e=this.limit)+e)%e:this.animatedScroll
      }get progress(){
      return 0===this.limit?1:this.scroll/this.limit
      }get isScrolling(){
      return this._isScrolling
      }set isScrolling(e){
      this._isScrolling!==e&&(this._isScrolling=e,this.updateClassName())
      }get isStopped(){
      return this._isStopped
      }set isStopped(e){
      this._isStopped!==e&&(this._isStopped=e,this.updateClassName())
      }get isLocked(){
      return this._isLocked
      }set isLocked(e){
      this._isLocked!==e&&(this._isLocked=e,this.updateClassName())
      }get isSmooth(){
      return"smooth"===this.isScrolling
      }get className(){
      let e="lenis";
      return this.options.autoToggle&&(e+=" lenis-autoToggle"),this.isStopped&&(e+=" lenis-stopped"),this.isLocked&&(e+=" lenis-locked"),this.isScrolling&&(e+=" lenis-scrolling"),"smooth"===this.isScrolling&&(e+=" lenis-smooth"),e
      }updateClassName(){
      this.cleanUpClassName(),this.className.split(" ").forEach(e=>{
        this.rootElement.classList.add(e)
        })
      }cleanUpClassName(){
      for(
      let e
       of Array.from(this.rootElement.classList))
      ("lenis"===e||e.startsWith("lenis-"))&&this.rootElement.classList.remove(e)
      }
  },m=e.i(89970),g=e.i(83495),v=e.i(41253);
  function b(){
    let e=(0,n.usePathname)(),t=(0,r.useRef)(e),i=(0,r.useRef)(null);
    return(0,r.useEffect)(()=>{
      let e=()=>{
        i.current=window.location.pathname
        };
      return window.addEventListener("popstate",e),()=>window.removeEventListener("popstate",e)
      },[]),(0,r.useEffect)(()=>{
      if(e===t.current)
      return;
      t.current=e;
      let r=i.current===e;
      i.current=null,r||window.location.hash||v.lenisRef.current?.scrollTo(0,{immediate:!0,force:!0})
      },[e]),null
    }
  m.default.registerPlugin(g.ScrollTrigger),e.s(["default",0,function({children:e}){
    return(0,r.useEffect)(()=>{
      if(window.matchMedia("(prefers-reduced-motion: reduce)").matches)
      return;
      let e=new p({lerp:.12,anchors:!0});
      v.lenisRef.current=e,e.on("scroll",g.ScrollTrigger.update);
      let t=t=>e.raf(1e3*t);
      return m.default.ticker.add(t),m.default.ticker.lagSmoothing(0),()=>{
        m.default.ticker.remove(t),v.lenisRef.current=null,e.destroy()
        }
      },[]),(0,t.jsxs)(t.Fragment,{children:[e,(0,t.jsx)(b,{})]})
    }],38685)
  },54227,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645),n=e.i(18566),i=e.i(89970),o=e.i(25215),l=e.i(91672),s=e.i(41253),a=e.i(21853),c=e.i(74268);
  let u=(0,a.defineTunables)("rulerLayout","Ruler layout",{side:{label:"Side 0=L 1=R",min:0,max:1,step:1,default:1,info:"Which viewport edge the ruler lives on: 0 = left, 1 = right."},edgePad:{label:"Edge pad px",min:0,max:40,step:2,default:12,info:"Vertical inset of the ruler's whole mapping (needle travel, clicks, compact map) from the nav bottom and viewport bottom — keeps the 0/100 ticks and labels fully visible."},railW:{label:"Rail width px",min:32,max:96,step:2,default:60,info:"Width of the tick rail at the viewport edge; also the gutter reserved from page content."},minorPct:{label:"Tick every %",min:.5,max:5,step:.5,default:1,info:"Scroll-percent spacing between minor ticks on the rail."},labelPct:{label:"Label every %",min:5,max:25,step:5,default:5,info:"Scroll-percent spacing between the longer, number-labeled major ticks."},thresholdPct:{label:"Flip line vh%",min:4,max:40,step:1,default:12,info:"Viewport-height % from the top where a riding word flips horizontal into the top stack."},headingPx:{label:"Heading px",min:12,max:34,step:1,default:34,info:"Font size of the full-size current-section heading below the top pile."},ridingPx:{label:"Riding px",min:9,max:24,step:1,default:20,info:"Font size of the vertical word riding the rail with its section."},queuePx:{label:"Queue px",min:9,max:24,step:1,default:16,info:"Font size of the compact heading links (bottom queue and top pile)."},topPad:{label:"Top pad px",min:4,max:120,step:4,default:28,info:"Gap between the nav bar and the first heading in the top pile."},currentGap:{label:"Current gap px",min:8,max:80,step:2,default:26,info:"Extra gap separating the full-size current heading from the compact pile above it."},queueSlot:{label:"Queue slot px",min:12,max:48,step:2,default:20,info:"Vertical spacing between stacked heading links, top pile and bottom queue alike."},queuePad:{label:"Queue bottom px",min:8,max:120,step:4,default:36,info:"Gap between the viewport bottom and the lowest queued heading."},textPad:{label:"Text pad px",min:0,max:48,step:2,default:0,info:"Horizontal gap between the tick rail and the heading text."}}),d=(0,a.defineTunables)("rulerMotion","Ruler motion",{flipZone:{label:"Flip zone px",min:60,max:600,step:10,default:200,info:"Scroll distance over which the vertical-to-horizontal top flip plays out."},detachZone:{label:"Detach zone px",min:60,max:600,step:10,default:240,info:"Scroll distance over which a queued heading morphs onto the rail beside its slot."},stagger:{label:"Letter stagger",min:0,max:.3,step:.01,default:.16,info:"Per-letter delay fraction in flips — higher = letters travel more one-by-one."},arc:{label:"Curve arc px",min:0,max:200,step:4,default:28,info:"How far each letter's flight path bows inward (toward the page) mid-flip."},jumpDur:{label:"Jump dur s",min:.2,max:2.5,step:.05,default:1.25,info:"Max duration of a click jump (rail or heading link); short hops scale it down."},snapDelay:{label:"Snap delay ms",min:100,max:1500,step:50,default:400,info:"How long scroll must rest with a flip half-done before it auto-resolves."},snapDur:{label:"Snap dur s",min:.2,max:2,step:.05,default:.7,info:"Duration of the damped auto-scroll that resolves a half-done flip."},introDur:{label:"Intro dur s",min:.1,max:2,step:.05,default:1,info:"Draw-in duration of each tick during the page-load cascade."},introStagger:{label:"Intro stag s",min:0,max:.02,step:.001,default:.01,info:"Delay between successive ticks in the load cascade (top-down)."},velRadius:{label:"Vel radius px",min:0,max:500,step:10,default:180,info:"Document distance around the needle within which ticks react to scroll speed."},velMax:{label:"Vel stretch",min:0,max:2,step:.05,default:.6,info:"How much fast scrolling stretches the ticks nearest the needle."},zoomInDelay:{label:"Zoom delay ms",min:0,max:800,step:25,default:150,info:"Hover intent time on the rail before the full-page zoom engages — accidental edge grazes don't fire."},zoomOutDelay:{label:"Unzoom delay ms",min:0,max:800,step:25,default:150,info:"Grace period after leaving the rail before the zoom relaxes back to 1:1."},zoomLerp:{label:"Zoom damping",min:2,max:16,step:.5,default:10,info:"Damping rate of the zoom morph — higher = snappier compression onto the needle."},dragLerp:{label:"Drag lerp",min:.05,max:.6,step:.01,default:.18,info:"How tightly the page chases the cursor while thumb-dragging the zoomed rail."},heroLead:{label:"Hero lead px",min:0,max:400,step:10,default:100,info:"How many scroll px before the wordmark would duck under the nav the hero-to-header morph begins."},heroZone:{label:"Hero morph px",min:100,max:900,step:20,default:320,info:"Scroll distance the hero wordmark's flight to the top heading slot spans."}}),h=(0,a.defineTunables)("rulerLook","Ruler look",{minorAlpha:{label:"Minor alpha",min:0,max:1,step:.05,default:.4,info:"Opacity of the minor ticks."},majorAlpha:{label:"Major alpha",min:0,max:1,step:.05,default:.8,info:"Opacity of labeled major ticks and the riding section ticks."},labelAlpha:{label:"Label alpha",min:0,max:1,step:.05,default:.5,info:"Opacity of the mono percent numbers and section index labels."},minorLen:{label:"Minor len px",min:2,max:20,step:1,default:10,info:"Length of minor ticks, drawn from the outer edge."},majorLen:{label:"Major len px",min:4,max:28,step:1,default:20,info:"Length of labeled major ticks, drawn from the outer edge."},ghostAlpha:{label:"Ghost alpha",min:0,max:1,step:.05,default:1,info:"Opacity of the hover ghost line previewing where a rail click will jump."},ghostThick:{label:"Ghost thick px",min:1,max:8,step:1,default:3,info:"Thickness of the hover ghost line."},queueAlpha:{label:"Queue alpha",min:0,max:1,step:.05,default:.35,info:"Opacity of the compact heading links (bottom queue and top pile) and of the in-transit riding word — everything that isn't the active top heading."},yieldPad:{label:"Yield margin px",min:0,max:80,step:2,default:24,info:"Distance around a riding word within which the tick percent labels fade out of its way (proximity yield)."},needleFadePct:{label:"Needle fade %",min:0,max:10,step:.5,default:3,info:"Progress percent below which the needle and its readout fade out — the instrument stays quiet at the very top of the page."},bracketAlpha:{label:"Bracket alpha",min:0,max:.5,step:.02,default:.1,info:"Opacity of the shaded bracket marking the visible page span while zoomed."},mapAlpha:{label:"Map alpha",min:0,max:1,step:.05,default:.85,info:"Opacity of the section labels in the zoomed full-page map."},poolAlpha:{label:"Pool alpha",min:0,max:1,step:.05,default:1,info:"Strength of the page-bg contrast pools behind the top stack and the bottom queue (0 = none)."},frostSolid:{label:"Frost solid %",min:0,max:80,step:5,default:40,info:"Portion of the rail (from the outer edge) where the frost is at full strength before the feather begins."},frostGamma:{label:"Frost ease",min:.5,max:4,step:.1,default:2.2,info:"Falloff curve of the frost's inner feather — higher eases in longer toward the page (a slower, less visible tail)."},poolPad:{label:"Pool pad px",min:0,max:160,step:8,default:64,info:"Feather margin the contrast pools extend beyond the top stack's and bottom queue's actual bounding boxes."}});
  var f=e.i(79655);
  function p({mode:e,side:n,sections:o,geom:l,layoutVersion:m}){
    let[g,v]=(0,r.useState)(null),b=(0,r.useRef)([]),x=(0,r.useRef)(null),w=(0,r.useRef)(null),y=(0,r.useRef)(-1),S=(0,r.useMemo)(()=>new Float32Array(o.length),[o.length]),E=(0,r.useMemo)(()=>new Float32Array(o.length),[o.length]),k=(0,r.useRef)({lastY:0,vel:0,snapSince:null,snapping:!1,armed:!0,jumping:!1}),N=(0,r.useMemo)(()=>u.read(),[m]);
    (0,r.useEffect)(()=>()=>{
      for(
      let e
       of c.heroWordmark.els)
      e.style.transform="",e.style.fontWeight="",e.style.fontStretch="",e.style.color="",e.style.opacity="1"
      },[e]),(0,a.useTunerStore)(e=>e.version);
    let j=h.read(),C=o.map(e=>e.label).join("|");
    if((0,r.useEffect)(()=>{
      if("full"!==e||!o.length)
      return;
      let t=!1,r=()=>{
        t||v(function(e){
          let t=document.createElement("div");
          t.className="font-display",t.style.cssText="position:absolute;left:-9999px;top:0;visibility:hidden;white-space:pre;font-size:100px;line-height:1;",document.body.appendChild(t);
          let r={};
          for(
          let n
           of e){
            t.textContent="";
            let e=n.split("").map(e=>{
              let r=document.createElement("span");
              return r.textContent=e,t.appendChild(r),r
              }).map(e=>e.getBoundingClientRect().width/100),i=[],o=0;
            for(
            let t
             of e)
            i.push(o),o+=t;
            r[n]={adv:e,cum:i,total:o}
            }
          return t.remove(),r
          }(o.map(e=>e.label)))
        },n=document.fonts?.ready;
      return n?n.then(r).catch(r):r(),()=>{
        t=!0
        }
      },[e,C]),(0,r.useEffect)(()=>{
      if("full"!==e||!g||!o.length||!l.docH)
      return;
      let t=(e,t)=>{
        let r=k.current,i=u.read(),a=d.read(),p=h.read(),{docH:m,vh:v,vw:N}=l,j=Math.min(t/1e3,.1)||.016,C=window.scrollY,M=Math.max(1,m-v),R=(0,c.clamp01)(C/M),P=(0,c.rulerMap)(v,i.edgePad),T=P.drift(R),O=(C-r.lastY)/j;
        r.lastY=C,r.vel+=(O-r.vel)*(1-Math.exp(-6*j));
        let L=i.thresholdPct/100*v,A=c.NAV_H+i.topPad,I=v-i.queuePad,D=i.headingPx,_=i.ridingPx/D,z=i.queuePx/D,F="right"===n?-1:1,W="right"===n?N-i.railW/2:i.railW/2,H=(0,c.easeInOutCubic)(c.rulerZoom.p),$=o.map((e,t)=>{
          let r,n=e.isHero&&c.heroWordmark.ready?c.heroWordmark.metrics:g[e.label],i=(n?.total??0)*D*_,o=e.anchor-C+T,l=0,s=null;
          if(0!==t||e.isHero){
            if(e.isHero){
              l=1;
              let e=Math.max(0,(c.heroWordmark.ready?Math.min(...c.heroWordmark.baseDocY)-.5*c.heroWordmark.fontPx:0)-c.NAV_H-a.heroLead),t=Math.max(1,a.heroZone);
              r=(0,c.clamp01)((C-e)/t),s={start:e,end:e+t}
              }else 
            if(r=(0,c.clamp01)((L+a.flipZone-o)/a.flipZone),e.anchor-M>L){
              let t=Math.min(e.bottom-v,M-24),n=Math.max(24,M-t);
              r=Math.max(r,(0,c.clamp01)((C-t)/n)),s={start:t,end:M}
              }
            }else 
          r=1,l=1;
          return{v:o,rideLen:i,flipP:r,scrollFlip:s,detachP:l,yq:I}
          });
        {
          let e=0;
          for(
          let t=o.length-1
          ;t>=0;t--){
            if(o[t].isHero||0===t)
            continue;
            let r=$[t];
            r.yq=I-i.queueSlot*e,r.detachP=(0,c.clamp01)((r.yq+a.detachZone-(r.v+r.rideLen))/a.detachZone),e+=1-r.detachP
            }
          }
        c.railOccupancy.spans.length=0;
        let Y=0,U=0;
        for(
        let e
         of $)
        e.flipP>=1?Y++:e.flipP>0&&(U+=e.flipP);
        let q=0,V=0;
        for(
        let e=0
        ;e<$.length;e++)
        if($[e].flipP>q&&(q=$[e].flipP),!o[e].isHero){
          let t=1-$[e].detachP;
          t>V&&(V=t)
          }
        x.current&&(x.current.style.opacity=String(p.poolAlpha*q)),w.current&&(w.current.style.opacity=String(p.poolAlpha*V));
        let B=(e,t,r,o,l)=>{
          let s=(e.cum[t]+e.adv[t]/2)*D*o,a=i.railW+i.textPad+("right"===n?e.total*D*o-s:s);
          return{x:"right"===n?N-a:a,y:r,rot:0,scale:o,alpha:l}
          },Z=(e,t,r)=>({x:W,y:r+(e.total-e.cum[t]-e.adv[t]/2)*D*_,rot:-90,scale:_,alpha:p.queueAlpha});
        for(
        let e=0
        ;e<o.length;e++){
          let t,r,n,l=o[e],s=l.isHero&&c.heroWordmark.ready,u=s?c.heroWordmark.metrics:g[l.label],d=b.current[e];
          if(!u||!d||l.isHero&&!s||l.isHero&&c.heroWordmark.forming)
          continue;
          let{v:h,rideLen:v,flipP:x,detachP:w,yq:k}=$[e],N=u.adv.length,M=e=>({x:c.heroWordmark.baseX[e],y:c.heroWordmark.baseDocY[e]-C,rot:0,scale:c.heroWordmark.fontPx/D,alpha:1}),R=!1;
          if(x>0)
          if(t=x,R=!0,r=s?M:e=>Z(u,e,h),x>=1){
            let t=e===Y-1?U:1,r=A+e*i.queueSlot+i.currentGap*(1-t),o=1-(1-z)*t,l=1-(1-p.queueAlpha)*t;
            n=e=>B(u,e,r,o,l)
            }else 
          n=t=>B(u,t,A+e*i.queueSlot+i.currentGap,1,1);
          else 
          if(w<1){
            t=w,R=!0;
            let e=k-v;
            n=t=>Z(u,t,e),r=e=>B(u,e,k,z,p.queueAlpha)
            }else 
          t=1,r=n=s?M:e=>Z(u,e,h);
          let T=a.stagger,O=1+(N-1)*T,L=P.base+(l.isHero?0:l.anchor)/m*P.span,I=s?c.heroWordmark.els:d.letters,_=s?D/c.heroWordmark.fontPx:1,W=s?H*Math.min(1,x):H,q=S[e]+=((y.current===e)-S[e])*(1-Math.exp(-j/.08)),V=(0,c.clamp01)((E[e]-performance.now())/350),K=1/0,G=-1/0,X=1/0,J=-1/0,Q=0;
          for(
          let e=0
          ;e<N;e++){
            let i=I[e];
            if(!i)
            continue;
            let o=R?N-1-e:e,l=(0,c.clamp01)(t*O-o*T),d=(0,c.easeInOutCubic)(l),h=r(e),m=n(e),g=(h.x+m.x)/2+F*a.arc,v=(h.y+m.y)/2,b=1-d,w=b*b*h.x+2*b*d*g+d*d*m.x,y=b*b*h.y+2*b*d*v+d*d*m.y,S=h.rot+(m.rot-h.rot)*d,E=h.scale+(m.scale-h.scale)*d,k=h.alpha+(m.alpha-h.alpha)*d;
            if(W>0){
              let t=B(u,e,L,z,p.mapAlpha);
              w+=(t.x-w)*W,y+=(t.y-y)*W,S*=1-W,E+=(t.scale-E)*W,k+=(t.alpha-k)*W
              }
            if(s){
              i.style.transform=`translate3d(${w-c.heroWordmark.baseX[e]}px, ${y-(c.heroWordmark.baseDocY[e]-C)}px, 0) rotate(${S}deg) scale(${E*_})`;
              let t=x>0?d:0,r=f.wordmarkTuner.read().weight;
              i.style.fontWeight=String(Math.round(r-(r-f.DISPLAY_WEIGHT)*t)),i.style.fontStretch=`${(f.WORDMARK_STRETCH-(f.WORDMARK_STRETCH-f.DISPLAY_STRETCH)*t).toFixed(1)}%`
              }else 
            i.style.transform=`translate3d(${w}px, ${y}px, 0) translate(-50%, -50%) rotate(${S}deg) scale(${E})`;
            i.style.opacity="1";
            let j=k+(1-k)*q,M=j>=.995?"var(--ink-strong)":`color-mix(in srgb, var(--ink-strong) ${(100*(0,c.clamp01)(j)).toFixed(1)}%, var(--bg))`;
            i.style.color=V>.01?`color-mix(in srgb, var(--accent-ink) ${(70*V).toFixed(0)}%, ${M})`:M,k>Q&&(Q=k);
            let P=u.adv[e]*D*E/2+2,A=D*E/2+2,H=Math.abs(S)>45,$=H?A:P,Y=H?P:A;
            w-$<K&&(K=w-$),w+$>G&&(G=w+$),y-Y<X&&(X=y-Y),y+Y>J&&(J=y+Y)
            }
          let ee=l.isHero?0:w*(1-x);
          ee>.02&&c.railOccupancy.spans.push({top:h,bottom:h+v,k:ee}),d.hit&&isFinite(K)&&(d.hit.style.left=`${K-2}px`,d.hit.style.top=`${X-2}px`,d.hit.style.width=`${G-K+4}px`,d.hit.style.height=`${J-X+4}px`,d.hit.style.pointerEvents=Q>.05&&(!l.isHero||x>.05)?"auto":"none")
          }
        let K=s.lenisRef.current,G=performance.now(),X=$.findIndex(e=>e.flipP>.04&&e.flipP<.96);
        if(c.rulerZoom.dragging&&(r.armed=!0),r.snapping)
        X<0&&(r.snapping=!1);
        else 
        if(X>=0&&r.armed&&!r.jumping&&30>Math.abs(r.vel)&&K&&!c.rulerZoom.dragging&&c.rulerZoom.p<.3){
          if(null===r.snapSince)
          r.snapSince=G;
          else 
          if(G-r.snapSince>a.snapDelay){
            let e,t=$[X],n=o[X];
            if(t.scrollFlip)
            e=t.flipP>=.5?t.scrollFlip.end+4:t.scrollFlip.start-4;
            else{
              let r=t.flipP>=.5?L-4:L+a.flipZone+4;
              e=n.anchor+T-r
              }
            let i=(e,t)=>{
              let r=e.anchor+T-L-.04*a.flipZone,n=e.anchor+T-L-.96*a.flipZone;
              if(!t.scrollFlip)
              return{yFlip:r,yUnflip:n};
              let i=t.scrollFlip.end-t.scrollFlip.start,o=t.scrollFlip.start+.96*i,l=t.scrollFlip.start+.04*i;
              return e.isHero?{yFlip:o,yUnflip:l}:{yFlip:Math.min(r,o),yUnflip:Math.min(n,l)}
              },l=e;
            for(
            let e=0
            ;e<$.length;e++){
              if(e===X)
              continue;
              let t=i(o[e],$[e]);
              $[e].flipP>=.96?l=Math.max(l,t.yFlip+2):$[e].flipP<=.04&&(l=Math.min(l,t.yUnflip-2))
              }
            let s=i(n,t),u=Math.max(0,Math.min(M,(t.flipP>=.5?l>=s.yFlip:l<=s.yUnflip)?l:e));
            r.snapping=!0,r.armed=!1,r.snapSince=null,K.scrollTo(u,{duration:a.snapDur,easing:c.easeInOutCubic,onComplete:()=>{
              r.snapping=!1
              }})
            }
          }else 
        r.snapSince=null
        },r=()=>{
        k.current.armed=!0
        };
      return window.addEventListener("wheel",r,{passive:!0}),window.addEventListener("touchmove",r,{passive:!0}),window.addEventListener("keydown",r),i.default.ticker.add(t),()=>{
        window.removeEventListener("wheel",r),window.removeEventListener("touchmove",r),window.removeEventListener("keydown",r),i.default.ticker.remove(t)
        }
      },[e,g,o,l,n,m]),!o.length)
    return null;
    if("static"===e){
      let e="right"===n?{right:N.railW+N.textPad,textAlign:"right"}:{left:N.railW+N.textPad};
      return(0,t.jsxs)("nav",{"aria-label":"Sections",className:"fixed z-40",style:{bottom:N.queuePad,...e},children:[(0,t.jsx)("div",{"aria-hidden":!0,className:"absolute -inset-x-16 -inset-y-10",style:{opacity:j.poolAlpha,backdropFilter:"blur(9px)",WebkitBackdropFilter:"blur(9px)",backgroundColor:"color-mix(in srgb, var(--bg) 82%, transparent)",maskImage:"radial-gradient(closest-side, black 55%, transparent 100%)",WebkitMaskImage:"radial-gradient(closest-side, black 55%, transparent 100%)"}}),(0,t.jsx)("ul",{className:"relative flex flex-col gap-1.5",children:o.map(e=>(0,t.jsx)("li",{children:(0,t.jsx)("a",{href:`#${e.id}`,className:"font-display text-ink hover:text-ink-strong active:text-accent-ink",style:{fontSize:N.queuePx+2},children:e.label})},e.id))})]})
      }
    if(!g)
    return null;
    let M=o.length,R=260;
    for(
    let e
     of o){
      let t=g[e.label];
      t&&(R=Math.max(R,t.total*N.headingPx))
      }
    R+=N.railW+N.textPad+j.poolPad;
    let P=c.NAV_H+N.topPad+Math.max(0,M-1)*N.queueSlot+N.currentGap+N.headingPx+j.poolPad,T=N.queuePad+M*N.queueSlot+j.poolPad,O=e=>`radial-gradient(100% 100% at ${"right"===n?"100%":"0%"} ${e}, black 38%, rgba(0,0,0,0.82) 56%, rgba(0,0,0,0.48) 72%, rgba(0,0,0,0.2) 86%, rgba(0,0,0,0.05) 94%, transparent 97%)`;
    return(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{"aria-hidden":!0,className:"pointer-events-none fixed inset-0 z-[39]",children:[(0,t.jsx)("div",{ref:x,className:"absolute top-0",style:{..."right"===n?{right:0}:{left:0},width:R,height:P,opacity:0,backdropFilter:"blur(9px)",WebkitBackdropFilter:"blur(9px)",backgroundColor:"color-mix(in srgb, var(--bg) 80%, transparent)",maskImage:O("0%"),WebkitMaskImage:O("0%")}}),(0,t.jsx)("div",{ref:w,className:"absolute bottom-0",style:{..."right"===n?{right:0}:{left:0},width:R,height:T,opacity:0,backdropFilter:"blur(9px)",WebkitBackdropFilter:"blur(9px)",backgroundColor:"color-mix(in srgb, var(--bg) 80%, transparent)",maskImage:O("100%"),WebkitMaskImage:O("100%")}})]}),(0,t.jsx)("div",{className:"pointer-events-none fixed inset-0 z-40",children:o.map((e,n)=>{
      let i=b.current[n]??={letters:[],hit:null};
      return(0,t.jsxs)(r.Fragment,{children:[(0,t.jsx)("a",{href:`#${e.id}`,ref:e=>{
        i.hit=e
        },onClick:t=>{
        t.preventDefault(),t.stopPropagation(),E[n]=performance.now()+350,k.current.armed=!1,k.current.jumping=!0;
        let r=s.lenisRef.current,i=document.getElementById(e.id),o=e.isHero?0:i?i.getBoundingClientRect().top+window.scrollY-c.NAV_H:e.anchor-c.NAV_H;
        r?r.scrollTo(o,{duration:d.read().jumpDur,easing:c.easeOutExpo,onComplete:()=>{
          k.current.jumping=!1
          }}):(window.scrollTo({top:o}),k.current.jumping=!1)
        },onPointerEnter:()=>{
        y.current=n
        },onPointerLeave:()=>{
        y.current===n&&(y.current=-1)
        },"aria-label":`Jump to ${e.label}`,className:"pointer-events-auto absolute cursor-pointer"}),!e.isHero&&e.label.split("").map((e,r)=>(0,t.jsx)("span",{ref:e=>{
        i.letters[r]=e
        },"aria-hidden":!0,className:"font-display absolute top-0 left-0 whitespace-pre text-ink-strong",style:{fontSize:N.headingPx,lineHeight:1,opacity:0,willChange:"transform, opacity",textShadow:"0 0 4px var(--bg), 0 0 10px var(--bg)"},children:e},r))]},e.id)
      })})]})
    }
  let m=["/media"];
  function g(){
    let[e,n]=(0,r.useState)(null),[f,m]=(0,r.useState)({docH:0,vh:0,vw:0}),[g,b]=(0,r.useState)(0),[x,w]=(0,r.useState)([]),y=(0,r.useRef)(null),S=(0,r.useRef)(null),E=(0,r.useRef)(null),k=(0,r.useRef)(null),N=(0,r.useRef)(null),j=(0,r.useRef)(null),C=(0,r.useRef)(null),M=(0,r.useRef)([]),R=(0,r.useRef)([]),P=(0,r.useRef)([]),T=(0,r.useRef)([]),O=(0,r.useRef)({vel:0,lastY:0,introDone:!1,prevDigits:[-1,-1,-1],prevPct:-1,readoutAbove:!1,geom:{docH:0,vh:0,vw:0},zoomIntent:!1,zoomTimer:0,zoomWrote:!1,ghostActive:!1,ghostY:0,dragStartY:0,dragMoved:0});
    O.current.geom=f,(0,r.useEffect)(()=>{
      let e=/Android|iPhone|iPad|iPod|Mobile/i.test(navigator.userAgent),t=window.matchMedia("(pointer: fine) and (hover: hover) and (min-width: 1024px)"),r=window.matchMedia("(prefers-reduced-motion: no-preference)"),i=()=>n(!e&&t.matches?r.matches?"full":"static":null);
      return i(),t.addEventListener("change",i),r.addEventListener("change",i),()=>{
        t.removeEventListener("change",i),r.removeEventListener("change",i)
        }
      },[]),(0,r.useEffect)(()=>{
      let e=O.current;
      return()=>{
        window.clearTimeout(e.zoomTimer),c.rulerZoom.target=0,c.rulerZoom.p=0,c.rulerZoom.dragging=!1
        }
      },[]),(0,r.useEffect)(()=>{
      let e,t=()=>JSON.stringify([u.read(),h.read()]),r=t(),n=a.useTunerStore.subscribe(()=>{
        let n=t();
        n!==r&&(r=n,clearTimeout(e),e=setTimeout(()=>b(e=>e+1),250))
        });
      return()=>{
        clearTimeout(e),n()
        }
      },[]);
    let L=(0,r.useMemo)(()=>u.read(),[g,e]),A=(0,r.useMemo)(()=>h.read(),[g,e]),I=L.side>=.5?"right":"left",D=L.railW;
    (0,r.useEffect)(()=>{
      if(!e)
      return;
      let t=document.documentElement;
      return t.dataset.ruler="full"===e?"on":"static",t.dataset.rulerSide=I,t.style.setProperty("--ruler-rail",`${D}px`),()=>{
        delete t.dataset.ruler,delete t.dataset.rulerSide,t.style.removeProperty("--ruler-rail")
        }
      },[e,I,D]),(0,r.useEffect)(()=>{
      if(!e)
      return;
      let t=()=>{
        let e={docH:document.documentElement.scrollHeight,vh:window.innerHeight,vw:window.innerWidth};
        m(t=>t.docH===e.docH&&t.vh===e.vh&&t.vw===e.vw?t:e)
        };
      t();
      let r=new ResizeObserver(t);
      return r.observe(document.body),window.addEventListener("resize",t),document.fonts?.ready.then(t).catch(()=>{
        }),()=>{
        r.disconnect(),window.removeEventListener("resize",t)
        }
      },[e]),(0,r.useEffect)(()=>{
      if(!e||!f.docH)
      return;
      let t=[];
      for(
      let e
       of o.RULER_SECTIONS){
        let r=document.getElementById(e.id);
        if(!r)
        continue;
        let n=r.getBoundingClientRect(),i=e.id===o.HERO_SECTION_ID,l=n.top+window.scrollY;
        t.push({id:e.id,label:e.label,index:t.length,anchor:l,bottom:n.bottom+window.scrollY,isHero:i})
        }
      w(t)
      },[e,f,g]);
    let _=(0,r.useMemo)(()=>{
      if(!e||!f.docH)
      return[];
      let t=[];
      for(
      let e=0
      ;e<=100+1e-6;e+=L.minorPct){
        let r=Math.round(100*e)/100,n=1e-6>Math.abs(r%L.labelPct);
        t.push({pct:r,docY:r/100*f.docH,major:n,alpha:n?A.majorAlpha:A.minorAlpha})
        }
      return M.current.length=t.length,R.current.length=t.length,P.current.length=t.length,t
      },[e,f.docH,L,A]);
    if((0,r.useEffect)(()=>{
      if("full"!==e||!_.length)
      return;
      let t=M.current.filter(e=>!!e);
      if(!t.length)
      return;
      let r=null,n=()=>{
        if(r?.kill(),l.introClock.done){
          i.default.set(t,{scaleX:1,opacity:1}),O.current.introDone=!0;
          return
          }
        O.current.introDone=!1;
        let e=d.read();
        i.default.set(t,{scaleX:0,opacity:0}),(r=i.default.timeline()).to({},{duration:l.introTuner.read().instrAt}),r.to(t,{scaleX:1,opacity:e=>_[e]?.alpha??.3,duration:e.introDur,stagger:e.introStagger,ease:"power3.out",overwrite:!0,onComplete:()=>{
          O.current.introDone=!0
          }}),r.timeScale(l.introClock.scale)
        };
      n();
      let o=(0,l.onIntroFast)(()=>r?.timeScale(l.introTuner.read().ffScale)),s=(0,l.onIntroReplay)(n);
      return()=>{
        o(),s(),r?.kill(),O.current.introDone=!0
        }
      },[e,_]),(0,r.useEffect)(()=>{
      if(!e||!f.docH)
      return;
      let t="full"===e,r=(e,r)=>{
        let n=O.current,{docH:i,vh:o}=n.geom;
        if(!o)
        return;
        let l=Math.min(r/1e3,.1)||.016,s=window.scrollY,a=Math.max(1,i-o),f=(0,c.clamp01)(s/a),p=(s-n.lastY)/l;
        n.lastY=s,n.vel+=(p-n.vel)*(1-Math.exp(-6*l));
        let m=(0,c.rulerMap)(o,u.read().edgePad),g=m.drift(f);
        S.current&&(S.current.style.transform=`translate3d(0, ${-s+g}px, 0)`);
        let v=h.read(),b=m.base+f*m.span;
        E.current&&(E.current.style.transform=`translate3d(0, ${b}px, 0)`,E.current.style.opacity=String((0,c.clamp01)(f/Math.max(.001,v.needleFadePct/100))));
        let x=b>o-26;
        k.current&&x!==n.readoutAbove&&(n.readoutAbove=x,k.current.style.top=x?"-14px":"4px");
        let w=Math.round(100*f);
        if(w!==n.prevPct){
          n.prevPct=w,y.current?.setAttribute("aria-valuenow",String(w));
          let e=String(w).padStart(3,"0");
          for(
          let t=0
          ;t<3;t++){
            let r=e.charCodeAt(t)-48;
            if(r!==n.prevDigits[t]){
              n.prevDigits[t]=r;
              let e=T.current[t];
              e&&(e.style.transform=`translateY(${-r}em)`)
              }
            }
          }
        let j=d.read();
        t&&(c.rulerZoom.target=n.zoomIntent||c.rulerZoom.dragging?1:0,c.rulerZoom.p+=(c.rulerZoom.target-c.rulerZoom.p)*(1-Math.exp(-j.zoomLerp*l)),0===c.rulerZoom.target&&c.rulerZoom.p<5e-4&&(c.rulerZoom.p=0),1===c.rulerZoom.target&&c.rulerZoom.p>.9995&&(c.rulerZoom.p=1));
        let L=t?c.rulerZoom.p:0;
        if(C.current){
          let e=C.current;
          e.style.transform=`translate3d(0, ${m.base+s/i*m.span}px, 0)`,e.style.height=`${o/i*m.span}px`,e.style.opacity=String(L)
          }
        if(N.current){
          let e=N.current;
          n.ghostActive?(e.style.transform=`translate3d(0, ${n.ghostY}px, 0)`,e.style.opacity=String(v.ghostAlpha*(.2+.8*L))):e.style.opacity="0"
          }
        if(t&&n.introDone&&_.length){
          let e=f*i,t=(0,c.clamp01)(Math.abs(n.vel)/3e3),r=L>0||n.zoomWrote,o=c.railOccupancy.spans;
          for(
          let n=0
          ;n<_.length;n++){
            let i=_[n].docY-s+g,l=m.base+_[n].pct/100*m.span;
            if(r){
              let e=R.current[n];
              e&&(e.style.transform=L>0?`translate3d(0, ${L*(l-i)}px, 0)`:"")
              }
            let a=P.current[n];
            if(a){
              let e=i+L*(l-i),t=1;
              if(v.yieldPad>0&&L<1)
              for(
              let r
               of o){
                let n=e<r.top?r.top-e:e>r.bottom?e-r.bottom:0;
                if(n<v.yieldPad){
                  let e=1-r.k*(1-n/v.yieldPad);
                  e<t&&(t=e)
                  }
                }
              a.style.opacity=String(v.labelAlpha*(1-(1-t)*(1-L)))
              }
            let c=M.current[n];
            if(!c)
            continue;
            let u=Math.abs(_[n].docY-e);
            if(u<j.velRadius&&j.velRadius>0){
              let e=1-u/j.velRadius,r=t*e*e;
              c.style.transform=`scaleX(${1+j.velMax*r})`,c.style.opacity=String(Math.min(1,_[n].alpha+.6*r))
              }else 
            c.style.transform="scaleX(1)",c.style.opacity=String(_[n].alpha)
            }
          n.zoomWrote=L>0
          }
        };
      return i.default.ticker.add(r),()=>{
        i.default.ticker.remove(r)
        }
      },[e,f,_]),!e||!f.docH)
    return null;
    let z="right"===I?{right:0}:{left:0},F="right"===I?"right":"left",W=e=>{
      let t=O.current;
      window.clearTimeout(t.zoomTimer);
      let r=d.read();
      t.zoomTimer=window.setTimeout(()=>{
        t.zoomIntent=e
        },e?r.zoomInDelay:r.zoomOutDelay)
      },H=e=>{
      if(!c.rulerZoom.dragging)
      return;
      c.rulerZoom.dragging=!1;
      let t=y.current?.getBoundingClientRect();
      t&&e.clientX>=t.left&&e.clientX<=t.right&&e.clientY>=t.top&&e.clientY<=t.bottom||(O.current.ghostActive=!1,W(!1))
      };
    return e?(0,t.jsxs)(t.Fragment,{children:[(0,t.jsxs)("div",{ref:y,role:"scrollbar","aria-controls":"main","aria-orientation":"vertical","aria-valuemin":0,"aria-valuemax":100,"aria-valuenow":0,"aria-label":"Page position",className:"fixed inset-y-0 z-40 cursor-crosshair overflow-hidden",style:{...z,width:D},onClick:t=>{
      !(O.current.dragMoved>4)&&((e=>{
        let t=O.current,r=(0,c.rulerMap)(t.geom.vh,u.read().edgePad),n=(0,c.clamp01)((e-r.base)/r.span)*Math.max(1,t.geom.docH-t.geom.vh),i=s.lenisRef.current;
        if(i){
          let e=d.read(),r=Math.abs(n-window.scrollY);
          i.scrollTo(n,{duration:e.jumpDur*(.4+.6*Math.min(1,r/(2.5*t.geom.vh))),easing:c.easeOutExpo})
          }else 
        window.scrollTo({top:n})
        })(t.clientY),"full"===e&&j.current&&i.default.fromTo(j.current,{opacity:1},{opacity:h.read().ghostAlpha,duration:.45}))
      },onPointerEnter:"full"===e?()=>{
      W(!0)
      }:void 0,onPointerLeave:"full"===e?()=>{
      O.current.ghostActive=!1,c.rulerZoom.dragging||W(!1)
      }:void 0,onPointerMove:"full"===e?e=>{
      let t=O.current,r=(0,c.rulerMap)(t.geom.vh,u.read().edgePad),n=Math.max(r.base,Math.min(r.base+r.span,e.clientY)),i=(0,c.clamp01)((n-r.base)/r.span);
      t.ghostActive=!0,t.ghostY=n,c.rulerZoom.dragging&&(t.dragMoved=Math.max(t.dragMoved,Math.abs(e.clientY-t.dragStartY)),s.lenisRef.current?.scrollTo(i*Math.max(1,t.geom.docH-t.geom.vh),{lerp:d.read().dragLerp}))
      }:void 0,onPointerDown:"full"===e?e=>{
      e.preventDefault();
      let t=O.current;
      t.dragStartY=e.clientY,t.dragMoved=0,c.rulerZoom.dragging=!0,e.currentTarget.setPointerCapture(e.pointerId)
      }:void 0,onPointerUp:"full"===e?H:void 0,onPointerCancel:"full"===e?H:void 0,children:[(0,t.jsx)("div",{"aria-hidden":!0,className:"absolute inset-0",style:{backdropFilter:"blur(9px)",WebkitBackdropFilter:"blur(9px)",backgroundColor:"color-mix(in srgb, var(--bg) 55%, transparent)",maskImage:v(I,A.frostSolid,A.frostGamma),WebkitMaskImage:v(I,A.frostSolid,A.frostGamma)}}),(0,t.jsx)("div",{ref:S,"aria-hidden":!0,className:"absolute inset-x-0 top-0",style:{height:f.docH},children:_.map((r,n)=>(0,t.jsxs)("div",{ref:e=>{
      R.current[n]=e
      },className:"absolute inset-x-0",style:{top:r.docY,height:0},children:[(0,t.jsx)("span",{ref:e=>{
      M.current[n]=e
      },className:"absolute block bg-ink",style:{[F]:0,top:0,width:r.major?A.majorLen:A.minorLen,height:1,opacity:"full"===e?0:r.alpha,transformOrigin:`${F} center`}}),r.major&&(0,t.jsx)("span",{ref:e=>{
      P.current[n]=e
      },className:"absolute -translate-y-1/2 font-mono text-ink",style:{[F]:A.majorLen+4,top:0,fontSize:9,letterSpacing:"0.08em",opacity:A.labelAlpha},children:r.pct})]},r.pct))}),"full"===e&&(0,t.jsxs)("div",{ref:C,"aria-hidden":!0,className:"absolute inset-x-0 top-0",style:{height:0,opacity:0},children:[(0,t.jsx)("div",{className:"absolute inset-0 bg-ink",style:{opacity:A.bracketAlpha}}),(0,t.jsx)("span",{className:"absolute inset-x-0 top-0 block bg-ink",style:{height:1,opacity:.5}}),(0,t.jsx)("span",{className:"absolute inset-x-0 bottom-0 block bg-ink",style:{height:1,opacity:.5}})]}),(0,t.jsxs)("div",{ref:E,"aria-hidden":!0,className:"absolute inset-x-0 top-0",style:{height:0},children:[(0,t.jsx)("span",{className:"absolute inset-x-0 block bg-accent",style:{top:0,height:1,boxShadow:"0 0 6px var(--accent)"}}),(0,t.jsxs)("span",{ref:k,className:"absolute whitespace-nowrap font-mono text-accent-ink",style:{[F]:2,top:4,fontSize:9,letterSpacing:"0.08em"},children:[(0,t.jsx)("span",{className:"ruler-digits",children:[0,1,2].map(e=>(0,t.jsx)("span",{ref:t=>{
      T.current[e]=t
      },className:"ruler-digit-col",children:"0123456789".split("").map(e=>(0,t.jsx)("span",{children:e},e))},e))}),(0,t.jsx)("span",{style:{marginLeft:2},children:"%"})]})]})]}),"full"===e&&(0,t.jsx)("div",{ref:N,"aria-hidden":!0,className:"pointer-events-none fixed inset-y-0 z-40",style:{...z,width:D,height:0,opacity:0,top:0},children:(0,t.jsx)("div",{ref:j,className:"absolute block bg-ink",style:{[F]:0,top:-A.ghostThick/2,width:D,height:A.ghostThick,opacity:A.ghostAlpha}})}),(0,t.jsx)(p,{mode:e,side:I,sections:x,geom:f,layoutVersion:g})]}):null
    }
  function v(e,t,r){
    let n=[`black ${t.toFixed(0)}%`];
    for(
    let e=1
    ;e<8;e++){
      let i=e/8,o=Math.pow(1-i,r),l=t+i*(100-t);
      n.push(`rgba(0,0,0,${o.toFixed(3)}) ${l.toFixed(1)}%`)
      }
    return n.push("transparent 100%"),`linear-gradient(${"right"===e?"to left":"to right"}, ${n.join(", ")})`
    }
  e.s(["default",0,function(){
    let e=(0,n.usePathname)();
    return m.some(t=>e===t||e.startsWith(`${t}/`))?null:(0,t.jsx)(g,{})
    }],54227)
  },55995,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645),n=e.i(21853);
  e.i(16787);
  var i=e.i(19455);
  let o="artcraft-tuner-ui",l={x:16,y:72,collapsed:!1,open:{}};
  function s(){
    try{
      return{...l,...JSON.parse(localStorage.getItem(o)??"{}")}
      }catch{
      return l
      }
    }
  function a(){
    let e=(0,n.useTunerStore)(e=>e.groups),i=(0,n.useTunerStore)(e=>e.resetAll),[l,a]=(0,r.useState)(s),[d,h]=(0,r.useState)(!1),f=(0,r.useRef)(null),p=e=>{
      a(e);
      try{
        localStorage.setItem(o,JSON.stringify(e))
        }catch{
        }
      },m=async()=>{
      try{
        await navigator.clipboard.writeText(JSON.stringify((0,n.tunerSnapshot)(),null,2)),h(!0),setTimeout(()=>h(!1),1200)
        }catch{
        }
      },g=Object.values(e).sort((e,t)=>e.order-t.order);
    return(0,t.jsxs)("div",{className:"fixed z-[100] w-[300px] border border-line-strong bg-bg-raised text-ink shadow-[0_8px_32px_rgba(0,0,0,0.35)] select-none",style:{left:l.x,top:l.y},children:[(0,t.jsxs)("div",{className:"flex cursor-grab items-center justify-between border-b border-line bg-bg-sunken px-3 py-2 active:cursor-grabbing",onPointerDown:e=>{
      e.target.setPointerCapture?.(e.pointerId),f.current={px:e.clientX,py:e.clientY,x:l.x,y:l.y}
      },onPointerMove:e=>{
      let t=f.current;
      t&&p({...l,x:Math.max(0,Math.min(window.innerWidth-60,t.x+e.clientX-t.px)),y:Math.max(0,Math.min(window.innerHeight-40,t.y+e.clientY-t.py))})
      },onPointerUp:()=>{
      f.current=null
      },children:[(0,t.jsx)("p",{className:"hud-label font-bold",children:"Tuner"}),(0,t.jsxs)("div",{className:"flex items-center gap-1",children:[(0,n.getTunerActions)().map(e=>(0,t.jsx)(c,{onClick:e.run,label:e.label},e.label)),(0,t.jsx)(c,{onClick:m,label:d?"Copied":"Copy"}),(0,t.jsx)(c,{onClick:i,label:"Reset"}),(0,t.jsx)(c,{onClick:()=>p({...l,collapsed:!l.collapsed}),label:l.collapsed?"+":"–"})]})]}),!l.collapsed&&(0,t.jsxs)("div",{className:"max-h-[70vh] overflow-y-auto",children:[0===g.length&&(0,t.jsx)("p",{className:"hud-label px-3 py-4 text-faint",children:"No tunables registered"}),g.map(e=>(0,t.jsx)(u,{group:e,open:l.open[e.id]??!1,onToggle:()=>p({...l,open:{...l.open,[e.id]:!l.open[e.id]}})},e.id))]})]})
    }
  function c({onClick:e,label:r}){
    return(0,t.jsx)(i.Button,{variant:"ghost",size:"sm",onClick:e,onPointerDown:e=>e.stopPropagation(),className:"min-w-[44px] border border-line px-1.5 py-0.5 text-[10px] font-medium",children:r})
    }
  function u({group:e,open:i,onToggle:o}){
    let[l,s]=(0,r.useState)(!1);
    return(0,t.jsxs)("div",{className:"border-b border-line last:border-b-0",children:[(0,t.jsxs)("div",{className:"flex items-center",children:[(0,t.jsxs)("button",{type:"button",onClick:o,className:"hud-label flex min-w-0 flex-1 items-center justify-between px-3 py-2 text-muted hover:text-ink","aria-expanded":i,children:[e.title,(0,t.jsx)("span",{"aria-hidden":!0,className:"text-faint",children:i?"–":"+"})]}),(0,t.jsx)("button",{type:"button",onClick:()=>{
      let t=(0,n.tunerSnapshot)()[e.id];
      navigator.clipboard?.writeText(JSON.stringify({[e.id]:t},null,2)).then(()=>{
        s(!0),setTimeout(()=>s(!1),1200)
        }).catch(()=>{
        })
      },title:`Copy ${e.title} values`,className:"hud-label px-1.5 py-2 text-faint hover:text-ink",children:l?"✓":"⧉"}),(0,t.jsx)("button",{type:"button",onClick:()=>n.useTunerStore.getState().resetGroup(e.id),title:`Reset ${e.title} to defaults`,className:"hud-label pr-3 pl-1.5 py-2 text-faint hover:text-ink",children:"↺"})]}),i&&(0,t.jsx)("div",{className:"flex flex-col gap-2 px-3 pb-3",children:Object.entries(e.defs).map(([r,n])=>(0,t.jsx)(d,{groupId:e.id,tunableKey:r,def:n},r))})]})
    }
  function d({groupId:e,tunableKey:i,def:o}){
    let l=`${e}.${i}`,s=(0,n.useTunerStore)(e=>e.values[l]??o.default),a=(0,n.useTunerStore)(e=>e.setValue),c=s!==o.default,[u,h]=(0,r.useState)(!1);
    return(0,t.jsxs)("label",{className:"flex flex-col gap-1",children:[(0,t.jsxs)("span",{className:"relative flex items-center justify-between",children:[(0,t.jsxs)("span",{className:`flex items-center gap-1 font-mono text-[10px] tracking-[0.08em] uppercase ${c?"text-accent-ink":"text-muted"}`,children:[o.label,o.info&&(0,t.jsx)("span",{"aria-label":o.info,onMouseEnter:()=>h(!0),onMouseLeave:()=>h(!1),onClick:e=>e.preventDefault(),onPointerDown:e=>e.preventDefault(),className:"inline-flex h-3 w-3 cursor-help items-center justify-center border border-line text-[8px] leading-none text-faint normal-case",children:"i"})]}),o.info&&u&&(0,t.jsx)("span",{className:"pointer-events-none absolute inset-x-0 top-full z-10 mt-1 border border-line-strong bg-bg-raised p-2 font-mono text-[10px] leading-snug tracking-normal normal-case text-ink shadow-[0_4px_16px_rgba(0,0,0,0.3)]",children:o.info}),(0,t.jsx)("input",{type:"number",value:Math.round(1e4*s)/1e4,min:o.min,max:o.max,step:o.step,onChange:t=>{
      let r=Number(t.target.value);
      Number.isNaN(r)||a(e,i,r)
      },className:"w-[72px] border border-line bg-bg px-1 py-0.5 text-right font-mono text-[11px] text-ink focus:outline-none focus:border-line-strong"})]}),(0,t.jsx)("input",{type:"range",value:s,min:o.min,max:o.max,step:o.step,onChange:t=>a(e,i,Number(t.target.value)),className:"h-1 w-full cursor-ew-resize accent-[var(--accent)]"})]})
    }
  e.s(["default",0,function(){
    let[e,n]=(0,r.useState)(!1);
    return((0,r.useEffect)(()=>{
      n(new URLSearchParams(window.location.search).has("tuner"))
      },[]),e)?(0,t.jsx)(a,{}):null
    }])
  }]);
