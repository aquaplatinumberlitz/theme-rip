(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,19056,e=>{
  "use strict";
  var r;
  let t,o,n,a,l,s=(e=new Map,r=null,t)=>({nextPart:e,validators:r,classGroupId:t}),i=[],c=(e,r,t)=>{
    if(0==e.length-r)
    return t.classGroupId;
    let o=e[r],n=t.nextPart.get(o);
    if(n){
      let t=c(e,r+1,n);
      if(t)
      return t
      }
    let a=t.validators;
    if(null===a)
    return;
    let l=0===r?e.join("-"):e.slice(r).join("-"),s=a.length;
    for(
    let e=0
    ;e<s;e++){
      let r=a[e];
      if(r.validator(l))
      return r.classGroupId
      }
    },d=(e,r)=>{
    let t=s();
    for(
    let o
     in e)
    m(e[o],t,o,r);
    return t
    },m=(e,r,t,o)=>{
    let n=e.length;
    for(
    let a=0
    ;a<n;a++)
    u(e[a],r,t,o)
    },u=(e,r,t,o)=>{
    "string"==typeof e?p(e,r,t):"function"==typeof e?b(e,r,t,o):f(e,r,t,o)
    },p=(e,r,t)=>{
    (""===e?r:g(r,e)).classGroupId=t
    },b=(e,r,t,o)=>{
    h(e)?m(e(o),r,t,o):(null===r.validators&&(r.validators=[]),r.validators.push({classGroupId:t,validator:e}))
    },f=(e,r,t,o)=>{
    let n=Object.entries(e),a=n.length;
    for(
    let e=0
    ;e<a;e++){
      let[a,l]=n[e];
      m(l,g(r,a),t,o)
      }
    },g=(e,r)=>{
    let t=e,o=r.split("-"),n=o.length;
    for(
    let e=0
    ;e<n;e++){
      let r=o[e],n=t.nextPart.get(r);
      n||(n=s(),t.nextPart.set(r,n)),t=n
      }
    return t
    },h=e=>"isThemeGetter"in e&&!0===e.isThemeGetter,x=[],w=(e,r,t,o,n)=>({modifiers:e,hasImportantModifier:r,baseClassName:t,maybePostfixModifierPosition:o,isExternal:n}),v=/\s+/,k=e=>{
    let r;
    if("string"==typeof e)
    return e;
    let t="";
    for(
    let o=0
    ;o<e.length;o++)
    e[o]&&(r=k(e[o]))&&(t&&(t+=" "),t+=r);
    return t
    },y=[],z=e=>{
    let r=r=>r[e]||y;
    return r.isThemeGetter=!0,r
    },j=/^\[(?:(\w[\w-]*):)?(.+)\]$/i,N=/^\((?:(\w[\w-]*):)?(.+)\)$/i,C=/^\d+(?:\.\d+)?\/\d+(?:\.\d+)?$/,M=/^(\d+(\.\d+)?)?(xs|sm|md|lg|xl)$/,I=/\d+(%|px|r?em|[sdl]?v([hwib]|min|max)|pt|pc|in|cm|mm|cap|ch|ex|r?lh|cq(w|h|i|b|min|max))|\b(calc|min|max|clamp)\(.+\)|^0$/,E=/^(rgba?|hsla?|hwb|(ok)?(lab|lch)|color-mix)\(.+\)$/,T=/^(inset_)?-?((\d+)?\.?(\d+)[a-z]+|0)_-?((\d+)?\.?(\d+)[a-z]+|0)/,S=/^(url|image|image-set|cross-fade|element|(repeating-)?(linear|radial|conic)-gradient)\(.+\)$/,G=e=>C.test(e),L=e=>!!e&&!Number.isNaN(Number(e)),W=e=>!!e&&Number.isInteger(Number(e)),D=e=>e.endsWith("%")&&L(e.slice(0,-1)),O=e=>M.test(e),P=()=>!0,$=e=>I.test(e)&&!E.test(e),A=()=>!1,B=e=>T.test(e),F=e=>S.test(e),R=e=>!U(e)&&!Z(e),q=e=>e.startsWith("@container")&&("/"===e[10]&&void 0!==e[11]||"s"===e[11]&&void 0!==e[16]&&e.startsWith("-size/",10)||"n"===e[11]&&void 0!==e[18]&&e.startsWith("-normal/",10)),K=e=>es(e,em,A),U=e=>j.test(e),_=e=>es(e,eu,$),H=e=>es(e,ep,L),V=e=>es(e,ef,P),X=e=>es(e,eb,A),J=e=>es(e,ec,A),Q=e=>es(e,ed,F),Y=e=>es(e,eg,B),Z=e=>N.test(e),ee=e=>ei(e,eu),er=e=>ei(e,eb),et=e=>ei(e,ec),eo=e=>ei(e,em),en=e=>ei(e,ed),ea=e=>ei(e,eg,!0),el=e=>ei(e,ef,!0),es=(e,r,t)=>{
    let o=j.exec(e);
    return!!o&&(o[1]?r(o[1]):t(o[2]))
    },ei=(e,r,t=!1)=>{
    let o=N.exec(e);
    return!!o&&(o[1]?r(o[1]):t)
    },ec=e=>"position"===e||"percentage"===e,ed=e=>"image"===e||"url"===e,em=e=>"length"===e||"size"===e||"bg-size"===e,eu=e=>"length"===e,ep=e=>"number"===e,eb=e=>"family-name"===e,ef=e=>"number"===e||"weight"===e,eg=e=>"shadow"===e,eh=(r=()=>{
    let e=z("color"),r=z("font"),t=z("text"),o=z("font-weight"),n=z("tracking"),a=z("leading"),l=z("breakpoint"),s=z("container"),i=z("spacing"),c=z("radius"),d=z("shadow"),m=z("inset-shadow"),u=z("text-shadow"),p=z("drop-shadow"),b=z("blur"),f=z("perspective"),g=z("aspect"),h=z("ease"),x=z("animate"),w=()=>["auto","avoid","all","avoid-page","page","left","right","column"],v=()=>["center","top","bottom","left","right","top-left","left-top","top-right","right-top","bottom-right","right-bottom","bottom-left","left-bottom"],k=()=>[...v(),Z,U],y=()=>["auto","hidden","clip","visible","scroll"],j=()=>["auto","contain","none"],N=()=>[Z,U,i],C=()=>[G,"full","auto",...N()],M=()=>[W,"none","subgrid",Z,U],I=()=>["auto",{span:["full",W,Z,U]},W,Z,U],E=()=>[W,"auto",Z,U],T=()=>["auto","min","max","fr",Z,U],S=()=>["start","end","center","between","around","evenly","stretch","baseline","center-safe","end-safe"],$=()=>["start","end","center","stretch","center-safe","end-safe"],A=()=>["auto",...N()],B=()=>[G,"auto","full","dvw","dvh","lvw","lvh","svw","svh","min","max","fit",...N()],F=()=>[G,"screen","full","dvw","lvw","svw","min","max","fit",...N()],es=()=>[G,"screen","full","lh","dvh","lvh","svh","min","max","fit",...N()],ei=()=>[e,Z,U],ec=()=>[...v(),et,J,{position:[Z,U]}],ed=()=>["no-repeat",{repeat:["","x","y","space","round"]}],em=()=>["auto","cover","contain",eo,K,{size:[Z,U]}],eu=()=>[D,ee,_],ep=()=>["","none","full",c,Z,U],eb=()=>["",L,ee,_],ef=()=>["solid","dashed","dotted","double"],eg=()=>["normal","multiply","screen","overlay","darken","lighten","color-dodge","color-burn","hard-light","soft-light","difference","exclusion","hue","saturation","color","luminosity"],eh=()=>[L,D,et,J],ex=()=>["","none",b,Z,U],ew=()=>["none",L,Z,U],ev=()=>["none",L,Z,U],ek=()=>[L,Z,U],ey=()=>[G,"full",...N()];
    return{cacheSize:500,theme:{animate:["spin","ping","pulse","bounce"],aspect:["video"],blur:[O],breakpoint:[O],color:[P],container:[O],"drop-shadow":[O],ease:["in","out","in-out"],font:[R],"font-weight":["thin","extralight","light","normal","medium","semibold","bold","extrabold","black"],"inset-shadow":[O],leading:["none","tight","snug","normal","relaxed","loose"],perspective:["dramatic","near","normal","midrange","distant","none"],radius:[O],shadow:[O],spacing:["px",L],text:[O],"text-shadow":[O],tracking:["tighter","tight","normal","wide","wider","widest"]},classGroups:{aspect:[{aspect:["auto","square",G,U,Z,g]}],container:["container"],"container-type":[{"@container":["","normal","size",Z,U]}],"container-named":[q],columns:[{columns:[L,U,Z,s]}],"break-after":[{"break-after":w()}],"break-before":[{"break-before":w()}],"break-inside":[{"break-inside":["auto","avoid","avoid-page","avoid-column"]}],"box-decoration":[{"box-decoration":["slice","clone"]}],box:[{box:["border","content"]}],display:["block","inline-block","inline","flex","inline-flex","table","inline-table","table-caption","table-cell","table-column","table-column-group","table-footer-group","table-header-group","table-row-group","table-row","flow-root","grid","inline-grid","contents","list-item","hidden"],sr:["sr-only","not-sr-only"],float:[{float:["right","left","none","start","end"]}],clear:[{clear:["left","right","both","none","start","end"]}],isolation:["isolate","isolation-auto"],"object-fit":[{object:["contain","cover","fill","none","scale-down"]}],"object-position":[{object:k()}],overflow:[{overflow:y()}],"overflow-x":[{"overflow-x":y()}],"overflow-y":[{"overflow-y":y()}],overscroll:[{overscroll:j()}],"overscroll-x":[{"overscroll-x":j()}],"overscroll-y":[{"overscroll-y":j()}],position:["static","fixed","absolute","relative","sticky"],inset:[{inset:C()}],"inset-x":[{"inset-x":C()}],"inset-y":[{"inset-y":C()}],start:[{"inset-s":C(),start:C()}],end:[{"inset-e":C(),end:C()}],"inset-bs":[{"inset-bs":C()}],"inset-be":[{"inset-be":C()}],top:[{top:C()}],right:[{right:C()}],bottom:[{bottom:C()}],left:[{left:C()}],visibility:["visible","invisible","collapse"],z:[{z:[W,"auto",Z,U]}],basis:[{basis:[G,"full","auto",s,...N()]}],"flex-direction":[{flex:["row","row-reverse","col","col-reverse"]}],"flex-wrap":[{flex:["nowrap","wrap","wrap-reverse"]}],flex:[{flex:[L,G,"auto","initial","none",U]}],grow:[{grow:["",L,Z,U]}],shrink:[{shrink:["",L,Z,U]}],order:[{order:[W,"first","last","none",Z,U]}],"grid-cols":[{"grid-cols":M()}],"col-start-end":[{col:I()}],"col-start":[{"col-start":E()}],"col-end":[{"col-end":E()}],"grid-rows":[{"grid-rows":M()}],"row-start-end":[{row:I()}],"row-start":[{"row-start":E()}],"row-end":[{"row-end":E()}],"grid-flow":[{"grid-flow":["row","col","dense","row-dense","col-dense"]}],"auto-cols":[{"auto-cols":T()}],"auto-rows":[{"auto-rows":T()}],gap:[{gap:N()}],"gap-x":[{"gap-x":N()}],"gap-y":[{"gap-y":N()}],"justify-content":[{justify:[...S(),"normal"]}],"justify-items":[{"justify-items":[...$(),"normal"]}],"justify-self":[{"justify-self":["auto",...$()]}],"align-content":[{content:["normal",...S()]}],"align-items":[{items:[...$(),{baseline:["","last"]}]}],"align-self":[{self:["auto",...$(),{baseline:["","last"]}]}],"place-content":[{"place-content":S()}],"place-items":[{"place-items":[...$(),"baseline"]}],"place-self":[{"place-self":["auto",...$()]}],p:[{p:N()}],px:[{px:N()}],py:[{py:N()}],ps:[{ps:N()}],pe:[{pe:N()}],pbs:[{pbs:N()}],pbe:[{pbe:N()}],pt:[{pt:N()}],pr:[{pr:N()}],pb:[{pb:N()}],pl:[{pl:N()}],m:[{m:A()}],mx:[{mx:A()}],my:[{my:A()}],ms:[{ms:A()}],me:[{me:A()}],mbs:[{mbs:A()}],mbe:[{mbe:A()}],mt:[{mt:A()}],mr:[{mr:A()}],mb:[{mb:A()}],ml:[{ml:A()}],"space-x":[{"space-x":N()}],"space-x-reverse":["space-x-reverse"],"space-y":[{"space-y":N()}],"space-y-reverse":["space-y-reverse"],size:[{size:B()}],"inline-size":[{inline:["auto",...F()]}],"min-inline-size":[{"min-inline":["auto",...F()]}],"max-inline-size":[{"max-inline":["none",...F()]}],"block-size":[{block:["auto",...es()]}],"min-block-size":[{"min-block":["auto",...es()]}],"max-block-size":[{"max-block":["none",...es()]}],w:[{w:[s,"screen",...B()]}],"min-w":[{"min-w":[s,"screen","none",...B()]}],"max-w":[{"max-w":[s,"screen","none","prose",{screen:[l]},...B()]}],h:[{h:["screen","lh",...B()]}],"min-h":[{"min-h":["screen","lh","none",...B()]}],"max-h":[{"max-h":["screen","lh",...B()]}],"font-size":[{text:["base",t,ee,_]}],"font-smoothing":["antialiased","subpixel-antialiased"],"font-style":["italic","not-italic"],"font-weight":[{font:[o,el,V]}],"font-stretch":[{"font-stretch":["ultra-condensed","extra-condensed","condensed","semi-condensed","normal","semi-expanded","expanded","extra-expanded","ultra-expanded",D,U]}],"font-family":[{font:[er,X,r]}],"font-features":[{"font-features":[U]}],"fvn-normal":["normal-nums"],"fvn-ordinal":["ordinal"],"fvn-slashed-zero":["slashed-zero"],"fvn-figure":["lining-nums","oldstyle-nums"],"fvn-spacing":["proportional-nums","tabular-nums"],"fvn-fraction":["diagonal-fractions","stacked-fractions"],tracking:[{tracking:[n,Z,U]}],"line-clamp":[{"line-clamp":[L,"none",Z,H]}],leading:[{leading:[a,...N()]}],"list-image":[{"list-image":["none",Z,U]}],"list-style-position":[{list:["inside","outside"]}],"list-style-type":[{list:["disc","decimal","none",Z,U]}],"text-alignment":[{text:["left","center","right","justify","start","end"]}],"placeholder-color":[{placeholder:ei()}],"text-color":[{text:ei()}],"text-decoration":["underline","overline","line-through","no-underline"],"text-decoration-style":[{decoration:[...ef(),"wavy"]}],"text-decoration-thickness":[{decoration:[L,"from-font","auto",Z,_]}],"text-decoration-color":[{decoration:ei()}],"underline-offset":[{"underline-offset":[L,"auto",Z,U]}],"text-transform":["uppercase","lowercase","capitalize","normal-case"],"text-overflow":["truncate","text-ellipsis","text-clip"],"text-wrap":[{text:["wrap","nowrap","balance","pretty"]}],indent:[{indent:N()}],"tab-size":[{tab:[W,Z,U]}],"vertical-align":[{align:["baseline","top","middle","bottom","text-top","text-bottom","sub","super",Z,U]}],whitespace:[{whitespace:["normal","nowrap","pre","pre-line","pre-wrap","break-spaces"]}],break:[{break:["normal","words","all","keep"]}],wrap:[{wrap:["break-word","anywhere","normal"]}],hyphens:[{hyphens:["none","manual","auto"]}],content:[{content:["none",Z,U]}],"bg-attachment":[{bg:["fixed","local","scroll"]}],"bg-clip":[{"bg-clip":["border","padding","content","text"]}],"bg-origin":[{"bg-origin":["border","padding","content"]}],"bg-position":[{bg:ec()}],"bg-repeat":[{bg:ed()}],"bg-size":[{bg:em()}],"bg-image":[{bg:["none",{linear:[{to:["t","tr","r","br","b","bl","l","tl"]},W,Z,U],radial:["",Z,U],conic:[W,Z,U]},en,Q]}],"bg-color":[{bg:ei()}],"gradient-from-pos":[{from:eu()}],"gradient-via-pos":[{via:eu()}],"gradient-to-pos":[{to:eu()}],"gradient-from":[{from:ei()}],"gradient-via":[{via:ei()}],"gradient-to":[{to:ei()}],rounded:[{rounded:ep()}],"rounded-s":[{"rounded-s":ep()}],"rounded-e":[{"rounded-e":ep()}],"rounded-t":[{"rounded-t":ep()}],"rounded-r":[{"rounded-r":ep()}],"rounded-b":[{"rounded-b":ep()}],"rounded-l":[{"rounded-l":ep()}],"rounded-ss":[{"rounded-ss":ep()}],"rounded-se":[{"rounded-se":ep()}],"rounded-ee":[{"rounded-ee":ep()}],"rounded-es":[{"rounded-es":ep()}],"rounded-tl":[{"rounded-tl":ep()}],"rounded-tr":[{"rounded-tr":ep()}],"rounded-br":[{"rounded-br":ep()}],"rounded-bl":[{"rounded-bl":ep()}],"border-w":[{border:eb()}],"border-w-x":[{"border-x":eb()}],"border-w-y":[{"border-y":eb()}],"border-w-s":[{"border-s":eb()}],"border-w-e":[{"border-e":eb()}],"border-w-bs":[{"border-bs":eb()}],"border-w-be":[{"border-be":eb()}],"border-w-t":[{"border-t":eb()}],"border-w-r":[{"border-r":eb()}],"border-w-b":[{"border-b":eb()}],"border-w-l":[{"border-l":eb()}],"divide-x":[{"divide-x":eb()}],"divide-x-reverse":["divide-x-reverse"],"divide-y":[{"divide-y":eb()}],"divide-y-reverse":["divide-y-reverse"],"border-style":[{border:[...ef(),"hidden","none"]}],"divide-style":[{divide:[...ef(),"hidden","none"]}],"border-color":[{border:ei()}],"border-color-x":[{"border-x":ei()}],"border-color-y":[{"border-y":ei()}],"border-color-s":[{"border-s":ei()}],"border-color-e":[{"border-e":ei()}],"border-color-bs":[{"border-bs":ei()}],"border-color-be":[{"border-be":ei()}],"border-color-t":[{"border-t":ei()}],"border-color-r":[{"border-r":ei()}],"border-color-b":[{"border-b":ei()}],"border-color-l":[{"border-l":ei()}],"divide-color":[{divide:ei()}],"outline-style":[{outline:[...ef(),"none","hidden"]}],"outline-offset":[{"outline-offset":[L,Z,U]}],"outline-w":[{outline:["",L,ee,_]}],"outline-color":[{outline:ei()}],shadow:[{shadow:["","none",d,ea,Y]}],"shadow-color":[{shadow:ei()}],"inset-shadow":[{"inset-shadow":["none",m,ea,Y]}],"inset-shadow-color":[{"inset-shadow":ei()}],"ring-w":[{ring:eb()}],"ring-w-inset":["ring-inset"],"ring-color":[{ring:ei()}],"ring-offset-w":[{"ring-offset":[L,_]}],"ring-offset-color":[{"ring-offset":ei()}],"inset-ring-w":[{"inset-ring":eb()}],"inset-ring-color":[{"inset-ring":ei()}],"text-shadow":[{"text-shadow":["none",u,ea,Y]}],"text-shadow-color":[{"text-shadow":ei()}],opacity:[{opacity:[L,Z,U]}],"mix-blend":[{"mix-blend":[...eg(),"plus-darker","plus-lighter"]}],"bg-blend":[{"bg-blend":eg()}],"mask-clip":[{"mask-clip":["border","padding","content","fill","stroke","view"]},"mask-no-clip"],"mask-composite":[{mask:["add","subtract","intersect","exclude"]}],"mask-image-linear-pos":[{"mask-linear":[L]}],"mask-image-linear-from-pos":[{"mask-linear-from":eh()}],"mask-image-linear-to-pos":[{"mask-linear-to":eh()}],"mask-image-linear-from-color":[{"mask-linear-from":ei()}],"mask-image-linear-to-color":[{"mask-linear-to":ei()}],"mask-image-t-from-pos":[{"mask-t-from":eh()}],"mask-image-t-to-pos":[{"mask-t-to":eh()}],"mask-image-t-from-color":[{"mask-t-from":ei()}],"mask-image-t-to-color":[{"mask-t-to":ei()}],"mask-image-r-from-pos":[{"mask-r-from":eh()}],"mask-image-r-to-pos":[{"mask-r-to":eh()}],"mask-image-r-from-color":[{"mask-r-from":ei()}],"mask-image-r-to-color":[{"mask-r-to":ei()}],"mask-image-b-from-pos":[{"mask-b-from":eh()}],"mask-image-b-to-pos":[{"mask-b-to":eh()}],"mask-image-b-from-color":[{"mask-b-from":ei()}],"mask-image-b-to-color":[{"mask-b-to":ei()}],"mask-image-l-from-pos":[{"mask-l-from":eh()}],"mask-image-l-to-pos":[{"mask-l-to":eh()}],"mask-image-l-from-color":[{"mask-l-from":ei()}],"mask-image-l-to-color":[{"mask-l-to":ei()}],"mask-image-x-from-pos":[{"mask-x-from":eh()}],"mask-image-x-to-pos":[{"mask-x-to":eh()}],"mask-image-x-from-color":[{"mask-x-from":ei()}],"mask-image-x-to-color":[{"mask-x-to":ei()}],"mask-image-y-from-pos":[{"mask-y-from":eh()}],"mask-image-y-to-pos":[{"mask-y-to":eh()}],"mask-image-y-from-color":[{"mask-y-from":ei()}],"mask-image-y-to-color":[{"mask-y-to":ei()}],"mask-image-radial":[{"mask-radial":[Z,U]}],"mask-image-radial-from-pos":[{"mask-radial-from":eh()}],"mask-image-radial-to-pos":[{"mask-radial-to":eh()}],"mask-image-radial-from-color":[{"mask-radial-from":ei()}],"mask-image-radial-to-color":[{"mask-radial-to":ei()}],"mask-image-radial-shape":[{"mask-radial":["circle","ellipse"]}],"mask-image-radial-size":[{"mask-radial":[{closest:["side","corner"],farthest:["side","corner"]}]}],"mask-image-radial-pos":[{"mask-radial-at":v()}],"mask-image-conic-pos":[{"mask-conic":[L]}],"mask-image-conic-from-pos":[{"mask-conic-from":eh()}],"mask-image-conic-to-pos":[{"mask-conic-to":eh()}],"mask-image-conic-from-color":[{"mask-conic-from":ei()}],"mask-image-conic-to-color":[{"mask-conic-to":ei()}],"mask-mode":[{mask:["alpha","luminance","match"]}],"mask-origin":[{"mask-origin":["border","padding","content","fill","stroke","view"]}],"mask-position":[{mask:ec()}],"mask-repeat":[{mask:ed()}],"mask-size":[{mask:em()}],"mask-type":[{"mask-type":["alpha","luminance"]}],"mask-image":[{mask:["none",Z,U]}],filter:[{filter:["","none",Z,U]}],blur:[{blur:ex()}],brightness:[{brightness:[L,Z,U]}],contrast:[{contrast:[L,Z,U]}],"drop-shadow":[{"drop-shadow":["","none",p,ea,Y]}],"drop-shadow-color":[{"drop-shadow":ei()}],grayscale:[{grayscale:["",L,Z,U]}],"hue-rotate":[{"hue-rotate":[L,Z,U]}],invert:[{invert:["",L,Z,U]}],saturate:[{saturate:[L,Z,U]}],sepia:[{sepia:["",L,Z,U]}],"backdrop-filter":[{"backdrop-filter":["","none",Z,U]}],"backdrop-blur":[{"backdrop-blur":ex()}],"backdrop-brightness":[{"backdrop-brightness":[L,Z,U]}],"backdrop-contrast":[{"backdrop-contrast":[L,Z,U]}],"backdrop-grayscale":[{"backdrop-grayscale":["",L,Z,U]}],"backdrop-hue-rotate":[{"backdrop-hue-rotate":[L,Z,U]}],"backdrop-invert":[{"backdrop-invert":["",L,Z,U]}],"backdrop-opacity":[{"backdrop-opacity":[L,Z,U]}],"backdrop-saturate":[{"backdrop-saturate":[L,Z,U]}],"backdrop-sepia":[{"backdrop-sepia":["",L,Z,U]}],"border-collapse":[{border:["collapse","separate"]}],"border-spacing":[{"border-spacing":N()}],"border-spacing-x":[{"border-spacing-x":N()}],"border-spacing-y":[{"border-spacing-y":N()}],"table-layout":[{table:["auto","fixed"]}],caption:[{caption:["top","bottom"]}],transition:[{transition:["","all","colors","opacity","shadow","transform","none",Z,U]}],"transition-behavior":[{transition:["normal","discrete"]}],duration:[{duration:[L,"initial",Z,U]}],ease:[{ease:["linear","initial",h,Z,U]}],delay:[{delay:[L,Z,U]}],animate:[{animate:["none",x,Z,U]}],backface:[{backface:["hidden","visible"]}],perspective:[{perspective:[f,Z,U]}],"perspective-origin":[{"perspective-origin":k()}],rotate:[{rotate:ew()}],"rotate-x":[{"rotate-x":ew()}],"rotate-y":[{"rotate-y":ew()}],"rotate-z":[{"rotate-z":ew()}],scale:[{scale:ev()}],"scale-x":[{"scale-x":ev()}],"scale-y":[{"scale-y":ev()}],"scale-z":[{"scale-z":ev()}],"scale-3d":["scale-3d"],skew:[{skew:ek()}],"skew-x":[{"skew-x":ek()}],"skew-y":[{"skew-y":ek()}],transform:[{transform:[Z,U,"","none","gpu","cpu"]}],"transform-origin":[{origin:k()}],"transform-style":[{transform:["3d","flat"]}],translate:[{translate:ey()}],"translate-x":[{"translate-x":ey()}],"translate-y":[{"translate-y":ey()}],"translate-z":[{"translate-z":ey()}],"translate-none":["translate-none"],zoom:[{zoom:[W,Z,U]}],accent:[{accent:ei()}],appearance:[{appearance:["none","auto"]}],"caret-color":[{caret:ei()}],"color-scheme":[{scheme:["normal","dark","light","light-dark","only-dark","only-light"]}],cursor:[{cursor:["auto","default","pointer","wait","text","move","help","not-allowed","none","context-menu","progress","cell","crosshair","vertical-text","alias","copy","no-drop","grab","grabbing","all-scroll","col-resize","row-resize","n-resize","e-resize","s-resize","w-resize","ne-resize","nw-resize","se-resize","sw-resize","ew-resize","ns-resize","nesw-resize","nwse-resize","zoom-in","zoom-out",Z,U]}],"field-sizing":[{"field-sizing":["fixed","content"]}],"pointer-events":[{"pointer-events":["auto","none"]}],resize:[{resize:["none","","y","x"]}],"scroll-behavior":[{scroll:["auto","smooth"]}],"scrollbar-thumb-color":[{"scrollbar-thumb":ei()}],"scrollbar-track-color":[{"scrollbar-track":ei()}],"scrollbar-gutter":[{"scrollbar-gutter":["auto","stable","both"]}],"scrollbar-w":[{scrollbar:["auto","thin","none"]}],"scroll-m":[{"scroll-m":N()}],"scroll-mx":[{"scroll-mx":N()}],"scroll-my":[{"scroll-my":N()}],"scroll-ms":[{"scroll-ms":N()}],"scroll-me":[{"scroll-me":N()}],"scroll-mbs":[{"scroll-mbs":N()}],"scroll-mbe":[{"scroll-mbe":N()}],"scroll-mt":[{"scroll-mt":N()}],"scroll-mr":[{"scroll-mr":N()}],"scroll-mb":[{"scroll-mb":N()}],"scroll-ml":[{"scroll-ml":N()}],"scroll-p":[{"scroll-p":N()}],"scroll-px":[{"scroll-px":N()}],"scroll-py":[{"scroll-py":N()}],"scroll-ps":[{"scroll-ps":N()}],"scroll-pe":[{"scroll-pe":N()}],"scroll-pbs":[{"scroll-pbs":N()}],"scroll-pbe":[{"scroll-pbe":N()}],"scroll-pt":[{"scroll-pt":N()}],"scroll-pr":[{"scroll-pr":N()}],"scroll-pb":[{"scroll-pb":N()}],"scroll-pl":[{"scroll-pl":N()}],"snap-align":[{snap:["start","end","center","align-none"]}],"snap-stop":[{snap:["normal","always"]}],"snap-type":[{snap:["none","x","y","both"]}],"snap-strictness":[{snap:["mandatory","proximity"]}],touch:[{touch:["auto","none","manipulation"]}],"touch-x":[{"touch-pan":["x","left","right"]}],"touch-y":[{"touch-pan":["y","up","down"]}],"touch-pz":["touch-pinch-zoom"],select:[{select:["none","text","all","auto"]}],"will-change":[{"will-change":["auto","scroll","contents","transform",Z,U]}],fill:[{fill:["none",...ei()]}],"stroke-w":[{stroke:[L,ee,_,H]}],stroke:[{stroke:["none",...ei()]}],"forced-color-adjust":[{"forced-color-adjust":["auto","none"]}]},conflictingClassGroups:{"container-named":["container-type"],overflow:["overflow-x","overflow-y"],overscroll:["overscroll-x","overscroll-y"],inset:["inset-x","inset-y","inset-bs","inset-be","start","end","top","right","bottom","left"],"inset-x":["right","left"],"inset-y":["top","bottom"],flex:["basis","grow","shrink"],gap:["gap-x","gap-y"],p:["px","py","ps","pe","pbs","pbe","pt","pr","pb","pl"],px:["pr","pl"],py:["pt","pb"],m:["mx","my","ms","me","mbs","mbe","mt","mr","mb","ml"],mx:["mr","ml"],my:["mt","mb"],size:["w","h"],"font-size":["leading"],"fvn-normal":["fvn-ordinal","fvn-slashed-zero","fvn-figure","fvn-spacing","fvn-fraction"],"fvn-ordinal":["fvn-normal"],"fvn-slashed-zero":["fvn-normal"],"fvn-figure":["fvn-normal"],"fvn-spacing":["fvn-normal"],"fvn-fraction":["fvn-normal"],"line-clamp":["display","overflow"],rounded:["rounded-s","rounded-e","rounded-t","rounded-r","rounded-b","rounded-l","rounded-ss","rounded-se","rounded-ee","rounded-es","rounded-tl","rounded-tr","rounded-br","rounded-bl"],"rounded-s":["rounded-ss","rounded-es"],"rounded-e":["rounded-se","rounded-ee"],"rounded-t":["rounded-tl","rounded-tr"],"rounded-r":["rounded-tr","rounded-br"],"rounded-b":["rounded-br","rounded-bl"],"rounded-l":["rounded-tl","rounded-bl"],"border-spacing":["border-spacing-x","border-spacing-y"],"border-w":["border-w-x","border-w-y","border-w-s","border-w-e","border-w-bs","border-w-be","border-w-t","border-w-r","border-w-b","border-w-l"],"border-w-x":["border-w-r","border-w-l"],"border-w-y":["border-w-t","border-w-b"],"border-color":["border-color-x","border-color-y","border-color-s","border-color-e","border-color-bs","border-color-be","border-color-t","border-color-r","border-color-b","border-color-l"],"border-color-x":["border-color-r","border-color-l"],"border-color-y":["border-color-t","border-color-b"],translate:["translate-x","translate-y","translate-none"],"translate-none":["translate","translate-x","translate-y","translate-z"],"scroll-m":["scroll-mx","scroll-my","scroll-ms","scroll-me","scroll-mbs","scroll-mbe","scroll-mt","scroll-mr","scroll-mb","scroll-ml"],"scroll-mx":["scroll-mr","scroll-ml"],"scroll-my":["scroll-mt","scroll-mb"],"scroll-p":["scroll-px","scroll-py","scroll-ps","scroll-pe","scroll-pbs","scroll-pbe","scroll-pt","scroll-pr","scroll-pb","scroll-pl"],"scroll-px":["scroll-pr","scroll-pl"],"scroll-py":["scroll-pt","scroll-pb"],touch:["touch-x","touch-y","touch-pz"],"touch-x":["touch"],"touch-y":["touch"],"touch-pz":["touch"]},conflictingClassGroupModifiers:{"font-size":["leading"]},postfixLookupClassGroups:["container-type"],orderSensitiveModifiers:["*","**","after","backdrop","before","details-content","file","first-letter","first-line","marker","placeholder","selection"]}
    },l=e=>{
    let r=o(e);
    if(r)
    return r;
    let a=((e,r)=>{
      let{parseClassName:t,getClassGroupId:o,getConflictingClassGroupIds:n,sortModifiers:a,postfixLookupClassGroupIds:l}=r,s=[],i=e.trim().split(v),c="";
      for(
      let e=i.length-1
      ;e>=0;e-=1){
        let r,d=i[e],{isExternal:m,modifiers:u,hasImportantModifier:p,baseClassName:b,maybePostfixModifierPosition:f}=t(d);
        if(m){
          c=d+(c.length>0?" "+c:c);
          continue
          }
        let g=!!f;
        if(g){
          let e=(r=o(b.substring(0,f)))&&l[r]?o(b):void 0;
          e&&e!==r&&(r=e,g=!1)
          }else 
        r=o(b);
        if(!r){
          if(!g||!(r=o(b))){
            c=d+(c.length>0?" "+c:c);
            continue
            }
          g=!1
          }
        let h=0===u.length?"":1===u.length?u[0]:a(u).join(":"),x=p?h+"!":h,w=x+r;
        if(s.indexOf(w)>-1)
        continue;
        s.push(w);
        let v=n(r,g);
        for(
        let e=0
        ;e<v.length;++e){
          let r=v[e];
          s.push(x+r)
          }
        c=d+(c.length>0?" "+c:c)
        }
      return c
      })(e,t);
    return n(e,a),a
    },a=e=>{
    var s;
    let m;
    return o=(t={cache:(e=>{
      if(e<1)
      return{get:()=>void 0,set:()=>{
        }};
      let r=0,t=Object.create(null),o=Object.create(null),n=(n,a)=>{
        t[n]=a,++r>e&&(r=0,o=t,t=Object.create(null))
        };
      return{get(e){
        let r=t[e];
        return void 0!==r?r:void 0!==(r=o[e])?(n(e,r),r):void 0
        },set(e,r){
        e in t?t[e]=r:n(e,r)
        }}
      })((s=[].reduce((e,r)=>r(e),r())).cacheSize),parseClassName:(e=>{
      let{prefix:r,experimentalParseClassName:t}=e,o=e=>{
        let r,t=[],o=0,n=0,a=0,l=e.length;
        for(
        let s=0
        ;s<l;s++){
          let l=e[s];
          if(0===o&&0===n){
            if(":"===l){
              t.push(e.slice(a,s)),a=s+1;
              continue
              }
            if("/"===l){
              r=s;
              continue
              }
            }
          "["===l?o++:"]"===l?o--:"("===l?n++:")"===l&&n--
          }
        let s=0===t.length?e:e.slice(a),i=s,c=!1;
        return s.endsWith("!")?(i=s.slice(0,-1),c=!0):s.startsWith("!")&&(i=s.slice(1),c=!0),w(t,c,i,r&&r>a?r-a:void 0)
        };
      if(r){
        let e=r+":",t=o;
        o=r=>r.startsWith(e)?t(r.slice(e.length)):w(x,!1,r,void 0,!0)
        }
      if(t){
        let e=o;
        o=r=>t({className:r,parseClassName:e})
        }
      return o
      })(s),sortModifiers:(m=new Map,s.orderSensitiveModifiers.forEach((e,r)=>{
      m.set(e,1e6+r)
      }),e=>{
      let r=[],t=[];
      for(
      let o=0
      ;o<e.length;o++){
        let n=e[o],a="["===n[0],l=m.has(n);
        a||l?(t.length>0&&(t.sort(),r.push(...t),t=[]),r.push(n)):t.push(n)
        }
      return t.length>0&&(t.sort(),r.push(...t)),r
      }),postfixLookupClassGroupIds:(e=>{
      let r=Object.create(null),t=e.postfixLookupClassGroups;
      if(t)
      for(
      let e=0
      ;e<t.length;e++)
      r[t[e]]=!0;
      return r
      })(s),...(e=>{
      let r=(e=>{
        let{theme:r,classGroups:t}=e;
        return d(t,r)
        })(e),{conflictingClassGroups:t,conflictingClassGroupModifiers:o}=e;
      return{getClassGroupId:e=>{
        if(e.startsWith("[")&&e.endsWith("]")){
          var t;
          let r,o,n;
          return -1===(t=e).slice(1,-1).indexOf(":")?void 0:(o=(r=t.slice(1,-1)).indexOf(":"),(n=r.slice(0,o))?"arbitrary.."+n:void 0)
          }
        let o=e.split("-"),n=+(""===o[0]&&o.length>1);
        return c(o,n,r)
        },getConflictingClassGroupIds:(e,r)=>{
        if(r){
          let r=o[e],n=t[e];
          if(r){
            if(n){
              let e=Array(n.length+r.length);
              for(
              let r=0
              ;r<n.length;r++)
              e[r]=n[r];
              for(
              let t=0
              ;t<r.length;t++)
              e[n.length+t]=r[t];
              return e
              }
            return r
            }
          return n||i
          }
        return t[e]||i
        }}
      })(s)}).cache.get,n=t.cache.set,a=l,l(e)
    },(...e)=>a(((...e)=>{
    let r,t,o=0,n="";
    for(;o<e.length;)
    (r=e[o++])&&(t=k(r))&&(n&&(n+=" "),n+=t);
    return n
    })(...e)));
  e.s(["twMerge",0,eh])
  },19455,38906,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(22016);
  let o=(0,e.i(56420).default)("loader-circle",[["path",{d:"M21 12a9 9 0 1 1-6.219-8.56",key:"13zald"}]]);
  e.s(["LoaderCircleIcon",0,o],38906);
  var n=e.i(19056);
  let a={primary:"bg-invert-bg text-invert-fg transition-opacity hover:opacity-80",secondary:"invert-block border border-line-strong bg-bg text-ink hover:border-transparent",action:"border border-line bg-bg-raised text-ink hover:border-line-strong",destructive:"bg-danger text-white transition-opacity hover:opacity-80",ghost:"text-muted hover:bg-invert-bg hover:text-invert-fg"},l={sm:"px-3 py-1.5 text-[11px]",md:"px-4 py-2 text-[11px]",lg:"h-12 px-6 text-[11px]"};
  e.s(["Button",0,function({variant:e="primary",size:s="md",href:i,external:c=!1,loading:d=!1,disabled:m,className:u,children:p,target:b,rel:f,type:g,...h}){
    let x=(0,n.twMerge)("inline-flex w-fit items-center justify-center gap-2 rounded-none font-mono font-bold uppercase tracking-[0.12em] whitespace-nowrap transition-colors duration-150",a[e],l[s],(m||d)&&"pointer-events-none opacity-50",u),w=(0,r.jsxs)(r.Fragment,{children:[d&&(0,r.jsx)(o,{"aria-hidden":!0,className:"h-4 w-4 animate-spin"}),p]});
    return i?c||/^(https?:\/\/|mailto:)/.test(i)?(0,r.jsx)("a",{href:i,target:b,rel:f,className:x,"data-cta":"",...h,children:w}):(0,r.jsx)(t.default,{href:i,className:x,"data-cta":"",...h,children:w}):(0,r.jsx)("button",{type:g??"button",className:x,disabled:m||d,...h,children:w})
    }],19455)
  },57428,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(71645),o=e.i(19056);
  let n=({className:e})=>(0,r.jsx)("svg",{"aria-hidden":!0,viewBox:"0 0 10 8",fill:"none",xmlns:"http://www.w3.org/2000/svg",className:(0,o.twMerge)("block",e),children:(0,r.jsx)("path",{d:"M1 4L3.6 6.6L9 1",stroke:"currentColor",strokeWidth:"1.75",strokeLinecap:"round",strokeLinejoin:"round"})});
  function a({label:e,size:l="md",className:s,checkboxClassName:i,labelClassName:c,id:d,disabled:m,checked:u,defaultChecked:p,onChange:b,ref:f,...g}){
    let h=(0,t.useId)(),x=d??h,w=void 0!==u,[v,k]=(0,t.useState)(!!p),y=w?u:v,z=(0,t.useCallback)(e=>{
      w||k(e.target.checked),b?.(e)
      },[w,b]);
    return(0,r.jsxs)("label",{htmlFor:x,className:(0,o.twMerge)("inline-flex select-none items-center gap-2 leading-none",m?"cursor-not-allowed opacity-50":"cursor-pointer",s),children:[(0,r.jsx)("input",{ref:f,id:x,type:"checkbox",disabled:m,checked:y,onChange:z,...g,className:"peer sr-only"}),(0,r.jsx)("span",{"aria-hidden":!0,className:(0,o.twMerge)("relative inline-block shrink-0 rounded-none border transition-colors","sm"===l?"h-3.5 w-3.5":"h-4 w-4",y?"border-invert-bg bg-invert-bg text-invert-fg":"border-line bg-transparent hover:border-line-strong","peer-focus-visible:outline peer-focus-visible:outline-2 peer-focus-visible:outline-offset-2 peer-focus-visible:outline-accent-ink",i),children:y&&(0,r.jsx)(n,{className:(0,o.twMerge)("absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2","sm"===l?"h-2 w-2":"h-2.5 w-2.5")})}),null!=e&&(0,r.jsx)("span",{className:(0,o.twMerge)("text-sm text-muted",m&&"text-faint",c),children:e})]})
    }
  e.s(["Checkbox",0,a,"default",0,a])
  },93698,e=>{
  "use strict";
  let r=(0,e.i(56420).default)("check",[["path",{d:"M20 6 9 17l-5-5",key:"1gmf2c"}]]);
  e.s(["CheckIcon",0,r],93698)
  },64168,e=>{
  "use strict";
  let r=(0,e.i(56420).default)("copy",[["rect",{width:"14",height:"14",x:"8",y:"8",rx:"2",ry:"2",key:"17jyea"}],["path",{d:"M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2",key:"zix9uf"}]]);
  e.s(["CopyIcon",0,r],64168)
  },66790,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(71645),o=e.i(93698),n=e.i(64168),a=e.i(19455);
  function l({value:e,label:s="Copy",copiedLabel:i="Copied",...c}){
    let[d,m]=(0,t.useState)("idle"),u=(0,t.useRef)(void 0);
    async function p(){
      let r="copied";
      try{
        await navigator.clipboard.writeText(e)
        }catch{
        r="failed"
        }
      m(r),clearTimeout(u.current),u.current=setTimeout(()=>m("idle"),1500)
      }
    let b="copied"===d?o.CheckIcon:n.CopyIcon;
    return(0,r.jsxs)(a.Button,{onClick:p,...c,children:[(0,r.jsx)(b,{"aria-hidden":!0,className:"h-3.5 w-3.5"}),(0,r.jsx)("span",{"aria-live":"polite",children:"copied"===d?i:"failed"===d?"Copy blocked":s})]})
    }
  e.s(["CopyButton",0,l,"default",0,l])
  },389,60964,73357,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(71645),o=e.i(74080),n=e.i(19056);
  let a=(0,e.i(56420).default)("x",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]]);
  function l({onClick:e,className:t,size:o="md"}){
    return(0,r.jsx)("button",{type:"button","aria-label":"Close",onClick:e,className:(0,n.twMerge)("flex items-center justify-center rounded-none text-muted transition-colors hover:bg-invert-bg hover:text-invert-fg",{sm:"h-5 w-5",md:"h-7 w-7",lg:"h-9 w-9"}[o],t),children:(0,r.jsx)(a,{className:"h-[70%] w-[70%]"})})
    }
  function s({isOpen:e,onClose:a,children:i,title:c,className:d,backdropClassName:m,childPadding:u=!0,showClose:p=!0,closeOnOutsideClick:b=!0,closeOnEsc:f=!0,accessibleTitle:g}){
    let[h,x]=(0,t.useState)(!1),[w,v]=(0,t.useState)(!1),k=(0,t.useId)();
    return((0,t.useEffect)(()=>x(!0),[]),(0,t.useEffect)(()=>{
      if(!e)
      return void v(!1);
      let r=requestAnimationFrame(()=>requestAnimationFrame(()=>v(!0)));
      return()=>cancelAnimationFrame(r)
      },[e]),(0,t.useEffect)(()=>{
      if(!e||!f)
      return;
      let r=e=>{
        "Escape"===e.key&&a()
        };
      return window.addEventListener("keydown",r),()=>window.removeEventListener("keydown",r)
      },[e,f,a]),(0,t.useEffect)(()=>{
      if(!e)
      return;
      let r=document.body.style.overflow;
      return document.body.style.overflow="hidden",()=>{
        document.body.style.overflow=r
        }
      },[e]),h&&e)?(0,o.createPortal)((0,r.jsxs)("div",{className:"fixed inset-0 z-[70]",children:[(0,r.jsx)("div",{"aria-hidden":!0,onClick:()=>b&&a(),className:(0,n.twMerge)("fixed inset-0 bg-black/70 transition-opacity duration-200",w?"opacity-100":"opacity-0",m)}),(0,r.jsx)("div",{className:"pointer-events-none flex min-h-full items-center justify-center p-0 sm:p-4",children:(0,r.jsxs)("div",{role:"dialog","aria-modal":"true","aria-labelledby":null!=c?k:void 0,"aria-label":null==c?g??"Dialog":void 0,className:(0,n.twMerge)("pointer-events-auto relative w-full max-w-lg rounded-none border border-line bg-bg-raised text-left align-middle text-ink",u&&"p-4","transition-[opacity,transform] duration-200",w?"translate-y-0 scale-100 opacity-100":"-translate-y-2.5 scale-95 opacity-0",d),children:[null!=c&&(0,r.jsx)("h2",{id:k,className:"mb-4 flex items-center gap-3 pr-10 font-display text-xl font-medium text-ink-strong",children:c}),i,p&&(0,r.jsx)(l,{onClick:a,className:"absolute right-2.5 top-2.5"})]})})]}),document.body):null
    }
  e.s(["XIcon",0,a],60964),e.s(["CloseButton",0,l],73357),e.s(["Modal",0,s,"default",0,s],389)
  },67489,3636,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(71645),o=e.i(93698);
  let n=(0,e.i(56420).default)("chevron-down",[["path",{d:"m6 9 6 6 6-6",key:"qrunsl"}]]);
  e.s(["ChevronDownIcon",0,n],3636);
  var a=e.i(19056);
  function l({onChange:e,options:s,placeholder:i,value:c,id:d,className:m,disabled:u}){
    let[p,b]=(0,t.useState)(!1),f=s.findIndex(e=>e.value===c),[g,h]=(0,t.useState)(f),x=(0,t.useRef)(null),w=(0,t.useId)(),v=f>=0?s[f]:{label:i??"",value:""},k=()=>{
      h(f>=0?f:0),b(!0)
      },y=r=>{
      let t=s[r];
      t&&e(t.value),b(!1)
      };
    return(0,t.useEffect)(()=>{
      if(!p)
      return;
      let e=e=>{
        x.current?.contains(e.target)||b(!1)
        };
      return document.addEventListener("pointerdown",e),()=>document.removeEventListener("pointerdown",e)
      },[p]),(0,r.jsxs)("div",{ref:x,className:(0,a.twMerge)("relative",m),children:[(0,r.jsxs)("button",{type:"button",id:d,disabled:u,"aria-haspopup":"listbox","aria-expanded":p,"aria-controls":p?w:void 0,onClick:()=>p?b(!1):k(),onKeyDown:e=>{
      switch(e.key){case"ArrowDown":
      e.preventDefault(),p?h(e=>Math.min(e+1,s.length-1)):k();
      break;
      case"ArrowUp":
      e.preventDefault(),p?h(e=>Math.max(e-1,0)):k();
      break;
      case"Home":
      p&&(e.preventDefault(),h(0));
      break;
      case"End":
      p&&(e.preventDefault(),h(s.length-1));
      break;
      case"Enter":case" ":
      e.preventDefault(),p?g>=0&&y(g):k();
      break;
      case"Escape":
      p&&(e.preventDefault(),b(!1))
      }
      },className:(0,a.twMerge)("relative h-10 w-full cursor-pointer rounded-none border border-line bg-bg-raised py-2 pl-3 pr-10 text-left text-sm text-ink","transition-colors duration-150 ease-in-out hover:border-line-strong",u&&"cursor-not-allowed opacity-60 hover:border-line"),children:[(0,r.jsx)("span",{className:(0,a.twMerge)("block truncate",f<0&&"text-faint"),children:v.label}),(0,r.jsx)("span",{className:"pointer-events-none absolute inset-y-0 right-0 flex items-center pr-2.5 text-muted",children:(0,r.jsx)(n,{"aria-hidden":!0,className:(0,a.twMerge)("h-4 w-4 transition-transform",p&&"rotate-180")})})]}),p&&(0,r.jsx)("ul",{id:w,role:"listbox",className:"absolute z-10 mt-1 max-h-60 w-full overflow-auto rounded-none border border-line bg-bg-raised text-sm",children:s.map((e,t)=>{
      let n=t===f;
      return(0,r.jsxs)("li",{role:"option","aria-selected":n,onMouseEnter:()=>h(t),onClick:()=>y(t),className:(0,a.twMerge)("relative cursor-pointer select-none py-2 pl-7 pr-2 transition-colors duration-150 ease-in-out",n?"bg-ink/10 font-medium text-ink":"text-ink/90",t===g&&"bg-invert-bg text-invert-fg"),children:[(0,r.jsx)("span",{className:"block truncate",children:e.label}),n&&(0,r.jsx)("span",{className:"absolute inset-y-0 left-0 flex items-center pl-2",children:(0,r.jsx)(o.CheckIcon,{"aria-hidden":!0,className:"h-3 w-3"})})]},`${e.value}-${t}`)
      })})]})
    }
  e.s(["Select",0,l,"default",0,l],67489)
  },99375,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(19056);
  function o({enabled:e,setEnabled:n,disabled:a,className:l,offClassName:s,"aria-label":i}){
    return(0,r.jsx)("button",{type:"button",role:"switch","aria-checked":e,"aria-label":i,disabled:a,onClick:()=>n(!e),className:(0,t.twMerge)("inline-flex h-6 w-11 items-center rounded-none border transition-colors",e?"border-invert-bg bg-invert-bg":s??"border-line bg-transparent hover:border-line-strong",a&&"cursor-not-allowed opacity-50",l),children:(0,r.jsx)("span",{className:(0,t.twMerge)("size-4 rounded-none transition-transform",e?"translate-x-[22px] bg-invert-fg":"translate-x-1 bg-ink/70")})})
    }
  e.s(["Switch",0,o,"default",0,o])
  },46798,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(71645),o=e.i(19056);
  let n={top:"bottom-full left-1/2 mb-2 -translate-x-1/2",bottom:"top-full left-1/2 mt-2 -translate-x-1/2",left:"right-full top-1/2 mr-2 -translate-y-1/2",right:"left-full top-1/2 ml-2 -translate-y-1/2"};
  function a({children:e,content:l,position:s="top",className:i,delay:c=300,description:d,disabled:m=!1}){
    let[u,p]=(0,t.useState)(!1),b=(0,t.useRef)(null),f=()=>{
      m||(b.current&&clearTimeout(b.current),b.current=setTimeout(()=>p(!0),c))
      },g=()=>{
      b.current&&clearTimeout(b.current),p(!1)
      };
    return(0,t.useEffect)(()=>{
      m&&p(!1)
      },[m]),(0,t.useEffect)(()=>()=>{
      b.current&&clearTimeout(b.current)
      },[]),(0,r.jsxs)("div",{className:"relative inline-block",onPointerEnter:f,onPointerLeave:g,onPointerCancel:g,onFocus:f,onBlur:g,children:[e,(0,r.jsxs)("div",{role:"tooltip","aria-hidden":!u,className:(0,o.twMerge)("pointer-events-none absolute z-50 w-max rounded-none border border-line bg-bg-raised px-2.5 py-1.5","font-mono text-[11px] font-medium uppercase tracking-[0.1em] text-ink","transition-opacity duration-150",n[s],u?"opacity-100":"opacity-0",i),children:[l,d&&(0,r.jsx)("p",{className:"mt-1 max-w-[240px] whitespace-normal font-body text-xs font-normal normal-case tracking-normal text-muted",children:d})]})]})
    }
  e.s(["Tooltip",0,a,"default",0,a])
  },22641,e=>{
  "use strict";
  var r=e.i(43476),t=e.i(71645),o=e.i(19056),n=e.i(46798);
  function a({tabs:e,activeTab:l,onTabChange:s,className:i,disabled:c,disabledMessage:d,tabClassName:m,indicatorClassName:u,selectedTabClassName:p,listClassName:b}){
    let f=e.findIndex(e=>e.id===l),g=(0,t.useRef)([]),[h,x]=(0,t.useState)({left:0,width:0});
    (0,t.useEffect)(()=>{
      let e=f>=0?g.current[f]:null;
      e&&x({left:e.offsetLeft,width:e.offsetWidth})
      },[f,e]);
    let w=(0,r.jsx)("div",{className:(0,o.twMerge)("w-fit",i,c&&"cursor-not-allowed opacity-60"),children:(0,r.jsxs)("div",{role:"tablist",className:(0,o.twMerge)("relative inline-flex min-w-fit overflow-x-auto rounded-none border border-line bg-bg-raised p-0.5 py-1",b),children:[(0,r.jsx)("div",{"aria-hidden":!0,className:(0,o.twMerge)("absolute top-1 z-10 h-[calc(100%-8px)] rounded-none bg-invert-bg transition-all duration-200 ease-in-out",u),style:{left:h.left,width:h.width}}),e.map((e,t)=>{
      let n=t===f;
      return(0,r.jsx)("button",{ref:e=>{
        g.current[t]=e
        },type:"button",role:"tab","aria-selected":n,disabled:c,onClick:()=>s(e.id),className:(0,o.twMerge)("relative z-20 mx-0.5 min-w-max rounded-none px-4 py-0.5 text-center font-mono text-[11px] font-semibold uppercase tracking-[0.1em] transition-colors duration-200 ease-in-out",n?(0,o.twMerge)("text-invert-fg",p):"text-muted hover:text-ink",c&&"cursor-not-allowed",m),children:e.label},e.id)
      })]})});
    return c?(0,r.jsx)(n.Tooltip,{content:d??"Cannot change tab right now.",position:"bottom",children:w}):w
    }
  e.s(["TabSelector",0,a,"default",0,a])
  }]);
