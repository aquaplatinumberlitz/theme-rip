(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,89970,t=>{
  "use strict";
  function e(t){
    if(void 0===t)
    throw ReferenceError("this hasn't been initialised - super() hasn't been called");
    return t
    }
  function r(t,e){
    t.prototype=Object.create(e.prototype),t.prototype.constructor=t,t.__proto__=e
    }
  var n,i,s,a,o,u,l,c,f,h,p,d,g,_,m,v,y,x,b,T,w,k,M,O,C,S,E,A,P={autoSleep:120,force3D:"auto",nullTargetWarn:1,units:{lineHeight:""}},D={duration:.5,overwrite:!1,delay:0},R=2*Math.PI,z=R/4,F=0,I=Math.sqrt,Y=Math.cos,B=Math.sin,L=function(t){
    return"string"==typeof t
    },N=function(t){
    return"function"==typeof t
    },X=function(t){
    return"number"==typeof t
    },U=function(t){
    return void 0===t
    },W=function(t){
    return"object"==typeof t
    },q=function(t){
    return!1!==t
    },H=function(){
    return"u">typeof window
    },V=function(t){
    return N(t)||L(t)
    },j="function"==typeof ArrayBuffer&&ArrayBuffer.isView||function(){
    },G=Array.isArray,$=/random\([^)]+\)/g,Q=/,\s*/g,K=/(?:-?\.?\d|\.)+/gi,Z=/[-+=.]*\d+[.e\-+]*\d*[e\-+]*\d*/g,J=/[-+=.]*\d+[.e-]*\d*[a-z%]*/g,tt=/[-+=.]*\d+\.?\d*(?:e-|e\+)?\d*/gi,te=/[+-]=-?[.\d]+/,tr=/[^,'"\[\]\s]+/gi,tn=/^[+\-=e\s\d]*\d+[.\d]*([a-z]*|%)\s*$/i,ti={},ts={},ta=function(t){
    return(ts=tI(t,ti))&&rC
    },to=function(t,e){
    return console.warn("Invalid property",t,"set to",e,"Missing plugin? gsap.registerPlugin()")
    },tu=function(t,e){
    return!e&&console.warn(t)
    },tl=function(t,e){
    return t&&(ti[t]=e)&&ts&&(ts[t]=e)||ti
    },tc=function(){
    return 0
    },tf={suppressEvents:!0,isStart:!0,kill:!1},th={suppressEvents:!0,kill:!1},tp={suppressEvents:!0},td={},tg=[],t_={},tm={},tv={},ty=30,tx=[],tb="",tT=function(t){
    var e,r,n=t[0];
    if(W(n)||N(n)||(t=[t]),!(e=(n._gsap||{}).harness)){
      for(r=tx.length;r--&&!tx[r].targetTest(n););
      e=tx[r]
      }
    for(r=t.length;r--;)
    t[r]&&(t[r]._gsap||(t[r]._gsap=new eW(t[r],e)))||t.splice(r,1);
    return t
    },tw=function(t){
    return t._gsap||tT(ea(t))[0]._gsap
    },tk=function(t,e,r){
    return(r=t[e])&&N(r)?t[e]():U(r)&&t.getAttribute&&t.getAttribute(e)||r
    },tM=function(t,e){
    return(t=t.split(",")).forEach(e)||t
    },tO=function(t){
    return Math.round(1e5*t)/1e5||0
    },tC=function(t){
    return Math.round(1e7*t)/1e7||0
    },tS=function(t,e){
    var r=e.charAt(0),n=parseFloat(e.substr(2));
    return t=parseFloat(t),"+"===r?t+n:"-"===r?t-n:"*"===r?t*n:t/n
    },tE=function(t,e){
    for(
    var r=e.length,n=0
    ;0>t.indexOf(e[n])&&++n<r;);
    return n<r
    },tA=function(){
    var t,e,r=tg.length,n=tg.slice(0);
    for(t=0,t_={},tg.length=0;t<r;t++)
    (e=n[t])&&e._lazy&&(e.render(e._lazy[0],e._lazy[1],!0)._lazy=0)
    },tP=function(t){
    return!!(t._initted||t._startAt||t.add)
    },tD=function(t,e,r,n){
    tg.length&&!b&&tA(),t.render(e,r,n||!!(b&&e<0&&tP(t))),tg.length&&!b&&tA()
    },tR=function(t){
    var e=parseFloat(t);
    return(e||0===e)&&(t+"").match(tr).length<2?e:L(t)?t.trim():t
    },tz=function(t){
    return t
    },tF=function(t,e){
    for(
    var r
     in e)
    r in t||(t[r]=e[r]);
    return t
    },tI=function(t,e){
    for(
    var r
     in e)
    t[r]=e[r];
    return t
    },tY=function t(e,r){
    for(
    var n
     in r)
    "__proto__"!==n&&"constructor"!==n&&"prototype"!==n&&(e[n]=W(r[n])?t(e[n]||(e[n]={}),r[n]):r[n]);
    return e
    },tB=function(t,e){
    var r,n={};
    for(r in t)
    r in e||(n[r]=t[r]);
    return n
    },tL=function(t){
    var e,r=t.parent||w,n=t.keyframes?(e=G(t.keyframes),function(t,r){
      for(
      var n
       in r)
      n in t||"duration"===n&&e||"ease"===n||(t[n]=r[n])
      }):tF;
    if(q(t.inherit))
    for(;r;)
    n(t,r.vars.defaults),r=r.parent||r._dp;
    return t
    },tN=function(t,e){
    for(
    var r=t.length,n=r===e.length
    ;n&&r--&&t[r]===e[r];);
    return r<0
    },tX=function(t,e,r,n,i){
    void 0===r&&(r="_first"),void 0===n&&(n="_last");
    var s,a=t[n];
    if(i)
    for(s=e[i];a&&a[i]>s;)
    a=a._prev;
    return a?(e._next=a._next,a._next=e):(e._next=t[r],t[r]=e),e._next?e._next._prev=e:t[n]=e,e._prev=a,e.parent=e._dp=t,e
    },tU=function(t,e,r,n){
    void 0===r&&(r="_first"),void 0===n&&(n="_last");
    var i=e._prev,s=e._next;
    i?i._next=s:t[r]===e&&(t[r]=s),s?s._prev=i:t[n]===e&&(t[n]=i),e._next=e._prev=e.parent=null
    },tW=function(t,e){
    t.parent&&(!e||t.parent.autoRemoveChildren)&&t.parent.remove&&t.parent.remove(t),t._act=0
    },tq=function(t,e){
    if(t&&(!e||e._end>t._dur||e._start<0))
    for(
    var r=t
    ;r;)
    r._dirty=1,r=r.parent;
    return t
    },tH=function(t){
    for(
    var e=t.parent
    ;e&&e.parent;)
    e._dirty=1,e.totalDuration(),e=e.parent;
    return t
    },tV=function(t,e,r,n){
    return t._startAt&&(b?t._startAt.revert(th):t.vars.immediateRender&&!t.vars.autoRevert||t._startAt.render(e,!0,n))
    },tj=function(t){
    return t._repeat?tG(t._tTime,t=t.duration()+t._rDelay)*t:0
    },tG=function(t,e){
    var r=Math.floor(t=tC(t/e));
    return t&&r===t?r-1:r
    },t$=function(t,e){
    return(t-e._start)*e._ts+(e._ts>=0?0:e._dirty?e.totalDuration():e._tDur)
    },tQ=function(t){
    return t._end=tC(t._start+(t._tDur/Math.abs(t._ts||t._rts||1e-8)||0))
    },tK=function(t,e){
    var r=t._dp;
    return r&&r.smoothChildTiming&&t._ts&&(t._start=tC(r._time-(t._ts>0?e/t._ts:-(((t._dirty?t.totalDuration():t._tDur)-e)/t._ts))),tQ(t),r._dirty||tq(r,t)),t
    },tZ=function(t,e){
    var r;
    if((e._time||!e._dur&&e._initted||e._start<t._time&&(e._dur||!e.add))&&(r=t$(t.rawTime(),e),(!e._dur||er(0,e.totalDuration(),r)-e._tTime>1e-8)&&e.render(r,!0)),tq(t,e)._dp&&t._initted&&t._time>=t._dur&&t._ts){
      if(t._dur<t.duration())
      for(r=t;r._dp;)
      r.rawTime()>=0&&r.totalTime(r._tTime),r=r._dp;
      t._zTime=-1e-8
      }
    },tJ=function(t,e,r,n){
    return e.parent&&tW(e),e._start=tC((X(r)?r:r||t!==w?t7(t,r,e):t._time)+e._delay),e._end=tC(e._start+(e.totalDuration()/Math.abs(e.timeScale())||0)),tX(t,e,"_first","_last",t._sort?"_start":0),t5(e)||(t._recent=e),n||tZ(t,e),t._ts<0&&tK(t,t._tTime),t
    },t0=function(t,e){
    return(ti.ScrollTrigger||to("scrollTrigger",e))&&ti.ScrollTrigger.create(e,t)
    },t1=function(t,e,r,n,i){
    return(e2(t,e,i),t._initted)?!r&&t._pt&&!b&&(t._dur&&!1!==t.vars.lazy||!t._dur&&t.vars.lazy)&&S!==eE.frame?(tg.push(t),t._lazy=[i,n],1):void 0:1
    },t2=function t(e){
    var r=e.parent;
    return r&&r._ts&&r._initted&&!r._lock&&(0>r.rawTime()||t(r))
    },t5=function(t){
    var e=t.data;
    return"isFromStart"===e||"isStart"===e
    },t3=function(t,e,r,n){
    var i,s,a,o=t.ratio,u=e<0||!e&&(!t._start&&t2(t)&&!(!t._initted&&t5(t))||(t._ts<0||t._dp._ts<0)&&!t5(t))?0:1,l=t._rDelay,c=0;
    if(l&&t._repeat&&(s=tG(c=er(0,t._tDur,e),l),t._yoyo&&1&s&&(u=1-u),s!==tG(t._tTime,l)&&(o=1-u,t.vars.repeatRefresh&&t._initted&&t.invalidate())),u!==o||b||n||1e-8===t._zTime||!e&&t._zTime){
      if(!t._initted&&t1(t,e,n,r,c))
      return;
      for(a=t._zTime,t._zTime=e||1e-8*!!r,r||(r=e&&!a),t.ratio=u,t._from&&(u=1-u),t._time=0,t._tTime=c,i=t._pt;i;)
      i.r(u,i.d),i=i._next;
      e<0&&tV(t,e,r,!0),t._onUpdate&&!r&&em(t,"onUpdate"),c&&t._repeat&&!r&&t.parent&&em(t,"onRepeat"),(e>=t._tDur||e<0)&&t.ratio===u&&(u&&tW(t,1),r||b||(em(t,u?"onComplete":"onReverseComplete",!0),t._prom&&t._prom()))
      }else 
    t._zTime||(t._zTime=e)
    },t8=function(t,e,r){
    var n;
    if(r>e)
    for(n=t._first;n&&n._start<=r;){
      if("isPause"===n.data&&n._start>e)
      return n;
      n=n._next
      }
    else 
    for(n=t._last;n&&n._start>=r;){
      if("isPause"===n.data&&n._start<e)
      return n;
      n=n._prev
      }
    },t6=function(t,e,r,n){
    var i=t._repeat,s=tC(e)||0,a=t._tTime/t._tDur;
    return a&&!n&&(t._time*=s/t._dur),t._dur=s,t._tDur=i?i<0?1e10:tC(s*(i+1)+t._rDelay*i):s,a>0&&!n&&tK(t,t._tTime=t._tDur*a),t.parent&&tQ(t),r||tq(t.parent,t),t
    },t4=function(t){
    return t instanceof eH?tq(t):t6(t,t._dur)
    },t9={_start:0,endTime:tc,totalDuration:tc},t7=function t(e,r,n){
    var i,s,a,o=e.labels,u=e._recent||t9,l=e.duration()>=1e8?u.endTime(!1):e._dur;
    return L(r)&&(isNaN(r)||r in o)?(s=r.charAt(0),a="%"===r.substr(-1),i=r.indexOf("="),"<"===s||">"===s)?(i>=0&&(r=r.replace(/=/,"")),("<"===s?u._start:u.endTime(u._repeat>=0))+(parseFloat(r.substr(1))||0)*(a?(i<0?u:n).totalDuration()/100:1)):i<0?(r in o||(o[r]=l),o[r]):(s=parseFloat(r.charAt(i-1)+r.substr(i+1)),a&&n&&(s=s/100*(G(n)?n[0]:n).totalDuration()),i>1?t(e,r.substr(0,i-1),n)+s:l+s):null==r?l:+r
    },et=function(t,e,r){
    var n,i,s=X(e[1]),a=(s?2:1)+(t<2?0:1),o=e[a];
    if(s&&(o.duration=e[1]),o.parent=r,t){
      for(n=o,i=r;i&&!("immediateRender"in n);)
      n=i.vars.defaults||{},i=q(i.vars.inherit)&&i.parent;
      o.immediateRender=q(n.immediateRender),t<2?o.runBackwards=1:o.startAt=e[a-1]
      }
    return new e7(e[0],o,e[a+1])
    },ee=function(t,e){
    return t||0===t?e(t):e
    },er=function(t,e,r){
    return r<t?t:r>e?e:r
    },en=function(t,e){
    return L(t)&&(e=tn.exec(t))?e[1]:""
    },ei=[].slice,es=function(t,e){
    return t&&W(t)&&"length"in t&&(!e&&!t.length||t.length-1 in t&&W(t[0]))&&!t.nodeType&&t!==k
    },ea=function(t,e,r){
    var n;
    return T&&!e&&T.selector?T.selector(t):L(t)&&!r&&(M||!eA())?ei.call((e||O).querySelectorAll(t),0):G(t)?(void 0===n&&(n=[]),t.forEach(function(t){
      var e;
      return L(t)&&!r||es(t,1)?(e=n).push.apply(e,ea(t)):n.push(t)
      })||n):es(t)?ei.call(t,0):t?[t]:[]
    },eo=function(t){
    return t=ea(t)[0]||tu("Invalid scope")||{},function(e){
      var r=t.current||t.nativeElement||t;
      return ea(e,r.querySelectorAll?r:r===t?tu("Invalid scope")||O.createElement("div"):t)
      }
    },eu=function(t){
    return t.sort(function(){
      return .5-Math.random()
      })
    },el=function(t){
    if(N(t))
    return t;
    var e=W(t)?t:{each:t},r=eB(e.ease),n=e.from||0,i=parseFloat(e.base)||0,s={},a=n>0&&n<1,o=isNaN(n)||a,u=e.axis,l=n,c=n;
    return L(n)?l=c=({center:.5,edges:.5,end:1})[n]||0:!a&&o&&(l=n[0],c=n[1]),function(t,a,f){
      var h,p,d,g,_,m,v,y,x,b=(f||e).length,T=s[b];
      if(!T){
        if(!(x="auto"===e.grid?0:(e.grid||[1,1e8])[1])){
          for(v=-1e8;v<(v=f[x++].getBoundingClientRect().left)&&x<b;);
          x<b&&x--
          }
        for(m=0,T=s[b]=[],h=o?Math.min(x,b)*l-.5:n%x,p=1e8===x?0:o?b*c/x-.5:n/x|0,v=0,y=1e8;m<b;m++)
        d=m%x-h,g=p-(m/x|0),T[m]=_=u?Math.abs("y"===u?g:d):I(d*d+g*g),_>v&&(v=_),_<y&&(y=_);
        "random"===n&&eu(T),T.max=v-y,T.min=y,T.v=b=(parseFloat(e.amount)||parseFloat(e.each)*(x>b?b-1:u?"y"===u?b/x:x:Math.max(x,b/x))||0)*("edges"===n?-1:1),T.b=b<0?i-b:i,T.u=en(e.amount||e.each)||0,r=r&&b<0?eY(r):r
        }
      return b=(T[t]-T.min)/T.max||0,tC(T.b+(r?r(b):b)*T.v)+T.u
      }
    },ec=function(t){
    var e=Math.pow(10,((t+"").split(".")[1]||"").length);
    return function(r){
      var n=tC(Math.round(parseFloat(r)/t)*t*e);
      return(n-n%1)/e+(X(r)?0:en(r))
      }
    },ef=function(t,e){
    var r,n,i=G(t);
    return!i&&W(t)&&(r=i=t.radius||1e8,t.values?(n=!X((t=ea(t.values))[0]))&&(r*=r):t=ec(t.increment)),ee(e,i?N(t)?function(e){
      return Math.abs((n=t(e))-e)<=r?n:e
      }:function(e){
      for(
      var i,s,a=parseFloat(n?e.x:e),o=parseFloat(n?e.y:0),u=1e8,l=0,c=t.length
      ;c--;)
      (i=n?(i=t[c].x-a)*i+(s=t[c].y-o)*s:Math.abs(t[c]-a))<u&&(u=i,l=c);
      return l=!r||u<=r?t[l]:e,n||l===e||X(e)?l:l+en(e)
      }:ec(t))
    },eh=function(t,e,r,n){
    return ee(G(t)?!e:!0===r?(r=0,!1):!n,function(){
      return G(t)?t[~~(Math.random()*t.length)]:(n=(r=r||1e-5)<1?Math.pow(10,(r+"").length-2):1)&&Math.floor(Math.round((t-r/2+Math.random()*(e-t+.99*r))/r)*r*n)/n
      })
    },ep=function(t,e,r){
    return ee(r,function(r){
      return t[~~e(r)]
      })
    },ed=function(t){
    return t.replace($,function(t){
      var e=t.indexOf("[")+1,r=t.substring(e||7,e?t.indexOf("]"):t.length-1).split(Q);
      return eh(e?r:+r[0],e?0:+r[1],+r[2]||1e-5)
      })
    },eg=function(t,e,r,n,i){
    var s=e-t,a=n-r;
    return ee(i,function(e){
      return r+((e-t)/s*a||0)
      })
    },e_=function(t,e,r){
    var n,i,s,a=t.labels,o=1e8;
    for(n in a)
    (i=a[n]-e)<0==!!r&&i&&o>(i=Math.abs(i))&&(s=n,o=i);
    return s
    },em=function(t,e,r){
    var n,i,s,a=t.vars,o=a[e],u=T,l=t._ctx;
    if(o)
    return n=a[e+"Params"],i=a.callbackScope||t,r&&tg.length&&tA(),l&&(T=l),s=n?o.apply(i,n):o.call(i),T=u,s
    },ev=function(t){
    return tW(t),t.scrollTrigger&&t.scrollTrigger.kill(!!b),1>t.progress()&&em(t,"onInterrupt"),t
    },ey=[],ex=function(t){
    if(t)
    if(t=!t.name&&t.default||t,H()||t.headless){
      var e=t.name,r=N(t),n=e&&!r&&t.init?function(){
        this._props=[]
        }:t,i={init:tc,render:ru,add:eJ,kill:rc,modifier:rl,rawVars:0},s={targetTest:0,get:0,getSetter:ri,aliases:{},register:0};
      if(eA(),t!==n){
        if(tm[e])
        return;
        tF(n,tF(tB(t,i),s)),tI(n.prototype,tI(i,tB(t,s))),tm[n.prop=e]=n,t.targetTest&&(tx.push(n),td[e]=1),e=("css"===e?"CSS":e.charAt(0).toUpperCase()+e.substr(1))+"Plugin"
        }
      tl(e,n),t.register&&t.register(rC,n,rp)
      }else 
    ey.push(t)
    },eb={aqua:[0,255,255],lime:[0,255,0],silver:[192,192,192],black:[0,0,0],maroon:[128,0,0],teal:[0,128,128],blue:[0,0,255],navy:[0,0,128],white:[255,255,255],olive:[128,128,0],yellow:[255,255,0],orange:[255,165,0],gray:[128,128,128],purple:[128,0,128],green:[0,128,0],red:[255,0,0],pink:[255,192,203],cyan:[0,255,255],transparent:[255,255,255,0]},eT=function(t,e,r){
    return(6*(t+=t<0?1:t>1?-1:0)<1?e+(r-e)*t*6:t<.5?r:3*t<2?e+(r-e)*(2/3-t)*6:e)*255+.5|0
    },ew=function(t,e,r){
    var n,i,s,a,o,u,l,c,f,h,p=t?X(t)?[t>>16,t>>8&255,255&t]:0:eb.black;
    if(!p){
      if(","===t.substr(-1)&&(t=t.substr(0,t.length-1)),eb[t])
      p=eb[t];
      else 
      if("#"===t.charAt(0)){
        if(t.length<6&&(n=t.charAt(1),t="#"+n+n+(i=t.charAt(2))+i+(s=t.charAt(3))+s+(5===t.length?t.charAt(4)+t.charAt(4):"")),9===t.length)
        return[(p=parseInt(t.substr(1,6),16))>>16,p>>8&255,255&p,parseInt(t.substr(7),16)/255];
        p=[(t=parseInt(t.substr(1),16))>>16,t>>8&255,255&t]
        }else 
      if("hsl"===t.substr(0,3))
      if(p=h=t.match(K),e){
        if(~t.indexOf("="))
        return p=t.match(Z),r&&p.length<4&&(p[3]=1),p
        }else 
      a=p[0]%360/360,o=p[1]/100,i=(u=p[2]/100)<=.5?u*(o+1):u+o-u*o,n=2*u-i,p.length>3&&(p[3]*=1),p[0]=eT(a+1/3,n,i),p[1]=eT(a,n,i),p[2]=eT(a-1/3,n,i);
      else 
      p=t.match(K)||eb.transparent;
      p=p.map(Number)
      }
    return e&&!h&&(n=p[0]/255,u=((l=Math.max(n,i=p[1]/255,s=p[2]/255))+(c=Math.min(n,i,s)))/2,l===c?a=o=0:(f=l-c,o=u>.5?f/(2-l-c):f/(l+c),a=(l===n?(i-s)/f+6*(i<s):l===i?(s-n)/f+2:(n-i)/f+4)*60),p[0]=~~(a+.5),p[1]=~~(100*o+.5),p[2]=~~(100*u+.5)),r&&p.length<4&&(p[3]=1),p
    },ek=function(t){
    var e=[],r=[],n=-1;
    return t.split(eO).forEach(function(t){
      var i=t.match(J)||[];
      e.push.apply(e,i),r.push(n+=i.length+1)
      }),e.c=r,e
    },eM=function(t,e,r){
    var n,i,s,a,o="",u=(t+o).match(eO),l=e?"hsla(":"rgba(",c=0;
    if(!u)
    return t;
    if(u=u.map(function(t){
      return(t=ew(t,e,1))&&l+(e?t[0]+","+t[1]+"%,"+t[2]+"%,"+t[3]:t.join(","))+")"
      }),r&&(s=ek(t),(n=r.c).join(o)!==s.c.join(o)))
    for(a=(i=t.replace(eO,"1").split(J)).length-1;c<a;c++)
    o+=i[c]+(~n.indexOf(c)?u.shift()||l+"0,0,0,0)":(s.length?s:u.length?u:r).shift());
    if(!i)
    for(a=(i=t.split(eO)).length-1;c<a;c++)
    o+=i[c]+u[c];
    return o+i[a]
    },eO=function(){
    var t,e="(?:\\b(?:(?:rgb|rgba|hsl|hsla)\\(.+?\\))|\\B#(?:[0-9a-f]{3,4}){1,2}\\b";
    for(t in eb)
    e+="|"+t+"\\b";
    return RegExp(e+")","gi")
    }(),eC=/hsl[a]?\(/,eS=function(t){
    var e,r=t.join(" ");
    if(eO.lastIndex=0,eO.test(r))
    return e=eC.test(r),t[1]=eM(t[1],e),t[0]=eM(t[0],e,ek(t[1])),!0
    },eE=(f=Date.now,h=500,p=33,g=d=f(),_=1e3/240,m=1e3/240,v=[],y=function t(e){
    var r,n,i,o,y=f()-g,x=!0===e;
    if((y>h||y<0)&&(d+=y-p),g+=y,((r=(i=g-d)-m)>0||x)&&(o=++u.frame,l=i-1e3*u.time,u.time=i/=1e3,m+=r+(r>=_?4:_-r),n=1),x||(s=a(t)),n)
    for(c=0;c<v.length;c++)
    v[c](i,l,o,e)
    },u={time:0,frame:0,tick:function(){
    y(!0)
    },deltaRatio:function(t){
    return l/(1e3/(t||60))
    },wake:function(){
    C&&(!M&&H()&&(O=(k=M=window).document||{},ti.gsap=rC,(k.gsapVersions||(k.gsapVersions=[])).push(rC.version),ta(ts||k.GreenSockGlobals||!k.gsap&&k||{}),ey.forEach(ex)),o="u">typeof requestAnimationFrame&&requestAnimationFrame,s&&u.sleep(),a=o||function(t){
      return setTimeout(t,m-1e3*u.time+1|0)
      },A=1,y(2))
    },sleep:function(){
    (o?cancelAnimationFrame:clearTimeout)(s),A=0,a=tc
    },lagSmoothing:function(t,e){
    p=Math.min(e||33,h=t||1/0)
    },fps:function(t){
    _=1e3/(t||240),m=1e3*u.time+_
    },add:function(t,e,r){
    var n=e?function(e,r,i,s){
      t(e,r,i,s),u.remove(n)
      }:t;
    return u.remove(t),v[r?"unshift":"push"](n),eA(),n
    },remove:function(t,e){
    ~(e=v.indexOf(t))&&v.splice(e,1)&&c>=e&&c--
    },_listeners:v}),eA=function(){
    return!A&&eE.wake()
    },eP={},eD=/^[\d.\-M][\d.\-,\s]/,eR=/["']/g,ez=function(t){
    for(
    var e,r,n,i={},s=t.substr(1,t.length-3).split(":"),a=s[0],o=1,u=s.length
    ;o<u;o++)
    r=s[o],e=o!==u-1?r.lastIndexOf(","):r.length,n=r.substr(0,e),i[a]=isNaN(n)?n.replace(eR,"").trim():+n,a=r.substr(e+1).trim();
    return i
    },eF=function(t){
    var e=t.indexOf("(")+1,r=t.indexOf(")"),n=t.indexOf("(",e);
    return t.substring(e,~n&&n<r?t.indexOf(")",r+1):r)
    },eI=function(t){
    var e=(t+"").split("("),r=eP[e[0]];
    return r&&e.length>1&&r.config?r.config.apply(null,~t.indexOf("{")?[ez(e[1])]:eF(t).split(",").map(tR)):eP._CE&&eD.test(t)?eP._CE("",t):r
    },eY=function(t){
    return function(e){
      return 1-t(1-e)
      }
    },eB=function(t,e){
    return t&&(N(t)?t:eP[t]||eI(t))||e
    },eL=function(t,e,r,n){
    void 0===r&&(r=function(t){
      return 1-e(1-t)
      }),void 0===n&&(n=function(t){
      return t<.5?e(2*t)/2:1-e((1-t)*2)/2
      });
    var i,s={easeIn:e,easeOut:r,easeInOut:n};
    return tM(t,function(t){
      for(
      var e
       in eP[t]=ti[t]=s,eP[i=t.toLowerCase()]=r,s)
      eP[i+("easeIn"===e?".in":"easeOut"===e?".out":".inOut")]=eP[t+"."+e]=s[e]
      }),s
    },eN=function(t){
    return function(e){
      return e<.5?(1-t(1-2*e))/2:.5+t((e-.5)*2)/2
      }
    },eX=function t(e,r,n){
    var i=r>=1?r:1,s=(n||(e?.3:.45))/(r<1?r:1),a=s/R*(Math.asin(1/i)||0),o=function(t){
      return 1===t?1:i*Math.pow(2,-10*t)*B((t-a)*s)+1
      },u="out"===e?o:"in"===e?function(t){
      return 1-o(1-t)
      }:eN(o);
    return s=R/s,u.config=function(r,n){
      return t(e,r,n)
      },u
    },eU=function t(e,r){
    void 0===r&&(r=1.70158);
    var n=function(t){
      return t?--t*t*((r+1)*t+r)+1:0
      },i="out"===e?n:"in"===e?function(t){
      return 1-n(1-t)
      }:eN(n);
    return i.config=function(r){
      return t(e,r)
      },i
    };
  tM("Linear,Quad,Cubic,Quart,Quint,Strong",function(t,e){
    var r=e<5?e+1:e;
    eL(t+",Power"+(r-1),e?function(t){
      return Math.pow(t,r)
      }:function(t){
      return t
      },function(t){
      return 1-Math.pow(1-t,r)
      },function(t){
      return t<.5?Math.pow(2*t,r)/2:1-Math.pow((1-t)*2,r)/2
      })
    }),eP.Linear.easeNone=eP.none=eP.Linear.easeIn,eL("Elastic",eX("in"),eX("out"),eX()),ej=2*(eV=1/2.75),eG=2.5*eV,eL("Bounce",function(t){
    return 1-e$(1-t)
    },e$=function(t){
    return t<eV?7.5625*t*t:t<ej?7.5625*Math.pow(t-1.5/2.75,2)+.75:t<eG?7.5625*(t-=2.25/2.75)*t+.9375:7.5625*Math.pow(t-2.625/2.75,2)+.984375
    }),eL("Expo",function(t){
    return Math.pow(2,10*(t-1))*t+t*t*t*t*t*t*(1-t)
    }),eL("Circ",function(t){
    return-(I(1-t*t)-1)
    }),eL("Sine",function(t){
    return 1===t?1:-Y(t*z)+1
    }),eL("Back",eU("in"),eU("out"),eU()),eP.SteppedEase=eP.steps=ti.SteppedEase={config:function(t,e){
    void 0===t&&(t=1);
    var r=1/t,n=t+ +!e,i=+!!e,s=.99999999;
    return function(t){
      return((n*er(0,s,t)|0)+i)*r
      }
    }},D.ease=eP["quad.out"],tM("onComplete,onUpdate,onStart,onRepeat,onReverseComplete,onInterrupt",function(t){
    return tb+=t+","+t+"Params,"
    });
  var eW=function(t,e){
    this.id=F++,t._gsap=this,this.target=t,this.harness=e,this.get=e?e.get:tk,this.set=e?e.getSetter:ri
    },eq=function(){
    function t(t){
      this.vars=t,this._delay=+t.delay||0,(this._repeat=t.repeat===1/0?-2:t.repeat||0)&&(this._rDelay=t.repeatDelay||0,this._yoyo=!!t.yoyo||!!t.yoyoEase),this._ts=1,t6(this,+t.duration,1,1),this.data=t.data,T&&(this._ctx=T,T.data.push(this)),A||eE.wake()
      }
    var e=t.prototype;
    return e.delay=function(t){
      return t||0===t?(this.parent&&this.parent.smoothChildTiming&&this.startTime(this._start+t-this._delay),this._delay=t,this):this._delay
      },e.duration=function(t){
      return arguments.length?this.totalDuration(this._repeat>0?t+(t+this._rDelay)*this._repeat:t):this.totalDuration()&&this._dur
      },e.totalDuration=function(t){
      return arguments.length?(this._dirty=0,t6(this,this._repeat<0?t:(t-this._repeat*this._rDelay)/(this._repeat+1))):this._tDur
      },e.totalTime=function(t,e){
      if(eA(),!arguments.length)
      return this._tTime;
      var r=this._dp;
      if(r&&r.smoothChildTiming&&this._ts){
        for(tK(this,t),!r._dp||r.parent||tZ(r,this);r&&r.parent;)
        r.parent._time!==r._start+(r._ts>=0?r._tTime/r._ts:-((r.totalDuration()-r._tTime)/r._ts))&&r.totalTime(r._tTime,!0),r=r.parent;
        !this.parent&&this._dp.autoRemoveChildren&&(this._ts>0&&t<this._tDur||this._ts<0&&t>0||!this._tDur&&!t)&&tJ(this._dp,this,this._start-this._delay)
        }
      return(this._tTime!==t||!this._dur&&!e||this._initted&&1e-8===Math.abs(this._zTime)||!this._initted&&this._dur&&t||!t&&!this._initted&&(this.add||this._ptLookup))&&(this._ts||(this._pTime=t),tD(this,t,e)),this
      },e.time=function(t,e){
      return arguments.length?this.totalTime(Math.min(this.totalDuration(),t+tj(this))%(this._dur+this._rDelay)||(t?this._dur:0),e):this._time
      },e.totalProgress=function(t,e){
      return arguments.length?this.totalTime(this.totalDuration()*t,e):this.totalDuration()?Math.min(1,this._tTime/this._tDur):this.rawTime()>=0&&this._initted?1:0
      },e.progress=function(t,e){
      return arguments.length?this.totalTime(this.duration()*(this._yoyo&&!(1&this.iteration())?1-t:t)+tj(this),e):this.duration()?Math.min(1,this._time/this._dur):+(this.rawTime()>0)
      },e.iteration=function(t,e){
      var r=this.duration()+this._rDelay;
      return arguments.length?this.totalTime(this._time+(t-1)*r,e):this._repeat?tG(this._tTime,r)+1:1
      },e.timeScale=function(t,e){
      if(!arguments.length)
      return -1e-8===this._rts?0:this._rts;
      if(this._rts===t)
      return this;
      var r=this.parent&&this._ts?t$(this.parent._time,this):this._tTime;
      return this._rts=+t||0,this._ts=this._ps||-1e-8===t?0:this._rts,this.totalTime(er(-Math.abs(this._delay),this.totalDuration(),r),!1!==e),tQ(this),tH(this)
      },e.paused=function(t){
      return arguments.length?(this._ps!==t&&(this._ps=t,t?(this._pTime=this._tTime||Math.max(-this._delay,this.rawTime()),this._ts=this._act=0):(eA(),this._ts=this._rts,this.totalTime(this.parent&&!this.parent.smoothChildTiming?this.rawTime():this._tTime||this._pTime,1===this.progress()&&1e-8!==Math.abs(this._zTime)&&(this._tTime-=1e-8)))),this):this._ps
      },e.startTime=function(t){
      if(arguments.length){
        this._start=tC(t);
        var e=this.parent||this._dp;
        return e&&(e._sort||!this.parent)&&tJ(e,this,this._start-this._delay),this
        }
      return this._start
      },e.endTime=function(t){
      return this._start+(q(t)?this.totalDuration():this.duration())/Math.abs(this._ts||1)
      },e.rawTime=function(t){
      var e=this.parent||this._dp;
      return e?t&&(!this._ts||this._repeat&&this._time&&1>this.totalProgress())?this._tTime%(this._dur+this._rDelay):this._ts?t$(e.rawTime(t),this):this._tTime:this._tTime
      },e.revert=function(t){
      void 0===t&&(t=tp);
      var e=b;
      return b=t,tP(this)&&(this.timeline&&this.timeline.revert(t),this.totalTime(-.01,t.suppressEvents)),"nested"!==this.data&&!1!==t.kill&&this.kill(),b=e,this
      },e.globalTime=function(t){
      for(
      var e=this,r=arguments.length?t:e.rawTime()
      ;e;)
      r=e._start+r/(Math.abs(e._ts)||1),e=e._dp;
      return!this.parent&&this._sat?this._sat.globalTime(t):r
      },e.repeat=function(t){
      return arguments.length?(this._repeat=t===1/0?-2:t,t4(this)):-2===this._repeat?1/0:this._repeat
      },e.repeatDelay=function(t){
      if(arguments.length){
        var e=this._time;
        return this._rDelay=t,t4(this),e?this.time(e):this
        }
      return this._rDelay
      },e.yoyo=function(t){
      return arguments.length?(this._yoyo=t,this):this._yoyo
      },e.seek=function(t,e){
      return this.totalTime(t7(this,t),q(e))
      },e.restart=function(t,e){
      return this.play().totalTime(t?-this._delay:0,q(e)),this._dur||(this._zTime=-1e-8),this
      },e.play=function(t,e){
      return null!=t&&this.seek(t,e),this.reversed(!1).paused(!1)
      },e.reverse=function(t,e){
      return null!=t&&this.seek(t||this.totalDuration(),e),this.reversed(!0).paused(!1)
      },e.pause=function(t,e){
      return null!=t&&this.seek(t,e),this.paused(!0)
      },e.resume=function(){
      return this.paused(!1)
      },e.reversed=function(t){
      return arguments.length?(!!t!==this.reversed()&&this.timeScale(-this._rts||(t?-1e-8:0)),this):this._rts<0
      },e.invalidate=function(){
      return this._initted=this._act=0,this._zTime=-1e-8,this
      },e.isActive=function(){
      var t,e=this.parent||this._dp,r=this._start;
      return!!(!e||this._ts&&this._initted&&e.isActive()&&(t=e.rawTime(!0))>=r&&t<this.endTime(!0)-1e-8)
      },e.eventCallback=function(t,e,r){
      var n=this.vars;
      return arguments.length>1?(e?(n[t]=e,r&&(n[t+"Params"]=r),"onUpdate"===t&&(this._onUpdate=e)):delete n[t],this):n[t]
      },e.then=function(t){
      var e=this,r=e._prom;
      return new Promise(function(n){
        var i=N(t)?t:tz,s=function(){
          var t=e.then;
          e.then=null,r&&r(),N(i)&&(i=i(e))&&(i.then||i===e)&&(e.then=t),n(i),e.then=t
          };
        e._initted&&1===e.totalProgress()&&e._ts>=0||!e._tTime&&e._ts<0?s():e._prom=s
        })
      },e.kill=function(){
      ev(this)
      },t
    }();
  tF(eq.prototype,{_time:0,_start:0,_end:0,_tTime:0,_tDur:0,_dirty:0,_repeat:0,_yoyo:!1,parent:null,_initted:!1,_rDelay:0,_ts:1,_dp:0,ratio:0,_zTime:-1e-8,_prom:0,_ps:!1,_rts:1});
  var eH=function(t){
    function n(r,n){
      var i;
      return void 0===r&&(r={}),(i=t.call(this,r)||this).labels={},i.smoothChildTiming=!!r.smoothChildTiming,i.autoRemoveChildren=!!r.autoRemoveChildren,i._sort=q(r.sortChildren),w&&tJ(r.parent||w,e(i),n),r.reversed&&i.reverse(),r.paused&&i.paused(!0),r.scrollTrigger&&t0(e(i),r.scrollTrigger),i
      }
    r(n,t);
    var i=n.prototype;
    return i.to=function(t,e,r){
      return et(0,arguments,this),this
      },i.from=function(t,e,r){
      return et(1,arguments,this),this
      },i.fromTo=function(t,e,r,n){
      return et(2,arguments,this),this
      },i.set=function(t,e,r){
      return e.duration=0,e.parent=this,tL(e).repeatDelay||(e.repeat=0),e.immediateRender=!!e.immediateRender,new e7(t,e,t7(this,r),1),this
      },i.call=function(t,e,r){
      return tJ(this,e7.delayedCall(0,t,e),r)
      },i.staggerTo=function(t,e,r,n,i,s,a){
      return r.duration=e,r.stagger=r.stagger||n,r.onComplete=s,r.onCompleteParams=a,r.parent=this,new e7(t,r,t7(this,i)),this
      },i.staggerFrom=function(t,e,r,n,i,s,a){
      return r.runBackwards=1,tL(r).immediateRender=q(r.immediateRender),this.staggerTo(t,e,r,n,i,s,a)
      },i.staggerFromTo=function(t,e,r,n,i,s,a,o){
      return n.startAt=r,tL(n).immediateRender=q(n.immediateRender),this.staggerTo(t,e,n,i,s,a,o)
      },i.render=function(t,e,r){
      var n,i,s,a,o,u,l,c,f,h,p,d,g=this._time,_=this._dirty?this.totalDuration():this._tDur,m=this._dur,v=t<=0?0:tC(t),y=this._zTime<0!=t<0&&(this._initted||!m);
      if(this!==w&&v>_&&t>=0&&(v=_),v!==this._tTime||r||y){
        if(g!==this._time&&m&&(v+=this._time-g,t+=this._time-g),n=v,f=this._start,u=!(c=this._ts),y&&(m||(g=this._zTime),(t||!e)&&(this._zTime=t)),this._repeat){
          if(p=this._yoyo,o=m+this._rDelay,this._repeat<-1&&t<0)
          return this.totalTime(100*o+t,e,r);
          if(n=tC(v%o),v===_?(a=this._repeat,n=m):((a=~~(h=tC(v/o)))&&a===h&&(n=m,a--),n>m&&(n=m)),h=tG(this._tTime,o),!g&&this._tTime&&h!==a&&this._tTime-h*o-this._dur<=0&&(h=a),p&&1&a&&(n=m-n,d=1),a!==h&&!this._lock){
            var x=p&&1&h,T=x===(p&&1&a);
            if(a<h&&(x=!x),g=x?0:v%m?m:v,this._lock=1,this.render(g||(d?0:tC(a*o)),e,!m)._lock=0,this._tTime=v,!e&&this.parent&&em(this,"onRepeat"),this.vars.repeatRefresh&&!d&&(this.invalidate()._lock=1,h=a),g&&g!==this._time||!this._ts!==u||this.vars.onRepeat&&!this.parent&&!this._act||(m=this._dur,_=this._tDur,T&&(this._lock=2,g=x?m:-1e-4,this.render(g,!0),this.vars.repeatRefresh&&!d&&this.invalidate()),this._lock=0,!this._ts&&!u))
            return this
            }
          }
        if(this._hasPause&&!this._forcing&&this._lock<2&&(l=t8(this,tC(g),tC(n)))&&(v-=n-(n=l._start)),this._tTime=v,this._time=n,this._act=!!c,this._initted||(this._onUpdate=this.vars.onUpdate,this._initted=1,this._zTime=t,g=0),!g&&v&&m&&!e&&!h&&(em(this,"onStart"),this._tTime!==v))
        return this;
        if(n>=g&&t>=0)
        for(i=this._first;i;){
          if(s=i._next,(i._act||n>=i._start)&&i._ts&&l!==i){
            if(i.parent!==this)
            return this.render(t,e,r);
            if(i.render(i._ts>0?(n-i._start)*i._ts:(i._dirty?i.totalDuration():i._tDur)+(n-i._start)*i._ts,e,r),n!==this._time||!this._ts&&!u){
              l=0,s&&(v+=this._zTime=-1e-8);
              break
              }
            }
          i=s
          }
        else{
          i=this._last;
          for(
          var k=t<0?t:n
          ;i;){
            if(s=i._prev,(i._act||k<=i._end)&&i._ts&&l!==i){
              if(i.parent!==this)
              return this.render(t,e,r);
              if(i.render(i._ts>0?(k-i._start)*i._ts:(i._dirty?i.totalDuration():i._tDur)+(k-i._start)*i._ts,e,r||b&&tP(i)),n!==this._time||!this._ts&&!u){
                l=0,s&&(v+=this._zTime=k?-1e-8:1e-8);
                break
                }
              }
            i=s
            }
          }
        if(l&&!e&&(this.pause(),l.render(n>=g?0:-1e-8)._zTime=n>=g?1:-1,this._ts))
        return this._start=f,tQ(this),this.render(t,e,r);
        this._onUpdate&&!e&&em(this,"onUpdate",!0),(v===_&&this._tTime>=this.totalDuration()||!v&&g)&&(f===this._start||Math.abs(c)!==Math.abs(this._ts))&&!this._lock&&((t||!m)&&(v===_&&this._ts>0||!v&&this._ts<0)&&tW(this,1),e||t<0&&!g||!v&&!g&&_||(em(this,v===_&&t>=0?"onComplete":"onReverseComplete",!0),this._prom&&!(v<_&&this.timeScale()>0)&&this._prom()))
        }
      return this
      },i.add=function(t,e){
      var r=this;
      if(X(e)||(e=t7(this,e,t)),!(t instanceof eq)){
        if(G(t))
        return t.forEach(function(t){
          return r.add(t,e)
          }),this;
        if(L(t))
        return this.addLabel(t,e);
        if(!N(t))
        return this;
        t=e7.delayedCall(0,t)
        }
      return this!==t?tJ(this,t,e):this
      },i.getChildren=function(t,e,r,n){
      void 0===t&&(t=!0),void 0===e&&(e=!0),void 0===r&&(r=!0),void 0===n&&(n=-1e8);
      for(
      var i=[],s=this._first
      ;s;)
      s._start>=n&&(s instanceof e7?e&&i.push(s):(r&&i.push(s),t&&i.push.apply(i,s.getChildren(!0,e,r)))),s=s._next;
      return i
      },i.getById=function(t){
      for(
      var e=this.getChildren(1,1,1),r=e.length
      ;r--;)
      if(e[r].vars.id===t)
      return e[r]
      },i.remove=function(t){
      return L(t)?this.removeLabel(t):N(t)?this.killTweensOf(t):(t.parent===this&&tU(this,t),t===this._recent&&(this._recent=this._last),tq(this))
      },i.totalTime=function(e,r){
      return arguments.length?(this._forcing=1,!this._dp&&this._ts&&(this._start=tC(eE.time-(this._ts>0?e/this._ts:-((this.totalDuration()-e)/this._ts)))),t.prototype.totalTime.call(this,e,r),this._forcing=0,this):this._tTime
      },i.addLabel=function(t,e){
      return this.labels[t]=t7(this,e),this
      },i.removeLabel=function(t){
      return delete this.labels[t],this
      },i.addPause=function(t,e,r){
      var n=e7.delayedCall(0,e||tc,r);
      return n.data="isPause",this._hasPause=1,tJ(this,n,t7(this,t))
      },i.removePause=function(t){
      var e=this._first;
      for(t=t7(this,t);e;)
      e._start===t&&"isPause"===e.data&&tW(e),e=e._next
      },i.killTweensOf=function(t,e,r){
      for(
      var n=this.getTweensOf(t,r),i=n.length
      ;i--;)
      eQ!==n[i]&&n[i].kill(t,e);
      return this
      },i.getTweensOf=function(t,e){
      for(
      var r,n=[],i=ea(t),s=this._first,a=X(e)
      ;s;)
      s instanceof e7?tE(s._targets,i)&&(a?(!eQ||s._initted&&s._ts)&&s.globalTime(0)<=e&&s.globalTime(s.totalDuration())>e:!e||s.isActive())&&n.push(s):(r=s.getTweensOf(i,e)).length&&n.push.apply(n,r),s=s._next;
      return n
      },i.tweenTo=function(t,e){
      e=e||{};
      var r,n=this,i=t7(n,t),s=e,a=s.startAt,o=s.onStart,u=s.onStartParams,l=s.immediateRender,c=e7.to(n,tF({ease:e.ease||"none",lazy:!1,immediateRender:!1,time:i,overwrite:"auto",duration:e.duration||Math.abs((i-(a&&"time"in a?a.time:n._time))/n.timeScale())||1e-8,onStart:function(){
        if(n.pause(),!r){
          var t=e.duration||Math.abs((i-(a&&"time"in a?a.time:n._time))/n.timeScale());
          c._dur!==t&&t6(c,t,0,1).render(c._time,!0,!0),r=1
          }
        o&&o.apply(c,u||[])
        }},e));
      return l?c.render(0):c
      },i.tweenFromTo=function(t,e,r){
      return this.tweenTo(e,tF({startAt:{time:t7(this,t)}},r))
      },i.recent=function(){
      return this._recent
      },i.nextLabel=function(t){
      return void 0===t&&(t=this._time),e_(this,t7(this,t))
      },i.previousLabel=function(t){
      return void 0===t&&(t=this._time),e_(this,t7(this,t),1)
      },i.currentLabel=function(t){
      return arguments.length?this.seek(t,!0):this.previousLabel(this._time+1e-8)
      },i.shiftChildren=function(t,e,r){
      void 0===r&&(r=0);
      var n,i=this._first,s=this.labels;
      for(t=tC(t);i;)
      i._start>=r&&(i._start+=t,i._end+=t),i=i._next;
      if(e)
      for(n in s)
      s[n]>=r&&(s[n]+=t);
      return tq(this)
      },i.invalidate=function(e){
      var r=this._first;
      for(this._lock=0;r;)
      r.invalidate(e),r=r._next;
      return t.prototype.invalidate.call(this,e)
      },i.clear=function(t){
      void 0===t&&(t=!0);
      for(
      var e,r=this._first
      ;r;)
      e=r._next,this.remove(r),r=e;
      return this._dp&&(this._time=this._tTime=this._pTime=0),t&&(this.labels={}),tq(this)
      },i.totalDuration=function(t){
      var e,r,n,i=0,s=this._last,a=1e8;
      if(arguments.length)
      return this.timeScale((this._repeat<0?this.duration():this.totalDuration())/(this.reversed()?-t:t));
      if(this._dirty){
        for(n=this.parent;s;)
        e=s._prev,s._dirty&&s.totalDuration(),(r=s._start)>a&&this._sort&&s._ts&&!this._lock?(this._lock=1,tJ(this,s,r-s._delay,1)._lock=0):a=r,r<0&&s._ts&&(i-=r,(!n&&!this._dp||n&&n.smoothChildTiming)&&(this._start+=tC(r/this._ts),this._time-=r,this._tTime-=r),this.shiftChildren(-r,!1,-Infinity),a=0),s._end>i&&s._ts&&(i=s._end),s=e;
        t6(this,this===w&&this._time>i?this._time:i,1,1),this._dirty=0
        }
      return this._tDur
      },n.updateRoot=function(t){
      if(w._ts&&(tD(w,t$(t,w)),S=eE.frame),eE.frame>=ty){
        ty+=P.autoSleep||120;
        var e=w._first;
        if((!e||!e._ts)&&P.autoSleep&&eE._listeners.length<2){
          for(;e&&!e._ts;)
          e=e._next;
          e||eE.sleep()
          }
        }
      },n
    }(eq);
  tF(eH.prototype,{_lock:0,_hasPause:0,_forcing:0});
  var eV,ej,eG,e$,eQ,eK,eZ=function(t,e,r,n,i,s,a){
    var o,u,l,c,f,h,p,d,g=new rp(this._pt,t,e,0,1,ro,null,i),_=0,m=0;
    for(g.b=r,g.e=n,r+="",n+="",(p=~n.indexOf("random("))&&(n=ed(n)),s&&(s(d=[r,n],t,e),r=d[0],n=d[1]),u=r.match(tt)||[];o=tt.exec(n);)
    c=o[0],f=n.substring(_,o.index),l?l=(l+1)%5:"rgba("===f.substr(-5)&&(l=1),c!==u[m++]&&(h=parseFloat(u[m-1])||0,g._pt={_next:g._pt,p:f||1===m?f:",",s:h,c:"="===c.charAt(1)?tS(h,c)-h:parseFloat(c)-h,m:l&&l<4?Math.round:0},_=tt.lastIndex);
    return g.c=_<n.length?n.substring(_,n.length):"",g.fp=a,(te.test(n)||p)&&(g.e=0),this._pt=g,g
    },eJ=function(t,e,r,n,i,s,a,o,u,l){
    N(n)&&(n=n(i||0,t,s));
    var c,f=t[e],h="get"!==r?r:N(f)?u?t[e.indexOf("set")||!N(t["get"+e.substr(3)])?e:"get"+e.substr(3)](u):t[e]():f,p=N(f)?u?rr:re:rt;
    if(L(n)&&(~n.indexOf("random(")&&(n=ed(n)),"="===n.charAt(1)&&((c=tS(h,n)+(en(h)||0))||0===c)&&(n=c)),!l||h!==n||eK)
    return isNaN(h*n)||""===n?(f||e in t||to(e,n),eZ.call(this,t,e,h,n,p,o||P.stringFilter,u)):(c=new rp(this._pt,t,e,+h||0,n-(h||0),"boolean"==typeof f?ra:rs,0,p),u&&(c.fp=u),a&&c.modifier(a,this,t),this._pt=c)
    },e0=function(t,e,r,n,i){
    if(N(t)&&(t=e6(t,i,e,r,n)),!W(t)||t.style&&t.nodeType||G(t)||j(t))
    return L(t)?e6(t,i,e,r,n):t;
    var s,a={};
    for(s in t)
    a[s]=e6(t[s],i,e,r,n);
    return a
    },e1=function(t,e,r,n,i,s){
    var a,o,u,l;
    if(tm[t]&&!1!==(a=new tm[t]).init(i,a.rawVars?e[t]:e0(e[t],n,i,s,r),r,n,s)&&(r._pt=o=new rp(r._pt,i,t,0,1,a.render,a,0,a.priority),r!==E))
    for(u=r._ptLookup[r._targets.indexOf(i)],l=a._props.length;l--;)
    u[a._props[l]]=o;
    return a
    },e2=function t(e,r,n){
    var i,s,a,o,u,l,c,f,h,p,d,g,_,m=e.vars,v=m.ease,y=m.startAt,T=m.immediateRender,k=m.lazy,M=m.onUpdate,O=m.runBackwards,C=m.yoyoEase,S=m.keyframes,E=m.autoRevert,A=e._dur,P=e._startAt,R=e._targets,z=e.parent,F=z&&"nested"===z.data?z.vars.targets:R,I="auto"===e._overwrite&&!x,Y=e.timeline,B=m.easeReverse||C;
    if(!Y||S&&v||(v="none"),e._ease=eB(v,D.ease),e._rEase=B&&(eB(B)||e._ease),e._from=!Y&&!!m.runBackwards,e._from&&(e.ratio=1),!Y||S&&!m.stagger){
      if(g=(f=R[0]?tw(R[0]).harness:0)&&m[f.prop],i=tB(m,td),P&&(P._zTime<0&&P.progress(1),r<0&&O&&T&&!E?P.render(-1,!0):P.revert(O&&A?th:tf),P._lazy=0),y){
        if(tW(e._startAt=e7.set(R,tF({data:"isStart",overwrite:!1,parent:z,immediateRender:!0,lazy:!P&&q(k),startAt:null,delay:0,onUpdate:M&&function(){
          return em(e,"onUpdate")
          },stagger:0},y))),e._startAt._dp=0,e._startAt._sat=e,r<0&&(b||!T&&!E)&&e._startAt.revert(th),T&&A&&r<=0&&n<=0){
          r&&(e._zTime=r);
          return
          }
        }else 
      if(O&&A&&!P)
      if(r&&(T=!1),a=tF({overwrite:!1,data:"isFromStart",lazy:T&&!P&&q(k),immediateRender:T,stagger:0,parent:z},i),g&&(a[f.prop]=g),tW(e._startAt=e7.set(R,a)),e._startAt._dp=0,e._startAt._sat=e,r<0&&(b?e._startAt.revert(th):e._startAt.render(-1,!0)),e._zTime=r,T){
        if(!r)
        return
        }else 
      t(e._startAt,1e-8,1e-8);
      for(s=0,e._pt=e._ptCache=0,k=A&&q(k)||k&&!A;s<R.length;s++){
        if(c=(u=R[s])._gsap||tT(R)[s]._gsap,e._ptLookup[s]=p={},t_[c.id]&&tg.length&&tA(),d=F===R?s:F.indexOf(u),f&&!1!==(h=new f).init(u,g||i,e,d,F)&&(e._pt=o=new rp(e._pt,u,h.name,0,1,h.render,h,0,h.priority),h._props.forEach(function(t){
          p[t]=o
          }),h.priority&&(l=1)),!f||g)
        for(a in i)
        tm[a]&&(h=e1(a,i,e,d,u,F))?h.priority&&(l=1):p[a]=o=eJ.call(e,u,a,"get",i[a],d,F,0,m.stringFilter);
        e._op&&e._op[s]&&e.kill(u,e._op[s]),I&&e._pt&&(eQ=e,w.killTweensOf(u,p,e.globalTime(r)),_=!e.parent,eQ=0),e._pt&&k&&(t_[c.id]=1)
        }
      l&&rh(e),e._onInit&&e._onInit(e)
      }
    e._onUpdate=M,e._initted=(!e._op||e._pt)&&!_,S&&r<=0&&Y.render(1e8,!0,!0)
    },e5=function(t,e,r,n,i,s,a,o){
    var u,l,c,f,h=(t._pt&&t._ptCache||(t._ptCache={}))[e];
    if(!h)
    for(h=t._ptCache[e]=[],c=t._ptLookup,f=t._targets.length;f--;){
      if((u=c[f][e])&&u.d&&u.d._pt)
      for(u=u.d._pt;u&&u.p!==e&&u.fp!==e;)
      u=u._next;
      if(!u)
      return eK=1,t.vars[e]="+=0",e2(t,a),eK=0,o?tu(e+" not eligible for reset. Try splitting into individual properties"):1;
      h.push(u)
      }
    for(f=h.length;f--;)
    (u=(l=h[f])._pt||l).s=(n||0===n)&&!i?n:u.s+(n||0)+s*u.c,u.c=r-u.s,l.e&&(l.e=tO(r)+en(l.e)),l.b&&(l.b=u.s+en(l.b))
    },e3=function(t,e){
    var r,n,i,s,a=t[0]?tw(t[0]).harness:0,o=a&&a.aliases;
    if(!o)
    return e;
    for(n in r=tI({},e),o)
    if(n in r)
    for(i=(s=o[n].split(",")).length;i--;)
    r[s[i]]=r[n];
    return r
    },e8=function(t,e,r,n){
    var i,s,a=e.ease||n||"power1.inOut";
    if(G(e))
    s=r[t]||(r[t]=[]),e.forEach(function(t,r){
      return s.push({t:r/(e.length-1)*100,v:t,e:a})
      });
    else 
    for(i in e)
    s=r[i]||(r[i]=[]),"ease"===i||s.push({t:parseFloat(t),v:e[i],e:a})
    },e6=function(t,e,r,n,i){
    return N(t)?t.call(e,r,n,i):L(t)&&~t.indexOf("random(")?ed(t):t
    },e4=tb+"repeat,repeatDelay,yoyo,repeatRefresh,yoyoEase,easeReverse,autoRevert",e9={};
  tM(e4+",id,stagger,delay,duration,paused,scrollTrigger",function(t){
    return e9[t]=1
    });
  var e7=function(t){
    function n(r,n,i,s){
      "number"==typeof n&&(i.duration=n,n=i,i=null);
      var a,o,u,l,c,f,h,p,d=t.call(this,s?n:tL(n))||this,g=d.vars,_=g.duration,m=g.delay,v=g.immediateRender,y=g.stagger,b=g.overwrite,T=g.keyframes,k=g.defaults,M=g.scrollTrigger,O=n.parent||w,C=(G(r)||j(r)?X(r[0]):"length"in n)?[r]:ea(r);
      if(d._targets=C.length?tT(C):tu("GSAP target "+r+" not found. https://gsap.com",!P.nullTargetWarn)||[],d._ptLookup=[],d._overwrite=b,T||y||V(_)||V(m)){
        var S=(n=d.vars).easeReverse||n.yoyoEase;
        if((a=d.timeline=new eH({data:"nested",defaults:k||{},targets:O&&"nested"===O.data?O.vars.targets:C})).kill(),a.parent=a._dp=e(d),a._start=0,y||V(_)||V(m)){
          if(l=C.length,h=y&&el(y),W(y))
          for(c in y)
          ~e4.indexOf(c)&&(p||(p={}),p[c]=y[c]);
          for(o=0;o<l;o++)
          (u=tB(n,e9)).stagger=0,S&&(u.easeReverse=S),p&&tI(u,p),f=C[o],u.duration=+e6(_,e(d),o,f,C),u.delay=(+e6(m,e(d),o,f,C)||0)-d._delay,!y&&1===l&&u.delay&&(d._delay=m=u.delay,d._start+=m,u.delay=0),a.to(f,u,h?h(o,f,C):0),a._ease=eP.none;
          a.duration()?_=m=0:d.timeline=0
          }else 
        if(T){
          tL(tF(a.vars.defaults,{ease:"none"})),a._ease=eB(T.ease||n.ease||"none");
          var E,A,D,R=0;
          if(G(T))
          T.forEach(function(t){
            return a.to(C,t,">")
            }),a.duration();
          else{
            for(c in u={},T)
            "ease"===c||"easeEach"===c||e8(c,T[c],u,T.easeEach);
            for(c in u)
            for(o=0,E=u[c].sort(function(t,e){
              return t.t-e.t
              }),R=0;o<E.length;o++)
            (D={ease:(A=E[o]).e,duration:(A.t-(o?E[o-1].t:0))/100*_})[c]=A.v,a.to(C,D,R),R+=D.duration;
            a.duration()<_&&a.to({},{duration:_-a.duration()})
            }
          }
        _||d.duration(_=a.duration())
        }else 
      d.timeline=0;
      return!0!==b||x||(eQ=e(d),w.killTweensOf(C),eQ=0),tJ(O,e(d),i),n.reversed&&d.reverse(),n.paused&&d.paused(!0),(v||!_&&!T&&d._start===tC(O._time)&&q(v)&&function t(e){
        return!e||e._ts&&t(e.parent)
        }(e(d))&&"nested"!==O.data)&&(d._tTime=-1e-8,d.render(Math.max(0,-m)||0)),M&&t0(e(d),M),d
      }
    r(n,t);
    var i=n.prototype;
    return i.render=function(t,e,r){
      var n,i,s,a,o,u,l,c,f=this._time,h=this._tDur,p=this._dur,d=t<0,g=t>h-1e-8&&!d?h:t<1e-8?0:t;
      if(p){
        if(g!==this._tTime||!t||r||!this._initted&&this._tTime||this._startAt&&this._zTime<0!==d||this._lazy){
          if(n=g,c=this.timeline,this._repeat){
            if(a=p+this._rDelay,this._repeat<-1&&d)
            return this.totalTime(100*a+t,e,r);
            if(n=tC(g%a),g===h?(s=this._repeat,n=p):(s=~~(o=tC(g/a)))&&s===o?(n=p,s--):n>p&&(n=p),(u=this._yoyo&&1&s)&&(n=p-n),o=tG(this._tTime,a),n===f&&!r&&this._initted&&s===o)
            return this._tTime=g,this;
            s!==o&&this.vars.repeatRefresh&&!u&&!this._lock&&n!==a&&this._initted&&(this._lock=r=1,this.render(tC(a*s),!0).invalidate()._lock=0)
            }
          if(!this._initted){
            if(t1(this,d?t:n,r,e,g))
            return this._tTime=0,this;
            if(f!==this._time&&!(r&&this.vars.repeatRefresh&&s!==o))
            return this;
            if(p!==this._dur)
            return this.render(t,e,r)
            }
          if(this._rEase){
            var _=n<f;
            if(_!==this._inv){
              var m=_?f:p-f;
              this._inv=_,this._from&&(this.ratio=1-this.ratio),this._invRatio=this.ratio,this._invTime=f,this._invRecip=m?(_?-1:1)/m:0,this._invScale=_?-this.ratio:1-this.ratio,this._invEase=_?this._rEase:this._ease
              }
            this.ratio=l=this._invRatio+this._invScale*this._invEase((n-this._invTime)*this._invRecip)
            }else 
          this.ratio=l=this._ease(n/p);
          if(this._from&&(this.ratio=l=1-l),this._tTime=g,this._time=n,!this._act&&this._ts&&(this._act=1,this._lazy=0),!f&&g&&!e&&!o&&(em(this,"onStart"),this._tTime!==g))
          return this;
          for(i=this._pt;i;)
          i.r(l,i.d),i=i._next;
          c&&c.render(t<0?t:c._dur*c._ease(n/this._dur),e,r)||this._startAt&&(this._zTime=t),this._onUpdate&&!e&&(d&&tV(this,t,e,r),em(this,"onUpdate")),this._repeat&&s!==o&&this.vars.onRepeat&&!e&&this.parent&&em(this,"onRepeat"),(g===this._tDur||!g)&&this._tTime===g&&(d&&!this._onUpdate&&tV(this,t,!0,!0),(t||!p)&&(g===this._tDur&&this._ts>0||!g&&this._ts<0)&&tW(this,1),!e&&!(d&&!f)&&(g||f||u)&&(em(this,g===h?"onComplete":"onReverseComplete",!0),this._prom&&!(g<h&&this.timeScale()>0)&&this._prom()))
          }
        }else 
      t3(this,t,e,r);
      return this
      },i.targets=function(){
      return this._targets
      },i.invalidate=function(e){
      return e&&this.vars.runBackwards||(this._startAt=0),this._pt=this._op=this._onUpdate=this._lazy=this.ratio=0,this._ptLookup=[],this.timeline&&this.timeline.invalidate(e),t.prototype.invalidate.call(this,e)
      },i.resetTo=function(t,e,r,n,i){
      A||eE.wake(),this._ts||this.play();
      var s=Math.min(this._dur,(this._dp._time-this._start)*this._ts);
      return(this._initted||e2(this,s),e5(this,t,e,r,n,this._ease(s/this._dur),s,i))?this.resetTo(t,e,r,n,1):(tK(this,0),this.parent||tX(this._dp,this,"_first","_last",this._dp._sort?"_start":0),this.render(0))
      },i.kill=function(t,e){
      if(void 0===e&&(e="all"),!t&&(!e||"all"===e))
      return this._lazy=this._pt=0,this.parent?ev(this):this.scrollTrigger&&this.scrollTrigger.kill(!!b),this;
      if(this.timeline){
        var r=this.timeline.totalDuration();
        return this.timeline.killTweensOf(t,e,eQ&&!0!==eQ.vars.overwrite)._first||ev(this),this.parent&&r!==this.timeline.totalDuration()&&t6(this,this._dur*this.timeline._tDur/r,0,1),this
        }
      var n,i,s,a,o,u,l,c=this._targets,f=t?ea(t):c,h=this._ptLookup,p=this._pt;
      if((!e||"all"===e)&&tN(c,f))
      return"all"===e&&(this._pt=0),ev(this);
      for(n=this._op=this._op||[],"all"!==e&&(L(e)&&(o={},tM(e,function(t){
        return o[t]=1
        }),e=o),e=e3(c,e)),l=c.length;l--;)
      if(~f.indexOf(c[l]))
      for(o in i=h[l],"all"===e?(n[l]=e,a=i,s={}):(s=n[l]=n[l]||{},a=e),a)
      (u=i&&i[o])&&("kill"in u.d&&!0!==u.d.kill(o)||tU(this,u,"_pt"),delete i[o]),"all"!==s&&(s[o]=1);
      return this._initted&&!this._pt&&p&&ev(this),this
      },n.to=function(t,e){
      return new n(t,e,arguments[2])
      },n.from=function(t,e){
      return et(1,arguments)
      },n.delayedCall=function(t,e,r,i){
      return new n(e,0,{immediateRender:!1,lazy:!1,overwrite:!1,delay:t,onComplete:e,onReverseComplete:e,onCompleteParams:r,onReverseCompleteParams:r,callbackScope:i})
      },n.fromTo=function(t,e,r){
      return et(2,arguments)
      },n.set=function(t,e){
      return e.duration=0,e.repeatDelay||(e.repeat=0),new n(t,e)
      },n.killTweensOf=function(t,e,r){
      return w.killTweensOf(t,e,r)
      },n
    }(eq);
  tF(e7.prototype,{_targets:[],_lazy:0,_startAt:0,_op:0,_onInit:0}),tM("staggerTo,staggerFrom,staggerFromTo",function(t){
    e7[t]=function(){
      var e=new eH,r=ei.call(arguments,0);
      return r.splice("staggerFromTo"===t?5:4,0,0),e[t].apply(e,r)
      }
    });
  var rt=function(t,e,r){
    return t[e]=r
    },re=function(t,e,r){
    return t[e](r)
    },rr=function(t,e,r,n){
    return t[e](n.fp,r)
    },rn=function(t,e,r){
    return t.setAttribute(e,r)
    },ri=function(t,e){
    return N(t[e])?re:U(t[e])&&t.setAttribute?rn:rt
    },rs=function(t,e){
    return e.set(e.t,e.p,Math.round((e.s+e.c*t)*1e6)/1e6,e)
    },ra=function(t,e){
    return e.set(e.t,e.p,!!(e.s+e.c*t),e)
    },ro=function(t,e){
    var r=e._pt,n="";
    if(!t&&e.b)
    n=e.b;
    else 
    if(1===t&&e.e)
    n=e.e;
    else{
      for(;r;)
      n=r.p+(r.m?r.m(r.s+r.c*t):Math.round((r.s+r.c*t)*1e4)/1e4)+n,r=r._next;
      n+=e.c
      }
    e.set(e.t,e.p,n,e)
    },ru=function(t,e){
    for(
    var r=e._pt
    ;r;)
    r.r(t,r.d),r=r._next
    },rl=function(t,e,r,n){
    for(
    var i,s=this._pt
    ;s;)
    i=s._next,s.p===n&&s.modifier(t,e,r),s=i
    },rc=function(t){
    for(
    var e,r,n=this._pt
    ;n;)
    r=n._next,(n.p!==t||n.op)&&n.op!==t?n.dep||(e=1):tU(this,n,"_pt"),n=r;
    return!e
    },rf=function(t,e,r,n){
    n.mSet(t,e,n.m.call(n.tween,r,n.mt),n)
    },rh=function(t){
    for(
    var e,r,n,i,s=t._pt
    ;s;){
      for(e=s._next,r=n;r&&r.pr>s.pr;)
      r=r._next;
      (s._prev=r?r._prev:i)?s._prev._next=s:n=s,(s._next=r)?r._prev=s:i=s,s=e
      }
    t._pt=n
    },rp=function(){
    function t(t,e,r,n,i,s,a,o,u){
      this.t=e,this.s=n,this.c=i,this.p=r,this.r=s||rs,this.d=a||this,this.set=o||rt,this.pr=u||0,this._next=t,t&&(t._prev=this)
      }
    return t.prototype.modifier=function(t,e,r){
      this.mSet=this.mSet||this.set,this.set=rf,this.m=t,this.mt=r,this.tween=e
      },t
    }();
  tM(tb+"parent,duration,ease,delay,overwrite,runBackwards,startAt,yoyo,immediateRender,repeat,repeatDelay,data,paused,reversed,lazy,callbackScope,stringFilter,id,yoyoEase,stagger,inherit,repeatRefresh,keyframes,autoRevert,scrollTrigger,easeReverse",function(t){
    return td[t]=1
    }),ti.TweenMax=ti.TweenLite=e7,ti.TimelineLite=ti.TimelineMax=eH,w=new eH({sortChildren:!1,defaults:D,autoRemoveChildren:!0,id:"root",smoothChildTiming:!0}),P.stringFilter=eS;
  var rd=[],rg={},r_=[],rm=0,rv=0,ry=function(t){
    return(rg[t]||r_).map(function(t){
      return t()
      })
    },rx=function(){
    var t=Date.now(),e=[];
    t-rm>2&&(ry("matchMediaInit"),rd.forEach(function(t){
      var r,n,i,s,a=t.queries,o=t.conditions;
      for(n in a)
      (r=k.matchMedia(a[n]).matches)&&(i=1),r!==o[n]&&(o[n]=r,s=1);
      s&&(t.revert(),i&&e.push(t))
      }),ry("matchMediaRevert"),e.forEach(function(t){
      return t.onMatch(t,function(e){
        return t.add(null,e)
        })
      }),rm=t,ry("matchMedia"))
    },rb=function(){
    function t(t,e){
      this.selector=e&&eo(e),this.data=[],this._r=[],this.isReverted=!1,this.id=rv++,t&&this.add(t)
      }
    var e=t.prototype;
    return e.add=function(t,e,r){
      N(t)&&(r=e,e=t,t=N);
      var n=this,i=function(){
        var t,i=T,s=n.selector;
        return i&&i!==n&&i.data.push(n),r&&(n.selector=eo(r)),T=n,t=e.apply(n,arguments),N(t)&&n._r.push(t),T=i,n.selector=s,n.isReverted=!1,t
        };
      return n.last=i,t===N?i(n,function(t){
        return n.add(null,t)
        }):t?n[t]=i:i
      },e.ignore=function(t){
      var e=T;
      T=null,t(this),T=e
      },e.getTweens=function(){
      var e=[];
      return this.data.forEach(function(r){
        return r instanceof t?e.push.apply(e,r.getTweens()):r instanceof e7&&!(r.parent&&"nested"===r.parent.data)&&e.push(r)
        }),e
      },e.clear=function(){
      this._r.length=this.data.length=0
      },e.kill=function(t,e){
      var r=this;
      if(t){
        for(
        var n,i=r.getTweens(),s=r.data.length
        ;s--;)
        "isFlip"===(n=r.data[s]).data&&(n.revert(),n.getChildren(!0,!0,!1).forEach(function(t){
          return i.splice(i.indexOf(t),1)
          }));
        for(i.map(function(t){
          return{g:t._dur||t._delay||t._sat&&!t._sat.vars.immediateRender?t.globalTime(0):-1/0,t:t}
          }).sort(function(t,e){
          return e.g-t.g||-1/0
          }).forEach(function(e){
          return e.t.revert(t)
          }),s=r.data.length;s--;)
        (n=r.data[s])instanceof eH?"nested"!==n.data&&(n.scrollTrigger&&n.scrollTrigger.revert(),n.kill()):n instanceof e7||!n.revert||n.revert(t);
        r._r.forEach(function(e){
          return e(t,r)
          }),r.isReverted=!0
        }else 
      this.data.forEach(function(t){
        return t.kill&&t.kill()
        });
      if(this.clear(),e)
      for(
      var a=rd.length
      ;a--;)
      rd[a].id===this.id&&rd.splice(a,1)
      },e.revert=function(t){
      this.kill(t||{})
      },t
    }(),rT=function(){
    function t(t){
      this.contexts=[],this.scope=t,T&&T.data.push(this)
      }
    var e=t.prototype;
    return e.add=function(t,e,r){
      W(t)||(t={matches:t});
      var n,i,s,a=new rb(0,r||this.scope),o=a.conditions={};
      for(i in T&&!a.selector&&(a.selector=T.selector),this.contexts.push(a),e=a.add("onMatch",e),a.queries=t,t)
      "all"===i?s=1:(n=k.matchMedia(t[i]))&&(0>rd.indexOf(a)&&rd.push(a),(o[i]=n.matches)&&(s=1),n.addListener?n.addListener(rx):n.addEventListener("change",rx));
      return s&&e(a,function(t){
        return a.add(null,t)
        }),this
      },e.revert=function(t){
      this.kill(t||{})
      },e.kill=function(t){
      this.contexts.forEach(function(e){
        return e.kill(t,!0)
        })
      },t
    }(),rw={registerPlugin:function(){
    for(
    var t=arguments.length,e=Array(t),r=0
    ;r<t;r++)
    e[r]=arguments[r];
    e.forEach(function(t){
      return ex(t)
      })
    },timeline:function(t){
    return new eH(t)
    },getTweensOf:function(t,e){
    return w.getTweensOf(t,e)
    },getProperty:function(t,e,r,n){
    L(t)&&(t=ea(t)[0]);
    var i=tw(t||{}).get,s=r?tz:tR;
    return"native"===r&&(r=""),t?e?s((tm[e]&&tm[e].get||i)(t,e,r,n)):function(e,r,n){
      return s((tm[e]&&tm[e].get||i)(t,e,r,n))
      }:t
    },quickSetter:function(t,e,r){
    if((t=ea(t)).length>1){
      var n=t.map(function(t){
        return rC.quickSetter(t,e,r)
        }),i=n.length;
      return function(t){
        for(
        var e=i
        ;e--;)
        n[e](t)
        }
      }
    t=t[0]||{};
    var s=tm[e],a=tw(t),o=a.harness&&(a.harness.aliases||{})[e]||e,u=s?function(e){
      var n=new s;
      E._pt=0,n.init(t,r?e+r:e,E,0,[t]),n.render(1,n),E._pt&&ru(1,E)
      }:a.set(t,o);
    return s?u:function(e){
      return u(t,o,r?e+r:e,a,1)
      }
    },quickTo:function(t,e,r){
    var n,i=rC.to(t,tF(((n={})[e]="+=0.1",n.paused=!0,n.stagger=0,n),r||{})),s=function(t,r,n){
      return i.resetTo(e,t,r,n)
      };
    return s.tween=i,s
    },isTweening:function(t){
    return w.getTweensOf(t,!0).length>0
    },defaults:function(t){
    return t&&t.ease&&(t.ease=eB(t.ease,D.ease)),tY(D,t||{})
    },config:function(t){
    return tY(P,t||{})
    },registerEffect:function(t){
    var e=t.name,r=t.effect,n=t.plugins,i=t.defaults,s=t.extendTimeline;
    (n||"").split(",").forEach(function(t){
      return t&&!tm[t]&&!ti[t]&&tu(e+" effect requires "+t+" plugin.")
      }),tv[e]=function(t,e,n){
      return r(ea(t),tF(e||{},i),n)
      },s&&(eH.prototype[e]=function(t,r,n){
      return this.add(tv[e](t,W(r)?r:(n=r)&&{},this),n)
      })
    },registerEase:function(t,e){
    eP[t]=eB(e)
    },parseEase:function(t,e){
    return arguments.length?eB(t,e):eP
    },getById:function(t){
    return w.getById(t)
    },exportRoot:function(t,e){
    void 0===t&&(t={});
    var r,n,i=new eH(t);
    for(i.smoothChildTiming=q(t.smoothChildTiming),w.remove(i),i._dp=0,i._time=i._tTime=w._time,r=w._first;r;)
    n=r._next,(e||!(!r._dur&&r instanceof e7&&r.vars.onComplete===r._targets[0]))&&tJ(i,r,r._start-r._delay),r=n;
    return tJ(w,i,0),i
    },context:function(t,e){
    return t?new rb(t,e):T
    },matchMedia:function(t){
    return new rT(t)
    },matchMediaRefresh:function(){
    return rd.forEach(function(t){
      var e,r,n=t.conditions;
      for(r in n)
      n[r]&&(n[r]=!1,e=1);
      e&&t.revert()
      })||rx()
    },addEventListener:function(t,e){
    var r=rg[t]||(rg[t]=[]);
    ~r.indexOf(e)||r.push(e)
    },removeEventListener:function(t,e){
    var r=rg[t],n=r&&r.indexOf(e);
    n>=0&&r.splice(n,1)
    },utils:{wrap:function t(e,r,n){
    var i=r-e;
    return G(e)?ep(e,t(0,e.length),r):ee(n,function(t){
      return(i+(t-e)%i)%i+e
      })
    },wrapYoyo:function t(e,r,n){
    var i=r-e,s=2*i;
    return G(e)?ep(e,t(0,e.length-1),r):ee(n,function(t){
      return t=(s+(t-e)%s)%s||0,e+(t>i?s-t:t)
      })
    },distribute:el,random:eh,snap:ef,normalize:function(t,e,r){
    return eg(t,e,0,1,r)
    },getUnit:en,clamp:function(t,e,r){
    return ee(r,function(r){
      return er(t,e,r)
      })
    },splitColor:ew,toArray:ea,selector:eo,mapRange:eg,pipe:function(){
    for(
    var t=arguments.length,e=Array(t),r=0
    ;r<t;r++)
    e[r]=arguments[r];
    return function(t){
      return e.reduce(function(t,e){
        return e(t)
        },t)
      }
    },unitize:function(t,e){
    return function(r){
      return t(parseFloat(r))+(e||en(r))
      }
    },interpolate:function t(e,r,n,i){
    var s=isNaN(e+r)?0:function(t){
      return(1-t)*e+t*r
      };
    if(!s){
      var a,o,u,l,c,f=L(e),h={};
      if(!0===n&&(i=1)&&(n=null),f)
      e={p:e},r={p:r};
      else 
      if(G(e)&&!G(r)){
        for(o=1,u=[],c=(l=e.length)-2;o<l;o++)
        u.push(t(e[o-1],e[o]));
        l--,s=function(t){
          var e=Math.min(c,~~(t*=l));
          return u[e](t-e)
          },n=r
        }else 
      i||(e=tI(G(e)?[]:{},e));
      if(!u){
        for(a in r)
        eJ.call(h,e,a,"get",r[a]);
        s=function(t){
          return ru(t,h)||(f?e.p:e)
          }
        }
      }
    return ee(n,s)
    },shuffle:eu},install:ta,effects:tv,ticker:eE,updateRoot:eH.updateRoot,plugins:tm,globalTimeline:w,core:{PropTween:rp,globals:tl,Tween:e7,Timeline:eH,Animation:eq,getCache:tw,_removeLinkedListItem:tU,reverting:function(){
    return b
    },context:function(t){
    return t&&T&&(T.data.push(t),t._ctx=T),T
    },suppressOverwrites:function(t){
    return x=t
    }}};
  tM("to,from,fromTo,delayedCall,set,killTweensOf",function(t){
    return rw[t]=e7[t]
    }),eE.add(eH.updateRoot),E=rw.to({},{duration:0});
  var rk=function(t,e){
    for(
    var r=t._pt
    ;r&&r.p!==e&&r.op!==e&&r.fp!==e;)
    r=r._next;
    return r
    },rM=function(t,e){
    var r,n,i,s=t._targets;
    for(r in e)
    for(n=s.length;n--;)
    (i=t._ptLookup[n][r])&&(i=i.d)&&(i._pt&&(i=rk(i,r)),i&&i.modifier&&i.modifier(e[r],t,s[n],r))
    },rO=function(t,e){
    return{name:t,headless:1,rawVars:1,init:function(t,r,n){
      n._onInit=function(t){
        var n,i;
        if(L(r)&&(n={},tM(r,function(t){
          return n[t]=1
          }),r=n),e){
          for(i in n={},r)
          n[i]=e(r[i]);
          r=n
          }
        rM(t,r)
        }
      }}
    },rC=rw.registerPlugin({name:"attr",init:function(t,e,r,n,i){
    var s,a,o;
    for(s in this.tween=r,e)
    o=t.getAttribute(s)||"",(a=this.add(t,"setAttribute",(o||0)+"",e[s],n,i,0,0,s)).op=s,a.b=o,this._props.push(s)
    },render:function(t,e){
    for(
    var r=e._pt
    ;r;)
    b?r.set(r.t,r.p,r.b,r):r.r(t,r.d),r=r._next
    }},{name:"endArray",headless:1,init:function(t,e){
    for(
    var r=e.length
    ;r--;)
    this.add(t,r,t[r]||0,e[r],0,0,0,0,0,1)
    }},rO("roundProps",ec),rO("modifiers"),rO("snap",ef))||rw;
  e7.version=eH.version=rC.version="3.15.0",C=1,H()&&eA(),eP.Power0,eP.Power1,eP.Power2,eP.Power3,eP.Power4,eP.Linear,eP.Quad,eP.Cubic,eP.Quart,eP.Quint,eP.Strong,eP.Elastic,eP.Back,eP.SteppedEase,eP.Bounce,eP.Sine,eP.Expo,eP.Circ;
  var rS,rE,rA,rP,rD,rR,rz,rF={},rI=180/Math.PI,rY=Math.PI/180,rB=Math.atan2,rL=/([A-Z])/g,rN=/(left|right|width|margin|padding|x)/i,rX=/[\s,\(]\S/,rU={autoAlpha:"opacity,visibility",scale:"scaleX,scaleY",alpha:"opacity"},rW=function(t,e){
    return e.set(e.t,e.p,Math.round((e.s+e.c*t)*1e4)/1e4+e.u,e)
    },rq=function(t,e){
    return e.set(e.t,e.p,1===t?e.e:Math.round((e.s+e.c*t)*1e4)/1e4+e.u,e)
    },rH=function(t,e){
    return e.set(e.t,e.p,t?Math.round((e.s+e.c*t)*1e4)/1e4+e.u:e.b,e)
    },rV=function(t,e){
    return e.set(e.t,e.p,1===t?e.e:t?Math.round((e.s+e.c*t)*1e4)/1e4+e.u:e.b,e)
    },rj=function(t,e){
    var r=e.s+e.c*t;
    e.set(e.t,e.p,~~(r+(r<0?-.5:.5))+e.u,e)
    },rG=function(t,e){
    return e.set(e.t,e.p,t?e.e:e.b,e)
    },r$=function(t,e){
    return e.set(e.t,e.p,1!==t?e.b:e.e,e)
    },rQ=function(t,e,r){
    return t.style[e]=r
    },rK=function(t,e,r){
    return t.style.setProperty(e,r)
    },rZ=function(t,e,r){
    return t._gsap[e]=r
    },rJ=function(t,e,r){
    return t._gsap.scaleX=t._gsap.scaleY=r
    },r0=function(t,e,r,n,i){
    var s=t._gsap;
    s.scaleX=s.scaleY=r,s.renderTransform(i,s)
    },r1=function(t,e,r,n,i){
    var s=t._gsap;
    s[e]=r,s.renderTransform(i,s)
    },r2="transform",r5=r2+"Origin",r3=function t(e,r){
    var n=this,i=this.target,s=i.style,a=i._gsap;
    if(e in rF&&s){
      if(this.tfm=this.tfm||{},"transform"===e)
      return rU.transform.split(",").forEach(function(e){
        return t.call(n,e,r)
        });
      if(~(e=rU[e]||e).indexOf(",")?e.split(",").forEach(function(t){
        return n.tfm[t]=nh(i,t)
        }):this.tfm[e]=a.x?a[e]:nh(i,e),e===r5&&(this.tfm.zOrigin=a.zOrigin),this.props.indexOf(r2)>=0)
      return;
      a.svg&&(this.svgo=i.getAttribute("data-svg-origin"),this.props.push(r5,r,"")),e=r2
      }
    (s||r)&&this.props.push(e,r,s[e])
    },r8=function(t){
    t.translate&&(t.removeProperty("translate"),t.removeProperty("scale"),t.removeProperty("rotate"))
    },r6=function(){
    var t,e,r=this.props,n=this.target,i=n.style,s=n._gsap;
    for(t=0;t<r.length;t+=3)
    r[t+1]?2===r[t+1]?n[r[t]](r[t+2]):n[r[t]]=r[t+2]:r[t+2]?i[r[t]]=r[t+2]:i.removeProperty("--"===r[t].substr(0,2)?r[t]:r[t].replace(rL,"-$1").toLowerCase());
    if(this.tfm){
      for(e in this.tfm)
      s[e]=this.tfm[e];
      s.svg&&(s.renderTransform(),n.setAttribute("data-svg-origin",this.svgo||"")),(t=rR())&&t.isStart||i[r2]||(r8(i),s.zOrigin&&i[r5]&&(i[r5]+=" "+s.zOrigin+"px",s.zOrigin=0,s.renderTransform()),s.uncache=1)
      }
    },r4=function(t,e){
    var r={target:t,props:[],revert:r6,save:r3};
    return t._gsap||rC.core.getCache(t),e&&t.style&&t.nodeType&&e.split(",").forEach(function(t){
      return r.save(t)
      }),r
    },r9=function(t,e){
    var r=rS.createElementNS?rS.createElementNS((e||"http://www.w3.org/1999/xhtml").replace(/^https/,"http"),t):rS.createElement(t);
    return r&&r.style?r:rS.createElement(t)
    },r7=function t(e,r,n){
    var i=getComputedStyle(e);
    return i[r]||i.getPropertyValue(r.replace(rL,"-$1").toLowerCase())||i.getPropertyValue(r)||!n&&t(e,ne(r)||r,1)||""
    },nt="O,Moz,ms,Ms,Webkit".split(","),ne=function(t,e,r){
    var n=(e||rP).style,i=5;
    if(t in n&&!r)
    return t;
    for(t=t.charAt(0).toUpperCase()+t.substr(1);i--&&!(nt[i]+t in n););
    return i<0?null:(3===i?"ms":i>=0?nt[i]:"")+t
    },nr=function(){
    "u">typeof window&&window.document&&(rE=(rS=window.document).documentElement,rP=r9("div")||{style:{}},r9("div"),r5=(r2=ne(r2))+"Origin",rP.style.cssText="border-width:0;line-height:0;position:absolute;padding:0",rz=!!ne("perspective"),rR=rC.core.reverting,rA=1)
    },nn=function(t){
    var e,r=t.ownerSVGElement,n=r9("svg",r&&r.getAttribute("xmlns")||"http://www.w3.org/2000/svg"),i=t.cloneNode(!0);
    i.style.display="block",n.appendChild(i),rE.appendChild(n);
    try{
      e=i.getBBox()
      }catch(t){
      }
    return n.removeChild(i),rE.removeChild(n),e
    },ni=function(t,e){
    for(
    var r=e.length
    ;r--;)
    if(t.hasAttribute(e[r]))
    return t.getAttribute(e[r])
    },ns=function(t){
    var e,r;
    try{
      e=t.getBBox()
      }catch(n){
      e=nn(t),r=1
      }
    return e&&(e.width||e.height)||r||(e=nn(t)),!e||e.width||e.x||e.y?e:{x:+ni(t,["x","cx","x1"])||0,y:+ni(t,["y","cy","y1"])||0,width:0,height:0}
    },na=function(t){
    return!!(t.getCTM&&(!t.parentNode||t.ownerSVGElement)&&ns(t))
    },no=function(t,e){
    if(e){
      var r,n=t.style;
      e in rF&&e!==r5&&(e=r2),n.removeProperty?(("ms"===(r=e.substr(0,2))||"webkit"===e.substr(0,6))&&(e="-"+e),n.removeProperty("--"===r?e:e.replace(rL,"-$1").toLowerCase())):n.removeAttribute(e)
      }
    },nu=function(t,e,r,n,i,s){
    var a=new rp(t._pt,e,r,0,1,s?r$:rG);
    return t._pt=a,a.b=n,a.e=i,t._props.push(r),a
    },nl={deg:1,rad:1,turn:1},nc={grid:1,flex:1},nf=function t(e,r,n,i){
    var s,a,o,u,l=parseFloat(n)||0,c=(n+"").trim().substr((l+"").length)||"px",f=rP.style,h=rN.test(r),p="svg"===e.tagName.toLowerCase(),d=(p?"client":"offset")+(h?"Width":"Height"),g="px"===i,_="%"===i;
    if(i===c||!l||nl[i]||nl[c])
    return l;
    if("px"===c||g||(l=t(e,r,n,"px")),u=e.getCTM&&na(e),(_||"%"===c)&&(rF[r]||~r.indexOf("adius")))
    return s=u?e.getBBox()[h?"width":"height"]:e[d],tO(_?l/s*100:l/100*s);
    if(f[h?"width":"height"]=100+(g?c:i),a="rem"!==i&&~r.indexOf("adius")||"em"===i&&e.appendChild&&!p?e:e.parentNode,u&&(a=(e.ownerSVGElement||{}).parentNode),a&&a!==rS&&a.appendChild||(a=rS.body),(o=a._gsap)&&_&&o.width&&h&&o.time===eE.time&&!o.uncache)
    return tO(l/o.width*100);
    if(_&&("height"===r||"width"===r)){
      var m=e.style[r];
      e.style[r]=100+i,s=e[d],m?e.style[r]=m:no(e,r)
      }else
    (_||"%"===c)&&!nc[r7(a,"display")]&&(f.position=r7(e,"position")),a===e&&(f.position="static"),a.appendChild(rP),s=rP[d],a.removeChild(rP),f.position="absolute";
    return h&&_&&((o=tw(a)).time=eE.time,o.width=a[d]),tO(g?s*l/100:s&&l?100/s*l:0)
    },nh=function(t,e,r,n){
    var i;
    return rA||nr(),e in rU&&"transform"!==e&&~(e=rU[e]).indexOf(",")&&(e=e.split(",")[0]),rF[e]&&"transform"!==e?(i=nk(t,n),i="transformOrigin"!==e?i[e]:i.svg?i.origin:nM(r7(t,r5))+" "+i.zOrigin+"px"):(!(i=t.style[e])||"auto"===i||n||~(i+"").indexOf("calc("))&&(i=nm[e]&&nm[e](t,e,r)||r7(t,e)||tk(t,e)||+("opacity"===e)),r&&!~(i+"").trim().indexOf(" ")?nf(t,e,i,r)+r:i
    },np=function(t,e,r,n){
    if(!r||"none"===r){
      var i=ne(e,t,1),s=i&&r7(t,i,1);
      s&&s!==r?(e=i,r=s):"borderColor"===e&&(r=r7(t,"borderTopColor"))
      }
    var a,o,u,l,c,f,h,p,d,g,_,m=new rp(this._pt,t.style,e,0,1,ro),v=0,y=0;
    if(m.b=r,m.e=n,r+="","var(--"===(n+="").substring(0,6)&&(n=r7(t,n.substring(4,n.indexOf(")")))),"auto"===n&&(f=t.style[e],t.style[e]=n,n=r7(t,e)||n,f?t.style[e]=f:no(t,e)),eS(a=[r,n]),r=a[0],n=a[1],u=r.match(J)||[],(n.match(J)||[]).length){
      for(;o=J.exec(n);)
      h=o[0],d=n.substring(v,o.index),c?c=(c+1)%5:("rgba("===d.substr(-5)||"hsla("===d.substr(-5))&&(c=1),h!==(f=u[y++]||"")&&(l=parseFloat(f)||0,_=f.substr((l+"").length),"="===h.charAt(1)&&(h=tS(l,h)+_),p=parseFloat(h),g=h.substr((p+"").length),v=J.lastIndex-g.length,g||(g=g||P.units[e]||_,v===n.length&&(n+=g,m.e+=g)),_!==g&&(l=nf(t,e,f,g)||0),m._pt={_next:m._pt,p:d||1===y?d:",",s:l,c:p-l,m:c&&c<4||"zIndex"===e?Math.round:0});
      m.c=v<n.length?n.substring(v,n.length):""
      }else 
    m.r="display"===e&&"none"===n?r$:rG;
    return te.test(n)&&(m.e=0),this._pt=m,m
    },nd={top:"0%",bottom:"100%",left:"0%",right:"100%",center:"50%"},ng=function(t){
    var e=t.split(" "),r=e[0],n=e[1]||"50%";
    return("top"===r||"bottom"===r||"left"===n||"right"===n)&&(t=r,r=n,n=t),e[0]=nd[r]||r,e[1]=nd[n]||n,e.join(" ")
    },n_=function(t,e){
    if(e.tween&&e.tween._time===e.tween._dur){
      var r,n,i,s=e.t,a=s.style,o=e.u,u=s._gsap;
      if("all"===o||!0===o)
      a.cssText="",n=1;
      else 
      for(i=(o=o.split(",")).length;--i>-1;)
      rF[r=o[i]]&&(n=1,r="transformOrigin"===r?r5:r2),no(s,r);
      n&&(no(s,r2),u&&(u.svg&&s.removeAttribute("transform"),a.scale=a.rotate=a.translate="none",nk(s,1),u.uncache=1,r8(a)))
      }
    },nm={clearProps:function(t,e,r,n,i){
    if("isFromStart"!==i.data){
      var s=t._pt=new rp(t._pt,e,r,0,0,n_);
      return s.u=n,s.pr=-10,s.tween=i,t._props.push(r),1
      }
    }},nv=[1,0,0,1,0,0],ny={},nx=function(t){
    return"matrix(1, 0, 0, 1, 0, 0)"===t||"none"===t||!t
    },nb=function(t){
    var e=r7(t,r2);
    return nx(e)?nv:e.substr(7).match(Z).map(tO)
    },nT=function(t,e){
    var r,n,i,s,a=t._gsap||tw(t),o=t.style,u=nb(t);
    return a.svg&&t.getAttribute("transform")?"1,0,0,1,0,0"===(u=[(i=t.transform.baseVal.consolidate().matrix).a,i.b,i.c,i.d,i.e,i.f]).join(",")?nv:u:(u!==nv||t.offsetParent||t===rE||a.svg||(i=o.display,o.display="block",(r=t.parentNode)&&(t.offsetParent||t.getBoundingClientRect().width)||(s=1,n=t.nextElementSibling,rE.appendChild(t)),u=nb(t),i?o.display=i:no(t,"display"),s&&(n?r.insertBefore(t,n):r?r.appendChild(t):rE.removeChild(t))),e&&u.length>6?[u[0],u[1],u[4],u[5],u[12],u[13]]:u)
    },nw=function(t,e,r,n,i,s){
    var a,o,u,l,c=t._gsap,f=i||nT(t,!0),h=c.xOrigin||0,p=c.yOrigin||0,d=c.xOffset||0,g=c.yOffset||0,_=f[0],m=f[1],v=f[2],y=f[3],x=f[4],b=f[5],T=e.split(" "),w=parseFloat(T[0])||0,k=parseFloat(T[1])||0;
    r?f!==nv&&(o=_*y-m*v)&&(u=y/o*w+-v/o*k+(v*b-y*x)/o,l=-m/o*w+_/o*k-(_*b-m*x)/o,w=u,k=l):(w=(a=ns(t)).x+(~T[0].indexOf("%")?w/100*a.width:w),k=a.y+(~(T[1]||T[0]).indexOf("%")?k/100*a.height:k)),n||!1!==n&&c.smooth?(c.xOffset=d+((x=w-h)*_+(b=k-p)*v)-x,c.yOffset=g+(x*m+b*y)-b):c.xOffset=c.yOffset=0,c.xOrigin=w,c.yOrigin=k,c.smooth=!!n,c.origin=e,c.originIsAbsolute=!!r,t.style[r5]="0px 0px",s&&(nu(s,c,"xOrigin",h,w),nu(s,c,"yOrigin",p,k),nu(s,c,"xOffset",d,c.xOffset),nu(s,c,"yOffset",g,c.yOffset)),t.setAttribute("data-svg-origin",w+" "+k)
    },nk=function(t,e){
    var r=t._gsap||new eW(t);
    if("x"in r&&!e&&!r.uncache)
    return r;
    var n,i,s,a,o,u,l,c,f,h,p,d,g,_,m,v,y,x,b,T,w,k,M,O,C,S,E,A,D,R,z,F,I=t.style,Y=r.scaleX<0,B=getComputedStyle(t),L=r7(t,r5)||"0";
    return n=i=s=u=l=c=f=h=p=0,a=o=1,r.svg=!!(t.getCTM&&na(t)),B.translate&&(("none"!==B.translate||"none"!==B.scale||"none"!==B.rotate)&&(I[r2]=("none"!==B.translate?"translate3d("+(B.translate+" 0 0").split(" ").slice(0,3).join(", ")+") ":"")+("none"!==B.rotate?"rotate("+B.rotate+") ":"")+("none"!==B.scale?"scale("+B.scale.split(" ").join(",")+") ":"")+("none"!==B[r2]?B[r2]:"")),I.scale=I.rotate=I.translate="none"),_=nT(t,r.svg),r.svg&&(r.uncache?(C=t.getBBox(),L=r.xOrigin-C.x+"px "+(r.yOrigin-C.y)+"px",O=""):O=!e&&t.getAttribute("data-svg-origin"),nw(t,O||L,!!O||r.originIsAbsolute,!1!==r.smooth,_)),d=r.xOrigin||0,g=r.yOrigin||0,_!==nv&&(x=_[0],b=_[1],T=_[2],w=_[3],n=k=_[4],i=M=_[5],6===_.length?(a=Math.sqrt(x*x+b*b),o=Math.sqrt(w*w+T*T),u=x||b?rB(b,x)*rI:0,(f=T||w?rB(T,w)*rI+u:0)&&(o*=Math.abs(Math.cos(f*rY))),r.svg&&(n-=d-(d*x+g*T),i-=g-(d*b+g*w))):(F=_[6],R=_[7],E=_[8],A=_[9],D=_[10],z=_[11],n=_[12],i=_[13],s=_[14],l=(m=rB(F,D))*rI,m&&(O=k*(v=Math.cos(-m))+E*(y=Math.sin(-m)),C=M*v+A*y,S=F*v+D*y,E=-(k*y)+E*v,A=-(M*y)+A*v,D=-(F*y)+D*v,z=-(R*y)+z*v,k=O,M=C,F=S),c=(m=rB(-T,D))*rI,m&&(O=x*(v=Math.cos(-m))-E*(y=Math.sin(-m)),C=b*v-A*y,S=T*v-D*y,z=w*y+z*v,x=O,b=C,T=S),u=(m=rB(b,x))*rI,m&&(O=x*(v=Math.cos(m))+b*(y=Math.sin(m)),C=k*v+M*y,b=b*v-x*y,M=M*v-k*y,x=O,k=C),l&&Math.abs(l)+Math.abs(u)>359.9&&(l=u=0,c=180-c),a=tO(Math.sqrt(x*x+b*b+T*T)),o=tO(Math.sqrt(M*M+F*F)),f=Math.abs(m=rB(k,M))>2e-4?m*rI:0,p=z?1/(z<0?-z:z):0),r.svg&&(O=t.getAttribute("transform"),r.forceCSS=t.setAttribute("transform","")||!nx(r7(t,r2)),O&&t.setAttribute("transform",O))),Math.abs(f)>90&&270>Math.abs(f)&&(Y?(a*=-1,f+=u<=0?180:-180,u+=u<=0?180:-180):(o*=-1,f+=f<=0?180:-180)),e=e||r.uncache,r.x=n-((r.xPercent=n&&(!e&&r.xPercent||(Math.round(t.offsetWidth/2)===Math.round(-n)?-50:0)))?t.offsetWidth*r.xPercent/100:0)+"px",r.y=i-((r.yPercent=i&&(!e&&r.yPercent||(Math.round(t.offsetHeight/2)===Math.round(-i)?-50:0)))?t.offsetHeight*r.yPercent/100:0)+"px",r.z=s+"px",r.scaleX=tO(a),r.scaleY=tO(o),r.rotation=tO(u)+"deg",r.rotationX=tO(l)+"deg",r.rotationY=tO(c)+"deg",r.skewX=f+"deg",r.skewY=h+"deg",r.transformPerspective=p+"px",(r.zOrigin=parseFloat(L.split(" ")[2])||!e&&r.zOrigin||0)&&(I[r5]=nM(L)),r.xOffset=r.yOffset=0,r.force3D=P.force3D,r.renderTransform=r.svg?nA:rz?nE:nC,r.uncache=0,r
    },nM=function(t){
    return(t=t.split(" "))[0]+" "+t[1]
    },nO=function(t,e,r){
    var n=en(e);
    return tO(parseFloat(e)+parseFloat(nf(t,"x",r+"px",n)))+n
    },nC=function(t,e){
    e.z="0px",e.rotationY=e.rotationX="0deg",e.force3D=0,nE(t,e)
    },nS="0deg",nE=function(t,e){
    var r=e||this,n=r.xPercent,i=r.yPercent,s=r.x,a=r.y,o=r.z,u=r.rotation,l=r.rotationY,c=r.rotationX,f=r.skewX,h=r.skewY,p=r.scaleX,d=r.scaleY,g=r.transformPerspective,_=r.force3D,m=r.target,v=r.zOrigin,y="",x="auto"===_&&t&&1!==t||!0===_;
    if(v&&(c!==nS||l!==nS)){
      var b,T=parseFloat(l)*rY,w=Math.sin(T),k=Math.cos(T);
      s=nO(m,s,-(w*(b=Math.cos(T=parseFloat(c)*rY))*v)),a=nO(m,a,-(-Math.sin(T)*v)),o=nO(m,o,-(k*b*v)+v)
      }
    "0px"!==g&&(y+="perspective("+g+") "),(n||i)&&(y+="translate("+n+"%, "+i+"%) "),(x||"0px"!==s||"0px"!==a||"0px"!==o)&&(y+="0px"!==o||x?"translate3d("+s+", "+a+", "+o+") ":"translate("+s+", "+a+") "),u!==nS&&(y+="rotate("+u+") "),l!==nS&&(y+="rotateY("+l+") "),c!==nS&&(y+="rotateX("+c+") "),(f!==nS||h!==nS)&&(y+="skew("+f+", "+h+") "),(1!==p||1!==d)&&(y+="scale("+p+", "+d+") "),m.style[r2]=y||"translate(0, 0)"
    },nA=function(t,e){
    var r,n,i,s,a,o=e||this,u=o.xPercent,l=o.yPercent,c=o.x,f=o.y,h=o.rotation,p=o.skewX,d=o.skewY,g=o.scaleX,_=o.scaleY,m=o.target,v=o.xOrigin,y=o.yOrigin,x=o.xOffset,b=o.yOffset,T=o.forceCSS,w=parseFloat(c),k=parseFloat(f);
    h=parseFloat(h),p=parseFloat(p),(d=parseFloat(d))&&(p+=d=parseFloat(d),h+=d),h||p?(h*=rY,p*=rY,r=Math.cos(h)*g,n=Math.sin(h)*g,i=-(Math.sin(h-p)*_),s=Math.cos(h-p)*_,p&&(d*=rY,i*=a=Math.sqrt(1+(a=Math.tan(p-d))*a),s*=a,d&&(r*=a=Math.sqrt(1+(a=Math.tan(d))*a),n*=a)),r=tO(r),n=tO(n),i=tO(i),s=tO(s)):(r=g,s=_,n=i=0),(w&&!~(c+"").indexOf("px")||k&&!~(f+"").indexOf("px"))&&(w=nf(m,"x",c,"px"),k=nf(m,"y",f,"px")),(v||y||x||b)&&(w=tO(w+v-(v*r+y*i)+x),k=tO(k+y-(v*n+y*s)+b)),(u||l)&&(w=tO(w+u/100*(a=m.getBBox()).width),k=tO(k+l/100*a.height)),a="matrix("+r+","+n+","+i+","+s+","+w+","+k+")",m.setAttribute("transform",a),T&&(m.style[r2]=a)
    },nP=function(t,e,r,n,i){
    var s,a,o=L(i),u=parseFloat(i)*(o&&~i.indexOf("rad")?rI:1)-n,l=n+u+"deg";
    return o&&("short"===(s=i.split("_")[1])&&(u%=360)!=u%180&&(u+=u<0?360:-360),"cw"===s&&u<0?u=(u+36e9)%360-360*~~(u/360):"ccw"===s&&u>0&&(u=(u-36e9)%360-360*~~(u/360))),t._pt=a=new rp(t._pt,e,r,n,u,rq),a.e=l,a.u="deg",t._props.push(r),a
    },nD=function(t,e){
    for(
    var r
     in e)
    t[r]=e[r];
    return t
    },nR=function(t,e,r){
    var n,i,s,a,o,u,l,c=nD({},r._gsap),f=r.style;
    for(i in c.svg?(s=r.getAttribute("transform"),r.setAttribute("transform",""),f[r2]=e,n=nk(r,1),no(r,r2),r.setAttribute("transform",s)):(s=getComputedStyle(r)[r2],f[r2]=e,n=nk(r,1),f[r2]=s),rF)
    (s=c[i])!==(a=n[i])&&0>"perspective,force3D,transformOrigin,svgOrigin".indexOf(i)&&(o=en(s)!==(l=en(a))?nf(r,i,s,l):parseFloat(s),u=parseFloat(a),t._pt=new rp(t._pt,n,i,o,u-o,rW),t._pt.u=l||0,t._props.push(i));
    nD(n,c)
    };
  tM("padding,margin,Width,Radius",function(t,e){
    var r="Right",n="Bottom",i="Left",s=(e<3?["Top",r,n,i]:["Top"+i,"Top"+r,n+r,n+i]).map(function(r){
      return e<2?t+r:"border"+r+t
      });
    nm[e>1?"border"+t:t]=function(t,e,r,n,i){
      var a,o;
      if(arguments.length<4)
      return 5===(o=(a=s.map(function(e){
        return nh(t,e,r)
        })).join(" ")).split(a[0]).length?a[0]:o;
      a=(n+"").split(" "),o={},s.forEach(function(t,e){
        return o[t]=a[e]=a[e]||a[(e-1)/2|0]
        }),t.init(e,o,i)
      }
    });
  var nz={name:"css",register:nr,targetTest:function(t){
    return t.style&&t.nodeType
    },init:function(t,e,r,n,i){
    var s,a,o,u,l,c,f,h,p,d,g,_,m,v,y,x,b,T=this._props,w=t.style,k=r.vars.startAt;
    for(f in rA||nr(),this.styles=this.styles||r4(t),x=this.styles.props,this.tween=r,e)
    if("autoRound"!==f&&(a=e[f],!(tm[f]&&e1(f,e,r,n,t,i)))){
      if(l=typeof a,c=nm[f],"function"===l&&(l=typeof(a=a.call(r,n,t,i))),"string"===l&&~a.indexOf("random(")&&(a=ed(a)),c)
      c(this,t,f,a,r)&&(y=1);
      else 
      if("--"===f.substr(0,2))
      s=(getComputedStyle(t).getPropertyValue(f)+"").trim(),a+="",eO.lastIndex=0,!eO.test(s)&&(h=en(s),(p=en(a))?h!==p&&(s=nf(t,f,s,p)+p):h&&(a+=h)),this.add(w,"setProperty",s,a,n,i,0,0,f),T.push(f),x.push(f,0,w[f]);
      else 
      if("undefined"!==l){
        if(k&&f in k?(L(s="function"==typeof k[f]?k[f].call(r,n,t,i):k[f])&&~s.indexOf("random(")&&(s=ed(s)),en(s+"")||"auto"===s||(s+=P.units[f]||en(nh(t,f))||""),"="===(s+"").charAt(1)&&(s=nh(t,f))):s=nh(t,f),u=parseFloat(s),(d="string"===l&&"="===a.charAt(1)&&a.substr(0,2))&&(a=a.substr(2)),o=parseFloat(a),f in rU&&("autoAlpha"===f&&(1===u&&"hidden"===nh(t,"visibility")&&o&&(u=0),x.push("visibility",0,w.visibility),nu(this,w,"visibility",u?"inherit":"hidden",o?"inherit":"hidden",!o)),"scale"!==f&&"transform"!==f&&~(f=rU[f]).indexOf(",")&&(f=f.split(",")[0])),g=f in rF){
          if(this.styles.save(f),b=a,"string"===l&&"var(--"===a.substring(0,6)){
            if("calc("===(a=r7(t,a.substring(4,a.indexOf(")")))).substring(0,5)){
              var M=t.style.perspective;
              t.style.perspective=a,a=r7(t,"perspective"),M?t.style.perspective=M:no(t,"perspective")
              }
            o=parseFloat(a)
            }
          if(_||((m=t._gsap).renderTransform&&!e.parseTransform||nk(t,e.parseTransform),v=!1!==e.smoothOrigin&&m.smooth,(_=this._pt=new rp(this._pt,w,r2,0,1,m.renderTransform,m,0,-1)).dep=1),"scale"===f)
          this._pt=new rp(this._pt,m,"scaleY",m.scaleY,(d?tS(m.scaleY,d+o):o)-m.scaleY||0,rW),this._pt.u=0,T.push("scaleY",f),f+="X";
          else 
          if("transformOrigin"===f){
            x.push(r5,0,w[r5]),a=ng(a),m.svg?nw(t,a,0,v,0,this):((p=parseFloat(a.split(" ")[2])||0)!==m.zOrigin&&nu(this,m,"zOrigin",m.zOrigin,p),nu(this,w,f,nM(s),nM(a)));
            continue
            }else 
          if("svgOrigin"===f){
            nw(t,a,1,v,0,this);
            continue
            }else 
          if(f in ny){
            nP(this,m,f,u,d?tS(u,d+a):a);
            continue
            }else 
          if("smoothOrigin"===f){
            nu(this,m,"smooth",m.smooth,a);
            continue
            }else 
          if("force3D"===f){
            m[f]=a;
            continue
            }else 
          if("transform"===f){
            nR(this,a,t);
            continue
            }
          }else 
        f in w||(f=ne(f)||f);
        if(g||(o||0===o)&&(u||0===u)&&!rX.test(a)&&f in w)
        h=(s+"").substr((u+"").length),o||(o=0),p=en(a)||(f in P.units?P.units[f]:h),h!==p&&(u=nf(t,f,s,p)),this._pt=new rp(this._pt,g?m:w,f,u,(d?tS(u,d+o):o)-u,!g&&("px"===p||"zIndex"===f)&&!1!==e.autoRound?rj:rW),this._pt.u=p||0,g&&b!==a?(this._pt.b=s,this._pt.e=b,this._pt.r=rV):h!==p&&"%"!==p&&(this._pt.b=s,this._pt.r=rH);
        else 
        if(f in w)
        np.call(this,t,f,s,d?d+a:a);
        else 
        if(f in t)
        this.add(t,f,s||t[f],d?d+a:a,n,i);
        else 
        if("parseTransform"!==f){
          to(f,a);
          continue
          }
        g||(f in w?x.push(f,0,w[f]):"function"==typeof t[f]?x.push(f,2,t[f]()):x.push(f,1,s||t[f])),T.push(f)
        }
      }
    y&&rh(this)
    },render:function(t,e){
    if(e.tween._time||!rR())
    for(
    var r=e._pt
    ;r;)
    r.r(t,r.d),r=r._next;
    else 
    e.styles.revert()
    },get:nh,aliases:rU,getSetter:function(t,e,r){
    var n=rU[e];
    return n&&0>n.indexOf(",")&&(e=n),e in rF&&e!==r5&&(t._gsap.x||nh(t,"x"))?r&&rD===r?"scale"===e?rJ:rZ:(rD=r||{},"scale"===e?r0:r1):t.style&&!U(t.style[e])?rQ:~e.indexOf("-")?rK:ri(t,e)
    },core:{_removeProperty:no,_getMatrix:nT}};
  rC.utils.checkPrefix=ne,rC.core.getStyleSaver=r4,i=tM("x,y,z,scale,scaleX,scaleY,xPercent,yPercent,"+(n="rotation,rotationX,rotationY,skewX,skewY")+",transform,transformOrigin,svgOrigin,force3D,smoothOrigin,transformPerspective",function(t){
    rF[t]=1
    }),tM(n,function(t){
    P.units[t]="deg",ny[t]=1
    }),rU[i[13]]="x,y,z,scale,scaleX,scaleY,xPercent,yPercent,"+n,tM("0:translateX,1:translateY,2:translateZ,8:rotate,8:rotationZ,8:rotateZ,9:rotateX,10:rotateY",function(t){
    var e=t.split(":");
    rU[e[1]]=i[e[0]]
    }),tM("x,y,z,top,right,bottom,left,width,height,fontSize,padding,margin,perspective",function(t){
    P.units[t]="px"
    }),rC.registerPlugin(nz);
  var nF=rC.registerPlugin(nz)||rC;
  nF.core.Tween,t.s(["default",0,nF],89970)
  },21853,t=>{
  "use strict";
  let e;
  var r=t.i(71645),n=t.i(8155);
  let i=t=>{
    let e=(0,n.createStore)(t),i=t=>(function(t,e=t=>t){
      let n=r.default.useSyncExternalStore(t.subscribe,r.default.useCallback(()=>e(t.getState()),[t,e]),r.default.useCallback(()=>e(t.getInitialState()),[t,e]));
      return r.default.useDebugValue(n),n
      })(e,t);
    return Object.assign(i,e),i
    },s="artcraft-tuner";
  function a(t){
    try{
      localStorage.setItem(s,JSON.stringify(t))
      }catch{
      }
    }
  let o=(e=t=>({groups:{},values:function(){
    try{
      let t=JSON.parse(localStorage.getItem(s)??"{}");
      return"object"==typeof t&&null!==t?t:{}
      }catch{
      return{}
      }
    }(),version:0,registerGroup:(e,r,n)=>t(t=>t.groups[e]?t:{groups:{...t.groups,[e]:{id:e,title:r,order:Object.keys(t.groups).length,defs:n}}}),setValue:(e,r,n)=>t(t=>{
    let i={...t.values,[`${e}.${r}`]:n};
    return a(i),{values:i,version:t.version+1}
    }),resetAll:()=>t(t=>(a({}),{values:{},version:t.version+1})),resetGroup:e=>t(t=>{
    let r={};
    for(
    let[n,i]
    of Object.entries(t.values))
    n.startsWith(e+".")||(r[n]=i);
    return a(r),{values:r,version:t.version+1}
    })}))?i(e):i,u=[];
  t.s(["defineTunables",0,function(t,e,r){
    return o.getState().registerGroup(t,e,r),{id:t,defs:r,read:()=>{
      let{values:e}=o.getState(),n={};
      for(
      let i
       in r){
        let s=e[`${t}.${String(i)}`];
        n[i]=s??r[i].default
        }
      return n
      }}
    },"getTunerActions",0,function(){
    return u
    },"registerTunerAction",0,function(t,e){
    let r=u.find(e=>e.label===t);
    r?r.run=e:u.push({label:t,run:e})
    },"tunerSnapshot",0,function(){
    let{groups:t,values:e}=o.getState(),r={};
    for(
    let n
     of Object.values(t))
    for(
    let t
     in r[n.id]={},n.defs)
    r[n.id][t]=e[`${n.id}.${t}`]??n.defs[t].default;
    return r
    },"useTunerStore",0,o],21853)
  },91672,t=>{
  "use strict";
  var e=t.i(21853);
  let r=(0,e.defineTunables)("intro","Intro",{wordAt:{label:"Word at s",min:0,max:2,step:.05,default:.35,info:"When the letters start sliding out from behind the logo (the logo itself fades in at 0)."},wordDur:{label:"Word dur s",min:.2,max:2,step:.05,default:.85,info:"How long the whole word-formation takes — the logo's glide to its slot spans this window."},instrAt:{label:"Instrument s",min:0,max:3,step:.05,default:.7,info:"When the instrument assembles: the ruler's tick cascade begins and the navbar contents stagger in."},copyAt:{label:"Copy at s",min:0,max:3,step:.05,default:1.05,info:"When the central copy stack (headline, subline, CTAs, proof) starts its reveal."},cardsAt:{label:"Cards at s",min:0,max:3,step:.05,default:1,info:"When the galaxy cards start rolling out from the center along their arms."},ffScale:{label:"Skip speed ×",min:1,max:10,step:.5,default:4,info:"Timeline acceleration when the visitor scrolls, clicks, or presses a key during the intro — fast-forward, never a jump cut."},returnScale:{label:"Return speed ×",min:1,max:6,step:.5,default:1,info:"Timeline acceleration for repeat visitors (localStorage flag) — they get the whole intro, much shorter."}}),n={t:0,scale:1,done:!1},i=new Set,s=new Set;
  (0,e.registerTunerAction)("Intro ↻",function(){
    window.matchMedia("(prefers-reduced-motion: reduce)").matches||(n.t=0,n.scale=1,n.done=!1,s.forEach(t=>t()))
    }),t.s(["INTRO_SEEN_KEY",0,"artcraft-intro-seen","introClock",0,n,"introFastForward",0,function(){
    let t=r.read().ffScale;
    n.done||n.scale>=t||(n.scale=t,i.forEach(t=>t()))
    },"introTuner",0,r,"onIntroFast",0,function(t){
    return i.add(t),()=>{
      i.delete(t)
      }
    },"onIntroReplay",0,function(t){
    return s.add(t),()=>{
      s.delete(t)
      }
    }])
  },83495,t=>{
  "use strict";
  var e,r,n,i,s,a,o,u,l,c,f,h,p,d=function(){
    return e||"u">typeof window&&(e=window.gsap)&&e.registerPlugin&&e
    },g=1,_=[],m=[],v=[],y=Date.now,x=function(t,e){
    return e
    },b=function(){
    var t=l.core,e=t.bridge||{},r=t._scrollers,n=t._proxies;
    r.push.apply(r,m),n.push.apply(n,v),m=r,v=n,x=function(t,r){
      return e[t](r)
      }
    },T=function(t,e){
    return~v.indexOf(t)&&v[v.indexOf(t)+1][e]
    },w=function(t){
    return!!~c.indexOf(t)
    },k=function(t,e,r,n,i){
    return t.addEventListener(e,r,{passive:!1!==n,capture:!!i})
    },M=function(t,e,r,n){
    return t.removeEventListener(e,r,!!n)
    },O="scrollLeft",C="scrollTop",S=function(){
    return f&&f.isPressed||m.cache++
    },E=function(t,e){
    var r=function r(i){
      if(i||0===i){
        g&&(n.history.scrollRestoration="manual");
        var s=f&&f.isPressed;
        t(i=r.v=Math.round(i)||(f&&f.iOS?1:0)),r.cacheID=m.cache,s&&x("ss",i)
        }else
      (e||m.cache!==r.cacheID||x("ref"))&&(r.cacheID=m.cache,r.v=t());
      return r.v+r.offset
      };
    return r.offset=0,t&&r
    },A={s:O,p:"left",p2:"Left",os:"right",os2:"Right",d:"width",d2:"Width",a:"x",sc:E(function(t){
    return arguments.length?n.scrollTo(t,P.sc()):n.pageXOffset||i[O]||s[O]||a[O]||0
    })},P={s:C,p:"top",p2:"Top",os:"bottom",os2:"Bottom",d:"height",d2:"Height",a:"y",op:A,sc:E(function(t){
    return arguments.length?n.scrollTo(A.sc(),t):n.pageYOffset||i[C]||s[C]||a[C]||0
    })},D=function(t,r){
    return(r&&r._ctx&&r._ctx.selector||e.utils.toArray)(t)[0]||("string"==typeof t&&!1!==e.config().nullTargetWarn?console.warn("Element not found:",t):null)
    },R=function(t,e){
    for(
    var r=e.length
    ;r--;)
    if(e[r]===t||e[r].contains(t))
    return!0;
    return!1
    },z=function(t,r){
    var n=r.s,a=r.sc;
    w(t)&&(t=i.scrollingElement||s);
    var o=m.indexOf(t),u=a===P.sc?1:2;
    ~o||(o=m.push(t)-1),m[o+u]||k(t,"scroll",S);
    var l=m[o+u],c=l||(m[o+u]=E(T(t,n),!0)||(w(t)?a:E(function(e){
      return arguments.length?t[n]=e:t[n]
      })));
    return c.target=t,l||(c.smooth="smooth"===e.getProperty(t,"scrollBehavior")),c
    },F=function(t,e,r){
    var n=t,i=t,s=y(),a=s,o=e||50,u=Math.max(500,3*o),l=function(t,e){
      var u=y();
      e||u-s>o?(i=n,n=t,a=s,s=u):r?n+=t:n=i+(t-i)/(u-a)*(s-a)
      };
    return{update:l,reset:function(){
      i=n=r?0:n,a=s=0
      },getVelocity:function(t){
      var e=a,o=i,c=y();
      return(t||0===t)&&t!==n&&l(t),s===a||c-a>u?0:(n+(r?o:-o))/((r?c:s)-e)*1e3
      }}
    },I=function(t,e){
    return e&&!t._gsapAllow&&!1!==t.cancelable&&t.preventDefault(),t.changedTouches?t.changedTouches[0]:t
    },Y=function(t){
    var e=Math.max.apply(Math,t),r=Math.min.apply(Math,t);
    return Math.abs(e)>=Math.abs(r)?e:r
    },B=function(){
    (l=e.core.globals().ScrollTrigger)&&l.core&&b()
    },L=function(t){
    return e=t||d(),!r&&e&&"u">typeof document&&document.body&&(n=window,s=(i=document).documentElement,a=i.body,c=[n,i,s,a],e.utils.clamp,p=e.core.context||function(){
      },u="onpointerenter"in a?"pointer":"mouse",o=N.isTouch=n.matchMedia&&n.matchMedia("(hover: none), (pointer: coarse)").matches?1:2*("ontouchstart"in n||navigator.maxTouchPoints>0||navigator.msMaxTouchPoints>0),h=N.eventTypes=("ontouchstart"in s?"touchstart,touchmove,touchcancel,touchend":!("onpointerdown"in s)?"mousedown,mousemove,mouseup,mouseup":"pointerdown,pointermove,pointercancel,pointerup").split(","),setTimeout(function(){
      return g=0
      },500),r=1),l||B(),r
    };
  A.op=P,m.cache=0;
  var N=function(){
    var t;
    function c(t){
      this.init(t)
      }
    return c.prototype.init=function(t){
      r||L(e)||console.warn("Please gsap.registerPlugin(Observer)"),l||B();
      var c=t.tolerance,d=t.dragMinimum,g=t.type,m=t.target,v=t.lineHeight,x=t.debounce,b=t.preventDefault,T=t.onStop,O=t.onStopDelay,C=t.ignore,E=t.wheelSpeed,N=t.event,X=t.onDragStart,U=t.onDragEnd,W=t.onDrag,q=t.onPress,H=t.onRelease,V=t.onRight,j=t.onLeft,G=t.onUp,$=t.onDown,Q=t.onChangeX,K=t.onChangeY,Z=t.onChange,J=t.onToggleX,tt=t.onToggleY,te=t.onHover,tr=t.onHoverEnd,tn=t.onMove,ti=t.ignoreCheck,ts=t.isNormalizer,ta=t.onGestureStart,to=t.onGestureEnd,tu=t.onWheel,tl=t.onEnable,tc=t.onDisable,tf=t.onClick,th=t.scrollSpeed,tp=t.capture,td=t.allowClicks,tg=t.lockAxis,t_=t.onLockAxis;
      this.target=m=D(m)||s,this.vars=t,C&&(C=e.utils.toArray(C)),c=c||1e-9,d=d||0,E=E||1,th=th||1,g=g||"wheel,touch,pointer",x=!1!==x,v||(v=parseFloat(n.getComputedStyle(a).lineHeight)||22);
      var tm,tv,ty,tx,tb,tT,tw,tk=this,tM=0,tO=0,tC=t.passive||!b&&!1!==t.passive,tS=z(m,A),tE=z(m,P),tA=tS(),tP=tE(),tD=~g.indexOf("touch")&&!~g.indexOf("pointer")&&"pointerdown"===h[0],tR=w(m),tz=m.ownerDocument||i,tF=[0,0,0],tI=[0,0,0],tY=0,tB=function(){
        return tY=y()
        },tL=function(t,e){
        return(tk.event=t)&&C&&R(t.target,C)||e&&tD&&"touch"!==t.pointerType||ti&&ti(t,e)
        },tN=function(){
        var t=tk.deltaX=Y(tF),e=tk.deltaY=Y(tI),r=Math.abs(t)>=c,n=Math.abs(e)>=c;
        Z&&(r||n)&&Z(tk,t,e,tF,tI),r&&(V&&tk.deltaX>0&&V(tk),j&&tk.deltaX<0&&j(tk),Q&&Q(tk),J&&tk.deltaX<0!=tM<0&&J(tk),tM=tk.deltaX,tF[0]=tF[1]=tF[2]=0),n&&($&&tk.deltaY>0&&$(tk),G&&tk.deltaY<0&&G(tk),K&&K(tk),tt&&tk.deltaY<0!=tO<0&&tt(tk),tO=tk.deltaY,tI[0]=tI[1]=tI[2]=0),(tx||ty)&&(tn&&tn(tk),ty&&(X&&1===ty&&X(tk),W&&W(tk),ty=0),tx=!1),tT&&(tT=!1,1)&&t_&&t_(tk),tb&&(tu(tk),tb=!1),tm=0
        },tX=function(t,e,r){
        tF[r]+=t,tI[r]+=e,tk._vx.update(t),tk._vy.update(e),x?tm||(tm=requestAnimationFrame(tN)):tN()
        },tU=function(t,e){
        tg&&!tw&&(tk.axis=tw=Math.abs(t)>Math.abs(e)?"x":"y",tT=!0),"y"!==tw&&(tF[2]+=t,tk._vx.update(t,!0)),"x"!==tw&&(tI[2]+=e,tk._vy.update(e,!0)),x?tm||(tm=requestAnimationFrame(tN)):tN()
        },tW=function(t){
        if(!tL(t,1)){
          var e=(t=I(t,b)).clientX,r=t.clientY,n=e-tk.x,i=r-tk.y,s=tk.isDragging;
          tk.x=e,tk.y=r,(s||(n||i)&&(Math.abs(tk.startX-e)>=d||Math.abs(tk.startY-r)>=d))&&(ty||(ty=s?2:1),s||(tk.isDragging=!0),tU(n,i))
          }
        },tq=tk.onPress=function(t){
        tL(t,1)||t&&t.button||(tk.axis=tw=null,tv.pause(),tk.isPressed=!0,t=I(t),tM=tO=0,tk.startX=tk.x=t.clientX,tk.startY=tk.y=t.clientY,tk._vx.reset(),tk._vy.reset(),k(ts?m:tz,h[1],tW,tC,!0),tk.deltaX=tk.deltaY=0,q&&q(tk))
        },tH=tk.onRelease=function(t){
        if(!tL(t,1)){
          M(ts?m:tz,h[1],tW,!0);
          var r=!isNaN(tk.y-tk.startY),i=tk.isDragging,s=i&&(Math.abs(tk.x-tk.startX)>3||Math.abs(tk.y-tk.startY)>3),a=I(t);
          !s&&r&&(tk._vx.reset(),tk._vy.reset(),b&&td&&e.delayedCall(.08,function(){
            if(y()-tY>300&&!t.defaultPrevented){
              if(t.target.click)
              t.target.click();
              else 
              if(tz.createEvent){
                var e=tz.createEvent("MouseEvents");
                e.initMouseEvent("click",!0,!0,n,1,a.screenX,a.screenY,a.clientX,a.clientY,!1,!1,!1,!1,0,null),t.target.dispatchEvent(e)
                }
              }
            })),tk.isDragging=tk.isGesturing=tk.isPressed=!1,T&&i&&!ts&&tv.restart(!0),ty&&tN(),U&&i&&U(tk),H&&H(tk,s)
          }
        },tV=function(t){
        return t.touches&&t.touches.length>1&&(tk.isGesturing=!0)&&ta(t,tk.isDragging)
        },tj=function(){
        return tk.isGesturing=!1,to(tk)
        },tG=function(t){
        if(!tL(t)){
          var e=tS(),r=tE();
          tX((e-tA)*th,(r-tP)*th,1),tA=e,tP=r,T&&tv.restart(!0)
          }
        },t$=function(t){
        if(!tL(t)){
          t=I(t,b),tu&&(tb=!0);
          var e=(1===t.deltaMode?v:2===t.deltaMode?n.innerHeight:1)*E;
          tX(t.deltaX*e,t.deltaY*e,0),T&&!ts&&tv.restart(!0)
          }
        },tQ=function(t){
        if(!tL(t)){
          var e=t.clientX,r=t.clientY,n=e-tk.x,i=r-tk.y;
          tk.x=e,tk.y=r,tx=!0,T&&tv.restart(!0),(n||i)&&tU(n,i)
          }
        },tK=function(t){
        tk.event=t,te(tk)
        },tZ=function(t){
        tk.event=t,tr(tk)
        },tJ=function(t){
        return tL(t)||I(t,b)&&tf(tk)
        };
      tv=tk._dc=e.delayedCall(O||.25,function(){
        tk._vx.reset(),tk._vy.reset(),tv.pause(),T&&T(tk)
        }).pause(),tk.deltaX=tk.deltaY=0,tk._vx=F(0,50,!0),tk._vy=F(0,50,!0),tk.scrollX=tS,tk.scrollY=tE,tk.isDragging=tk.isGesturing=tk.isPressed=!1,p(this),tk.enable=function(t){
        return!tk.isEnabled&&(k(tR?tz:m,"scroll",S),g.indexOf("scroll")>=0&&k(tR?tz:m,"scroll",tG,tC,tp),g.indexOf("wheel")>=0&&k(m,"wheel",t$,tC,tp),(g.indexOf("touch")>=0&&o||g.indexOf("pointer")>=0)&&(k(m,h[0],tq,tC,tp),k(tz,h[2],tH),k(tz,h[3],tH),td&&k(m,"click",tB,!0,!0),tf&&k(m,"click",tJ),ta&&k(tz,"gesturestart",tV),to&&k(tz,"gestureend",tj),te&&k(m,u+"enter",tK),tr&&k(m,u+"leave",tZ),tn&&k(m,u+"move",tQ)),tk.isEnabled=!0,tk.isDragging=tk.isGesturing=tk.isPressed=tx=ty=!1,tk._vx.reset(),tk._vy.reset(),tA=tS(),tP=tE(),t&&t.type&&tq(t),tl&&tl(tk)),tk
        },tk.disable=function(){
        tk.isEnabled&&(_.filter(function(t){
          return t!==tk&&w(t.target)
          }).length||M(tR?tz:m,"scroll",S),tk.isPressed&&(tk._vx.reset(),tk._vy.reset(),M(ts?m:tz,h[1],tW,!0)),M(tR?tz:m,"scroll",tG,tp),M(m,"wheel",t$,tp),M(m,h[0],tq,tp),M(tz,h[2],tH),M(tz,h[3],tH),M(m,"click",tB,!0),M(m,"click",tJ),M(tz,"gesturestart",tV),M(tz,"gestureend",tj),M(m,u+"enter",tK),M(m,u+"leave",tZ),M(m,u+"move",tQ),tk.isEnabled=tk.isPressed=tk.isDragging=!1,tc&&tc(tk))
        },tk.kill=tk.revert=function(){
        tk.disable();
        var t=_.indexOf(tk);
        t>=0&&_.splice(t,1),f===tk&&(f=0)
        },_.push(tk),ts&&w(m)&&(f=tk),tk.enable(N)
      },t=[{key:"velocityX",get:function(){
      return this._vx.getVelocity()
      }},{key:"velocityY",get:function(){
      return this._vy.getVelocity()
      }}],function(t,e){
      for(
      var r=0
      ;r<e.length;r++){
        var n=e[r];
        n.enumerable=n.enumerable||!1,n.configurable=!0,"value"in n&&(n.writable=!0),Object.defineProperty(t,n.key,n)
        }
      }(c.prototype,t),c
    }();
  N.version="3.15.0",N.create=function(t){
    return new N(t)
    },N.register=L,N.getAll=function(){
    return _.slice()
    },N.getById=function(t){
    return _.filter(function(e){
      return e.vars.id===t
      })[0]
    },d()&&e.registerPlugin(N);
  var X,U,W,q,H,V,j,G,$,Q,K,Z,J,tt,te,tr,tn,ti,ts,ta,to,tu,tl,tc,tf,th,tp,td,tg,t_,tm,tv,ty,tx,tb,tT,tw,tk,tM=1,tO=Date.now,tC=tO(),tS=0,tE=0,tA=function(t,e,r){
    var n=tq(t)&&("clamp("===t.substr(0,6)||t.indexOf("max")>-1);
    return r["_"+e+"Clamp"]=n,n?t.substr(6,t.length-7):t
    },tP=function(t,e){
    return e&&(!tq(t)||"clamp("!==t.substr(0,6))?"clamp("+t+")":t
    },tD=function(){
    return tt=1
    },tR=function(){
    return tt=0
    },tz=function(t){
    return t
    },tF=function(t){
    return Math.round(1e5*t)/1e5||0
    },tI=function(){
    return"u">typeof window
    },tY=function(){
    return X||tI()&&(X=window.gsap)&&X.registerPlugin&&X
    },tB=function(t){
    return!!~j.indexOf(t)
    },tL=function(t){
    return("Height"===t?tm:W["inner"+t])||H["client"+t]||V["client"+t]
    },tN=function(t){
    return T(t,"getBoundingClientRect")||(tB(t)?function(){
      return ej.width=W.innerWidth,ej.height=tm,ej
      }:function(){
      return er(t)
      })
    },tX=function(t,e,r){
    var n=r.d,i=r.d2,s=r.a;
    return(s=T(t,"getBoundingClientRect"))?function(){
      return s()[n]
      }:function(){
      return(e?tL(i):t["client"+i])||0
      }
    },tU=function(t,e){
    var r=e.s,n=e.d2,i=e.d,s=e.a;
    return Math.max(0,(s=T(t,r="scroll"+n))?s()-tN(t)()[i]:tB(t)?(H[r]||V[r])-tL(n):t[r]-t["offset"+n])
    },tW=function(t,e){
    for(
    var r=0
    ;r<ts.length;r+=3)
    (!e||~e.indexOf(ts[r+1]))&&t(ts[r],ts[r+1],ts[r+2])
    },tq=function(t){
    return"string"==typeof t
    },tH=function(t){
    return"function"==typeof t
    },tV=function(t){
    return"number"==typeof t
    },tj=function(t){
    return"object"==typeof t
    },tG=function(t,e,r){
    return t&&t.progress(+!e)&&r&&t.pause()
    },t$=function(t,e,r){
    if(t.enabled){
      var n=t._ctx?t._ctx.add(function(){
        return e(t,r)
        }):e(t,r);
      n&&n.totalTime&&(t.callbackAnimation=n)
      }
    },tQ=Math.abs,tK="left",tZ="right",tJ="bottom",t0="width",t1="height",t2="Right",t5="Left",t3="Bottom",t8="padding",t6="margin",t4="Width",t9="Height",t7=function(t){
    return W.getComputedStyle(t.nodeType===Node.DOCUMENT_NODE?t.scrollingElement:t)
    },et=function(t){
    var e=t7(t).position;
    t.style.position="absolute"===e||"fixed"===e?e:"relative"
    },ee=function(t,e){
    for(
    var r
     in e)
    r in t||(t[r]=e[r]);
    return t
    },er=function(t,e){
    var r=e&&"matrix(1, 0, 0, 1, 0, 0)"!==t7(t)[te]&&X.to(t,{x:0,y:0,xPercent:0,yPercent:0,rotation:0,rotationX:0,rotationY:0,scale:1,skewX:0,skewY:0}).progress(1),n=t.getBoundingClientRect?t.getBoundingClientRect():t.scrollingElement.getBoundingClientRect();
    return r&&r.progress(0).kill(),n
    },en=function(t,e){
    var r=e.d2;
    return t["offset"+r]||t["client"+r]||0
    },ei=function(t){
    var e,r=[],n=t.labels,i=t.duration();
    for(e in n)
    r.push(n[e]/i);
    return r
    },es=function(t){
    var e=X.utils.snap(t),r=Array.isArray(t)&&t.slice(0).sort(function(t,e){
      return t-e
      });
    return r?function(t,n,i){
      var s;
      if(void 0===i&&(i=.001),!n)
      return e(t);
      if(n>0){
        for(t-=i,s=0;s<r.length;s++)
        if(r[s]>=t)
        return r[s];
        return r[s-1]
        }
      for(s=r.length,t+=i;s--;)
      if(r[s]<=t)
      return r[s];
      return r[0]
      }:function(r,n,i){
      void 0===i&&(i=.001);
      var s=e(r);
      return!n||Math.abs(s-r)<i||s-r<0==n<0?s:e(n<0?r-t:r+t)
      }
    },ea=function(t,e,r,n){
    return r.split(",").forEach(function(r){
      return t(e,r,n)
      })
    },eo=function(t,e,r,n,i){
    return t.addEventListener(e,r,{passive:!n,capture:!!i})
    },eu=function(t,e,r,n){
    return t.removeEventListener(e,r,!!n)
    },el=function(t,e,r){
    (r=r&&r.wheelHandler)&&(t(e,"wheel",r),t(e,"touchmove",r))
    },ec={startColor:"green",endColor:"red",indent:0,fontSize:"16px",fontWeight:"normal"},ef={toggleActions:"play",anticipatePin:0},eh={top:0,left:0,center:.5,bottom:1,right:1},ep=function(t,e){
    if(tq(t)){
      var r=t.indexOf("="),n=~r?(t.charAt(r-1)+1)*parseFloat(t.substr(r+1)):0;
      ~r&&(t.indexOf("%")>r&&(n*=e/100),t=t.substr(0,r-1)),t=n+(t in eh?eh[t]*e:~t.indexOf("%")?parseFloat(t)*e/100:parseFloat(t)||0)
      }
    return t
    },ed=function(t,e,r,n,i,s,a,o){
    var u=i.startColor,l=i.endColor,c=i.fontSize,f=i.indent,h=i.fontWeight,p=q.createElement("div"),d=tB(r)||"fixed"===T(r,"pinType"),g=-1!==t.indexOf("scroller"),_=d?V:"IFRAME"===r.tagName?r.contentDocument.body:r,m=-1!==t.indexOf("start"),v=m?u:l,y="border-color:"+v+";font-size:"+c+";color:"+v+";font-weight:"+h+";pointer-events:none;white-space:nowrap;font-family:sans-serif,Arial;z-index:1000;padding:4px 8px;border-width:0;border-style:solid;";
    return y+="position:"+((g||o)&&d?"fixed;":"absolute;"),(g||o||!d)&&(y+=(n===P?tZ:tJ)+":"+(s+parseFloat(f))+"px;"),a&&(y+="box-sizing:border-box;text-align:left;width:"+a.offsetWidth+"px;"),p._isStart=m,p.setAttribute("class","gsap-marker-"+t+(e?" marker-"+e:"")),p.style.cssText=y,p.innerText=e||0===e?t+"-"+e:t,_.children[0]?_.insertBefore(p,_.children[0]):_.appendChild(p),p._offset=p["offset"+n.op.d2],eg(p,0,n,m),p
    },eg=function(t,e,r,n){
    var i={display:"block"},s=r[n?"os2":"p2"],a=r[n?"p2":"os2"];
    t._isFlipped=n,i[r.a+"Percent"]=n?-100:0,i[r.a]=n?"1px":0,i["border"+s+t4]=1,i["border"+a+t4]=0,i[r.p]=e+"px",X.set(t,i)
    },e_=[],em={},ev=function(){
    return tO()-tS>34&&(tb||(tb=requestAnimationFrame(eB)))
    },ey=function(){
    tl&&tl.isPressed&&!(tl.startX>V.clientWidth)||(m.cache++,tl?tb||(tb=requestAnimationFrame(eB)):eB(),tS||eM("scrollStart"),tS=tO())
    },ex=function(){
    th=W.innerWidth,tf=W.innerHeight
    },eb=function(t){
    m.cache++,(!0===t||!J&&!tu&&!q.fullscreenElement&&!q.webkitFullscreenElement&&(!tc||th!==W.innerWidth||Math.abs(W.innerHeight-tf)>.25*W.innerHeight))&&G.restart(!0)
    },eT={},ew=[],ek=function t(){
    return eu(e0,"scrollEnd",t)||eF(!0)
    },eM=function(t){
    return eT[t]&&eT[t].map(function(t){
      return t()
      })||ew
    },eO=[],eC=function(t){
    for(
    var e=0
    ;e<eO.length;e+=5)
    (!t||eO[e+4]&&eO[e+4].query===t)&&(eO[e].style.cssText=eO[e+1],eO[e].getBBox&&eO[e].setAttribute("transform",eO[e+2]||""),eO[e+3].uncache=1)
    },eS=function(){
    return m.forEach(function(t){
      return tH(t)&&++t.cacheID&&(t.rec=t())
      })
    },eE=function(t,e){
    var r;
    for(tr=0;tr<e_.length;tr++)
    (r=e_[tr])&&(!e||r._ctx===e)&&(t?r.kill(1):r.revert(!0,!0));
    tv=!0,e&&eC(e),e||eM("revert")
    },eA=function(t,e){
    m.cache++,(e||!tT)&&m.forEach(function(t){
      return tH(t)&&t.cacheID++&&(t.rec=0)
      }),tq(t)&&(W.history.scrollRestoration=tg=t)
    },eP=0,eD=function(){
    if(tw!==eP){
      var t=tw=eP;
      requestAnimationFrame(function(){
        return t===eP&&eF(!0)
        })
      }
    },eR=function(){
    V.appendChild(t_),tm=!tl&&t_.offsetHeight||W.innerHeight,V.removeChild(t_)
    },ez=function(t){
    return $(".gsap-marker-start, .gsap-marker-end, .gsap-marker-scroller-start, .gsap-marker-scroller-end").forEach(function(e){
      return e.style.display=t?"none":"block"
      })
    },eF=function(t,e){
    if(H=q.documentElement,V=q.body,j=[W,q,H,V],tS&&!t&&!tv)
    return void eo(e0,"scrollEnd",ek);
    eR(),tT=e0.isRefreshing=!0,tv||eS();
    var r=eM("refreshInit");
    ta&&e0.sort(),e||eE(),m.forEach(function(t){
      tH(t)&&(t.smooth&&(t.target.style.scrollBehavior="auto"),t(0))
      }),e_.slice(0).forEach(function(t){
      return t.refresh()
      }),tv=!1,e_.forEach(function(t){
      if(t._subPinOffset&&t.pin){
        var e=t.vars.horizontal?"offsetWidth":"offsetHeight",r=t.pin[e];
        t.revert(!0,1),t.adjustPinSpacing(t.pin[e]-r),t.refresh()
        }
      }),ty=1,ez(!0),e_.forEach(function(t){
      var e=tU(t.scroller,t._dir),r="max"===t.vars.end||t._endClamp&&t.end>e,n=t._startClamp&&t.start>=e;
      (r||n)&&t.setPositions(n?e-1:t.start,r?Math.max(n?e:t.start+1,e):t.end,!0)
      }),ez(!1),ty=0,r.forEach(function(t){
      return t&&t.render&&t.render(-1)
      }),m.forEach(function(t){
      tH(t)&&(t.smooth&&requestAnimationFrame(function(){
        return t.target.style.scrollBehavior="smooth"
        }),t.rec&&t(t.rec))
      }),eA(tg,1),G.pause(),eP++,tT=2,eB(2),e_.forEach(function(t){
      return tH(t.vars.onRefresh)&&t.vars.onRefresh(t)
      }),tT=e0.isRefreshing=!1,eM("refresh")
    },eI=0,eY=1,eB=function(t){
    if(2===t||!tT&&!tv){
      e0.isUpdating=!0,tk&&tk.update(0);
      var e=e_.length,r=tO(),n=r-tC>=50,i=e&&e_[0].scroll();
      if(eY=eI>i?-1:1,tT||(eI=i),n&&(tS&&!tt&&r-tS>200&&(tS=0,eM("scrollEnd")),K=tC,tC=r),eY<0){
        for(tr=e;tr-- >0;)
        e_[tr]&&e_[tr].update(0,n);
        eY=1
        }else 
      for(tr=0;tr<e;tr++)
      e_[tr]&&e_[tr].update(0,n);
      e0.isUpdating=!1
      }
    tb=0
    },eL=[tK,"top",tJ,tZ,t6+t3,t6+t2,t6+"Top",t6+t5,"display","flexShrink","float","zIndex","gridColumnStart","gridColumnEnd","gridRowStart","gridRowEnd","gridArea","justifySelf","alignSelf","placeSelf","order"],eN=eL.concat([t0,t1,"boxSizing","max"+t4,"max"+t9,"position",t6,t8,t8+"Top",t8+t2,t8+t3,t8+t5]),eX=function(t,e,r){
    eq(r);
    var n=t._gsap;
    if(n.spacerIsNative)
    eq(n.spacerState);
    else 
    if(t._gsap.swappedIn){
      var i=e.parentNode;
      i&&(i.insertBefore(t,e),i.removeChild(e))
      }
    t._gsap.swappedIn=!1
    },eU=function(t,e,r,n){
    if(!t._gsap.swappedIn){
      for(
      var i,s=eL.length,a=e.style,o=t.style
      ;s--;)
      a[i=eL[s]]=r[i];
      a.position="absolute"===r.position?"absolute":"relative","inline"===r.display&&(a.display="inline-block"),o[tJ]=o[tZ]="auto",a.flexBasis=r.flexBasis||"auto",a.overflow="visible",a.boxSizing="border-box",a[t0]=en(t,A)+"px",a[t1]=en(t,P)+"px",a[t8]=o[t6]=o.top=o[tK]="0",eq(n),o[t0]=o["max"+t4]=r[t0],o[t1]=o["max"+t9]=r[t1],o[t8]=r[t8],t.parentNode!==e&&(t.parentNode.insertBefore(e,t),e.appendChild(t)),t._gsap.swappedIn=!0
      }
    },eW=/([A-Z])/g,eq=function(t){
    if(t){
      var e,r,n=t.t.style,i=t.length,s=0;
      for((t.t._gsap||X.core.getCache(t.t)).uncache=1;s<i;s+=2)
      r=t[s+1],e=t[s],r?n[e]=r:n[e]&&n.removeProperty(e.replace(eW,"-$1").toLowerCase())
      }
    },eH=function(t){
    for(
    var e=eN.length,r=t.style,n=[],i=0
    ;i<e;i++)
    n.push(eN[i],r[eN[i]]);
    return n.t=t,n
    },eV=function(t,e,r){
    for(
    var n,i=[],s=t.length,a=8*!!r
    ;a<s;a+=2)
    n=t[a],i.push(n,n in e?e[n]:t[a+1]);
    return i.t=t.t,i
    },ej={left:0,top:0},eG=function(t,e,r,n,i,s,a,o,u,l,c,f,h,p){
    tH(t)&&(t=t(o)),tq(t)&&"max"===t.substr(0,3)&&(t=f+("="===t.charAt(4)?ep("0"+t.substr(3),r):0));
    var d,g,_,m=h?h.time():0;
    if(h&&h.seek(0),isNaN(t)||(t*=1),tV(t))
    h&&(t=X.utils.mapRange(h.scrollTrigger.start,h.scrollTrigger.end,0,f,t)),a&&eg(a,r,n,!0);
    else{
      tH(e)&&(e=e(o));
      var v,y,x,b,T=(t||"0").split(" ");
      (v=er(_=D(e,o)||V)||{}).left||v.top||"none"!==t7(_).display||(b=_.style.display,_.style.display="block",v=er(_),b?_.style.display=b:_.style.removeProperty("display")),y=ep(T[0],v[n.d]),x=ep(T[1]||"0",r),t=v[n.p]-u[n.p]-l+y+i-x,a&&eg(a,x,n,r-x<20||a._isStart&&x>20),r-=r-x
      }
    if(p&&(o[p]=t||-.001,t<0&&(t=0)),s){
      var w=t+r,k=s._isStart;
      d="scroll"+n.d2,eg(s,w,n,k&&w>20||!k&&(c?Math.max(V[d],H[d]):s.parentNode[d])<=w+1),c&&(u=er(a),c&&(s.style[n.op.p]=u[n.op.p]-n.op.m-s._offset+"px"))
      }
    return h&&_&&(d=er(_),h.seek(f),g=er(_),h._caScrollDist=d[n.p]-g[n.p],t=t/h._caScrollDist*f),h&&h.seek(m),h?t:Math.round(t)
    },e$=/(webkit|moz|length|cssText|inset)/i,eQ=function(t,e,r,n){
    if(t.parentNode!==e){
      var i,s,a=t.style;
      if(e===V){
        for(i in t._stOrig=a.cssText,s=t7(t))
        +i||e$.test(i)||!s[i]||"string"!=typeof a[i]||"0"===i||(a[i]=s[i]);
        a.top=r,a.left=n
        }else 
      a.cssText=t._stOrig;
      X.core.getCache(t).uncache=1,e.appendChild(t)
      }
    },eK=function(t,e,r){
    var n=e,i=n;
    return function(e){
      var s=Math.round(t());
      return s!==n&&s!==i&&Math.abs(s-n)>3&&Math.abs(s-i)>3&&(e=s,r&&r()),i=n,n=Math.round(e)
      }
    },eZ=function(t,e,r){
    var n={};
    n[e.p]="+="+r,X.set(t,n)
    },eJ=function(t,e){
    var r=z(t,e),n="_scroll"+e.p2,i=function e(i,s,a,o,u){
      var l=e.tween,c=s.onComplete,f={};
      a=a||r();
      var h=eK(r,a,function(){
        l.kill(),e.tween=0
        });
      return u=o&&u||0,o=o||i-a,l&&l.kill(),s[n]=i,s.inherit=!1,s.modifiers=f,f[n]=function(){
        return h(a+o*l.ratio+u*l.ratio*l.ratio)
        },s.onUpdate=function(){
        m.cache++,e.tween&&eB()
        },s.onComplete=function(){
        e.tween=0,c&&c.call(l)
        },l=e.tween=X.to(t,s)
      };
    return t[n]=r,r.wheelHandler=function(){
      return i.tween&&i.tween.kill()&&(i.tween=0)
      },eo(t,"wheel",r.wheelHandler),e0.isTouch&&eo(t,"touchmove",r.wheelHandler),i
    },e0=function(){
    function t(e,r){
      U||t.register(X)||console.warn("Please gsap.registerPlugin(ScrollTrigger)"),td(this),this.init(e,r)
      }
    return t.prototype.init=function(e,r){
      if(this.progress=this.start=0,this.vars&&this.kill(!0,!0),!tE){
        this.update=this.refresh=this.kill=tz;
        return
        }
      var n,i,s,a,o,u,l,c,f,h,p,d,g,_,y,x,b,w,k,M,O,C,S,E,R,F,I,Y,B,L,N,U,j,G,Z,te,tn,ti,ts,tu,tl,tc=e=ee(tq(e)||tV(e)||e.nodeType?{trigger:e}:e,ef),tf=tc.onUpdate,th=tc.toggleClass,tp=tc.id,td=tc.onToggle,tg=tc.onRefresh,t_=tc.scrub,tm=tc.trigger,tv=tc.pin,tb=tc.pinSpacing,tw=tc.invalidateOnRefresh,tC=tc.anticipatePin,tD=tc.onScrubComplete,tR=tc.onSnapComplete,tI=tc.once,tY=tc.snap,tL=tc.pinReparent,tW=tc.pinSpacer,tK=tc.containerAnimation,tZ=tc.fastScrollEnd,tJ=tc.preventOverlaps,ea=e.horizontal||e.containerAnimation&&!1!==e.horizontal?A:P,el=!t_&&0!==t_,eh=D(e.scroller||W),eg=X.core.getCache(eh),ev=tB(eh),ex=("pinType"in e?e.pinType:T(eh,"pinType")||ev&&"fixed")==="fixed",eT=[e.onEnter,e.onLeave,e.onEnterBack,e.onLeaveBack],ew=el&&e.toggleActions.split(" "),eM="markers"in e?e.markers:ef.markers,eO=ev?0:parseFloat(t7(eh)["border"+ea.p2+t4])||0,eC=this,eS=e.onRefreshInit&&function(){
        return e.onRefreshInit(eC)
        },eE=tX(eh,ev,ea),eA=!ev||~v.indexOf(eh)?tN(eh):function(){
        return ej
        },eP=0,eR=0,ez=0,eF=z(eh,ea);
      if(eC._startClamp=eC._endClamp=!1,eC._dir=ea,tC*=45,eC.scroller=eh,eC.scroll=tK?tK.time.bind(tK):eF,u=eF(),eC.vars=e,r=r||e.animation,"refreshPriority"in e&&(ta=1,-9999===e.refreshPriority&&(tk=eC)),eg.tweenScroll=eg.tweenScroll||{top:eJ(eh,P),left:eJ(eh,A)},eC.tweenTo=s=eg.tweenScroll[ea.p],eC.scrubDuration=function(t){
        (Z=tV(t)&&t)?G?G.duration(t):G=X.to(r,{ease:"expo",totalProgress:"+=0",inherit:!1,duration:Z,paused:!0,onComplete:function(){
          return tD&&tD(eC)
          }}):(G&&G.progress(1).kill(),G=0)
        },r&&(r.vars.lazy=!1,r._initted&&!eC.isReverted||!1!==r.vars.immediateRender&&!1!==e.immediateRender&&r.duration()&&r.render(0,!0,!0),eC.animation=r.pause(),r.scrollTrigger=eC,eC.scrubDuration(t_),U=0,tp||(tp=r.vars.id)),tY&&((!tj(tY)||tY.push)&&(tY={snapTo:tY}),"scrollBehavior"in V.style&&X.set(ev?[V,H]:eh,{scrollBehavior:"auto"}),m.forEach(function(t){
        return tH(t)&&t.target===(ev?q.scrollingElement||H:eh)&&(t.smooth=!1)
        }),o=tH(tY.snapTo)?tY.snapTo:"labels"===tY.snapTo?(n=r,function(t){
        return X.utils.snap(ei(n),t)
        }):"labelsDirectional"===tY.snapTo?(i=r,function(t,e){
        return es(ei(i))(t,e.direction)
        }):!1!==tY.directional?function(t,e){
        return es(tY.snapTo)(t,tO()-eR<500?0:e.direction)
        }:X.utils.snap(tY.snapTo),te=tj(te=tY.duration||{min:.1,max:2})?Q(te.min,te.max):Q(te,te),tn=X.delayedCall(tY.delay||Z/2||.1,function(){
        var t=eF(),e=tO()-eR<500,n=s.tween;
        if((e||10>Math.abs(eC.getVelocity()))&&!n&&!tt&&eP!==t){
          var i,a,u=(t-c)/x,l=r&&!el?r.totalProgress():u,h=e?0:(l-j)/(tO()-K)*1e3||0,p=X.utils.clamp(-u,1-u,tQ(h/2)*h/.185),d=u+(!1===tY.inertia?0:p),g=tY,_=g.onStart,m=g.onInterrupt,v=g.onComplete;
          if(tV(i=o(d,eC))||(i=d),a=Math.max(0,Math.round(c+i*x)),t<=f&&t>=c&&a!==t){
            if(n&&!n._initted&&n.data<=tQ(a-t))
            return;
            !1===tY.inertia&&(p=i-u),s(a,{duration:te(tQ(.185*Math.max(tQ(d-l),tQ(i-l))/h/.05||0)),ease:tY.ease||"power3",data:tQ(a-t),onInterrupt:function(){
              return tn.restart(!0)&&m&&t$(eC,m)
              },onComplete:function(){
              eC.update(),eP=eF(),r&&!el&&(G?G.resetTo("totalProgress",i,r._tTime/r._tDur):r.progress(i)),U=j=r&&!el?r.totalProgress():eC.progress,tR&&tR(eC),v&&t$(eC,v)
              }},t,p*x,a-t-p*x),_&&t$(eC,_,s.tween)
            }
          }else 
        eC.isActive&&eP!==t&&tn.restart(!0)
        }).pause()),tp&&(em[tp]=eC),(tl=(tm=eC.trigger=D(tm||!0!==tv&&tv))&&tm._gsap&&tm._gsap.stRevert)&&(tl=tl(eC)),tv=!0===tv?tm:D(tv),tq(th)&&(th={targets:tm,className:th}),tv&&(!1===tb||tb===t6||(tb=(!!tb||!tv.parentNode||!tv.parentNode.style||"flex"!==t7(tv.parentNode).display)&&t8),eC.pin=tv,(a=X.core.getCache(tv)).spacer?b=a.pinState:(tW&&((tW=D(tW))&&!tW.nodeType&&(tW=tW.current||tW.nativeElement),a.spacerIsNative=!!tW,tW&&(a.spacerState=eH(tW))),a.spacer=M=tW||q.createElement("div"),M.classList.add("pin-spacer"),tp&&M.classList.add("pin-spacer-"+tp),a.pinState=b=eH(tv)),!1!==e.force3D&&X.set(tv,{force3D:!0}),eC.spacer=M=a.spacer,F=(N=t7(tv))[tb+ea.os2],C=X.getProperty(tv),S=X.quickSetter(tv,ea.a,"px"),eU(tv,M,N),k=eH(tv)),eM){
        _=tj(eM)?ee(eM,ec):ec,d=ed("scroller-start",tp,eh,ea,_,0),g=ed("scroller-end",tp,eh,ea,_,0,d),O=d["offset"+ea.op.d2];
        var eI=D(T(eh,"content")||eh);
        h=this.markerStart=ed("start",tp,eI,ea,_,O,0,tK),p=this.markerEnd=ed("end",tp,eI,ea,_,O,0,tK),tK&&(tu=X.quickSetter([h,p],ea.a,"px")),ex||v.length&&!0===T(eh,"fixedMarkers")||(et(ev?V:eh),X.set([d,g],{force3D:!0}),Y=X.quickSetter(d,ea.a,"px"),L=X.quickSetter(g,ea.a,"px"))
        }
      if(tK){
        var eB=tK.vars.onUpdate,eL=tK.vars.onUpdateParams;
        tK.eventCallback("onUpdate",function(){
          eC.update(0,0,1),eB&&eB.apply(tK,eL||[])
          })
        }
      if(eC.previous=function(){
        return e_[e_.indexOf(eC)-1]
        },eC.next=function(){
        return e_[e_.indexOf(eC)+1]
        },eC.revert=function(t,e){
        if(!e)
        return eC.kill(!0);
        var n=!1!==t||!eC.enabled,i=J;
        n!==eC.isReverted&&(n&&(ti=Math.max(eF(),eC.scroll.rec||0),ez=eC.progress,ts=r&&r.progress()),h&&[h,p,d,g].forEach(function(t){
          return t.style.display=n?"none":"block"
          }),n&&(J=eC,eC.update(n)),!tv||tL&&eC.isActive||(n?eX(tv,M,b):eU(tv,M,t7(tv),I)),n||eC.update(n),J=i,eC.isReverted=n)
        },eC.refresh=function(n,i,a,o){
        if(!J&&eC.enabled||i){
          if(tv&&n&&tS)
          return void eo(t,"scrollEnd",ek);
          !tT&&eS&&eS(eC),J=eC,s.tween&&!a&&(s.tween.kill(),s.tween=0),G&&G.pause(),tw&&r&&(r.revert({kill:!1}).invalidate(),r.getChildren?r.getChildren(!0,!0,!1).forEach(function(t){
            return t.vars.immediateRender&&t.render(0,!0,!0)
            }):r.vars.immediateRender&&r.render(0,!0,!0)),eC.isReverted||eC.revert(!0,!0),eC._subPinOffset=!1;
          var _,m,v,T,O,S,F,Y,L,N,U,W,j,$=eE(),Q=eA(),K=tK?tK.duration():tU(eh,ea),Z=x<=.01||!x,tt=0,te=o||0,tr=tj(a)?a.end:e.end,ta=e.endTrigger||tm,tu=tj(a)?a.start:e.start||(0!==e.start&&tm?tv?"0 0":"0 100%":0),tl=eC.pinnedContainer=e.pinnedContainer&&D(e.pinnedContainer,eC),tc=tm&&Math.max(0,e_.indexOf(eC))||0,tf=tc;
          for(eM&&tj(a)&&(W=X.getProperty(d,ea.p),j=X.getProperty(g,ea.p));tf-- >0;)
          (S=e_[tf]).end||S.refresh(0,1)||(J=eC),(F=S.pin)&&(F===tm||F===tv||F===tl)&&!S.isReverted&&(N||(N=[]),N.unshift(S),S.revert(!0,!0)),S!==e_[tf]&&(tc--,tf--);
          for(tH(tu)&&(tu=tu(eC)),c=eG(tu=tA(tu,"start",eC),tm,$,ea,eF(),h,d,eC,Q,eO,ex,K,tK,eC._startClamp&&"_startClamp")||(tv?-.001:0),tH(tr)&&(tr=tr(eC)),tq(tr)&&!tr.indexOf("+=")&&(~tr.indexOf(" ")?tr=(tq(tu)?tu.split(" ")[0]:"")+tr:(tt=ep(tr.substr(2),$),tr=tq(tu)?tu:(tK?X.utils.mapRange(0,tK.duration(),tK.scrollTrigger.start,tK.scrollTrigger.end,c):c)+tt,ta=tm)),tr=tA(tr,"end",eC),f=Math.max(c,eG(tr||(ta?"100% 0":K),ta,$,ea,eF()+tt,p,g,eC,Q,eO,ex,K,tK,eC._endClamp&&"_endClamp"))||-.001,tt=0,tf=tc;tf--;)
          (F=(S=e_[tf]||{}).pin)&&S.start-S._pinPush<=c&&!tK&&S.end>0&&(_=S.end-(eC._startClamp?Math.max(0,S.start):S.start),(F===tm&&S.start-S._pinPush<c||F===tl)&&isNaN(tu)&&(tt+=_*(1-S.progress)),F===tv&&(te+=_));
          if(c+=tt,f+=tt,eC._startClamp&&(eC._startClamp+=tt),eC._endClamp&&!tT&&(eC._endClamp=f||-.001,f=Math.min(f,tU(eh,ea))),x=f-c||(c-=.01)&&.001,Z&&(ez=X.utils.clamp(0,1,X.utils.normalize(c,f,ti))),eC._pinPush=te,h&&tt&&((_={})[ea.a]="+="+tt,tl&&(_[ea.p]="-="+eF()),X.set([h,p],_)),tv&&!(ty&&eC.end>=tU(eh,ea)))
          _=t7(tv),T=ea===P,v=eF(),E=parseFloat(C(ea.a))+te,!K&&f>1&&(U={style:U=(ev?q.scrollingElement||H:eh).style,value:U["overflow"+ea.a.toUpperCase()]},ev&&"scroll"!==t7(V)["overflow"+ea.a.toUpperCase()]&&(U.style["overflow"+ea.a.toUpperCase()]="scroll")),eU(tv,M,_),k=eH(tv),m=er(tv,!0),Y=ex&&z(eh,T?A:P)(),tb?((I=[tb+ea.os2,x+te+"px"]).t=M,(tf=tb===t8?en(tv,ea)+x+te:0)&&(I.push(ea.d,tf+"px"),"auto"!==M.style.flexBasis&&(M.style.flexBasis=tf+"px")),eq(I),tl&&e_.forEach(function(t){
            t.pin===tl&&!1!==t.vars.pinSpacing&&(t._subPinOffset=!0)
            }),ex&&eF(ti)):(tf=en(tv,ea))&&"auto"!==M.style.flexBasis&&(M.style.flexBasis=tf+"px"),ex&&((O={top:m.top+(T?v-c:Y)+"px",left:m.left+(T?Y:v-c)+"px",boxSizing:"border-box",position:"fixed"})[t0]=O["max"+t4]=Math.ceil(m.width)+"px",O[t1]=O["max"+t9]=Math.ceil(m.height)+"px",O[t6]=O[t6+"Top"]=O[t6+t2]=O[t6+t3]=O[t6+t5]="0",O[t8]=_[t8],O[t8+"Top"]=_[t8+"Top"],O[t8+t2]=_[t8+t2],O[t8+t3]=_[t8+t3],O[t8+t5]=_[t8+t5],w=eV(b,O,tL),tT&&eF(0)),r?(L=r._initted,to(1),r.render(r.duration(),!0,!0),R=C(ea.a)-E+x+te,B=Math.abs(x-R)>1,ex&&B&&w.splice(w.length-2,2),r.render(0,!0,!0),L||r.invalidate(!0),r.parent||r.totalTime(r.totalTime()),to(0)):R=x,U&&(U.value?U.style["overflow"+ea.a.toUpperCase()]=U.value:U.style.removeProperty("overflow-"+ea.a));
          else 
          if(tm&&eF()&&!tK)
          for(m=tm.parentNode;m&&m!==V;)
          m._pinOffset&&(c-=m._pinOffset,f-=m._pinOffset),m=m.parentNode;
          N&&N.forEach(function(t){
            return t.revert(!1,!0)
            }),eC.start=c,eC.end=f,u=l=tT?ti:eF(),tK||tT||(u<ti&&eF(ti),eC.scroll.rec=0),eC.revert(!1,!0),eR=tO(),tn&&(eP=-1,tn.restart(!0)),J=0,r&&el&&(r._initted||ts)&&r.progress()!==ts&&r.progress(ts||0,!0).render(r.time(),!0,!0),(Z||ez!==eC.progress||tK||tw||r&&!r._initted)&&(r&&!el&&(r._initted||ez||!1!==r.vars.immediateRender)&&r.totalProgress(tK&&c<-.001&&!ez?X.utils.normalize(c,f,0):ez,!0),eC.progress=Z||(u-c)/x===ez?0:ez),tv&&tb&&(M._pinOffset=Math.round(eC.progress*R)),G&&G.invalidate(),isNaN(W)||(W-=X.getProperty(d,ea.p),j-=X.getProperty(g,ea.p),eZ(d,ea,W),eZ(h,ea,W-(o||0)),eZ(g,ea,j),eZ(p,ea,j-(o||0))),Z&&!tT&&eC.update(),!tg||tT||y||(y=!0,tg(eC),y=!1)
          }
        },eC.getVelocity=function(){
        return(eF()-l)/(tO()-K)*1e3||0
        },eC.endAnimation=function(){
        tG(eC.callbackAnimation),r&&(G?G.progress(1):r.paused()?el||tG(r,eC.direction<0,1):tG(r,r.reversed()))
        },eC.labelToScroll=function(t){
        return r&&r.labels&&(c||eC.refresh()||c)+r.labels[t]/r.duration()*x||0
        },eC.getTrailing=function(t){
        var e=e_.indexOf(eC),r=eC.direction>0?e_.slice(0,e).reverse():e_.slice(e+1);
        return(tq(t)?r.filter(function(e){
          return e.vars.preventOverlaps===t
          }):r).filter(function(t){
          return eC.direction>0?t.end<=c:t.start>=f
          })
        },eC.update=function(t,e,n){
        if(!tK||n||t){
          var i,a,o,h,p,g,_,m=!0===tT?ti:eC.scroll(),v=t?0:(m-c)/x,y=v<0?0:v>1?1:v||0,b=eC.progress;
          if(e&&(l=u,u=tK?eF():m,tY&&(j=U,U=r&&!el?r.totalProgress():y)),tC&&tv&&!J&&!tM&&tS&&(!y&&c<m+(m-l)/(tO()-K)*tC?y=1e-4:1===y&&f>m+(m-l)/(tO()-K)*tC&&(y=.9999)),y!==b&&eC.enabled){
            if(h=(p=(i=eC.isActive=!!y&&y<1)!=(!!b&&b<1))||!!y!=!!b,eC.direction=y>b?1:-1,eC.progress=y,h&&!J&&(a=y&&!b?0:1===y?1:1===b?2:3,el&&(o=!p&&"none"!==ew[a+1]&&ew[a+1]||ew[a],_=r&&("complete"===o||"reset"===o||o in r))),tJ&&(p||_)&&(_||t_||!r)&&(tH(tJ)?tJ(eC):eC.getTrailing(tJ).forEach(function(t){
              return t.endAnimation()
              })),!el&&(!G||J||tM?r&&r.totalProgress(y,!!(J&&(eR||t))):(G._dp._time-G._start!==G._time&&G.render(G._dp._time-G._start),G.resetTo?G.resetTo("totalProgress",y,r._tTime/r._tDur):(G.vars.totalProgress=y,G.invalidate().restart()))),tv)
            if(t&&tb&&(M.style[tb+ea.os2]=F),ex){
              if(h){
                if(g=!t&&y>b&&f+1>m&&m+1>=tU(eh,ea),tL)
                if(!t&&(i||g)){
                  var T=er(tv,!0),O=m-c;
                  eQ(tv,V,T.top+(ea===P?O:0)+"px",T.left+(ea===P?0:O)+"px")
                  }else 
                eQ(tv,M);
                eq(i||g?w:k),B&&y<1&&i||S(E+(1!==y||g?0:R))
                }
              }else 
            S(tF(E+R*y));
            !tY||s.tween||J||tM||tn.restart(!0),th&&(p||tI&&y&&(y<1||!tx))&&$(th.targets).forEach(function(t){
              return t.classList[i||tI?"add":"remove"](th.className)
              }),!tf||el||t||tf(eC),h&&!J?(el&&(_&&("complete"===o?r.pause().totalProgress(1):"reset"===o?r.restart(!0).pause():"restart"===o?r.restart(!0):r[o]()),tf&&tf(eC)),(p||!tx)&&(td&&p&&t$(eC,td),eT[a]&&t$(eC,eT[a]),tI&&(1===y?eC.kill(!1,1):eT[a]=0),!p&&eT[a=1===y?1:3]&&t$(eC,eT[a])),tZ&&!i&&Math.abs(eC.getVelocity())>(tV(tZ)?tZ:2500)&&(tG(eC.callbackAnimation),G?G.progress(1):tG(r,"reverse"===o?1:!y,1))):el&&tf&&!J&&tf(eC)
            }
          if(L){
            var C=tK?m/tK.duration()*(tK._caScrollDist||0):m;
            Y(C+ +!!d._isFlipped),L(C)
            }
          tu&&tu(-m/tK.duration()*(tK._caScrollDist||0))
          }
        },eC.enable=function(e,r){
        eC.enabled||(eC.enabled=!0,eo(eh,"resize",eb),ev||eo(eh,"scroll",ey),eS&&eo(t,"refreshInit",eS),!1!==e&&(eC.progress=ez=0,u=l=eP=eF()),!1!==r&&eC.refresh())
        },eC.getTween=function(t){
        return t&&s?s.tween:G
        },eC.setPositions=function(t,e,r,n){
        if(tK){
          var i=tK.scrollTrigger,s=tK.duration(),a=i.end-i.start;
          t=i.start+a*t/s,e=i.start+a*e/s
          }
        eC.refresh(!1,!1,{start:tP(t,r&&!!eC._startClamp),end:tP(e,r&&!!eC._endClamp)},n),eC.update()
        },eC.adjustPinSpacing=function(t){
        if(I&&t){
          var e=I.indexOf(ea.d)+1;
          I[e]=parseFloat(I[e])+t+"px",I[1]=parseFloat(I[1])+t+"px",eq(I)
          }
        },eC.disable=function(e,r){
        if(!1!==e&&eC.revert(!0,!0),eC.enabled&&(eC.enabled=eC.isActive=!1,r||G&&G.pause(),ti=0,a&&(a.uncache=1),eS&&eu(t,"refreshInit",eS),tn&&(tn.pause(),s.tween&&s.tween.kill()&&(s.tween=0)),!ev)){
          for(
          var n=e_.length
          ;n--;)
          if(e_[n].scroller===eh&&e_[n]!==eC)
          return;
          eu(eh,"resize",eb),ev||eu(eh,"scroll",ey)
          }
        },eC.kill=function(t,n){
        eC.disable(t,n),G&&!n&&G.kill(),tp&&delete em[tp];
        var i=e_.indexOf(eC);
        i>=0&&e_.splice(i,1),i===tr&&eY>0&&tr--,i=0,e_.forEach(function(t){
          return t.scroller===eC.scroller&&(i=1)
          }),i||tT||(eC.scroll.rec=0),r&&(r.scrollTrigger=null,t&&r.revert({kill:!1}),n||r.kill()),h&&[h,p,d,g].forEach(function(t){
          return t.parentNode&&t.parentNode.removeChild(t)
          }),tk===eC&&(tk=0),tv&&(a&&(a.uncache=1),i=0,e_.forEach(function(t){
          return t.pin===tv&&i++
          }),i||(a.spacer=0)),e.onKill&&e.onKill(eC)
        },e_.push(eC),eC.enable(!1,!1),tl&&tl(eC),r&&r.add&&!x){
        var eN=eC.update;
        eC.update=function(){
          eC.update=eN,m.cache++,c||f||eC.refresh()
          },X.delayedCall(.01,eC.update),x=.01,c=f=0
        }else 
      eC.refresh();
      tv&&eD()
      },t.register=function(e){
      return U||(X=e||tY(),tI()&&window.document&&t.enable(),U=tE),U
      },t.defaults=function(t){
      if(t)
      for(
      var e
       in t)
      ef[e]=t[e];
      return ef
      },t.disable=function(t,e){
      tE=0,e_.forEach(function(r){
        return r[e?"kill":"disable"](t)
        }),eu(W,"wheel",ey),eu(q,"scroll",ey),clearInterval(Z),eu(q,"touchcancel",tz),eu(V,"touchstart",tz),ea(eu,q,"pointerdown,touchstart,mousedown",tD),ea(eu,q,"pointerup,touchend,mouseup",tR),G.kill(),tW(eu);
      for(
      var r=0
      ;r<m.length;r+=3)
      el(eu,m[r],m[r+1]),el(eu,m[r],m[r+2])
      },t.enable=function(){
      if(W=window,H=(q=document).documentElement,V=q.body,X)
      if($=X.utils.toArray,Q=X.utils.clamp,td=X.core.context||tz,to=X.core.suppressOverwrites||tz,tg=W.history.scrollRestoration||"auto",eI=W.pageYOffset||0,X.core.globals("ScrollTrigger",t),V){
        tE=1,(t_=document.createElement("div")).style.height="100vh",t_.style.position="absolute",eR(),function t(){
          return tE&&requestAnimationFrame(t)
          }(),N.register(X),t.isTouch=N.isTouch,tp=N.isTouch&&/(iPad|iPhone|iPod|Mac)/g.test(navigator.userAgent),tc=1===N.isTouch,eo(W,"wheel",ey),j=[W,q,H,V],X.matchMedia?(t.matchMedia=function(t){
          var e,r=X.matchMedia();
          for(e in t)
          r.add(e,t[e]);
          return r
          },X.addEventListener("matchMediaInit",function(){
          eS(),eE()
          }),X.addEventListener("matchMediaRevert",function(){
          return eC()
          }),X.addEventListener("matchMedia",function(){
          eF(0,1),eM("matchMedia")
          }),X.matchMedia().add("(orientation: portrait)",function(){
          return ex(),ex
          })):console.warn("Requires GSAP 3.11.0 or later"),ex(),eo(q,"scroll",ey);
        var e,r,n=V.hasAttribute("style"),i=V.style,s=i.borderTopStyle,a=X.core.Animation.prototype;
        for(a.revert||Object.defineProperty(a,"revert",{value:function(){
          return this.time(-.01,!0)
          }}),i.borderTopStyle="solid",P.m=Math.round((e=er(V)).top+P.sc())||0,A.m=Math.round(e.left+A.sc())||0,s?i.borderTopStyle=s:i.removeProperty("border-top-style"),n||(V.setAttribute("style",""),V.removeAttribute("style")),Z=setInterval(ev,250),X.delayedCall(.5,function(){
          return tM=0
          }),eo(q,"touchcancel",tz),eo(V,"touchstart",tz),ea(eo,q,"pointerdown,touchstart,mousedown",tD),ea(eo,q,"pointerup,touchend,mouseup",tR),te=X.utils.checkPrefix("transform"),eN.push(te),U=tO(),G=X.delayedCall(.2,eF).pause(),ts=[q,"visibilitychange",function(){
          var t=W.innerWidth,e=W.innerHeight;
          q.hidden?(tn=t,ti=e):(tn!==t||ti!==e)&&eb()
          },q,"DOMContentLoaded",eF,W,"load",eF,W,"resize",eb],tW(eo),e_.forEach(function(t){
          return t.enable(0,1)
          }),r=0;r<m.length;r+=3)
        el(eu,m[r],m[r+1]),el(eu,m[r],m[r+2])
        }else 
      q&&q.addEventListener("DOMContentLoaded",function e(){
        t.enable(),q.removeEventListener("DOMContentLoaded",e)
        })
      },t.config=function(e){
      "limitCallbacks"in e&&(tx=!!e.limitCallbacks);
      var r=e.syncInterval;
      r&&clearInterval(Z)||(Z=r)&&setInterval(ev,r),"ignoreMobileResize"in e&&(tc=1===t.isTouch&&e.ignoreMobileResize),"autoRefreshEvents"in e&&(tW(eu)||tW(eo,e.autoRefreshEvents||"none"),tu=-1===(e.autoRefreshEvents+"").indexOf("resize"))
      },t.scrollerProxy=function(t,e){
      var r=D(t),n=m.indexOf(r),i=tB(r);
      ~n&&m.splice(n,i?6:2),e&&(i?v.unshift(W,e,V,e,H,e):v.unshift(r,e))
      },t.clearMatchMedia=function(t){
      e_.forEach(function(e){
        return e._ctx&&e._ctx.query===t&&e._ctx.kill(!0,!0)
        })
      },t.isInViewport=function(t,e,r){
      var n=(tq(t)?D(t):t).getBoundingClientRect(),i=n[r?t0:t1]*e||0;
      return r?n.right-i>0&&n.left+i<W.innerWidth:n.bottom-i>0&&n.top+i<W.innerHeight
      },t.positionInViewport=function(t,e,r){
      tq(t)&&(t=D(t));
      var n=t.getBoundingClientRect(),i=n[r?t0:t1],s=null==e?i/2:e in eh?eh[e]*i:~e.indexOf("%")?parseFloat(e)*i/100:parseFloat(e)||0;
      return r?(n.left+s)/W.innerWidth:(n.top+s)/W.innerHeight
      },t.killAll=function(t){
      if(e_.slice(0).forEach(function(t){
        return"ScrollSmoother"!==t.vars.id&&t.kill()
        }),!0!==t){
        var e=eT.killAll||[];
        eT={},e.forEach(function(t){
          return t()
          })
        }
      },t
    }();
  e0.version="3.15.0",e0.saveStyles=function(t){
    return t?$(t).forEach(function(t){
      if(t&&t.style){
        var e=eO.indexOf(t);
        e>=0&&eO.splice(e,5),eO.push(t,t.style.cssText,t.getBBox&&t.getAttribute("transform"),X.core.getCache(t),td())
        }
      }):eO
    },e0.revert=function(t,e){
    return eE(!t,e)
    },e0.create=function(t,e){
    return new e0(t,e)
    },e0.refresh=function(t){
    return t?eb(!0):(U||e0.register())&&eF(!0)
    },e0.update=function(t){
    return++m.cache&&eB(2*(!0===t))
    },e0.clearScrollMemory=eA,e0.maxScroll=function(t,e){
    return tU(t,e?A:P)
    },e0.getScrollFunc=function(t,e){
    return z(D(t),e?A:P)
    },e0.getById=function(t){
    return em[t]
    },e0.getAll=function(){
    return e_.filter(function(t){
      return"ScrollSmoother"!==t.vars.id
      })
    },e0.isScrolling=function(){
    return!!tS
    },e0.snapDirectional=es,e0.addEventListener=function(t,e){
    var r=eT[t]||(eT[t]=[]);
    ~r.indexOf(e)||r.push(e)
    },e0.removeEventListener=function(t,e){
    var r=eT[t],n=r&&r.indexOf(e);
    n>=0&&r.splice(n,1)
    },e0.batch=function(t,e){
    var r,n=[],i={},s=e.interval||.016,a=e.batchMax||1e9,o=function(t,e){
      var r=[],n=[],i=X.delayedCall(s,function(){
        e(r,n),r=[],n=[]
        }).pause();
      return function(t){
        r.length||i.restart(!0),r.push(t.trigger),n.push(t),a<=r.length&&i.progress(1)
        }
      };
    for(r in e)
    i[r]="on"===r.substr(0,2)&&tH(e[r])&&"onRefreshInit"!==r?o(r,e[r]):e[r];
    return tH(a)&&(a=a(),eo(e0,"refresh",function(){
      return a=e.batchMax()
      })),$(t).forEach(function(t){
      var e={};
      for(r in i)
      e[r]=i[r];
      e.trigger=t,n.push(e0.create(e))
      }),n
    };
  var e1,e2=function(t,e,r,n){
    return e>n?t(n):e<0&&t(0),r>n?(n-e)/(r-e):r<0?e/(e-r):1
    },e5=function t(e,r){
    !0===r?e.style.removeProperty("touch-action"):e.style.touchAction=!0===r?"auto":r?"pan-"+r+(N.isTouch?" pinch-zoom":""):"none",e===H&&t(V,r)
    },e3={auto:1,scroll:1},e8=function(t){
    var e,r=t.event,n=t.target,i=t.axis,s=(r.changedTouches?r.changedTouches[0]:r).target,a=s._gsap||X.core.getCache(s),o=tO();
    if(!a._isScrollT||o-a._isScrollT>2e3){
      for(;s&&s!==V&&(s.scrollHeight<=s.clientHeight&&s.scrollWidth<=s.clientWidth||!(e3[(e=t7(s)).overflowY]||e3[e.overflowX]));)
      s=s.parentNode;
      a._isScroll=s&&s!==n&&!tB(s)&&(e3[(e=t7(s)).overflowY]||e3[e.overflowX]),a._isScrollT=o
      }
    (a._isScroll||"x"===i)&&(r.stopPropagation(),r._gsapAllow=!0)
    },e6=function(t,e,r,n){
    return N.create({target:t,capture:!0,debounce:!1,lockAxis:!0,type:e,onWheel:n=n&&e8,onPress:n,onDrag:n,onScroll:n,onEnable:function(){
      return r&&eo(q,N.eventTypes[0],e9,!1,!0)
      },onDisable:function(){
      return eu(q,N.eventTypes[0],e9,!0)
      }})
    },e4=/(input|label|select|textarea)/i,e9=function(t){
    var e=e4.test(t.target.tagName);
    (e||e1)&&(t._gsapAllow=!0,e1=e)
    },e7=function(t){
    tj(t)||(t={}),t.preventDefault=t.isNormalizer=t.allowClicks=!0,t.type||(t.type="wheel,touch"),t.debounce=!!t.debounce,t.id=t.id||"normalizer";
    var e,r,n,i,s,a,o,u,l=t,c=l.normalizeScrollX,f=l.momentum,h=l.allowNestedScroll,p=l.onRelease,d=D(t.target)||H,g=X.core.globals().ScrollSmoother,_=g&&g.get(),v=tp&&(t.content&&D(t.content)||_&&!1!==t.content&&!_.smooth()&&_.content()),y=z(d,P),x=z(d,A),b=1,T=(N.isTouch&&W.visualViewport?W.visualViewport.scale*W.visualViewport.width:W.outerWidth)/W.innerWidth,w=0,k=tH(f)?function(){
      return f(e)
      }:function(){
      return f||2.8
      },M=e6(d,t.type,!0,h),O=function(){
      return i=!1
      },C=tz,S=tz,E=function(){
      r=tU(d,P),S=Q(+!!tp,r),c&&(C=Q(0,tU(d,A))),n=eP
      },R=function(){
      v._gsap.y=tF(parseFloat(v._gsap.y)+y.offset)+"px",v.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+parseFloat(v._gsap.y)+", 0, 1)",y.offset=y.cacheID=0
      },F=function(){
      if(i){
        requestAnimationFrame(O);
        var t=tF(e.deltaY/2),r=S(y.v-t);
        if(v&&r!==y.v+y.offset){
          y.offset=r-y.v;
          var n=tF((parseFloat(v&&v._gsap.y)||0)-y.offset);
          v.style.transform="matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, "+n+", 0, 1)",v._gsap.y=n+"px",y.cacheID=m.cache,eB()
          }
        return!0
        }
      y.offset&&R(),i=!0
      },I=function(){
      E(),s.isActive()&&s.vars.scrollY>r&&(y()>r?s.progress(1)&&y(r):s.resetTo("scrollY",r))
      };
    return v&&X.set(v,{y:"+=0"}),t.ignoreCheck=function(t){
      return tp&&"touchmove"===t.type&&F(t)||b>1.05&&"touchstart"!==t.type||e.isGesturing||t.touches&&t.touches.length>1
      },t.onPress=function(){
      i=!1;
      var t=b;
      b=tF((W.visualViewport&&W.visualViewport.scale||1)/T),s.pause(),t!==b&&e5(d,b>1.01||!c&&"x"),a=x(),o=y(),E(),n=eP
      },t.onRelease=t.onGestureStart=function(t,e){
      if(y.offset&&R(),e){
        m.cache++;
        var n,i,a=k();
        c&&(i=(n=x())+-(.05*a*t.velocityX)/.227,a*=e2(x,n,i,tU(d,A)),s.vars.scrollX=C(i)),i=(n=y())+-(.05*a*t.velocityY)/.227,a*=e2(y,n,i,tU(d,P)),s.vars.scrollY=S(i),s.invalidate().duration(a).play(.01),(tp&&s.vars.scrollY>=r||n>=r-1)&&X.to({},{onUpdate:I,duration:a})
        }else 
      u.restart(!0);
      p&&p(t)
      },t.onWheel=function(){
      s._ts&&s.pause(),tO()-w>1e3&&(n=0,w=tO())
      },t.onChange=function(t,e,r,i,s){
      if(eP!==n&&E(),e&&c&&x(C(i[2]===e?a+(t.startX-t.x):x()+e-i[1])),r){
        y.offset&&R();
        var u=s[2]===r,l=u?o+t.startY-t.y:y()+r-s[1],f=S(l);
        u&&l!==f&&(o+=f-l),y(f)
        }
      (r||e)&&eB()
      },t.onEnable=function(){
      e5(d,!c&&"x"),e0.addEventListener("refresh",I),eo(W,"resize",I),y.smooth&&(y.target.style.scrollBehavior="auto",y.smooth=x.smooth=!1),M.enable()
      },t.onDisable=function(){
      e5(d,!0),eu(W,"resize",I),e0.removeEventListener("refresh",I),M.kill()
      },t.lockAxis=!1!==t.lockAxis,(e=new N(t)).iOS=tp,tp&&!y()&&y(1),tp&&X.ticker.add(tz),u=e._dc,s=X.to(e,{ease:"power4",paused:!0,inherit:!1,scrollX:c?"+=0.1":"+=0",scrollY:"+=0.1",modifiers:{scrollY:eK(y,y(),function(){
      return s.pause()
      })},onUpdate:eB,onComplete:u.vars.onComplete}),e
    };
  e0.sort=function(t){
    if(tH(t))
    return e_.sort(t);
    var e=W.pageYOffset||0;
    return e0.getAll().forEach(function(t){
      return t._sortY=t.trigger?e+t.trigger.getBoundingClientRect().top:t.start+W.innerHeight
      }),e_.sort(t||function(t,e){
      return -1e6*(t.vars.refreshPriority||0)+(t.vars.containerAnimation?1e6:t._sortY)-((e.vars.containerAnimation?1e6:e._sortY)+-1e6*(e.vars.refreshPriority||0))
      })
    },e0.observe=function(t){
    return new N(t)
    },e0.normalizeScroll=function(t){
    if(void 0===t)
    return tl;
    if(!0===t&&tl)
    return tl.enable();
    if(!1===t){
      tl&&tl.kill(),tl=t;
      return
      }
    var e=t instanceof N?t:e7(t);
    return tl&&tl.target===e.target&&tl.kill(),tB(e.target)&&(tl=e),e
    },e0.core={_getVelocityProp:F,_inputObserver:e6,_scrollers:m,_proxies:v,bridge:{ss:function(){
    tS||eM("scrollStart"),tS=tO()
    },ref:function(){
    return J
    }}},tY()&&X.registerPlugin(e0),t.s(["ScrollTrigger",0,e0],83495)
  }]);
