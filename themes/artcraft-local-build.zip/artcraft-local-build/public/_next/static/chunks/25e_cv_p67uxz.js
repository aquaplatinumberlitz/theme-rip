(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,16787,87486,10204,93479,e=>{
  "use strict";
  var t=e.i(43476),a=e.i(19056);
  function r({className:e,children:i,required:n,...o}){
    return(0,t.jsxs)("label",{className:(0,a.twMerge)("mb-1.5 font-mono text-[10px] font-semibold uppercase tracking-[0.25em] text-muted",e),...o,children:[i,n&&(0,t.jsx)("span",{className:"ml-0.5 text-danger",children:"*"})]})
    }
  e.s(["Badge",0,function({label:e,className:r,icon:i}){
    return(0,t.jsxs)("div",{className:(0,a.twMerge)("flex w-fit items-center gap-1 rounded-none border border-line bg-bg-sunken px-1.5 py-px font-mono text-[10px] font-medium uppercase tracking-[0.1em] text-muted",r),children:[i,e]})
    }],87486),e.i(19455),e.i(57428),e.i(73357),e.i(66790),e.s(["Label",0,r],10204),e.s(["Input",0,function({label:e,icon:i,inputClassName:n,className:o,id:s,isError:l,errorMessage:c,ref:d,...u}){
    let p=s??e;
    return(0,t.jsxs)("div",{className:(0,a.twMerge)("flex flex-col",o),children:[e&&(0,t.jsx)(r,{htmlFor:p,children:e}),(0,t.jsxs)("div",{className:"relative w-full",children:[i&&(0,t.jsx)("span",{className:"pointer-events-none absolute inset-y-0 left-3 flex items-center text-muted",children:i}),(0,t.jsx)("input",{ref:d,id:p,className:(0,a.twMerge)("h-10 w-full rounded-none border border-line bg-bg-raised px-3 py-2.5 text-ink outline-none placeholder:text-faint","transition-colors duration-150 ease-in-out hover:border-line-strong focus:border-ink focus:outline-none","disabled:cursor-not-allowed disabled:opacity-60 disabled:hover:border-line",i&&"pl-10",l&&"border-danger focus:border-danger",n),...u}),c&&(0,t.jsx)("p",{className:"mt-1 font-mono text-[10px] uppercase tracking-[0.1em] text-danger",children:c})]})]})
    }],93479),e.i(389),e.i(67489),e.i(99375),e.i(22641),e.i(46798),e.s([],16787)
  },98183,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0});
  var r={assign:function(){
    return l
    },searchParamsToUrlQuery:function(){
    return n
    },urlQueryToSearchParams:function(){
    return s
    }};
  for(
  var i
   in r)
  Object.defineProperty(a,i,{enumerable:!0,get:r[i]});
  function n(e){
    let t={};
    for(
    let[a,r]
    of e.entries()){
      let e=t[a];
      void 0===e?t[a]=r:Array.isArray(e)?e.push(r):t[a]=[e,r]
      }
    return t
    }
  function o(e){
    return"string"==typeof e?e:("number"!=typeof e||isNaN(e))&&"boolean"!=typeof e?"":String(e)
    }
  function s(e){
    let t=new URLSearchParams;
    for(
    let[a,r]
    of Object.entries(e))
    if(Array.isArray(r))
    for(
    let e
     of r)
    t.append(a,o(e));
    else 
    t.set(a,o(r));
    return t
    }
  function l(e,...t){
    for(
    let a
     of t){
      for(
      let t
       of a.keys())
      e.delete(t);
      for(
      let[t,r]
      of a.entries())
      e.append(t,r)
      }
    return e
    }
  },18967,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0});
  var r={DecodeError:function(){
    return b
    },MiddlewareNotFoundError:function(){
    return y
    },MissingStaticPage:function(){
    return v
    },NormalizeError:function(){
    return w
    },PageNotFoundError:function(){
    return x
    },SP:function(){
    return g
    },ST:function(){
    return m
    },WEB_VITALS:function(){
    return n
    },execOnce:function(){
    return o
    },getDisplayName:function(){
    return u
    },getLocationOrigin:function(){
    return c
    },getURL:function(){
    return d
    },isAbsoluteUrl:function(){
    return l
    },isResSent:function(){
    return p
    },loadGetInitialProps:function(){
    return h
    },normalizeRepeatedSlashes:function(){
    return f
    },stringifyError:function(){
    return k
    }};
  for(
  var i
   in r)
  Object.defineProperty(a,i,{enumerable:!0,get:r[i]});
  let n=["CLS","FCP","FID","INP","LCP","TTFB"];
  function o(e){
    let t,a=!1;
    return(...r)=>(a||(a=!0,t=e(...r)),t)
    }
  let s=/^[a-zA-Z][a-zA-Z\d+\-.]*?:/,l=e=>s.test(e);
  function c(){
    let{protocol:e,hostname:t,port:a}=window.location;
    return`${e}//${t}${a?":"+a:""}`
    }
  function d(){
    let{href:e}=window.location,t=c();
    return e.substring(t.length)
    }
  function u(e){
    return"string"==typeof e?e:e.displayName||e.name||"Unknown"
    }
  function p(e){
    return e.finished||e.headersSent
    }
  function f(e){
    let t=e.split("?");
    return t[0].replace(/\\/g,"/").replace(/\/\/+/g,"/")+(t[1]?`?${t.slice(1).join("?")}`:"")
    }
  async function h(e,t){
    let a=t.res||t.ctx&&t.ctx.res;
    if(!e.getInitialProps)
    return t.ctx&&t.Component?{pageProps:await h(t.Component,t.ctx)}:{};
    let r=await e.getInitialProps(t);
    if(a&&p(a))
    return r;
    if(!r)
    throw Object.defineProperty(Error(`"${u(e)}.getInitialProps()" should resolve to an object. But found "${r}" instead.`),"__NEXT_ERROR_CODE",{value:"E1025",enumerable:!1,configurable:!0});
    return r
    }
  let g="u">typeof performance,m=g&&["mark","measure","getEntriesByName"].every(e=>"function"==typeof performance[e]);
  class b extends Error{
    }
  class w extends Error{
    }
  class x extends Error{
    constructor(e){
      super(),this.code="ENOENT",this.name="PageNotFoundError",this.message=`Cannot find module for page: ${e}`
      }
  }
  class v extends Error{
    constructor(e,t){
      super(),this.message=`Failed to load static file for page: ${e} ${t}`
      }
  }
  class y extends Error{
    constructor(){
      super(),this.code="ENOENT",this.message="Cannot find the middleware module"
      }
  }
  function k(e){
    return JSON.stringify({message:e.message,stack:e.stack})
    }
  },33525,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"warnOnce",{enumerable:!0,get:function(){
    return r
    }});
  let r=e=>{
    }
  },95057,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0});
  var r={formatUrl:function(){
    return s
    },formatWithValidation:function(){
    return c
    },urlObjectKeys:function(){
    return l
    }};
  for(
  var i
   in r)
  Object.defineProperty(a,i,{enumerable:!0,get:r[i]});
  let n=e.r(90809)._(e.r(98183)),o=/https?|ftp|gopher|file/;
  function s(e){
    let{auth:t,hostname:a}=e,r=e.protocol||"",i=e.pathname||"",s=e.hash||"",l=e.query||"",c=!1;
    t=t?encodeURIComponent(t).replace(/%3A/i,":")+"@":"",e.host?c=t+e.host:a&&(c=t+(~a.indexOf(":")?`[${a}]`:a),e.port&&(c+=":"+e.port)),l&&"object"==typeof l&&(l=String(n.urlQueryToSearchParams(l)));
    let d=e.search||l&&`?${l}`||"";
    return r&&!r.endsWith(":")&&(r+=":"),e.slashes||(!r||o.test(r))&&!1!==c?(c="//"+(c||""),i&&"/"!==i[0]&&(i="/"+i)):c||(c=""),s&&"#"!==s[0]&&(s="#"+s),d&&"?"!==d[0]&&(d="?"+d),i=i.replace(/[?#]/g,encodeURIComponent),d=d.replace("#","%23"),`${r}${c}${i}${d}${s}`
    }
  let l=["auth","hash","host","hostname","href","path","pathname","port","protocol","query","search","slashes"];
  function c(e){
    return s(e)
    }
  },18581,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"useMergedRef",{enumerable:!0,get:function(){
    return i
    }});
  let r=e.r(71645);
  function i(e,t){
    let a=(0,r.useRef)(null),i=(0,r.useRef)(null);
    return(0,r.useCallback)(r=>{
      if(null===r){
        let e=a.current;
        e&&(a.current=null,e());
        let t=i.current;
        t&&(i.current=null,t())
        }else 
      e&&(a.current=n(e,r)),t&&(i.current=n(t,r))
      },[e,t])
    }
  function n(e,t){
    if("function"!=typeof e)
    return e.current=t,()=>{
      e.current=null
      };
    {
      let a=e(t);
      return"function"==typeof a?a:()=>e(null)
      }
  }
  ("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)
  },73668,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"isLocalURL",{enumerable:!0,get:function(){
    return n
    }});
  let r=e.r(18967),i=e.r(52817);
  function n(e){
    if(!(0,r.isAbsoluteUrl)(e))
    return!0;
    try{
      let t=(0,r.getLocationOrigin)(),a=new URL(e,t);
      return a.origin===t&&(0,i.hasBasePath)(a.pathname)
      }catch(e){
      return!1
      }
    }
  },84508,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0}),Object.defineProperty(a,"errorOnce",{enumerable:!0,get:function(){
    return r
    }});
  let r=e=>{
    }
  },22016,(e,t,a)=>{
  "use strict";
  Object.defineProperty(a,"__esModule",{value:!0});
  var r={default:function(){
    return b
    },useLinkStatus:function(){
    return x
    }};
  for(
  var i
   in r)
  Object.defineProperty(a,i,{enumerable:!0,get:r[i]});
  let n=e.r(90809),o=e.r(43476),s=n._(e.r(71645)),l=e.r(95057),c=e.r(8372),d=e.r(18581),u=e.r(18967),p=e.r(5550);
  e.r(33525);
  let f=e.r(88540),h=e.r(91949),g=e.r(73668),m=e.r(9396);
  function b(t){
    var a,r;
    let i,n,b,[x,v]=(0,s.useOptimistic)(h.IDLE_LINK_STATUS),y=(0,s.useRef)(null),{href:k,as:_,children:A,prefetch:S=!1,passHref:C,replace:P,shallow:z,scroll:I,onClick:R,onMouseEnter:T,onTouchStart:E,legacyBehavior:L=!1,onNavigate:M,transitionTypes:O,ref:D,unstable_dynamicOnHover:F,...U}=t;
    i=A,L&&("string"==typeof i||"number"==typeof i)&&(i=(0,o.jsx)("a",{children:i}));
    let N=s.default.useContext(c.AppRouterContext),j=!1!==S,W=!1!==S?null===(r=S)||"auto"===r?m.FetchStrategy.PPR:m.FetchStrategy.Full:m.FetchStrategy.PPR,H="string"==typeof(a=_||k)?a:(0,l.formatUrl)(a);
    if(L){
      if(i?.$$typeof===Symbol.for("react.lazy"))
      throw Object.defineProperty(Error("`<Link legacyBehavior>` received a direct child that is either a Server Component, or JSX that was loaded with React.lazy(). This is not supported. Either remove legacyBehavior, or make the direct child a Client Component that renders the Link's `<a>` tag."),"__NEXT_ERROR_CODE",{value:"E863",enumerable:!1,configurable:!0});
      n=s.default.Children.only(i)
      }
    let $=L?n&&"object"==typeof n&&n.ref:D,G=s.default.useCallback(e=>(null!==N&&(y.current=(0,h.mountLinkInstance)(e,H,N,W,j,v)),()=>{
      y.current&&((0,h.unmountLinkForCurrentNavigation)(y.current),y.current=null),(0,h.unmountPrefetchableInstance)(e)
      }),[j,H,N,W,v]),B={ref:(0,d.useMergedRef)(G,$),onClick(t){
      L||"function"!=typeof R||R(t),L&&n.props&&"function"==typeof n.props.onClick&&n.props.onClick(t),!N||t.defaultPrevented||function(t,a,r,i,n,o,l){
        if("u">typeof window){
          let c,{nodeName:d}=t.currentTarget;
          if("A"===d.toUpperCase()&&((c=t.currentTarget.getAttribute("target"))&&"_self"!==c||t.metaKey||t.ctrlKey||t.shiftKey||t.altKey||t.nativeEvent&&2===t.nativeEvent.which)||t.currentTarget.hasAttribute("download"))
          return;
          if(!(0,g.isLocalURL)(a)){
            i&&(t.preventDefault(),location.replace(a));
            return
            }
          if(t.preventDefault(),o){
            let e=!1;
            if(o({preventDefault:()=>{
              e=!0
              }}),e)
            return
            }
          let{dispatchNavigateAction:u}=e.r(99781);
          s.default.startTransition(()=>{
            u(a,i?"replace":"push",!1===n?f.ScrollBehavior.NoScroll:f.ScrollBehavior.Default,r.current,l)
            })
          }
        }(t,H,y,P,I,M,O)
      },onMouseEnter(e){
      L||"function"!=typeof T||T(e),L&&n.props&&"function"==typeof n.props.onMouseEnter&&n.props.onMouseEnter(e),N&&j&&(0,h.onNavigationIntent)(e.currentTarget,!0===F)
      },onTouchStart:function(e){
      L||"function"!=typeof E||E(e),L&&n.props&&"function"==typeof n.props.onTouchStart&&n.props.onTouchStart(e),N&&j&&(0,h.onNavigationIntent)(e.currentTarget,!0===F)
      }};
    return(0,u.isAbsoluteUrl)(H)?B.href=H:L&&!C&&("a"!==n.type||"href"in n.props)||(B.href=(0,p.addBasePath)(H)),b=L?s.default.cloneElement(n,B):(0,o.jsx)("a",{...U,...B,children:i}),(0,o.jsx)(w.Provider,{value:x,children:b})
    }
  e.r(84508);
  let w=(0,s.createContext)(h.IDLE_LINK_STATUS),x=()=>(0,s.useContext)(w);
  ("function"==typeof a.default||"object"==typeof a.default&&null!==a.default)&&void 0===a.default.__esModule&&(Object.defineProperty(a.default,"__esModule",{value:!0}),Object.assign(a.default,a),t.exports=a.default)
  },96661,e=>{
  "use strict";
  e.s(["mergeClasses",0,(...e)=>e.filter((e,t,a)=>!!e&&""!==e.trim()&&a.indexOf(e)===t).join(" ").trim()])
  },71987,88973,e=>{
  "use strict";
  e.s(["default",0,{xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"}],71987),e.s(["hasA11yProp",0,e=>{
    for(
    let t
     in e)
    if(t.startsWith("aria-")||"role"===t||"title"===t)
    return!0;
    return!1
    }],88973)
  },5014,e=>{
  "use strict";
  var t=e.i(71645),a=e.i(71987),r=e.i(88973),i=e.i(96661);
  let n=(0,t.createContext)({}),o=(0,t.forwardRef)(({color:e,size:o,strokeWidth:s,absoluteStrokeWidth:l,className:c="",children:d,iconNode:u,...p},f)=>{
    let{size:h=24,strokeWidth:g=2,absoluteStrokeWidth:m=!1,color:b="currentColor",className:w=""}=(0,t.useContext)(n)??{},x=l??m?24*Number(s??g)/Number(o??h):s??g;
    return(0,t.createElement)("svg",{ref:f,...a.default,width:o??h??a.default.width,height:o??h??a.default.height,stroke:e??b,strokeWidth:x,className:(0,i.mergeClasses)("lucide",w,c),...!d&&!(0,r.hasA11yProp)(p)&&{"aria-hidden":"true"},...p},[...u.map(([e,a])=>(0,t.createElement)(e,a)),...Array.isArray(d)?d:[d]])
    });
  e.s(["default",0,o],5014)
  },8155,e=>{
  "use strict";
  let t=e=>{
    let t,a=new Set,r=(e,r)=>{
      let i="function"==typeof e?e(t):e;
      if(!Object.is(i,t)){
        let e=t;
        t=(null!=r?r:"object"!=typeof i||null===i)?i:Object.assign({},t,i),a.forEach(a=>a(t,e))
        }
      },i=()=>t,n={setState:r,getState:i,getInitialState:()=>o,subscribe:e=>(a.add(e),()=>a.delete(e))},o=t=e(r,i,n);
    return n
    };
  e.s(["createStore",0,e=>e?t(e):t])
  },56420,e=>{
  "use strict";
  var t=e.i(71645),a=e.i(96661);
  let r=e=>{
    let t=e.replace(/^([A-Z])|[\s-_]+(\w)/g,(e,t,a)=>a?a.toUpperCase():t.toLowerCase());
    return t.charAt(0).toUpperCase()+t.slice(1)
    };
  var i=e.i(5014);
  e.s(["default",0,(e,n)=>{
    let o=(0,t.forwardRef)(({className:o,...s},l)=>(0,t.createElement)(i.default,{ref:l,iconNode:n,className:(0,a.mergeClasses)(`lucide-${r(e).replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase()}`,`lucide-${e}`,o),...s}));
    return o.displayName=r(e),o
    }],56420)
  },12637,e=>{
  "use strict";
  var t=e.i(47167);
  let a=t.default.env.NEXT_PUBLIC_WEBAPP_URL??"https://app.getartcraft.com/",r=t.default.env.NEXT_PUBLIC_MEDIA_BASE??"";
  e.s(["SOCIAL_LINKS",0,{DISCORD:"https://discord.gg/artcraft",YOUTUBE:"https://www.youtube.com/@OfficialArtCraftStudios",TIKTOK:"https://www.tiktok.com/@artcraft.studios",GITHUB:"https://github.com/storytold/artcraft",INSTAGRAM:"https://www.instagram.com/get_artcraft",LINKEDIN:"https://www.linkedin.com/company/artcraft-ai",REDDIT:"https://www.reddit.com/r/ArtCraftAI/"},"WEBAPP_URL",0,a,"cdnMediaUrl",0,function(e){
    return`/cdn${e.startsWith("/")?e:`/${e}`}`
    },"mediaUrl",0,function(e){
    return`${r}${e.startsWith("/")?e:`/${e}`}`
    },"webappUrl",0,function(e){
    return`${a}${e.replace(/^\//,"")}`
    }])
  },8164,e=>{
  "use strict";
  var t=e.i(43476);
  e.s(["DiscordIcon",0,function({className:e}){
    return(0,t.jsx)("svg",{viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":!0,className:e,children:(0,t.jsx)("path",{d:"M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0 12.64 12.64 0 0 0-.617-1.25.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057 19.9 19.9 0 0 0 5.993 3.03.078.078 0 0 0 .084-.028c.462-.63.874-1.295 1.226-1.994a.076.076 0 0 0-.041-.106 13.107 13.107 0 0 1-1.872-.892.077.077 0 0 1-.008-.128 10.2 10.2 0 0 0 .372-.292.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127 12.299 12.299 0 0 1-1.873.892.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028 19.839 19.839 0 0 0 6.002-3.03.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.956-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419 0-1.333.955-2.419 2.157-2.419 1.21 0 2.176 1.096 2.157 2.42 0 1.333-.946 2.418-2.157 2.418z"})})
    },"WindowsIcon",0,function({className:e}){
    return(0,t.jsx)("svg",{viewBox:"0 0 24 24",fill:"currentColor","aria-hidden":!0,className:e,children:(0,t.jsx)("path",{d:"M0 3.449L9.75 2.1v9.451H0m10.949-9.602L24 0v11.4H10.949M0 12.6h9.75v9.451L0 20.699M10.949 12.6H24V24l-12.9-1.801"})})
    }])
  },5947,(e,t,a)=>{
  t.exports=JSON.parse('{"releases":{"craft-launcher":{"tag":"v0.5.1","version":"0.5.1","files":["SHA256SUMS.txt","artcraft-launcher-0.5.1-freebsd-x86_64.tar.gz","artcraft-launcher-0.5.1-linux-aarch64.AppImage","artcraft-launcher-0.5.1-linux-aarch64.AppImage.zsync","artcraft-launcher-0.5.1-linux-aarch64.deb","artcraft-launcher-0.5.1-linux-aarch64.flatpak","artcraft-launcher-0.5.1-linux-aarch64.rpm","artcraft-launcher-0.5.1-linux-aarch64.tar.gz","artcraft-launcher-0.5.1-linux-riscv64.deb","artcraft-launcher-0.5.1-linux-riscv64.rpm","artcraft-launcher-0.5.1-linux-riscv64.tar.gz","artcraft-launcher-0.5.1-linux-x86_64.AppImage","artcraft-launcher-0.5.1-linux-x86_64.AppImage.zsync","artcraft-launcher-0.5.1-linux-x86_64.deb","artcraft-launcher-0.5.1-linux-x86_64.flatpak","artcraft-launcher-0.5.1-linux-x86_64.rpm","artcraft-launcher-0.5.1-linux-x86_64.tar.gz","artcraft-launcher-0.5.1-macos-universal.dmg","artcraft-launcher-0.5.1-windows-arm64-portable.zip","artcraft-launcher-0.5.1-windows-arm64.msi","artcraft-launcher-0.5.1-windows-x64-portable.zip","artcraft-launcher-0.5.1-windows-x64.msi","artcraft-launcher-0.5.1-windows-x86-portable.zip","artcraft-launcher-0.5.1-windows-x86.msi","artcraft-launcher-web-0.5.1.zip"]},"photocraft":{"tag":"v0.10.0","version":"0.10.0","files":["SHA256SUMS.txt","photocraft-0.10.0-freebsd-x86_64.tar.gz","photocraft-0.10.0-linux-aarch64.AppImage","photocraft-0.10.0-linux-aarch64.AppImage.zsync","photocraft-0.10.0-linux-aarch64.deb","photocraft-0.10.0-linux-aarch64.flatpak","photocraft-0.10.0-linux-aarch64.rpm","photocraft-0.10.0-linux-aarch64.tar.gz","photocraft-0.10.0-linux-riscv64.deb","photocraft-0.10.0-linux-riscv64.rpm","photocraft-0.10.0-linux-riscv64.tar.gz","photocraft-0.10.0-linux-x86_64.AppImage","photocraft-0.10.0-linux-x86_64.AppImage.zsync","photocraft-0.10.0-linux-x86_64.deb","photocraft-0.10.0-linux-x86_64.flatpak","photocraft-0.10.0-linux-x86_64.rpm","photocraft-0.10.0-linux-x86_64.tar.gz","photocraft-0.10.0-macos-universal.dmg","photocraft-0.10.0-windows-arm64-portable.zip","photocraft-0.10.0-windows-arm64.msi","photocraft-0.10.0-windows-x64-portable.zip","photocraft-0.10.0-windows-x64.msi","photocraft-0.10.0-windows-x86-portable.zip","photocraft-0.10.0-windows-x86.msi","photocraft-cli-0.10.0-macos-universal.zip","photocraft-web-0.10.0.zip"]},"vectorcraft":{"tag":"v0.13.1","version":"0.13.1","files":["SHA256SUMS.txt","vectorcraft-0.13.1-freebsd-x86_64.tar.gz","vectorcraft-0.13.1-linux-aarch64.AppImage","vectorcraft-0.13.1-linux-aarch64.AppImage.zsync","vectorcraft-0.13.1-linux-aarch64.deb","vectorcraft-0.13.1-linux-aarch64.flatpak","vectorcraft-0.13.1-linux-aarch64.rpm","vectorcraft-0.13.1-linux-aarch64.tar.gz","vectorcraft-0.13.1-linux-riscv64.deb","vectorcraft-0.13.1-linux-riscv64.rpm","vectorcraft-0.13.1-linux-riscv64.tar.gz","vectorcraft-0.13.1-linux-x86_64.AppImage","vectorcraft-0.13.1-linux-x86_64.AppImage.zsync","vectorcraft-0.13.1-linux-x86_64.deb","vectorcraft-0.13.1-linux-x86_64.flatpak","vectorcraft-0.13.1-linux-x86_64.rpm","vectorcraft-0.13.1-linux-x86_64.tar.gz","vectorcraft-0.13.1-macos-universal.dmg","vectorcraft-0.13.1-windows-arm64-portable.zip","vectorcraft-0.13.1-windows-arm64.msi","vectorcraft-0.13.1-windows-x64-portable.zip","vectorcraft-0.13.1-windows-x64.msi","vectorcraft-0.13.1-windows-x86-portable.zip","vectorcraft-0.13.1-windows-x86.msi","vectorcraft-cli-0.13.1-macos-universal.zip","vectorcraft-web-0.13.1.zip"]},"filmcraft":{"tag":"v0.9.0","version":"0.9.0","files":["SHA256SUMS.txt","filmcraft-0.9.0-freebsd-x86_64.tar.gz","filmcraft-0.9.0-linux-aarch64.AppImage","filmcraft-0.9.0-linux-aarch64.AppImage.zsync","filmcraft-0.9.0-linux-aarch64.deb","filmcraft-0.9.0-linux-aarch64.flatpak","filmcraft-0.9.0-linux-aarch64.rpm","filmcraft-0.9.0-linux-aarch64.tar.gz","filmcraft-0.9.0-linux-riscv64.deb","filmcraft-0.9.0-linux-riscv64.rpm","filmcraft-0.9.0-linux-riscv64.tar.gz","filmcraft-0.9.0-linux-x86_64.AppImage","filmcraft-0.9.0-linux-x86_64.AppImage.zsync","filmcraft-0.9.0-linux-x86_64.deb","filmcraft-0.9.0-linux-x86_64.flatpak","filmcraft-0.9.0-linux-x86_64.rpm","filmcraft-0.9.0-linux-x86_64.tar.gz","filmcraft-0.9.0-macos-universal.dmg","filmcraft-0.9.0-windows-arm64-portable.zip","filmcraft-0.9.0-windows-arm64.msi","filmcraft-0.9.0-windows-x64-portable.zip","filmcraft-0.9.0-windows-x64.msi","filmcraft-0.9.0-windows-x86-portable.zip","filmcraft-0.9.0-windows-x86.msi","filmcraft-cli-0.9.0-macos-universal.zip","filmcraft-web-0.9.0.zip"]},"lightcraft":{"tag":"v0.9.1","version":"0.9.1","files":["SHA256SUMS.txt","lightcraft-0.9.1-freebsd-x86_64.tar.gz","lightcraft-0.9.1-linux-aarch64.AppImage","lightcraft-0.9.1-linux-aarch64.AppImage.zsync","lightcraft-0.9.1-linux-aarch64.deb","lightcraft-0.9.1-linux-aarch64.flatpak","lightcraft-0.9.1-linux-aarch64.rpm","lightcraft-0.9.1-linux-aarch64.tar.gz","lightcraft-0.9.1-linux-riscv64.deb","lightcraft-0.9.1-linux-riscv64.rpm","lightcraft-0.9.1-linux-riscv64.tar.gz","lightcraft-0.9.1-linux-x86_64.AppImage","lightcraft-0.9.1-linux-x86_64.AppImage.zsync","lightcraft-0.9.1-linux-x86_64.deb","lightcraft-0.9.1-linux-x86_64.flatpak","lightcraft-0.9.1-linux-x86_64.rpm","lightcraft-0.9.1-linux-x86_64.tar.gz","lightcraft-0.9.1-macos-universal.dmg","lightcraft-0.9.1-windows-arm64-portable.zip","lightcraft-0.9.1-windows-arm64.msi","lightcraft-0.9.1-windows-x64-portable.zip","lightcraft-0.9.1-windows-x64.msi","lightcraft-0.9.1-windows-x86-portable.zip","lightcraft-0.9.1-windows-x86.msi","lightcraft-cli-0.9.1-macos-universal.zip","lightcraft-web-0.9.1.zip"]},"pdfcraft":{"tag":"v0.9.0","version":"0.9.0","files":["SHA256SUMS.txt","pdfcraft-0.9.0-freebsd-x86_64.tar.gz","pdfcraft-0.9.0-linux-aarch64.AppImage","pdfcraft-0.9.0-linux-aarch64.AppImage.zsync","pdfcraft-0.9.0-linux-aarch64.deb","pdfcraft-0.9.0-linux-aarch64.flatpak","pdfcraft-0.9.0-linux-aarch64.rpm","pdfcraft-0.9.0-linux-aarch64.tar.gz","pdfcraft-0.9.0-linux-riscv64.deb","pdfcraft-0.9.0-linux-riscv64.rpm","pdfcraft-0.9.0-linux-riscv64.tar.gz","pdfcraft-0.9.0-linux-x86_64.AppImage","pdfcraft-0.9.0-linux-x86_64.AppImage.zsync","pdfcraft-0.9.0-linux-x86_64.deb","pdfcraft-0.9.0-linux-x86_64.flatpak","pdfcraft-0.9.0-linux-x86_64.rpm","pdfcraft-0.9.0-linux-x86_64.tar.gz","pdfcraft-0.9.0-macos-universal.dmg","pdfcraft-0.9.0-windows-arm64-portable.zip","pdfcraft-0.9.0-windows-arm64.msi","pdfcraft-0.9.0-windows-x64-portable.zip","pdfcraft-0.9.0-windows-x64.msi","pdfcraft-0.9.0-windows-x86-portable.zip","pdfcraft-0.9.0-windows-x86.msi","pdfcraft-cli-0.9.0-linux-aarch64.tar.gz","pdfcraft-cli-0.9.0-linux-x86_64.tar.gz","pdfcraft-cli-0.9.0-macos-universal.zip","pdfcraft-web-0.9.0.zip"]},"effectcraft":{"tag":"v0.11.1","version":"0.11.1","files":["SHA256SUMS.txt","effectcraft-0.11.1-freebsd-x86_64.tar.gz","effectcraft-0.11.1-linux-aarch64.AppImage","effectcraft-0.11.1-linux-aarch64.AppImage.zsync","effectcraft-0.11.1-linux-aarch64.deb","effectcraft-0.11.1-linux-aarch64.flatpak","effectcraft-0.11.1-linux-aarch64.rpm","effectcraft-0.11.1-linux-aarch64.tar.gz","effectcraft-0.11.1-linux-riscv64.deb","effectcraft-0.11.1-linux-riscv64.rpm","effectcraft-0.11.1-linux-riscv64.tar.gz","effectcraft-0.11.1-linux-x86_64.AppImage","effectcraft-0.11.1-linux-x86_64.AppImage.zsync","effectcraft-0.11.1-linux-x86_64.deb","effectcraft-0.11.1-linux-x86_64.flatpak","effectcraft-0.11.1-linux-x86_64.rpm","effectcraft-0.11.1-linux-x86_64.tar.gz","effectcraft-0.11.1-macos-universal.dmg","effectcraft-0.11.1-windows-arm64-portable.zip","effectcraft-0.11.1-windows-arm64.msi","effectcraft-0.11.1-windows-x64-portable.zip","effectcraft-0.11.1-windows-x64.msi","effectcraft-0.11.1-windows-x86-portable.zip","effectcraft-0.11.1-windows-x86.msi","effectcraft-cli-0.11.1-macos-universal.zip","effectcraft-web-0.11.1.zip"]},"designcraft":{"tag":"v0.9.0","version":"0.9.0","files":["SHA256SUMS.txt","designcraft-0.9.0-freebsd-x86_64.tar.gz","designcraft-0.9.0-linux-aarch64.AppImage","designcraft-0.9.0-linux-aarch64.AppImage.zsync","designcraft-0.9.0-linux-aarch64.deb","designcraft-0.9.0-linux-aarch64.flatpak","designcraft-0.9.0-linux-aarch64.pkg.tar.zst","designcraft-0.9.0-linux-aarch64.rpm","designcraft-0.9.0-linux-aarch64.tar.gz","designcraft-0.9.0-linux-riscv64.deb","designcraft-0.9.0-linux-riscv64.rpm","designcraft-0.9.0-linux-riscv64.tar.gz","designcraft-0.9.0-linux-x86_64.AppImage","designcraft-0.9.0-linux-x86_64.AppImage.zsync","designcraft-0.9.0-linux-x86_64.deb","designcraft-0.9.0-linux-x86_64.flatpak","designcraft-0.9.0-linux-x86_64.pkg.tar.zst","designcraft-0.9.0-linux-x86_64.rpm","designcraft-0.9.0-linux-x86_64.tar.gz","designcraft-0.9.0-macos-universal.dmg","designcraft-0.9.0-windows-arm64-portable.zip","designcraft-0.9.0-windows-arm64.msi","designcraft-0.9.0-windows-x64-portable.zip","designcraft-0.9.0-windows-x64.msi","designcraft-0.9.0-windows-x86-portable.zip","designcraft-0.9.0-windows-x86.msi","designcraft-cli-0.9.0-macos-universal.zip","designcraft-web-0.9.0.zip"]},"figcraft":{"tag":"v0.7.0","version":"0.7.0","files":["SHA256SUMS.txt","figcraft-0.7.0-freebsd-x86_64.tar.gz","figcraft-0.7.0-linux-aarch64.AppImage","figcraft-0.7.0-linux-aarch64.AppImage.zsync","figcraft-0.7.0-linux-aarch64.deb","figcraft-0.7.0-linux-aarch64.flatpak","figcraft-0.7.0-linux-aarch64.rpm","figcraft-0.7.0-linux-aarch64.tar.gz","figcraft-0.7.0-linux-riscv64.deb","figcraft-0.7.0-linux-riscv64.rpm","figcraft-0.7.0-linux-riscv64.tar.gz","figcraft-0.7.0-linux-x86_64.AppImage","figcraft-0.7.0-linux-x86_64.AppImage.zsync","figcraft-0.7.0-linux-x86_64.deb","figcraft-0.7.0-linux-x86_64.flatpak","figcraft-0.7.0-linux-x86_64.rpm","figcraft-0.7.0-linux-x86_64.tar.gz","figcraft-0.7.0-macos-universal.dmg","figcraft-0.7.0-windows-arm64-portable.zip","figcraft-0.7.0-windows-arm64.msi","figcraft-0.7.0-windows-x64-portable.zip","figcraft-0.7.0-windows-x64.msi","figcraft-0.7.0-windows-x86-portable.zip","figcraft-0.7.0-windows-x86.msi","figcraft-cli-0.7.0-macos-universal.zip","figcraft-server-0.7.0-linux-aarch64.tar.gz","figcraft-server-0.7.0-linux-x86_64.tar.gz","figcraft-web-0.7.0.zip"]},"wordcraft":{"tag":"v0.8.0","version":"0.8.0","files":["SHA256SUMS.txt","wordcraft-0.8.0-freebsd-x86_64.tar.gz","wordcraft-0.8.0-linux-aarch64.AppImage","wordcraft-0.8.0-linux-aarch64.AppImage.zsync","wordcraft-0.8.0-linux-aarch64.deb","wordcraft-0.8.0-linux-aarch64.flatpak","wordcraft-0.8.0-linux-aarch64.rpm","wordcraft-0.8.0-linux-aarch64.tar.gz","wordcraft-0.8.0-linux-riscv64.deb","wordcraft-0.8.0-linux-riscv64.rpm","wordcraft-0.8.0-linux-riscv64.tar.gz","wordcraft-0.8.0-linux-x86_64.AppImage","wordcraft-0.8.0-linux-x86_64.AppImage.zsync","wordcraft-0.8.0-linux-x86_64.deb","wordcraft-0.8.0-linux-x86_64.flatpak","wordcraft-0.8.0-linux-x86_64.rpm","wordcraft-0.8.0-linux-x86_64.tar.gz","wordcraft-0.8.0-macos-universal.dmg","wordcraft-0.8.0-windows-arm64-portable.zip","wordcraft-0.8.0-windows-arm64.msi","wordcraft-0.8.0-windows-x64-portable.zip","wordcraft-0.8.0-windows-x64.msi","wordcraft-0.8.0-windows-x86-portable.zip","wordcraft-0.8.0-windows-x86.msi","wordcraft-cli-0.8.0-macos-universal.zip","wordcraft-web-0.8.0.zip"]},"soundcraft":{"tag":"v0.8.0","version":"0.8.0","files":["SHA256SUMS.txt","soundcraft-0.8.0-freebsd-x86_64.tar.gz","soundcraft-0.8.0-linux-aarch64.AppImage","soundcraft-0.8.0-linux-aarch64.AppImage.zsync","soundcraft-0.8.0-linux-aarch64.deb","soundcraft-0.8.0-linux-aarch64.flatpak","soundcraft-0.8.0-linux-aarch64.rpm","soundcraft-0.8.0-linux-aarch64.tar.gz","soundcraft-0.8.0-linux-riscv64.deb","soundcraft-0.8.0-linux-riscv64.rpm","soundcraft-0.8.0-linux-riscv64.tar.gz","soundcraft-0.8.0-linux-x86_64.AppImage","soundcraft-0.8.0-linux-x86_64.AppImage.zsync","soundcraft-0.8.0-linux-x86_64.deb","soundcraft-0.8.0-linux-x86_64.flatpak","soundcraft-0.8.0-linux-x86_64.rpm","soundcraft-0.8.0-linux-x86_64.tar.gz","soundcraft-0.8.0-macos-universal.dmg","soundcraft-0.8.0-windows-arm64-portable.zip","soundcraft-0.8.0-windows-arm64.msi","soundcraft-0.8.0-windows-x64-portable.zip","soundcraft-0.8.0-windows-x64.msi","soundcraft-0.8.0-windows-x86-portable.zip","soundcraft-0.8.0-windows-x86.msi","soundcraft-cli-0.8.0-macos-universal.zip","soundcraft-web-0.8.0.zip"]},"deckcraft":{"tag":"v0.8.0","version":"0.8.0","files":["SHA256SUMS.txt","deckcraft-0.8.0-freebsd-x86_64.tar.gz","deckcraft-0.8.0-linux-aarch64.AppImage","deckcraft-0.8.0-linux-aarch64.AppImage.zsync","deckcraft-0.8.0-linux-aarch64.deb","deckcraft-0.8.0-linux-aarch64.flatpak","deckcraft-0.8.0-linux-aarch64.rpm","deckcraft-0.8.0-linux-aarch64.tar.gz","deckcraft-0.8.0-linux-riscv64.deb","deckcraft-0.8.0-linux-riscv64.rpm","deckcraft-0.8.0-linux-riscv64.tar.gz","deckcraft-0.8.0-linux-x86_64.AppImage","deckcraft-0.8.0-linux-x86_64.AppImage.zsync","deckcraft-0.8.0-linux-x86_64.deb","deckcraft-0.8.0-linux-x86_64.flatpak","deckcraft-0.8.0-linux-x86_64.rpm","deckcraft-0.8.0-linux-x86_64.tar.gz","deckcraft-0.8.0-macos-universal.dmg","deckcraft-0.8.0-windows-arm64-portable.zip","deckcraft-0.8.0-windows-arm64.msi","deckcraft-0.8.0-windows-x64-portable.zip","deckcraft-0.8.0-windows-x64.msi","deckcraft-0.8.0-windows-x86-portable.zip","deckcraft-0.8.0-windows-x86.msi","deckcraft-cli-0.8.0-macos-universal.zip","deckcraft-web-0.8.0.zip"]},"cadcraft":{"tag":"v0.8.0","version":"0.8.0","files":["SHA256SUMS.txt","cadcraft-0.8.0-freebsd-x86_64.tar.gz","cadcraft-0.8.0-linux-aarch64.AppImage","cadcraft-0.8.0-linux-aarch64.AppImage.zsync","cadcraft-0.8.0-linux-aarch64.deb","cadcraft-0.8.0-linux-aarch64.flatpak","cadcraft-0.8.0-linux-aarch64.rpm","cadcraft-0.8.0-linux-aarch64.tar.gz","cadcraft-0.8.0-linux-riscv64.deb","cadcraft-0.8.0-linux-riscv64.rpm","cadcraft-0.8.0-linux-riscv64.tar.gz","cadcraft-0.8.0-linux-x86_64.AppImage","cadcraft-0.8.0-linux-x86_64.AppImage.zsync","cadcraft-0.8.0-linux-x86_64.deb","cadcraft-0.8.0-linux-x86_64.flatpak","cadcraft-0.8.0-linux-x86_64.rpm","cadcraft-0.8.0-linux-x86_64.tar.gz","cadcraft-0.8.0-macos-universal.dmg","cadcraft-0.8.0-windows-arm64-portable.zip","cadcraft-0.8.0-windows-arm64.msi","cadcraft-0.8.0-windows-x64-portable.zip","cadcraft-0.8.0-windows-x64.msi","cadcraft-0.8.0-windows-x86-portable.zip","cadcraft-0.8.0-windows-x86.msi","cadcraft-cli-0.8.0-macos-universal.zip","cadcraft-web-0.8.0.zip"]},"gridcraft":{"tag":"v0.8.0","version":"0.8.0","files":["SHA256SUMS.txt","gridcraft-0.8.0-freebsd-x86_64.tar.gz","gridcraft-0.8.0-linux-aarch64.AppImage","gridcraft-0.8.0-linux-aarch64.AppImage.zsync","gridcraft-0.8.0-linux-aarch64.deb","gridcraft-0.8.0-linux-aarch64.flatpak","gridcraft-0.8.0-linux-aarch64.rpm","gridcraft-0.8.0-linux-aarch64.tar.gz","gridcraft-0.8.0-linux-riscv64.deb","gridcraft-0.8.0-linux-riscv64.rpm","gridcraft-0.8.0-linux-riscv64.tar.gz","gridcraft-0.8.0-linux-x86_64.AppImage","gridcraft-0.8.0-linux-x86_64.AppImage.zsync","gridcraft-0.8.0-linux-x86_64.deb","gridcraft-0.8.0-linux-x86_64.flatpak","gridcraft-0.8.0-linux-x86_64.rpm","gridcraft-0.8.0-linux-x86_64.tar.gz","gridcraft-0.8.0-macos-universal.dmg","gridcraft-0.8.0-windows-arm64-portable.zip","gridcraft-0.8.0-windows-arm64.msi","gridcraft-0.8.0-windows-x64-portable.zip","gridcraft-0.8.0-windows-x64.msi","gridcraft-0.8.0-windows-x86-portable.zip","gridcraft-0.8.0-windows-x86.msi","gridcraft-cli-0.8.0-macos-universal.zip","gridcraft-web-0.8.0.zip"]}}}')
  },75001,76964,e=>{
  "use strict";
  var t,a=e.i(5947);
  let r=[{file:"{slug}-{version}-macos-universal.dmg",group:"macOS",label:"Disk image (Universal)",description:"Apple silicon and Intel Macs.",arch:"universal",recommended:!0},{file:"{slug}-cli-{version}-macos-universal.zip",group:"macOS",label:"Command-line tool (Universal)",description:"The headless CLI for scripts and agents.",arch:"universal"},{file:"{slug}-{version}-windows-x64.msi",group:"Windows",label:"Installer (64-bit)",description:"Most Windows 10 and 11 PCs.",arch:"x64",recommended:!0},{file:"{slug}-{version}-windows-x64-portable.zip",group:"Windows",label:"Portable (64-bit)",description:"Unzip and run, no install.",arch:"x64"},{file:"{slug}-{version}-windows-x86.msi",group:"Windows",label:"Installer (32-bit)",description:"Older 32-bit Windows.",arch:"x86"},{file:"{slug}-{version}-windows-x86-portable.zip",group:"Windows",label:"Portable (32-bit)",description:"Unzip and run on 32-bit Windows.",arch:"x86"},{file:"{slug}-{version}-windows-arm64.msi",group:"Windows",label:"Installer (ARM64)",description:"Windows 11 on ARM laptops.",arch:"aarch64"},{file:"{slug}-{version}-windows-arm64-portable.zip",group:"Windows",label:"Portable (ARM64)",description:"Unzip and run on Windows on ARM.",arch:"aarch64"},{file:"{slug}-{version}-linux-x86_64.flatpak",group:"Linux",label:"Flatpak (x86_64)",description:"Sandboxed. Install with flatpak install --user.",arch:"x86_64",recommended:!0},{file:"{slug}-{version}-linux-x86_64.AppImage",group:"Linux",label:"AppImage (x86_64)",description:"Any distro. Mark it executable and run.",arch:"x86_64"},{file:"{slug}-{version}-linux-x86_64.deb",group:"Linux",label:"Debian package (x86_64)",description:"Debian, Ubuntu and derivatives.",arch:"x86_64"},{file:"{slug}-{version}-linux-x86_64.rpm",group:"Linux",label:"RPM package (x86_64)",description:"Fedora, RHEL and openSUSE.",arch:"x86_64"},{file:"{slug}-{version}-linux-x86_64.tar.gz",group:"Linux",label:"Tarball (x86_64)",description:"Plain binaries to unpack anywhere.",arch:"x86_64"},{file:"{slug}-{version}-linux-aarch64.flatpak",group:"Linux",label:"Flatpak (ARM64)",description:"Sandboxed, on 64-bit ARM.",arch:"aarch64",recommended:!0},{file:"{slug}-{version}-linux-aarch64.AppImage",group:"Linux",label:"AppImage (ARM64)",description:"Any distro on 64-bit ARM.",arch:"aarch64"},{file:"{slug}-{version}-linux-aarch64.deb",group:"Linux",label:"Debian package (ARM64)",description:"Debian, Ubuntu and derivatives on ARM.",arch:"aarch64"},{file:"{slug}-{version}-linux-aarch64.rpm",group:"Linux",label:"RPM package (ARM64)",description:"Fedora, RHEL and openSUSE on ARM.",arch:"aarch64"},{file:"{slug}-{version}-linux-aarch64.tar.gz",group:"Linux",label:"Tarball (ARM64)",description:"Plain binaries for 64-bit ARM.",arch:"aarch64"},{file:"{slug}-{version}-freebsd-x86_64.tar.gz",group:"Other",label:"FreeBSD (x86_64)",description:"Plain binaries for FreeBSD 14."},{file:"{slug}-web-{version}.zip",group:"Other",label:"Web build",description:"The WebAssembly app, to host yourself."},{file:"SHA256SUMS.txt",group:"Other",label:"SHA-256 checksums",description:"Verify any download above."}],i=a.default.releases;
  function n(e,t=r){
    let a=i[e];
    return a?{version:a.version,tag:a.tag,assets:t,files:a.files}:null
    }
  let o=n("craft-launcher",r.filter(e=>!e.file.startsWith("{slug}-cli-")));
  n("photocraft"),n("vectorcraft"),n("filmcraft"),n("lightcraft"),n("pdfcraft"),n("effectcraft"),n("designcraft"),n("figcraft"),n("wordcraft"),n("soundcraft"),n("deckcraft"),n("cadcraft"),n("gridcraft"),e.s(["CRAFT_DESKTOP_PLATFORMS",0,["macOS","Windows","Linux"],"CRAFT_LAUNCHER_RELEASE",0,o],76964);
  var s=e.i(12637);
  let l=[{slug:"photocraft",prefix:"Photo",category:"Image editor",status:"Early alpha",headline:["The image editor you already ","know"," how to use."],pitch:"The open-source image editor you already know how to use.",lede:"Layers, masks, adjustment layers, layer styles, type, vectors and brushes in a native app written entirely in Rust. Open source, offline, and yours.",schemaCategory:"DesignApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"Familiar by design",body:"The menus, shortcuts, panels and tools your hands already know. Productive on day one, no retraining."},{title:"Native GPU canvas",body:"Renders on Metal, Vulkan, DirectX 12 and WebGPU. No Electron and no web view, just a fast native compositor."},{title:"Real layered files",body:"Opens and saves layered PSD and PSB documents. 134 of 135 real-world test files round-trip byte for byte."},{title:"Non-destructive editing",body:"16 adjustment layers, 70+ live-preview filters, smart objects with smart filters, and a full set of layer styles."},{title:"On-device selection",body:"Select subjects and objects and refine masks with tools that run on your machine, not someone else's server."},{title:"Serious color",body:"8, 16 and 32-bit documents in RGB, CMYK, Lab and Grayscale, with ICC color management and soft proofing."}],shots:[{file:"hero.webp",source:"photocraft-demo.jpg",caption:"Curves and type layers — The Great Wave",alt:"PhotoCraft editing The Great Wave off Kanagawa with a Curves adjustment and type layers in the Layers panel"},{file:"adjustments.webp",source:"photocraft-adjustments.jpg",caption:"Levels with a live histogram",alt:"PhotoCraft applying a Levels adjustment layer to Impression, Sunrise with the histogram panel open"},{file:"layer-styles.webp",source:"photocraft-layer-styles.jpg",caption:"Layer styles on live type",alt:"PhotoCraft's Layer Style dialog adding an outer glow and stroke to the word Earthrise"},{file:"masks.webp",source:"photocraft-masks.jpg",caption:"Selections and masked adjustments",alt:"PhotoCraft with an elliptical selection and a Hue/Saturation adjustment on Girl with a Pearl Earring"}]},{slug:"vectorcraft",prefix:"Vector",category:"Vector illustration",status:"In development",headline:["Vector illustration, ","reimagined"," in pure Rust."],pitch:"Fast, open-source vector illustration, reimagined in pure Rust.",lede:"The pen, panels and shortcuts working illustrators expect, in a native app that keeps up with you. Open source, and in your browser too.",schemaCategory:"DesignApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"The workflow you know",body:"Pen, direct selection, shape booleans, snapping guides and an appearance panel, laid out the way you expect."},{title:"Genuinely fast",body:"20,000 shapes render in about 27 ms at retina resolution, and the interface runs at 120 fps."},{title:"Booleans that never fail",body:"Exact curve booleans mean no more “cannot perform operation”. Unlimited undo means no more fear."},{title:"Live, editable effects",body:"Blends, envelope distort, gradient mesh, live radial, grid and mirror repeats, glows and drop shadows — all still editable."},{title:"Image tracing",body:"Turn raster images into clean vector paths with 12 tracing presets."},{title:"Open formats",body:"Native JSON documents, SVG and PDF import and export, PNG, JPEG and WebP output, and multi-size export for screens."}],shots:[{file:"hero.webp",source:"shot-1-neon.png",caption:"Neon Drive — made in VectorCraft",alt:"VectorCraft editing the Neon Drive poster: the title is selected, the Appearance panel lists its live outer glow, and the Properties panel shows its character settings"},{file:"ribbons.webp",source:"shot-2-ribbons.png",caption:"Live blends and layers",alt:"VectorCraft showing three live blend ribbons clipped to the artboard, one selected with its key paths, and the Layers panel listing the clip group and blends"},{file:"bezier.webp",source:"shot-4-bezier.png",caption:"Pen and direct selection",alt:"VectorCraft direct-selecting the anchor points and bezier handles of a crescent moon, with the contextual task bar below it"},{file:"revolve.webp",source:"shot-6-revolve.png",caption:"3D revolve with vector shading",alt:"VectorCraft with a still life of a vase, a bowl, a sphere and a bottle made with 3D revolve; the vase is selected and the Revolve dialog shows its rotation, cap and view settings beside the rotation gizmo"},{file:"dimensions.webp",source:"shot-7-dimensions.png",caption:"Dimensions that follow the art",alt:"VectorCraft in its light theme with a bracket drawing measured by linear, angular, diameter and radius dimensions, the Dimension tool active and the Properties panel showing the selected dimension's units, precision and style"},{file:"perspective.webp",source:"shot-5-perspective.png",caption:"Perspective grid, still editable",alt:"VectorCraft with two lit building facades drawn on the left and right planes of a two-point perspective grid at sunset"},{file:"sheet.webp",source:"shot-3-sheet.png",caption:"Booleans, mesh, repeat and envelope",alt:"VectorCraft in its light theme with four artboards: shape booleans, a gradient mesh, a live radial repeat and an envelope distort"}],demo:{src:(0,s.cdnMediaUrl)("/videos/vectorcraft-mcp-anime-film.mp4"),poster:"mcp-poster.webp",label:"MCP server",headline:["Describe it. Your agent ","draws"," it."],lede:"Every menu item, tool, panel and dialog is a command, and VectorCraft's MCP server hands all of them to your AI agent. Ask for a piece and watch it drawn live as real, editable vector art.",caption:"An agent drawing a poster over MCP",alt:"A prompt for an anime movie poster of a night train under a huge moon is sent to an AI agent, which draws it live in VectorCraft through its MCP server while the tool calls scroll beside the canvas, ending on the VectorCraft end card."}},{slug:"filmcraft",prefix:"Film",category:"Video editor",status:"In development",headline:["Professional video editing, ","rebuilt"," from scratch."],pitch:"Professional, open-source video editing, rebuilt from scratch in Rust.",lede:"Source and program monitors, a real timeline and every trim mode, in a native editor written in pure Rust — down to its own codecs.",schemaCategory:"MultimediaApplication",platforms:["macOS","Windows","Linux"],rustVersion:"1.95",features:[{title:"A timeline you already know",body:"Source and program monitors, three-point editing, every trim mode, and J/K/L dynamic trimming."},{title:"Frame-exact time",body:"An integer timebase keeps 23.976 and 29.97 drop-frame exact. No drift, no rounding, no mystery frames."},{title:"Its own codecs",body:"No FFmpeg inside. Native H.264, HEVC, ProRes, VP9, AAC and Opus, with bit-exact decoders."},{title:"Color grading",body:"Curves, color wheels, HSL secondaries, LUTs, HDR and log workflows, plus scopes to check your work."},{title:"Effects and keyframes",body:"About 55 video effects and 30 transitions, keyframes with value and velocity graphs, and a linear-light GPU compositor."},{title:"Broadcast-ready audio",body:"EBU R128 loudness meters, a mixer with automation, and native DSP effects."}],shots:[{file:"color.webp",source:"filmcraft-color.png",caption:"Scopes and timeline — Charade (1963)",alt:"FilmCraft with video scopes, the program monitor showing Charade (1963), and a multi-track timeline"},{file:"hero.webp",source:"filmcraft-hero.png",caption:"Effect controls — Night of the Living Dead (1968)",alt:"FilmCraft's effect controls and timeline editing Night of the Living Dead (1968)"},{file:"keyframes.webp",source:"filmcraft-keyframes.png",caption:"Keyframes with value and velocity graphs",alt:"FilmCraft keyframing scale with value and velocity graphs on a title shot"},{file:"export.webp",source:"filmcraft-export.png",caption:"Export with destination presets",alt:"FilmCraft export screen with H.264 settings and destination presets"}]},{slug:"lightcraft",prefix:"Light",category:"Photo library & raw developer",status:"In development",headline:["Your photos. Your pixels. Your ","machine","."],pitch:"An open-source photo library and raw developer that runs on your machine.",lede:"A fast photo library and non-destructive raw developer, written from scratch in pure Rust. No account, no cloud, no telemetry, no subscription.",schemaCategory:"MultimediaApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"Non-destructive by design",body:"A scene-referred, wide-gamut, 32-bit float pipeline. Your originals are never touched."},{title:"Every control you reach for",body:"Light, color, effects, tone curve, an 8-band color mixer, 3-way color grading wheels and 18 built-in presets."},{title:"Precise masking",body:"Brush, linear and radial gradients, luminance and color ranges, plus sky, subject and background masks."},{title:"Native raw decoding",body:"Pure-Rust decoders for DNG, CR2, ARW, NEF, RAF (including X-Trans), RW2, PEF and ORF, with more on the way."},{title:"A library that keeps up",body:"Albums, ratings, flags, field search and virtualized grids built for big catalogs."},{title:"Instant feedback",body:"The GPU develop pipeline updates a 24 MP raw in about 4 ms per slider move."}],shots:[{file:"hero.webp",source:"hero-tetons.jpg",caption:"Develop — The Tetons and the Snake River",alt:"LightCraft developing Ansel Adams' The Tetons and the Snake River with light and effects sliders"},{file:"grading.webp",source:"grading-migrant-mother.jpg",caption:"Color grading wheels — Migrant Mother",alt:"LightCraft color grading wheels applied to Dorothea Lange's Migrant Mother"},{file:"masking.webp",source:"masking.jpg",caption:"Sky and radial gradient masks",alt:"LightCraft masking panel with a radial gradient mask warming a sunset sky"},{file:"library.webp",source:"grid-demo.jpg",caption:"Library with albums and ratings",alt:"LightCraft library grid with albums, ratings and the develop panel"}]},{slug:"pdfcraft",prefix:"Pdf",category:"PDF workbench",status:"Early alpha",headline:["The ","open-source"," PDF workbench."],pitch:"The open-source PDF workbench: read, organize, combine, split and secure.",lede:"Read, organize, combine, split and secure PDFs in a fast, native app written in Rust from the ground up. No account, no telemetry, no cloud.",schemaCategory:"BusinessApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"Faithful rendering",body:"World scripts, vertical Japanese, color emoji and transparency. Zero crashes across a 983-file test corpus."},{title:"Search as you type",body:"Instant find, and text selection that follows the document's real reading order."},{title:"Organize like cards",body:"Rotate, delete, insert and reorder pages, with deep undo behind every change."},{title:"Combine, extract, split",body:"Assemble and break apart documents while keeping links, form fields, layers and bookmarks intact."},{title:"Fearless saves",body:"Incremental, atomic saves with autosave and crash recovery."},{title:"Built-in security",body:"Opens everything from RC4 to AES-256 encryption and honors author permissions."}],shots:[{file:"hero.webp",source:"pdfcraft-viewer.png",caption:"Viewer with threaded comments",alt:"PdfCraft showing a showcase PDF cover with the All tools panel and threaded comments"},{file:"organize.webp",source:"pdfcraft-organize.png",caption:"Organize pages like cards",alt:"PdfCraft page organizer with three pages selected and the page tools in the toolbar above"},{file:"palette.webp",source:"pdfcraft-palette.png",caption:"A command palette for every tool",alt:"PdfCraft command palette searching for page and listing the page tools"},{file:"twoup.webp",source:"pdfcraft-twoup.png",caption:"Two-up Read mode, dark theme",alt:"PdfCraft two-up Read mode in the dark theme showing typeset specimen pages"}]},{slug:"effectcraft",prefix:"Effect",category:"Motion graphics & VFX",status:"In development",headline:["Motion graphics and visual ","effects",", in pure Rust."],pitch:"Open-source motion graphics and visual effects, built in pure Rust.",lede:"Compositions, layers, keyframes, 259 effects, expressions, 3D cameras and lights, and a render queue in a native compositor written in pure Rust. Young, moving fast, and already usable.",schemaCategory:"MultimediaApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.95",features:[{title:"Animate the way you know",body:"Familiar panels and keyframes: linear, bezier, hold and eased keys, roving keys, and a graph editor with value and speed curves."},{title:"Layers of every kind",body:"Solids, shapes, text, footage, nested compositions, nulls, adjustment layers, cameras and lights, with parenting, track mattes and 38 blend modes."},{title:"259 effects",body:"Blur, color correction, distortion, generators, keying, particles and simulation, stylize and time effects, each with sensible defaults."},{title:"Real 3D",body:"3D layers with cameras, depth of field and lights that cast soft ray-traced shadows, plus orbit, pan and dolly tools."},{title:"Expressions",body:"JavaScript expressions with wiggle, loops and layer references, edited inline and linked straight to any property."},{title:"Export anywhere",body:"H.264 and ProRes with alpha, PNG, TIFF and 32-bit EXR sequences, GIF, and Lottie import and export for the web. No FFmpeg inside."}],shots:[{file:"hero.webp",source:"effectcraft-hero.png",caption:"An animated title on the timeline",alt:"EffectCraft's composition panel showing an animated EFFECTCRAFT title, with the project panel, a timeline of text, shape and solid layers, and the properties panel"},{file:"graph-editor.webp",source:"effectcraft-graph-editor.png",caption:"Graph editor with eased keyframes",alt:"EffectCraft's graph editor showing an eased value curve for a text animator"},{file:"effects.webp",source:"effectcraft-effects.png",caption:"Particle simulation effects",alt:"EffectCraft's effect controls for a particle simulation bursting from the center of the composition"},{file:"3d.webp",source:"effectcraft-3d.png",caption:"3D cameras, lights and soft shadows",alt:"EffectCraft's 3D showcase: intersecting cards lit by a spot light with soft shadows on a gridded floor, seen from a custom camera view"}]},{slug:"designcraft",prefix:"Design",category:"Page layout & publishing",status:"In development",headline:["Page layout and ","publishing",", rebuilt in pure Rust."],pitch:"Open-source page layout and publishing, rebuilt in pure Rust.",lede:"Spreads and parent pages, threaded stories, styles, swatches and text wrap in a native layout app with a professional paragraph composer. No subscription, no licence server, no telemetry.",schemaCategory:"DesignApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"The layout tools you know",body:"Spreads and parent pages, frames and threaded stories, paragraph and character styles, swatches and text wrap, laid out the way you expect."},{title:"Beautiful type",body:"A Knuth–Plass paragraph composer, dictionary hyphenation, optical margin alignment and baseline grids. Line breaks match on screen and in PDF."},{title:"Print-ready PDF",body:"Real selectable text with embedded fonts, CMYK and spot colors, bleed, crop marks and archival PDF/A output."},{title:"Fast",body:"Multithreaded SIMD rendering, copy-on-write documents with instant undo, and cached composition."},{title:"Open formats",body:"A documented native format, PNG export, and layout interchange import and export for moving work between tools."},{title:"Agent-native",body:"Every menu item, tool, panel and dialog can be driven over a JSON control channel and an MCP server."}],shots:[{file:"hero.webp",source:"ui-spread.png",caption:"Threaded columns and text wrap — Quarterly",alt:"DesignCraft showing a magazine spread: a threaded three-column story with its thread line, a wrapped pull quote, and the Properties panel's text frame options"},{file:"cover.webp",source:"page-cover.png",caption:"Cover",alt:"Magazine cover for The Spring Issue: a dusk landscape of layered purple hills under a pale sun, with the serif headline The Quiet Art of Layout",portrait:!0},{file:"feature.webp",source:"page-2.png",caption:"Styles",alt:"Feature opener titled Notes on the Grid with a kicker rule, italic deck, landscape picture, caption and two columns of justified body text",portrait:!0},{file:"columns.webp",source:"page-3.png",caption:"Threading and wrap",alt:"Three columns of justified, hyphenated body text wrapping around a shaded pull quote",portrait:!0},{file:"swatches.webp",source:"page-4.png",caption:"Swatches",alt:"Coming Next page titled Color, Ink and Paper on a plum background with four labeled color swatches",portrait:!0}]},{slug:"figcraft",prefix:"Fig",category:"Interface design",status:"Early alpha",headline:["Interface design, ","rebuilt"," in pure Rust."],pitch:"Open-source interface design and prototyping, rebuilt in pure Rust.",lede:"Frames, auto layout, components and variants, vector networks, styles, variables and prototypes in a native app that opens instantly and works offline. No account, no telemetry, no subscription.",schemaCategory:"DesignApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.95",features:[{title:"Familiar by design",body:"The toolbar, layers panel, Design panel, menus and shortcuts sit where your hands expect them. Productive on day one, no retraining."},{title:"Layouts that build themselves",body:"Auto layout in both directions with wrap and grid, padding, gaps and Hug, Fill and Fixed sizing, plus constraints and layout grids for everything else."},{title:"Components that scale",body:"Instances with overrides that survive edits, component sets with variants and properties, and styles and variables with modes for light and dark."},{title:"Real vector networks",body:"Pen and pencil, a shape builder, booleans whose operands stay editable, variable-width strokes and smooth corners."},{title:"Prototype and hand off",body:"Connections, triggers and animated transitions, a presentation view, and Dev Mode with measurements, annotations and generated CSS, HTML, React, SwiftUI and Compose code."},{title:"Agent-ready",body:"Every menu item, tool and gesture runs one of 400+ commands, so the CLI, a JSON control channel and an MCP server can do anything you can click."}],shots:[{file:"hero.webp",source:"shot-1-hero.png",caption:"Ridgeline — auto layout screens in light and dark",alt:"FigCraft editing the Ridgeline hiking app: three phone screens on the canvas, the Featured trail card instance selected, the layers panel showing its auto layout tree, and the Design panel showing Fill and Hug sizing and the Theme variable mode"},{file:"components.webp",source:"shot-2-components.png",caption:"Components, variants and the Assets panel",alt:"FigCraft's Assets panel with live component thumbnails beside a Button component set of nine variants, and the Design panel listing its Style and State variant properties"},{file:"prototype.webp",source:"shot-3-prototype.png",caption:"Prototype connections and flows",alt:"Four onboarding phone screens in FigCraft's Prototype tab joined by connection curves, with the Prototype panel showing an On click, Navigate to interaction"},{file:"dev-mode.webp",source:"shot-4-devmode.png",caption:"Dev Mode with annotations and generated code",alt:"FigCraft's Dev Mode on the Ridgeline home screen with a Ready for dev badge, an annotation callout, and the Inspect panel showing generated React code for the selected trail row"},{file:"vector.webp",source:"shot-5-vector.png",caption:"Vector networks and variable-width strokes",alt:"FigCraft's vector edit mode on a wave path with a tapered gradient stroke, its anchor points and bezier handles visible, above a boolean-built mountain mark and a knot of excluded rings"},{file:"dashboard.webp",source:"shot-6-dashboard-light.png",caption:"Layout grids and styles, light theme",alt:"FigCraft in its light theme with a web analytics dashboard of KPI cards, bar, donut and area charts, and the frame's 12-column layout grid showing as tinted columns"},{file:"collab.webp",source:"shot-7-collab.png",caption:"Live session with cursor chat and spotlight",alt:"A FigCraft live session with three participant avatars, a spotlight banner with a Follow button, two collaborators' cursors and selections on the canvas, and a cursor chat bubble"}],demo:{src:(0,s.cdnMediaUrl)("/videos/figcraft-collab-web.mp4"),poster:"collab-poster.webp",label:"Live sessions",headline:["Design ","together",", in real time."],lede:"Host the open file from the app or a server of your own, share the invite link, and edit it together. Changes sync live with cursors, selections and cursor chat, and undo takes back only your own.",caption:"A host and a guest editing one file",alt:"Two people editing one FigCraft file live: each sees the other's cursor, selection and edits land instantly, ending on the FigCraft end card."}},{slug:"wordcraft",prefix:"Word",category:"Word processing",status:"In development",headline:["A fast, open-source ","word processor",", rebuilt in pure Rust."],pitch:"Fast, open-source word processing, rebuilt in pure Rust.",lede:"The ribbon, styles, tables, track changes, references and mail merge in a native word processor that reads and writes .docx. Open source, offline, and fast.",schemaCategory:"BusinessApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"The ribbon you know",body:"Tabs, groups, shortcuts and the live Styles gallery. Enter continues a list, Tab demotes it, and formatting works as your hands expect."},{title:"Real document formats",body:"Opens and saves .docx natively, imports and exports .odt, .rtf, .html, .md and .txt, and exports clean PDF with selectable text."},{title:"Instant layout",body:"Paragraph layout is cached: typing in a 188-page document re-lays it out in about 1.4 ms, with pages rendered on demand."},{title:"Track changes & review",body:"Comment balloons in the margin, accept and reject changes, document comparison, plus offline spelling and grammar as you type."},{title:"Academic & business references",body:"Generate tables of contents, footnotes, citations and bibliographies in APA, MLA, Chicago and IEEE styles, indexes, and captions."},{title:"Agent-ready commands",body:"389 discrete commands drive the ribbon, keyboard shortcuts, a command-line tool, a JSON control channel and an MCP server."}],shots:[{file:"hero.webp",source:"hero.png",caption:"The Open Studio Handbook — ribbon, styles and navigation",alt:"WordCraft with the Home tab of the ribbon open over a two-page document titled The Open Studio Handbook, the Navigation pane on the left, and the Styles gallery showing live previews"},{file:"review.webp",source:"review.png",caption:"Review and track changes",alt:"WordCraft's Review tab with Track Changes on, inline insertions and deletions, and margin comment balloons"},{file:"references.webp",source:"references.png",caption:"Table of contents and citations",alt:"WordCraft's References tab showing a table of contents with dot leaders on page one and citations on page two"},{file:"layout.webp",source:"layout.png",caption:"Drop caps and text wrap",alt:"WordCraft layout tab showing a three-line drop cap, text wrapping around an object, and margin line numbers"},{file:"dark.webp",source:"dark.png",caption:"Dark mode with formatting marks",alt:"WordCraft in dark mode with the Insert tab open and formatting marks visible"}]},{slug:"soundcraft",prefix:"Sound",category:"Digital audio workstation",status:"In development",headline:["Professional audio recording and ","mixing",", rebuilt in pure Rust."],pitch:"Professional audio recording, editing and mixing in pure Rust.",lede:"Dedicated Edit and Mix windows, multitrack audio and MIDI, ten inserts and sends per track, surround panning, and offline AudioSuite in a native DAW built from scratch.",schemaCategory:"MultimediaApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"The studio workflow",body:"Dedicated Edit and Mix windows, Shuffle, Slip, Spot and Grid modes, comping playlists, memory locations, and single-key Commands Focus shortcuts."},{title:"Full mixing console",body:"Ten inserts and ten sends per track, busses, aux inputs, VCAs, routing folders, solo-in-place, and automatic plugin delay compensation."},{title:"Live automation",body:"Write, Touch, Latch and Trim automation passes recorded live for volume, pan, mutes, sends and every plugin parameter."},{title:"Original plugins & CLAP support",body:"Built-in EQ, dynamic processors, reverbs, delays, modulation, synthesisers, plus support for loading external CLAP plugins."},{title:"MIDI & notation",body:"Piano-roll MIDI editor with velocity lane, step input, quantize, transposition, score notation editor, and Audio-to-MIDI pitch detection."},{title:"Surround & video sync",body:"Surround panning up to 9.1.6, live speaker rendering, and a dedicated picture track with video playback synchronized to the playhead."}],shots:[{file:"hero.webp",source:"edit.png",caption:"Edit window — arranging and editing the demo session",alt:"SoundCraft Edit window showing audio waveforms, MIDI tracks, rulers, markers and transport controls for a multi-track session"},{file:"mix.webp",source:"mix.png",caption:"Mix console with inserts and sends",alt:"SoundCraft Mix window with ten inserts and sends per track, pan knobs, faders, meters and an EQ plugin window"},{file:"midi.webp",source:"midi.png",caption:"Piano-roll MIDI editor",alt:"SoundCraft MIDI editor showing note velocity lanes and piano roll editing"},{file:"automation.webp",source:"automation.png",caption:"Breakpoint automation and memory locations",alt:"SoundCraft displaying volume automation curves on a track alongside the Memory Locations window"},{file:"surround.webp",source:"surround.png",caption:"Immersive surround renderer",alt:"SoundCraft Renderer window displaying a 7.1.4 surround speaker layout and spatial panners"}]},{slug:"deckcraft",prefix:"Deck",category:"Presentations & slide shows",status:"In development",headline:["Fast, dynamic slide ","presentations",", in pure Rust."],pitch:"Build and deliver dynamic slide presentations, in pure Rust.",lede:"Slide masters, themes, 150+ vector shapes, transitions, animations and presenter view in a native app that opens and saves presentation files. No subscription, no cloud.",schemaCategory:"BusinessApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"Master slides & themes",body:"Slide masters and eleven layouts with inheriting placeholders, eight original themes with font and colour schemes, sections, and presenter notes."},{title:"Vector shapes & drawing",body:"Over 150 preset shapes with adjustment handles, sticky connectors, curve booleans, gradient fills, and outline styling."},{title:"Transitions & animation",body:"Slide transitions including Morph, entrance, emphasis, exit and motion-path animations, with by-paragraph builds."},{title:"Presenter view",body:"Full-screen slide show delivery with speaker notes, upcoming slide previews, elapsed timers, rehearsal timings, and pen drawing."},{title:"Format compatibility",body:"Open and save presentation files (.pptx), export vector PDF slides and handouts, and render slide images."},{title:"Automated with MCP",body:"Over 200 commands scriptable from the CLI, a JSON control channel, and an MCP server for autonomous agents."}],shots:[{file:"hero.webp",source:"editor.png",caption:"Slide editor with process diagram",alt:"DeckCraft slide editor showing the ribbon, slide thumbnails, notes panel, and a vector process diagram on the canvas"},{file:"shape-format.webp",source:"shape-format.png",caption:"Shape formatting and geometry",alt:"DeckCraft Shape Format tab with selection handles and alignment tools on an active shape"},{file:"format-pane.webp",source:"format-pane.png",caption:"Format Shape pane and gradient stops",alt:"DeckCraft Format Shape pane configuring gradient fill angles, stops and transparency"},{file:"slide-sorter.webp",source:"slide-sorter.png",caption:"Slide Sorter view with transitions",alt:"DeckCraft Slide Sorter showing all slides in the deck with assigned transition badges"},{file:"dark-mode.webp",source:"dark-mode.png",caption:"Dark mode with chart slide",alt:"DeckCraft dark mode editing a presentation slide featuring a native chart"}]},{slug:"cadcraft",prefix:"CAD",category:"Computer-aided design & drafting",status:"In development",headline:["Computer-aided design and drafting, ","reimagined"," in pure Rust."],pitch:"Fast, open-source computer-aided design and drafting in pure Rust.",lede:"The command line, object snaps, layers, dimensions, hatches, blocks and drawings you already know. Fast, native, and built for both people and AI agents.",schemaCategory:"DesignApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"The drafting workflow",body:"Type commands, click points, direct distance entry, object snaps, polar tracking, ortho, grips, and right-click-to-repeat."},{title:"Open drawing formats",body:"Reads and writes DXF (ASCII and binary, R12–2018), opens DWG (R13–2018), and exports to PDF, SVG, and PNG."},{title:"Paper space & viewports",body:"Layout sheets with floating viewports, per-viewport layer overrides, page setups, and scale-exact plotting."},{title:"Associative annotations",body:"Linear, aligned, angular and radial dimensions that follow geometry, multileaders, tables, and custom drafting fonts."},{title:"Hatching & block libraries",body:"Pick-point boundary hatching with islands, pattern fills, block definitions with attributes, and nested blocks."},{title:"Parametric constraints",body:"Geometric and dimensional constraints with expression parameters that automatically re-solve as you edit."}],shots:[{file:"hero.webp",source:"ui-apartment.png",caption:"Apartment floor plan with hatching and dimensions",alt:"CADCraft displaying an architectural floor plan with pick-point wall hatching, room schedules, dimensions and the command line"},{file:"layout.webp",source:"ui-layout.png",caption:"Paper space layout with scaled viewport",alt:"CADCraft paper space layout showing a title block sheet with an active scaled model viewport"},{file:"bracket.webp",source:"ui-bracket.png",caption:"Mechanical part drawing with section hatch",alt:"CADCraft drafting a mechanical mounting bracket with section lines, dimensions and title block"}]},{slug:"gridcraft",prefix:"Grid",category:"Spreadsheets & data analysis",status:"In development",headline:["Fast, native spreadsheets, ","rebuilt"," in pure Rust."],pitch:"Fast, open-source spreadsheets and data analysis, rebuilt in pure Rust.",lede:"Ribbon tabs, formula bar, 500+ calculation functions, dynamic arrays, PivotTables and charts in a native spreadsheet app that reads and writes .xlsx files.",schemaCategory:"BusinessApplication",platforms:["macOS","Windows","Linux","Web"],rustVersion:"1.90",features:[{title:"The spreadsheet workflow",body:"Formula bar, Name Box, sheet tabs, fill handle, colored cell references, conditional formatting, and familiar shortcuts."},{title:"Native XLSX compatibility",body:"Styles, themes, formulas, dynamic arrays, tables, validation, comments, sparklines and PivotTables round-trip cleanly."},{title:"500+ calculation functions",body:"Full dependency-graph calculation engine with dynamic arrays, spilling, LET, LAMBDA, MAP, REDUCE, and table references."},{title:"Charts & PivotTables",body:"Seventeen chart types with customizable formatting, plus PivotTables with filters, field lists, layouts, and date grouping."},{title:"High-performance engine",body:"Copy-on-write workbooks with instant undo snapshots, incremental recalculation, and a virtualised grid."},{title:"Agent-native automation",body:"Every ribbon button, menu item, and formula can be driven by AI agents over an MCP server, CLI, or JSON control channel."}],shots:[{file:"hero.webp",source:"hero-sales.png",caption:"Quarterly sales dashboard with charts and sparklines",alt:"GridCraft sales dashboard featuring a styled table with conditional formatting, sparklines, and column and pie charts"},{file:"budget.webp",source:"budget.png",caption:"Household budget with conditional formatting",alt:"GridCraft budget sheet showing accounting currency formats, color scales, and comparison bar charts"},{file:"grades-formulas.webp",source:"grades-formulas.png",caption:"Formulas and function library",alt:"GridCraft formula bar and Formulas ribbon tab calculating averages and letter grades"},{file:"pivot.webp",source:"pivot.png",caption:"PivotTable and field list",alt:"GridCraft PivotTable report summarizing data with the PivotTable Fields pane open on the right"},{file:"format-chart.webp",source:"format-chart.png",caption:"Chart Design and Format Chart Area pane",alt:"GridCraft configuring a column chart with the Format Chart Area pane and highlighted source range"}]}];
  ["Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine","Ten","Eleven","Twelve","Thirteen","Fourteen","Fifteen","Sixteen"][l.length]??String(l.length);
  let c=new Intl.ListFormat("en",{type:"conjunction"});
  function d(e){
    return`${e.prefix}Craft`
    }
  t=l.filter(e=>e.platforms.includes("Web")).map(d),c.format(t),(0,s.mediaUrl)("/images/apps/og.jpg"),e.s(["CRAFTING_APPS",0,l,"CRAFTING_APPS_GITHUB_ORG",0,"https://github.com/storytold","craftAppIconPath",0,function(e){
    return`/images/apps/${e.slug}/icon.webp`
    },"craftAppIconSourceUrl",0,function(e){
    return`https://raw.githubusercontent.com/storytold/${e.slug}/main/assets/app-icon/${e.slug}-1024.png`
    },"craftAppName",0,d,"craftShotPath",0,function(e,t){
    return`/images/apps/${e.slug}/${t.file}`
    },"craftShotSourceUrl",0,function(e,t){
    return`https://raw.githubusercontent.com/storytold/${e.slug}/main/docs/images/${t.source}`
    },"releaseDownloads",0,function(e,t,a){
    let r=`${e}/releases/download/${a.tag??`v${a.version}`}`;
    return a.assets.flatMap(({file:e,...i})=>{
      let n=e.replaceAll("{slug}",a.fileSlug??t).replaceAll("{version}",a.version);
      return a.files&&!a.files.includes(n)?[]:[{...i,fileName:n,href:`${r}/${n}`}]
      })
    }],75001)
  },75679,e=>{
  "use strict";
  var t=e.i(12637);
  let a="".trim()||void 0;
  function r(e,t){
    a&&window.gtag?.("event",e,t)
    }
  let i=new URL(t.WEBAPP_URL).origin,n=new Map(Object.entries(t.SOCIAL_LINKS).map(([e,t])=>[c(new URL(t).hostname),e.toLowerCase()])),o=/^\/[^/]+\/([^/]+)\/releases\/download\/([^/]+)\/([^/]+)$/;
  function s(e){
    return e.closest("#site-nav")?"nav":e.closest("footer")?"footer":e.closest('[role="dialog"]')?"modal":e.closest("section[id]")?.id||"page"
    }
  function l(e){
    return(e.getAttribute("aria-label")||e.textContent||"").replace(/\s+/g," ").trim().slice(0,100)
    }
  function c(e){
    return e.replace(/^www\./,"")
    }
  e.s(["GA_MEASUREMENT_ID",0,a,"trackAttrs",0,function(e,t){
    let a={"data-track":e};
    for(
    let[e,r]
    of Object.entries(t))
    void 0!==r&&(a[`data-track-${e}`]=String(r));
    return a
    },"trackClick",0,function(e){
    if(!(e instanceof Element))
    return;
    let t=e.closest("[data-track]");
    if(t?.dataset.track)
    return void r(t.dataset.track,{...function(e){
      let t={};
      for(
      let[a,r]
      of Object.entries(e.dataset))
      a.length>5&&a.startsWith("track")&&(t[a.charAt(5).toLowerCase()+a.slice(6)]=r);
      return t
      }(t),link_location:s(t)});
    let a=e.closest("a[href]"),d=a&&function(e){
      let t;
      try{
        t=new URL(e.href)
        }catch{
        return null
        }
      if("mailto:"===t.protocol)
      return{event:"contact_click",params:{method:"mailto"}};
      let a="github.com"===t.hostname&&o.exec(t.pathname);
      if(a){
        var r;
        let[,e,t,i]=a,n=decodeURIComponent(i);
        return{event:"app_download",params:{app_name:e,app_version:t.replace(/^\D*/,""),platform:(r=n,/\.dmg$|macos/i.test(r)?"macos":/\.(exe|msi)$|windows/i.test(r)?"windows":/\.(appimage|deb|rpm)$|linux/i.test(r)?"linux":"other"),file_name:n}}
        }
      if(t.origin===i)
      return{event:"webapp_click",params:{destination:t.pathname,link_text:l(e)}};
      let s=n.get(c(t.hostname));
      return s?{event:"social_click",params:{network:s}}:e.hasAttribute("data-cta")?{event:"cta_click",params:{link_url:t.origin===window.location.origin?t.pathname+t.hash:t.href,link_text:l(e)}}:null
      }(a);
    d&&r(d.event,{...d.params,link_location:s(a)})
    },"trackEvent",0,function(e,t){
    r(e,t)
    }])
  },9165,e=>{
  "use strict";
  let t=e.i(47167).default.env.NEXT_PUBLIC_API_HOST??window.location.origin,a="artcraft_signed_session";
  function r(e,t){
    return n(e,{method:"POST",body:t}).then(e=>e.success?e.data.stripe_checkout_redirect_url?{success:!0,data:{checkoutUrl:e.data.stripe_checkout_redirect_url}}:{success:!1,errorMessage:"Failed to initiate checkout"}:e)
    }
  function i(e,t){
    return n(e,{method:"POST",body:t}).then(e=>e.success?e.data.stripe_portal_url?{success:!0,data:{portalUrl:e.data.stripe_portal_url}}:{success:!1,errorMessage:"Failed to open the billing portal"}:e)
    }
  async function n(e,r={}){
    try{
      let i={Accept:"application/json","Content-Type":"application/json"},n=function(){
        try{
          return localStorage.getItem(a)
          }catch{
          return null
          }
        }();
      n&&(i.session=n);
      let o=await fetch(`${t}${e}`,{method:r.method??"GET",headers:i,credentials:"include",signal:r.signal,body:void 0===r.body?void 0:JSON.stringify(r.body)}),s=await o.json().catch(()=>null);
      if(!o.ok)
      return{success:!1,status:o.status,errorMessage:s?.message??s?.error_message??`Request failed (${o.status})`};
      if(!s?.success)
      return{success:!1,errorMessage:s?.error_message??"Request failed"};
      return{success:!0,data:s}
      }catch(e){
      return{success:!1,errorMessage:e instanceof Error?e.message:"Network error"}
      }
    }
  function o(e){
    if(e)
    try{
      localStorage.setItem(a,e)
      }catch{
      }
    }
  e.s(["creditsPackCheckout",0,function(e){
    return r("/v1/stripe_artcraft/checkout/credits_pack",{credits_pack:e})
    },"generateVideo",0,function(e){
    return n("/v1/omni_gen/generate/video",{method:"POST",body:{model:e.model,prompt:e.prompt,idempotency_token:crypto.randomUUID(),aspect_ratio:e.aspectRatio??null,resolution:e.resolution??null,duration_seconds:e.durationSeconds??null,generate_audio:e.generateAudio??null,video_batch_count:1,start_frame_image_media_token:null,end_frame_image_media_token:null,reference_image_media_tokens:null,reference_video_media_tokens:null,reference_audio_media_tokens:null,reference_character_tokens:null}}).then(e=>e.success?e.data.inference_job_token?{success:!0,data:{jobToken:e.data.inference_job_token}}:{success:!1,errorMessage:"Generation failed"}:e)
    },"getPortalUrl",0,function(){
    return i("/v1/stripe_artcraft/portal/manage_plan",{})
    },"getSession",0,function(){
    return n("/v1/session").then(e=>e.success?{success:!0,data:{loggedIn:e.data.logged_in,user:e.data.user}}:e)
    },"getVideoJob",0,function(e){
    return n(`/v1/jobs/job/${e}`).then(e=>{
      if(!e.success)
      return{status:"pending"};
      let t=e.data.state,a=t?.status?.status?.toLowerCase()??"";
      if("complete_success"===a||"complete"===a){
        let e=t?.maybe_result?.media_links?.cdn_url;
        return e?{status:"complete",videoUrl:e}:{status:"pending"}
        }
      return a.includes("fail")||a.includes("error")||"dead"===a?{status:"failed",error:t?.status?.maybe_failure_message??t?.status?.maybe_extra_status_description??"Generation failed"}:{status:"pending"}
      })
    },"listActiveSubscriptions",0,function(){
    return n("/v1/billing/active_subscriptions").then(e=>e.success?{success:!0,data:e.data.active_subscriptions??[]}:e)
    },"logWebReferral",0,function(e){
    return n("/v1/web_referrals/record",{method:"POST",body:{maybe_referral_url:e??null}}).then(()=>void 0)
    },"login",0,function(e){
    return n("/v1/login",{method:"POST",body:{username_or_email:e.usernameOrEmail,password:e.password}}).then(e=>e.success?(o(e.data.signed_session),{success:!0,data:{signedSession:e.data.signed_session}}):e)
    },"request",0,n,"signup",0,function(e){
    return n("/v1/create_account",{method:"POST",body:{username:e.username,email_address:e.email,password:e.password,password_confirmation:e.password,signup_source:e.signupSource,...e.maybeReferralUrl&&{maybe_referral_url:e.maybeReferralUrl},...e.maybeLandingUrl&&{maybe_landing_url:e.maybeLandingUrl},...e.maybeReferralUsername&&{maybe_referral_username:e.maybeReferralUsername},...e.maybeReferralCode&&{maybe_referral_code:e.maybeReferralCode}}}).then(e=>e.success?(o(e.data.signed_session),{success:!0,data:{signedSession:e.data.signed_session}}):e)
    },"subscriptionCheckout",0,function(e){
    return r("/v1/stripe_artcraft/checkout/subscription",e)
    },"switchPlan",0,function(e){
    return i("/v1/stripe_artcraft/portal/switch_plan",e)
    },"userSignupSubscriptionCheckout",0,function(e){
    return r("/v1/stripe_artcraft/user_signup_subscription_checkout",{plan:e.plan,cadence:e.cadence,...e.maybeReferralUrl&&{maybe_referral_url:e.maybeReferralUrl},...e.maybeLandingUrl&&{maybe_landing_url:e.maybeLandingUrl},...e.maybeReferralUsername&&{maybe_referral_username:e.maybeReferralUsername},...e.maybeReferralCode&&{maybe_referral_code:e.maybeReferralCode}})
    }])
  },88814,e=>{
  "use strict";
  let t="referral_username",a="referral_code",r="referral_landing_url",i="referral_referrer",n=["getartcraft.com"];
  function o(){
    return p(r)
    }
  function s(){
    return p(i)
    }
  function l(e){
    return e.trim().toLowerCase().replace(/[^a-z0-9_]/g,"").slice(0,20)
    }
  function c(e){
    return e.trim().replace(/[^A-Za-z0-9._-]/g,"").slice(0,30)
    }
  function d(e){
    let t=e?.trim();
    return t?t.slice(0,1024):void 0
    }
  function u(e,t){
    let a="https:"===window.location.protocol?"; Secure":"",r=window.location.hostname,i=n.find(e=>r===e||r.endsWith(`.${e}`)),o=i?`; Domain=.${i}`:"";
    document.cookie=`${e}=${encodeURIComponent(t)}; Max-Age=7776000; Path=/; SameSite=Lax${a}${o}`;
    try{
      localStorage.setItem(e,t)
      }catch{
      }
    }
  function p(e){
    let t=`${e}=`,a=document.cookie.split("; ").find(e=>e.startsWith(t));
    if(a)
    return decodeURIComponent(a.slice(t.length))||void 0;
    try{
      return localStorage.getItem(e)??void 0
      }catch{
      return
      }
    }
  e.s(["captureLandingContext",0,function(){
    try{
      let e=new URLSearchParams(window.location.search),n=l(e.get("u")??"");
      n&&u(t,n);
      let p=c(e.get("r")??"");
      p&&u(a,p);
      let f=d(window.location.href);
      f&&!o()&&u(r,f);
      let h=d(document.referrer);
      h&&!s()&&u(i,h)
      }catch{
      }
    },"getLandingUrl",0,o,"getReferralCode",0,function(){
    let e=p(a);
    return e&&c(e)||void 0
    },"getReferralUsername",0,function(){
    let e=p(t);
    return e&&l(e)||void 0
    },"getReferrer",0,s])
  },25215,e=>{
  "use strict";
  var t=e.i(75001),a=e.i(12637);
  (0,a.mediaUrl)("/videos/features/WorldLabs_Demo_2.webm"),(0,a.mediaUrl)("/videos/features/Panel.webm"),(0,a.mediaUrl)("/videos/features/Editor.webm"),(0,a.mediaUrl)("/videos/features/Make_3D.webm"),(0,a.mediaUrl)("/videos/features/Mixed.webm"),(0,a.mediaUrl)("/videos/features/Character-Pose.webm"),(0,a.mediaUrl)("/videos/features/Background.webm");
  let r=Array.from({length:35},(e,t)=>({src:(0,a.cdnMediaUrl)(`/videos/${String(t+1).padStart(3,"0")}.mp4`),aspect:16/9})),i="hero",n=[{id:i,label:"ARTCRAFT"},{id:"seedance-2",label:"SEEDANCE 2.0"},{id:"seedance-2-5",label:"SEEDANCE 2.5"},{id:"minimax-h3",label:"MINIMAX H3"},{id:"apps",label:"CRAFTING APPS"},...t.CRAFTING_APPS.map(e=>({id:e.slug,label:(0,t.craftAppName)(e).toUpperCase()})),{id:"creator",label:"SPOTLIGHT"},{id:"overview",label:"OVERVIEW"},{id:"highlights",label:"HIGHLIGHTS"},{id:"lineup",label:"LINEUP"},{id:"principles",label:"PRINCIPLES"},{id:"gallery",label:"SCREENSHOTS"},{id:"get-it",label:"GET IT"},{id:"family",label:"THE FAMILY"},{id:"examples",label:"EXAMPLES"},{id:"tips",label:"PROMPT TIPS"},{id:"campaign-faq",label:"FAQ"},{id:"manifesto",label:"MANIFESTO"},{id:"the-work",label:"THE WORK"},{id:"craft",label:"THE CRAFT"},{id:"features",label:"FEATURES"},{id:"ownership",label:"OWNERSHIP"},{id:"reasons",label:"WHY ARTCRAFT"},{id:"made-with",label:"COMMUNITY"},{id:"community",label:"JOIN US"},{id:"start",label:"GET STARTED"},{id:"pricing",label:"PRICING"},{id:"download",label:"DOWNLOAD"},{id:"tutorials",label:"TUTORIALS"},{id:"news",label:"NEWS"},{id:"faq",label:"FAQ"},{id:"support",label:"SUPPORT"},{id:"press-kit",label:"PRESS KIT"},{id:"beta",label:"BETA"},{id:"plans",label:"PLANS"},{id:"enterprise",label:"ENTERPRISE"},{id:"credits",label:"CREDITS"},{id:"platforms",label:"PLATFORMS"},{id:"quick-start",label:"QUICK START"},{id:"articles",label:"ARTICLES"},{id:"contact",label:"CONTACT"}];
  e.s(["HERO_SECTION_ID",0,i,"RULER_SECTIONS",0,n,"SEEDANCE_SHOWCASE",0,r])
  },74268,79655,e=>{
  "use strict";
  e.s(["NAV_H",0,48,"clamp01",0,e=>Math.max(0,Math.min(1,e)),"easeInOutCubic",0,e=>e<.5?4*e*e*e:1-Math.pow(-2*e+2,3)/2,"easeOutExpo",0,e=>e>=1?1:1-Math.pow(2,-10*e),"heroWordmark",0,{ready:!1,forming:!1,els:[],baseX:[],baseDocY:[],fontPx:0,metrics:{adv:[],cum:[],total:0}},"railOccupancy",0,{spans:[]},"rulerMap",0,function(e,t){
    let a=48+t;
    return{base:a,span:Math.max(1,e-48-2*t),drift:e=>a-e*(48+2*t)}
    },"rulerZoom",0,{target:0,p:0,dragging:!1}],74268);
  let t=(0,e.i(21853).defineTunables)("wordmark","Wordmark",{weight:{label:"Type weight",min:400,max:900,step:10,default:750,info:"Resting font weight of the letters. The logo-A is a fixed-stroke SVG (about 0.22 of its cap height), so the letters' stems are dialed down from the 900 poster extreme to match it."},logoCap:{label:"Logo cap em",min:.5,max:1,step:.005,default:.7,info:"Height of the logo-A relative to the font size — match it to the caps' visual height."},logoLift:{label:"Logo lift em",min:-.1,max:.1,step:.002,default:-.006,info:"Vertical baseline correction of the logo-A: positive raises it. Syncs the SVG's box-bottom alignment with the glyphs' ink baseline."},logoPad:{label:"Logo pad em",min:0,max:.15,step:.005,default:.05,info:"Side bearing between the logo-A and the R, standing in for the glyph spacing the SVG doesn't have."},bladeTuck:{label:"Blade tuck em",min:0,max:.5,step:.01,default:.12,info:"Extra distance the sliding word starts tucked behind the blade edge — kills any sliver peeking past the clip at rest."},scrimPadX:{label:"Scrim pad x",min:0,max:320,step:8,default:128,info:"How far the contrast scrim behind the center stack extends horizontally beyond the content."},scrimPadY:{label:"Scrim pad y",min:0,max:240,step:8,default:88,info:"How far the contrast scrim extends vertically beyond the content."},scrimBg:{label:"Scrim peak %",min:40,max:95,step:1,default:78,info:"Peak page-background strength at the scrim's center — the contrast pocket the wordmark and copy sit in over the galaxy."}});
  e.s(["DISPLAY_STRETCH",0,118,"DISPLAY_WEIGHT",0,620,"WORDMARK_FONT",0,"var(--font-archivo), system-ui, sans-serif","WORDMARK_STRETCH",0,125,"wordmarkDefaults",0,function(){
    let e={};
    for(
    let a
     of Object.keys(t.defs))
    e[a]=t.defs[a].default;
    return e
    },"wordmarkTuner",0,t],79655)
  }]);
