(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,55838,(e,t,n)=>{
  "use strict";
  var r=e.r(71645),l="function"==typeof Object.is?Object.is:function(e,t){
    return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t
    },a=r.useState,i=r.useEffect,o=r.useLayoutEffect,u=r.useDebugValue;
  function s(e){
    var t=e.getSnapshot;
    e=e.value;
    try{
      var n=t();
      return!l(e,n)
      }catch(e){
      return!0
      }
    }
  var c="u"<typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){
    return t()
    }:function(e,t){
    var n=t(),r=a({inst:{value:n,getSnapshot:t}}),l=r[0].inst,c=r[1];
    return o(function(){
      l.value=n,l.getSnapshot=t,s(l)&&c({inst:l})
      },[e,n,t]),i(function(){
      return s(l)&&c({inst:l}),e(function(){
        s(l)&&c({inst:l})
        })
      },[e]),u(n),n
    };
  n.useSyncExternalStore=void 0!==r.useSyncExternalStore?r.useSyncExternalStore:c
  },2239,(e,t,n)=>{
  "use strict";
  t.exports=e.r(55838)
  },52822,(e,t,n)=>{
  "use strict";
  var r=e.r(71645),l=e.r(2239),a="function"==typeof Object.is?Object.is:function(e,t){
    return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t
    },i=l.useSyncExternalStore,o=r.useRef,u=r.useEffect,s=r.useMemo,c=r.useDebugValue;
  n.useSyncExternalStoreWithSelector=function(e,t,n,r,l){
    var f=o(null);
    if(null===f.current){
      var d={hasValue:!1,value:null};
      f.current=d
      }else 
    d=f.current;
    var p=i(e,(f=s(function(){
      function e(e){
        if(!u){
          if(u=!0,i=e,e=r(e),void 0!==l&&d.hasValue){
            var t=d.value;
            if(l(t,e))
            return o=t
            }
          return o=e
          }
        if(t=o,a(i,e))
        return t;
        var n=r(e);
        return void 0!==l&&l(t,n)?(i=e,t):(i=e,o=n)
        }
      var i,o,u=!1,s=void 0===n?null:n;
      return[function(){
        return e(t())
        },null===s?void 0:function(){
        return e(s())
        }]
      },[t,n,r,l]))[0],f[1]);
    return u(function(){
      d.hasValue=!0,d.value=p
      },[p]),c(p),p
    }
  },30224,(e,t,n)=>{
  "use strict";
  t.exports=e.r(52822)
  },66936,(e,t,n)=>{
  "use strict";
  function r(e,t){
    var n=e.length;
    for(e.push(t);0<n;){
      var r=n-1>>>1,l=e[r];
      if(0<i(l,t))
      e[r]=t,e[n]=l,n=r;
      else 
      break
      }
    }
  function l(e){
    return 0===e.length?null:e[0]
    }
  function a(e){
    if(0===e.length)
    return null;
    var t=e[0],n=e.pop();
    if(n!==t){
      e[0]=n;
      for(
      var r=0,l=e.length,a=l>>>1
      ;r<a;){
        var o=2*(r+1)-1,u=e[o],s=o+1,c=e[s];
        if(0>i(u,n))
        s<l&&0>i(c,u)?(e[r]=c,e[s]=n,r=s):(e[r]=u,e[o]=n,r=o);
        else 
        if(s<l&&0>i(c,n))
        e[r]=c,e[s]=n,r=s;
        else 
        break
        }
      }
    return t
    }
  function i(e,t){
    var n=e.sortIndex-t.sortIndex;
    return 0!==n?n:e.id-t.id
    }
  if(n.unstable_now=void 0,"object"==typeof performance&&"function"==typeof performance.now){
    var o,u=performance;
    n.unstable_now=function(){
      return u.now()
      }
    }else{
    var s=Date,c=s.now();
    n.unstable_now=function(){
      return s.now()-c
      }
    }
  var f=[],d=[],p=1,m=null,h=3,g=!1,v=!1,b=!1,y=!1,S="function"==typeof setTimeout?setTimeout:null,C="function"==typeof clearTimeout?clearTimeout:null,w="u">typeof setImmediate?setImmediate:null;
  function x(e){
    for(
    var t=l(d)
    ;null!==t;){
      if(null===t.callback)
      a(d);
      else 
      if(t.startTime<=e)
      a(d),t.sortIndex=t.expirationTime,r(f,t);
      else 
      break;
      t=l(d)
      }
    }
  function k(e){
    if(b=!1,x(e),!v)
    if(null!==l(f))
    v=!0,T||(T=!0,o());
    else{
      var t=l(d);
      null!==t&&R(k,t.startTime-e)
      }
    }
  var T=!1,E=-1,_=5,P=-1;
  function z(){
    return!!y||!(n.unstable_now()-P<_)
    }
  function M(){
    if(y=!1,T){
      var e=n.unstable_now();
      P=e;
      var t=!0;
      try{
        e:{
          v=!1,b&&(b=!1,C(E),E=-1),g=!0;
          var r=h;
          try{
            t:{
              for(x(e),m=l(f);null!==m&&!(m.expirationTime>e&&z());){
                var i=m.callback;
                if("function"==typeof i){
                  m.callback=null,h=m.priorityLevel;
                  var u=i(m.expirationTime<=e);
                  if(e=n.unstable_now(),"function"==typeof u){
                    m.callback=u,x(e),t=!0;
                    break t
                    }
                  m===l(f)&&a(f),x(e)
                  }else 
                a(f);
                m=l(f)
                }
              if(null!==m)
              t=!0;
              else{
                var s=l(d);
                null!==s&&R(k,s.startTime-e),t=!1
                }
              }
            break e
            }finally{
            m=null,h=r,g=!1
            }
          }
        }finally{
        t?o():T=!1
        }
      }
    }
  if("function"==typeof w)
  o=function(){
    w(M)
    };
  else 
  if("u">typeof MessageChannel){
    var F=new MessageChannel,L=F.port2;
    F.port1.onmessage=M,o=function(){
      L.postMessage(null)
      }
    }else 
  o=function(){
    S(M,0)
    };
  function R(e,t){
    E=S(function(){
      e(n.unstable_now())
      },t)
    }
  n.unstable_IdlePriority=5,n.unstable_ImmediatePriority=1,n.unstable_LowPriority=4,n.unstable_NormalPriority=3,n.unstable_Profiling=null,n.unstable_UserBlockingPriority=2,n.unstable_cancelCallback=function(e){
    e.callback=null
    },n.unstable_forceFrameRate=function(e){
    0>e||125<e?console.error("forceFrameRate takes a positive int between 0 and 125, forcing frame rates higher than 125 fps is not supported"):_=0<e?Math.floor(1e3/e):5
    },n.unstable_getCurrentPriorityLevel=function(){
    return h
    },n.unstable_next=function(e){
    switch(h){case 1:case 2:case 3:
    var t=3;
    break;
    default:
    t=h
    }
    var n=h;
    h=t;
    try{
      return e()
      }finally{
      h=n
      }
    },n.unstable_requestPaint=function(){
    y=!0
    },n.unstable_runWithPriority=function(e,t){
    switch(e){case 1:case 2:case 3:case 4:case 5:
    break;
    default:
    e=3
    }
    var n=h;
    h=e;
    try{
      return t()
      }finally{
      h=n
      }
    },n.unstable_scheduleCallback=function(e,t,a){
    var i=n.unstable_now();
    switch(a="object"==typeof a&&null!==a&&"number"==typeof(a=a.delay)&&0<a?i+a:i,e){case 1:
    var u=-1;
    break;
    case 2:
    u=250;
    break;
    case 5:
    u=0x3fffffff;
    break;
    case 4:
    u=1e4;
    break;
    default:
    u=5e3
    }
    return u=a+u,e={id:p++,callback:t,priorityLevel:e,startTime:a,expirationTime:u,sortIndex:-1},a>i?(e.sortIndex=a,r(d,e),null===l(f)&&e===l(d)&&(b?(C(E),E=-1):b=!0,R(k,a-i))):(e.sortIndex=u,r(f,e),v||g||(v=!0,T||(T=!0,o()))),e
    },n.unstable_shouldYield=z,n.unstable_wrapCallback=function(e){
    var t=h;
    return function(){
      var n=h;
      h=t;
      try{
        return e.apply(this,arguments)
        }finally{
        h=n
        }
      }
    }
  },89499,(e,t,n)=>{
  "use strict";
  t.exports=e.r(66936)
  },75056,1950,25234,e=>{
  "use strict";
  let t,n,r,l,a,i,o,u,s;
  var c,f,d,p,m,h,g=e.i(47167),v=e.i(71645),b=e.i(90072),y=e.i(8560),S=e.i(30224),C=e.i(8155);
  let{useSyncExternalStoreWithSelector:w}=S.default,x=(e,t)=>{
    let n=(0,C.createStore)(e),r=(e,r=t)=>(function(e,t=e=>e,n){
      let r=w(e.subscribe,e.getState,e.getInitialState,t,n);
      return v.default.useDebugValue(r),r
      })(n,e,r);
    return Object.assign(r,n),r
    },k=[];
  function T(e,t,n=(e,t)=>e===t){
    if(e===t)
    return!0;
    if(!e||!t)
    return!1;
    let r=e.length;
    if(t.length!==r)
    return!1;
    for(
    let l=0
    ;l<r;l++)
    if(!n(e[l],t[l]))
    return!1;
    return!0
    }
  function E(e,t=null,n=!1,r={}){
    for(
    let l
     of(null===t&&(t=[e]),k))
    if(T(t,l.keys,l.equal)){
      if(n)
      return;
      if(Object.prototype.hasOwnProperty.call(l,"error"))
      throw l.error;
      if(Object.prototype.hasOwnProperty.call(l,"response"))
      return r.lifespan&&r.lifespan>0&&(l.timeout&&clearTimeout(l.timeout),l.timeout=setTimeout(l.remove,r.lifespan)),l.response;
      if(!n)
      throw l.promise
      }
    let l={keys:t,equal:r.equal,remove:()=>{
      let e=k.indexOf(l);
      -1!==e&&k.splice(e,1)
      },promise:("object"==typeof e&&"function"==typeof e.then?e:e(...t)).then(e=>{
      l.response=e,r.lifespan&&r.lifespan>0&&(l.timeout=setTimeout(l.remove,r.lifespan))
      }).catch(e=>l.error=e)};
    if(k.push(l),!n)
    throw l.promise
    }
  var _=e.i(89499),P=e.i(43476),z=v;
  function M(e,t,n){
    if(!e)
    return;
    if(!0===n(e))
    return e;
    let r=t?e.return:e.child;
    for(;r;){
      let e=M(r,t,n);
      if(e)
      return e;
      r=t?null:r.sibling
      }
    }
  function F(e){
    try{
      return Object.defineProperties(e,{_currentRenderer:{get:()=>null,set(){
        }},_currentRenderer2:{get:()=>null,set(){
        }}})
      }catch(t){
      return e
      }
    }
  "u">typeof window&&((null==(c=window.document)?void 0:c.createElement)||(null==(f=window.navigator)?void 0:f.product)==="ReactNative")?z.useLayoutEffect:z.useEffect;
  let L=F(z.createContext(null));
  class R extends z.Component{
    render(){
      return z.createElement(L.Provider,{value:this._reactInternals},this.props.children)
      }
  }
  function N(){
    let e=z.useContext(L);
    if(null===e)
    throw Error("its-fine: useFiber must be called within a <FiberProvider />!");
    let t=z.useId();
    return z.useMemo(()=>{
      for(
      let n
       of[e,null==e?void 0:e.alternate]){
        if(!n)
        continue;
        let e=M(n,!1,e=>{
          let n=e.memoizedState;
          for(;n;){
            if(n.memoizedState===t)
            return!0;
            n=n.next
            }
          });
        if(e)
        return e
        }
      },[e,t])
    }
  let A=Symbol.for("react.context"),I=e=>null!==e&&"object"==typeof e&&"$$typeof"in e&&e.$$typeof===A;
  function B(e){
    let t=e.root;
    for(;t.getState().previousRoot;)
    t=t.getState().previousRoot;
    return t
    }
  v.act;
  let j=e=>e&&e.hasOwnProperty("current"),D=e=>null!=e&&("string"==typeof e||"number"==typeof e||e.isColor),G="u">typeof window&&((null==(i=window.document)?void 0:i.createElement)||(null==(o=window.navigator)?void 0:o.product)==="ReactNative")?v.useLayoutEffect:v.useEffect;
  function O(e){
    let t=v.useRef(e);
    return G(()=>void(t.current=e),[e]),t
    }
  function U(){
    let e,t=N(),n=(e=function(){
      let e=N(),[t]=z.useState(()=>new Map);
      t.clear();
      let n=e;
      for(;n;){
        let e=n.type;
        I(e)&&e!==L&&!t.has(e)&&t.set(e,z.use(F(e))),n=n.return
        }
      return t
      }(),z.useMemo(()=>Array.from(e.keys()).reduce((t,n)=>r=>z.createElement(t,null,z.createElement(n.Provider,{...r,value:e.get(n)})),e=>z.createElement(R,{...e})),[e]));
    return v.useMemo(()=>({children:e})=>{
      let r=M(t,!0,e=>e.type===v.StrictMode)?v.StrictMode:v.Fragment;
      return(0,P.jsx)(r,{children:(0,P.jsx)(n,{children:e})})
      },[t,n])
    }
  function H({set:e}){
    return G(()=>(e(new Promise(()=>null)),()=>e(!1)),[e]),null
    }
  let V=((u=class extends v.Component{
    constructor(...e){
      super(...e),this.state={error:!1}
      }componentDidCatch(e){
      this.props.set(e)
      }render(){
      return this.state.error?null:this.props.children
      }
  }).getDerivedStateFromError=()=>({error:!0}),u);
  function q(e){
    var t;
    let n="u">typeof window?null!=(t=window.devicePixelRatio)?t:2:1;
    return Array.isArray(e)?Math.min(Math.max(e[0],n),e[1]):e
    }
  function W(e){
    var t;
    return null==(t=e.__r3f)?void 0:t.root.getState()
    }
  let Q={obj:e=>e===Object(e)&&!Q.arr(e)&&"function"!=typeof e,fun:e=>"function"==typeof e,str:e=>"string"==typeof e,num:e=>"number"==typeof e,boo:e=>"boolean"==typeof e,und:e=>void 0===e,nul:e=>null===e,arr:e=>Array.isArray(e),equ(e,t,{arrays:n="shallow",objects:r="reference",strict:l=!0}={}){
    let a;
    if(typeof e!=typeof t||!!e!=!!t)
    return!1;
    if(Q.str(e)||Q.num(e)||Q.boo(e))
    return e===t;
    let i=Q.obj(e);
    if(i&&"reference"===r)
    return e===t;
    let o=Q.arr(e);
    if(o&&"reference"===n)
    return e===t;
    if((o||i)&&e===t)
    return!0;
    for(a in e)
    if(!(a in t))
    return!1;
    if(i&&"shallow"===n&&"shallow"===r){
      for(a in l?t:e)
      if(!Q.equ(e[a],t[a],{strict:l,objects:"reference"}))
      return!1
      }else 
    for(a in l?t:e)
    if(e[a]!==t[a])
    return!1;
    if(Q.und(a)){
      if(o&&0===e.length&&0===t.length||i&&0===Object.keys(e).length&&0===Object.keys(t).length)
      return!0;
      if(e!==t)
      return!1
      }
    return!0
    }},$=["children","key","ref"];
  function K(e,t,n,r){
    let l=null==e?void 0:e.__r3f;
    return!l&&(l={root:t,type:n,parent:null,children:[],props:function(e){
      let t={};
      for(
      let n
       in e)
      $.includes(n)||(t[n]=e[n]);
      return t
      }(r),object:e,eventCount:0,handlers:{},isHidden:!1},e&&(e.__r3f=l)),l
    }
  function X(e,t){
    if(!t.includes("-")||t in e)
    return{root:e,key:t,target:e[t]};
    let n=e,r=t.split("-");
    for(
    let l
     of r){
      if("object"!=typeof n||null===n){
        if(void 0!==n)
        return{root:n,key:r.slice(r.indexOf(l)).join("-"),target:void 0};
        return{root:e,key:t,target:void 0}
        }
      t=l,e=n,n=n[t]
      }
    return{root:e,key:t,target:n}
    }
  let Y=/-\d+$/;
  function Z(e,t){
    if(Q.str(t.props.attach)){
      if(Y.test(t.props.attach)){
        let n=t.props.attach.replace(Y,""),{root:r,key:l}=X(e.object,n);
        Array.isArray(r[l])||(r[l]=[])
        }
      let{root:n,key:r}=X(e.object,t.props.attach);
      t.previousAttach=n[r],n[r]=t.object
      }else 
    Q.fun(t.props.attach)&&(t.previousAttach=t.props.attach(e.object,t.object))
    }
  function J(e,t){
    if(Q.str(t.props.attach)){
      let{root:n,key:r}=X(e.object,t.props.attach),l=t.previousAttach;
      void 0===l?delete n[r]:n[r]=l
      }else 
    null==t.previousAttach||t.previousAttach(e.object,t.object);
    delete t.previousAttach
    }
  let ee=[...$,"args","dispose","attach","object","onUpdate","dispose"],et=new Map,en=["map","emissiveMap","sheenColorMap","specularColorMap","envMap"],er=/^on(Pointer|Click|DoubleClick|ContextMenu|Wheel)/;
  function el(e,t){
    var n,r;
    let l=e.__r3f,a=l&&B(l).getState(),i=null==l?void 0:l.eventCount;
    for(
    let n
     in t){
      let i=t[n];
      if(ee.includes(n))
      continue;
      if(l&&er.test(n)){
        "function"==typeof i?l.handlers[n]=i:delete l.handlers[n],l.eventCount=Object.keys(l.handlers).length;
        continue
        }
      if(void 0===i)
      continue;
      let{root:o,key:u,target:s}=X(e,n);
      if(void 0===s&&("object"!=typeof o||null===o))
      throw Error(`R3F: Cannot set "${n}". Ensure it is an object before setting "${u}".`);
      if(s instanceof b.Layers&&i instanceof b.Layers)
      s.mask=i.mask;
      else 
      if(s instanceof b.Color&&D(i))
      s.set(i);
      else 
      if(null!==s&&"object"==typeof s&&"function"==typeof s.set&&"function"==typeof s.copy&&null!=i&&i.constructor&&s.constructor===i.constructor)
      s.copy(i);
      else 
      if(null!==s&&"object"==typeof s&&"function"==typeof s.set&&Array.isArray(i))
      "function"==typeof s.fromArray?s.fromArray(i):s.set(...i);
      else 
      if(null!==s&&"object"==typeof s&&"function"==typeof s.set&&"number"==typeof i)
      "function"==typeof s.setScalar?s.setScalar(i):s.set(i);
      else 
      if(o instanceof b.ShaderMaterial&&"uniforms"===u&&Q.obj(i)){
        Q.obj(o.uniforms)||(o.uniforms={});
        let e=o.uniforms;
        for(
        let t
         in i){
          let n=i[t],r=e[t];
          r?Object.assign(r,n):e[t]={...n}
          }
        }else 
      o[u]=i,a&&!a.linear&&en.includes(u)&&null!=(r=o[u])&&r.isTexture&&o[u].format===b.RGBAFormat&&o[u].type===b.UnsignedByteType&&(o[u].colorSpace=b.SRGBColorSpace)
      }
    if(null!=l&&l.parent&&null!=a&&a.internal&&null!=(n=l.object)&&n.isObject3D&&i!==l.eventCount){
      let e=l.object,t=a.internal.interaction.indexOf(e);
      t>-1&&a.internal.interaction.splice(t,1),l.eventCount&&null!==e.raycast&&a.internal.interaction.push(e)
      }
    return l&&void 0===l.props.attach&&(l.object.isBufferGeometry?l.props.attach="geometry":l.object.isMaterial&&(l.props.attach="material")),l&&ea(l),e
    }
  function ea(e){
    var t;
    if(!e.parent)
    return;
    null==e.props.onUpdate||e.props.onUpdate(e.object);
    let n=null==(t=e.root)||null==t.getState?void 0:t.getState();
    n&&0===n.internal.frames&&n.invalidate()
    }
  let ei=e=>null==e?void 0:e.isObject3D;
  function eo(e){
    return(e.eventObject||e.object).uuid+"/"+e.index+e.instanceId
    }
  function eu(e,t,n,r){
    let l=n.get(t);
    l&&(n.delete(t),0===n.size&&(e.delete(r),l.target.releasePointerCapture(r)))
    }
  let es=e=>!!(null!=e&&e.render),ec=v.createContext(null);
  function ef(){
    let e=v.useContext(ec);
    if(!e)
    throw Error("R3F: Hooks can only be used within the Canvas component!");
    return e
    }
  function ed(e,t=0){
    let n=ef(),r=n.getState().internal.subscribe,l=O(e);
    return G(()=>r(l,t,n),[t,r,n]),null
    }
  let ep=new WeakMap;
  function em(e,t){
    return function(n,...r){
      var l;
      let a;
      return"function"==typeof n&&(null==n||null==(l=n.prototype)?void 0:l.constructor)===n?(a=ep.get(n))||(a=new n,ep.set(n,a)):a=n,e&&e(a),Promise.all(r.map(e=>new Promise((n,r)=>a.load(e,e=>{
        var t;
        let r;
        ei(null==e?void 0:e.scene)&&Object.assign(e,(t=e.scene,r={nodes:{},materials:{},meshes:{}},t&&t.traverse(e=>{
          e.name&&(r.nodes[e.name]=e),e.material&&!r.materials[e.material.name]&&(r.materials[e.material.name]=e.material),e.isMesh&&!r.meshes[e.name]&&(r.meshes[e.name]=e)
          }),r)),n(e)
        },t,t=>r(Error(`Could not load ${e}: ${null==t?void 0:t.message}`))))))
      }
    }
  function eh(e,t,n,r){
    let l=Array.isArray(t)?t:[t],a=E(em(n,r),[e,...l],!1,{equal:Q.equ});
    return Array.isArray(t)?a:a[0]
    }
  eh.preload=function(e,t,n){
    let r,l=Array.isArray(t)?t:[t];
    E(em(n),[e,...l],!0,r)
    },eh.clear=function(e,t){
    var n=[e,...Array.isArray(t)?t:[t]];
    if(void 0===n||0===n.length)
    k.splice(0,k.length);
    else{
      let e=k.find(e=>T(n,e.keys,e.equal));
      e&&e.remove()
      }
    };
  var eg={exports:{}},ev={exports:{}};
  ev.exports;
  let eb=(h||(h=1,m||(m=1,ev.exports=function(e){
    function t(e,t,n,r){
      return new rK(e,t,n,r)
      }
    function n(){
      }
    function r(e){
      var t="https://react.dev/errors/"+e;
      if(1<arguments.length){
        t+="?args[]="+encodeURIComponent(arguments[1]);
        for(
        var n=2
        ;n<arguments.length;n++)
        t+="&args[]="+encodeURIComponent(arguments[n])
        }
      return"Minified React error #"+e+"; visit "+t+" for the full message or use the non-minified dev environment for full errors and additional helpful warnings."
      }
    function l(e){
      var t=e,n=e;
      if(e.alternate)
      for(;t.return;)
      t=t.return;
      else{
        e=t;
        do
        (4098&(t=e).flags)!=0&&(n=t.return),e=t.return;
        while(e)
        }
      return 3===t.tag?n:null
      }
    function a(e){
      if(l(e)!==e)
      throw Error(r(188))
      }
    function i(e){
      var t=e.alternate;
      if(!t){
        if(null===(t=l(e)))
        throw Error(r(188));
        return t!==e?null:e
        }
      for(
      var n=e,i=t
      ;;){
        var o=n.return;
        if(null===o)
        break;
        var u=o.alternate;
        if(null===u){
          if(null!==(i=o.return)){
            n=i;
            continue
            }
          break
          }
        if(o.child===u.child){
          for(u=o.child;u;){
            if(u===n)
            return a(o),e;
            if(u===i)
            return a(o),t;
            u=u.sibling
            }
          throw Error(r(188))
          }
        if(n.return!==i.return)
        n=o,i=u;
        else{
          for(
          var s=!1,c=o.child
          ;c;){
            if(c===n){
              s=!0,n=o,i=u;
              break
              }
            if(c===i){
              s=!0,i=o,n=u;
              break
              }
            c=c.sibling
            }
          if(!s){
            for(c=u.child;c;){
              if(c===n){
                s=!0,n=u,i=o;
                break
                }
              if(c===i){
                s=!0,i=u,n=o;
                break
                }
              c=c.sibling
              }
            if(!s)
            throw Error(r(189))
            }
          }
        if(n.alternate!==i)
        throw Error(r(190))
        }
      if(3!==n.tag)
      throw Error(r(188));
      return n.stateNode.current===n?e:t
      }
    function o(e){
      return null===e||"object"!=typeof e?null:"function"==typeof(e=ly&&e[ly]||e["@@iterator"])?e:null
      }
    function u(e){
      if(null==e)
      return null;
      if("function"==typeof e)
      return e.$$typeof===lS?null:e.displayName||e.name||null;
      if("string"==typeof e)
      return e;
      switch(e){case lo:
      return"Fragment";
      case ls:
      return"Profiler";
      case lu:
      return"StrictMode";
      case lp:
      return"Suspense";
      case lm:
      return"SuspenseList";
      case lv:
      return"Activity"
      }
      if("object"==typeof e)
      switch(e.$$typeof){case li:
      return"Portal";
      case lf:
      return e.displayName||"Context";
      case lc:
      return(e._context.displayName||"Context")+".Consumer";
      case ld:
      var t=e.render;
      return(e=e.displayName)||(e=""!==(e=t.displayName||t.name||"")?"ForwardRef("+e+")":"ForwardRef"),e;
      case lh:
      return null!==(t=e.displayName||null)?t:u(e.type)||"Memo";
      case lg:
      t=e._payload,e=e._init;
      try{
        return u(e(t))
        }catch{
        }
      }
      return null
      }
    function s(e){
      return{current:e}
      }
    function c(e){
      0>iT||(e.current=ik[iT],ik[iT]=null,iT--)
      }
    function f(e,t){
      ik[++iT]=e.current,e.current=t
      }
    function d(e){
      var t=42&e;
      if(0!==t)
      return t;
      switch(e&-e){case 1:
      return 1;
      case 2:
      return 2;
      case 4:
      return 4;
      case 8:
      return 8;
      case 16:
      return 16;
      case 32:
      return 32;
      case 64:
      return 64;
      case 128:
      return 128;
      case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:
      return 261888&e;
      case 262144:case 524288:case 1048576:case 2097152:
      return 3932160&e;
      case 4194304:case 8388608:case 0x1000000:case 0x2000000:
      return 0x3c00000&e;
      case 0x4000000:
      return 0x4000000;
      case 0x8000000:
      return 0x8000000;
      case 0x10000000:
      return 0x10000000;
      case 0x20000000:
      return 0x20000000;
      case 0x40000000:
      return 0;
      default:
      return e
      }
      }
    function p(e,t,n){
      var r=e.pendingLanes;
      if(0===r)
      return 0;
      var l=0,a=e.suspendedLanes,i=e.pingedLanes;
      e=e.warmLanes;
      var o=0x7ffffff&r;
      return 0!==o?0!=(r=o&~a)?l=d(r):0!=(i&=o)?l=d(i):n||0!=(n=o&~e)&&(l=d(n)):0!=(o=r&~a)?l=d(o):0!==i?l=d(i):n||0!=(n=r&~e)&&(l=d(n)),0===l?0:0!==t&&t!==l&&(t&a)==0&&((a=l&-l)>=(n=t&-t)||32===a&&(4194048&n)!=0)?t:l
      }
    function m(e,t){
      return(e.pendingLanes&~(e.suspendedLanes&~e.pingedLanes)&t)==0
      }
    function h(){
      var e=iL;
      return(0x3c00000&(iL<<=1))==0&&(iL=4194304),e
      }
    function b(e){
      for(
      var t=[],n=0
      ;31>n;n++)
      t.push(e);
      return t
      }
    function y(e,t){
      e.pendingLanes|=t,0x10000000!==t&&(e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0)
      }
    function S(e,t,n){
      e.pendingLanes|=t,e.suspendedLanes&=~t;
      var r=31-i_(t);
      e.entangledLanes|=t,e.entanglements[r]=0x40000000|e.entanglements[r]|261930&n
      }
    function C(e,t){
      var n=e.entangledLanes|=t;
      for(e=e.entanglements;n;){
        var r=31-i_(n),l=1<<r;
        l&t|e[r]&t&&(e[r]|=t),n&=~l
        }
      }
    function w(e,t){
      var n=t&-t;
      return((n=(42&n)!=0?1:x(n))&(e.suspendedLanes|t))!=0?0:n
      }
    function x(e){
      switch(e){case 2:
      e=1;
      break;
      case 8:
      e=4;
      break;
      case 32:
      e=16;
      break;
      case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:case 4194304:case 8388608:case 0x1000000:case 0x2000000:
      e=128;
      break;
      case 0x10000000:
      e=0x8000000;
      break;
      default:
      e=0
      }
      return e
      }
    function k(e){
      return 2<(e&=-e)?8<e?(0x7ffffff&e)!=0?32:0x10000000:8:2
      }
    function T(e){
      if("function"==typeof iU&&iH(e),iq&&"function"==typeof iq.setStrictMode)
      try{
        iq.setStrictMode(iV,e)
        }catch{
        }
      }
    function E(e){
      if(void 0===a7)
      try{
        throw Error()
        }catch(e){
        var t=e.stack.trim().match(/\n( *(at )?)/);
        a7=t&&t[1]||"",a9=-1<e.stack.indexOf(`
    at`)?" (<anonymous>)":-1<e.stack.indexOf("@")?"@unknown:0:0":""
        }
      return`
`+a7+e+a9
      }
    function P(e,t){
      if(!e||iK)
      return"";
      iK=!0;
      var n=Error.prepareStackTrace;
      Error.prepareStackTrace=void 0;
      try{
        var r={DetermineComponentFrameRoot:function(){
          try{
            if(t){
              var n=function(){
                throw Error()
                };
              if(Object.defineProperty(n.prototype,"props",{set:function(){
                throw Error()
                }}),"object"==typeof Reflect&&Reflect.construct){
                try{
                  Reflect.construct(n,[])
                  }catch(e){
                  var r=e
                  }
                Reflect.construct(e,[],n)
                }else{
                try{
                  n.call()
                  }catch(e){
                  r=e
                  }
                e.call(n.prototype)
                }
              }else{
              try{
                throw Error()
                }catch(e){
                r=e
                }
              (n=e())&&"function"==typeof n.catch&&n.catch(function(){
                })
              }
            }catch(e){
            if(e&&r&&"string"==typeof e.stack)
            return[e.stack,r.stack]
            }
          return[null,null]
          }};
        r.DetermineComponentFrameRoot.displayName="DetermineComponentFrameRoot";
        var l=Object.getOwnPropertyDescriptor(r.DetermineComponentFrameRoot,"name");
        l&&l.configurable&&Object.defineProperty(r.DetermineComponentFrameRoot,"name",{value:"DetermineComponentFrameRoot"});
        var a=r.DetermineComponentFrameRoot(),i=a[0],o=a[1];
        if(i&&o){
          var u=i.split(`
`),s=o.split(`
`);
          for(l=r=0;r<u.length&&!u[r].includes("DetermineComponentFrameRoot");)
          r++;
          for(;l<s.length&&!s[l].includes("DetermineComponentFrameRoot");)
          l++;
          if(r===u.length||l===s.length)
          for(r=u.length-1,l=s.length-1;1<=r&&0<=l&&u[r]!==s[l];)
          l--;
          for(;1<=r&&0<=l;r--,l--)
          if(u[r]!==s[l]){
            if(1!==r||1!==l)
            do 
            if(r--,l--,0>l||u[r]!==s[l]){
              var c=`
`+u[r].replace(" at new "," at ");
              return e.displayName&&c.includes("<anonymous>")&&(c=c.replace("<anonymous>",e.displayName)),c
              }
            while(1<=r&&0<=l)
            break
            }
          }
        }finally{
        iK=!1,Error.prepareStackTrace=n
        }
      return(n=e?e.displayName||e.name:"")?E(n):""
      }
    function z(e){
      try{
        var t="",n=null;
        do 
        t+=function(e,t){
          switch(e.tag){case 26:case 27:case 5:
          return E(e.type);
          case 16:
          return E("Lazy");
          case 13:
          return e.child!==t&&null!==t?E("Suspense Fallback"):E("Suspense");
          case 19:
          return E("SuspenseList");
          case 0:case 15:
          return P(e.type,!1);
          case 11:
          return P(e.type.render,!1);
          case 1:
          return P(e.type,!0);
          case 31:
          return E("Activity");
          default:
          return""
          }
          }(e,n),n=e,e=e.return;
        while(e)
        return t
        }catch(e){
        return`
Error generating stack: `+e.message+`
`+e.stack
        }
      }
    function M(e,t){
      if("object"==typeof e&&null!==e){
        var n=iX.get(e);
        return void 0!==n?n:(t={value:e,source:t,stack:z(t)},iX.set(e,t),t)
        }
      return{value:e,source:t,stack:z(t)}
      }
    function F(e,t){
      iY[iZ++]=i0,iY[iZ++]=iJ,iJ=e,i0=t
      }
    function L(e,t,n){
      i1[i2++]=i4,i1[i2++]=i5,i1[i2++]=i3,i3=e;
      var r=i4;
      e=i5;
      var l=32-i_(r)-1;
      r&=~(1<<l),n+=1;
      var a=32-i_(t)+l;
      if(30<a){
        var i=l-l%5;
        a=(r&(1<<i)-1).toString(32),r>>=i,l-=i,i4=1<<32-i_(t)+l|n<<l|r,i5=a+e
        }else 
      i4=1<<a|n<<l|r,i5=e
      }
    function R(e){
      null!==e.return&&(F(e,1),L(e,1,0))
      }
    function N(e){
      for(;e===iJ;)
      iJ=iY[--iZ],iY[iZ]=null,i0=iY[--iZ],iY[iZ]=null;
      for(;e===i3;)
      i3=i1[--i2],i1[i2]=null,i5=i1[--i2],i1[i2]=null,i4=i1[--i2],i1[i2]=null
      }
    function A(e,t){
      i1[i2++]=i4,i1[i2++]=i5,i1[i2++]=i3,i4=t.id,i5=t.overflow,i3=e
      }
    function I(e,t){
      f(i7,t),f(i8,e),f(i6,null),e=l_(t),c(i6),f(i6,e)
      }
    function B(){
      c(i6),c(i8),c(i7)
      }
    function j(e){
      null!==e.memoizedState&&f(i9,e);
      var t=i6.current,n=lP(t,e.type);
      t!==n&&(f(i8,e),f(i6,n))
      }
    function D(e){
      i8.current===e&&(c(i6),c(i8)),i9.current===e&&(c(i9),lD?l4._currentValue=l3:l4._currentValue2=l3)
      }
    function G(e){
      var t=Error(r(418,1<arguments.length&&void 0!==arguments[1]&&arguments[1]?"text":"HTML",""));
      throw W(M(t,e)),oa
      }
    function O(e,t){
      if(!lU)
      throw Error(r(175));
      aq(e.stateNode,e.type,e.memoizedProps,t,e)||G(e,!0)
      }
    function U(e){
      for(oe=e.return;oe;)
      switch(oe.tag){case 5:case 31:case 13:
      ol=!1;
      return;
      case 27:case 3:
      ol=!0;
      return;
      default:
      oe=oe.return
      }
      }
    function H(e){
      if(!lU||e!==oe)
      return!1;
      if(!on)
      return U(e),on=!0,!1;
      var t=e.tag;
      if(ib?3!==t&&27!==t&&(5!==t||a8(e.type)&&!lN(e.type,e.memoizedProps))&&ot&&G(e):3!==t&&(5!==t||a8(e.type)&&!lN(e.type,e.memoizedProps))&&ot&&G(e),U(e),13===t){
        if(!lU)
        throw Error(r(316));
        if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))
        throw Error(r(317));
        ot=aX(e)
        }else 
      if(31===t){
        if(!(e=null!==(e=e.memoizedState)?e.dehydrated:null))
        throw Error(r(317));
        ot=aK(e)
        }else 
      ot=ib&&27===t?aA(e.type,ot):oe?aN(e.stateNode):null;
      return!0
      }
    function V(){
      lU&&(ot=oe=null,on=!1)
      }
    function q(){
      var e=or;
      return null!==e&&(null===uR?uR=e:uR.push.apply(uR,e),or=null),e
      }
    function W(e){
      null===or?or=[e]:or.push(e)
      }
    function Q(e,t,n){
      lD?(f(oi,t._currentValue),t._currentValue=n):(f(oi,t._currentValue2),t._currentValue2=n)
      }
    function $(e){
      var t=oi.current;
      lD?e._currentValue=t:e._currentValue2=t,c(oi)
      }
    function K(e,t,n){
      for(;null!==e;){
        var r=e.alternate;
        if((e.childLanes&t)!==t?(e.childLanes|=t,null!==r&&(r.childLanes|=t)):null!==r&&(r.childLanes&t)!==t&&(r.childLanes|=t),e===n)
        break;
        e=e.return
        }
      }
    function X(e,t,n,l){
      var a=e.child;
      for(null!==a&&(a.return=e);null!==a;){
        var i=a.dependencies;
        if(null!==i){
          var o=a.child;
          i=i.firstContext;
          n:
          for(;null!==i;){
            var u=i;
            i=a;
            for(
            var s=0
            ;s<t.length;s++)
            if(u.context===t[s]){
              i.lanes|=n,null!==(u=i.alternate)&&(u.lanes|=n),K(i.return,n,e),l||(o=null);
              break n
              }
            i=u.next
            }
          }else 
        if(18===a.tag){
          if(null===(o=a.return))
          throw Error(r(341));
          o.lanes|=n,null!==(i=o.alternate)&&(i.lanes|=n),K(o,n,e),o=null
          }else 
        o=a.child;
        if(null!==o)
        o.return=a;
        else 
        for(o=a;null!==o;){
          if(o===e){
            o=null;
            break
            }
          if(null!==(a=o.sibling)){
            a.return=o.return,o=a;
            break
            }
          o=o.return
          }
        a=o
        }
      }
    function Y(e,t,n,l){
      e=null;
      for(
      var a=t,i=!1
      ;null!==a;){
        if(!i){
          if((524288&a.flags)!=0)
          i=!0;
          else 
          if((262144&a.flags)!=0)
          break
          }
        if(10===a.tag){
          var o=a.alternate;
          if(null===o)
          throw Error(r(387));
          if(null!==(o=o.memoizedProps)){
            var u=a.type;
            iW(a.pendingProps.value,o.value)||(null!==e?e.push(u):e=[u])
            }
          }else 
        if(a===i9.current){
          if(null===(o=a.alternate))
          throw Error(r(387));
          o.memoizedState.memoizedState!==a.memoizedState.memoizedState&&(null!==e?e.push(l4):e=[l4])
          }
        a=a.return
        }
      null!==e&&X(t,e,n,l),t.flags|=262144
      }
    function Z(e){
      for(e=e.firstContext;null!==e;){
        var t=e.context;
        if(!iW(lD?t._currentValue:t._currentValue2,e.memoizedValue))
        return!0;
        e=e.next
        }
      return!1
      }
    function J(e){
      oo=e,ou=null,null!==(e=e.dependencies)&&(e.firstContext=null)
      }
    function ee(e){
      return en(oo,e)
      }
    function et(e,t){
      return null===oo&&J(e),en(e,t)
      }
    function en(e,t){
      var n=lD?t._currentValue:t._currentValue2;
      if(t={context:t,memoizedValue:n,next:null},null===ou){
        if(null===e)
        throw Error(r(308));
        ou=t,e.dependencies={lanes:0,firstContext:t},e.flags|=524288
        }else 
      ou=ou.next=t;
      return n
      }
    function er(){
      return{controller:new os,data:new Map,refCount:0}
      }
    function el(e){
      e.refCount--,0===e.refCount&&oc(of,function(){
        e.controller.abort()
        })
      }
    function ea(){
      }
    function ei(e){
      e!==om&&null===e.next&&(null===om?op=om=e:om=om.next=e),og=!0,oh||(oh=!0,l6?l8(function(){
        (6&ug)!=0?iR(ij,eu):es()
        }):iR(ij,eu))
      }
    function eo(e,t){
      if(!ov&&og){
        ov=!0;
        do 
        for(
        var n=!1,r=op
        ;null!==r;){
          if(!t)
          if(0!==e){
            var l=r.pendingLanes;
            if(0===l)
            var a=0;
            else{
              var i=r.suspendedLanes,o=r.pingedLanes;
              a=0xc000095&(a=(1<<31-i_(42|e)+1)-1&(l&~(i&~o)))?0xc000095&a|1:a?2|a:0
              }
            0!==a&&(n=!0,ed(r,a))
            }else 
          a=uy,(3&(a=p(r,r===uv?a:0,null!==r.cancelPendingCommit||r.timeoutHandle!==lj)))==0||m(r,a)||(n=!0,ed(r,a));
          r=r.next
          }
        while(n)
        ov=!1
        }
      }
    function eu(){
      es()
      }
    function es(){
      og=oh=!1;
      var e=0;
      0!==ob&&l$()&&(e=ob);
      for(
      var t=iB(),n=null,r=op
      ;null!==r;){
        var l=r.next,a=ec(r,t);
        0===a?(r.next=null,null===n?op=l:n.next=l,null===l&&(om=n)):(n=r,(0!==e||(3&a)!=0)&&(og=!0)),r=l
        }
      0!==uG&&5!==uG||eo(e,!1),0!==ob&&(ob=0)
      }
    function ec(e,t){
      for(
      var n=e.suspendedLanes,r=e.pingedLanes,l=e.expirationTimes,a=-0x3c00001&e.pendingLanes
      ;0<a;){
        var i=31-i_(a),o=1<<i,u=l[i];
        -1===u?((o&n)==0||(o&r)!=0)&&(l[i]=function(e,t){
          switch(e){case 1:case 2:case 4:case 8:case 64:
          return t+250;
          case 16:case 32:case 128:case 256:case 512:case 1024:case 2048:case 4096:case 8192:case 16384:case 32768:case 65536:case 131072:case 262144:case 524288:case 1048576:case 2097152:
          return t+5e3;
          default:
          return -1
          }
          }(o,t)):u<=t&&(e.expiredLanes|=o),a&=~o
        }
      if(t=uv,n=uy,n=p(e,e===t?n:0,null!==e.cancelPendingCommit||e.timeoutHandle!==lj),r=e.callbackNode,0===n||e===t&&(2===uS||9===uS)||null!==e.cancelPendingCommit)
      return null!==r&&null!==r&&iN(r),e.callbackNode=null,e.callbackPriority=0;
      if((3&n)==0||m(e,n)){
        if((t=n&-n)===e.callbackPriority)
        return t;
        switch(null!==r&&iN(r),k(n)){case 2:case 8:
        n=iD;
        break;
        case 32:default:
        n=iG;
        break;
        case 0x10000000:
        n=iO
        }
        return n=iR(n,r=ef.bind(null,e)),e.callbackPriority=t,e.callbackNode=n,t
        }
      return null!==r&&null!==r&&iN(r),e.callbackPriority=2,e.callbackNode=null,2
      }
    function ef(e,t){
      if(0!==uG&&5!==uG)
      return e.callbackNode=null,e.callbackPriority=0,null;
      var n=e.callbackNode;
      if(rG()&&e.callbackNode!==n)
      return null;
      var r=uy;
      return 0===(r=p(e,e===uv?r:0,null!==e.cancelPendingCommit||e.timeoutHandle!==lj))?null:(rb(e,r,t),ec(e,iB()),null!=e.callbackNode&&e.callbackNode===n?ef.bind(null,e):null)
      }
    function ed(e,t){
      if(rG())
      return null;
      rb(e,t,!0)
      }
    function ep(){
      if(0===ob){
        var e=oC;
        0===e&&(e=iM,(261888&(iM<<=1))==0&&(iM=256)),ob=e
        }
      return ob
      }
    function em(){
      if(0==--oS&&null!==oy){
        null!==ow&&(ow.status="fulfilled");
        var e=oy;
        oy=null,oC=0,ow=null;
        for(
        var t=0
        ;t<e.length;t++)
        (0,e[t])()
        }
      }
    function eh(){
      var e=ok.current;
      return null!==e?e:uv.pooledCache
      }
    function eg(e,t){
      null===t?f(ok,ok.current):f(ok,t.pool)
      }
    function ev(){
      var e=eh();
      return null===e?null:{parent:lD?od._currentValue:od._currentValue2,pool:e}
      }
    function eb(e,t){
      if(iW(e,t))
      return!0;
      if("object"!=typeof e||null===e||"object"!=typeof t||null===t)
      return!1;
      var n=Object.keys(e),r=Object.keys(t);
      if(n.length!==r.length)
      return!1;
      for(r=0;r<n.length;r++){
        var l=n[r];
        if(!i$.call(t,l)||!iW(e[l],t[l]))
        return!1
        }
      return!0
      }
    function ey(e){
      return"fulfilled"===(e=e.status)||"rejected"===e
      }
    function eS(e,t,n){
      switch(void 0===(n=e[n])?e.push(t):n!==t&&(t.then(ea,ea),t=n),t.status){case"fulfilled":
      return t.value;
      case"rejected":
      throw ex(e=t.reason),e;
      default:
      if("string"==typeof t.status)
      t.then(ea,ea);
      else{
        if(null!==(e=uv)&&100<e.shellSuspendCounter)
        throw Error(r(482));
        (e=t).status="pending",e.then(function(e){
          if("pending"===t.status){
            var n=t;
            n.status="fulfilled",n.value=e
            }
          },function(e){
          if("pending"===t.status){
            var n=t;
            n.status="rejected",n.reason=e
            }
          })
        }
      switch(t.status){case"fulfilled":
      return t.value;
      case"rejected":
      throw ex(e=t.reason),e
      }
      throw oz=t,oT
      }
      }
    function eC(e){
      try{
        return(0,e._init)(e._payload)
        }catch(e){
        throw null!==e&&"object"==typeof e&&"function"==typeof e.then?(oz=e,oT):e
        }
      }
    function ew(){
      if(null===oz)
      throw Error(r(459));
      var e=oz;
      return oz=null,e
      }
    function ex(e){
      if(e===oT||e===o_)
      throw Error(r(483))
      }
    function ek(e){
      var t=oF;
      return oF+=1,null===oM&&(oM=[]),eS(oM,e,t)
      }
    function eT(e,t){
      e.ref=void 0!==(t=t.props.ref)?t:null
      }
    function eE(e,t){
      throw t.$$typeof===ll?Error(r(525)):Error(r(31,"[object Object]"===(e=Object.prototype.toString.call(t))?"object with keys {"+Object.keys(t).join(", ")+"}":e))
      }
    function e_(e){
      function n(t,n){
        if(e){
          var r=t.deletions;
          null===r?(t.deletions=[n],t.flags|=16):r.push(n)
          }
        }
      function l(t,r){
        if(!e)
        return null;
        for(;null!==r;)
        n(t,r),r=r.sibling;
        return null
        }
      function a(e){
        for(
        var t=new Map
        ;null!==e;)
        null!==e.key?t.set(e.key,e):t.set(e.index,e),e=e.sibling;
        return t
        }
      function i(e,t){
        return(e=rY(e,t)).index=0,e.sibling=null,e
        }
      function u(t,n,r){
        return t.index=r,e?null!==(r=t.alternate)?(r=r.index)<n?(t.flags|=0x4000002,n):r:(t.flags|=0x4000002,n):(t.flags|=1048576,n)
        }
      function s(t){
        return e&&null===t.alternate&&(t.flags|=0x4000002),t
        }
      function c(e,t,n,r){
        return null===t||6!==t.tag?(t=r1(n,e.mode,r)).return=e:(t=i(t,n)).return=e,t
        }
      function f(e,t,n,r){
        var l=n.type;
        return l===lo?p(e,t,n.props.children,r,n.key):(null!==t&&(t.elementType===l||"object"==typeof l&&null!==l&&l.$$typeof===lg&&eC(l)===t.type)?eT(t=i(t,n.props),n):eT(t=rJ(n.type,n.key,n.props,null,e.mode,r),n),t.return=e,t)
        }
      function d(e,t,n,r){
        return null===t||4!==t.tag||t.stateNode.containerInfo!==n.containerInfo||t.stateNode.implementation!==n.implementation?(t=r3(n,e.mode,r)).return=e:(t=i(t,n.children||[])).return=e,t
        }
      function p(e,t,n,r,l){
        return null===t||7!==t.tag?(t=r0(n,e.mode,r,l)).return=e:(t=i(t,n)).return=e,t
        }
      function m(e,t,n){
        if("string"==typeof t&&""!==t||"number"==typeof t||"bigint"==typeof t)
        return(t=r1(""+t,e.mode,n)).return=e,t;
        if("object"==typeof t&&null!==t){
          switch(t.$$typeof){case la:
          return eT(n=rJ(t.type,t.key,t.props,null,e.mode,n),t),n.return=e,n;
          case li:
          return(t=r3(t,e.mode,n)).return=e,t;
          case lg:
          return m(e,t=eC(t),n)
          }
          if(lC(t)||o(t))
          return(t=r0(t,e.mode,n,null)).return=e,t;
          if("function"==typeof t.then)
          return m(e,ek(t),n);
          if(t.$$typeof===lf)
          return m(e,et(e,t),n);
          eE(e,t)
          }
        return null
        }
      function h(e,t,n,r){
        var l=null!==t?t.key:null;
        if("string"==typeof n&&""!==n||"number"==typeof n||"bigint"==typeof n)
        return null!==l?null:c(e,t,""+n,r);
        if("object"==typeof n&&null!==n){
          switch(n.$$typeof){case la:
          return n.key===l?f(e,t,n,r):null;
          case li:
          return n.key===l?d(e,t,n,r):null;
          case lg:
          return h(e,t,n=eC(n),r)
          }
          if(lC(n)||o(n))
          return null!==l?null:p(e,t,n,r,null);
          if("function"==typeof n.then)
          return h(e,t,ek(n),r);
          if(n.$$typeof===lf)
          return h(e,t,et(e,n),r);
          eE(e,n)
          }
        return null
        }
      function g(e,t,n,r,l){
        if("string"==typeof r&&""!==r||"number"==typeof r||"bigint"==typeof r)
        return c(t,e=e.get(n)||null,""+r,l);
        if("object"==typeof r&&null!==r){
          switch(r.$$typeof){case la:
          return f(t,e=e.get(null===r.key?n:r.key)||null,r,l);
          case li:
          return d(t,e=e.get(null===r.key?n:r.key)||null,r,l);
          case lg:
          return g(e,t,n,r=eC(r),l)
          }
          if(lC(r)||o(r))
          return p(t,e=e.get(n)||null,r,l,null);
          if("function"==typeof r.then)
          return g(e,t,n,ek(r),l);
          if(r.$$typeof===lf)
          return g(e,t,n,et(t,r),l);
          eE(t,r)
          }
        return null
        }
      return function(c,f,d,p){
        try{
          oF=0;
          var v=function t(c,f,d,p){
            if("object"==typeof d&&null!==d&&d.type===lo&&null===d.key&&(d=d.props.children),"object"==typeof d&&null!==d){
              switch(d.$$typeof){case la:
              n:{
                for(
                var v=d.key
                ;null!==f;){
                  if(f.key===v){
                    if((v=d.type)===lo){
                      if(7===f.tag){
                        l(c,f.sibling),(p=i(f,d.props.children)).return=c,c=p;
                        break n
                        }
                      }else 
                    if(f.elementType===v||"object"==typeof v&&null!==v&&v.$$typeof===lg&&eC(v)===f.type){
                      l(c,f.sibling),eT(p=i(f,d.props),d),p.return=c,c=p;
                      break n
                      }
                    l(c,f);
                    break
                    }
                  n(c,f),f=f.sibling
                  }
                d.type===lo?(p=r0(d.props.children,c.mode,p,d.key)).return=c:(eT(p=rJ(d.type,d.key,d.props,null,c.mode,p),d),p.return=c),c=p
                }
              return s(c);
              case li:
              n:{
                for(v=d.key;null!==f;){
                  if(f.key===v)
                  if(4===f.tag&&f.stateNode.containerInfo===d.containerInfo&&f.stateNode.implementation===d.implementation){
                    l(c,f.sibling),(p=i(f,d.children||[])).return=c,c=p;
                    break n
                    }else{
                    l(c,f);
                    break
                    }
                  n(c,f),f=f.sibling
                  }
                (p=r3(d,c.mode,p)).return=c,c=p
                }
              return s(c);
              case lg:
              return t(c,f,d=eC(d),p)
              }
              if(lC(d))
              return function(t,r,i,o){
                for(
                var s=null,c=null,f=r,d=r=0,p=null
                ;null!==f&&d<i.length;d++){
                  f.index>d?(p=f,f=null):p=f.sibling;
                  var v=h(t,f,i[d],o);
                  if(null===v){
                    null===f&&(f=p);
                    break
                    }
                  e&&f&&null===v.alternate&&n(t,f),r=u(v,r,d),null===c?s=v:c.sibling=v,c=v,f=p
                  }
                if(d===i.length)
                return l(t,f),on&&F(t,d),s;
                if(null===f){
                  for(;d<i.length;d++)
                  null!==(f=m(t,i[d],o))&&(r=u(f,r,d),null===c?s=f:c.sibling=f,c=f);
                  return on&&F(t,d),s
                  }
                for(f=a(f);d<i.length;d++)
                null!==(p=g(f,t,d,i[d],o))&&(e&&null!==p.alternate&&f.delete(null===p.key?d:p.key),r=u(p,r,d),null===c?s=p:c.sibling=p,c=p);
                return e&&f.forEach(function(e){
                  return n(t,e)
                  }),on&&F(t,d),s
                }(c,f,d,p);
              if(o(d)){
                if("function"!=typeof(v=o(d)))
                throw Error(r(150));
                return function(t,i,o,s){
                  if(null==o)
                  throw Error(r(151));
                  for(
                  var c=null,f=null,d=i,p=i=0,v=null,b=o.next()
                  ;null!==d&&!b.done;p++,b=o.next()){
                    d.index>p?(v=d,d=null):v=d.sibling;
                    var y=h(t,d,b.value,s);
                    if(null===y){
                      null===d&&(d=v);
                      break
                      }
                    e&&d&&null===y.alternate&&n(t,d),i=u(y,i,p),null===f?c=y:f.sibling=y,f=y,d=v
                    }
                  if(b.done)
                  return l(t,d),on&&F(t,p),c;
                  if(null===d){
                    for(;!b.done;p++,b=o.next())
                    null!==(b=m(t,b.value,s))&&(i=u(b,i,p),null===f?c=b:f.sibling=b,f=b);
                    return on&&F(t,p),c
                    }
                  for(d=a(d);!b.done;p++,b=o.next())
                  null!==(b=g(d,t,p,b.value,s))&&(e&&null!==b.alternate&&d.delete(null===b.key?p:b.key),i=u(b,i,p),null===f?c=b:f.sibling=b,f=b);
                  return e&&d.forEach(function(e){
                    return n(t,e)
                    }),on&&F(t,p),c
                  }(c,f,d=v.call(d),p)
                }
              if("function"==typeof d.then)
              return t(c,f,ek(d),p);
              if(d.$$typeof===lf)
              return t(c,f,et(c,d),p);
              eE(c,d)
              }
            return"string"==typeof d&&""!==d||"number"==typeof d||"bigint"==typeof d?(d=""+d,null!==f&&6===f.tag?(l(c,f.sibling),(p=i(f,d)).return=c):(l(c,f),(p=r1(d,c.mode,p)).return=c),s(c=p)):l(c,f)
            }(c,f,d,p);
          return oM=null,v
          }catch(e){
          if(e===oT||e===o_)
          throw e;
          var b=t(29,e,null,c.mode);
          return b.lanes=p,b.return=c,b
          }finally{
          }
        }
      }
    function eP(){
      for(
      var e=oA,t=oI=oA=0
      ;t<e;){
        var n=oN[t];
        oN[t++]=null;
        var r=oN[t];
        oN[t++]=null;
        var l=oN[t];
        oN[t++]=null;
        var a=oN[t];
        if(oN[t++]=null,null!==r&&null!==l){
          var i=r.pending;
          null===i?l.next=l:(l.next=i.next,i.next=l),r.pending=l
          }
        0!==a&&eL(n,l,a)
        }
      }
    function ez(e,t,n,r){
      oN[oA++]=e,oN[oA++]=t,oN[oA++]=n,oN[oA++]=r,oI|=r,e.lanes|=r,null!==(e=e.alternate)&&(e.lanes|=r)
      }
    function eM(e,t,n,r){
      return ez(e,t,n,r),eR(e)
      }
    function eF(e,t){
      return ez(e,null,null,t),eR(e)
      }
    function eL(e,t,n){
      e.lanes|=n;
      var r=e.alternate;
      null!==r&&(r.lanes|=n);
      for(
      var l=!1,a=e.return
      ;null!==a;)
      a.childLanes|=n,null!==(r=a.alternate)&&(r.childLanes|=n),22===a.tag&&(null===(e=a.stateNode)||1&e._visibility||(l=!0)),e=a,a=a.return;
      return 3===e.tag?(a=e.stateNode,l&&null!==t&&(l=31-i_(n),null===(r=(e=a.hiddenUpdates)[l])?e[l]=[t]:r.push(t),t.lane=0x20000000|n),a):null
      }
    function eR(e){
      if(50<uQ)
      throw uQ=0,u$=null,Error(r(185));
      for(
      var t=e.return
      ;null!==t;)
      t=(e=t).return;
      return 3===e.tag?e.stateNode:null
      }
    function eN(e){
      e.updateQueue={baseState:e.memoizedState,firstBaseUpdate:null,lastBaseUpdate:null,shared:{pending:null,lanes:0,hiddenCallbacks:null},callbacks:null}
      }
    function eA(e,t){
      e=e.updateQueue,t.updateQueue===e&&(t.updateQueue={baseState:e.baseState,firstBaseUpdate:e.firstBaseUpdate,lastBaseUpdate:e.lastBaseUpdate,shared:e.shared,callbacks:null})
      }
    function eI(e){
      return{lane:e,tag:0,payload:null,callback:null,next:null}
      }
    function eB(e,t,n){
      var r=e.updateQueue;
      if(null===r)
      return null;
      if(r=r.shared,(2&ug)!=0){
        var l=r.pending;
        return null===l?t.next=t:(t.next=l.next,l.next=t),r.pending=t,t=eR(e),eL(e,null,n),t
        }
      return ez(e,r,t,n),eR(e)
      }
    function ej(e,t,n){
      if(null!==(t=t.updateQueue)&&(t=t.shared,(4194048&n)!=0)){
        var r=t.lanes;
        r&=e.pendingLanes,n|=r,t.lanes=n,C(e,n)
        }
      }
    function eD(e,t){
      var n=e.updateQueue,r=e.alternate;
      if(null!==r&&n===(r=r.updateQueue)){
        var l=null,a=null;
        if(null!==(n=n.firstBaseUpdate)){
          do{
            var i={lane:n.lane,tag:n.tag,payload:n.payload,callback:null,next:null};
            null===a?l=a=i:a=a.next=i,n=n.next
            }while(null!==n)
          null===a?l=a=t:a=a.next=t
          }else 
        l=a=t;
        n={baseState:r.baseState,firstBaseUpdate:l,lastBaseUpdate:a,shared:r.shared,callbacks:r.callbacks},e.updateQueue=n;
        return
        }
      null===(e=n.lastBaseUpdate)?n.firstBaseUpdate=t:e.next=t,n.lastBaseUpdate=t
      }
    function eG(){
      if(oj){
        var e=ow;
        if(null!==e)
        throw e
        }
      }
    function eO(e,t,n,r){
      oj=!1;
      var l=e.updateQueue;
      oB=!1;
      var a=l.firstBaseUpdate,i=l.lastBaseUpdate,o=l.shared.pending;
      if(null!==o){
        l.shared.pending=null;
        var u=o,s=u.next;
        u.next=null,null===i?a=s:i.next=s,i=u;
        var c=e.alternate;
        null!==c&&(o=(c=c.updateQueue).lastBaseUpdate)!==i&&(null===o?c.firstBaseUpdate=s:o.next=s,c.lastBaseUpdate=u)
        }
      if(null!==a){
        var f=l.baseState;
        for(i=0,c=s=u=null,o=a;;){
          var d=-0x20000001&o.lane,p=d!==o.lane;
          if(p?(uy&d)===d:(r&d)===d){
            0!==d&&d===oC&&(oj=!0),null!==c&&(c=c.next={lane:0,tag:o.tag,payload:o.payload,callback:null,next:null});
            n:{
              var m=e,h=o;
              switch(d=t,h.tag){case 1:
              if("function"==typeof(m=h.payload)){
                f=m.call(n,f,d);
                break n
                }
              f=m;
              break n;
              case 3:
              m.flags=-65537&m.flags|128;
              case 0:
              if(null==(d="function"==typeof(m=h.payload)?m.call(n,f,d):m))
              break n;
              f=lr({},f,d);
              break n;
              case 2:
              oB=!0
              }
              }
            null!==(d=o.callback)&&(e.flags|=64,p&&(e.flags|=8192),null===(p=l.callbacks)?l.callbacks=[d]:p.push(d))
            }else 
          p={lane:d,tag:o.tag,payload:o.payload,callback:o.callback,next:null},null===c?(s=c=p,u=f):c=c.next=p,i|=d;
          if(null===(o=o.next)){
            if(null===(o=l.shared.pending))
            break;
            o=(p=o).next,p.next=null,l.lastBaseUpdate=p,l.shared.pending=null
            }
          }
        null===c&&(u=f),l.baseState=u,l.firstBaseUpdate=s,l.lastBaseUpdate=c,null===a&&(l.shared.lanes=0),u_|=i,e.lanes=i,e.memoizedState=f
        }
      }
    function eU(e,t){
      if("function"!=typeof e)
      throw Error(r(191,e));
      e.call(t)
      }
    function eH(e,t){
      var n=e.callbacks;
      if(null!==n)
      for(e.callbacks=null,e=0;e<n.length;e++)
      eU(n[e],t)
      }
    function eV(e,t){
      f(oG,e=uT),f(oD,t),uT=e|t.baseLanes
      }
    function eq(){
      f(oG,uT),f(oD,oD.current)
      }
    function eW(){
      uT=oG.current,c(oD),c(oG)
      }
    function eQ(e){
      var t=e.alternate;
      f(oH,1&oH.current),f(oO,e),null===oU&&(null===t||null!==oD.current||null!==t.memoizedState)&&(oU=e)
      }
    function e$(e){
      f(oH,oH.current),f(oO,e),null===oU&&(oU=e)
      }
    function eK(e){
      22===e.tag?(f(oH,oH.current),f(oO,e),null===oU&&(oU=e)):eX()
      }
    function eX(){
      f(oH,oH.current),f(oO,oO.current)
      }
    function eY(e){
      c(oO),oU===e&&(oU=null),c(oH)
      }
    function eZ(e){
      for(
      var t=e
      ;null!==t;){
        if(13===t.tag){
          var n=t.memoizedState;
          if(null!==n&&(null===(n=n.dehydrated)||aP(n)||az(n)))
          return t
          }else 
        if(19===t.tag&&("forwards"===t.memoizedProps.revealOrder||"backwards"===t.memoizedProps.revealOrder||"unstable_legacy-backwards"===t.memoizedProps.revealOrder||"together"===t.memoizedProps.revealOrder)){
          if((128&t.flags)!=0)
          return t
          }else 
        if(null!==t.child){
          t.child.return=t,t=t.child;
          continue
          }
        if(t===e)
        break;
        for(;null===t.sibling;){
          if(null===t.return||t.return===e)
          return null;
          t=t.return
          }
        t.sibling.return=t.return,t=t.sibling
        }
      return null
      }
    function eJ(){
      throw Error(r(321))
      }
    function e0(e,t){
      if(null===t)
      return!1;
      for(
      var n=0
      ;n<t.length&&n<e.length;n++)
      if(!iW(e[n],t[n]))
      return!1;
      return!0
      }
    function e1(e,t,n,r,l,a){
      return oV=a,oq=t,t.memoizedState=null,t.updateQueue=null,t.lanes=0,lw.H=null===e||null===e.memoizedState?o2:o3,oX=!1,a=n(r,l),oX=!1,oK&&(a=e3(t,n,r,l)),e2(e),a
      }
    function e2(e){
      lw.H=o1;
      var t=null!==oW&&null!==oW.next;
      if(oV=0,oQ=oW=oq=null,o$=!1,oZ=0,oJ=null,t)
      throw Error(r(300));
      null===e||o8||null!==(e=e.dependencies)&&Z(e)&&(o8=!0)
      }
    function e3(e,t,n,l){
      oq=e;
      var a=0;
      do{
        if(oK&&(oJ=null),oZ=0,oK=!1,25<=a)
        throw Error(r(301));
        if(a+=1,oQ=oW=null,null!=e.updateQueue){
          var i=e.updateQueue;
          i.lastEffect=null,i.events=null,i.stores=null,null!=i.memoCache&&(i.memoCache.index=0)
          }
        lw.H=o4,i=t(n,l)
        }while(oK)
      return i
      }
    function e4(){
      var e=lw.H,t=e.useState()[0];
      return t="function"==typeof t.then?tt(t):t,e=e.useState()[0],(null!==oW?oW.memoizedState:null)!==e&&(oq.flags|=1024),t
      }
    function e5(){
      var e=0!==oY;
      return oY=0,e
      }
    function e6(e,t,n){
      t.updateQueue=e.updateQueue,t.flags&=-2053,e.lanes&=~n
      }
    function e8(e){
      if(o$){
        for(e=e.memoizedState;null!==e;){
          var t=e.queue;
          null!==t&&(t.pending=null),e=e.next
          }
        o$=!1
        }
      oV=0,oQ=oW=oq=null,oK=!1,oZ=oY=0,oJ=null
      }
    function e7(){
      var e={memoizedState:null,baseState:null,baseQueue:null,queue:null,next:null};
      return null===oQ?oq.memoizedState=oQ=e:oQ=oQ.next=e,oQ
      }
    function e9(){
      if(null===oW){
        var e=oq.alternate;
        e=null!==e?e.memoizedState:null
        }else 
      e=oW.next;
      var t=null===oQ?oq.memoizedState:oQ.next;
      if(null!==t)
      oQ=t,oW=e;
      else{
        if(null===e)
        throw null===oq.alternate?Error(r(467)):Error(r(310));
        e={memoizedState:(oW=e).memoizedState,baseState:oW.baseState,baseQueue:oW.baseQueue,queue:oW.queue,next:null},null===oQ?oq.memoizedState=oQ=e:oQ=oQ.next=e
        }
      return oQ
      }
    function te(){
      return{lastEffect:null,events:null,stores:null,memoCache:null}
      }
    function tt(e){
      var t=oZ;
      return oZ+=1,null===oJ&&(oJ=[]),e=eS(oJ,e,t),t=oq,(null===oQ?t.memoizedState:oQ.next)===null&&(lw.H=null===(t=t.alternate)||null===t.memoizedState?o2:o3),e
      }
    function tn(e){
      if(null!==e&&"object"==typeof e){
        if("function"==typeof e.then)
        return tt(e);
        if(e.$$typeof===lf)
        return ee(e)
        }
      throw Error(r(438,String(e)))
      }
    function tr(e){
      var t=null,n=oq.updateQueue;
      if(null!==n&&(t=n.memoCache),null==t){
        var r=oq.alternate;
        null!==r&&null!==(r=r.updateQueue)&&null!=(r=r.memoCache)&&(t={data:r.data.map(function(e){
          return e.slice()
          }),index:0})
        }
      if(null==t&&(t={data:[],index:0}),null===n&&(n=te(),oq.updateQueue=n),n.memoCache=t,void 0===(n=t.data[t.index]))
      for(n=t.data[t.index]=Array(e),r=0;r<e;r++)
      n[r]=lb;
      return t.index++,n
      }
    function tl(e,t){
      return"function"==typeof t?t(e):t
      }
    function ta(e){
      return ti(e9(),oW,e)
      }
    function ti(e,t,n){
      var l=e.queue;
      if(null===l)
      throw Error(r(311));
      l.lastRenderedReducer=n;
      var a=e.baseQueue,i=l.pending;
      if(null!==i){
        if(null!==a){
          var o=a.next;
          a.next=i.next,i.next=o
          }
        t.baseQueue=a=i,l.pending=null
        }
      if(i=e.baseState,null===a)
      e.memoizedState=i;
      else{
        t=a.next;
        var u=o=null,s=null,c=t,f=!1;
        do{
          var d=-0x20000001&c.lane;
          if(d!==c.lane?(uy&d)===d:(oV&d)===d){
            var p=c.revertLane;
            if(0===p)
            null!==s&&(s=s.next={lane:0,revertLane:0,gesture:null,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null}),d===oC&&(f=!0);
            else 
            if((oV&p)===p){
              c=c.next,p===oC&&(f=!0);
              continue
              }else 
            d={lane:0,revertLane:c.revertLane,gesture:null,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null},null===s?(u=s=d,o=i):s=s.next=d,oq.lanes|=p,u_|=p;
            d=c.action,oX&&n(i,d),i=c.hasEagerState?c.eagerState:n(i,d)
            }else 
          p={lane:d,revertLane:c.revertLane,gesture:c.gesture,action:c.action,hasEagerState:c.hasEagerState,eagerState:c.eagerState,next:null},null===s?(u=s=p,o=i):s=s.next=p,oq.lanes|=d,u_|=d;
          c=c.next
          }while(null!==c&&c!==t)
        if(null===s?o=i:s.next=u,!iW(i,e.memoizedState)&&(o8=!0,f&&null!==(n=ow)))
        throw n;
        e.memoizedState=i,e.baseState=o,e.baseQueue=s,l.lastRenderedState=i
        }
      return null===a&&(l.lanes=0),[e.memoizedState,l.dispatch]
      }
    function to(e){
      var t=e9(),n=t.queue;
      if(null===n)
      throw Error(r(311));
      n.lastRenderedReducer=e;
      var l=n.dispatch,a=n.pending,i=t.memoizedState;
      if(null!==a){
        n.pending=null;
        var o=a=a.next;
        do 
        i=e(i,o.action),o=o.next;
        while(o!==a)
        iW(i,t.memoizedState)||(o8=!0),t.memoizedState=i,null===t.baseQueue&&(t.baseState=i),n.lastRenderedState=i
        }
      return[i,l]
      }
    function tu(e,t,n){
      var l=oq,a=e9(),i=on;
      if(i){
        if(void 0===n)
        throw Error(r(407));
        n=n()
        }else 
      n=t();
      var o=!iW((oW||a).memoizedState,n);
      if(o&&(a.memoizedState=n,o8=!0),a=a.queue,tR(tf.bind(null,l,a,e),[e]),a.getSnapshot!==t||o||null!==oQ&&1&oQ.memoizedState.tag){
        if(l.flags|=2048,tP(9,{destroy:void 0},tc.bind(null,l,a,n,t),null),null===uv)
        throw Error(r(349));
        i||(127&oV)!=0||ts(l,t,n)
        }
      return n
      }
    function ts(e,t,n){
      e.flags|=16384,e={getSnapshot:t,value:n},null===(t=oq.updateQueue)?(t=te(),oq.updateQueue=t,t.stores=[e]):null===(n=t.stores)?t.stores=[e]:n.push(e)
      }
    function tc(e,t,n,r){
      t.value=n,t.getSnapshot=r,td(t)&&tp(e)
      }
    function tf(e,t,n){
      return n(function(){
        td(t)&&tp(e)
        })
      }
    function td(e){
      var t=e.getSnapshot;
      e=e.value;
      try{
        var n=t();
        return!iW(e,n)
        }catch{
        return!0
        }
      }
    function tp(e){
      var t=eF(e,2);
      null!==t&&rv(t,e,2)
      }
    function tm(e){
      var t=e7();
      if("function"==typeof e){
        var n=e;
        if(e=n(),oX){
          T(!0);
          try{
            n()
            }finally{
            T(!1)
            }
          }
        }
      return t.memoizedState=t.baseState=e,t.queue={pending:null,lanes:0,dispatch:null,lastRenderedReducer:tl,lastRenderedState:e},t
      }
    function th(e,t,n,r){
      return e.baseState=n,ti(e,oW,"function"==typeof r?r:tl)
      }
    function tg(e,t,n,l,a){
      if(t0(e))
      throw Error(r(485));
      if(null!==(e=t.action)){
        var i={payload:a,action:e,next:null,isTransition:!0,status:"pending",value:null,reason:null,listeners:[],then:function(e){
          i.listeners.push(e)
          }};
        null!==lw.T?n(!0):i.isTransition=!1,l(i),null===(n=t.pending)?(i.next=t.pending=i,tv(t,i)):(i.next=n.next,t.pending=n.next=i)
        }
      }
    function tv(e,t){
      var n=t.action,r=t.payload,l=e.state;
      if(t.isTransition){
        var a=lw.T,i={};
        lw.T=i;
        try{
          var o=n(l,r),u=lw.S;
          null!==u&&u(i,o),tb(e,t,o)
          }catch(n){
          tS(e,t,n)
          }finally{
          null!==a&&null!==i.types&&(a.types=i.types),lw.T=a
          }
        }else 
      try{
        a=n(l,r),tb(e,t,a)
        }catch(n){
        tS(e,t,n)
        }
      }
    function tb(e,t,n){
      null!==n&&"object"==typeof n&&"function"==typeof n.then?n.then(function(n){
        ty(e,t,n)
        },function(n){
        return tS(e,t,n)
        }):ty(e,t,n)
      }
    function ty(e,t,n){
      t.status="fulfilled",t.value=n,tC(t),e.state=n,null!==(t=e.pending)&&((n=t.next)===t?e.pending=null:(n=n.next,t.next=n,tv(e,n)))
      }
    function tS(e,t,n){
      var r=e.pending;
      if(e.pending=null,null!==r){
        r=r.next;
        do 
        t.status="rejected",t.reason=n,tC(t),t=t.next;
        while(t!==r)
        }
      e.action=null
      }
    function tC(e){
      e=e.listeners;
      for(
      var t=0
      ;t<e.length;t++)
      (0,e[t])()
      }
    function tw(e,t){
      return t
      }
    function tx(e,t){
      if(on){
        var n=uv.formState;
        if(null!==n){
          n:{
            var r=oq;
            if(on){
              if(ot){
                var l=aL(ot,ol);
                if(l){
                  ot=aN(l),r=aR(l);
                  break n
                  }
                }
              G(r)
              }
            r=!1
            }
          r&&(t=n[0])
          }
        }
      (n=e7()).memoizedState=n.baseState=t,r={pending:null,lanes:0,dispatch:null,lastRenderedReducer:tw,lastRenderedState:t},n.queue=r,n=tY.bind(null,oq,r),r.dispatch=n,r=tm(!1);
      var a=tJ.bind(null,oq,!1,r.queue);
      return r=e7(),l={state:t,dispatch:null,action:e,pending:null},r.queue=l,n=tg.bind(null,oq,l,a,n),l.dispatch=n,r.memoizedState=e,[t,n,!1]
      }
    function tk(e){
      return tT(e9(),oW,e)
      }
    function tT(e,t,n){
      if(t=ti(e,t,tw)[0],e=ta(tl)[0],"object"==typeof t&&null!==t&&"function"==typeof t.then)
      try{
        var r=tt(t)
        }catch(e){
        throw e===oT?o_:e
        }
      else 
      r=t;
      var l=(t=e9()).queue,a=l.dispatch;
      return n!==t.memoizedState&&(oq.flags|=2048,tP(9,{destroy:void 0},tE.bind(null,l,n),null)),[r,a,e]
      }
    function tE(e,t){
      e.action=t
      }
    function t_(e){
      var t=e9(),n=oW;
      if(null!==n)
      return tT(t,n,e);
      e9(),t=t.memoizedState;
      var r=(n=e9()).queue.dispatch;
      return n.memoizedState=e,[t,r,!1]
      }
    function tP(e,t,n,r){
      return e={tag:e,create:n,deps:r,inst:t,next:null},null===(t=oq.updateQueue)&&(t=te(),oq.updateQueue=t),null===(n=t.lastEffect)?t.lastEffect=e.next=e:(r=n.next,n.next=e,e.next=r,t.lastEffect=e),e
      }
    function tz(){
      return e9().memoizedState
      }
    function tM(e,t,n,r){
      var l=e7();
      oq.flags|=e,l.memoizedState=tP(1|t,{destroy:void 0},n,void 0===r?null:r)
      }
    function tF(e,t,n,r){
      var l=e9();
      r=void 0===r?null:r;
      var a=l.memoizedState.inst;
      null!==oW&&null!==r&&e0(r,oW.memoizedState.deps)?l.memoizedState=tP(t,a,n,r):(oq.flags|=e,l.memoizedState=tP(1|t,a,n,r))
      }
    function tL(e,t){
      tM(8390656,8,e,t)
      }
    function tR(e,t){
      tF(2048,8,e,t)
      }
    function tN(e){
      var t=e9().memoizedState;
      return function(e){
        oq.flags|=4;
        var t=oq.updateQueue;
        if(null===t)
        t=te(),oq.updateQueue=t,t.events=[e];
        else{
          var n=t.events;
          null===n?t.events=[e]:n.push(e)
          }
        }({ref:t,nextImpl:e}),function(){
        if((2&ug)!=0)
        throw Error(r(440));
        return t.impl.apply(void 0,arguments)
        }
      }
    function tA(e,t){
      return tF(4,2,e,t)
      }
    function tI(e,t){
      return tF(4,4,e,t)
      }
    function tB(e,t){
      if("function"==typeof t){
        var n=t(e=e());
        return function(){
          "function"==typeof n?n():t(null)
          }
        }
      if(null!=t)
      return t.current=e=e(),function(){
        t.current=null
        }
      }
    function tj(e,t,n){
      n=null!=n?n.concat([e]):null,tF(4,4,tB.bind(null,t,e),n)
      }
    function tD(){
      }
    function tG(e,t){
      var n=e9();
      t=void 0===t?null:t;
      var r=n.memoizedState;
      return null!==t&&e0(t,r[1])?r[0]:(n.memoizedState=[e,t],e)
      }
    function tO(e,t){
      var n=e9();
      t=void 0===t?null:t;
      var r=n.memoizedState;
      if(null!==t&&e0(t,r[1]))
      return r[0];
      if(r=e(),oX){
        T(!0);
        try{
          e()
          }finally{
          T(!1)
          }
        }
      return n.memoizedState=[r,t],r
      }
    function tU(e,t,n){
      return void 0===n||(0x40000000&oV)!=0&&(261930&uy)==0?e.memoizedState=t:(e.memoizedState=n,e=rg(),oq.lanes|=e,u_|=e,n)
      }
    function tH(e,t,n,r){
      return iW(n,t)?n:null!==oD.current?(iW(e=tU(e,n,r),t)||(o8=!0),e):(42&oV)==0||(0x40000000&oV)!=0&&(261930&uy)==0?(o8=!0,e.memoizedState=n):(e=rg(),oq.lanes|=e,u_|=e,t)
      }
    function tV(e,t,n,r,l){
      var a=lW();
      lq(0!==a&&8>a?a:8);
      var i=lw.T,o={};
      lw.T=o,tJ(e,!1,t,n);
      try{
        var u=l(),s=lw.S;
        if(null!==s&&s(o,u),null!==u&&"object"==typeof u&&"function"==typeof u.then){
          var c,f,d=(c=[],f={status:"pending",value:null,reason:null,then:function(e){
            c.push(e)
            }},u.then(function(){
            f.status="fulfilled",f.value=r;
            for(
            var e=0
            ;e<c.length;e++)
            (0,c[e])(r)
            },function(e){
            for(f.status="rejected",f.reason=e,e=0;e<c.length;e++)
            (0,c[e])(void 0)
            }),f);
          tZ(e,t,d,rh(e))
          }else 
        tZ(e,t,r,rh(e))
        }catch(n){
        tZ(e,t,{then:function(){
          },status:"rejected",reason:n},rh())
        }finally{
        lq(a),null!==i&&null!==o.types&&(i.types=o.types),lw.T=i
        }
      }
    function tq(e){
      var t=e.memoizedState;
      if(null!==t)
      return t;
      var n={};
      return(t={memoizedState:l3,baseState:l3,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:tl,lastRenderedState:l3},next:null}).next={memoizedState:n,baseState:n,baseQueue:null,queue:{pending:null,lanes:0,dispatch:null,lastRenderedReducer:tl,lastRenderedState:n},next:null},e.memoizedState=t,null!==(e=e.alternate)&&(e.memoizedState=t),t
      }
    function tW(){
      return ee(l4)
      }
    function tQ(){
      return e9().memoizedState
      }
    function t$(){
      return e9().memoizedState
      }
    function tK(e){
      for(
      var t=e.return
      ;null!==t;){
        switch(t.tag){case 24:case 3:
        var n=rh(),r=eB(t,e=eI(n),n);
        null!==r&&(rv(r,t,n),ej(r,t,n)),t={cache:er()},e.payload=t;
        return
        }
        t=t.return
        }
      }
    function tX(e,t,n){
      var r=rh();
      n={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null},t0(e)?t1(t,n):null!==(n=eM(e,t,n,r))&&(rv(n,e,r),t2(n,t,r))
      }
    function tY(e,t,n){
      tZ(e,t,n,rh())
      }
    function tZ(e,t,n,r){
      var l={lane:r,revertLane:0,gesture:null,action:n,hasEagerState:!1,eagerState:null,next:null};
      if(t0(e))
      t1(t,l);
      else{
        var a=e.alternate;
        if(0===e.lanes&&(null===a||0===a.lanes)&&null!==(a=t.lastRenderedReducer))
        try{
          var i=t.lastRenderedState,o=a(i,n);
          if(l.hasEagerState=!0,l.eagerState=o,iW(o,i))
          return ez(e,t,l,0),null===uv&&eP(),!1
          }catch{
          }finally{
          }
        if(null!==(n=eM(e,t,l,r)))
        return rv(n,e,r),t2(n,t,r),!0
        }
      return!1
      }
    function tJ(e,t,n,l){
      if(l={lane:2,revertLane:ep(),gesture:null,action:l,hasEagerState:!1,eagerState:null,next:null},t0(e)){
        if(t)
        throw Error(r(479))
        }else 
      null!==(t=eM(e,n,l,2))&&rv(t,e,2)
      }
    function t0(e){
      var t=e.alternate;
      return e===oq||null!==t&&t===oq
      }
    function t1(e,t){
      oK=o$=!0;
      var n=e.pending;
      null===n?t.next=t:(t.next=n.next,n.next=t),e.pending=t
      }
    function t2(e,t,n){
      if((4194048&n)!=0){
        var r=t.lanes;
        r&=e.pendingLanes,t.lanes=n|=r,C(e,n)
        }
      }
    function t3(e,t,n,r){
      n=null==(n=n(r,t=e.memoizedState))?t:lr({},t,n),e.memoizedState=n,0===e.lanes&&(e.updateQueue.baseState=n)
      }
    function t4(e,t,n,r,l,a,i){
      return"function"==typeof(e=e.stateNode).shouldComponentUpdate?e.shouldComponentUpdate(r,a,i):!t.prototype||!t.prototype.isPureReactComponent||!eb(n,r)||!eb(l,a)
      }
    function t5(e,t,n,r){
      e=t.state,"function"==typeof t.componentWillReceiveProps&&t.componentWillReceiveProps(n,r),"function"==typeof t.UNSAFE_componentWillReceiveProps&&t.UNSAFE_componentWillReceiveProps(n,r),t.state!==e&&o5.enqueueReplaceState(t,t.state,null)
      }
    function t6(e,t){
      var n=t;
      if("ref"in t)
      for(
      var r
       in n={},t)
      "ref"!==r&&(n[r]=t[r]);
      if(e=e.defaultProps)
      for(
      var l
       in n===t&&(n=lr({},n)),e)
      void 0===n[l]&&(n[l]=e[l]);
      return n
      }
    function t8(e,t){
      try{
        (0,e.onUncaughtError)(t.value,{componentStack:t.stack})
        }catch(e){
        setTimeout(function(){
          throw e
          })
        }
      }
    function t7(e,t,n){
      try{
        (0,e.onCaughtError)(n.value,{componentStack:n.stack,errorBoundary:1===t.tag?t.stateNode:null})
        }catch(e){
        setTimeout(function(){
          throw e
          })
        }
      }
    function t9(e,t,n){
      return(n=eI(n)).tag=3,n.payload={element:null},n.callback=function(){
        t8(e,t)
        },n
      }
    function ne(e){
      return(e=eI(e)).tag=3,e
      }
    function nt(e,t,n,r){
      var l=n.type.getDerivedStateFromError;
      if("function"==typeof l){
        var a=r.value;
        e.payload=function(){
          return l(a)
          },e.callback=function(){
          t7(t,n,r)
          }
        }
      var i=n.stateNode;
      null!==i&&"function"==typeof i.componentDidCatch&&(e.callback=function(){
        t7(t,n,r),"function"!=typeof l&&(null===uD?uD=new Set([this]):uD.add(this));
        var e=r.stack;
        this.componentDidCatch(r.value,{componentStack:null!==e?e:""})
        })
      }
    function nn(e,t,n,r){
      t.child=null===e?oR(t,null,n,r):oL(t,e.child,n,r)
      }
    function nr(e,t,n,r,l){
      n=n.render;
      var a=t.ref;
      if("ref"in r){
        var i={};
        for(
        var o
         in r)
        "ref"!==o&&(i[o]=r[o])
        }else 
      i=r;
      return J(t),r=e1(e,t,n,i,a,l),o=e5(),null===e||o8?(on&&o&&R(t),t.flags|=1,nn(e,t,r,l),t.child):(e6(e,t,l),nT(e,t,l))
      }
    function nl(e,t,n,r,l){
      if(null===e){
        var a=n.type;
        return"function"!=typeof a||rX(a)||void 0!==a.defaultProps||null!==n.compare?((e=rJ(n.type,null,r,t,t.mode,l)).ref=t.ref,e.return=t,t.child=e):(t.tag=15,t.type=a,na(e,t,a,r,l))
        }
      if(a=e.child,!nE(e,l)){
        var i=a.memoizedProps;
        if((n=null!==(n=n.compare)?n:eb)(i,r)&&e.ref===t.ref)
        return nT(e,t,l)
        }
      return t.flags|=1,(e=rY(a,r)).ref=t.ref,e.return=t,t.child=e
      }
    function na(e,t,n,r,l){
      if(null!==e){
        var a=e.memoizedProps;
        if(eb(a,r)&&e.ref===t.ref)
        if(o8=!1,t.pendingProps=r=a,!nE(e,l))
        return t.lanes=e.lanes,nT(e,t,l);
        else
        (131072&e.flags)!=0&&(o8=!0)
        }
      return nd(e,t,n,r,l)
      }
    function ni(e,t,n,r){
      var l=r.children,a=null!==e?e.memoizedState:null;
      if(null===e&&null===t.stateNode&&(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),"hidden"===r.mode){
        if((128&t.flags)!=0){
          if(a=null!==a?a.baseLanes|n:n,null!==e){
            for(r=t.child=e.child,l=0;null!==r;)
            l=l|r.lanes|r.childLanes,r=r.sibling;
            r=l&~a
            }else 
          r=0,t.child=null;
          return nu(e,t,a,n,r)
          }
        if((0x20000000&n)==0)
        return r=t.lanes=0x20000000,nu(e,t,null!==a?a.baseLanes|n:n,n,r);
        t.memoizedState={baseLanes:0,cachePool:null},null!==e&&eg(t,null!==a?a.cachePool:null),null!==a?eV(t,a):eq(),eK(t)
        }else 
      null!==a?(eg(t,a.cachePool),eV(t,a),eX(),t.memoizedState=null):(null!==e&&eg(t,null),eq(),eX());
      return nn(e,t,l,n),t.child
      }
    function no(e,t){
      return null!==e&&22===e.tag||null!==t.stateNode||(t.stateNode={_visibility:1,_pendingMarkers:null,_retryCache:null,_transitions:null}),t.sibling
      }
    function nu(e,t,n,r,l){
      var a=eh();
      return t.memoizedState={baseLanes:n,cachePool:a=null===a?null:{parent:lD?od._currentValue:od._currentValue2,pool:a}},null!==e&&eg(t,null),eq(),eK(t),null!==e&&Y(e,t,r,!0),t.childLanes=l,null
      }
    function ns(e,t){
      return(t=nS({mode:t.mode,children:t.children},e.mode)).ref=e.ref,e.child=t,t.return=e,t
      }
    function nc(e,t,n){
      return oL(t,e.child,null,n),e=ns(t,t.pendingProps),e.flags|=2,eY(t),t.memoizedState=null,e
      }
    function nf(e,t){
      var n=t.ref;
      if(null===n)
      null!==e&&null!==e.ref&&(t.flags|=4194816);
      else{
        if("function"!=typeof n&&"object"!=typeof n)
        throw Error(r(284));
        (null===e||e.ref!==n)&&(t.flags|=4194816)
        }
      }
    function nd(e,t,n,r,l){
      return J(t),n=e1(e,t,n,r,void 0,l),r=e5(),null===e||o8?(on&&r&&R(t),t.flags|=1,nn(e,t,n,l),t.child):(e6(e,t,l),nT(e,t,l))
      }
    function np(e,t,n,r,l,a){
      return J(t),t.updateQueue=null,n=e3(t,r,n,l),e2(e),r=e5(),null===e||o8?(on&&r&&R(t),t.flags|=1,nn(e,t,n,a),t.child):(e6(e,t,a),nT(e,t,a))
      }
    function nm(e,t,n,r,l){
      if(J(t),null===t.stateNode){
        var a=iE,i=n.contextType;
        "object"==typeof i&&null!==i&&(a=ee(i)),t.memoizedState=null!==(a=new n(r,a)).state&&void 0!==a.state?a.state:null,a.updater=o5,t.stateNode=a,a._reactInternals=t,(a=t.stateNode).props=r,a.state=t.memoizedState,a.refs={},eN(t),i=n.contextType,a.context="object"==typeof i&&null!==i?ee(i):iE,a.state=t.memoizedState,"function"==typeof(i=n.getDerivedStateFromProps)&&(t3(t,n,i,r),a.state=t.memoizedState),"function"==typeof n.getDerivedStateFromProps||"function"==typeof a.getSnapshotBeforeUpdate||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||(i=a.state,"function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount(),i!==a.state&&o5.enqueueReplaceState(a,a.state,null),eO(t,r,a,l),eG(),a.state=t.memoizedState),"function"==typeof a.componentDidMount&&(t.flags|=4194308),r=!0
        }else 
      if(null===e){
        a=t.stateNode;
        var o=t.memoizedProps,u=t6(n,o);
        a.props=u;
        var s=a.context,c=n.contextType;
        i=iE,"object"==typeof c&&null!==c&&(i=ee(c));
        var f=n.getDerivedStateFromProps;
        c="function"==typeof f||"function"==typeof a.getSnapshotBeforeUpdate,o=t.pendingProps!==o,c||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(o||s!==i)&&t5(t,a,r,i),oB=!1;
        var d=t.memoizedState;
        a.state=d,eO(t,r,a,l),eG(),s=t.memoizedState,o||d!==s||oB?("function"==typeof f&&(t3(t,n,f,r),s=t.memoizedState),(u=oB||t4(t,n,u,r,d,s,i))?(c||"function"!=typeof a.UNSAFE_componentWillMount&&"function"!=typeof a.componentWillMount||("function"==typeof a.componentWillMount&&a.componentWillMount(),"function"==typeof a.UNSAFE_componentWillMount&&a.UNSAFE_componentWillMount()),"function"==typeof a.componentDidMount&&(t.flags|=4194308)):("function"==typeof a.componentDidMount&&(t.flags|=4194308),t.memoizedProps=r,t.memoizedState=s),a.props=r,a.state=s,a.context=i,r=u):("function"==typeof a.componentDidMount&&(t.flags|=4194308),r=!1)
        }else{
        a=t.stateNode,eA(e,t),c=t6(n,i=t.memoizedProps),a.props=c,f=t.pendingProps,d=a.context,s=n.contextType,u=iE,"object"==typeof s&&null!==s&&(u=ee(s)),(s="function"==typeof(o=n.getDerivedStateFromProps)||"function"==typeof a.getSnapshotBeforeUpdate)||"function"!=typeof a.UNSAFE_componentWillReceiveProps&&"function"!=typeof a.componentWillReceiveProps||(i!==f||d!==u)&&t5(t,a,r,u),oB=!1,d=t.memoizedState,a.state=d,eO(t,r,a,l),eG();
        var p=t.memoizedState;
        i!==f||d!==p||oB||null!==e&&null!==e.dependencies&&Z(e.dependencies)?("function"==typeof o&&(t3(t,n,o,r),p=t.memoizedState),(c=oB||t4(t,n,c,r,d,p,u)||null!==e&&null!==e.dependencies&&Z(e.dependencies))?(s||"function"!=typeof a.UNSAFE_componentWillUpdate&&"function"!=typeof a.componentWillUpdate||("function"==typeof a.componentWillUpdate&&a.componentWillUpdate(r,p,u),"function"==typeof a.UNSAFE_componentWillUpdate&&a.UNSAFE_componentWillUpdate(r,p,u)),"function"==typeof a.componentDidUpdate&&(t.flags|=4),"function"==typeof a.getSnapshotBeforeUpdate&&(t.flags|=1024)):("function"!=typeof a.componentDidUpdate||i===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||i===e.memoizedProps&&d===e.memoizedState||(t.flags|=1024),t.memoizedProps=r,t.memoizedState=p),a.props=r,a.state=p,a.context=u,r=c):("function"!=typeof a.componentDidUpdate||i===e.memoizedProps&&d===e.memoizedState||(t.flags|=4),"function"!=typeof a.getSnapshotBeforeUpdate||i===e.memoizedProps&&d===e.memoizedState||(t.flags|=1024),r=!1)
        }
      return a=r,nf(e,t),r=(128&t.flags)!=0,a||r?(a=t.stateNode,n=r&&"function"!=typeof n.getDerivedStateFromError?null:a.render(),t.flags|=1,null!==e&&r?(t.child=oL(t,e.child,null,l),t.child=oL(t,null,n,l)):nn(e,t,n,l),t.memoizedState=a.state,e=t.child):e=nT(e,t,l),e
      }
    function nh(e,t,n,r){
      return V(),t.flags|=256,nn(e,t,n,r),t.child
      }
    function ng(e){
      return{baseLanes:e,cachePool:ev()}
      }
    function nv(e,t,n){
      return e=null!==e?e.childLanes&~n:0,t&&(e|=uM),e
      }
    function nb(e,t,n){
      var l,a=t.pendingProps,i=!1,o=(128&t.flags)!=0;
      if((l=o)||(l=(null===e||null!==e.memoizedState)&&(2&oH.current)!=0),l&&(i=!0,t.flags&=-129),l=(32&t.flags)!=0,t.flags&=-33,null===e){
        if(on){
          if(i?eQ(t):eX(),(e=ot)?null!==(e=aV(e,ol))&&(t.memoizedState={dehydrated:e,treeContext:null!==i3?{id:i4,overflow:i5}:null,retryLane:0x20000000,hydrationErrors:null},(n=r2(e)).return=t,t.child=n,oe=t,ot=null):e=null,null===e)
          throw G(t);
          return az(e)?t.lanes=32:t.lanes=0x20000000,null
          }
        var u=a.children;
        return a=a.fallback,i?(eX(),u=nS({mode:"hidden",children:u},i=t.mode),a=r0(a,i,n,null),u.return=t,a.return=t,u.sibling=a,t.child=u,(a=t.child).memoizedState=ng(n),a.childLanes=nv(e,l,n),t.memoizedState=o7,no(null,a)):(eQ(t),ny(t,u))
        }
      var s=e.memoizedState;
      if(null!==s&&null!==(u=s.dehydrated)){
        if(o)
        256&t.flags?(eQ(t),t.flags&=-257,t=nC(e,t,n)):null!==t.memoizedState?(eX(),t.child=e.child,t.flags|=128,t=null):(eX(),u=a.fallback,i=t.mode,a=nS({mode:"visible",children:a.children},i),u=r0(u,i,n,null),u.flags|=2,a.return=t,u.return=t,a.sibling=u,t.child=a,oL(t,e.child,null,n),(a=t.child).memoizedState=ng(n),a.childLanes=nv(e,l,n),t.memoizedState=o7,t=no(null,a));
        else 
        if(eQ(t),az(u))
        l=aM(u).digest,(a=Error(r(419))).stack="",a.digest=l,W({value:a,source:null,stack:null}),t=nC(e,t,n);
        else 
        if(o8||Y(e,t,n,!1),l=(n&e.childLanes)!=0,o8||l){
          if(null!==(l=uv)&&0!==(a=w(l,n))&&a!==s.retryLane)
          throw s.retryLane=a,eF(e,a),rv(l,e,a),o6;
          aP(u)||rP(),t=nC(e,t,n)
          }else 
        aP(u)?(t.flags|=192,t.child=e.child,t=null):(e=s.treeContext,lU&&(ot=aD(u),oe=t,on=!0,or=null,ol=!1,null!==e&&A(t,e)),t=ny(t,a.children),t.flags|=4096);
        return t
        }
      return i?(eX(),u=a.fallback,i=t.mode,o=(s=e.child).sibling,(a=rY(s,{mode:"hidden",children:a.children})).subtreeFlags=0x3e00000&s.subtreeFlags,null!==o?u=rY(o,u):(u=r0(u,i,n,null),u.flags|=2),u.return=t,a.return=t,a.sibling=u,t.child=a,no(null,a),a=t.child,null===(u=e.child.memoizedState)?u=ng(n):(null!==(i=u.cachePool)?(s=lD?od._currentValue:od._currentValue2,i=i.parent!==s?{parent:s,pool:s}:i):i=ev(),u={baseLanes:u.baseLanes|n,cachePool:i}),a.memoizedState=u,a.childLanes=nv(e,l,n),t.memoizedState=o7,no(e.child,a)):(eQ(t),e=(n=e.child).sibling,(n=rY(n,{mode:"visible",children:a.children})).return=t,n.sibling=null,null!==e&&(null===(l=t.deletions)?(t.deletions=[e],t.flags|=16):l.push(e)),t.child=n,t.memoizedState=null,n)
      }
    function ny(e,t){
      return(t=nS({mode:"visible",children:t},e.mode)).return=e,e.child=t
      }
    function nS(e,n){
      return(e=t(22,e,null,n)).lanes=0,e
      }
    function nC(e,t,n){
      return oL(t,e.child,null,n),e=ny(t,t.pendingProps.children),e.flags|=2,t.memoizedState=null,e
      }
    function nw(e,t,n){
      e.lanes|=t;
      var r=e.alternate;
      null!==r&&(r.lanes|=t),K(e.return,t,n)
      }
    function nx(e,t,n,r,l,a){
      var i=e.memoizedState;
      null===i?e.memoizedState={isBackwards:t,rendering:null,renderingStartTime:0,last:r,tail:n,tailMode:l,treeForkCount:a}:(i.isBackwards=t,i.rendering=null,i.renderingStartTime=0,i.last=r,i.tail=n,i.tailMode=l,i.treeForkCount=a)
      }
    function nk(e,t,n){
      var r=t.pendingProps,l=r.revealOrder,a=r.tail;
      r=r.children;
      var i=oH.current,o=(2&i)!=0;
      if(o?(i=1&i|2,t.flags|=128):i&=1,f(oH,i),nn(e,t,r,n),r=on?i0:0,!o&&null!==e&&(128&e.flags)!=0)
      n:
      for(e=t.child;null!==e;){
        if(13===e.tag)
        null!==e.memoizedState&&nw(e,n,t);
        else 
        if(19===e.tag)
        nw(e,n,t);
        else 
        if(null!==e.child){
          e.child.return=e,e=e.child;
          continue
          }
        if(e===t)
        break;
        for(;null===e.sibling;){
          if(null===e.return||e.return===t)
          break n;
          e=e.return
          }
        e.sibling.return=e.return,e=e.sibling
        }
      switch(l){case"forwards":
      for(n=t.child,l=null;null!==n;)
      null!==(e=n.alternate)&&null===eZ(e)&&(l=n),n=n.sibling;
      null===(n=l)?(l=t.child,t.child=null):(l=n.sibling,n.sibling=null),nx(t,!1,l,n,a,r);
      break;
      case"backwards":case"unstable_legacy-backwards":
      for(n=null,l=t.child,t.child=null;null!==l;){
        if(null!==(e=l.alternate)&&null===eZ(e)){
          t.child=l;
          break
          }
        e=l.sibling,l.sibling=n,n=l,l=e
        }
      nx(t,!0,n,null,a,r);
      break;
      case"together":
      nx(t,!1,null,null,void 0,r);
      break;
      default:
      t.memoizedState=null
      }
      return t.child
      }
    function nT(e,t,n){
      if(null!==e&&(t.dependencies=e.dependencies),u_|=t.lanes,(n&t.childLanes)==0){
        if(null===e)
        return null;
        else 
        if(Y(e,t,n,!1),(n&t.childLanes)==0)
        return null
        }
      if(null!==e&&t.child!==e.child)
      throw Error(r(153));
      if(null!==t.child){
        for(n=rY(e=t.child,e.pendingProps),t.child=n,n.return=t;null!==e.sibling;)
        e=e.sibling,(n=n.sibling=rY(e,e.pendingProps)).return=t;
        n.sibling=null
        }
      return t.child
      }
    function nE(e,t){
      return(e.lanes&t)!=0||!!(null!==(e=e.dependencies)&&Z(e))
      }
    function n_(e,t,n){
      if(null!==e)
      if(e.memoizedProps!==t.pendingProps)
      o8=!0;
      else{
        if(!nE(e,n)&&(128&t.flags)==0)
        return o8=!1,function(e,t,n){
          switch(t.tag){case 3:
          I(t,t.stateNode.containerInfo),Q(t,od,e.memoizedState.cache),V();
          break;
          case 27:case 5:
          j(t);
          break;
          case 4:
          I(t,t.stateNode.containerInfo);
          break;
          case 10:
          Q(t,t.type,t.memoizedProps.value);
          break;
          case 31:
          if(null!==t.memoizedState)
          return t.flags|=128,e$(t),null;
          break;
          case 13:
          var r=t.memoizedState;
          if(null!==r)
          return null!==r.dehydrated?(eQ(t),t.flags|=128,null):(n&t.child.childLanes)!=0?nb(e,t,n):(eQ(t),null!==(e=nT(e,t,n))?e.sibling:null);
          eQ(t);
          break;
          case 19:
          var l=(128&e.flags)!=0;
          if((r=(n&t.childLanes)!=0)||(Y(e,t,n,!1),r=(n&t.childLanes)!=0),l){
            if(r)
            return nk(e,t,n);
            t.flags|=128
            }
          if(null!==(l=t.memoizedState)&&(l.rendering=null,l.tail=null,l.lastEffect=null),f(oH,oH.current),r)
          break;
          return null;
          case 22:
          return t.lanes=0,ni(e,t,n,t.pendingProps);
          case 24:
          Q(t,od,e.memoizedState.cache)
          }
          return nT(e,t,n)
          }(e,t,n);
        o8=(131072&e.flags)!=0
        }
      else 
      o8=!1,on&&(1048576&t.flags)!=0&&L(t,i0,t.index);
      switch(t.lanes=0,t.tag){case 16:
      n:{
        var l=t.pendingProps;
        if(e=eC(t.elementType),t.type=e,"function"==typeof e)
        rX(e)?(l=t6(e,l),t.tag=1,t=nm(null,t,e,l,n)):(t.tag=0,t=nd(null,t,e,l,n));
        else{
          if(null!=e){
            var a=e.$$typeof;
            if(a===ld){
              t.tag=11,t=nr(null,t,e,l,n);
              break n
              }
            if(a===lh){
              t.tag=14,t=nl(null,t,e,l,n);
              break n
              }
            }
          throw Error(r(306,t=u(e)||e,""))
          }
        }
      return t;
      case 0:
      return nd(e,t,t.type,t.pendingProps,n);
      case 1:
      return a=t6(l=t.type,t.pendingProps),nm(e,t,l,a,n);
      case 3:
      n:{
        if(I(t,t.stateNode.containerInfo),null===e)
        throw Error(r(387));
        var i=t.pendingProps;
        l=(a=t.memoizedState).element,eA(e,t),eO(t,i,null,n);
        var o=t.memoizedState;
        if(Q(t,od,i=o.cache),i!==a.cache&&X(t,[od],n,!0),eG(),i=o.element,lU&&a.isDehydrated)
        if(a={element:i,isDehydrated:!1,cache:o.cache},t.updateQueue.baseState=a,t.memoizedState=a,256&t.flags){
          t=nh(e,t,i,n);
          break n
          }else 
        if(i!==l){
          W(l=M(Error(r(424)),t)),t=nh(e,t,i,n);
          break n
          }else 
        for(lU&&(ot=aB(t.stateNode.containerInfo),oe=t,on=!0,or=null,ol=!0),n=oR(t,null,i,n),t.child=n;n;)
        n.flags=-3&n.flags|4096,n=n.sibling;
        else{
          if(V(),i===l){
            t=nT(e,t,n);
            break n
            }
          nn(e,t,i,n)
          }
        t=t.child
        }
      return t;
      case 26:
      if(ir)
      return nf(e,t),null===e?(n=ii(t.type,null,t.pendingProps,null))?t.memoizedState=n:on||(t.stateNode=ip(t.type,t.pendingProps,i7.current,t)):t.memoizedState=ii(t.type,e.memoizedProps,t.pendingProps,e.memoizedState),null;
      case 27:
      if(ib)
      return j(t),null===e&&ib&&on&&(l=t.stateNode=iy(t.type,t.pendingProps,i7.current,i6.current,!1),oe=t,ol=!0,ot=aG(t.type,l,ot)),nn(e,t,t.pendingProps.children,n),nf(e,t),null===e&&(t.flags|=4194304),t.child;
      case 5:
      return null===e&&on&&(ie(t.type,t.pendingProps,i6.current),(a=l=ot)&&(null!==(l=aO(l,t.type,t.pendingProps,ol))?(t.stateNode=l,oe=t,ot=aI(l),ol=!1,a=!0):a=!1),a||G(t)),j(t),a=t.type,i=t.pendingProps,o=null!==e?e.memoizedProps:null,l=i.children,lN(a,i)?l=null:null!==o&&lN(a,o)&&(t.flags|=32),null!==t.memoizedState&&(a=e1(e,t,e4,null,null,n),lD?l4._currentValue=a:l4._currentValue2=a),nf(e,t),nn(e,t,l,n),t.child;
      case 6:
      return null===e&&on&&(it(t.pendingProps,i6.current),(e=n=ot)&&(null!==(n=aU(n,t.pendingProps,ol))?(t.stateNode=n,oe=t,ot=null,e=!0):e=!1),e||G(t)),null;
      case 13:
      return nb(e,t,n);
      case 4:
      return I(t,t.stateNode.containerInfo),l=t.pendingProps,null===e?t.child=oL(t,null,l,n):nn(e,t,l,n),t.child;
      case 11:
      return nr(e,t,t.type,t.pendingProps,n);
      case 7:
      return nn(e,t,t.pendingProps,n),t.child;
      case 8:case 12:
      return nn(e,t,t.pendingProps.children,n),t.child;
      case 10:
      return l=t.pendingProps,Q(t,t.type,l.value),nn(e,t,l.children,n),t.child;
      case 9:
      return a=t.type._context,l=t.pendingProps.children,J(t),l=l(a=ee(a)),t.flags|=1,nn(e,t,l,n),t.child;
      case 14:
      return nl(e,t,t.type,t.pendingProps,n);
      case 15:
      return na(e,t,t.type,t.pendingProps,n);
      case 19:
      return nk(e,t,n);
      case 31:
      var s=e,c=t,d=n,p=c.pendingProps,m=(128&c.flags)!=0;
      if(c.flags&=-129,null===s){
        if(on){
          if("hidden"===p.mode)
          return s=ns(c,p),c.lanes=0x20000000,no(null,s);
          if(e$(c),(s=ot)?null!==(s=aH(s,ol))&&(c.memoizedState={dehydrated:s,treeContext:null!==i3?{id:i4,overflow:i5}:null,retryLane:0x20000000,hydrationErrors:null},(d=r2(s)).return=c,c.child=d,oe=c,ot=null):s=null,null===s)
          throw G(c);
          return c.lanes=0x20000000,null
          }
        return ns(c,p)
        }
      var h=s.memoizedState;
      if(null!==h){
        var g=h.dehydrated;
        if(e$(c),m)
        if(256&c.flags)
        c.flags&=-257,c=nc(s,c,d);
        else 
        if(null!==c.memoizedState)
        c.child=s.child,c.flags|=128,c=null;
        else 
        throw Error(r(558));
        else 
        if(o8||Y(s,c,d,!1),m=(d&s.childLanes)!=0,o8||m){
          if(null!==(p=uv)&&0!==(g=w(p,d))&&g!==h.retryLane)
          throw h.retryLane=g,eF(s,g),rv(p,s,g),o6;
          rP(),c=nc(s,c,d)
          }else 
        s=h.treeContext,lU&&(ot=aj(g),oe=c,on=!0,or=null,ol=!1,null!==s&&A(c,s)),c=ns(c,p),c.flags|=4096;
        return c
        }
      return(s=rY(s.child,{mode:p.mode,children:p.children})).ref=c.ref,c.child=s,s.return=c,s;
      case 22:
      return ni(e,t,n,t.pendingProps);
      case 24:
      return J(t),l=ee(od),null===e?(null===(a=eh())&&(a=uv,i=er(),a.pooledCache=i,i.refCount++,null!==i&&(a.pooledCacheLanes|=n),a=i),t.memoizedState={parent:l,cache:a},eN(t),Q(t,od,a)):((e.lanes&n)!=0&&(eA(e,t),eO(t,null,null,n),eG()),a=e.memoizedState,i=t.memoizedState,a.parent!==l?(a={parent:l,cache:l},t.memoizedState=a,0===t.lanes&&(t.memoizedState=t.updateQueue.baseState=a),Q(t,od,l)):(Q(t,od,l=i.cache),l!==a.cache&&X(t,[od],n,!0))),nn(e,t,t.pendingProps.children,n),t.child;
      case 29:
      throw t.pendingProps
      }
      throw Error(r(156,t.tag))
      }
    function nP(e){
      e.flags|=4
      }
    function nz(e){
      lO&&(e.flags|=8)
      }
    function nM(e,t){
      if(null!==e&&e.child===t.child)
      return!1;
      if((16&t.flags)!=0)
      return!0;
      for(e=t.child;null!==e;){
        if((8218&e.flags)!=0||(8218&e.subtreeFlags)!=0)
        return!0;
        e=e.sibling
        }
      return!1
      }
    function nF(e,t,n,r){
      if(lG)
      for(n=t.child;null!==n;){
        if(5===n.tag||6===n.tag)
        lL(e,n.stateNode);
        else 
        if(!(4===n.tag||ib&&27===n.tag)&&null!==n.child){
          n.child.return=n,n=n.child;
          continue
          }
        if(n===t)
        break;
        for(;null===n.sibling;){
          if(null===n.return||n.return===t)
          return;
          n=n.return
          }
        n.sibling.return=n.return,n=n.sibling
        }
      else 
      if(lO)
      for(
      var l=t.child
      ;null!==l;){
        if(5===l.tag){
          var a=l.stateNode;
          n&&r&&(a=aE(a,l.type,l.memoizedProps)),lL(e,a)
          }else 
        if(6===l.tag)
        a=l.stateNode,n&&r&&(a=a_(a,l.memoizedProps)),lL(e,a);
        else 
        if(4!==l.tag){
          if(22===l.tag&&null!==l.memoizedState)
          null!==(a=l.child)&&(a.return=l),nF(e,l,!0,!0);
          else 
          if(null!==l.child){
            l.child.return=l,l=l.child;
            continue
            }
          }
        if(l===t)
        break;
        for(;null===l.sibling;){
          if(null===l.return||l.return===t)
          return;
          l=l.return
          }
        l.sibling.return=l.return,l=l.sibling
        }
      }
    function nL(e,t){
      if(lO&&nM(e,t)){
        var n=(e=t.stateNode).containerInfo,r=aw();
        (function e(t,n,r,l){
          var a=!1;
          if(lO)
          for(
          var i=n.child
          ;null!==i;){
            if(5===i.tag){
              var o=i.stateNode;
              r&&l&&(o=aE(o,i.type,i.memoizedProps)),ax(t,o)
              }else 
            if(6===i.tag)
            o=i.stateNode,r&&l&&(o=a_(o,i.memoizedProps)),ax(t,o);
            else 
            if(4!==i.tag){
              if(22===i.tag&&null!==i.memoizedState)
              null!==(a=i.child)&&(a.return=i),e(t,i,!0,!0),a=!0;
              else 
              if(null!==i.child){
                i.child.return=i,i=i.child;
                continue
                }
              }
            if(i===n)
            break;
            for(;null===i.sibling;){
              if(null===i.return||i.return===n)
              return a;
              i=i.return
              }
            i.sibling.return=i.return,i=i.sibling
            }
          return a
          })(r,t,!1,!1),e.pendingChildren=r,nP(t),ak(n,r)
        }
      }
    function nR(e,t,n,r){
      if(lG)
      e.memoizedProps!==r&&nP(t);
      else 
      if(lO){
        var l=e.stateNode,a=e.memoizedProps;
        if((e=nM(e,t))||a!==r){
          var i=i6.current;
          (a=aC(l,n,a,r,!e,null))===l?t.stateNode=l:(nz(t),lR(a,n,r,i)&&nP(t),t.stateNode=a,e&&nF(a,t,!1,!1))
          }else 
        t.stateNode=l
        }
      }
    function nN(e,t,n,r,l){
      if((32&e.mode)!=0&&(null===n?lX(t,r):lY(t,n,r))){
        if(e.flags|=0x1000000,(0x13ffff40&l)===l||lZ(t,r))
        if(lJ(e.stateNode,t,r))
        e.flags|=8192;
        else 
        if(rT())
        e.flags|=8192;
        else 
        throw oz=oP,oE
        }else 
      e.flags&=-0x1000001
      }
    function nA(e,t){
      if(ih(t)){
        if(e.flags|=0x1000000,!ig(t))
        if(rT())
        e.flags|=8192;
        else 
        throw oz=oP,oE
        }else 
      e.flags&=-0x1000001
      }
    function nI(e,t){
      null!==t&&(e.flags|=4),16384&e.flags&&(t=22!==e.tag?h():0x20000000,e.lanes|=t,uF|=t)
      }
    function nB(e,t){
      if(!on)
      switch(e.tailMode){case"hidden":
      t=e.tail;
      for(
      var n=null
      ;null!==t;)
      null!==t.alternate&&(n=t),t=t.sibling;
      null===n?e.tail=null:n.sibling=null;
      break;
      case"collapsed":
      n=e.tail;
      for(
      var r=null
      ;null!==n;)
      null!==n.alternate&&(r=n),n=n.sibling;
      null===r?t||null===e.tail?e.tail=null:e.tail.sibling=null:r.sibling=null
      }
      }
    function nj(e){
      var t=null!==e.alternate&&e.alternate.child===e.child,n=0,r=0;
      if(t)
      for(
      var l=e.child
      ;null!==l;)
      n|=l.lanes|l.childLanes,r|=0x3e00000&l.subtreeFlags,r|=0x3e00000&l.flags,l.return=e,l=l.sibling;
      else 
      for(l=e.child;null!==l;)
      n|=l.lanes|l.childLanes,r|=l.subtreeFlags,r|=l.flags,l.return=e,l=l.sibling;
      return e.subtreeFlags|=r,e.childLanes=n,t
      }
    function nD(e,t){
      switch(N(t),t.tag){case 3:
      $(od),B();
      break;
      case 26:case 27:case 5:
      D(t);
      break;
      case 4:
      B();
      break;
      case 31:
      null!==t.memoizedState&&eY(t);
      break;
      case 13:
      eY(t);
      break;
      case 19:
      c(oH);
      break;
      case 10:
      $(t.type);
      break;
      case 22:case 23:
      eY(t),eW(),null!==e&&c(ok);
      break;
      case 24:
      $(od)
      }
      }
    function nG(e,t){
      try{
        var n=t.updateQueue,r=null!==n?n.lastEffect:null;
        if(null!==r){
          var l=r.next;
          n=l;
          do{
            if((n.tag&e)===e){
              r=void 0;
              var a=n.create;
              n.inst.destroy=r=a()
              }
            n=n.next
            }while(n!==l)
          }
        }catch(e){
        rH(t,t.return,e)
        }
      }
    function nO(e,t,n){
      try{
        var r=t.updateQueue,l=null!==r?r.lastEffect:null;
        if(null!==l){
          var a=l.next;
          r=a;
          do{
            if((r.tag&e)===e){
              var i=r.inst,o=i.destroy;
              if(void 0!==o){
                i.destroy=void 0,l=t;
                try{
                  o()
                  }catch(e){
                  rH(l,n,e)
                  }
                }
              }
            r=r.next
            }while(r!==a)
          }
        }catch(e){
        rH(t,t.return,e)
        }
      }
    function nU(e){
      var t=e.updateQueue;
      if(null!==t){
        var n=e.stateNode;
        try{
          eH(t,n)
          }catch(t){
          rH(e,e.return,t)
          }
        }
      }
    function nH(e,t,n){
      n.props=t6(e.type,e.memoizedProps),n.state=e.memoizedState;
      try{
        n.componentWillUnmount()
        }catch(n){
        rH(e,t,n)
        }
      }
    function nV(e,t){
      try{
        var n=e.ref;
        if(null!==n){
          switch(e.tag){case 26:case 27:case 5:
          var r=lE(e.stateNode);
          break;
          default:
          r=e.stateNode
          }
          "function"==typeof n?e.refCleanup=n(r):n.current=r
          }
        }catch(n){
        rH(e,t,n)
        }
      }
    function nq(e,t){
      var n=e.ref,r=e.refCleanup;
      if(null!==n)
      if("function"==typeof r)
      try{
        r()
        }catch(n){
        rH(e,t,n)
        }finally{
        e.refCleanup=null,null!=(e=e.alternate)&&(e.refCleanup=null)
        }
      else 
      if("function"==typeof n)
      try{
        n(null)
        }catch(n){
        rH(e,t,n)
        }
      else 
      n.current=null
      }
    function nW(e){
      var t=e.type,n=e.memoizedProps,r=e.stateNode;
      try{
        as(r,t,n,e)
        }catch(t){
        rH(e,e.return,t)
        }
      }
    function nQ(e,t,n){
      try{
        ac(e.stateNode,e.type,n,t,e)
        }catch(t){
        rH(e,e.return,t)
        }
      }
    function n$(e){
      return 5===e.tag||3===e.tag||!!ir&&26===e.tag||!!ib&&27===e.tag&&ix(e.type)||4===e.tag
      }
    function nK(e){
      n:
      for(;;){
        for(;null===e.sibling;){
          if(null===e.return||n$(e.return))
          return null;
          e=e.return
          }
        for(e.sibling.return=e.return,e=e.sibling;5!==e.tag&&6!==e.tag&&18!==e.tag;){
          if(ib&&27===e.tag&&ix(e.type)||2&e.flags||null===e.child||4===e.tag)
          continue n;
          e.child.return=e,e=e.child
          }
        if(!(2&e.flags))
        return e.stateNode
        }
      }
    function nX(e,t,n){
      var r=e.tag;
      if(5===r||6===r)
      e=e.stateNode,t?af(n,e,t):ai(n,e);
      else 
      if(4!==r&&(ib&&27===r&&ix(e.type)&&(n=e.stateNode),null!==(e=e.child)))
      for(nX(e,t,n),e=e.sibling;null!==e;)
      nX(e,t,n),e=e.sibling
      }
    function nY(e,t,n){
      e=e.containerInfo;
      try{
        aT(e,n)
        }catch(e){
        rH(t,t.return,e)
        }
      }
    function nZ(e){
      var t=e.stateNode,n=e.memoizedProps;
      try{
        iS(e.type,n,t,e)
        }catch(t){
        rH(e,e.return,t)
        }
      }
    function nJ(e,t,n){
      var r=n.flags;
      switch(n.tag){case 0:case 11:case 15:
      n7(e,n),4&r&&nG(5,n);
      break;
      case 1:
      if(n7(e,n),4&r)
      if(e=n.stateNode,null===t)
      try{
        e.componentDidMount()
        }catch(e){
        rH(n,n.return,e)
        }
      else{
        var l=t6(n.type,t.memoizedProps);
        t=t.memoizedState;
        try{
          e.componentDidUpdate(l,t,e.__reactInternalSnapshotBeforeUpdate)
          }catch(e){
          rH(n,n.return,e)
          }
        }
      64&r&&nU(n),512&r&&nV(n,n.return);
      break;
      case 3:
      if(n7(e,n),64&r&&null!==(r=n.updateQueue)){
        if(e=null,null!==n.child)
        switch(n.child.tag){case 27:case 5:
        e=lE(n.child.stateNode);
        break;
        case 1:
        e=n.child.stateNode
        }
        try{
          eH(r,e)
          }catch(e){
          rH(n,n.return,e)
          }
        }
      break;
      case 27:
      ib&&null===t&&4&r&&nZ(n);
      case 26:case 5:
      if(n7(e,n),null===t){
        if(4&r)
        nW(n);
        else 
        if(64&r){
          e=n.type,t=n.memoizedProps,l=n.stateNode;
          try{
            aY(l,e,t,n)
            }catch(e){
            rH(n,n.return,e)
            }
          }
        }
      512&r&&nV(n,n.return);
      break;
      case 12:default:
      n7(e,n);
      break;
      case 31:
      n7(e,n),4&r&&n2(e,n);
      break;
      case 13:
      n7(e,n),4&r&&n3(e,n),64&r&&null!==(r=n.memoizedState)&&null!==(r=r.dehydrated)&&aF(r,n=rQ.bind(null,n));
      break;
      case 22:
      if(!(r=null!==n.memoizedState||o9)){
        t=null!==t&&null!==t.memoizedState||ue,l=o9;
        var a=ue;
        o9=r,(ue=t)&&!a?function e(t,n,r){
          for(r=r&&(8772&n.subtreeFlags)!=0,n=n.child;null!==n;){
            var l=n.alternate,a=t,i=n,o=i.flags;
            switch(i.tag){case 0:case 11:case 15:
            e(a,i,r),nG(4,i);
            break;
            case 1:
            if(e(a,i,r),"function"==typeof(a=(l=i).stateNode).componentDidMount)
            try{
              a.componentDidMount()
              }catch(e){
              rH(l,l.return,e)
              }
            if(null!==(a=(l=i).updateQueue)){
              var u=l.stateNode;
              try{
                var s=a.shared.hiddenCallbacks;
                if(null!==s)
                for(a.shared.hiddenCallbacks=null,a=0;a<s.length;a++)
                eU(s[a],u)
                }catch(e){
                rH(l,l.return,e)
                }
              }
            r&&64&o&&nU(i),nV(i,i.return);
            break;
            case 27:
            ib&&nZ(i);
            case 26:case 5:
            e(a,i,r),r&&null===l&&4&o&&nW(i),nV(i,i.return);
            break;
            case 12:default:
            e(a,i,r);
            break;
            case 31:
            e(a,i,r),r&&4&o&&n2(a,i);
            break;
            case 13:
            e(a,i,r),r&&4&o&&n3(a,i);
            break;
            case 22:
            null===i.memoizedState&&e(a,i,r),nV(i,i.return);
            case 30:}
            n=n.sibling
            }
          }(e,n,(8772&n.subtreeFlags)!=0):n7(e,n),o9=l,ue=a
        }
      case 30:}
      }
    function n0(e,t,n){
      for(n=n.child;null!==n;)
      n1(e,t,n),n=n.sibling
      }
    function n1(e,t,n){
      if(iq&&"function"==typeof iq.onCommitFiberUnmount)
      try{
        iq.onCommitFiberUnmount(iV,n)
        }catch{
        }
      switch(n.tag){case 26:
      if(ir){
        ue||nq(n,t),n0(e,t,n),n.memoizedState?iu(n.memoizedState):n.stateNode&&id(n.stateNode);
        break
        }
      case 27:
      if(ib){
        ue||nq(n,t);
        var r=ul,l=ua;
        ix(n.type)&&(ul=n.stateNode,ua=!1),n0(e,t,n),iC(n.stateNode),ul=r,ua=l;
        break
        }
      case 5:
      ue||nq(n,t);
      case 6:
      if(lG){
        if(r=ul,l=ua,ul=null,n0(e,t,n),ul=r,ua=l,null!==ul)
        if(ua)
        try{
          am(ul,n.stateNode)
          }catch(e){
          rH(n,t,e)
          }
        else 
        try{
          ap(ul,n.stateNode)
          }catch(e){
          rH(n,t,e)
          }
        }else 
      n0(e,t,n);
      break;
      case 18:
      lG&&null!==ul&&(ua?a4(ul,n.stateNode):a3(ul,n.stateNode));
      break;
      case 4:
      lG?(r=ul,l=ua,ul=n.stateNode.containerInfo,ua=!0,n0(e,t,n),ul=r,ua=l):(lO&&nY(n.stateNode,n,aw()),n0(e,t,n));
      break;
      case 0:case 11:case 14:case 15:
      nO(2,n,t),ue||nO(4,n,t),n0(e,t,n);
      break;
      case 1:
      ue||(nq(n,t),"function"==typeof(r=n.stateNode).componentWillUnmount&&nH(n,t,r)),n0(e,t,n);
      break;
      case 21:default:
      n0(e,t,n);
      break;
      case 22:
      ue=(r=ue)||null!==n.memoizedState,n0(e,t,n),ue=r
      }
      }
    function n2(e,t){
      if(lU&&null===t.memoizedState&&null!==(e=t.alternate)&&null!==(e=e.memoizedState)){
        e=e.dehydrated;
        try{
          aJ(e)
          }catch(e){
          rH(t,t.return,e)
          }
        }
      }
    function n3(e,t){
      if(lU&&null===t.memoizedState&&null!==(e=t.alternate)&&null!==(e=e.memoizedState)&&null!==(e=e.dehydrated))
      try{
        a0(e)
        }catch(e){
        rH(t,t.return,e)
        }
      }
    function n4(e,t){
      var n=function(e){
        switch(e.tag){case 31:case 13:case 19:
        var t=e.stateNode;
        return null===t&&(t=e.stateNode=new un),t;
        case 22:
        return null===(t=(e=e.stateNode)._retryCache)&&(t=e._retryCache=new un),t;
        default:
        throw Error(r(435,e.tag))
        }
        }(e);
      t.forEach(function(t){
        if(!n.has(t)){
          n.add(t);
          var r=r$.bind(null,e,t);
          t.then(r,r)
          }
        })
      }
    function n5(e,t){
      var n=t.deletions;
      if(null!==n)
      for(
      var l=0
      ;l<n.length;l++){
        var a=n[l],i=e,o=t;
        if(lG){
          var u=o;
          n:
          for(;null!==u;){
            switch(u.tag){case 27:
            if(ib){
              if(ix(u.type)){
                ul=u.stateNode,ua=!1;
                break n
                }
              break
              }
            case 5:
            ul=u.stateNode,ua=!1;
            break n;
            case 3:case 4:
            ul=u.stateNode.containerInfo,ua=!0;
            break n
            }
            u=u.return
            }
          if(null===ul)
          throw Error(r(160));
          n1(i,o,a),ul=null,ua=!1
          }else 
        n1(i,o,a);
        null!==(i=a.alternate)&&(i.return=null),a.return=null
        }
      if(13886&t.subtreeFlags)
      for(t=t.child;null!==t;)
      n6(t,e),t=t.sibling
      }
    function n6(e,t){
      var n=e.alternate,l=e.flags;
      switch(e.tag){case 0:case 11:case 14:case 15:
      n5(t,e),n8(e),4&l&&(nO(3,e,e.return),nG(3,e),nO(5,e,e.return));
      break;
      case 1:
      n5(t,e),n8(e),512&l&&(ue||null===n||nq(n,n.return)),64&l&&o9&&null!==(e=e.updateQueue)&&null!==(l=e.callbacks)&&(n=e.shared.hiddenCallbacks,e.shared.hiddenCallbacks=null===n?l:n.concat(l));
      break;
      case 26:
      if(ir){
        var a=ui;
        if(n5(t,e),n8(e),512&l&&(ue||null===n||nq(n,n.return)),4&l){
          l=null!==n?n.memoizedState:null;
          var i=e.memoizedState;
          null===n?null===i?null===e.stateNode?e.stateNode=is(a,e.type,e.memoizedProps,e):ic(a,e.type,e.stateNode):e.stateNode=io(a,i,e.memoizedProps):l!==i?(null===l?null!==n.stateNode&&id(n.stateNode):iu(l),null===i?ic(a,e.type,e.stateNode):io(a,i,e.memoizedProps)):null===i&&null!==e.stateNode&&nQ(e,e.memoizedProps,n.memoizedProps)
          }
        break
        }
      case 27:
      if(ib){
        n5(t,e),n8(e),512&l&&(ue||null===n||nq(n,n.return)),null!==n&&4&l&&nQ(e,e.memoizedProps,n.memoizedProps);
        break
        }
      case 5:
      if(n5(t,e),n8(e),512&l&&(ue||null===n||nq(n,n.return)),lG){
        if(32&e.flags){
          a=e.stateNode;
          try{
            ah(a)
            }catch(t){
            rH(e,e.return,t)
            }
          }
        4&l&&null!=e.stateNode&&(a=e.memoizedProps,nQ(e,a,null!==n?n.memoizedProps:a)),1024&l&&(ut=!0)
        }else 
      lO&&null!==e.alternate&&(e.alternate.stateNode=e.stateNode);
      break;
      case 6:
      if(n5(t,e),n8(e),4&l&&lG){
        if(null===e.stateNode)
        throw Error(r(162));
        l=e.memoizedProps,n=null!==n?n.memoizedProps:l,a=e.stateNode;
        try{
          au(a,n,l)
          }catch(t){
          rH(e,e.return,t)
          }
        }
      break;
      case 3:
      if(ir?(im(),a=ui,ui=ia(t.containerInfo),n5(t,e),ui=a):n5(t,e),n8(e),4&l){
        if(lG&&lU&&null!==n&&n.memoizedState.isDehydrated)
        try{
          aZ(t.containerInfo)
          }catch(t){
          rH(e,e.return,t)
          }
        if(lO){
          l=t.containerInfo,n=t.pendingChildren;
          try{
            aT(l,n)
            }catch(t){
            rH(e,e.return,t)
            }
          }
        }
      ut&&(ut=!1,function e(t){
        if(1024&t.subtreeFlags)
        for(t=t.child;null!==t;){
          var n=t;
          e(n),5===n.tag&&1024&n.flags&&l5(n.stateNode),t=t.sibling
          }
        }(e));
      break;
      case 4:
      ir?(n=ui,ui=ia(e.stateNode.containerInfo),n5(t,e),n8(e),ui=n):(n5(t,e),n8(e)),4&l&&lO&&nY(e.stateNode,e,e.stateNode.pendingChildren);
      break;
      case 12:default:
      n5(t,e),n8(e);
      break;
      case 31:case 19:
      n5(t,e),n8(e),4&l&&null!==(l=e.updateQueue)&&(e.updateQueue=null,n4(e,l));
      break;
      case 13:
      n5(t,e),n8(e),8192&e.child.flags&&null!==e.memoizedState!=(null!==n&&null!==n.memoizedState)&&(uA=iB()),4&l&&null!==(l=e.updateQueue)&&(e.updateQueue=null,n4(e,l));
      break;
      case 22:
      a=null!==e.memoizedState;
      var o=null!==n&&null!==n.memoizedState,u=o9,s=ue;
      if(o9=u||a,ue=s||o,n5(t,e),ue=s,o9=u,n8(e),8192&l&&((t=e.stateNode)._visibility=a?-2&t._visibility:1|t._visibility,a&&(null===n||o||o9||ue||function e(t){
        for(t=t.child;null!==t;){
          var n=t;
          switch(n.tag){case 0:case 11:case 14:case 15:
          nO(4,n,n.return),e(n);
          break;
          case 1:
          nq(n,n.return);
          var r=n.stateNode;
          "function"==typeof r.componentWillUnmount&&nH(n,n.return,r),e(n);
          break;
          case 27:
          ib&&iC(n.stateNode);
          case 26:case 5:
          nq(n,n.return),e(n);
          break;
          case 22:
          null===n.memoizedState&&e(n);
          break;
          default:
          e(n)
          }
          t=t.sibling
          }
        }(e)),lG)){
        n:
        if(n=null,lG)
        for(t=e;;){
          if(5===t.tag||ir&&26===t.tag){
            if(null===n){
              o=n=t;
              try{
                i=o.stateNode,a?ag(i):ab(o.stateNode,o.memoizedProps)
                }catch(e){
                rH(o,o.return,e)
                }
              }
            }else 
          if(6===t.tag){
            if(null===n){
              o=t;
              try{
                var c=o.stateNode;
                a?av(c):ay(c,o.memoizedProps)
                }catch(e){
                rH(o,o.return,e)
                }
              }
            }else 
          if(18===t.tag){
            if(null===n){
              o=t;
              try{
                var f=o.stateNode;
                a?a5(f):a6(o.stateNode)
                }catch(e){
                rH(o,o.return,e)
                }
              }
            }else 
          if((22!==t.tag&&23!==t.tag||null===t.memoizedState||t===e)&&null!==t.child){
            t.child.return=t,t=t.child;
            continue
            }
          if(t===e)
          break n;
          for(;null===t.sibling;){
            if(null===t.return||t.return===e)
            break n;
            n===t&&(n=null),t=t.return
            }
          n===t&&(n=null),t.sibling.return=t.return,t=t.sibling
          }
        }
      4&l&&null!==(l=e.updateQueue)&&null!==(n=l.retryQueue)&&(l.retryQueue=null,n4(e,n));
      case 30:case 21:}
      }
    function n8(e){
      var t=e.flags;
      if(2&t){
        try{
          for(
          var n,l=e.return
          ;null!==l;){
            if(n$(l)){
              n=l;
              break
              }
            l=l.return
            }
          if(lG){
            if(null==n)
            throw Error(r(160));
            switch(n.tag){case 27:
            if(ib){
              var a=n.stateNode,i=nK(e);
              nX(e,i,a);
              break
              }
            case 5:
            var o=n.stateNode;
            32&n.flags&&(ah(o),n.flags&=-33);
            var u=nK(e);
            nX(e,u,o);
            break;
            case 3:case 4:
            var s=n.stateNode.containerInfo,c=nK(e);
            !function e(t,n,r){
              var l=t.tag;
              if(5===l||6===l)
              t=t.stateNode,n?ad(r,t,n):ao(r,t);
              else 
              if(4!==l&&(ib&&27===l&&ix(t.type)&&(r=t.stateNode,n=null),null!==(t=t.child)))
              for(e(t,n,r),t=t.sibling;null!==t;)
              e(t,n,r),t=t.sibling
              }(e,c,s);
            break;
            default:
            throw Error(r(161))
            }
            }
          }catch(t){
          rH(e,e.return,t)
          }
        e.flags&=-3
        }
      4096&t&&(e.flags&=-4097)
      }
    function n7(e,t){
      if(8772&t.subtreeFlags)
      for(t=t.child;null!==t;)
      nJ(e,t.alternate,t),t=t.sibling
      }
    function n9(e,t){
      var n=null;
      null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(n=e.memoizedState.cachePool.pool),e=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(e=t.memoizedState.cachePool.pool),e!==n&&(null!=e&&e.refCount++,null!=n&&el(n))
      }
    function re(e,t){
      e=null,null!==t.alternate&&(e=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==e&&(t.refCount++,null!=e&&el(e))
      }
    function rt(e,t,n,r){
      if(10256&t.subtreeFlags)
      for(t=t.child;null!==t;)
      rn(e,t,n,r),t=t.sibling
      }
    function rn(e,t,n,r){
      var l=t.flags;
      switch(t.tag){case 0:case 11:case 15:
      rt(e,t,n,r),2048&l&&nG(9,t);
      break;
      case 1:case 31:case 13:default:
      rt(e,t,n,r);
      break;
      case 3:
      rt(e,t,n,r),2048&l&&(e=null,null!==t.alternate&&(e=t.alternate.memoizedState.cache),(t=t.memoizedState.cache)!==e&&(t.refCount++,null!=e&&el(e)));
      break;
      case 12:
      if(2048&l){
        rt(e,t,n,r),e=t.stateNode;
        try{
          var a=t.memoizedProps,i=a.id,o=a.onPostCommit;
          "function"==typeof o&&o(i,null===t.alternate?"mount":"update",e.passiveEffectDuration,-0)
          }catch(e){
          rH(t,t.return,e)
          }
        }else 
      rt(e,t,n,r);
      break;
      case 23:
      break;
      case 22:
      a=t.stateNode,i=t.alternate,null!==t.memoizedState?2&a._visibility?rt(e,t,n,r):rr(e,t):2&a._visibility?rt(e,t,n,r):(a._visibility|=2,function e(t,n,r,l,a){
        for(a=a&&(10256&n.subtreeFlags)!=0,n=n.child;null!==n;){
          var i=n,o=i.flags;
          switch(i.tag){case 0:case 11:case 15:
          e(t,i,r,l,a),nG(8,i);
          break;
          case 23:
          break;
          case 22:
          var u=i.stateNode;
          null!==i.memoizedState?2&u._visibility?e(t,i,r,l,a):rr(t,i):(u._visibility|=2,e(t,i,r,l,a)),a&&2048&o&&n9(i.alternate,i);
          break;
          case 24:
          e(t,i,r,l,a),a&&2048&o&&re(i.alternate,i);
          break;
          default:
          e(t,i,r,l,a)
          }
          n=n.sibling
          }
        }(e,t,n,r,(10256&t.subtreeFlags)!=0)),2048&l&&n9(i,t);
      break;
      case 24:
      rt(e,t,n,r),2048&l&&re(t.alternate,t)
      }
      }
    function rr(e,t){
      if(10256&t.subtreeFlags)
      for(t=t.child;null!==t;){
        var n=t,r=n.flags;
        switch(n.tag){case 22:
        rr(e,n),2048&r&&n9(n.alternate,n);
        break;
        case 24:
        rr(e,n),2048&r&&re(n.alternate,n);
        break;
        default:
        rr(e,n)
        }
        t=t.sibling
        }
      }
    function rl(e,t,n){
      if(e.subtreeFlags&uo)
      for(e=e.child;null!==e;)
      ra(e,t,n),e=e.sibling
      }
    function ra(e,t,n){
      switch(e.tag){case 26:
      if(rl(e,t,n),e.flags&uo)
      if(null!==e.memoizedState)
      iv(n,ui,e.memoizedState,e.memoizedProps);
      else{
        var r=e.stateNode,l=e.type;
        e=e.memoizedProps,((0x13ffff40&t)===t||lZ(l,e))&&l1(n,r,l,e)
        }
      break;
      case 5:
      rl(e,t,n),e.flags&uo&&(r=e.stateNode,l=e.type,e=e.memoizedProps,((0x13ffff40&t)===t||lZ(l,e))&&l1(n,r,l,e));
      break;
      case 3:case 4:
      ir?(r=ui,ui=ia(e.stateNode.containerInfo),rl(e,t,n),ui=r):rl(e,t,n);
      break;
      case 22:
      null===e.memoizedState&&(null!==(r=e.alternate)&&null!==r.memoizedState?(r=uo,uo=0x1000000,rl(e,t,n),uo=r):rl(e,t,n));
      break;
      default:
      rl(e,t,n)
      }
      }
    function ri(e){
      var t=e.alternate;
      if(null!==t&&null!==(e=t.child)){
        t.child=null;
        do 
        t=e.sibling,e.sibling=null,e=t;
        while(null!==e)
        }
      }
    function ro(e){
      var t=e.deletions;
      if((16&e.flags)!=0){
        if(null!==t)
        for(
        var n=0
        ;n<t.length;n++){
          var r=t[n];
          ur=r,rs(r,e)
          }
        ri(e)
        }
      if(10256&e.subtreeFlags)
      for(e=e.child;null!==e;)
      ru(e),e=e.sibling
      }
    function ru(e){
      switch(e.tag){case 0:case 11:case 15:
      ro(e),2048&e.flags&&nO(9,e,e.return);
      break;
      case 3:case 12:default:
      ro(e);
      break;
      case 22:
      var t=e.stateNode;
      null!==e.memoizedState&&2&t._visibility&&(null===e.return||13!==e.return.tag)?(t._visibility&=-3,function e(t){
        var n=t.deletions;
        if((16&t.flags)!=0){
          if(null!==n)
          for(
          var r=0
          ;r<n.length;r++){
            var l=n[r];
            ur=l,rs(l,t)
            }
          ri(t)
          }
        for(t=t.child;null!==t;){
          switch((n=t).tag){case 0:case 11:case 15:
          nO(8,n,n.return),e(n);
          break;
          case 22:
          2&(r=n.stateNode)._visibility&&(r._visibility&=-3,e(n));
          break;
          default:
          e(n)
          }
          t=t.sibling
          }
        }(e)):ro(e)
      }
      }
    function rs(e,t){
      for(;null!==ur;){
        var n=ur;
        switch(n.tag){case 0:case 11:case 15:
        nO(8,n,t);
        break;
        case 23:case 22:
        if(null!==n.memoizedState&&null!==n.memoizedState.cachePool){
          var r=n.memoizedState.cachePool.pool;
          null!=r&&r.refCount++
          }
        break;
        case 24:
        el(n.memoizedState.cache)
        }
        if(null!==(r=n.child))
        r.return=n,ur=r;
        else 
        for(n=e;null!==ur;){
          var l=(r=ur).sibling,a=r.return;
          if(function e(t){
            var n=t.alternate;
            null!==n&&(t.alternate=null,e(n)),t.child=null,t.deletions=null,t.sibling=null,5===t.tag&&null!==(n=t.stateNode)&&lK(n),t.stateNode=null,t.return=null,t.dependencies=null,t.memoizedProps=null,t.memoizedState=null,t.pendingProps=null,t.stateNode=null,t.updateQueue=null
            }(r),r===n){
            ur=null;
            break
            }
          if(null!==l){
            l.return=a,ur=l;
            break
            }
          ur=a
          }
        }
      }
    function rc(e){
      var t=lH(e);
      if(null!=t){
        if("string"!=typeof t.memoizedProps["data-testname"])
        throw Error(r(364));
        return t
        }
      if(null===(e=l9(e)))
      throw Error(r(362));
      return e.stateNode.current
      }
    function rf(e,t){
      var n=e.tag;
      switch(t.$$typeof){case us:
      if(e.type===t.value)
      return!0;
      break;
      case uc:
      n:{
        for(t=t.value,e=[e,0],n=0;n<e.length;){
          var l=e[n++],a=l.tag,i=e[n++],o=t[i];
          if(5!==a&&26!==a&&27!==a||!an(l)){
            for(;null!=o&&rf(l,o);)
            o=t[++i];
            if(i===t.length){
              t=!0;
              break n
              }
            for(l=l.child;null!==l;)
            e.push(l,i),l=l.sibling
            }
          }
        t=!1
        }
      return t;
      case uf:
      if((5===n||26===n||27===n)&&ar(e.stateNode,t.value))
      return!0;
      break;
      case up:
      if((5===n||6===n||26===n||27===n)&&null!==(e=at(e))&&0<=e.indexOf(t.value))
      return!0;
      break;
      case ud:
      if((5===n||26===n||27===n)&&"string"==typeof(e=e.memoizedProps["data-testname"])&&e.toLowerCase()===t.value.toLowerCase())
      return!0;
      break;
      default:
      throw Error(r(365))
      }
      return!1
      }
    function rd(e){
      switch(e.$$typeof){case us:
      return"<"+(u(e.value)||"Unknown")+">";
      case uc:
      return":has("+(rd(e)||"")+")";
      case uf:
      return'[role="'+e.value+'"]';
      case up:
      return'"'+e.value+'"';
      case ud:
      return'[data-testname="'+e.value+'"]';
      default:
      throw Error(r(365))
      }
      }
    function rp(e,t){
      var n=[];
      e=[e,0];
      for(
      var r=0
      ;r<e.length;){
        var l=e[r++],a=l.tag,i=e[r++],o=t[i];
        if(5!==a&&26!==a&&27!==a||!an(l)){
          for(;null!=o&&rf(l,o);)
          o=t[++i];
          if(i===t.length)
          n.push(l);
          else 
          for(l=l.child;null!==l;)
          e.push(l,i),l=l.sibling
          }
        }
      return n
      }
    function rm(e,t){
      if(!l7)
      throw Error(r(363));
      e=rp(e=rc(e),t),t=[],e=Array.from(e);
      for(
      var n=0
      ;n<e.length;){
        var l=e[n++],a=l.tag;
        if(5===a||26===a||27===a)
        an(l)||t.push(l.stateNode);
        else 
        for(l=l.child;null!==l;)
        e.push(l),l=l.sibling
        }
      return t
      }
    function rh(){
      return(2&ug)!=0&&0!==uy?uy&-uy:null!==lw.T?ep():lQ()
      }
    function rg(){
      if(0===uM)
      if((0x20000000&uy)==0||on){
        var e=iF;
        (3932160&(iF<<=1))==0&&(iF=262144),uM=e
        }else 
      uM=0x20000000;
      return null!==(e=oO.current)&&(e.flags|=32),uM
      }
    function rv(e,t,n){
      (e===uv&&(2===uS||9===uS)||null!==e.cancelPendingCommit)&&(rx(e,0),rS(e,uy,uM,!1)),y(e,n),((2&ug)==0||e!==uv)&&(e===uv&&((2&ug)==0&&(uP|=n),4===uE&&rS(e,uy,uM,!1)),ei(e))
      }
    function rb(e,t,n){
      if((6&ug)!=0)
      throw Error(r(327));
      for(
      var l=!n&&(127&t)==0&&(t&e.expiredLanes)==0||m(e,t),a=l?function(e,t){
        var n=ug;
        ug|=2;
        var l=rE(),a=r_();
        uv!==e||uy!==t?(uj=null,uB=iB()+500,rx(e,t)):ux=m(e,t);
        n:
        for(;;)
        try{
          if(0!==uS&&null!==ub){
            t=ub;
            var i=uC;
            r:
            switch(uS){case 1:
            uS=0,uC=null,rL(e,t,i,1);
            break;
            case 2:case 9:
            if(ey(i)){
              uS=0,uC=null,rF(t);
              break
              }
            t=function(){
              2!==uS&&9!==uS||uv!==e||(uS=7),ei(e)
              },i.then(t,t);
            break n;
            case 3:
            uS=7;
            break n;
            case 4:
            uS=5;
            break n;
            case 7:
            ey(i)?(uS=0,uC=null,rF(t)):(uS=0,uC=null,rL(e,t,i,7));
            break;
            case 5:
            var o=null;
            switch(ub.tag){case 26:
            o=ub.memoizedState;
            case 5:case 27:
            var u=ub,s=u.type,c=u.pendingProps;
            if(o?ig(o):lJ(u.stateNode,s,c)){
              uS=0,uC=null;
              var f=u.sibling;
              if(null!==f)
              ub=f;
              else{
                var d=u.return;
                null!==d?(ub=d,rR(d)):ub=null
                }
              break r
              }
            }
            uS=0,uC=null,rL(e,t,i,5);
            break;
            case 6:
            uS=0,uC=null,rL(e,t,i,6);
            break;
            case 8:
            rw(),uE=6;
            break n;
            default:
            throw Error(r(462))
            }
            }
          for(;null!==ub&&!iA();)
          rM(ub);
          break
          }catch(t){
          rk(e,t)
          }
        return ou=oo=null,lw.H=l,lw.A=a,ug=n,null!==ub?0:(uv=null,uy=0,eP(),uE)
        }(e,t):rz(e,t,!0),i=l
      ;;){
        if(0===a)
        ux&&!l&&rS(e,t,0,!1);
        else{
          if(n=e.current.alternate,i&&!function(e){
            for(
            var t=e
            ;;){
              var n=t.tag;
              if((0===n||11===n||15===n)&&16384&t.flags&&null!==(n=t.updateQueue)&&null!==(n=n.stores))
              for(
              var r=0
              ;r<n.length;r++){
                var l=n[r],a=l.getSnapshot;
                l=l.value;
                try{
                  if(!iW(a(),l))
                  return!1
                  }catch{
                  return!1
                  }
                }
              if(n=t.child,16384&t.subtreeFlags&&null!==n)
              n.return=t,t=n;
              else{
                if(t===e)
                break;
                for(;null===t.sibling;){
                  if(null===t.return||t.return===e)
                  return!0;
                  t=t.return
                  }
                t.sibling.return=t.return,t=t.sibling
                }
              }
            return!0
            }(n)){
            a=rz(e,t,!1),i=!1;
            continue
            }
          if(2===a){
            if(i=t,e.errorRecoveryDisabledLanes&i)
            var o=0;
            else 
            o=0!=(o=-0x20000001&e.pendingLanes)?o:0x20000000&o?0x20000000:0;
            if(0!==o){
              t=o;
              n:{
                a=uL;
                var u=lU&&e.current.memoizedState.isDehydrated;
                if(u&&(rx(e,o).flags|=256),2!==(o=rz(e,o,!1))){
                  if(uk&&!u){
                    e.errorRecoveryDisabledLanes|=i,uP|=i,a=4;
                    break n
                    }
                  i=uR,uR=a,null!==i&&(null===uR?uR=i:uR.push.apply(uR,i))
                  }
                a=o
                }
              if(i=!1,2!==a)
              continue
              }
            }
          if(1===a){
            rx(e,0),rS(e,t,0,!0);
            break
            }
          n:{
            switch(l=e,i=a){case 0:case 1:
            throw Error(r(345));
            case 4:
            if((4194048&t)!==t)
            break;
            case 6:
            rS(l,t,uM,!uw);
            break n;
            case 2:
            uR=null;
            break;
            case 3:case 5:
            break;
            default:
            throw Error(r(329))
            }
            if((0x3c00000&t)===t&&10<(a=uA+300-iB())){
              if(rS(l,t,uM,!uw),0!==p(l,0,!0))
              break n;
              uH=t,l.timeoutHandle=lI(ry.bind(null,l,n,uR,uj,uN,t,uM,uP,uF,uw,i,"Throttled",-0,0),a);
              break n
              }
            ry(l,n,uR,uj,uN,t,uM,uP,uF,uw,i,null,-0,0)
            }
          }
        break
        }
      ei(e)
      }
    function ry(e,t,n,r,l,a,i,o,u,s,c,f,d,p){
      if(e.timeoutHandle=lj,8192&(f=t.subtreeFlags)||(0x1002000&f)==0x1002000){
        ra(t,a,f=l0());
        var m=(0x3c00000&a)===a?uA-iB():(4194048&a)===a?uI-iB():0;
        if(null!==(m=l2(f,m))){
          uH=a,e.cancelPendingCommit=m(rA.bind(null,e,t,a,n,r,l,i,o,u,c,f,null,d,p)),rS(e,a,i,!s);
          return
          }
        }
      rA(e,t,a,n,r,l,i,o,u)
      }
    function rS(e,t,n,r){
      t&=~uz,t&=~uP,e.suspendedLanes|=t,e.pingedLanes&=~t,r&&(e.warmLanes|=t),r=e.expirationTimes;
      for(
      var l=t
      ;0<l;){
        var a=31-i_(l),i=1<<a;
        r[a]=-1,l&=~i
        }
      0!==n&&S(e,n,t)
      }
    function rC(){
      return(6&ug)!=0||(eo(0,!1),!1)
      }
    function rw(){
      if(null!==ub){
        if(0===uS)
        var e=ub.return;
        else 
        e=ub,ou=oo=null,e8(e),oM=null,oF=0,e=ub;
        for(;null!==e;)
        nD(e.alternate,e),e=e.return;
        ub=null
        }
      }
    function rx(e,t){
      var n=e.timeoutHandle;
      n!==lj&&(e.timeoutHandle=lj,lB(n)),null!==(n=e.cancelPendingCommit)&&(e.cancelPendingCommit=null,n()),uH=0,rw(),uv=e,ub=n=rY(e.current,null),uy=t,uS=0,uC=null,uw=!1,ux=m(e,t),uk=!1,uF=uM=uz=uP=u_=uE=0,uR=uL=null,uN=!1,(8&t)!=0&&(t|=32&t);
      var r=e.entangledLanes;
      if(0!==r)
      for(e=e.entanglements,r&=t;0<r;){
        var l=31-i_(r),a=1<<l;
        t|=e[l],r&=~a
        }
      return uT=t,eP(),n
      }
    function rk(e,t){
      oq=null,lw.H=o1,t===oT||t===o_?(t=ew(),uS=3):t===oE?(t=ew(),uS=4):uS=t===o6?8:null!==t&&"object"==typeof t&&"function"==typeof t.then?6:1,uC=t,null===ub&&(uE=1,t8(e,M(t,e.current)))
      }
    function rT(){
      var e=oO.current;
      return null===e||((4194048&uy)===uy?null===oU:((0x3c00000&uy)===uy||(0x20000000&uy)!=0)&&e===oU)
      }
    function rE(){
      var e=lw.H;
      return lw.H=o1,null===e?o1:e
      }
    function r_(){
      var e=lw.A;
      return lw.A=uu,e
      }
    function rP(){
      uE=4,uw||(4194048&uy)!==uy&&null!==oO.current||(ux=!0),(0x7ffffff&u_)==0&&(0x7ffffff&uP)==0||null===uv||rS(uv,uy,uM,!1)
      }
    function rz(e,t,n){
      var r=ug;
      ug|=2;
      var l=rE(),a=r_();
      (uv!==e||uy!==t)&&(uj=null,rx(e,t)),t=!1;
      var i=uE;
      n:
      for(;;)
      try{
        if(0!==uS&&null!==ub){
          var o=ub,u=uC;
          switch(uS){case 8:
          rw(),i=6;
          break n;
          case 3:case 2:case 9:case 6:
          null===oO.current&&(t=!0);
          var s=uS;
          if(uS=0,uC=null,rL(e,o,u,s),n&&ux){
            i=0;
            break n
            }
          break;
          default:
          s=uS,uS=0,uC=null,rL(e,o,u,s)
          }
          }
        (function(){
          for(;null!==ub;)
          rM(ub)
          })(),i=uE;
        break
        }catch(t){
        rk(e,t)
        }
      return t&&e.shellSuspendCounter++,ou=oo=null,ug=r,lw.H=l,lw.A=a,null===ub&&(uv=null,uy=0,eP()),i
      }
    function rM(e){
      var t=n_(e.alternate,e,uT);
      e.memoizedProps=e.pendingProps,null===t?rR(e):ub=t
      }
    function rF(e){
      var t=e,n=t.alternate;
      switch(t.tag){case 15:case 0:
      t=np(n,t,t.pendingProps,t.type,void 0,uy);
      break;
      case 11:
      t=np(n,t,t.pendingProps,t.type.render,t.ref,uy);
      break;
      case 5:
      e8(t);
      default:
      nD(n,t),t=n_(n,t=ub=rZ(t,uT),uT)
      }
      e.memoizedProps=e.pendingProps,null===t?rR(e):ub=t
      }
    function rL(e,t,n,l){
      ou=oo=null,e8(t),oM=null,oF=0;
      var a=t.return;
      try{
        if(function(e,t,n,l,a){
          if(n.flags|=32768,null!==l&&"object"==typeof l&&"function"==typeof l.then){
            if(null!==(t=n.alternate)&&Y(t,n,a,!0),null!==(n=oO.current)){
              switch(n.tag){case 31:case 13:
              return null===oU?rP():null===n.alternate&&0===uE&&(uE=3),n.flags&=-257,n.flags|=65536,n.lanes=a,l===oP?n.flags|=16384:(null===(t=n.updateQueue)?n.updateQueue=new Set([l]):t.add(l),rV(e,l,a)),!1;
              case 22:
              return n.flags|=65536,l===oP?n.flags|=16384:(null===(t=n.updateQueue)?(t={transitions:null,markerInstances:null,retryQueue:new Set([l])},n.updateQueue=t):null===(n=t.retryQueue)?t.retryQueue=new Set([l]):n.add(l),rV(e,l,a)),!1
              }
              throw Error(r(435,n.tag))
              }
            return rV(e,l,a),rP(),!1
            }
          if(on)
          return null!==(t=oO.current)?((65536&t.flags)==0&&(t.flags|=256),t.flags|=65536,t.lanes=a,l!==oa&&W(M(e=Error(r(422),{cause:l}),n))):(l!==oa&&W(M(t=Error(r(423),{cause:l}),n)),e=e.current.alternate,e.flags|=65536,a&=-a,e.lanes|=a,l=M(l,n),a=t9(e.stateNode,l,a),eD(e,a),4!==uE&&(uE=2)),!1;
          var i=Error(r(520),{cause:l});
          if(i=M(i,n),null===uL?uL=[i]:uL.push(i),4!==uE&&(uE=2),null===t)
          return!0;
          l=M(l,n),n=t;
          do{
            switch(n.tag){case 3:
            return n.flags|=65536,e=a&-a,n.lanes|=e,e=t9(n.stateNode,l,e),eD(n,e),!1;
            case 1:
            if(t=n.type,i=n.stateNode,(128&n.flags)==0&&("function"==typeof t.getDerivedStateFromError||null!==i&&"function"==typeof i.componentDidCatch&&(null===uD||!uD.has(i))))
            return n.flags|=65536,a&=-a,n.lanes|=a,nt(a=ne(a),e,n,l),eD(n,a),!1
            }
            n=n.return
            }while(null!==n)
          return!1
          }(e,a,t,n,uy)){
          uE=1,t8(e,M(n,e.current)),ub=null;
          return
          }
        }catch(t){
        if(null!==a)
        throw ub=a,t;
        uE=1,t8(e,M(n,e.current)),ub=null;
        return
        }
      32768&t.flags?(on||1===l?e=!0:ux||(0x20000000&uy)!=0?e=!1:(uw=e=!0,(2===l||9===l||3===l||6===l)&&null!==(l=oO.current)&&13===l.tag&&(l.flags|=16384)),rN(t,e)):rR(t)
      }
    function rR(e){
      var t=e;
      do{
        if((32768&t.flags)!=0)
        return void rN(t,uw);
        e=t.return;
        var n=function(e,t,n){
          var l=t.pendingProps;
          switch(N(t),t.tag){case 16:case 15:case 0:case 11:case 7:case 8:case 12:case 9:case 14:case 1:
          return nj(t),null;
          case 3:
          return n=t.stateNode,l=null,null!==e&&(l=e.memoizedState.cache),t.memoizedState.cache!==l&&(t.flags|=2048),$(od),B(),n.pendingContext&&(n.context=n.pendingContext,n.pendingContext=null),(null===e||null===e.child)&&(H(t)?nP(t):null===e||e.memoizedState.isDehydrated&&(256&t.flags)==0||(t.flags|=1024,q())),nL(e,t),nj(t),null;
          case 26:
          if(ir){
            var a=t.type,i=t.memoizedState;
            return null===e?(nP(t),null!==i?(nj(t),nA(t,i)):(nj(t),nN(t,a,null,l,n))):i?i!==e.memoizedState?(nP(t),nj(t),nA(t,i)):(nj(t),t.flags&=-0x1000001):(i=e.memoizedProps,lG?i!==l&&nP(t):nR(e,t,a,l),nj(t),nN(t,a,i,l,n)),null
            }
          case 27:
          if(ib){
            if(D(t),n=i7.current,a=t.type,null!==e&&null!=t.stateNode)
            lG?e.memoizedProps!==l&&nP(t):nR(e,t,a,l);
            else{
              if(!l){
                if(null===t.stateNode)
                throw Error(r(166));
                return nj(t),null
                }
              e=i6.current,H(t)?O(t,e):(t.stateNode=e=iy(a,l,n,e,!0),nP(t))
              }
            return nj(t),null
            }
          case 5:
          if(D(t),a=t.type,null!==e&&null!=t.stateNode)
          nR(e,t,a,l);
          else{
            if(!l){
              if(null===t.stateNode)
              throw Error(r(166));
              return nj(t),null
              }
            if(i=i6.current,H(t))
            O(t,i),a1(t.stateNode,a,l,i)&&(t.flags|=64);
            else{
              var o=lF(a,l,i7.current,i,t);
              nz(t),nF(o,t,!1,!1),t.stateNode=o,lR(o,a,l,i)&&nP(t)
              }
            }
          return nj(t),nN(t,t.type,null===e?null:e.memoizedProps,t.pendingProps,n),null;
          case 6:
          if(e&&null!=t.stateNode)
          n=e.memoizedProps,lG?n!==l&&nP(t):lO&&(n!==l?(e=i7.current,n=i6.current,nz(t),t.stateNode=lA(l,e,n,t)):t.stateNode=e.stateNode);
          else{
            if("string"!=typeof l&&null===t.stateNode)
            throw Error(r(166));
            if(e=i7.current,n=i6.current,H(t)){
              if(!lU)
              throw Error(r(176));
              if(e=t.stateNode,n=t.memoizedProps,l=null,null!==(a=oe))
              switch(a.tag){case 27:case 5:
              l=a.memoizedProps
              }
              aW(e,n,t,l)||G(t,!0)
              }else 
            nz(t),t.stateNode=lA(l,e,n,t)
            }
          return nj(t),null;
          case 31:
          if(n=t.memoizedState,null===e||null!==e.memoizedState){
            if(l=H(t),null!==n){
              if(null===e){
                if(!l)
                throw Error(r(318));
                if(!lU)
                throw Error(r(556));
                if(!(e=null!==(e=t.memoizedState)?e.dehydrated:null))
                throw Error(r(557));
                aQ(e,t)
                }else 
              V(),(128&t.flags)==0&&(t.memoizedState=null),t.flags|=4;
              nj(t),e=!1
              }else 
            n=q(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=n),e=!0;
            if(!e)
            return 256&t.flags?(eY(t),t):(eY(t),null);
            if((128&t.flags)!=0)
            throw Error(r(558))
            }
          return nj(t),null;
          case 13:
          if(l=t.memoizedState,null===e||null!==e.memoizedState&&null!==e.memoizedState.dehydrated){
            if(a=H(t),null!==l&&null!==l.dehydrated){
              if(null===e){
                if(!a)
                throw Error(r(318));
                if(!lU)
                throw Error(r(344));
                if(!(a=null!==(a=t.memoizedState)?a.dehydrated:null))
                throw Error(r(317));
                a$(a,t)
                }else 
              V(),(128&t.flags)==0&&(t.memoizedState=null),t.flags|=4;
              nj(t),a=!1
              }else 
            a=q(),null!==e&&null!==e.memoizedState&&(e.memoizedState.hydrationErrors=a),a=!0;
            if(!a)
            return 256&t.flags?(eY(t),t):(eY(t),null)
            }
          return eY(t),(128&t.flags)!=0?(t.lanes=n,t):(n=null!==l,e=null!==e&&null!==e.memoizedState,n&&(l=t.child,a=null,null!==l.alternate&&null!==l.alternate.memoizedState&&null!==l.alternate.memoizedState.cachePool&&(a=l.alternate.memoizedState.cachePool.pool),i=null,null!==l.memoizedState&&null!==l.memoizedState.cachePool&&(i=l.memoizedState.cachePool.pool),i!==a&&(l.flags|=2048)),n!==e&&n&&(t.child.flags|=8192),nI(t,t.updateQueue),nj(t),null);
          case 4:
          return B(),nL(e,t),null===e&&lV(t.stateNode.containerInfo),nj(t),null;
          case 10:
          return $(t.type),nj(t),null;
          case 19:
          if(c(oH),null===(l=t.memoizedState))
          return nj(t),null;
          if(a=(128&t.flags)!=0,null===(i=l.rendering))
          if(a)
          nB(l,!1);
          else{
            if(0!==uE||null!==e&&(128&e.flags)!=0)
            for(e=t.child;null!==e;){
              if(null!==(i=eZ(e))){
                for(t.flags|=128,nB(l,!1),t.updateQueue=e=i.updateQueue,nI(t,e),t.subtreeFlags=0,e=n,n=t.child;null!==n;)
                rZ(n,e),n=n.sibling;
                return f(oH,1&oH.current|2),on&&F(t,l.treeForkCount),t.child
                }
              e=e.sibling
              }
            null!==l.tail&&iB()>uB&&(t.flags|=128,a=!0,nB(l,!1),t.lanes=4194304)
            }
          else{
            if(!a)
            if(null!==(e=eZ(i))){
              if(t.flags|=128,a=!0,t.updateQueue=e=e.updateQueue,nI(t,e),nB(l,!0),null===l.tail&&"hidden"===l.tailMode&&!i.alternate&&!on)
              return nj(t),null
              }else 
            2*iB()-l.renderingStartTime>uB&&0x20000000!==n&&(t.flags|=128,a=!0,nB(l,!1),t.lanes=4194304);
            l.isBackwards?(i.sibling=t.child,t.child=i):(null!==(e=l.last)?e.sibling=i:t.child=i,l.last=i)
            }
          return null!==l.tail?(e=l.tail,l.rendering=e,l.tail=e.sibling,l.renderingStartTime=iB(),e.sibling=null,n=oH.current,f(oH,a?1&n|2:1&n),on&&F(t,l.treeForkCount),e):(nj(t),null);
          case 22:case 23:
          return eY(t),eW(),l=null!==t.memoizedState,null!==e?null!==e.memoizedState!==l&&(t.flags|=8192):l&&(t.flags|=8192),l?(0x20000000&n)!=0&&(128&t.flags)==0&&(nj(t),6&t.subtreeFlags&&(t.flags|=8192)):nj(t),null!==(n=t.updateQueue)&&nI(t,n.retryQueue),n=null,null!==e&&null!==e.memoizedState&&null!==e.memoizedState.cachePool&&(n=e.memoizedState.cachePool.pool),l=null,null!==t.memoizedState&&null!==t.memoizedState.cachePool&&(l=t.memoizedState.cachePool.pool),l!==n&&(t.flags|=2048),null!==e&&c(ok),null;
          case 24:
          return n=null,null!==e&&(n=e.memoizedState.cache),t.memoizedState.cache!==n&&(t.flags|=2048),$(od),nj(t),null;
          case 25:case 30:
          return null
          }
          throw Error(r(156,t.tag))
          }(t.alternate,t,uT);
        if(null!==n){
          ub=n;
          return
          }
        if(null!==(t=t.sibling)){
          ub=t;
          return
          }
        ub=t=e
        }while(null!==t)
      0===uE&&(uE=5)
      }
    function rN(e,t){
      do{
        var n=function(e,t){
          switch(N(t),t.tag){case 1:
          return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;
          case 3:
          return $(od),B(),(65536&(e=t.flags))!=0&&(128&e)==0?(t.flags=-65537&e|128,t):null;
          case 26:case 27:case 5:
          return D(t),null;
          case 31:
          if(null!==t.memoizedState){
            if(eY(t),null===t.alternate)
            throw Error(r(340));
            V()
            }
          return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;
          case 13:
          if(eY(t),null!==(e=t.memoizedState)&&null!==e.dehydrated){
            if(null===t.alternate)
            throw Error(r(340));
            V()
            }
          return 65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;
          case 19:
          return c(oH),null;
          case 4:
          return B(),null;
          case 10:
          return $(t.type),null;
          case 22:case 23:
          return eY(t),eW(),null!==e&&c(ok),65536&(e=t.flags)?(t.flags=-65537&e|128,t):null;
          case 24:
          return $(od),null;
          default:
          return null
          }
          }(e.alternate,e);
        if(null!==n){
          n.flags&=32767,ub=n;
          return
          }
        if(null!==(n=e.return)&&(n.flags|=32768,n.subtreeFlags=0,n.deletions=null),!t&&null!==(e=e.sibling)){
          ub=e;
          return
          }
        ub=e=n
        }while(null!==e)
      uE=6,ub=null
      }
    function rA(e,t,n,l,a,i,o,u,s){
      e.cancelPendingCommit=null;
      do 
      rG();
      while(0!==uG)
      if((6&ug)!=0)
      throw Error(r(327));
      if(null!==t){
        if(t===e.current)
        throw Error(r(177));
        if(function(e,t,n,r,l,a){
          var i=e.pendingLanes;
          e.pendingLanes=n,e.suspendedLanes=0,e.pingedLanes=0,e.warmLanes=0,e.expiredLanes&=n,e.entangledLanes&=n,e.errorRecoveryDisabledLanes&=n,e.shellSuspendCounter=0;
          var o=e.entanglements,u=e.expirationTimes,s=e.hiddenUpdates;
          for(n=i&~n;0<n;){
            var c=31-i_(n),f=1<<c;
            o[c]=0,u[c]=-1;
            var d=s[c];
            if(null!==d)
            for(s[c]=null,c=0;c<d.length;c++){
              var p=d[c];
              null!==p&&(p.lane&=-0x20000001)
              }
            n&=~f
            }
          0!==r&&S(e,r,0),0!==a&&0===l&&0!==e.tag&&(e.suspendedLanes|=a&~(i&~t))
          }(e,n,i=t.lanes|t.childLanes|oI,o,u,s),e===uv&&(ub=uv=null,uy=0),uU=t,uO=e,uH=n,uV=i,uq=a,uW=l,(10256&t.subtreeFlags)!=0||(10256&t.flags)!=0?(e.callbackNode=null,e.callbackPriority=0,iR(iG,function(){
          return rO(),null
          })):(e.callbackNode=null,e.callbackPriority=0),l=(13878&t.flags)!=0,(13878&t.subtreeFlags)!=0||l){
          l=lw.T,lw.T=null,a=lW(),lq(2),o=ug,ug|=4;
          try{
            !function(e,t){
              for(lz(e.containerInfo),ur=t;null!==ur;)
              if(t=(e=ur).child,(1028&e.subtreeFlags)!=0&&null!==t)
              t.return=e,ur=t;
              else 
              for(;null!==ur;){
                var n=(e=ur).alternate;
                switch(t=e.flags,e.tag){case 0:
                if((4&t)!=0&&null!==(t=null!==(t=e.updateQueue)?t.events:null))
                for(
                var l=0
                ;l<t.length;l++){
                  var a=t[l];
                  a.ref.impl=a.nextImpl
                  }
                break;
                case 11:case 15:case 5:case 26:case 27:case 6:case 4:case 17:
                break;
                case 1:
                if((1024&t)!=0&&null!==n){
                  t=void 0,l=e,a=n.memoizedProps,n=n.memoizedState;
                  var i=l.stateNode;
                  try{
                    var o=t6(l.type,a);
                    t=i.getSnapshotBeforeUpdate(o,n),i.__reactInternalSnapshotBeforeUpdate=t
                    }catch(e){
                    rH(l,l.return,e)
                    }
                  }
                break;
                case 3:
                (1024&t)!=0&&lG&&aS(e.stateNode.containerInfo);
                break;
                default:
                if((1024&t)!=0)
                throw Error(r(163))
                }
                if(null!==(t=e.sibling)){
                  t.return=e.return,ur=t;
                  break
                  }
                ur=e.return
                }
              }(e,t)
            }finally{
            ug=o,lq(a),lw.T=l
            }
          }
        uG=1,rI(),rB(),rj()
        }
      }
    function rI(){
      if(1===uG){
        uG=0;
        var e=uO,t=uU,n=(13878&t.flags)!=0;
        if((13878&t.subtreeFlags)!=0||n){
          n=lw.T,lw.T=null;
          var r=lW();
          lq(2);
          var l=ug;
          ug|=4;
          try{
            n6(t,e),lM(e.containerInfo)
            }finally{
            ug=l,lq(r),lw.T=n
            }
          }
        e.current=t,uG=2
        }
      }
    function rB(){
      if(2===uG){
        uG=0;
        var e=uO,t=uU,n=(8772&t.flags)!=0;
        if((8772&t.subtreeFlags)!=0||n){
          n=lw.T,lw.T=null;
          var r=lW();
          lq(2);
          var l=ug;
          ug|=4;
          try{
            nJ(e,t.alternate,t)
            }finally{
            ug=l,lq(r),lw.T=n
            }
          }
        uG=3
        }
      }
    function rj(){
      if(4===uG||3===uG){
        uG=0,iI();
        var e=uO,t=uU,n=uH,r=uW;
        (10256&t.subtreeFlags)!=0||(10256&t.flags)!=0?uG=5:(uG=0,uU=uO=null,rD(e,e.pendingLanes));
        var l=e.pendingLanes;
        if(0===l&&(uD=null),k(n),t=t.stateNode,iq&&"function"==typeof iq.onCommitFiberRoot)
        try{
          iq.onCommitFiberRoot(iV,t,void 0,(128&t.current.flags)==128)
          }catch{
          }
        if(null!==r){
          t=lw.T,l=lW(),lq(2),lw.T=null;
          try{
            for(
            var a=e.onRecoverableError,i=0
            ;i<r.length;i++){
              var o=r[i];
              a(o.value,{componentStack:o.stack})
              }
            }finally{
            lw.T=t,lq(l)
            }
          }
        (3&uH)!=0&&rG(),ei(e),l=e.pendingLanes,(261930&n)!=0&&(42&l)!=0?e===u$?uQ++:(uQ=0,u$=e):uQ=0,lU&&a2(),eo(0,!1)
        }
      }
    function rD(e,t){
      0==(e.pooledCacheLanes&=t)&&null!=(t=e.pooledCache)&&(e.pooledCache=null,el(t))
      }
    function rG(){
      return rI(),rB(),rj(),rO()
      }
    function rO(){
      if(5!==uG)
      return!1;
      var e=uO,t=uV;
      uV=0;
      var n=k(uH),l=32>n?32:n;
      n=lw.T;
      var a=lW();
      try{
        lq(l),lw.T=null,l=uq,uq=null;
        var i=uO,o=uH;
        if(uG=0,uU=uO=null,uH=0,(6&ug)!=0)
        throw Error(r(331));
        var u=ug;
        if(ug|=4,ru(i.current),rn(i,i.current,o,l),ug=u,eo(0,!1),iq&&"function"==typeof iq.onPostCommitFiberRoot)
        try{
          iq.onPostCommitFiberRoot(iV,i)
          }catch{
          }
        return!0
        }finally{
        lq(a),lw.T=n,rD(e,t)
        }
      }
    function rU(e,t,n){
      t=M(n,t),t=t9(e.stateNode,t,2),null!==(e=eB(e,t,2))&&(y(e,2),ei(e))
      }
    function rH(e,t,n){
      if(3===e.tag)
      rU(e,e,n);
      else 
      for(;null!==t;){
        if(3===t.tag){
          rU(t,e,n);
          break
          }
        if(1===t.tag){
          var r=t.stateNode;
          if("function"==typeof t.type.getDerivedStateFromError||"function"==typeof r.componentDidCatch&&(null===uD||!uD.has(r))){
            e=M(n,e),null!==(r=eB(t,n=ne(2),2))&&(nt(n,r,t,e),y(r,2),ei(r));
            break
            }
          }
        t=t.return
        }
      }
    function rV(e,t,n){
      var r=e.pingCache;
      if(null===r){
        r=e.pingCache=new uh;
        var l=new Set;
        r.set(t,l)
        }else 
      void 0===(l=r.get(t))&&(l=new Set,r.set(t,l));
      l.has(n)||(uk=!0,l.add(n),e=rq.bind(null,e,t,n),t.then(e,e))
      }
    function rq(e,t,n){
      var r=e.pingCache;
      null!==r&&r.delete(t),e.pingedLanes|=e.suspendedLanes&n,e.warmLanes&=~n,uv===e&&(uy&n)===n&&(4===uE||3===uE&&(0x3c00000&uy)===uy&&300>iB()-uA?(2&ug)==0&&rx(e,0):uz|=n,uF===uy&&(uF=0)),ei(e)
      }
    function rW(e,t){
      0===t&&(t=h()),null!==(e=eF(e,t))&&(y(e,t),ei(e))
      }
    function rQ(e){
      var t=e.memoizedState,n=0;
      null!==t&&(n=t.retryLane),rW(e,n)
      }
    function r$(e,t){
      var n=0;
      switch(e.tag){case 31:case 13:
      var l=e.stateNode,a=e.memoizedState;
      null!==a&&(n=a.retryLane);
      break;
      case 19:
      l=e.stateNode;
      break;
      case 22:
      l=e.stateNode._retryCache;
      break;
      default:
      throw Error(r(314))
      }
      null!==l&&l.delete(t),rW(e,n)
      }
    function rK(e,t,n,r){
      this.tag=e,this.key=n,this.sibling=this.child=this.return=this.stateNode=this.type=this.elementType=null,this.index=0,this.refCleanup=this.ref=null,this.pendingProps=t,this.dependencies=this.memoizedState=this.updateQueue=this.memoizedProps=null,this.mode=r,this.subtreeFlags=this.flags=0,this.deletions=null,this.childLanes=this.lanes=0,this.alternate=null
      }
    function rX(e){
      return!(!(e=e.prototype)||!e.isReactComponent)
      }
    function rY(e,n){
      var r=e.alternate;
      return null===r?((r=t(e.tag,n,e.key,e.mode)).elementType=e.elementType,r.type=e.type,r.stateNode=e.stateNode,r.alternate=e,e.alternate=r):(r.pendingProps=n,r.type=e.type,r.flags=0,r.subtreeFlags=0,r.deletions=null),r.flags=0x3e00000&e.flags,r.childLanes=e.childLanes,r.lanes=e.lanes,r.child=e.child,r.memoizedProps=e.memoizedProps,r.memoizedState=e.memoizedState,r.updateQueue=e.updateQueue,n=e.dependencies,r.dependencies=null===n?null:{lanes:n.lanes,firstContext:n.firstContext},r.sibling=e.sibling,r.index=e.index,r.ref=e.ref,r.refCleanup=e.refCleanup,r
      }
    function rZ(e,t){
      e.flags&=0x3e00002;
      var n=e.alternate;
      return null===n?(e.childLanes=0,e.lanes=t,e.child=null,e.subtreeFlags=0,e.memoizedProps=null,e.memoizedState=null,e.updateQueue=null,e.dependencies=null,e.stateNode=null):(e.childLanes=n.childLanes,e.lanes=n.lanes,e.child=n.child,e.subtreeFlags=0,e.deletions=null,e.memoizedProps=n.memoizedProps,e.memoizedState=n.memoizedState,e.updateQueue=n.updateQueue,e.type=n.type,e.dependencies=null===(t=n.dependencies)?null:{lanes:t.lanes,firstContext:t.firstContext}),e
      }
    function rJ(e,n,l,a,i,o){
      var u=0;
      if(a=e,"function"==typeof e)
      rX(e)&&(u=1);
      else 
      if("string"==typeof e)
      u=ir&&ib?il(e,l,i6.current)?26:iw(e)?27:5:ir?il(e,l,i6.current)?26:5:ib&&iw(e)?27:5;
      else 
      n:
      switch(e){case lv:
      return(e=t(31,l,n,i)).elementType=lv,e.lanes=o,e;
      case lo:
      return r0(l.children,i,o,n);
      case lu:
      u=8,i|=24;
      break;
      case ls:
      return(e=t(12,l,n,2|i)).elementType=ls,e.lanes=o,e;
      case lp:
      return(e=t(13,l,n,i)).elementType=lp,e.lanes=o,e;
      case lm:
      return(e=t(19,l,n,i)).elementType=lm,e.lanes=o,e;
      default:
      if("object"==typeof e&&null!==e)
      switch(e.$$typeof){case lf:
      u=10;
      break n;
      case lc:
      u=9;
      break n;
      case ld:
      u=11;
      break n;
      case lh:
      u=14;
      break n;
      case lg:
      u=16,a=null;
      break n
      }
      u=29,l=Error(r(130,null===e?"null":typeof e,"")),a=null
      }
      return(n=t(u,l,n,i)).elementType=e,n.type=a,n.lanes=o,n
      }
    function r0(e,n,r,l){
      return(e=t(7,e,l,n)).lanes=r,e
      }
    function r1(e,n,r){
      return(e=t(6,e,null,n)).lanes=r,e
      }
    function r2(e){
      var n=t(18,null,null,0);
      return n.stateNode=e,n
      }
    function r3(e,n,r){
      return(n=t(4,null!==e.children?e.children:[],e.key,n)).lanes=r,n.stateNode={containerInfo:e.containerInfo,pendingChildren:null,implementation:e.implementation},n
      }
    function r4(e,t,n,r,l,a,i,o,u){
      this.tag=1,this.containerInfo=e,this.pingCache=this.current=this.pendingChildren=null,this.timeoutHandle=lj,this.callbackNode=this.next=this.pendingContext=this.context=this.cancelPendingCommit=null,this.callbackPriority=0,this.expirationTimes=b(-1),this.entangledLanes=this.shellSuspendCounter=this.errorRecoveryDisabledLanes=this.expiredLanes=this.warmLanes=this.pingedLanes=this.suspendedLanes=this.pendingLanes=0,this.entanglements=b(0),this.hiddenUpdates=b(null),this.identifierPrefix=r,this.onUncaughtError=l,this.onCaughtError=a,this.onRecoverableError=i,this.pooledCache=null,this.pooledCacheLanes=0,this.formState=u,this.incompleteTransitions=new Map
      }
    function r5(e,n,r,l,a,i,o,u,s,c,f,d){
      return e=new r4(e,n,r,o,s,c,f,d,u),n=1,!0===i&&(n|=24),i=t(3,null,null,n),e.current=i,i.stateNode=e,n=er(),n.refCount++,e.pooledCache=n,n.refCount++,i.memoizedState={element:l,isDehydrated:r,cache:n},eN(i),e
      }
    function r6(e){
      var t=e._reactInternals;
      if(void 0===t)
      throw"function"==typeof e.render?Error(r(188)):Error(r(268,e=Object.keys(e).join(",")));
      return null===(e=null!==(e=i(t))?function e(t){
        var n=t.tag;
        if(5===n||26===n||27===n||6===n)
        return t;
        for(t=t.child;null!==t;){
          if(null!==(n=e(t)))
          return n;
          t=t.sibling
          }
        return null
        }(e):null)?null:lE(e.stateNode)
      }
    function r8(e,t,n,r,l,a){
      l=iE,null===r.context?r.context=l:r.pendingContext=l,(r=eI(t)).payload={element:n},null!==(a=void 0===a?null:a)&&(r.callback=a),null!==(n=eB(e,r,t))&&(rv(n,e,t),ej(n,e,t))
      }
    function r7(e,t){
      if(null!==(e=e.memoizedState)&&null!==e.dehydrated){
        var n=e.retryLane;
        e.retryLane=0!==n&&n<t?n:t
        }
      }
    function r9(e,t){
      r7(e,t),(e=e.alternate)&&r7(e,t)
      }
    var le={},lt=v.default,ln=_.default,lr=Object.assign,ll=Symbol.for("react.element"),la=Symbol.for("react.transitional.element"),li=Symbol.for("react.portal"),lo=Symbol.for("react.fragment"),lu=Symbol.for("react.strict_mode"),ls=Symbol.for("react.profiler"),lc=Symbol.for("react.consumer"),lf=Symbol.for("react.context"),ld=Symbol.for("react.forward_ref"),lp=Symbol.for("react.suspense"),lm=Symbol.for("react.suspense_list"),lh=Symbol.for("react.memo"),lg=Symbol.for("react.lazy"),lv=Symbol.for("react.activity"),lb=Symbol.for("react.memo_cache_sentinel"),ly=Symbol.iterator,lS=Symbol.for("react.client.reference"),lC=Array.isArray,lw=lt.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE,lx=e.rendererVersion,lk=e.rendererPackageName,lT=e.extraDevToolsConfig,lE=e.getPublicInstance,l_=e.getRootHostContext,lP=e.getChildHostContext,lz=e.prepareForCommit,lM=e.resetAfterCommit,lF=e.createInstance;
    e.cloneMutableInstance;
    var lL=e.appendInitialChild,lR=e.finalizeInitialChildren,lN=e.shouldSetTextContent,lA=e.createTextInstance;
    e.cloneMutableTextInstance;
    var lI=e.scheduleTimeout,lB=e.cancelTimeout,lj=e.noTimeout,lD=e.isPrimaryRenderer;
    e.warnsIfNotActing;
    var lG=e.supportsMutation,lO=e.supportsPersistence,lU=e.supportsHydration,lH=e.getInstanceFromNode;
    e.beforeActiveInstanceBlur;
    var lV=e.preparePortalMount;
    e.prepareScopeUpdate,e.getInstanceFromScope;
    var lq=e.setCurrentUpdatePriority,lW=e.getCurrentUpdatePriority,lQ=e.resolveUpdatePriority;
    e.trackSchedulerEvent,e.resolveEventType,e.resolveEventTimeStamp;
    var l$=e.shouldAttemptEagerTransition,lK=e.detachDeletedInstance;
    e.requestPostPaintCallback;
    var lX=e.maySuspendCommit,lY=e.maySuspendCommitOnUpdate,lZ=e.maySuspendCommitInSyncRender,lJ=e.preloadInstance,l0=e.startSuspendingCommit,l1=e.suspendInstance;
    e.suspendOnActiveViewTransition;
    var l2=e.waitForCommitToBeReady;
    e.getSuspendedCommitReason;
    var l3=e.NotPendingTransition,l4=e.HostTransitionContext,l5=e.resetFormInstance;
    e.bindToConsole;
    var l6=e.supportsMicrotasks,l8=e.scheduleMicrotask,l7=e.supportsTestSelectors,l9=e.findFiberRoot,ae=e.getBoundingRect,at=e.getTextContent,an=e.isHiddenSubtree,ar=e.matchAccessibilityRole,al=e.setFocusIfFocusable,aa=e.setupIntersectionObserver,ai=e.appendChild,ao=e.appendChildToContainer,au=e.commitTextUpdate,as=e.commitMount,ac=e.commitUpdate,af=e.insertBefore,ad=e.insertInContainerBefore,ap=e.removeChild,am=e.removeChildFromContainer,ah=e.resetTextContent,ag=e.hideInstance,av=e.hideTextInstance,ab=e.unhideInstance,ay=e.unhideTextInstance;
    e.cancelViewTransitionName,e.cancelRootViewTransitionName,e.restoreRootViewTransitionName,e.cloneRootViewTransitionContainer,e.removeRootViewTransitionClone,e.measureClonedInstance,e.hasInstanceChanged,e.hasInstanceAffectedParent,e.startViewTransition,e.startGestureTransition,e.stopViewTransition,e.getCurrentGestureOffset,e.createViewTransitionInstance;
    var aS=e.clearContainer;
    e.createFragmentInstance,e.updateFragmentInstanceFiber,e.commitNewChildToFragmentInstance,e.deleteChildFromFragmentInstance;
    var aC=e.cloneInstance,aw=e.createContainerChildSet,ax=e.appendChildToContainerChildSet,ak=e.finalizeContainerChildren,aT=e.replaceContainerChildren,aE=e.cloneHiddenInstance,a_=e.cloneHiddenTextInstance,aP=e.isSuspenseInstancePending,az=e.isSuspenseInstanceFallback,aM=e.getSuspenseInstanceFallbackErrorDetails,aF=e.registerSuspenseInstanceRetry,aL=e.canHydrateFormStateMarker,aR=e.isFormStateMarkerMatching,aN=e.getNextHydratableSibling,aA=e.getNextHydratableSiblingAfterSingleton,aI=e.getFirstHydratableChild,aB=e.getFirstHydratableChildWithinContainer,aj=e.getFirstHydratableChildWithinActivityInstance,aD=e.getFirstHydratableChildWithinSuspenseInstance,aG=e.getFirstHydratableChildWithinSingleton,aO=e.canHydrateInstance,aU=e.canHydrateTextInstance,aH=e.canHydrateActivityInstance,aV=e.canHydrateSuspenseInstance,aq=e.hydrateInstance,aW=e.hydrateTextInstance,aQ=e.hydrateActivityInstance,a$=e.hydrateSuspenseInstance,aK=e.getNextHydratableInstanceAfterActivityInstance,aX=e.getNextHydratableInstanceAfterSuspenseInstance,aY=e.commitHydratedInstance,aZ=e.commitHydratedContainer,aJ=e.commitHydratedActivityInstance,a0=e.commitHydratedSuspenseInstance,a1=e.finalizeHydratedChildren,a2=e.flushHydrationEvents;
    e.clearActivityBoundary;
    var a3=e.clearSuspenseBoundary;
    e.clearActivityBoundaryFromContainer;
    var a4=e.clearSuspenseBoundaryFromContainer,a5=e.hideDehydratedBoundary,a6=e.unhideDehydratedBoundary,a8=e.shouldDeleteUnhydratedTailInstances;
    e.diffHydratedPropsForDevWarnings,e.diffHydratedTextForDevWarnings,e.describeHydratableInstanceForDevWarnings;
    var a7,a9,ie=e.validateHydratableInstance,it=e.validateHydratableTextInstance,ir=e.supportsResources,il=e.isHostHoistableType,ia=e.getHoistableRoot,ii=e.getResource,io=e.acquireResource,iu=e.releaseResource,is=e.hydrateHoistable,ic=e.mountHoistable,id=e.unmountHoistable,ip=e.createHoistableInstance,im=e.prepareToCommitHoistables,ih=e.mayResourceSuspendCommit,ig=e.preloadResource,iv=e.suspendResource,ib=e.supportsSingletons,iy=e.resolveSingletonInstance,iS=e.acquireSingletonInstance,iC=e.releaseSingletonInstance,iw=e.isHostSingletonType,ix=e.isSingletonScope,ik=[],iT=-1,iE={},i_=Math.clz32?Math.clz32:function(e){
      return 0==(e>>>=0)?32:31-(iP(e)/iz|0)|0
      },iP=Math.log,iz=Math.LN2,iM=256,iF=262144,iL=4194304,iR=ln.unstable_scheduleCallback,iN=ln.unstable_cancelCallback,iA=ln.unstable_shouldYield,iI=ln.unstable_requestPaint,iB=ln.unstable_now,ij=ln.unstable_ImmediatePriority,iD=ln.unstable_UserBlockingPriority,iG=ln.unstable_NormalPriority,iO=ln.unstable_IdlePriority,iU=ln.log,iH=ln.unstable_setDisableYieldValue,iV=null,iq=null,iW="function"==typeof Object.is?Object.is:function(e,t){
      return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t
      },iQ="function"==typeof reportError?reportError:function(e){
      if("object"==typeof window&&"function"==typeof window.ErrorEvent){
        var t=new window.ErrorEvent("error",{bubbles:!0,cancelable:!0,message:"object"==typeof e&&null!==e&&"string"==typeof e.message?String(e.message):String(e),error:e});
        if(!window.dispatchEvent(t))
        return
        }else 
      if("object"==typeof g.default&&"function"==typeof g.default.emit)
      return void g.default.emit("uncaughtException",e);
      console.error(e)
      },i$=Object.prototype.hasOwnProperty,iK=!1,iX=new WeakMap,iY=[],iZ=0,iJ=null,i0=0,i1=[],i2=0,i3=null,i4=1,i5="",i6=s(null),i8=s(null),i7=s(null),i9=s(null),oe=null,ot=null,on=!1,or=null,ol=!1,oa=Error(r(519)),oi=s(null),oo=null,ou=null,os="u">typeof AbortController?AbortController:function(){
      var e=[],t=this.signal={aborted:!1,addEventListener:function(t,n){
        e.push(n)
        }};
      this.abort=function(){
        t.aborted=!0,e.forEach(function(e){
          return e()
          })
        }
      },oc=ln.unstable_scheduleCallback,of=ln.unstable_NormalPriority,od={$$typeof:lf,Consumer:null,Provider:null,_currentValue:null,_currentValue2:null,_threadCount:0},op=null,om=null,oh=!1,og=!1,ov=!1,ob=0,oy=null,oS=0,oC=0,ow=null,ox=lw.S;
    lw.S=function(e,t){
      uI=iB(),"object"==typeof t&&null!==t&&"function"==typeof t.then&&function(e){
        if(null===oy){
          var t=oy=[];
          oS=0,oC=ep(),ow={status:"pending",value:void 0,then:function(e){
            t.push(e)
            }}
          }
        oS++,e.then(em,em)
        }(t),null!==ox&&ox(e,t)
      };
    var ok=s(null),oT=Error(r(460)),oE=Error(r(474)),o_=Error(r(542)),oP={then:function(){
      }},oz=null,oM=null,oF=0,oL=e_(!0),oR=e_(!1),oN=[],oA=0,oI=0,oB=!1,oj=!1,oD=s(null),oG=s(0),oO=s(null),oU=null,oH=s(0),oV=0,oq=null,oW=null,oQ=null,o$=!1,oK=!1,oX=!1,oY=0,oZ=0,oJ=null,o0=0,o1={readContext:ee,use:tn,useCallback:eJ,useContext:eJ,useEffect:eJ,useImperativeHandle:eJ,useLayoutEffect:eJ,useInsertionEffect:eJ,useMemo:eJ,useReducer:eJ,useRef:eJ,useState:eJ,useDebugValue:eJ,useDeferredValue:eJ,useTransition:eJ,useSyncExternalStore:eJ,useId:eJ,useHostTransitionStatus:eJ,useFormState:eJ,useActionState:eJ,useOptimistic:eJ,useMemoCache:eJ,useCacheRefresh:eJ};
    o1.useEffectEvent=eJ;
    var o2={readContext:ee,use:tn,useCallback:function(e,t){
      return e7().memoizedState=[e,void 0===t?null:t],e
      },useContext:ee,useEffect:tL,useImperativeHandle:function(e,t,n){
      n=null!=n?n.concat([e]):null,tM(4194308,4,tB.bind(null,t,e),n)
      },useLayoutEffect:function(e,t){
      return tM(4194308,4,e,t)
      },useInsertionEffect:function(e,t){
      tM(4,2,e,t)
      },useMemo:function(e,t){
      var n=e7();
      t=void 0===t?null:t;
      var r=e();
      return n.memoizedState=[r,t],r
      },useReducer:function(e,t,n){
      var r=e7();
      if(void 0!==n)
      var l=n(t);
      else 
      l=t;
      return r.memoizedState=r.baseState=l,r.queue=e={pending:null,lanes:0,dispatch:null,lastRenderedReducer:e,lastRenderedState:l},e=e.dispatch=tX.bind(null,oq,e),[r.memoizedState,e]
      },useRef:function(e){
      return e7().memoizedState={current:e}
      },useState:function(e){
      var t=(e=tm(e)).queue,n=tY.bind(null,oq,t);
      return t.dispatch=n,[e.memoizedState,n]
      },useDebugValue:tD,useDeferredValue:function(e,t){
      return tU(e7(),e,t)
      },useTransition:function(){
      var e=tm(!1);
      return e=tV.bind(null,oq,e.queue,!0,!1),e7().memoizedState=e,[!1,e]
      },useSyncExternalStore:function(e,t,n){
      var l=oq,a=e7();
      if(on){
        if(void 0===n)
        throw Error(r(407));
        n=n()
        }else{
        if(n=t(),null===uv)
        throw Error(r(349));
        (127&uy)!=0||ts(l,t,n)
        }
      a.memoizedState=n;
      var i={value:n,getSnapshot:t};
      return a.queue=i,tL(tf.bind(null,l,i,e),[e]),l.flags|=2048,tP(9,{destroy:void 0},tc.bind(null,l,i,n,t),null),n
      },useId:function(){
      var e=e7(),t=uv.identifierPrefix;
      if(on){
        var n=i5,r=i4;
        t="_"+t+"R_"+(n=(r&~(1<<32-i_(r)-1)).toString(32)+n),0<(n=oY++)&&(t+="H"+n.toString(32)),t+="_"
        }else 
      t="_"+t+"r_"+(n=o0++).toString(32)+"_";
      return e.memoizedState=t
      },useHostTransitionStatus:tW,useFormState:tx,useActionState:tx,useOptimistic:function(e){
      var t=e7();
      t.memoizedState=t.baseState=e;
      var n={pending:null,lanes:0,dispatch:null,lastRenderedReducer:null,lastRenderedState:null};
      return t.queue=n,t=tJ.bind(null,oq,!0,n),n.dispatch=t,[e,t]
      },useMemoCache:tr,useCacheRefresh:function(){
      return e7().memoizedState=tK.bind(null,oq)
      },useEffectEvent:function(e){
      var t=e7(),n={impl:e};
      return t.memoizedState=n,function(){
        if((2&ug)!=0)
        throw Error(r(440));
        return n.impl.apply(void 0,arguments)
        }
      }},o3={readContext:ee,use:tn,useCallback:tG,useContext:ee,useEffect:tR,useImperativeHandle:tj,useInsertionEffect:tA,useLayoutEffect:tI,useMemo:tO,useReducer:ta,useRef:tz,useState:function(){
      return ta(tl)
      },useDebugValue:tD,useDeferredValue:function(e,t){
      return tH(e9(),oW.memoizedState,e,t)
      },useTransition:function(){
      var e=ta(tl)[0],t=e9().memoizedState;
      return["boolean"==typeof e?e:tt(e),t]
      },useSyncExternalStore:tu,useId:tQ,useHostTransitionStatus:tW,useFormState:tk,useActionState:tk,useOptimistic:function(e,t){
      return th(e9(),oW,e,t)
      },useMemoCache:tr,useCacheRefresh:t$};
    o3.useEffectEvent=tN;
    var o4={readContext:ee,use:tn,useCallback:tG,useContext:ee,useEffect:tR,useImperativeHandle:tj,useInsertionEffect:tA,useLayoutEffect:tI,useMemo:tO,useReducer:to,useRef:tz,useState:function(){
      return to(tl)
      },useDebugValue:tD,useDeferredValue:function(e,t){
      var n=e9();
      return null===oW?tU(n,e,t):tH(n,oW.memoizedState,e,t)
      },useTransition:function(){
      var e=to(tl)[0],t=e9().memoizedState;
      return["boolean"==typeof e?e:tt(e),t]
      },useSyncExternalStore:tu,useId:tQ,useHostTransitionStatus:tW,useFormState:t_,useActionState:t_,useOptimistic:function(e,t){
      var n=e9();
      return null!==oW?th(n,oW,e,t):(n.baseState=e,[e,n.queue.dispatch])
      },useMemoCache:tr,useCacheRefresh:t$};
    o4.useEffectEvent=tN;
    var o5={enqueueSetState:function(e,t,n){
      e=e._reactInternals;
      var r=rh(),l=eI(r);
      l.payload=t,null!=n&&(l.callback=n),null!==(t=eB(e,l,r))&&(rv(t,e,r),ej(t,e,r))
      },enqueueReplaceState:function(e,t,n){
      e=e._reactInternals;
      var r=rh(),l=eI(r);
      l.tag=1,l.payload=t,null!=n&&(l.callback=n),null!==(t=eB(e,l,r))&&(rv(t,e,r),ej(t,e,r))
      },enqueueForceUpdate:function(e,t){
      e=e._reactInternals;
      var n=rh(),r=eI(n);
      r.tag=2,null!=t&&(r.callback=t),null!==(t=eB(e,r,n))&&(rv(t,e,n),ej(t,e,n))
      }},o6=Error(r(461)),o8=!1,o7={dehydrated:null,treeContext:null,retryLane:0,hydrationErrors:null},o9=!1,ue=!1,ut=!1,un="function"==typeof WeakSet?WeakSet:Set,ur=null,ul=null,ua=!1,ui=null,uo=8192,uu={getCacheForType:function(e){
      var t=ee(od),n=t.data.get(e);
      return void 0===n&&(n=e(),t.data.set(e,n)),n
      },cacheSignal:function(){
      return ee(od).controller.signal
      }},us=0,uc=1,uf=2,ud=3,up=4;
    if("function"==typeof Symbol&&Symbol.for){
      var um=Symbol.for;
      us=um("selector.component"),uc=um("selector.has_pseudo_class"),uf=um("selector.role"),ud=um("selector.test_id"),up=um("selector.text")
      }
    var uh="function"==typeof WeakMap?WeakMap:Map,ug=0,uv=null,ub=null,uy=0,uS=0,uC=null,uw=!1,ux=!1,uk=!1,uT=0,uE=0,u_=0,uP=0,uz=0,uM=0,uF=0,uL=null,uR=null,uN=!1,uA=0,uI=0,uB=1/0,uj=null,uD=null,uG=0,uO=null,uU=null,uH=0,uV=0,uq=null,uW=null,uQ=0,u$=null;
    return le.attemptContinuousHydration=function(e){
      if(13===e.tag||31===e.tag){
        var t=eF(e,0x4000000);
        null!==t&&rv(t,e,0x4000000),r9(e,0x4000000)
        }
      },le.attemptHydrationAtCurrentPriority=function(e){
      if(13===e.tag||31===e.tag){
        var t=rh(),n=eF(e,t=x(t));
        null!==n&&rv(n,e,t),r9(e,t)
        }
      },le.attemptSynchronousHydration=function(e){
      switch(e.tag){case 3:
      if((e=e.stateNode).current.memoizedState.isDehydrated){
        var t=d(e.pendingLanes);
        if(0!==t){
          for(e.pendingLanes|=2,e.entangledLanes|=2;t;){
            var n=1<<31-i_(t);
            e.entanglements[1]|=n,t&=~n
            }
          ei(e),(6&ug)==0&&(uB=iB()+500,eo(0,!1))
          }
        }
      break;
      case 31:case 13:
      null!==(t=eF(e,2))&&rv(t,e,2),rC(),r9(e,2)
      }
      },le.batchedUpdates=function(e,t){
      return e(t)
      },le.createComponentSelector=function(e){
      return{$$typeof:us,value:e}
      },le.createContainer=function(e,t,n,r,l,a,i,o,u,s){
      return r5(e,t,!1,null,n,r,a,null,i,o,u,s)
      },le.createHasPseudoClassSelector=function(e){
      return{$$typeof:uc,value:e}
      },le.createHydrationContainer=function(e,t,n,r,l,a,i,o,u,s,c,f,d,p){
      var m;
      return(e=r5(n,r,!0,e,l,a,o,p,u,s,c,f)).context=iE,n=e.current,(l=eI(r=x(r=rh()))).callback=null!=(m=t)?m:null,eB(n,l,r),t=r,e.current.lanes=t,y(e,t),ei(e),e
      },le.createPortal=function(e,t,n){
      var r=3<arguments.length&&void 0!==arguments[3]?arguments[3]:null;
      return{$$typeof:li,key:null==r?null:""+r,children:e,containerInfo:t,implementation:n}
      },le.createRoleSelector=function(e){
      return{$$typeof:uf,value:e}
      },le.createTestNameSelector=function(e){
      return{$$typeof:ud,value:e}
      },le.createTextSelector=function(e){
      return{$$typeof:up,value:e}
      },le.defaultOnCaughtError=function(e){
      console.error(e)
      },le.defaultOnRecoverableError=function(e){
      iQ(e)
      },le.defaultOnUncaughtError=function(e){
      iQ(e)
      },le.deferredUpdates=function(e){
      var t=lw.T,n=lW();
      try{
        return lq(32),lw.T=null,e()
        }finally{
        lq(n),lw.T=t
        }
      },le.discreteUpdates=function(e,t,n,r,l){
      var a=lw.T,i=lW();
      try{
        return lq(2),lw.T=null,e(t,n,r,l)
        }finally{
        lq(i),lw.T=a,0===ug&&(uB=iB()+500)
        }
      },le.findAllNodes=rm,le.findBoundingRects=function(e,t){
      if(!l7)
      throw Error(r(363));
      t=rm(e,t),e=[];
      for(
      var n=0
      ;n<t.length;n++)
      e.push(ae(t[n]));
      for(t=e.length-1;0<t;t--){
        n=e[t];
        for(
        var l=n.x,a=l+n.width,i=n.y,o=i+n.height,u=t-1
        ;0<=u;u--)
        if(t!==u){
          var s=e[u],c=s.x,f=c+s.width,d=s.y,p=d+s.height;
          if(l>=c&&i>=d&&a<=f&&o<=p){
            e.splice(t,1);
            break
            }
          if(l!==c||n.width!==s.width||p<i||d>o){
            if(!(i!==d||n.height!==s.height||f<l||c>a)){
              c>l&&(s.width+=c-l,s.x=l),f<a&&(s.width=a-c),e.splice(t,1);
              break
              }
            }else{
            d>i&&(s.height+=d-i,s.y=i),p<o&&(s.height=o-d),e.splice(t,1);
            break
            }
          }
        }
      return e
      },le.findHostInstance=r6,le.findHostInstanceWithNoPortals=function(e){
      return null===(e=null!==(e=i(e))?function e(t){
        var n=t.tag;
        if(5===n||26===n||27===n||6===n)
        return t;
        for(t=t.child;null!==t;){
          if(4!==t.tag&&null!==(n=e(t)))
          return n;
          t=t.sibling
          }
        return null
        }(e):null)?null:lE(e.stateNode)
      },le.findHostInstanceWithWarning=function(e){
      return r6(e)
      },le.flushPassiveEffects=rG,le.flushSyncFromReconciler=function(e){
      var t=ug;
      ug|=1;
      var n=lw.T,r=lW();
      try{
        if(lq(2),lw.T=null,e)
        return e()
        }finally{
        lq(r),lw.T=n,(6&(ug=t))==0&&eo(0,!1)
        }
      },le.flushSyncWork=rC,le.focusWithin=function(e,t){
      if(!l7)
      throw Error(r(363));
      for(t=Array.from(t=rp(e=rc(e),t)),e=0;e<t.length;){
        var n=t[e++],l=n.tag;
        if(!an(n)){
          if((5===l||26===l||27===l)&&al(n.stateNode))
          return!0;
          for(n=n.child;null!==n;)
          t.push(n),n=n.sibling
          }
        }
      return!1
      },le.getFindAllNodesFailureDescription=function(e,t){
      if(!l7)
      throw Error(r(363));
      var n=0,l=[];
      e=[rc(e),0];
      for(
      var a=0
      ;a<e.length;){
        var i=e[a++],o=i.tag,u=e[a++],s=t[u];
        if((5!==o&&26!==o&&27!==o||!an(i))&&(rf(i,s)&&(l.push(rd(s)),++u>n&&(n=u)),u<t.length))
        for(i=i.child;null!==i;)
        e.push(i,u),i=i.sibling
        }
      if(n<t.length){
        for(e=[];n<t.length;n++)
        e.push(rd(t[n]));
        return`findAllNodes was able to match part of the selector:
  `+l.join(" > ")+`

No matching component was found for:
  `+e.join(" > ")
        }
      return null
      },le.getPublicRootInstance=function(e){
      if(!(e=e.current).child)
      return null;
      switch(e.child.tag){case 27:case 5:
      return lE(e.child.stateNode);
      default:
      return e.child.stateNode
      }
      },le.injectIntoDevTools=function(){
      var e={bundleType:0,version:lx,rendererPackageName:lk,currentDispatcherRef:lw,reconcilerVersion:"19.2.0"};
      if(null!==lT&&(e.rendererConfig=lT),typeof __REACT_DEVTOOLS_GLOBAL_HOOK__>"u")
      e=!1;
      else{
        var t=__REACT_DEVTOOLS_GLOBAL_HOOK__;
        if(t.isDisabled||!t.supportsFiber)
        e=!0;
        else{
          try{
            iV=t.inject(e),iq=t
            }catch{
            }
          e=!!t.checkDCE
          }
        }
      return e
      },le.isAlreadyRendering=function(){
      return(6&ug)!=0
      },le.observeVisibleRects=function(e,t,n,l){
      if(!l7)
      throw Error(r(363));
      var a=aa(e=rm(e,t),n,l).disconnect;
      return{disconnect:function(){
        a()
        }}
      },le.shouldError=function(){
      return null
      },le.shouldSuspend=function(){
      return!1
      },le.startHostTransition=function(e,t,l,a){
      if(5!==e.tag)
      throw Error(r(476));
      var i=tq(e).queue;
      tV(e,i,t,l3,null===l?n:function(){
        var t=tq(e);
        return null===t.next&&(t=e.alternate.memoizedState),tZ(e,t.next.queue,{},rh()),l(a)
        })
      },le.updateContainer=function(e,t,n,r){
      var l=t.current,a=rh();
      return r8(l,a,e,t,n,r),a
      },le.updateContainerSync=function(e,t,n,r){
      return r8(t.current,2,e,t,n,r),2
      },le
    },ev.exports.default=ev.exports,Object.defineProperty(ev.exports,"__esModule",{value:!0})),eg.exports=ev.exports),(d=eg.exports)&&d.__esModule&&Object.prototype.hasOwnProperty.call(d,"default"))?d.default:d,ey={},eS=/^three(?=[A-Z])/,eC=e=>`${e[0].toUpperCase()}${e.slice(1)}`,ew=0;
  function ex(e){
    if("function"==typeof e){
      let t=`${ew++}`;
      return ey[t]=e,t
      }
    Object.assign(ey,e)
    }
  function ek(e,t){
    let n=eC(e),r=ey[n];
    if("primitive"!==e&&!r)
    throw Error(`R3F: ${n} is not part of the THREE namespace! Did you forget to extend? See: https://docs.pmnd.rs/react-three-fiber/api/objects#using-3rd-party-objects-declaratively`);
    if("primitive"===e&&!t.object)
    throw Error("R3F: Primitives without 'object' are invalid!");
    if(void 0!==t.args&&!Array.isArray(t.args))
    throw Error("R3F: The args prop must be an array!")
    }
  function eT(e){
    if(e.isHidden){
      var t;
      e.props.attach&&null!=(t=e.parent)&&t.object?Z(e.parent,e):ei(e.object)&&!1!==e.props.visible&&(e.object.visible=!0),e.isHidden=!1,ea(e)
      }
    }
  function eE(e,t,n){
    let r=t.root.getState();
    if(e.parent||e.object===r.scene){
      if(!t.object){
        var l,a;
        let e=ey[eC(t.type)];
        t.object=null!=(l=t.props.object)?l:new e(...null!=(a=t.props.args)?a:[]),t.object.__r3f=t
        }
      if(el(t.object,t.props),t.props.attach)
      Z(e,t);
      else 
      if(ei(t.object)&&ei(e.object)){
        let r=e.object.children.indexOf(null==n?void 0:n.object);
        if(n&&-1!==r){
          let n=e.object.children.indexOf(t.object);
          -1!==n?(e.object.children.splice(n,1),e.object.children.splice(n<r?r-1:r,0,t.object)):(t.object.parent=e.object,e.object.children.splice(r,0,t.object),t.object.dispatchEvent({type:"added"}),e.object.dispatchEvent({type:"childadded",child:t.object}))
          }else 
        e.object.add(t.object)
        }
      for(
      let e
       of t.children)
      eE(t,e);
      ea(t)
      }
    }
  function e_(e,t){
    t&&(t.parent=e,e.children.push(t),eE(e,t))
    }
  function eP(e,t,n){
    if(!t||!n)
    return;
    t.parent=e;
    let r=e.children.indexOf(n);
    -1!==r?e.children.splice(r,0,t):e.children.push(t),eE(e,t,n)
    }
  function ez(e){
    if("function"==typeof e.dispose){
      let t=()=>{
        try{
          e.dispose()
          }catch{
          }
        };
      "u">typeof IS_REACT_ACT_ENVIRONMENT?t():(0,_.unstable_scheduleCallback)(_.unstable_IdlePriority,t)
      }
    }
  function eM(e,t,n){
    if(!t)
    return;
    t.parent=null;
    let r=e.children.indexOf(t);
    -1!==r&&e.children.splice(r,1),t.props.attach?J(e,t):ei(t.object)&&ei(e.object)&&(e.object.remove(t.object),function(e,t){
      let{internal:n}=e.getState();
      n.interaction=n.interaction.filter(e=>e!==t),n.initialHits=n.initialHits.filter(e=>e!==t),n.hovered.forEach((e,r)=>{
        (e.eventObject===t||e.object===t)&&n.hovered.delete(r)
        }),n.capturedMap.forEach((e,r)=>{
        eu(n.capturedMap,t,e,r)
        })
      }(B(t),t.object));
    let l=null!==t.props.dispose&&!1!==n;
    for(
    let e=t.children.length-1
    ;e>=0;e--){
      let n=t.children[e];
      eM(t,n,l)
      }
    t.children.length=0,delete t.object.__r3f,l&&"primitive"!==t.type&&"Scene"!==t.object.type&&ez(t.object),void 0===n&&ea(t)
    }
  let eF=[],eL=()=>{
    },eR={},eN=0,eA=(p={isPrimaryRenderer:!1,warnsIfNotActing:!1,supportsMutation:!0,supportsPersistence:!1,supportsHydration:!1,createInstance:function(e,t,n){
    var r;
    return ek(e=eC(e)in ey?e:e.replace(eS,""),t),"primitive"===e&&null!=(r=t.object)&&r.__r3f&&delete t.object.__r3f,K(t.object,n,e,t)
    },removeChild:eM,appendChild:e_,appendInitialChild:e_,insertBefore:eP,appendChildToContainer(e,t){
    let n=e.getState().scene.__r3f;
    t&&n&&e_(n,t)
    },removeChildFromContainer(e,t){
    let n=e.getState().scene.__r3f;
    t&&n&&eM(n,t)
    },insertInContainerBefore(e,t,n){
    let r=e.getState().scene.__r3f;
    t&&n&&r&&eP(r,t,n)
    },getRootHostContext:()=>eR,getChildHostContext:()=>eR,commitUpdate(e,t,n,r,l){
    var a,i,o;
    ek(t,r);
    let u=!1;
    if("primitive"===e.type&&n.object!==r.object||(null==(a=r.args)?void 0:a.length)!==(null==(i=n.args)?void 0:i.length)?u=!0:null!=(o=r.args)&&o.some((e,t)=>{
      var r;
      return e!==(null==(r=n.args)?void 0:r[t])
      })&&(u=!0),u)
    eF.push([e,{...r},l]);
    else{
      let t=function(e,t){
        let n={};
        for(
        let r
         in t)
        if(!ee.includes(r)&&!Q.equ(t[r],e.props[r]))
        for(
        let e
         in n[r]=t[r],t)
        e.startsWith(`${r}-`)&&(n[e]=t[e]);
        for(
        let r
         in e.props){
          if(ee.includes(r)||t.hasOwnProperty(r))
          continue;
          let{root:l,key:a}=X(e.object,r);
          if(l.constructor&&0===l.constructor.length){
            let e=function(e){
              let t=et.get(e.constructor);
              try{
                t||(t=new e.constructor,et.set(e.constructor,t))
                }catch(e){
                }
              return t
              }(l);
            Q.und(e)||(n[a]=e[a])
            }else 
          n[a]=0
          }
        return n
        }(e,r);
      Object.keys(t).length&&(Object.assign(e.props,t),el(e.object,t))
      }
    (null===l.sibling||(4&l.flags)==0)&&function(){
      for(
      let[e]
      of eF){
        let t=e.parent;
        if(t)
        for(
        let n
         of(e.props.attach?J(t,e):ei(e.object)&&ei(t.object)&&t.object.remove(e.object),e.children))
        n.props.attach?J(e,n):ei(n.object)&&ei(e.object)&&e.object.remove(n.object);
        e.isHidden&&eT(e),e.object.__r3f&&delete e.object.__r3f,"primitive"!==e.type&&ez(e.object)
        }
      for(
      let[r,l,a]
      of eF){
        r.props=l;
        let i=r.parent;
        if(i){
          let l=ey[eC(r.type)],o=r.object;
          r.object=null!=(e=r.props.object)?e:new l(...null!=(t=r.props.args)?t:[]),r.object.__r3f=r;
          var e,t,n=r.object;
          for(
          let e
           of[a,a.alternate])
          if(null!==e)
          if("function"==typeof e.ref){
            null==e.refCleanup||e.refCleanup();
            let t=e.ref(n);
            "function"==typeof t&&(e.refCleanup=t)
            }else 
          e.ref&&(e.ref.current=n);
          for(
          let e
           of(!function(e,t,n){
            let{internal:r}=e.getState();
            for(
            let e=0
            ;e<r.interaction.length;e++)
            r.interaction[e]===t&&(r.interaction[e]=n);
            for(
            let e=0
            ;e<r.initialHits.length;e++)
            r.initialHits[e]===t&&(r.initialHits[e]=n);
            r.hovered.forEach((e,l)=>{
              if(e.eventObject===t||e.object===t){
                r.hovered.delete(l);
                let a={...e,eventObject:e.eventObject===t?n:e.eventObject,object:e.object===t?n:e.object};
                r.hovered.set(eo(a),a)
                }
              }),r.capturedMap.forEach(e=>{
              let r=e.get(t);
              r&&(e.delete(t),e.set(n,r))
              })
            }(B(r),o,r.object),el(r.object,r.props),r.props.attach?Z(i,r):ei(r.object)&&ei(i.object)&&i.object.add(r.object),r.children))
          e.props.attach?Z(r,e):ei(e.object)&&ei(r.object)&&r.object.add(e.object);
          ea(r)
          }
        }
      eF.length=0
      }()
    },finalizeInitialChildren:()=>!1,commitMount(){
    },getPublicInstance:e=>null==e?void 0:e.object,prepareForCommit:()=>null,preparePortalMount:e=>K(e.getState().scene,e,"",{}),resetAfterCommit:()=>{
    },shouldSetTextContent:()=>!1,clearContainer:()=>!1,hideInstance:function(e){
    if(!e.isHidden){
      var t;
      e.props.attach&&null!=(t=e.parent)&&t.object?J(e.parent,e):ei(e.object)&&(e.object.visible=!1),e.isHidden=!0,ea(e)
      }
    },unhideInstance:eT,createTextInstance:eL,hideTextInstance:eL,unhideTextInstance:eL,scheduleTimeout:"function"==typeof setTimeout?setTimeout:void 0,cancelTimeout:"function"==typeof clearTimeout?clearTimeout:void 0,noTimeout:-1,getInstanceFromNode:()=>null,beforeActiveInstanceBlur(){
    },afterActiveInstanceBlur(){
    },detachDeletedInstance(){
    },prepareScopeUpdate(){
    },getInstanceFromScope:()=>null,shouldAttemptEagerTransition:()=>!1,trackSchedulerEvent:()=>{
    },resolveEventType:()=>null,resolveEventTimeStamp:()=>-1.1,requestPostPaintCallback(){
    },maySuspendCommit:()=>!1,preloadInstance:()=>!0,suspendInstance(){
    },waitForCommitToBeReady:()=>null,NotPendingTransition:null,HostTransitionContext:v.createContext(null),setCurrentUpdatePriority(e){
    eN=e
    },getCurrentUpdatePriority:()=>eN,resolveUpdatePriority(){
    var e;
    if(0!==eN)
    return eN;
    switch("u">typeof window&&(null==(e=window.event)?void 0:e.type)){case"click":case"contextmenu":case"dblclick":case"pointercancel":case"pointerdown":case"pointerup":
    return 2;
    case"pointermove":case"pointerout":case"pointerover":case"pointerenter":case"pointerleave":case"wheel":
    return 8;
    default:
    return 32
    }
    },resetFormInstance(){
    },rendererPackageName:"@react-three/fiber",rendererVersion:"9.6.1",applyViewTransitionName(e,t,n){
    },restoreViewTransitionName(e,t){
    },cancelViewTransitionName(e,t,n){
    },cancelRootViewTransitionName(e){
    },restoreRootViewTransitionName(e){
    },InstanceMeasurement:null,measureInstance:e=>null,wasInstanceInViewport:e=>!0,hasInstanceChanged:(e,t)=>!1,hasInstanceAffectedParent:(e,t)=>!1,suspendOnActiveViewTransition(e,t){
    },startGestureTransition:()=>null,startViewTransition:()=>null,stopViewTransition(e){
    },createViewTransitionInstance:e=>null,getCurrentGestureOffset(e){
    throw Error("startGestureTransition is not yet supported in react-three-fiber.")
    },cloneMutableInstance:(e,t)=>e,cloneMutableTextInstance:e=>e,cloneRootViewTransitionContainer(e){
    throw Error("Not implemented.")
    },removeRootViewTransitionClone(e,t){
    throw Error("Not implemented.")
    },createFragmentInstance:e=>null,updateFragmentInstanceFiber(e,t){
    },commitNewChildToFragmentInstance(e,t){
    },deleteChildFromFragmentInstance(e,t){
    },measureClonedInstance:e=>null,maySuspendCommitOnUpdate:(e,t,n)=>!1,maySuspendCommitInSyncRender:(e,t)=>!1,startSuspendingCommit:()=>null,getSuspendedCommitReason:(e,t)=>null},(s=eb(p)).injectIntoDevTools(),s),eI=new Map,eB={objects:"shallow",strict:!1};
  function ej(e){
    var t,n;
    let r,l,a,i,o,u,s,c,f,d=eI.get(e),p=null==d?void 0:d.fiber,m=null==d?void 0:d.store;
    d&&console.warn("R3F.createRoot should only be called once!");
    let h="function"==typeof reportError?reportError:console.error,g=m||(t=eX,n=eY,s=(u=(o=(a=(e,r)=>{
      let l,a=new b.Vector3,i=new b.Vector3,o=new b.Vector3;
      function u(e=r().camera,t=i,n=r().size){
        let{width:l,height:s,top:c,left:f}=n,d=l/s;
        t.isVector3?o.copy(t):o.set(...t);
        let p=e.getWorldPosition(a).distanceTo(o);
        if(e&&e.isOrthographicCamera)
        return{width:l/e.zoom,height:s/e.zoom,top:c,left:f,factor:1,distance:p,aspect:d};
        {
          let t=2*Math.tan(e.fov*Math.PI/180/2)*p,n=l/s*t;
          return{width:n,height:t,top:c,left:f,factor:l/n,distance:p,aspect:d}
          }
      }
      let s=t=>e(e=>({performance:{...e.performance,current:t}})),c=new b.Vector2;
      return{set:e,get:r,gl:null,camera:null,raycaster:null,events:{priority:1,enabled:!0,connected:!1},scene:null,xr:null,invalidate:(e=1)=>t(r(),e),advance:(e,t)=>n(e,t,r()),legacy:!1,linear:!1,flat:!1,controls:null,clock:new b.Clock,pointer:c,mouse:c,frameloop:"always",onPointerMissed:void 0,performance:{current:1,min:.5,max:1,debounce:200,regress:()=>{
        let e=r();
        l&&clearTimeout(l),e.performance.current!==e.performance.min&&s(e.performance.min),l=setTimeout(()=>s(r().performance.max),e.performance.debounce)
        }},size:{width:0,height:0,top:0,left:0},viewport:{initialDpr:0,dpr:0,width:0,height:0,top:0,left:0,aspect:0,distance:0,factor:0,getCurrentViewport:u},setEvents:t=>e(e=>({...e,events:{...e.events,...t}})),setSize:(t,n,l=0,a=0)=>{
        let o=r().camera,s={width:t,height:n,top:l,left:a};
        e(e=>({size:s,viewport:{...e.viewport,...u(o,i,s)}}))
        },setDpr:t=>e(e=>{
        let n=q(t);
        return{viewport:{...e.viewport,dpr:n,initialDpr:e.viewport.initialDpr||n}}
        }),setFrameloop:(t="always")=>{
        let n=r().clock;
        n.stop(),n.elapsedTime=0,"never"!==t&&(n.start(),n.elapsedTime=0),e(()=>({frameloop:t}))
        },previousRoot:void 0,internal:{interaction:[],hovered:new Map,subscribers:[],initialClick:[0,0],initialHits:[],capturedMap:new Map,lastEvent:v.createRef(),active:!1,frames:0,priority:0,subscribe:(e,t,n)=>{
        let l=r().internal;
        return l.priority=l.priority+ +(t>0),l.subscribers.push({ref:e,priority:t,store:n}),l.subscribers=l.subscribers.sort((e,t)=>e.priority-t.priority),()=>{
          let n=r().internal;
          null!=n&&n.subscribers&&(n.priority=n.priority-(t>0),n.subscribers=n.subscribers.filter(t=>t.ref!==e))
          }
        }}}
      })?x(a,i):x).getState()).size,c=u.viewport.dpr,f=u.camera,o.subscribe(()=>{
      let{camera:e,size:t,viewport:n,gl:r,set:l}=o.getState();
      if(t.width!==s.width||t.height!==s.height||n.dpr!==c){
        s=t,c=n.dpr;
        !e.manual&&(e&&e.isOrthographicCamera?(e.left=-(t.width/2),e.right=t.width/2,e.top=t.height/2,e.bottom=-(t.height/2)):e.aspect=t.width/t.height,e.updateProjectionMatrix());
        n.dpr>0&&r.setPixelRatio(n.dpr);
        let l="u">typeof HTMLCanvasElement&&r.domElement instanceof HTMLCanvasElement;
        r.setSize(t.width,t.height,l)
        }
      e!==f&&(f=e,l(t=>({viewport:{...t.viewport,...t.viewport.getCurrentViewport(e)}})))
      }),o.subscribe(e=>t(e)),o),S=p||eA.createContainer(g,1,null,!1,null,"",h,h,h,null);
    d||eI.set(e,{fiber:S,store:g});
    let C=!1,w=null;
    return{async configure(t={}){
      var n,a;
      let i;
      w=new Promise(e=>i=e);
      let{gl:o,size:u,scene:s,events:c,onCreated:f,shadows:d=!1,linear:p=!1,flat:m=!1,legacy:h=!1,orthographic:v=!1,frameloop:S="always",dpr:x=[1,2],performance:k,raycaster:T,camera:E,onPointerMissed:_}=t,P=g.getState(),z=P.gl;
      if(!P.gl){
        let t={canvas:e,powerPreference:"high-performance",antialias:!0,alpha:!0},n="function"==typeof o?await o(t):o;
        z=es(n)?n:new y.WebGLRenderer({...t,...o}),P.set({gl:z})
        }
      let M=P.raycaster;
      M||P.set({raycaster:M=new b.Raycaster});
      let{params:F,...L}=T||{};
      if(Q.equ(L,M,eB)||el(M,{...L}),Q.equ(F,M.params,eB)||el(M,{params:{...M.params,...F}}),!P.camera||P.camera===l&&!Q.equ(l,E,eB)){
        l=E;
        let e=null==E?void 0:E.isCamera,t=e?E:v?new b.OrthographicCamera(0,0,0,0,.1,1e3):new b.PerspectiveCamera(75,0,.1,1e3);
        !e&&(t.position.z=5,E&&(el(t,E),!t.manual&&("aspect"in E||"left"in E||"right"in E||"bottom"in E||"top"in E)&&(t.manual=!0,t.updateProjectionMatrix())),P.camera||null!=E&&E.rotation||t.lookAt(0,0,0)),P.set({camera:t}),M.camera=t
        }
      if(!P.scene){
        let e;
        null!=s&&s.isScene?K(e=s,g,"",{}):(K(e=new b.Scene,g,"",{}),s&&el(e,s)),P.set({scene:e})
        }
      c&&!P.events.handlers&&P.set({events:c(g)});
      let R=function(e,t){
        if(!t&&"u">typeof HTMLCanvasElement&&e instanceof HTMLCanvasElement&&e.parentElement){
          let{width:t,height:n,top:r,left:l}=e.parentElement.getBoundingClientRect();
          return{width:t,height:n,top:r,left:l}
          }
        return!t&&"u">typeof OffscreenCanvas&&e instanceof OffscreenCanvas?{width:e.width,height:e.height,top:0,left:0}:{width:0,height:0,top:0,left:0,...t}
        }(e,u);
      if(Q.equ(R,P.size,eB)||P.setSize(R.width,R.height,R.top,R.left),x&&P.viewport.dpr!==q(x)&&P.setDpr(x),P.frameloop!==S&&P.setFrameloop(S),P.onPointerMissed||P.set({onPointerMissed:_}),k&&!Q.equ(k,P.performance,eB)&&P.set(e=>({performance:{...e.performance,...k}})),!P.xr){
        let e=(e,t)=>{
          let n=g.getState();
          "never"!==n.frameloop&&eY(e,!0,n,t)
          },t=()=>{
          let t=g.getState();
          t.gl.xr.enabled=t.gl.xr.isPresenting,t.gl.xr.setAnimationLoop(t.gl.xr.isPresenting?e:null),t.gl.xr.isPresenting||eX(t)
          },r={connect(){
          let e=g.getState().gl;
          e.xr.addEventListener("sessionstart",t),e.xr.addEventListener("sessionend",t)
          },disconnect(){
          let e=g.getState().gl;
          e.xr.removeEventListener("sessionstart",t),e.xr.removeEventListener("sessionend",t)
          }};
        "function"==typeof(null==(n=z.xr)?void 0:n.addEventListener)&&r.connect(),P.set({xr:r})
        }
      if(z.shadowMap){
        let e=z.shadowMap.enabled,t=z.shadowMap.type;
        if(z.shadowMap.enabled=!!d,Q.boo(d))
        z.shadowMap.type=b.PCFSoftShadowMap;
        else 
        if(Q.str(d)){
          let e={basic:b.BasicShadowMap,percentage:b.PCFShadowMap,soft:b.PCFSoftShadowMap,variance:b.VSMShadowMap};
          z.shadowMap.type=null!=(a=e[d])?a:b.PCFSoftShadowMap
          }else 
        Q.obj(d)&&Object.assign(z.shadowMap,d);
        (e!==z.shadowMap.enabled||t!==z.shadowMap.type)&&(z.shadowMap.needsUpdate=!0)
        }
      return b.ColorManagement.enabled=!h,C||(z.outputColorSpace=p?b.LinearSRGBColorSpace:b.SRGBColorSpace,z.toneMapping=m?b.NoToneMapping:b.ACESFilmicToneMapping),P.legacy!==h&&P.set(()=>({legacy:h})),P.linear!==p&&P.set(()=>({linear:p})),P.flat!==m&&P.set(()=>({flat:m})),!o||Q.fun(o)||es(o)||Q.equ(o,z,eB)||el(z,o),r=f,C=!0,i(),this
      },render(t){
      return C||w||this.configure(),w.then(()=>{
        eA.updateContainer((0,P.jsx)(eD,{store:g,children:t,onCreated:r,rootElement:e}),S,null,()=>void 0)
        }),g
      },unmount(){
      eG(e)
      }}
    }
  function eD({store:e,children:t,onCreated:n,rootElement:r}){
    return G(()=>{
      let t=e.getState();
      t.set(e=>({internal:{...e.internal,active:!0}})),n&&n(t),e.getState().events.connected||null==t.events.connect||t.events.connect(r)
      },[]),(0,P.jsx)(ec.Provider,{value:e,children:t})
    }
  function eG(e,t){
    let n=eI.get(e),r=null==n?void 0:n.fiber;
    if(r){
      let l=null==n?void 0:n.store.getState();
      l&&(l.internal.active=!1),eA.updateContainer(null,r,null,()=>{
        l&&setTimeout(()=>{
          try{
            null==l.events.disconnect||l.events.disconnect(),null==(n=l.gl)||null==(r=n.renderLists)||null==r.dispose||r.dispose(),null==(a=l.gl)||null==a.forceContextLoss||a.forceContextLoss(),null!=(i=l.gl)&&i.xr&&l.xr.disconnect();
            var n,r,a,i,o=l.scene;
            for(
            let e
             in"Scene"!==o.type&&(null==o.dispose||o.dispose()),o){
              let t=o[e];
              (null==t?void 0:t.type)!=="Scene"&&(null==t||null==t.dispose||t.dispose())
              }
            eI.delete(e),t&&t(e)
            }catch(e){
            }
          },500)
        })
      }
    }
  let eO=new Set,eU=new Set,eH=new Set;
  function eV(e,t){
    if(e.size)
    for(
    let{callback:n}
    of e.values())
    n(t)
    }
  function eq(e,t){
    switch(e){case"before":
    return eV(eO,t);
    case"after":
    return eV(eU,t);
    case"tail":
    return eV(eH,t)
    }
    }
  function eW(e,r,l){
    let a=r.clock.getDelta();
    "never"===r.frameloop&&"number"==typeof e&&(a=e-r.clock.elapsedTime,r.clock.oldTime=r.clock.elapsedTime,r.clock.elapsedTime=e),t=r.internal.subscribers;
    for(
    let e=0
    ;e<t.length;e++)
    (n=t[e]).ref.current(n.store.getState(),a,l);
    return!r.internal.priority&&r.gl.render&&r.gl.render(r.scene,r.camera),r.internal.frames=Math.max(0,r.internal.frames-1),"always"===r.frameloop?1:r.internal.frames
    }
  let eQ=!1,e$=!1;
  function eK(e){
    for(
    let n
     of(l=requestAnimationFrame(eK),eQ=!0,r=0,eq("before",e),e$=!0,eI.values())){
      var t;
      (a=n.store.getState()).internal.active&&("always"===a.frameloop||a.internal.frames>0)&&!(null!=(t=a.gl.xr)&&t.isPresenting)&&(r+=eW(e,a))
      }
    if(e$=!1,eq("after",e),0===r)
    return eq("tail",e),eQ=!1,cancelAnimationFrame(l)
    }
  function eX(e,t=1){
    var n;
    if(!e)
    return eI.forEach(e=>eX(e.store.getState(),t));
    (null==(n=e.gl.xr)||!n.isPresenting)&&e.internal.active&&"never"!==e.frameloop&&(t>1?e.internal.frames=Math.min(60,e.internal.frames+t):e$?e.internal.frames=2:e.internal.frames=1,eQ||(eQ=!0,requestAnimationFrame(eK)))
    }
  function eY(e,t=!0,n,r){
    if(t&&eq("before",e),n)
    eW(e,n,r);
    else 
    for(
    let t
     of eI.values())
    eW(e,t.store.getState());
    t&&eq("after",e)
    }
  let eZ={onClick:["click",!1],onContextMenu:["contextmenu",!1],onDoubleClick:["dblclick",!1],onWheel:["wheel",!0],onPointerDown:["pointerdown",!0],onPointerUp:["pointerup",!0],onPointerLeave:["pointerleave",!0],onPointerMove:["pointermove",!0],onPointerCancel:["pointercancel",!0],onLostPointerCapture:["lostpointercapture",!0]};
  function eJ(e){
    let{handlePointer:t}=function(e){
      function t(e){
        return e.filter(e=>["Move","Over","Enter","Out","Leave"].some(t=>{
          var n;
          return null==(n=e.__r3f)?void 0:n.handlers["onPointer"+t]
          }))
        }
      function n(t){
        let{internal:n}=e.getState();
        for(
        let e
         of n.hovered.values())
        if(!t.length||!t.find(t=>t.object===e.object&&t.index===e.index&&t.instanceId===e.instanceId)){
          let r=e.eventObject.__r3f;
          if(n.hovered.delete(eo(e)),null!=r&&r.eventCount){
            let n=r.handlers,l={...e,intersections:t};
            null==n.onPointerOut||n.onPointerOut(l),null==n.onPointerLeave||n.onPointerLeave(l)
            }
          }
        }
      function r(e,t){
        for(
        let n=0
        ;n<t.length;n++){
          let r=t[n].__r3f;
          null==r||null==r.handlers.onPointerMissed||r.handlers.onPointerMissed(e)
          }
        }
      return{handlePointer:function(l){
        switch(l){case"onPointerLeave":case"onPointerCancel":
        return()=>n([]);
        case"onLostPointerCapture":
        return t=>{
          let{internal:r}=e.getState();
          "pointerId"in t&&r.capturedMap.has(t.pointerId)&&requestAnimationFrame(()=>{
            r.capturedMap.has(t.pointerId)&&(r.capturedMap.delete(t.pointerId),n([]))
            })
          }
        }
        return function(a){
          let{onPointerMissed:i,internal:o}=e.getState();
          o.lastEvent.current=a;
          let u="onPointerMove"===l,s="onClick"===l||"onContextMenu"===l||"onDoubleClick"===l,c=function(t,n){
            let r=e.getState(),l=new Set,a=[],i=n?n(r.internal.interaction):r.internal.interaction;
            for(
            let e=0
            ;e<i.length;e++){
              let t=W(i[e]);
              t&&(t.raycaster.camera=void 0)
              }
            r.previousRoot||null==r.events.compute||r.events.compute(t,r);
            let o=i.flatMap(function(e){
              let n=W(e);
              if(!n||!n.events.enabled||null===n.raycaster.camera)
              return[];
              if(void 0===n.raycaster.camera){
                var r;
                null==n.events.compute||n.events.compute(t,n,null==(r=n.previousRoot)?void 0:r.getState()),void 0===n.raycaster.camera&&(n.raycaster.camera=null)
                }
              return n.raycaster.camera?n.raycaster.intersectObject(e,!0):[]
              }).sort((e,t)=>{
              let n=W(e.object),r=W(t.object);
              return n&&r&&r.events.priority-n.events.priority||e.distance-t.distance
              }).filter(e=>{
              let t=eo(e);
              return!l.has(t)&&(l.add(t),!0)
              });
            for(
            let e
             of(r.events.filter&&(o=r.events.filter(o,r)),o)){
              let t=e.object;
              for(;t;){
                var u;
                null!=(u=t.__r3f)&&u.eventCount&&a.push({...e,eventObject:t}),t=t.parent
                }
              }
            if("pointerId"in t&&r.internal.capturedMap.has(t.pointerId))
            for(
            let e
             of r.internal.capturedMap.get(t.pointerId).values())
            l.has(eo(e.intersection))||a.push(e.intersection);
            return a
            }(a,u?t:void 0),f=s?function(t){
            let{internal:n}=e.getState(),r=t.offsetX-n.initialClick[0],l=t.offsetY-n.initialClick[1];
            return Math.round(Math.sqrt(r*r+l*l))
            }(a):0;
          "onPointerDown"===l&&(o.initialClick=[a.offsetX,a.offsetY],o.initialHits=c.map(e=>e.eventObject)),s&&!c.length&&f<=2&&(r(a,o.interaction),i&&i(a)),u&&n(c),!function(e,t,r,l){
            if(e.length){
              let a={stopped:!1};
              for(
              let i
               of e){
                let o=W(i.object);
                if(o||i.object.traverseAncestors(e=>{
                  let t=W(e);
                  if(t)
                  return o=t,!1
                  }),o){
                  let{raycaster:u,pointer:s,camera:c,internal:f}=o,d=new b.Vector3(s.x,s.y,0).unproject(c),p=e=>{
                    var t,n;
                    return null!=(t=null==(n=f.capturedMap.get(e))?void 0:n.has(i.eventObject))&&t
                    },m=e=>{
                    let n={intersection:i,target:t.target};
                    f.capturedMap.has(e)?f.capturedMap.get(e).set(i.eventObject,n):f.capturedMap.set(e,new Map([[i.eventObject,n]])),t.target.setPointerCapture(e)
                    },h=e=>{
                    let t=f.capturedMap.get(e);
                    t&&eu(f.capturedMap,i.eventObject,t,e)
                    },g={};
                  for(
                  let e
                   in t){
                    let n=t[e];
                    "function"!=typeof n&&(g[e]=n)
                    }
                  let v={...i,...g,pointer:s,intersections:e,stopped:a.stopped,delta:r,unprojectedPoint:d,ray:u.ray,camera:c,stopPropagation(){
                    let r="pointerId"in t&&f.capturedMap.get(t.pointerId);
                    (!r||r.has(i.eventObject))&&(v.stopped=a.stopped=!0,f.hovered.size&&Array.from(f.hovered.values()).find(e=>e.eventObject===i.eventObject)&&n([...e.slice(0,e.indexOf(i)),i]))
                    },target:{hasPointerCapture:p,setPointerCapture:m,releasePointerCapture:h},currentTarget:{hasPointerCapture:p,setPointerCapture:m,releasePointerCapture:h},nativeEvent:t};
                  if(l(v),!0===a.stopped)
                  break
                  }
                }
              }
            }(c,a,f,function(e){
            let t=e.eventObject,n=t.__r3f;
            if(!(null!=n&&n.eventCount))
            return;
            let i=n.handlers;
            if(u){
              if(i.onPointerOver||i.onPointerEnter||i.onPointerOut||i.onPointerLeave){
                let t=eo(e),n=o.hovered.get(t);
                n?n.stopped&&e.stopPropagation():(o.hovered.set(t,e),null==i.onPointerOver||i.onPointerOver(e),null==i.onPointerEnter||i.onPointerEnter(e))
                }
              null==i.onPointerMove||i.onPointerMove(e)
              }else{
              let n=i[l];
              n?(!s||o.initialHits.includes(t))&&(r(a,o.interaction.filter(e=>!o.initialHits.includes(e))),n(e)):s&&o.initialHits.includes(t)&&r(a,o.interaction.filter(e=>!o.initialHits.includes(e)))
              }
            })
          }
        }}
      }(e);
    return{priority:1,enabled:!0,compute(e,t,n){
      t.pointer.set(e.offsetX/t.size.width*2-1,-(2*(e.offsetY/t.size.height))+1),t.raycaster.setFromCamera(t.pointer,t.camera)
      },connected:void 0,handlers:Object.keys(eZ).reduce((e,n)=>({...e,[n]:t(n)}),{}),update:()=>{
      var t;
      let{events:n,internal:r}=e.getState();
      null!=(t=r.lastEvent)&&t.current&&n.handlers&&n.handlers.onPointerMove(r.lastEvent.current)
      },connect:t=>{
      let{set:n,events:r}=e.getState();
      if(null==r.disconnect||r.disconnect(),n(e=>({events:{...e.events,connected:t}})),r.handlers)
      for(
      let e
       in r.handlers){
        let n=r.handlers[e],[l,a]=eZ[e];
        t.addEventListener(l,n,{passive:a})
        }
      },disconnect:()=>{
      let{set:t,events:n}=e.getState();
      if(n.connected){
        if(n.handlers)
        for(
        let e
         in n.handlers){
          let t=n.handlers[e],[r]=eZ[e];
          n.connected.removeEventListener(r,t)
          }
        t(e=>({events:{...e.events,connected:void 0}}))
        }
      }}
    }
  e.s(["B",0,H,"C",0,function(e=e=>e,t){
    return ef()(e,t)
    },"D",0,ed,"E",0,V,"a",0,O,"b",0,G,"c",0,ej,"d",0,eG,"e",0,ex,"f",0,eJ,"i",0,j,"u",0,U],1950),e.s(["ACESFilmicToneMapping",()=>b.ACESFilmicToneMapping,"AddEquation",()=>b.AddEquation,"AddOperation",()=>b.AddOperation,"AdditiveAnimationBlendMode",()=>b.AdditiveAnimationBlendMode,"AdditiveBlending",()=>b.AdditiveBlending,"AgXToneMapping",()=>b.AgXToneMapping,"AlphaFormat",()=>b.AlphaFormat,"AlwaysCompare",()=>b.AlwaysCompare,"AlwaysDepth",()=>b.AlwaysDepth,"AlwaysStencilFunc",()=>b.AlwaysStencilFunc,"AmbientLight",()=>b.AmbientLight,"AnimationAction",()=>b.AnimationAction,"AnimationClip",()=>b.AnimationClip,"AnimationLoader",()=>b.AnimationLoader,"AnimationMixer",()=>b.AnimationMixer,"AnimationObjectGroup",()=>b.AnimationObjectGroup,"AnimationUtils",()=>b.AnimationUtils,"ArcCurve",()=>b.ArcCurve,"ArrayCamera",()=>b.ArrayCamera,"ArrowHelper",()=>b.ArrowHelper,"AttachedBindMode",()=>b.AttachedBindMode,"Audio",()=>b.Audio,"AudioAnalyser",()=>b.AudioAnalyser,"AudioContext",()=>b.AudioContext,"AudioListener",()=>b.AudioListener,"AudioLoader",()=>b.AudioLoader,"AxesHelper",()=>b.AxesHelper,"BackSide",()=>b.BackSide,"BasicDepthPacking",()=>b.BasicDepthPacking,"BasicShadowMap",()=>b.BasicShadowMap,"BatchedMesh",()=>b.BatchedMesh,"BezierInterpolant",()=>b.BezierInterpolant,"Bone",()=>b.Bone,"BooleanKeyframeTrack",()=>b.BooleanKeyframeTrack,"Box2",()=>b.Box2,"Box3",()=>b.Box3,"Box3Helper",()=>b.Box3Helper,"BoxGeometry",()=>b.BoxGeometry,"BoxHelper",()=>b.BoxHelper,"BufferAttribute",()=>b.BufferAttribute,"BufferGeometry",()=>b.BufferGeometry,"BufferGeometryLoader",()=>b.BufferGeometryLoader,"ByteType",()=>b.ByteType,"Cache",()=>b.Cache,"Camera",()=>b.Camera,"CameraHelper",()=>b.CameraHelper,"CanvasTexture",()=>b.CanvasTexture,"CapsuleGeometry",()=>b.CapsuleGeometry,"CatmullRomCurve3",()=>b.CatmullRomCurve3,"CineonToneMapping",()=>b.CineonToneMapping,"CircleGeometry",()=>b.CircleGeometry,"ClampToEdgeWrapping",()=>b.ClampToEdgeWrapping,"Clock",()=>b.Clock,"Color",()=>b.Color,"ColorKeyframeTrack",()=>b.ColorKeyframeTrack,"ColorManagement",()=>b.ColorManagement,"Compatibility",()=>b.Compatibility,"CompressedArrayTexture",()=>b.CompressedArrayTexture,"CompressedCubeTexture",()=>b.CompressedCubeTexture,"CompressedTexture",()=>b.CompressedTexture,"CompressedTextureLoader",()=>b.CompressedTextureLoader,"ConeGeometry",()=>b.ConeGeometry,"ConstantAlphaFactor",()=>b.ConstantAlphaFactor,"ConstantColorFactor",()=>b.ConstantColorFactor,"Controls",()=>b.Controls,"CubeCamera",()=>b.CubeCamera,"CubeDepthTexture",()=>b.CubeDepthTexture,"CubeReflectionMapping",()=>b.CubeReflectionMapping,"CubeRefractionMapping",()=>b.CubeRefractionMapping,"CubeTexture",()=>b.CubeTexture,"CubeTextureLoader",()=>b.CubeTextureLoader,"CubeUVReflectionMapping",()=>b.CubeUVReflectionMapping,"CubicBezierCurve",()=>b.CubicBezierCurve,"CubicBezierCurve3",()=>b.CubicBezierCurve3,"CubicInterpolant",()=>b.CubicInterpolant,"CullFaceBack",()=>b.CullFaceBack,"CullFaceFront",()=>b.CullFaceFront,"CullFaceFrontBack",()=>b.CullFaceFrontBack,"CullFaceNone",()=>b.CullFaceNone,"Curve",()=>b.Curve,"CurvePath",()=>b.CurvePath,"CustomBlending",()=>b.CustomBlending,"CustomToneMapping",()=>b.CustomToneMapping,"CylinderGeometry",()=>b.CylinderGeometry,"Cylindrical",()=>b.Cylindrical,"Data3DTexture",()=>b.Data3DTexture,"DataArrayTexture",()=>b.DataArrayTexture,"DataTexture",()=>b.DataTexture,"DataTextureLoader",()=>b.DataTextureLoader,"DataUtils",()=>b.DataUtils,"DecrementStencilOp",()=>b.DecrementStencilOp,"DecrementWrapStencilOp",()=>b.DecrementWrapStencilOp,"DefaultLoadingManager",()=>b.DefaultLoadingManager,"DepthFormat",()=>b.DepthFormat,"DepthStencilFormat",()=>b.DepthStencilFormat,"DepthTexture",()=>b.DepthTexture,"DetachedBindMode",()=>b.DetachedBindMode,"DirectionalLight",()=>b.DirectionalLight,"DirectionalLightHelper",()=>b.DirectionalLightHelper,"DiscreteInterpolant",()=>b.DiscreteInterpolant,"DodecahedronGeometry",()=>b.DodecahedronGeometry,"DoubleSide",()=>b.DoubleSide,"DstAlphaFactor",()=>b.DstAlphaFactor,"DstColorFactor",()=>b.DstColorFactor,"DynamicCopyUsage",()=>b.DynamicCopyUsage,"DynamicDrawUsage",()=>b.DynamicDrawUsage,"DynamicReadUsage",()=>b.DynamicReadUsage,"EdgesGeometry",()=>b.EdgesGeometry,"EllipseCurve",()=>b.EllipseCurve,"EqualCompare",()=>b.EqualCompare,"EqualDepth",()=>b.EqualDepth,"EqualStencilFunc",()=>b.EqualStencilFunc,"EquirectangularReflectionMapping",()=>b.EquirectangularReflectionMapping,"EquirectangularRefractionMapping",()=>b.EquirectangularRefractionMapping,"Euler",()=>b.Euler,"EventDispatcher",()=>b.EventDispatcher,"ExternalTexture",()=>b.ExternalTexture,"ExtrudeGeometry",()=>b.ExtrudeGeometry,"FileLoader",()=>b.FileLoader,"Float16BufferAttribute",()=>b.Float16BufferAttribute,"Float32BufferAttribute",()=>b.Float32BufferAttribute,"FloatType",()=>b.FloatType,"Fog",()=>b.Fog,"FogExp2",()=>b.FogExp2,"FramebufferTexture",()=>b.FramebufferTexture,"FrontSide",()=>b.FrontSide,"Frustum",()=>b.Frustum,"FrustumArray",()=>b.FrustumArray,"GLBufferAttribute",()=>b.GLBufferAttribute,"GLSL1",()=>b.GLSL1,"GLSL3",()=>b.GLSL3,"GreaterCompare",()=>b.GreaterCompare,"GreaterDepth",()=>b.GreaterDepth,"GreaterEqualCompare",()=>b.GreaterEqualCompare,"GreaterEqualDepth",()=>b.GreaterEqualDepth,"GreaterEqualStencilFunc",()=>b.GreaterEqualStencilFunc,"GreaterStencilFunc",()=>b.GreaterStencilFunc,"GridHelper",()=>b.GridHelper,"Group",()=>b.Group,"HTMLTexture",()=>b.HTMLTexture,"HalfFloatType",()=>b.HalfFloatType,"HemisphereLight",()=>b.HemisphereLight,"HemisphereLightHelper",()=>b.HemisphereLightHelper,"IcosahedronGeometry",()=>b.IcosahedronGeometry,"ImageBitmapLoader",()=>b.ImageBitmapLoader,"ImageLoader",()=>b.ImageLoader,"ImageUtils",()=>b.ImageUtils,"IncrementStencilOp",()=>b.IncrementStencilOp,"IncrementWrapStencilOp",()=>b.IncrementWrapStencilOp,"InstancedBufferAttribute",()=>b.InstancedBufferAttribute,"InstancedBufferGeometry",()=>b.InstancedBufferGeometry,"InstancedInterleavedBuffer",()=>b.InstancedInterleavedBuffer,"InstancedMesh",()=>b.InstancedMesh,"Int16BufferAttribute",()=>b.Int16BufferAttribute,"Int32BufferAttribute",()=>b.Int32BufferAttribute,"Int8BufferAttribute",()=>b.Int8BufferAttribute,"IntType",()=>b.IntType,"InterleavedBuffer",()=>b.InterleavedBuffer,"InterleavedBufferAttribute",()=>b.InterleavedBufferAttribute,"Interpolant",()=>b.Interpolant,"InterpolateBezier",()=>b.InterpolateBezier,"InterpolateDiscrete",()=>b.InterpolateDiscrete,"InterpolateLinear",()=>b.InterpolateLinear,"InterpolateSmooth",()=>b.InterpolateSmooth,"InterpolationSamplingMode",()=>b.InterpolationSamplingMode,"InterpolationSamplingType",()=>b.InterpolationSamplingType,"InvertStencilOp",()=>b.InvertStencilOp,"KeepStencilOp",()=>b.KeepStencilOp,"KeyframeTrack",()=>b.KeyframeTrack,"LOD",()=>b.LOD,"LatheGeometry",()=>b.LatheGeometry,"Layers",()=>b.Layers,"LessCompare",()=>b.LessCompare,"LessDepth",()=>b.LessDepth,"LessEqualCompare",()=>b.LessEqualCompare,"LessEqualDepth",()=>b.LessEqualDepth,"LessEqualStencilFunc",()=>b.LessEqualStencilFunc,"LessStencilFunc",()=>b.LessStencilFunc,"Light",()=>b.Light,"LightProbe",()=>b.LightProbe,"Line",()=>b.Line,"Line3",()=>b.Line3,"LineBasicMaterial",()=>b.LineBasicMaterial,"LineCurve",()=>b.LineCurve,"LineCurve3",()=>b.LineCurve3,"LineDashedMaterial",()=>b.LineDashedMaterial,"LineLoop",()=>b.LineLoop,"LineSegments",()=>b.LineSegments,"LinearFilter",()=>b.LinearFilter,"LinearInterpolant",()=>b.LinearInterpolant,"LinearMipMapLinearFilter",()=>b.LinearMipMapLinearFilter,"LinearMipMapNearestFilter",()=>b.LinearMipMapNearestFilter,"LinearMipmapLinearFilter",()=>b.LinearMipmapLinearFilter,"LinearMipmapNearestFilter",()=>b.LinearMipmapNearestFilter,"LinearSRGBColorSpace",()=>b.LinearSRGBColorSpace,"LinearToneMapping",()=>b.LinearToneMapping,"LinearTransfer",()=>b.LinearTransfer,"Loader",()=>b.Loader,"LoaderUtils",()=>b.LoaderUtils,"LoadingManager",()=>b.LoadingManager,"LoopOnce",()=>b.LoopOnce,"LoopPingPong",()=>b.LoopPingPong,"LoopRepeat",()=>b.LoopRepeat,"MOUSE",()=>b.MOUSE,"Material",()=>b.Material,"MaterialBlending",()=>b.MaterialBlending,"MaterialLoader",()=>b.MaterialLoader,"MathUtils",()=>b.MathUtils,"Matrix2",()=>b.Matrix2,"Matrix3",()=>b.Matrix3,"Matrix4",()=>b.Matrix4,"MaxEquation",()=>b.MaxEquation,"Mesh",()=>b.Mesh,"MeshBasicMaterial",()=>b.MeshBasicMaterial,"MeshDepthMaterial",()=>b.MeshDepthMaterial,"MeshDistanceMaterial",()=>b.MeshDistanceMaterial,"MeshLambertMaterial",()=>b.MeshLambertMaterial,"MeshMatcapMaterial",()=>b.MeshMatcapMaterial,"MeshNormalMaterial",()=>b.MeshNormalMaterial,"MeshPhongMaterial",()=>b.MeshPhongMaterial,"MeshPhysicalMaterial",()=>b.MeshPhysicalMaterial,"MeshStandardMaterial",()=>b.MeshStandardMaterial,"MeshToonMaterial",()=>b.MeshToonMaterial,"MinEquation",()=>b.MinEquation,"MirroredRepeatWrapping",()=>b.MirroredRepeatWrapping,"MixOperation",()=>b.MixOperation,"MultiplyBlending",()=>b.MultiplyBlending,"MultiplyOperation",()=>b.MultiplyOperation,"NearestFilter",()=>b.NearestFilter,"NearestMipMapLinearFilter",()=>b.NearestMipMapLinearFilter,"NearestMipMapNearestFilter",()=>b.NearestMipMapNearestFilter,"NearestMipmapLinearFilter",()=>b.NearestMipmapLinearFilter,"NearestMipmapNearestFilter",()=>b.NearestMipmapNearestFilter,"NeutralToneMapping",()=>b.NeutralToneMapping,"NeverCompare",()=>b.NeverCompare,"NeverDepth",()=>b.NeverDepth,"NeverStencilFunc",()=>b.NeverStencilFunc,"NoBlending",()=>b.NoBlending,"NoColorSpace",()=>b.NoColorSpace,"NoNormalPacking",()=>b.NoNormalPacking,"NoToneMapping",()=>b.NoToneMapping,"NormalAnimationBlendMode",()=>b.NormalAnimationBlendMode,"NormalBlending",()=>b.NormalBlending,"NormalGAPacking",()=>b.NormalGAPacking,"NormalRGPacking",()=>b.NormalRGPacking,"NotEqualCompare",()=>b.NotEqualCompare,"NotEqualDepth",()=>b.NotEqualDepth,"NotEqualStencilFunc",()=>b.NotEqualStencilFunc,"NumberKeyframeTrack",()=>b.NumberKeyframeTrack,"Object3D",()=>b.Object3D,"ObjectLoader",()=>b.ObjectLoader,"ObjectSpaceNormalMap",()=>b.ObjectSpaceNormalMap,"OctahedronGeometry",()=>b.OctahedronGeometry,"OneFactor",()=>b.OneFactor,"OneMinusConstantAlphaFactor",()=>b.OneMinusConstantAlphaFactor,"OneMinusConstantColorFactor",()=>b.OneMinusConstantColorFactor,"OneMinusDstAlphaFactor",()=>b.OneMinusDstAlphaFactor,"OneMinusDstColorFactor",()=>b.OneMinusDstColorFactor,"OneMinusSrcAlphaFactor",()=>b.OneMinusSrcAlphaFactor,"OneMinusSrcColorFactor",()=>b.OneMinusSrcColorFactor,"OrthographicCamera",()=>b.OrthographicCamera,"PCFShadowMap",()=>b.PCFShadowMap,"PCFSoftShadowMap",()=>b.PCFSoftShadowMap,"PMREMGenerator",()=>y.PMREMGenerator,"Path",()=>b.Path,"PerspectiveCamera",()=>b.PerspectiveCamera,"Plane",()=>b.Plane,"PlaneGeometry",()=>b.PlaneGeometry,"PlaneHelper",()=>b.PlaneHelper,"PointLight",()=>b.PointLight,"PointLightHelper",()=>b.PointLightHelper,"Points",()=>b.Points,"PointsMaterial",()=>b.PointsMaterial,"PolarGridHelper",()=>b.PolarGridHelper,"PolyhedronGeometry",()=>b.PolyhedronGeometry,"PositionalAudio",()=>b.PositionalAudio,"PropertyBinding",()=>b.PropertyBinding,"PropertyMixer",()=>b.PropertyMixer,"QuadraticBezierCurve",()=>b.QuadraticBezierCurve,"QuadraticBezierCurve3",()=>b.QuadraticBezierCurve3,"Quaternion",()=>b.Quaternion,"QuaternionKeyframeTrack",()=>b.QuaternionKeyframeTrack,"QuaternionLinearInterpolant",()=>b.QuaternionLinearInterpolant,"R11_EAC_Format",()=>b.R11_EAC_Format,"RED_GREEN_RGTC2_Format",()=>b.RED_GREEN_RGTC2_Format,"RED_RGTC1_Format",()=>b.RED_RGTC1_Format,"REVISION",()=>b.REVISION,"RG11_EAC_Format",()=>b.RG11_EAC_Format,"RGBADepthPacking",()=>b.RGBADepthPacking,"RGBAFormat",()=>b.RGBAFormat,"RGBAIntegerFormat",()=>b.RGBAIntegerFormat,"RGBA_ASTC_10x10_Format",()=>b.RGBA_ASTC_10x10_Format,"RGBA_ASTC_10x5_Format",()=>b.RGBA_ASTC_10x5_Format,"RGBA_ASTC_10x6_Format",()=>b.RGBA_ASTC_10x6_Format,"RGBA_ASTC_10x8_Format",()=>b.RGBA_ASTC_10x8_Format,"RGBA_ASTC_12x10_Format",()=>b.RGBA_ASTC_12x10_Format,"RGBA_ASTC_12x12_Format",()=>b.RGBA_ASTC_12x12_Format,"RGBA_ASTC_4x4_Format",()=>b.RGBA_ASTC_4x4_Format,"RGBA_ASTC_5x4_Format",()=>b.RGBA_ASTC_5x4_Format,"RGBA_ASTC_5x5_Format",()=>b.RGBA_ASTC_5x5_Format,"RGBA_ASTC_6x5_Format",()=>b.RGBA_ASTC_6x5_Format,"RGBA_ASTC_6x6_Format",()=>b.RGBA_ASTC_6x6_Format,"RGBA_ASTC_8x5_Format",()=>b.RGBA_ASTC_8x5_Format,"RGBA_ASTC_8x6_Format",()=>b.RGBA_ASTC_8x6_Format,"RGBA_ASTC_8x8_Format",()=>b.RGBA_ASTC_8x8_Format,"RGBA_BPTC_Format",()=>b.RGBA_BPTC_Format,"RGBA_ETC2_EAC_Format",()=>b.RGBA_ETC2_EAC_Format,"RGBA_PVRTC_2BPPV1_Format",()=>b.RGBA_PVRTC_2BPPV1_Format,"RGBA_PVRTC_4BPPV1_Format",()=>b.RGBA_PVRTC_4BPPV1_Format,"RGBA_S3TC_DXT1_Format",()=>b.RGBA_S3TC_DXT1_Format,"RGBA_S3TC_DXT3_Format",()=>b.RGBA_S3TC_DXT3_Format,"RGBA_S3TC_DXT5_Format",()=>b.RGBA_S3TC_DXT5_Format,"RGBDepthPacking",()=>b.RGBDepthPacking,"RGBFormat",()=>b.RGBFormat,"RGBIntegerFormat",()=>b.RGBIntegerFormat,"RGB_BPTC_SIGNED_Format",()=>b.RGB_BPTC_SIGNED_Format,"RGB_BPTC_UNSIGNED_Format",()=>b.RGB_BPTC_UNSIGNED_Format,"RGB_ETC1_Format",()=>b.RGB_ETC1_Format,"RGB_ETC2_Format",()=>b.RGB_ETC2_Format,"RGB_PVRTC_2BPPV1_Format",()=>b.RGB_PVRTC_2BPPV1_Format,"RGB_PVRTC_4BPPV1_Format",()=>b.RGB_PVRTC_4BPPV1_Format,"RGB_S3TC_DXT1_Format",()=>b.RGB_S3TC_DXT1_Format,"RGDepthPacking",()=>b.RGDepthPacking,"RGFormat",()=>b.RGFormat,"RGIntegerFormat",()=>b.RGIntegerFormat,"RawShaderMaterial",()=>b.RawShaderMaterial,"Ray",()=>b.Ray,"Raycaster",()=>b.Raycaster,"RectAreaLight",()=>b.RectAreaLight,"RedFormat",()=>b.RedFormat,"RedIntegerFormat",()=>b.RedIntegerFormat,"ReinhardToneMapping",()=>b.ReinhardToneMapping,"RenderTarget",()=>b.RenderTarget,"RenderTarget3D",()=>b.RenderTarget3D,"RepeatWrapping",()=>b.RepeatWrapping,"ReplaceStencilOp",()=>b.ReplaceStencilOp,"ReverseSubtractEquation",()=>b.ReverseSubtractEquation,"RingGeometry",()=>b.RingGeometry,"SIGNED_R11_EAC_Format",()=>b.SIGNED_R11_EAC_Format,"SIGNED_RED_GREEN_RGTC2_Format",()=>b.SIGNED_RED_GREEN_RGTC2_Format,"SIGNED_RED_RGTC1_Format",()=>b.SIGNED_RED_RGTC1_Format,"SIGNED_RG11_EAC_Format",()=>b.SIGNED_RG11_EAC_Format,"SRGBColorSpace",()=>b.SRGBColorSpace,"SRGBTransfer",()=>b.SRGBTransfer,"Scene",()=>b.Scene,"ShaderChunk",()=>y.ShaderChunk,"ShaderLib",()=>y.ShaderLib,"ShaderMaterial",()=>b.ShaderMaterial,"ShadowMaterial",()=>b.ShadowMaterial,"Shape",()=>b.Shape,"ShapeGeometry",()=>b.ShapeGeometry,"ShapePath",()=>b.ShapePath,"ShapeUtils",()=>b.ShapeUtils,"ShortType",()=>b.ShortType,"Skeleton",()=>b.Skeleton,"SkeletonHelper",()=>b.SkeletonHelper,"SkinnedMesh",()=>b.SkinnedMesh,"Source",()=>b.Source,"Sphere",()=>b.Sphere,"SphereGeometry",()=>b.SphereGeometry,"Spherical",()=>b.Spherical,"SphericalHarmonics3",()=>b.SphericalHarmonics3,"SplineCurve",()=>b.SplineCurve,"SpotLight",()=>b.SpotLight,"SpotLightHelper",()=>b.SpotLightHelper,"Sprite",()=>b.Sprite,"SpriteMaterial",()=>b.SpriteMaterial,"SrcAlphaFactor",()=>b.SrcAlphaFactor,"SrcAlphaSaturateFactor",()=>b.SrcAlphaSaturateFactor,"SrcColorFactor",()=>b.SrcColorFactor,"StaticCopyUsage",()=>b.StaticCopyUsage,"StaticDrawUsage",()=>b.StaticDrawUsage,"StaticReadUsage",()=>b.StaticReadUsage,"StereoCamera",()=>b.StereoCamera,"StreamCopyUsage",()=>b.StreamCopyUsage,"StreamDrawUsage",()=>b.StreamDrawUsage,"StreamReadUsage",()=>b.StreamReadUsage,"StringKeyframeTrack",()=>b.StringKeyframeTrack,"SubtractEquation",()=>b.SubtractEquation,"SubtractiveBlending",()=>b.SubtractiveBlending,"TOUCH",()=>b.TOUCH,"TangentSpaceNormalMap",()=>b.TangentSpaceNormalMap,"TetrahedronGeometry",()=>b.TetrahedronGeometry,"Texture",()=>b.Texture,"TextureLoader",()=>b.TextureLoader,"TextureUtils",()=>b.TextureUtils,"Timer",()=>b.Timer,"TimestampQuery",()=>b.TimestampQuery,"TorusGeometry",()=>b.TorusGeometry,"TorusKnotGeometry",()=>b.TorusKnotGeometry,"Triangle",()=>b.Triangle,"TriangleFanDrawMode",()=>b.TriangleFanDrawMode,"TriangleStripDrawMode",()=>b.TriangleStripDrawMode,"TrianglesDrawMode",()=>b.TrianglesDrawMode,"TubeGeometry",()=>b.TubeGeometry,"UVMapping",()=>b.UVMapping,"Uint16BufferAttribute",()=>b.Uint16BufferAttribute,"Uint32BufferAttribute",()=>b.Uint32BufferAttribute,"Uint8BufferAttribute",()=>b.Uint8BufferAttribute,"Uint8ClampedBufferAttribute",()=>b.Uint8ClampedBufferAttribute,"Uniform",()=>b.Uniform,"UniformsGroup",()=>b.UniformsGroup,"UniformsLib",()=>y.UniformsLib,"UniformsUtils",()=>b.UniformsUtils,"UnsignedByteType",()=>b.UnsignedByteType,"UnsignedInt101111Type",()=>b.UnsignedInt101111Type,"UnsignedInt248Type",()=>b.UnsignedInt248Type,"UnsignedInt5999Type",()=>b.UnsignedInt5999Type,"UnsignedIntType",()=>b.UnsignedIntType,"UnsignedShort4444Type",()=>b.UnsignedShort4444Type,"UnsignedShort5551Type",()=>b.UnsignedShort5551Type,"UnsignedShortType",()=>b.UnsignedShortType,"VSMShadowMap",()=>b.VSMShadowMap,"Vector2",()=>b.Vector2,"Vector3",()=>b.Vector3,"Vector4",()=>b.Vector4,"VectorKeyframeTrack",()=>b.VectorKeyframeTrack,"VideoFrameTexture",()=>b.VideoFrameTexture,"VideoTexture",()=>b.VideoTexture,"WebGL3DRenderTarget",()=>b.WebGL3DRenderTarget,"WebGLArrayRenderTarget",()=>b.WebGLArrayRenderTarget,"WebGLCoordinateSystem",()=>b.WebGLCoordinateSystem,"WebGLCubeRenderTarget",()=>y.WebGLCubeRenderTarget,"WebGLRenderTarget",()=>b.WebGLRenderTarget,"WebGLRenderer",()=>y.WebGLRenderer,"WebGLUtils",()=>y.WebGLUtils,"WebGPUCoordinateSystem",()=>b.WebGPUCoordinateSystem,"WebXRController",()=>b.WebXRController,"WireframeGeometry",()=>b.WireframeGeometry,"WrapAroundEnding",()=>b.WrapAroundEnding,"ZeroCurvatureEnding",()=>b.ZeroCurvatureEnding,"ZeroFactor",()=>b.ZeroFactor,"ZeroSlopeEnding",()=>b.ZeroSlopeEnding,"ZeroStencilOp",()=>b.ZeroStencilOp,"createCanvasElement",()=>b.createCanvasElement,"error",()=>b.error,"getConsoleFunction",()=>b.getConsoleFunction,"log",()=>b.log,"setConsoleFunction",()=>b.setConsoleFunction,"warn",()=>b.warn,"warnOnce",()=>b.warnOnce],32009);
  var e0=e.i(32009);
  function e1(e,t){
    let n;
    return(...r)=>{
      window.clearTimeout(n),n=window.setTimeout(()=>e(...r),t)
      }
    }
  let e2=["x","y","top","bottom","left","right","width","height"];
  function e3({ref:e,children:t,fallback:n,resize:r,style:l,gl:a,events:i=eJ,eventSource:o,eventPrefix:u,shadows:s,linear:c,flat:f,legacy:d,orthographic:p,frameloop:m,dpr:h,performance:g,raycaster:b,camera:y,scene:S,onPointerMissed:C,onCreated:w,...x}){
    v.useMemo(()=>ex(e0),[]);
    let k=U(),[T,E]=function({debounce:e,scroll:t,polyfill:n,offsetSize:r}={debounce:0,scroll:!1,offsetSize:!1}){
      var l,a,i;
      let o=n||("u"<typeof window?class{
        }:window.ResizeObserver);
      if(!o)
      throw Error("This browser does not support ResizeObserver out of the box. See: https://github.com/react-spring/react-use-measure/#resize-observer-polyfills");
      let[u,s]=(0,v.useState)({left:0,top:0,width:0,height:0,bottom:0,right:0,x:0,y:0}),c=(0,v.useRef)({element:null,scrollContainers:null,resizeObserver:null,lastBounds:u,orientationHandler:null}),f=e?"number"==typeof e?e:e.scroll:null,d=e?"number"==typeof e?e:e.resize:null,p=(0,v.useRef)(!1);
      (0,v.useEffect)(()=>(p.current=!0,()=>void(p.current=!1)));
      let[m,h,g]=(0,v.useMemo)(()=>{
        let e=()=>{
          let e,t;
          if(!c.current.element)
          return;
          let{left:n,top:l,width:a,height:i,bottom:o,right:u,x:f,y:d}=c.current.element.getBoundingClientRect(),m={left:n,top:l,width:a,height:i,bottom:o,right:u,x:f,y:d};
          c.current.element instanceof HTMLElement&&r&&(m.height=c.current.element.offsetHeight,m.width=c.current.element.offsetWidth),Object.freeze(m),p.current&&(e=c.current.lastBounds,t=m,!e2.every(n=>e[n]===t[n]))&&s(c.current.lastBounds=m)
          };
        return[e,d?e1(e,d):e,f?e1(e,f):e]
        },[s,r,f,d]);
      function b(){
        c.current.scrollContainers&&(c.current.scrollContainers.forEach(e=>e.removeEventListener("scroll",g,!0)),c.current.scrollContainers=null),c.current.resizeObserver&&(c.current.resizeObserver.disconnect(),c.current.resizeObserver=null),c.current.orientationHandler&&("orientation"in screen&&"removeEventListener"in screen.orientation?screen.orientation.removeEventListener("change",c.current.orientationHandler):"onorientationchange"in window&&window.removeEventListener("orientationchange",c.current.orientationHandler))
        }
      function y(){
        c.current.element&&(c.current.resizeObserver=new o(g),c.current.resizeObserver.observe(c.current.element),t&&c.current.scrollContainers&&c.current.scrollContainers.forEach(e=>e.addEventListener("scroll",g,{capture:!0,passive:!0})),c.current.orientationHandler=()=>{
          g()
          },"orientation"in screen&&"addEventListener"in screen.orientation?screen.orientation.addEventListener("change",c.current.orientationHandler):"onorientationchange"in window&&window.addEventListener("orientationchange",c.current.orientationHandler))
        }
      return l=g,a=!!t,(0,v.useEffect)(()=>{
        if(a)
        return window.addEventListener("scroll",l,{capture:!0,passive:!0}),()=>void window.removeEventListener("scroll",l,!0)
        },[l,a]),i=h,(0,v.useEffect)(()=>(window.addEventListener("resize",i),()=>void window.removeEventListener("resize",i)),[i]),(0,v.useEffect)(()=>{
        b(),y()
        },[t,g,h]),(0,v.useEffect)(()=>b,[]),[e=>{
        e&&e!==c.current.element&&(b(),c.current.element=e,c.current.scrollContainers=function e(t){
          let n=[];
          if(!t||t===document.body)
          return n;
          let{overflow:r,overflowX:l,overflowY:a}=window.getComputedStyle(t);
          return[r,l,a].some(e=>"auto"===e||"scroll"===e)&&n.push(t),[...n,...e(t.parentElement)]
          }(e),y())
        },u,m]
      }({scroll:!0,debounce:{scroll:50,resize:0},...r}),_=v.useRef(null),z=v.useRef(null);
    v.useImperativeHandle(e,()=>_.current);
    let M=O(C),[F,L]=v.useState(!1),[R,N]=v.useState(!1);
    if(F)
    throw F;
    if(R)
    throw R;
    let A=v.useRef(null);
    G(()=>{
      let e=_.current;
      E.width>0&&E.height>0&&e&&(A.current||(A.current=ej(e)),async function(){
        await A.current.configure({gl:a,scene:S,events:i,shadows:s,linear:c,flat:f,legacy:d,orthographic:p,frameloop:m,dpr:h,performance:g,raycaster:b,camera:y,size:E,onPointerMissed:(...e)=>null==M.current?void 0:M.current(...e),onCreated:e=>{
          null==e.events.connect||e.events.connect(o?j(o)?o.current:o:z.current),u&&e.setEvents({compute:(e,t)=>{
            let n=e[u+"X"],r=e[u+"Y"];
            t.pointer.set(n/t.size.width*2-1,-(2*(r/t.size.height))+1),t.raycaster.setFromCamera(t.pointer,t.camera)
            }}),null==w||w(e)
          }}),A.current.render((0,P.jsx)(k,{children:(0,P.jsx)(V,{set:N,children:(0,P.jsx)(v.Suspense,{fallback:(0,P.jsx)(H,{set:L}),children:null!=t?t:null})})}))
        }())
      }),v.useEffect(()=>{
      let e=_.current;
      if(e)
      return()=>eG(e)
      },[]);
    let I=o?"none":"auto";
    return(0,P.jsx)("div",{ref:z,style:{position:"relative",width:"100%",height:"100%",overflow:"hidden",pointerEvents:I,...l},...x,children:(0,P.jsx)("div",{ref:T,style:{width:"100%",height:"100%"},children:(0,P.jsx)("canvas",{ref:_,style:{display:"block"},children:n})})})
    }
  e.s(["Canvas",0,function(e){
    return(0,P.jsx)(R,{children:(0,P.jsx)(e3,{...e})})
    }],75056),e.s(["useFrame",0,ed],25234)
  }]);
