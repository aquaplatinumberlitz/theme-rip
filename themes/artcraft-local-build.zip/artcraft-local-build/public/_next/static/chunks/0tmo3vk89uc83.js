(globalThis.TURBOPACK||(globalThis.TURBOPACK=[])).push(["object"==typeof document?document.currentScript:void 0,51778,e=>{
  "use strict";
  var t=e.i(71645),r=e.i(89970),n=e.i(83495),l=e.i(91672);
  r.default.registerPlugin(n.ScrollTrigger);
  let a={autoAlpha:0,y:28,filter:"blur(8px)"},o={autoAlpha:1,y:0,filter:"blur(0px)",duration:.9,ease:"power3.out",overwrite:!0,clearProps:"all"};
  e.s(["default",0,function(){
    return(0,t.useEffect)(()=>{
      let e=r.default.matchMedia();
      return e.add("(prefers-reduced-motion: no-preference)",()=>{
        r.default.utils.toArray("[data-choreo]").forEach(e=>{
          let t=e.querySelector("[data-draw-rule]"),l=e.querySelectorAll("[data-draw-tick]"),i=e.querySelector("[data-draw-eyebrow]");
          t&&r.default.set(t,{scaleX:0}),l.length&&r.default.set(l,{scale:0,opacity:0}),i&&r.default.set(i,a),n.ScrollTrigger.create({trigger:e,start:"top 88%",once:!0,onEnter:()=>{
            let e=r.default.timeline();
            t&&e.to(t,{scaleX:1,duration:.7,ease:"power2.out",clearProps:"all"},0),i&&e.to(i,{...o},.15),l.length&&e.to(l,{scale:1,opacity:1,duration:.35,ease:"power3.out",stagger:.06,clearProps:"all"},.35)
            }})
          }),r.default.utils.toArray("[data-reveal]:not([data-reveal-group] [data-reveal])").forEach(e=>{
          r.default.set(e,a),n.ScrollTrigger.create({trigger:e,start:"top 85%",once:!0,onEnter:()=>r.default.to(e,o)})
          });
        let e=[];
        return r.default.utils.toArray("[data-reveal-group]").forEach(t=>{
          let i=Array.from(t.querySelectorAll("[data-reveal]"));
          if(!i.length)
          return;
          if(r.default.set(i,a),t.closest("#hero")){
            let t=null,n=()=>{
              t&&r.default.ticker.remove(t),r.default.set(i,a);
              let e=()=>{
                l.introClock.t<l.introTuner.read().copyAt||(r.default.to(i,{...o,stagger:.08}),r.default.ticker.remove(e),t===e&&(t=null))
                };
              t=e,r.default.ticker.add(e)
              };
            n(),e.push((0,l.onIntroReplay)(n)),e.push(()=>{
              t&&r.default.ticker.remove(t)
              });
            return
            }
          let u=t.getBoundingClientRect();
          i.forEach(e=>{
            let t=u.width>0?(e.getBoundingClientRect().left-u.left)/u.width*.18:0;
            n.ScrollTrigger.create({trigger:e,start:"top 88%",once:!0,onEnter:()=>r.default.to(e,{...o,delay:t})})
            })
          }),()=>{
          e.forEach(e=>e())
          }
        }),()=>e.revert()
      },[]),null
    }])
  },67585,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"BailoutToCSR",{enumerable:!0,get:function(){
    return l
    }});
  let n=e.r(32061);
  function l({reason:e,children:t}){
    if("u"<typeof window)
    throw Object.defineProperty(new n.BailoutToCSRError(e),"__NEXT_ERROR_CODE",{value:"E394",enumerable:!1,configurable:!0});
    return t
    }
  },9885,(e,t,r)=>{
  "use strict";
  function n(e){
    return e.split("/").map(e=>encodeURIComponent(e)).join("/")
    }
  Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"encodeURIPath",{enumerable:!0,get:function(){
    return n
    }})
  },52157,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"PreloadChunks",{enumerable:!0,get:function(){
    return u
    }});
  let n=e.r(43476),l=e.r(74080),a=e.r(63599),o=e.r(9885),i=e.r(43369);
  function u({moduleIds:e}){
    if("u">typeof window)
    return null;
    let t=a.workAsyncStorage.getStore();
    if(void 0===t)
    return null;
    let r=[];
    if(t.reactLoadableManifest&&e){
      let n=t.reactLoadableManifest;
      for(
      let t
       of e){
        if(!n[t])
        continue;
        let e=n[t].files;
        r.push(...e)
        }
      }
    if(0===r.length)
    return null;
    let s=(0,i.getAssetTokenQuery)();
    return(0,n.jsx)(n.Fragment,{children:r.map(e=>{
      let r=`${t.assetPrefix}/_next/${(0,o.encodeURIPath)(e)}${s}`;
      return e.endsWith(".css")?(0,n.jsx)("link",{precedence:"dynamic",href:r,rel:"stylesheet",as:"style",nonce:t.nonce},e):((0,l.preload)(r,{as:"script",fetchPriority:"low",nonce:t.nonce}),null)
      })})
    }
  },69093,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"default",{enumerable:!0,get:function(){
    return s
    }});
  let n=e.r(43476),l=e.r(71645),a=e.r(67585),o=e.r(52157);
  function i(e){
    return{default:e&&"default"in e?e.default:e}
    }
  let u={loader:()=>Promise.resolve(i(()=>null)),loading:null,ssr:!0},s=function(e){
    let t={...u,...e},r=(0,l.lazy)(()=>t.loader().then(i)),s=t.loading;
    function c(e){
      let i=s?(0,n.jsx)(s,{isLoading:!0,pastDelay:!0,error:null}):null,u=!t.ssr||!!t.loading,c=u?l.Suspense:l.Fragment,d=t.ssr?(0,n.jsxs)(n.Fragment,{children:["u"<typeof window?(0,n.jsx)(o.PreloadChunks,{moduleIds:t.modules}):null,(0,n.jsx)(r,{...e})]}):(0,n.jsx)(a.BailoutToCSR,{reason:"next/dynamic",children:(0,n.jsx)(r,{...e})});
      return(0,n.jsx)(c,{...u?{fallback:i}:{},children:d})
      }
    return c.displayName="LoadableComponent",c
    }
  },70703,(e,t,r)=>{
  "use strict";
  Object.defineProperty(r,"__esModule",{value:!0}),Object.defineProperty(r,"default",{enumerable:!0,get:function(){
    return l
    }});
  let n=e.r(55682)._(e.r(69093));
  function l(e,t){
    let r={};
    "function"==typeof e&&(r.loader=e);
    let l={...r,...t};
    return(0,n.default)({...l,modules:l.loadableGenerated?.modules})
    }
  ("function"==typeof r.default||"object"==typeof r.default&&null!==r.default)&&void 0===r.default.__esModule&&(Object.defineProperty(r.default,"__esModule",{value:!0}),Object.assign(r.default,r),t.exports=r.default)
  },57095,e=>{
  "use strict";
  let t=(0,e.i(56420).default)("play",[["path",{d:"M5 5a2 2 0 0 1 3.008-1.728l11.997 6.998a2 2 0 0 1 .003 3.458l-12 7A2 2 0 0 1 5 19z",key:"10ikf1"}]]);
  e.s(["PlayIcon",0,t],57095)
  },81992,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645),n=e.i(57095),l=e.i(75679);
  e.s(["default",0,function({videoId:e,title:a}){
    let[o,i]=(0,r.useState)(!1);
    return o?(0,t.jsx)("iframe",{className:"absolute inset-0 h-full w-full",src:`https://www.youtube-nocookie.com/embed/${e}?autoplay=1`,title:a,allow:"accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture",allowFullScreen:!0}):(0,t.jsxs)("button",{type:"button",onClick:()=>i(!0),className:"group absolute inset-0 h-full w-full","aria-label":`Play video: ${a}`,...(0,l.trackAttrs)("video_start",{video_provider:"youtube",video_title:a,video_url:`https://www.youtube.com/watch?v=${e}`}),children:[(0,t.jsx)("img",{src:`/external/youtube/${e}.jpg`,alt:"",loading:"lazy",className:"absolute inset-0 h-full w-full object-cover"}),(0,t.jsx)("span",{className:"absolute inset-0 bg-black/20 transition-colors group-hover:bg-black/10"}),(0,t.jsxs)("span",{className:"hud-label absolute bottom-3 left-3 flex items-center gap-1.5 bg-invert-bg px-3 py-1.5 font-bold text-invert-fg",children:[(0,t.jsx)(n.PlayIcon,{"aria-hidden":!0,className:"h-3.5 w-3.5"}),"Play"]})]})
    }])
  },3144,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(71645);
  e.s(["default",0,function({src:e,poster:n,className:l,label:a}){
    let o=(0,r.useRef)(null);
    return(0,r.useEffect)(()=>{
      let e=o.current;
      if(!e)
      return;
      if(window.matchMedia("(prefers-reduced-motion: reduce)").matches){
        e.preload="metadata";
        return
        }
      let t=new IntersectionObserver(([t])=>{
        t.isIntersecting?e.play().catch(()=>{
          }):e.pause()
        },{rootMargin:"160px 0px"});
      return t.observe(e),()=>t.disconnect()
      },[]),(0,t.jsx)("video",{ref:o,src:e,poster:n,className:l,muted:!0,loop:!0,playsInline:!0,preload:"none","aria-label":a})
    }])
  },69529,e=>{
  "use strict";
  let t=null;
  e.s(["webglAvailable",0,function(){
    if(null!==t)
    return t;
    try{
      let e=document.createElement("canvas"),r=e.getContext("webgl2")??e.getContext("webgl")??e.getContext("experimental-webgl");
      t=!!r,r&&"getExtension"in r&&r.getExtension("WEBGL_lose_context")?.loseContext()
      }catch{
      t=!1
      }
    return t
    }])
  },82040,e=>{
  "use strict";
  e.s(["watchThemeColors",0,function(e){
    let t=()=>{
      let t,r,n,l,a,o,i,u;
      return e((t=getComputedStyle(document.documentElement),(r=document.createElement("span")).style.display="none",document.body.appendChild(r),n=e=>{
        r.style.color="",r.style.color=t.getPropertyValue(e).trim();
        let[n=0,l=0,a=0,o=1]=(getComputedStyle(r).color.match(/[\d.]+/g)??[]).map(Number);
        return[n,l,a,o]
        },l=(e,t,r)=>`#${[e,t,r].map(e=>Math.round(Math.max(0,Math.min(255,e))).toString(16).padStart(2,"0")).join("")}`,a=n("--bg"),o=n("--bg-sunken"),i=([e,t,r,n])=>l(e*n+o[0]*(1-n),t*n+o[1]*(1-n),r*n+o[2]*(1-n)),u={bg:l(a[0],a[1],a[2]),bgSunken:l(o[0],o[1],o[2]),ink:i(n("--ink")),line:i(n("--line")),lineStrong:i(n("--line-strong")),accent:i(n("--accent")),accentInk:i(n("--accent-ink"))},r.remove(),u))
      },r=0,n=0,l=()=>{
      t(),performance.now()<n&&(r=requestAnimationFrame(l))
      },a=()=>{
      n=performance.now()+550,cancelAnimationFrame(r),t(),r=requestAnimationFrame(l)
      };
    t();
    let o=new MutationObserver(a);
    o.observe(document.documentElement,{attributes:!0,attributeFilter:["data-theme"]});
    let i=window.matchMedia("(prefers-color-scheme: dark)");
    return i.addEventListener("change",a),()=>{
      cancelAnimationFrame(r),o.disconnect(),i.removeEventListener("change",a)
      }
    }])
  },96627,e=>{
  "use strict";
  var t=e.i(43476),r=e.i(70703),n=e.i(71645),l=e.i(3144),a=e.i(82040),o=e.i(69529);
  let i=(0,r.default)(()=>e.A(46532),{loadableGenerated:{modules:[47055]}});
  class u extends n.Component{
    state={failed:!1};static getDerivedStateFromError(){
      return{failed:!0}
      }render(){
      return this.state.failed?null:this.props.children
      }
  }
  e.s(["default",0,function({videoSrc:e,videoLabel:r}){
    let[s,c]=(0,n.useState)(!1),[d,f]=(0,n.useState)(null),m=(0,n.useRef)(null),p=(0,n.useRef)(null),g=(0,n.useRef)(null),h=(0,n.useRef)({x:0,y:0}),b=(0,n.useRef)(!1),y=(0,n.useRef)(50);
    (0,n.useEffect)(()=>{
      if(!((0,o.webglAvailable)()&&window.matchMedia("(pointer: fine) and (min-width: 768px)").matches&&window.matchMedia("(prefers-reduced-motion: no-preference)").matches))
      return;
      let e=0,t=()=>{
        document.hidden?e=requestAnimationFrame(t):c(!0)
        };
      return e=requestAnimationFrame(t),()=>cancelAnimationFrame(e)
      },[]),(0,n.useEffect)(()=>{
      if(s)
      return(0,a.watchThemeColors)(f)
      },[s]),(0,n.useEffect)(()=>{
      if(!s||!d)
      return;
      let e=m.current;
      if(!e)
      return;
      let t=t=>{
        let r=e.getBoundingClientRect(),n=(t.clientX-r.left)/r.width,l=(t.clientY-r.top)/r.height;
        b.current=!0,h.current.x=2*n-1,h.current.y=2*l-1,y.current=10+80*n
        },r=()=>{
        b.current=!1,h.current.x=0,h.current.y=0
        };
      e.addEventListener("pointermove",t),e.addEventListener("pointerleave",r);
      let n=0,l=50,a=performance.now(),o=e=>{
        let t=Math.min((e-a)/1e3,.1);
        a=e,b.current||(y.current=50+16*Math.sin(e/1e3/3.4)),l+=(y.current-l)*(1-Math.exp(-5*t)),p.current&&(p.current.style.clipPath=`inset(0 ${100-l}% 0 0)`),g.current&&(g.current.style.left=`${l}%`),n=requestAnimationFrame(o)
        };
      return n=requestAnimationFrame(o),()=>{
        e.removeEventListener("pointermove",t),e.removeEventListener("pointerleave",r),cancelAnimationFrame(n)
        }
      },[s,d]);
    let v=s&&null!==d;
    return(0,t.jsxs)("div",{ref:m,className:"absolute inset-0",children:[(0,t.jsx)(l.default,{src:e,label:r,className:"absolute inset-0 h-full w-full object-cover"}),v&&(0,t.jsxs)(u,{children:[(0,t.jsxs)("div",{ref:p,"aria-hidden":!0,className:"absolute inset-0 bg-bg-sunken",style:{clipPath:"inset(0 50% 0 0)"},children:[(0,t.jsx)(i,{colors:d,pointer:h}),(0,t.jsx)("p",{className:"hud-label absolute bottom-3 left-3 bg-invert-bg px-3 py-1.5 font-bold text-invert-fg",children:"3D blocking — your control"})]}),(0,t.jsx)("div",{ref:g,"aria-hidden":!0,className:"absolute top-0 bottom-0 w-px -translate-x-1/2 bg-accent",style:{left:"50%",boxShadow:"0 0 12px 1px var(--accent)"}}),(0,t.jsx)("p",{"aria-hidden":!0,className:"hud-label absolute right-3 bottom-3 bg-invert-bg px-3 py-1.5 font-bold text-invert-fg",children:"AI render — your shot"})]})]})
    }])
  },46532,e=>{
  e.v(t=>Promise.all(["static/chunks/3noeih3m3j-g_.js"].map(t=>e.l(t))).then(()=>t(47055)))
  }]);
