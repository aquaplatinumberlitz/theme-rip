// Keep the saved ArtCraft destinations local, including context-menu and new-tab links.
(() => {
 const routes = new Set(window.__ARTCRAFT_ROUTES__ || []);
 const studioOrigins = new Set(['https://app.getartcraft.com']);
 const websiteOrigins = new Set([location.origin, 'https://getartcraft.com', 'https://www.getartcraft.com']);
 function localDestination(anchor) {
  let url;
  try { url = new URL(anchor.getAttribute('href'), location.href); } catch { return null; }
  const pathname = url.pathname.length > 1 ? url.pathname.replace(/\/$/, '') : '/';
  const isStudio = studioOrigins.has(url.origin) && ['/create-image', '/create-video'].includes(pathname);
  if (!isStudio && !(websiteOrigins.has(url.origin) && routes.has(pathname))) return null;
  return pathname + url.search + url.hash;
 }
 function rewrite(anchor) {
  const local = localDestination(anchor);
  if (local && anchor.getAttribute('href') !== local) anchor.setAttribute('href', local);
 }
 function rewriteTree(node) {
  if (node.nodeType !== Node.ELEMENT_NODE) return;
  if (node.matches('a[href]')) rewrite(node);
  node.querySelectorAll('a[href]').forEach(rewrite);
 }
 document.addEventListener('DOMContentLoaded', () => rewriteTree(document.documentElement));
 new MutationObserver(records => {
  for (const record of records) {
   if (record.type === 'attributes') rewrite(record.target);
   else record.addedNodes.forEach(rewriteTree);
  }
 }).observe(document, {subtree: true, childList: true, attributes: true, attributeFilter: ['href']});
 document.addEventListener('click', event => {
  const anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
  if (!anchor) return;
  const local = localDestination(anchor);
  if (!local) return;
  rewrite(anchor);
  if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey || anchor.download || (anchor.target && anchor.target !== '_self')) return;
  const url = new URL(local, location.href);
  if (url.pathname === location.pathname && url.hash) return;
  event.preventDefault();
  event.stopImmediatePropagation();
  location.assign(local);
 }, true);
})();
