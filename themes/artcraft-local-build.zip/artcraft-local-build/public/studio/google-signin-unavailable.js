// Google Sign-In requires the original ArtCraft service.
