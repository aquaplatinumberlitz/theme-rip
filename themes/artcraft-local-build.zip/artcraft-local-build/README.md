# ArtCraft — bản website và studio local

Bản lưu giao diện ArtCraft tại thời điểm 27/10/2026 (Asia/Tokyo), gồm Home, Craft Apps, Image, Video và các mục trong thanh điều hướng.

## Chạy

Cần Node.js 22 trở lên; không cần cài package.

```bash
cd /home/admin/artcraft-local
npm run dev
```

Mở http://localhost:4175/. Các địa chỉ chính:

- `/` — Home; `/apps` — danh sách Craft Apps.
- `/create-image`, `/create-video` — giao diện studio cho người chưa đăng nhập.
- `/pricing`, `/download`, `/support`.
- `/tutorials`, `/news`, `/faq`, `/press-kit`.
- `/apps/photocraft` và 12 trang Craft Apps còn lại.

Có thể đổi cổng bằng `PORT=8080 npm run dev` hoặc `npm run dev -- --port 8080`. `npm run check` kiểm tra source và tài nguyên. `npm run build` tạo thư mục `dist/`; chạy `npm start` trong `dist/` để dùng bản độc lập.

`dist/public/` chứa bản static của các trang giới thiệu. Giao diện Image/Video cần Node server trong `dist/` để cấp dữ liệu demo qua API local; không chạy đầy đủ bằng static hosting thuần.

## Nội dung và animation

Trang giới thiệu giữ HTML, CSS, font, ảnh, video, React và hiệu ứng site công khai. Hero dùng Three.js/WebGL, shader và 35 video; các video feature và video demo của Craft Apps được lưu local. Giữ theme sáng/tối, menu responsive, chuyển động khi cuộn, menu tải, chọn gói Pricing và các liên kết.

Image/Video dùng bundle studio gốc, dữ liệu model và session không đăng nhập chụp từ API gốc. Các lựa chọn model và thông số trình bày trên giao diện hoạt động trong phạm vi giao diện demo. **Không có backend sinh AI, tài khoản, thanh toán, upload hay tạo kết quả thật.** Dữ liệu chi phí/credit là ảnh chụp cho lựa chọn mặc định, không tính giá thực khi đổi model. Những chức năng cần tài khoản và dịch vụ gốc cần triển khai backend riêng hoặc dùng ArtCraft thật. Google Sign-In không hoạt động ở bản local. Các trang ứng dụng khác trong sidebar studio như Audio, 3D, Editor và Library nằm ngoài phạm vi dựng và chưa được triển khai.

Các liên kết GitHub, Discord, download và xem video YouTube vẫn mở dịch vụ tương ứng. Các trang website không có trong danh sách trên chuyển tới site gốc.

## Cấu trúc

- `src/pages/`: HTML và dữ liệu React Server Components cho trang website, cùng `studio.html`.
- `src/frontend/`: bundle React/Next.js, GSAP, Three.js, shader và các thành phần của website đã đặt tên, xuống dòng để đọc.
- `src/styles/app.css`: CSS website.
- `public/studio/assets/`: bundle React, CSS và WebAssembly công khai của ứng dụng studio; đã sửa API host về local.
- `server/studio-fixtures.json`: dữ liệu session, danh sách model và chi phí mặc định cho bản demo.
- `server/routes.json`, `server/modules.json`: ánh xạ URL và module.
- `public/`: font, ảnh, video và các tài nguyên khác.
- `reference/`: bản gốc, thông tin nguồn, ảnh chụp và dữ liệu dùng đối chiếu.
- `verification/`: ảnh và báo cáo kiểm tra.

Đây là bản dựng từ frontend đã phát hành, không phải repository TypeScript/React/Next.js chưa biên dịch của tác giả. Bản studio chỉ sửa địa chỉ API, đường dẫn tài nguyên và tắt script Google Sign-In. Các video và tài nguyên marketing được đưa về local. Các module có tên biến minify là một phần bundle phát hành.

Để sửa văn bản thuộc React Server Components, cần cập nhật dữ liệu trong HTML và module client tương ứng để tránh sai lệch khi hydrate. Chi tiết nguồn và cách tái tạo bản ban đầu nằm trong `reference/PROVENANCE.md` và `tools/`.

Các liên kết menu của những trang đã lưu được chuyển về local, bao gồm mở tab mới và sao chép địa chỉ liên kết. Nếu đang dùng ZIP cũ, hãy thay bằng bản cập nhật và khởi động lại server.
