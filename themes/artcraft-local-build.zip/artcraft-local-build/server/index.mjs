import http from 'node:http';
import {createReadStream} from 'node:fs';
import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
export const root=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'..');
const fixtures=JSON.parse(await fs.readFile(new URL('./studio-fixtures.json',import.meta.url),'utf8'));
const routes=JSON.parse(await fs.readFile(new URL('./routes.json',import.meta.url),'utf8'));
const modules=JSON.parse(await fs.readFile(new URL('./modules.json',import.meta.url),'utf8'));
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.mjs':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.svg':'image/svg+xml','.png':'image/png','.webp':'image/webp','.jpg':'image/jpeg','.jpeg':'image/jpeg','.avif':'image/avif','.woff2':'font/woff2','.woff':'font/woff','.mp4':'video/mp4','.webm':'video/webm','.wasm':'application/wasm'};
export const server=http.createServer(async(req,res)=>{
 try{
  const url=new URL(req.url,'http://localhost');const route=decodeURIComponent(url.pathname);
  if(route.startsWith('/v1/')){const fixture=fixtures[route];const allowed=fixture&&fixture.method===req.method;res.writeHead(allowed?(fixture.status||200):501,{'content-type':'application/json','cache-control':'no-store'});res.end(JSON.stringify(allowed?fixture.response:{success:false,error:'Chức năng này cần kết nối tài khoản và backend ArtCraft.'}));return;}
  if(!['GET','HEAD'].includes(req.method)){res.writeHead(405);res.end();return;}
  const normalized=route.length>1?route.replace(/\/$/,''):route;
  if(routes[normalized]){
   const html=await fs.readFile(path.join(root,'src/pages',routes[normalized]+'.html'));
   res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-cache'});res.end(req.method==='HEAD'?undefined:html);return;
  }
  const alias=route.startsWith('/_next/static/chunks/')?modules[path.basename(route)]:null;
  const file=alias?path.resolve(root,alias):path.resolve(root,'public','.'+route);
  if(!alias&&!file.startsWith(path.join(root,'public')+path.sep)){res.writeHead(403);res.end();return;}
  let stat;try{stat=await fs.stat(file);}catch{if(!path.extname(route)&&!route.startsWith('/_next/')){res.writeHead(302,{location:'https://getartcraft.com'+url.pathname+url.search+url.hash});res.end();return;}res.writeHead(404);res.end('Not found');return;}
  if(!stat.isFile()){res.writeHead(404);res.end();return;}
  const headers={'content-type':mime[path.extname(file)]||'application/octet-stream','accept-ranges':'bytes','cache-control':'public, max-age=3600'};
  let start=0,end=stat.size-1,status=200;
  if(req.headers.range){const match=/^bytes=(\d*)-(\d*)$/.exec(req.headers.range);if(!match){res.writeHead(416,{'content-range':`bytes */${stat.size}`});res.end();return;}
   if(match[1]){start=Number(match[1]);if(match[2])end=Math.min(Number(match[2]),end);}else if(match[2])start=Math.max(0,stat.size-Number(match[2]));
   if(start>end||start>=stat.size){res.writeHead(416,{'content-range':`bytes */${stat.size}`});res.end();return;}status=206;headers['content-range']=`bytes ${start}-${end}/${stat.size}`;
  }
  headers['content-length']=end-start+1;res.writeHead(status,headers);if(req.method==='HEAD')res.end();else createReadStream(file,{start,end}).pipe(res);
 }catch(e){console.error(e);if(!res.headersSent)res.writeHead(500);res.end('Server error');}
});
if(process.argv[1]&&path.resolve(process.argv[1])===fileURLToPath(import.meta.url)){const i=process.argv.indexOf('--port');const port=Number(process.env.PORT||(i>=0?process.argv[i+1]:4175));server.listen(port,'0.0.0.0',()=>console.log(`ArtCraft local: http://localhost:${port}\nApps: http://localhost:${port}/apps`));}
